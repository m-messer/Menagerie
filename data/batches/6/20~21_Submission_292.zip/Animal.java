import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 */
public abstract class Animal
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;
    // Boolean representing if the animal is male or not
    private boolean gender;
    // The animal's food level, which is increased by eating.
    protected int foodLevel;
    // Wheather the animal is infected
    private boolean infected ; 
    // The chance of being infected   
    private float infectionProbability = 0.05f;
    // The chance of dying from infection  
    private float mortalityRate = 0.1f;
    // The chance of recovering from infection 
    private float recoveryRate = 0.3f;
    // The infection's incubation period 
    protected int incubationSteps = 3;
    // The sinmulation's time
    protected int hours;
    // The animal's age
    protected int age;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        gender = randomiseGender(); 
        this.field = field;
        setLocation(location);
        infected = randomiseInfected() ; 
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Increments the animal's age
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Make this animal hungrier. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = newAnimal();
            newAnimals.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if the animal can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Checks whether the animal is allowed to breed.
     * @return true if animal is allowed to breed.
     */
    private boolean canBreed()
    {
        boolean canBreed = false ; 
        
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location neighbour = it.next();
            Object animal = field.getObjectAt(neighbour);
            // Checks if there is an animal of opposite gender
            if(getPartner(animal)) { 
                Animal partner = (Animal) animal;
                if(partner.getGender() != getGender() ) { 
                    canBreed = true ;
                }
                else{
                    canBreed = false ;
                }
            }
        }
        
        if (age >= getBreedingAge()){
            canBreed = true;
        }
        
        return canBreed; 
    }
    
    /**
     * Pass on a disease to an adjacent animal.
     */
    protected void infect()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location neighbour = it.next();
            Object animal = field.getObjectAt(neighbour);
            if(getPartner(animal)){
                Animal partner = (Animal) animal;
                if(!partner.isInfected()){ 
                    partner.setInfected(randomiseInfected()); 
                }
            }
        }
    }
    
    /**
     * Decides the outcome of an infection. An animal can recover, die
     * or stay infected.
     */
    protected void processInfection(){
        if(isInfected()){
            float probability = rand.nextFloat();
            
            if(probability <= mortalityRate){
                setDead();
            }
            else if(probability <= recoveryRate){
                toggleInfected();
            }
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Get the animal's gender.
     * @return the animals gender
     */
    protected boolean getGender()
    {
        return gender; 
    }
    
    /**
     * Set the animal's gender.
     * @return true if male
     */
    private boolean randomiseGender()
    {
        return rand.nextBoolean(); 
    }
    
    /**
     * Randomly decides if an animal gets infected.
     * @return true if animal is infected
     */
    private boolean randomiseInfected()
    {
        float probability  = rand.nextFloat();
        
        return probability <= infectionProbability;
    }
    
    /**
     * Set the animal's infection.
     * @param Whether the animal is infected or not;
     */
    private void setInfected(boolean infect)
    {
        infected = infect; 
    }
    
    /**
     * Toggle the animal's infection.
     */
    private void toggleInfected()
    {
        infected = !infected; 
    }
    
    /**
     * Check if animal is infected.
     * @return true if animal is infected
     */
    private boolean isInfected()
    {
        return infected; 
    }
    
    /**
     * Get the simulation's time
     * @param The simulation's time
     */
    public void tellTime(int hours){
        this.hours = hours;
    }
    
    /**
     * Gets the animal's breeding probability
     * @return The animal's breeding probability
     */
    abstract protected double getBreedingProbability();
    
    /**
     * Gets the animal's max litter size
     * @return The animal's max litter size
     */
    abstract protected int getMaxLitterSize();
    
    /**
     * Gets the animal's breeding age
     * @return The animal's breeding age
     */
    abstract protected int getBreedingAge();
    
    /**
     * Gets the animal's max age
     * @return The animal's max age
     */
    abstract protected int getMaxAge();
    
    /**
     * Gets the animal's partner.
     * @param The type of animal the partner has to be
     * @return true if animal is of the same type
     */
    abstract protected boolean getPartner(Object animal);
    
    /**
     * Creates a new animal.
     * @return The new animal
     */
    abstract protected Animal newAnimal();
    
}
