import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing different animals and plants.
 *
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a human will be created in any given grid position.
    private static final double HUMAN_CREATION_PROBABILITY = 0.006;
    // The probability that a mammoth will be created in any given grid position.
    private static final double MAMMOTH_CREATION_PROBABILITY = 0.24;
    // The probability that a tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.014;
    // The probability that a sloth will be created in any given grid position.
    private static final double SLOTH_CREATION_PROBABILITY = 0.24;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.24;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.12;
    // The probability that a snow will occur.
    private static final double SNOW_CREATION_PROBABILITY = 0.3; 
    
    private boolean isSnowing = false  ; 

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // Hours passd from the start of the simulation
    public int hours = 0;
    // Default weather
    public String weather = "" ; 
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Mammoth.class, Color.BLACK);
        view.setColor(Human.class, Color.PINK);
        view.setColor(Tiger.class, Color.ORANGE);
        view.setColor(Sloth.class, Color.BLUE);
        view.setColor(Squirrel.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period.
     */
    public void runLongSimulation()
    {
        simulate(10000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        incrementTime();
        toggleSnow();
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        
        // Let all plants grow
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ){
            Plant plant = it.next();
            plant.grow();
        }
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            animal.tellTime(hours);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        
        //Generate more plants if it is not snowing
        if (!isSnowing){
            Random rand = Randomizer.getRandom();
           for(int row = 0; row < field.getDepth(); row++) {
                for(int col = 0; col < field.getWidth(); col++) {
                    if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        
                        if(field.getObjectAt(location) == null){
                            Plant plant = new Plant(true, field, location);
                            plants.add(plant);
                        }
                    }
                }
            }
        }
       
        
        
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field, hours, weather);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        hours = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, hours, weather);
    }
    
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HUMAN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Human human = new Human(true, field, location);
                    animals.add(human);
                }
                else if(rand.nextDouble() <= MAMMOTH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mammoth mammoth = new Mammoth(true, field, location);
                    animals.add(mammoth);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= SLOTH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sloth sloth = new Sloth(true, field, location);
                    animals.add(sloth);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    animals.add(squirrel);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    plants.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Increments the simulation's time
     */
    private void incrementTime(){
        hours = (hours + 1) % 24;
    }
    
    /**
     * Returns the simulation's time
     * @return hours 
     */
    public int getHours(){
        return hours;
    }
    
    /**
     * Randomly toggles the simulation's weather
     */
    private void toggleSnow(){
        Random rand = Randomizer.getRandom();   
        float probability = rand.nextFloat(); 
        
        if (probability> SNOW_CREATION_PROBABILITY) {
            isSnowing = false ;
            weather = "Overcast";
        } 
        else if (probability<= SNOW_CREATION_PROBABILITY) {
            isSnowing = true ;
            weather = "Snowing";
        }
    }
}
