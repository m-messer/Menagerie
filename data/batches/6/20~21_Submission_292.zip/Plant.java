import java.util.*;

/**
 * A class representing a plant. PLants grow at a given rate
 * but do not move. Prey eat plants.
 *
 */
public class Plant
{
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    
    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    protected Field field;
    // The plant's position in the field.
    protected Location location;
    
    //The plant's food value
    private int FOOD_VALUE = 10;
    
    //Steps until fully grown
    private int MAX_AGE = 2;
    
    //The age of the plant
    private int age;
    
    /**
     * Constructor for objects of class Plant
     * 
     * @param randomAge If true, the plant will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge,Field field, Location location){
        alive = true;
        this.field = field;
        setLocation(location);
        
        age = 0;
        if(randomAge){
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * Increments the plant's age
     */
    public void grow(){
        if(age < MAX_AGE){
            age++;
        }
    }
    
    /**
     * Returns if the plant is fully grown
     * @return true if plant is fully grown
     */
    public boolean isGrown(){
        return age == MAX_AGE;
    }
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field
     */
    public void setDead(){
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Returns the plant's food value
     * @return The plant's food value
     */
    public int getFoodValue(){
        return FOOD_VALUE;
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
}
