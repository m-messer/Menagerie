import java.util.List;
import java.util.Iterator;
/**
 * Predator of type Tiger .
 *
 */


public class Human extends Predator
{
    // The age at which a human can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a human can live.
    private static final int MAX_AGE = 15;
    // The likelihood of a human breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    
    /**
     * Constructor for objects of class Human
     * 
     * @param randomAge If true, the human will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Human(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Gets the human's max age
     * @return The human's max age
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * Gets the human's breeding probability
     * @return The human's breeding probability
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Gets the human's max litter size 
     * @return The human's max litter size
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Gets the human's max breeding age 
     * @return The human's max breeding age
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Creates a new human.
     * @return The new human
     */
    protected Human newAnimal(){
        return new Human(false, field, location);
    }
    
    /**
     * Check the human's diet: what prey the predator 
     * should be eating.
     * @param potential food
     * @return true if animal is part of diet
     */
    protected boolean checkDiet(Object animal){
        return (animal instanceof Sloth || animal instanceof Mammoth);
    }
    
    /**
     * Gets the human's partner.
     * @param The type of animal the partner has to be
     * @return true if animal is of the same type
     */
        protected boolean getPartner(Object animal){
        return (animal instanceof Human);
    }
    
    /**
     * Checks whether the human has to sleep.
     * return true if human is awake
     */
    protected boolean checkTime(){
        return (hours > 12 && hours < 24) || (hours > 0 && hours < 7);
    }
}