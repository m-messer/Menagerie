import java.util.List;
import java.util.Iterator;
/**
 * Predator of type Tiger .
 *
 */


public class Tiger extends Predator
{
    // The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a tiger can live.
    private static final int MAX_AGE = 15;
    // The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    
    /**
     * Constructor for objects of class Tiger
     * 
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Gets the tiger's max age
     * @return The tiger's max age
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * Gets the tiger's breeding probability
     * @return The tiger's breeding probability
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Gets the tiger's max litter size 
     * @return The tiger's max litter size
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Gets the tiger's max breeding age 
     * @return The tiger's max breeding age
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Creates a new tiger.
     * @return The new tiger
     */
    protected Tiger newAnimal(){
        return new Tiger(false, field, location);
    }
    
    /**
     * Check the tiger's diet: what prey the predator 
     * should be eating.
     * @param potential food
     * @return true if animal is part of diet
     */
    protected boolean checkDiet(Object animal){
        return (animal instanceof Squirrel || animal instanceof Mammoth);
    }
    
    /**
     * Gets the tiger's partner.
     * @param The type of animal the partner has to be
     * @return true if animal is of the same type
     */
        protected boolean getPartner(Object animal){
        return (animal instanceof Tiger);
    }
    
    /**
     * Checks whether the tiger has to sleep.
     * return true if tiger is awake
     */
    protected boolean checkTime(){
        return (hours > 12 && hours < 24) || (hours > 0 && hours < 7);
    }
}