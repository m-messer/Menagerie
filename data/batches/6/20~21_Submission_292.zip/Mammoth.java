import java.util.List;
import java.util.Iterator;
/**
 * Prey of type Mammoth .
 *
 */


public class Mammoth  extends Prey
{
    // The age at which a mammoth can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a mammoth can live.
    private static final int MAX_AGE = 25;
    // The likelihood of a mammothloth breeding.
    private static final double BREEDING_PROBABILITY = 0.31;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value that a mammoth gives to a predator
    private static final int FOOD_VALUE = 10;
    
    /**
     * Constructor for objects of class Mammoth
     * 
     * @param randomAge If true, the mammoth will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mammoth(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Gets the mammoth's max age
     * @return The mammoth's max age
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * Gets the sloth's breeding probability
     * @return The sloth's breeding probability
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Gets the mammoth's max litter size 
     * @return The mammoth's max litter size
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Gets the mammoth's breeding age
     * @return The mammoth's breeding age
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Creates a new mammoth.
     * @return The new mammoth
     */
    protected Mammoth newAnimal(){
        return new Mammoth(false, field, location);
    }
    
    /**
     * Gets the mammoth's partner.
     * @param The type of animal the partner has to be
     * @return true if animal is of the same type
     */
    protected boolean getPartner(Object animal){
        return (animal instanceof Mammoth);
    }
    
    /**
     * Gets the mammoth's food value
     * @return The mammoth's food value
     * 
     */
    public int getFoodValue(){
        return FOOD_VALUE;
    }
}
