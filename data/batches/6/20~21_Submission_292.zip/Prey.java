import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * Animal of type prey.
 *
 */
public abstract class Prey extends Animal
{
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();  
    // The prey max food value at birth
    private static final int MAX_FOOD_VALUE = 5;
    
    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        foodLevel = rand.nextInt(MAX_FOOD_VALUE);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
        }
    }
    
    /**
     * This is what the prey does most of the time: it looks for
     * plants to eat. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newPrey A list to return newly born prey.
     */
    public void act(List<Animal> newPrey)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPrey);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            if(newLocation != null) {
                setLocation(newLocation);
                infect();
                processInfection();
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first fully grown plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant){
                Plant food = (Plant) plant;
                if(food.isGrown()){ 
                    food.setDead();
                    foodLevel = getPlantFoodValue(food);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Gets the plant's food value
     * @param The plant object
     */
    private int getPlantFoodValue(Plant plant){
        return plant.getFoodValue();
    }
    
    /**
     * Gets the prey's food value
     * @return The prey's food value
     */
    abstract int getFoodValue();
}
