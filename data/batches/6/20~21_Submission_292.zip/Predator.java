import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Animal of type predator.
 *
 */
public abstract class Predator extends Animal 
{
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    // The predator's max food value at birth
    private static final int MAX_FOOD_VALUE = 4;
    
    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(MAX_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newPredators A list to return newly born predators.
     */
    public void act(List<Animal> newPredators)
    {
        incrementAge();
        if(checkTime()){
            incrementHunger();
            if(isAlive()) {
                giveBirth(newPredators);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                    infect();
                    processInfection();
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live pray is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(checkDiet(animal)) {
                Prey food = (Prey) animal;
                if(food.isAlive()) { 
                    food.setDead();
                    foodLevel = getPreyFoodValue(food);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Returns the prey's food value
     * @param the prey in question
     * @return the prey's food value
     */
    protected int getPreyFoodValue(Prey animal){
        return animal.getFoodValue();
    }
    
    /**
     * Check the animal's diet: what prey the predator 
     * should be eating.
     * @param potential food
     * @return true if animal is part of diet
     */
    abstract protected boolean checkDiet(Object animal);
    
    /**
     * Checks whether the predator has to sleep.
     * return true if predator is awake
     */
    abstract protected boolean checkTime();
}
