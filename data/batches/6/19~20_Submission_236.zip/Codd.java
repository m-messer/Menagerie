import java.util.List;
import java.util.Random;

/**
 * This is the class of the animal codd
 *
 * @version 2019.02.23
 */
public class Codd extends Prey
{
    // Characteristics shared by all codds (class variables).

    // The age at which a codd it can start to breed.
    private static final int BREEDING_AGE = 4;
    // If it acts during the day or during night.
    private static final boolean DAY = true;
    // The age to which a codd it can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a codd it breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food capacity
    private static final int FOOD_CAPACITY = 15;
    
    // Individual characteristics (instance fields).
    

    /**
     * Create a new codd. A codd it may be created with age
     * zero (a new born) or with a random age.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param foodLevel the food level
     */
    public Codd(Field field, Location location, int foodLevel)
    {
        super(field, location, foodLevel,0,MAX_AGE,BREEDING_AGE,BREEDING_PROBABILITY,MAX_LITTER_SIZE);
    }

    /**
     * Instantiates a new Codd.
     *
     * @param field    the field
     * @param location the location
     */
    public Codd(Field field, Location location)
    {
        super(field, location, MAX_AGE,BREEDING_AGE,BREEDING_PROBABILITY,MAX_LITTER_SIZE);
    }

    /**
     * @see Animal
     * Includes the behaviour of the animal with the weather
     *
     * @param newCodds
     * @param isDay     if it is day
     * @param weather   the weather
     */
    @Override
    public void act(List<Actor> newCodds, boolean isDay, Weather weather) {

        if(isDay) {
            super.act(newCodds);

            if (weather == Weather.SUNNY) super.act(newCodds);

        }

        if(weather == Weather.STORM){
            if(isDay != DAY) {
                if (rand.nextDouble() < 0.1) setDead();
            }else{
                super.act(newCodds);
                if (rand.nextDouble() < 0.05) setDead();
            }
        }
    }

    /**
     * Create actor codd
     *
     * @param loc   the location it will be
     * @param field the field it will be
     * @return
     */
    @Override
    protected Actor create(Location loc, Field field) {
        return new Codd(field,loc, getFoodLevel());
    }

    /***
     * Get the food value
     *
     * @return
     */
    @Override
    public int getFoodValue() {
        return 15;
    }
}
