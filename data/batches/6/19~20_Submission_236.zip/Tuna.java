import java.util.List;
import java.util.Random;

/**
 * This is the class of the animal tuna.
 *
 * @version 2019.02.23
 */
public class Tuna extends Prey {
    // Characteristics shared by all tunas (class variables).

    // The age at which a tuna can start to breed.
    private static final int BREEDING_AGE = 6;
    // If it acts during the day or during night.
    private static final boolean DAY = false;
    // The age to which a tuna can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a tuna breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Create a new tuna. A tuna may be created with age
     * zero (a new born) or with a random age.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param foodLevel the food level
     */
    public Tuna(Field field, Location location, int foodLevel)
    {
        super(field, location, foodLevel,0,MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);

    }

    /**
     * Instantiates a new Tuna.
     *
     * @param field    the field
     * @param location the location
     */
    public Tuna(Field field, Location location)
    {
        super(field, location, MAX_AGE,BREEDING_AGE,BREEDING_PROBABILITY,MAX_LITTER_SIZE);

    }

    /**
     * @param newTunas
     * @param isDay    if it is day
     * @param weather  the weather
     * @see Animal
     * Includes the behaviour of the animal with the weather
     */
    @Override
    public void act(List<Actor> newTunas, boolean isDay, Weather weather) {
        if(isDay == DAY) {

            super.act(newTunas);

            if (weather == Weather.SUNNY) super.act(newTunas);

        }

        if (weather == Weather.STORM) {
            if (isDay != DAY) {
                if (rand.nextDouble() < 0.3) setDead();
            } else {
                super.act(newTunas);
                if (rand.nextDouble() < 0.1) setDead();
            }
        }

    }

    /**
     * Create actor tuna
     *
     * @param loc   the location it will be
     * @param field the field it will be
     * @return
     */
    @Override
    protected Actor create(Location loc, Field field) {
        return new Tuna(field, loc, getFoodLevel());
    }

    /***
     * Get the food value
     *
     * @return
     */
    @Override
    public int getFoodValue() {
        return 12;
    }
}
