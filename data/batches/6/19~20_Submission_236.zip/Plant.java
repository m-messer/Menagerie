import java.util.List;

/**
 * This class containts all the methods and fields neeeded by the plants
 *
 * @version 2019.02.23
 */
public abstract class Plant extends Actor {

    /**
     * The constant PROBABILITY_MAKE_DISEASE.
     */
// Probability of the plant to create a disease.
    public static final double PROBABILITY_MAKE_DISEASE = 0.0000008;

    /**
     * Instantiates a new Plant.
     *
     * @param field               the field
     * @param location            the location
     * @param foodLevel           the food level
     * @param age                 the age
     * @param max_age             the max age
     * @param breeding_age        the breeding age
     * @param breeding_probabilty the breeding probabilty
     * @param food_step           the food step
     */
    public Plant(Field field, Location location, int foodLevel, int age, int max_age, int breeding_age, double breeding_probabilty, int food_step) {
        super(field, location, foodLevel, age, max_age, breeding_age, breeding_probabilty, food_step);
    }

    /**
     * Instantiates a new Plant.
     *
     * @param field                the field
     * @param location             the location
     * @param max_age              the max age
     * @param breeding_age         the breeding age
     * @param breeding_probability the breeding probability
     * @param food_step            the food step
     */
    public Plant(Field field, Location location, int max_age, int breeding_age, double breeding_probability, int food_step) {
        super(field, location, max_age, breeding_age, breeding_probability, food_step);
    }

    /**
     * It can make a disease if the probability matches.
     */
    protected void makeDisease() {
        if (rand.nextDouble() < PROBABILITY_MAKE_DISEASE) {
            hasDisease = true;
            disease = new Disease();
            longDisease = disease.getHowLong();
        }
    }

    /**
     * This is what the plant does most of the time.
     * It might breed, die of hunger, make a disease
     * or die of old age.
     *
     * @param newPlants A list to return newly born plants.
     */
    public void act(List<Actor> newPlants, boolean isDay, Weather weather) {
        if (isDay && weather == Weather.SUNNY && foodLevel < food_step)
            foodLevel = Math.max(rand.nextInt(food_step), foodLevel);

        if (isDay == day) {
            makeDisease();

            if (isAlive()) {
                if (weather == Weather.SUNNY) {
                    giveBirth(newPlants);
                } else if (weather == Weather.STORM) {
                    giveBirth(newPlants);
                    giveBirth(newPlants);
                }
            }
        }
    }

    /***
     * Get the food value
     *
     * @return
     */
    @Override
    public int getFoodValue() {
        return 3;
    }


    /**
     * Create actor.
     *
     * @param loc   the loc
     * @param field the field
     * @return the actor
     */
    abstract protected Actor create(Location loc, Field field);

    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newPlants A list to return newly born plants.
     */
    private void giveBirth(List<Actor> newPlants) {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newPlants.add(create(loc, field));
        }
    }
}

