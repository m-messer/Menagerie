import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * This abstract class provides all the methods and fields needed by all actors of the simulation
 *
 * @version 2019.02.23
 */
public abstract class Actor implements Killable
{
    // Whether the actor is alive or not.
    protected boolean alive;
    // Whether the actor is a male or not.
    protected boolean male;
    // The disease of the actor, if it gets it.
    protected Disease disease;
    // The disease's duration of the actor, if it gets it.
    protected int longDisease;
    // Whether the actor has a disease or not.
    protected boolean hasDisease;
    // Whether the actor acts during the day or not (therefore night).
    protected boolean day;
    // Age of the actor.
    protected int age;
    // The maximum the actor can live.
    protected int max_age;
    //The actor's food level.
    protected int foodLevel;
    // The actor's field.
    protected Field field;
    // The actor's position in the field.
    protected Location location;
    //The actor's breeding age.
    protected int breeding_age;
    //The actor's breeding probability.
    protected double breeding_prob;
    //The actor's food step.
    protected int food_step;
    //The actor's food capacity
    protected int foodCapacity;

    //Random from class Randomizer
    protected static final Random rand = Randomizer.getRandom();

    /**
     * Create a new actor at location in field.
     *
     * @param field               The field currently occupied.
     * @param location            The location within the field.
     * @param foodLevel           the food level
     * @param age                 the initial age
     * @param max_age             the max age
     * @param breeding_age        the breeding age
     * @param breeding_probabilty the breeding probabilty
     * @param food_step           the food step
     */
    public Actor(Field field, Location location,  int foodLevel, int age, int max_age, int breeding_age, double breeding_probabilty, int food_step)
    {
        alive = true;
        this.field = field;
        this.male = rand.nextBoolean();
        this.breeding_age = breeding_age + rand.nextInt(breeding_age/2 + 1);
        this.breeding_prob = breeding_probabilty*3;
        this.max_age = max_age + rand.nextInt(max_age/2);
        this.age = age;
        this.foodLevel = foodLevel;
        this.food_step = food_step * 5;

        setLocation(location);
    }

    /**
     * Instantiates a new Actor.
     *
     * @param field                the field
     * @param location             the location
     * @param max_age              the max age
     * @param breeding_age         the breeding age
     * @param breeding_probability the breeding probability
     * @param food_step            the food step
     */
    public Actor(Field field, Location location, int max_age, int breeding_age, double breeding_probability, int food_step){
       this(field,location,rand.nextInt(30),rand.nextInt(max_age),max_age,breeding_age,breeding_probability, food_step);
    }

    /**
     * Increase the age. This could result in the actor's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > max_age) {
            setDead();
        }
    }

    /**
     * Checks if two animals are of different sexes so they can have birth.
     *
     * @return a boolean, true if they can give birth
     */
    protected boolean differentSex() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Actor o = (Actor) field.getObjectAt(where);
            if (o != null && o.getClass() == this.getClass()) {
                if (o.canBreed()) {
                    if (hasDisease == true) transmitInfection(o, this.getDisease());
                    if (o.isMale() != this.isMale()) {
                        return true;
                    }
                }
            }
        }

        return true;
    }

    /**
     * An actor can breed if it has reached the breeding age.
     */
    protected boolean canBreed() {
        return age >= breeding_age;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed and if it has a partner close.
     *
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= breeding_prob && differentSex()) {
            births = rand.nextInt(food_step) + 1;
        }
        return births;
    }

    /**
     * Make this actor more hungry. This could result in the actor's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Transmit infection.
     *
     * @param actor   the actor to which the infection is being transmited
     * @param disease the disease
     */
    protected void transmitInfection(Actor actor, Disease disease){
        if(actor != null && rand.nextDouble() < disease.getInfectiousRate()) {
            actor.hasDisease = true;
            actor.disease = disease;
            actor.longDisease = disease.getHowLong();
        }
    }


    /**
     * If after incrementing the age, hunger and disease (if it has)
     * makes the actor act
     *
     * @param newActors the new actors
     * @param isDay     the is day
     * @param weather   the weather
     */
    public void action(List<Actor> newActors, boolean isDay, Weather weather) {
        incrementAge();
        incrementHunger();
        increaseDisease();

        if(isAlive())
            act(newActors,isDay,weather);
    }

    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newActors A list to receive newly born actors
     * @param isDay     the is day
     * @param weather   the weather
     */
    abstract protected void act(List<Actor> newActors, boolean isDay, Weather weather);

    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * If it has a disease, increase the duration of it.
     */
    public void increaseDisease()
    {
        if(hasDisease && --longDisease<=0){
            if (rand.nextDouble()<disease.getMortalityRate()) setDead();
            else cureDisease();
        }
    }

    /**
     * Cure disease.
     */
    protected void cureDisease(){
        disease = null;
        hasDisease = false;
    }

    /**
     * Is male boolean.
     *
     * @return true if it is a male, false if female
     */
    protected boolean isMale(){
        return male;
    }

    /**
     * Get food level int.
     *
     * @return the int
     */
    protected int getFoodLevel(){
        return foodLevel;
    }

    /**
     * Has disease boolean.
     *
     * @return the boolean
     */
    public boolean hasDisease(){
        return hasDisease;
    }

    /**
     * Get disease of the actor.
     *
     * @return the disease
     */
    public Disease getDisease(){
        return disease;
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /***
     * Abstract method that returns the food value of the actor
     *
     * @return
     */
    public abstract int getFoodValue();

    /**
     * Return the actor's location.
     *
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     *
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }

        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the actor's field.
     *
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }
}
