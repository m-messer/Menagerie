import java.util.Iterator;
import java.util.List;

/**
 * This abstract class containts all the methods needed by the animals
 *
 * @version 2019.02.23
 */
public abstract class Animal extends Actor {

    /**
     * Instantiates a new Animal.
     *
     * @param field               the field
     * @param location            the location
     * @param foodLevel           the food level
     * @param age                 the age
     * @param max_age             the max age
     * @param breeding_age        the breeding age
     * @param breeding_probabilty the breeding probabilty
     * @param food_step           the food step
     */
    public Animal(Field field, Location location, int foodLevel, int age, int max_age, int breeding_age, double breeding_probabilty, int food_step) {
        super(field, location, foodLevel, age, max_age, breeding_age, breeding_probabilty, food_step);
    }

    /**
     * Instantiates a new Animal.
     *
     * @param field                the field
     * @param location             the location
     * @param max_age              the max age
     * @param breeding_age         the breeding age
     * @param breeding_probability the breeding probability
     * @param food_step            the food step
     */
    public Animal(Field field, Location location, int max_age, int breeding_age, double breeding_probability, int food_step) {
        super(field, location, max_age, breeding_age, breeding_probability, food_step);
        this.foodCapacity = foodCapacity;
    }

    /**
     * This is what the animal does most of the time: it looks for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newAnimals A list to return newly born animals.
     */
    public void act(List<Actor> newAnimals) {

        if (isAlive()) {
            giveBirth(newAnimals);
            // Move towards a source of food if found.
            Location newLocation = null;

            if (foodLevel < food_step) newLocation = findFood();

            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Get the food value of the animal.
     */
    @Override
    public int getFoodValue() {
        return 9;
    }

    /**
     * Checks if the adjacent actor is desirable for this animal.
     *
     * @param o the adjacent actor
     * @return the boolean, true if it is desirable, false otherwise
     */
    abstract protected boolean desirable(Object o);

    /**
     * Look for actors adjacent to the current location.
     * Only the first live desirable food is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object o = field.getObjectAt(where);
            if (desirable(o)) {
                Killable foodSource = (Killable) o;
                Actor actor = (Actor) o;
                if (foodSource.isAlive()) {
                    foodSource.setDead();
                    
                    foodLevel += foodSource.getFoodValue();

                    if (actor.hasDisease == true) transmitInfection(this, actor.getDisease());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Create actor.
     *
     * @param loc   the loc
     * @param field the field
     * @return the actor
     */
    abstract protected Actor create(Location loc, Field field);

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newBirths A list to return newly born animals.
     */
    private void giveBirth(List<Actor> newBirths) {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newBirths.add(create(loc, field));
        }
    }

    /**
     * @return The number of births (may be zero).
     * @see Actor
     * Checks before if it is a female
     */
    protected int breed() {
        if (male) {
            return 0;
        }
        return super.breed();
    }
}
