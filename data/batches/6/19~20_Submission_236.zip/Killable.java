/**
 * Interface that sets the methods needed for that animals thar are killeable
 *
 * @version 2019.02.23
 */
public interface Killable {
    /**
     * Is alive boolean.
     *
     * @return the boolean
     */
    boolean isAlive();

    /**
     * Sets the actor dead.
     */
    void setDead();

    /**
     * Gets food value.
     *
     * @return the food value
     */
    int getFoodValue();
}
