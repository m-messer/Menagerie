/**
 * Enum containing the weathers of the simulation.
 *
 * @version 2019.02.23
 */
public enum Weather {
    SUNNY, CLOUDY, STORM;
}
