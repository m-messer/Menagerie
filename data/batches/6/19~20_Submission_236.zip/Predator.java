/**
 * This class containts all the methods and fields neeeded by the predators
 *
 * @version 2019.02.23
 */
public abstract class Predator extends Animal {

    /**
     * Instantiates a new Predator.
     *
     * @param field               the field
     * @param location            the location
     * @param foodLevel           the food level
     * @param age                 the age
     * @param max_age             the max age
     * @param breeding_age        the breeding age
     * @param breeding_probabilty the breeding probabilty
     * @param food_step           the food step
     */
    public Predator(Field field, Location location, int foodLevel, int age, int max_age, int breeding_age, double breeding_probabilty, int food_step)
    {
        super(field,location, foodLevel,age,max_age,breeding_age,breeding_probabilty,food_step);

    }

    /**
     * Instantiates a new Predator.
     *
     * @param field                the field
     * @param location             the location
     * @param max_age              the max age
     * @param breeding_age         the breeding age
     * @param breeding_probability the breeding probability
     * @param food_step            the food step
     */
    public Predator(Field field, Location location,int max_age, int breeding_age, double breeding_probability, int food_step){
        super(field,location,max_age,breeding_age,breeding_probability, food_step);

    }

    /**
     * Checks if this animals eats the given food
     *
     * @param o the actor which you wanto to know if it is desirable
     * @return true if it is desireable, false otherwise
     */
    @Override
    protected boolean desirable(Object o) {
        return o instanceof Prey;
    }

}
