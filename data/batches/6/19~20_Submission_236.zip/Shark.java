import java.util.List;

/**
 * Write a description of interface Breedable here.
 *
 * @version 2019.02.23
 */
public class Shark extends Predator {
    // The age at which a octopus it can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a shark can live.
    private static final int MAX_AGE = 150;
    // If it acts during the day or during night.
    private static final boolean DAY = true;
    // The likelihood of a shark breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    //The quantity of steps that it can go without dying.
    private static final int FOOD_STEP = 25;


    /**
     * Create a shark. A shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param foodLevel the food level
     */
    public Shark(Field field, Location location, int foodLevel)
    {
        super(field, location, 10,0,MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, FOOD_STEP);

    }

    /**
     * Instantiates a new Shark.
     *
     * @param field    the field
     * @param location the location
     */
    public Shark(Field field, Location location){
        super(field, location, MAX_AGE ,BREEDING_AGE, BREEDING_PROBABILITY, FOOD_STEP);

    }

    /***
     * @see Animal
     *Includes the behaviour of the animal with the weather
     *
     * @param newSharks
     * @param isDay     if it is day
     * @param weather   the weather
     */
    @Override
    public void act(List<Actor> newSharks, boolean isDay, Weather weather) {

        if (isDay) {
            super.act(newSharks);

            if (weather == Weather.SUNNY) super.act(newSharks);

        }

        if ((weather == Weather.STORM) && (rand.nextDouble() < 0.1)) setDead();
    }

    /**
     * Create actor shark
     *
     * @param loc   the location it will be
     * @param field the field it will be
     * @return
     */
    @Override
    protected Actor create(Location loc, Field field) {
        return new Shark(field, loc, getFoodLevel());
    }

    /***
     * Get the food value
     *
     * @return
     */
    @Override
    public int getFoodValue() {
        return 30;
    }
}
