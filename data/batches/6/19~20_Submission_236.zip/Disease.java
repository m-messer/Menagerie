import java.util.Random;

/**
 * Class for disease. They are created by plants and their fields are generated
 * randomly making different kind of diseaases.
 *
 * @version 2019.02.23
 */
public class Disease {
    // How many steps lasts the disease
    private int howLong;
    // The mortality rate
    private double mortalityRate;
    // The infectious rate
    private double infectiousRate;

    private Random random = Randomizer.getRandom();


    /**
     * Constructor for objects of class Disease
     * All the fields selected randomly
     */
    public Disease() {
        howLong = random.nextInt(13) + 1; //Between 1 and 14 steps
        mortalityRate = 0.1 + (0.9 - 0.1) * random.nextDouble();  //rangeMin + (rangeMax - rangeMin) * random.nextDouble();
        infectiousRate = 0.1 + (1 - 0.1) * random.nextDouble();  //rangeMin + (rangeMax - rangeMin) * random.nextDouble();
    }

    /**
     * Gets how long it lasts.
     *
     * @return the how long
     */
    public int getHowLong() {
        return howLong;
    }

    /**
     * Gets mortality rate.
     *
     * @return the mortality rate
     */
    public double getMortalityRate() {
        return mortalityRate;
    }

    /**
     * Gets infectious rate.
     *
     * @return the infectious rate
     */
    public double getInfectiousRate() {
        return infectiousRate;
    }

}
