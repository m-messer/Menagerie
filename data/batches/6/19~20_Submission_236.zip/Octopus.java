import java.util.List;

/**
 * This is the class of the animal octopus
 *
 * @version 2019.02.23
 */
public class Octopus extends Predator {
    // The age at which a octopus it can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a octopus can live.
    private static final int MAX_AGE = 300;
    // If it acts during the day or during night.
    private static final boolean DAY = false;
    // The likelihood of a octopus breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    //The quantity of steps that it can go without dying.
    private static final int FOOD_STEP = 200;

    /**
     * Create a octopus. A octopus can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param foodLevel the food level
     */
    public Octopus(Field field, Location location, int foodLevel)
    {
        super(field, location, foodLevel,0,MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, FOOD_STEP);

    }

    /**
     * Instantiates a new Octopus.
     *
     * @param field    the field
     * @param location the location
     */
    public Octopus(Field field, Location location){
        super(field, location, MAX_AGE ,BREEDING_AGE, BREEDING_PROBABILITY, FOOD_STEP);

    }

    /**
     * Create actor octopus
     *
     * @param loc   the location it will be
     * @param field the field it will be
     * @return
     */
    @Override
    protected Actor create(Location loc, Field field) {
        return new Octopus(field, loc, getFoodLevel());
    }

    /**
     * @param newOctopuses
     * @param isDay        if it is day
     * @param weather      the weather
     * @see Animal
     * Includes the behaviour of the animal with the weather
     */
    @Override
    public void act(List<Actor> newOctopuses, boolean isDay, Weather weather) {
        if ((isDay == DAY) || (weather == Weather.CLOUDY)) {
            super.act(newOctopuses);
        }

        if (weather == Weather.STORM) {
            if (isDay != DAY) {
                if (rand.nextDouble() < 0.2) setDead();
            } else {
                super.act(newOctopuses);
                if (rand.nextDouble() < 0.05) setDead();
            }
        }
    }

    /**
     * Checks if this animals eats the given food
     *
     * @param o the animal which you wanto to know if it is desirable
     * @return true if it is desireable, false otherwise
     */
    @Override
    protected boolean desirable(Object o) {
        return (o instanceof Animal) && !(o instanceof Octopus);
    }

}
