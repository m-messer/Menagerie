import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;


/**
 * The type Statistics view.
 *
 * @version 2019.02.23
 */
public class StatisticsView extends JPanel {
    private XYSeriesCollection collection = new XYSeriesCollection();
    private HashMap<Class, XYSeries> series;

    private int n = 0;
    private XYPlot plot;

    /**
     * Instantiates a new Statistics view.
     */
    public StatisticsView() {
        try {
            series = new HashMap<>();

            //Create new chart
            JFreeChart chart = ChartFactory.createXYLineChart("Population", "Time step", "Population", collection, PlotOrientation.VERTICAL, true, true, false);
            plot = (XYPlot) chart.getPlot();
            plot.getDomainAxis().setStandardTickUnits(NumberAxis.createIntegerTickUnits());
            XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
            this.add(new ChartPanel(chart), BorderLayout.CENTER);

            this.setLayout(new java.awt.BorderLayout());
            this.setVisible(true);
            this.setSize(300, 300);

            ChartPanel CP = new ChartPanel(chart);
            CP.setPreferredSize(new Dimension(100, 200));
            CP.setMouseWheelEnabled(true);

            this.add(CP, BorderLayout.CENTER);
            this.validate();

        } catch (Exception e) {
            System.out.print("Chart exception:" + e);
        }
    }

    /**
     * AddS a new type with a certain color
     *
     * @param c     the class
     * @param color the color
     */
    public void add(Class c, Color color) {
        XYSeries s = new XYSeries(c.getName());
        collection.addSeries(s);
        series.put(c, s);

        //set color to latest item
        plot.getRenderer().setSeriesPaint(series.size() - 1, color);
    }

    /**
     * Update. Add new datapoints
     *
     * @param data the data
     */
    public void update(HashMap<Class, Counter> data) {
        n++;

        for (Class c : data.keySet()) {
            series.get(c).add(n, data.get(c).getCount());
        }
    }

}
