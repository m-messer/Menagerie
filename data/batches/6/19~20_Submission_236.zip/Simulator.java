import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;
import java.util.Map.Entry;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants.
 *
 * @version 2019.02.23 (3)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;

    // Create a of class, double tuples for the creating probability to make it more dynamic and extendable
    private static List<Entry<Class<? extends Actor>,Double>> probs =  new ArrayList<>(Map.of(
            Octopus.class,0.05,
            Shark.class,0.08,
            Tuna.class,0.1,
            Codd.class,0.05,
            Plankton.class,0.3,
            Coral.class,0.2
            ).entrySet());


    private boolean isDay;
    private Weather weather;

    //for the main thread to avoid concurrent modificaion errors
    private boolean run = false;
    private boolean dead = false;
    private boolean single = false;

    /**
     * The Actors.
     */
// List of animals in the field.
    public List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field. Pass this class to View as in MVC
        view = new SimulatorView(depth, width, this);
        view.setColor(Codd.class, Color.ORANGE);
        view.setColor(Shark.class, Color.GRAY);
        view.setColor(Plankton.class, Color.GREEN);
        view.setColor(Octopus.class, Color.PINK);
        view.setColor(Coral.class, Color.YELLOW);
        view.setColor(Tuna.class, Color.RED);

        view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Setup a valid starting point.
        reset();
    }


    /**
     * Set single.
     */
    public void setSingle() {
        single = true;
    }

    /**
     * Set run.
     */
    public void setRun() {
        run = true;
    }

    /**
     * Set stop.
     */
    public void setStop() {
        run = false;
    }

    /**
     * Get run boolean.
     *
     * @return the boolean
     */
    public boolean getRun() {
        return run;
    }

    /**
     * Run endless loop until the view is closed.
     * Run step if the UI is used and the state is set
     * Stop the simulation of it is no longer viable
     */
    public void runLongSimulation() {
        while (!view.isClosed()) {
            if (run || single) {
                step++;
                simulateOneStep();
                single = false;
            }

            try{
                Thread.sleep(10);
            }catch (Exception e){


            }

            if (!view.isViable(field)) run = false;
        }

    }


    /**
     * Main. To run from console and intelliJ
     *
     * @param args the args
     */
    public static void main(String[] args) {
        new Simulator().runLongSimulation();
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(120);   // uncomment this to run more slowly
        }
    }

    /**
     * Change weather.
     */
    void changeWeather() {
        Random rand = Randomizer.getRandom();

        if (rand.nextDouble() < 0.2) weather = Weather.CLOUDY;
        else if (rand.nextDouble() < 0.3) weather = Weather.STORM;
        else weather = Weather.SUNNY;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep() {
        step++;
        changeWeather();
        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>();
        //view.SETB
        // Let all rabbits act.
        for (Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.action(newActors, isDay, weather);
            if (!actor.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born foxes and rabbits to the main lists.
        actors.addAll(newActors);

        //Houses.fillHouses(field, actors);

        view.showStatus(step, field, isDay);

        isDay = !isDay;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        actors.clear();
        populate();
        //Houses.fillHouses(field, actors);

        run = false;
        isDay = true;

        // Show the starting state in the view.
        view.showStatus(step, field, isDay);
    }

    private Actor randomActor(Location location) {
        Random rand = Randomizer.getRandom();
        Actor o = null;

        //Shuffle the array so the creation probabilties are actually useful and not dependent on the order of the original if/else statements
        Collections.shuffle(probs);

        for (Entry<Class<? extends Actor>, Double> entry : probs) {
            if (rand.nextDouble() <= entry.getValue()) {
                try {
                    //Create instances of class
                    o = entry.getKey().getConstructor(Field.class, Location.class).newInstance(field, location);
                } catch (Exception e) {
                    System.out.println("Constructor not available for " + entry.getKey().getSimpleName());
                }
                break;
            }
        }

        return o;
    }

    /**
     * Randomly populate the field with actors.
     */
    private void populate() {
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);

                Actor o = randomActor(location);

                if (o != null) actors.add(o);
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
