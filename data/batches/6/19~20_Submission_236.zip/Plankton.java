import java.util.Random;

/**
 * Write a description of interface Breedable here.
 *
 * @version 2019.02.23
 */
public class Plankton extends Plant {
    // Characteristics shared by all planktons (class variables).

    // The age at which a plankton can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a plankton can live.
    private static final int MAX_AGE = 40;
    // If it acts during the day
    private static final boolean DAY = true;
    // The likelihood of a plankton breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    /**
     * Create a new plankton. A plankton may be created with age
     * zero (a new born) or with a random age.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param foodLevel the food level
     */
    public Plankton(Field field, Location location, int foodLevel) {
        super(field, location, foodLevel, 0, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
    }

    /**
     * Instantiates a new Plankton.
     *
     * @param field    the field
     * @param location the location
     */
    public Plankton(Field field, Location location) {
        super(field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
    }

    /**
     * Create actor plankton
     *
     * @param loc   the location it will be
     * @param field the field it will be
     * @return
     */
    @Override
    protected Actor create(Location loc, Field field) {
        return new Plankton(field, loc);
    }

    /***
     * Get the food value
     *
     * @return
     */
    @Override
    public int getFoodValue() {
        return 5;
    }
}