import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2019.02.23 (2)
 */
public class SimulatorView extends JFrame implements WindowListener {
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private JLabel stepLabel, population, infoLabel;
    private FieldView fieldView;

    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;
    private StatisticsView statistics;

    private JSlider slider;

    //Store historic states
    private ArrayList<Color[][]> history;
    private int width, height;

    private boolean closed = false;

    /**
     * Create a view of the given width and height.
     *
     * @param height    The simulation's height.
     * @param width     The simulation's width.
     * @param simulator the simulator
     */
    public SimulatorView(int height, int width, Simulator simulator) {

        this.width = width / 2;
        this.height = height / 2;

        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Sea Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        statistics = new StatisticsView();

        history = new ArrayList<>();

        setLocation(100, 50);

        fieldView = new FieldView(height, width);

        //Tabbed view and UI boxes
        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel panel = new JPanel(new BorderLayout());
        Box buttons = Box.createVerticalBox();
        Box bottom = Box.createVerticalBox();
        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new BorderLayout());
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(infoLabel, BorderLayout.CENTER);

        //UI control buttons and callbacks
        JButton onestep = new JButton("One step");
        onestep.addActionListener((ActionListener) -> {
            simulator.setSingle();
        });
        JButton reset = new JButton("Reset");
        reset.addActionListener((ActionListener) -> {
            simulator.setStop();
            simulator.reset();
        });
        JButton run = new JButton("Run");
        run.addActionListener((ActionListener) -> {
            reset.setEnabled(false);
            simulator.setRun();
        });
        JButton stop = new JButton("Stop");
        stop.addActionListener((ActionListener) -> {
            simulator.setStop();
            reset.setEnabled(true);
        });

        //History slider
        slider = new JSlider(JSlider.HORIZONTAL, 0, 1, 0);

        slider.setPaintLabels(true);
        slider.addChangeListener((ChangeListener) -> {
            //if not interfering with running simulation
            if (!simulator.getRun()) {
                //update label
                stepLabel.setText(STEP_PREFIX + slider.getValue());

                //get historic state
                Color[][] cs = history.get(Math.min(slider.getValue(), history.size() - 1));

                //repaint with historic data
                fieldView.preparePaint();
                for (int i = 0; i < cs.length; ++i)
                    for (int j = 0; j < cs[i].length; ++j)
                        fieldView.drawMark(j, i, cs[i][j]);

                fieldView.repaint();
            }
        });

        buttons.add(onestep);
        buttons.add(run);
        buttons.add(stop);
        buttons.add(reset);

        bottom.add(population);
        bottom.add(slider);

        panel.add(infoPane, BorderLayout.NORTH);
        panel.add(fieldView, BorderLayout.CENTER);
        panel.add(bottom, BorderLayout.SOUTH);
        panel.add(buttons, BorderLayout.EAST);

        tabbedPane.add(panel, "View");
        tabbedPane.add(statistics, "Statistics");

        contents.add(tabbedPane);
        //contents.add(statistics, BorderLayout.EAST);
        pack();
        setVisible(true);

        this.addWindowListener(this);
    }

    /**
     * Define a color to be used for a given class of animal.
     *
     * @param animalClass The animal's Class object.
     * @param color       The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color) {
        colors.put(animalClass, color);
        //add color and animal to statistics
        statistics.add(animalClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     *
     * @param text the text
     */
    public void setInfoText(String text) {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass) {
        Color col = colors.get(animalClass);
        if (col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        } else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     *
     * @param step  Which iteration step it is.
     * @param field The field whose status is to be displayed.
     * @param isDay the is day
     */
    public void showStatus(int step, Field field, boolean isDay) {
        if (!isVisible()) {
            setVisible(true);
        }

        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();

        fieldView.preparePaint();

        Color[][] cs = new Color[field.getDepth()][];

        for (int row = 0; row < field.getDepth(); row++) {
            cs[row] = new Color[field.getWidth()];
            for (int col = 0; col < field.getWidth(); col++) {
                Object being = field.getObjectAt(row, col);

                Color c;
                if (being != null) {
                    Actor actor = (Actor) being;
                    stats.incrementCount(actor.getClass());
                    c = !actor.hasDisease() ? getColor(being.getClass()) : getColor(being.getClass()).darker();
                } else {
                    c = EMPTY_COLOR;
                }

                fieldView.drawMark(col, row, c);
                cs[row][col] = c;
            }
        }
        stats.countFinished();
        statistics.update(stats.getCounters());

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));

        //add state to history
        history.add(cs);

        //update slider position
        int max = slider.getMaximum();

        slider.setMaximum(max + 1);
        slider.setValue(max + 1);

        fieldView.repaint();
    }

    /**
     * Convert to type buffered image.
     *
     * @param sourceImage the source image
     * @param targetType  the target type
     * @return the buffered image
     */
    public BufferedImage convertToType(BufferedImage sourceImage, int targetType) {
        BufferedImage image;

        if (sourceImage.getType() == targetType) {
            image = sourceImage;
        } else {
            image = new BufferedImage(sourceImage.getWidth(), sourceImage.getHeight(), targetType);
            image.getGraphics().drawImage(sourceImage, 0, 0, this.width, this.height, null);
        }
        return image;
    }


    /**
     * Determine whether the simulation should continue to run.
     *
     * @param field the field
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field) {
        return stats.isViable(field);
    }

    @Override
    public void windowOpened(WindowEvent windowEvent) {

    }

    @Override
    public void windowClosing(WindowEvent windowEvent) {
        closed = true;
    }

    @Override
    public void windowClosed(WindowEvent windowEvent) {
    }

    @Override
    public void windowIconified(WindowEvent windowEvent) {

    }

    @Override
    public void windowDeiconified(WindowEvent windowEvent) {

    }

    @Override
    public void windowActivated(WindowEvent windowEvent) {

    }

    @Override
    public void windowDeactivated(WindowEvent windowEvent) {

    }

    /**
     * Provide a graphical view of a rectangular field. This is
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this
     * for your project if you like.
     */
    private class FieldView extends JPanel {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        /**
         * The Size.
         */
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         *
         * @param height the height
         * @param width  the width
         */
        public FieldView(int height, int width) {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize() {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR, gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint() {
            if (!size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if (xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if (yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         *
         * @param x     the x
         * @param y     the y
         * @param color the color
         */
        public void drawMark(int x, int y, Color color) {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g) {
            if (fieldImage != null) {
                Dimension currentSize = getSize();
                if (size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                } else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }

    }


    /**
     * Is closed boolean.
     *
     * @return the boolean
     */
    public boolean isClosed() {
        return closed;
    }

}
