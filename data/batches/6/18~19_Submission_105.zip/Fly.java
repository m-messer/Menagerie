import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Fly.
 * Flys age, move, breed, and die.
 *
 * @version 2019.02.20
 */
public class Fly extends Animal
{

    // number of steps a Fly can go before it has to eat again.
    private static final int CATTAIL_FOOD_VALUE = 15;
    private static final int GRASS_FOOD_VALUE = 20;

    /**
     * Create a new Fly. A Fly may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Fly will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomSickness If true, the fly will randomly get a disease.
     * @param isSick If true, the fly is sick.
     */
    public Fly(boolean randomAge, Field field, Location location, boolean randomSickness, boolean isSick)
    {
        super(randomAge, field, location, 2, 10, 0.08, 6, 15, randomSickness, isSick);
    }

    /**
     * This is what the Fly does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newFlys A list to return newly born Flys.
     * @param isDay A boolean indicating whether it is day or night.
     * @param weather A string for a the weather.
     */
    public void act(List<Actor> newFlys, boolean isDay, String weather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newFlys);
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }

    }

    /**
     * Check whether or not this Fly is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFlys A list to return newly born Flys.
     */
    protected void giveBirth(List<Actor> newFlys)
    {
        // New Flys are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fly) {
                Fly fly = (Fly) animal;
                if(fly.isMale() != this.isMale()) {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++)
                    {
                        boolean gotSTD = fly.getSick() || getSick();
                        Location loc = free.remove(0);
                        Fly young = new Fly(false, field, loc, false, gotSTD);
                        newFlys.add(young);
                    }
                }
            }

        }
    }

    /**
     * Look for Grass or Cattail adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cattail) {
                Cattail cattail = (Cattail) animal;
                if(cattail.isEdible()) {
                    cattail.setDead();
                    foodLevel = CATTAIL_FOOD_VALUE;
                    return where;
                }
            }

            if(animal instanceof Grass) {
                Grass grass = (Grass) animal;
                if(grass.isEdible()) {
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }

        }
        return null;
    }

}
