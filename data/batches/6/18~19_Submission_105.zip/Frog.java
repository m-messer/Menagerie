import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Frog.
 * Frogs age, move, eat  and die.
 *
 * @version 2019.02.20
 */
public class Frog extends Animal
{
    // Characteristics shared by all Frogs (class variables).

    // number of steps a Frog can go before it has to eat again.
    private static final int CRICKET_FOOD_VALUE = 15;
    private static final int FLY_FOOD_VALUE = 15;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Frog. A Frog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Frog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomSickness If true, the frog will randomly get a disease.
     * @param isSick If true, the frog is sick.
     */
    public Frog(boolean randomAge, Field field, Location location, boolean randomSickness, boolean isSick)
    {
        super(randomAge, field, location, 5, 75, 0.12, 4, CRICKET_FOOD_VALUE, randomSickness, isSick);

    }

    /**
     * This is what the Frog does most of the time: it hunts for
     * Crickets and Flies. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newFrogs A list to return newly born Frogs.
     * @param isDay A boolean indicating whether it is day or night.
     * @param weather A string for a the weather.
     */
    public void act(List<Actor> newFrogs, boolean isDay, String weather)
    {
        incrementAge();
        incrementHunger();

        if((isAlive() && (weather.equals("Rainy") || weather.equals("Clear")))) { // if it is rainy or sunny, the Frogs will reproduce.
            giveBirth(newFrogs);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for Crickets or Flys adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cricket) {
                Cricket cricket = (Cricket) animal;
                if(cricket.isAlive()) {
                    cricket.setDead();
                    foodLevel = CRICKET_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Fly) {
                Fly fly = (Fly) animal;
                if(fly.isAlive()) {
                    fly.setDead();
                    foodLevel = FLY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Frog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFrogs A list to return newly born Frogs.
     */
    protected void giveBirth(List<Actor> newFrogs)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isMale() != this.isMale()) {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++)
                    {
                        boolean gotSTD = frog.getSick() || getSick();
                        Location loc = free.remove(0);
                        Frog young = new Frog(false, field, loc, false, gotSTD);
                        newFrogs.add(young);
                    }
                }
            }

        }
    }

}
