import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a Grass.
 * Grass grows, breeds, and dies.
 *
 * @version 2019.02.20
 */
public class Grass extends Plant
{

    /**
     * Constructor for objects of class Grass
     */
    public Grass(Field field,Location location)
    {
        super(field, location);
        this.setVal(0.06,2);
    }

    /**
     * Make the Grass  act.
     * @param newAnimals A list to receive newly born animals.
     * @param isDay A boolean indicating whether it is day or night.
     * @param weather A string for a the weather.
     */
    public void act(List<Actor> newGrass, boolean isDay, String weather)
    {

        if (weather.equals("Clear")) { //if the weather is clear the grass will grow
            grow();
        }

        if(isAlive() && isEdible() && !isDay){ //if the grass is alive, is edible and it is day, they will asexually reproduce
            giveBirth(newGrass);
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }

    }

    /**
     * Check whether or not this Grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrass A list to return newly born Grass.
     */
    protected void giveBirth(List<Actor> newGrass)
    {
        // New Grass are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(field, loc);
            newGrass.add(young);
        }
    }
}
