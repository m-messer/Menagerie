import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing a series of different actors and plants.
 *
 * @version 2019.02.20
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Shrew will be created in any given grid position.
    private static final double SHREW_CREATION_PROBABILITY = 0.05;
    // The probability that a Frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.05;
    // The probability that a Grasshopper will be created in any given grid position.
    private static final double GRASSHOPPER_CREATION_PROBABILITY = 0.08;
    // The probability that a Cricket will be created in any given grid position.
    private static final double CRICKET_CREATION_PROBABILITY = 0.08;
    // The probability that a Plant spawns
    private static final double GRASS_CREATION_PROBABILITY = 0.06;
    private static final double CATTAIL_CREATION_PROBABILITY = 0.06;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    // Whether is is day or night.
    private boolean isDay = true;
    // The weather in the field.
    private Weather weather;
    private String currentWeather;

    /**
     * Construct a simulation field with default size and weather.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        weather = new Weather();
        weather.changeWeather();
        currentWeather = weather.getWeather();
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Shrew.class, Color.RED);
        view.setColor(Frog.class, Color.GREEN);
        view.setColor(Grasshopper.class, Color.YELLOW);
        view.setColor(Cricket.class, Color.BLACK);
        view.setColor(Cattail.class, Color.GRAY);
        view.setColor(Grass.class, Color.CYAN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     * The day and weather change after a certain number of steps.
     */
    public void simulateOneStep()
    {
        step++;

        if (step % 50 == 0 ){
            isDay = !isDay; // Every 75 steps, the time of day changes.
        }

        if (step % 20 == 0) {
            weather.changeWeather(); // Every 50 steps, the weather is randomly changed.
        }

        currentWeather = weather.getWeather();
        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors, isDay, currentWeather);
            if(! actor.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born actors to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field, currentWeather, getTime());

    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, currentWeather, getTime());
    }

    /**
     * Randomly populate the field with all the actors and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {

                if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location, true, false);
                    actors.add(frog);
                }
                else if(rand.nextDouble() <= SHREW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shrew shrew = new Shrew(true, field, location, true, false);
                    actors.add(shrew);
                }
                else if(rand.nextDouble() <= GRASSHOPPER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grasshopper grasshopper = new Grasshopper(true, field, location, true, false);
                    actors.add(grasshopper);
                }
                else if(rand.nextDouble() <= CRICKET_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cricket cricket = new Cricket(true, field, location, true, false);
                    actors.add(cricket);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Grass grass = new Grass(field, location);
                    actors.add(grass);
                }
                else if(rand.nextDouble() <= CATTAIL_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Cattail cattail = new Cattail(field, location);
                    actors.add(cattail);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Returns a string for the day/night.
     */
    public String getTime() {
        if (isDay == true) {
            return "Day";
        } else {
            return "Night";
        }
    }
}
