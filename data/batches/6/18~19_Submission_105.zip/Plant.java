import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A class representing the shared characteristics of all plants.
 *
 * @version 2019.02.20
 */
public abstract class Plant extends Actor
{
    //Add plants. Plants grow at a given rate, but they do not move. Some creatures eat plants.
    //They will die if they do not find their food plant.
    private double GROWTH_PROBABILITY;     
    private int currentGrowthState;
    private int MAX_GROWTH = 3;

    public static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
        currentGrowthState = rand.nextInt(MAX_GROWTH);
    }

    /**
     * Sets the values for growth and max growth.
     */
    public void setVal(double rate, int max)
    {
        GROWTH_PROBABILITY = rate;
        MAX_GROWTH = max;
    }

    public double getGrowthRate(){
        return GROWTH_PROBABILITY;
    }

    /**
     * Checks if plant is fully grown
     * if is it is set back to growth state of 0 and 'is eaten'
     */
    public boolean isEdible()
    {
        return currentGrowthState == MAX_GROWTH;
    }

    /**
     * The plant will grow if it has not reached its maximum size.
     */
    public void grow()
    {
        if (currentGrowthState < MAX_GROWTH){
            currentGrowthState++;
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= GROWTH_PROBABILITY) {
            births = rand.nextInt(MAX_GROWTH) + 1;
        }
        return births;
    }

}
