import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Shrew.
 * Shrews age, move, eat  and die.
 *
 * @version 2019.02.20
 */
public class Shrew extends Animal
{
    // Characteristics shared by all Shrews (class variables).

    // number of steps a Shrew can go before it has to eat again.
    private static final int CRICKET_FOOD_VALUE = 20;
    private static final int GRASSHOPPER_FOOD_VALUE = 10;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Shrew. A Shrew can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Shrew will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomSickness If true, the shew will randomly get a disease.
     * @param isSick If true, the shrew is sick.
     */
    public Shrew(boolean randomAge, Field field, Location location, boolean randomSickness, boolean isSick)
    {
        super(randomAge, field, location, 5, 120, 0.12, 6, GRASSHOPPER_FOOD_VALUE, randomSickness, isSick);
    }

    /**
     * This is what the Shrew does most of the time: it hunts for
     * Snakes and Shrew. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newShrews A list to return newly born Shrews.
     * @param isDay A boolean indicating whether it is day or night.
     * @param weather A string for a the weather.
     */
    public void act(List<Actor> newShrews, boolean isDay, String weather)
    {
        incrementAge();
        incrementHunger();

        if(isAlive() && (weather.equals("Rainy") || weather.equals("Snowy"))) {
            giveBirth(newShrews);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for Cricket and Grasshopper adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cricket) {
                Cricket cricket = (Cricket) animal;
                if(cricket.isAlive()) {
                    cricket.setDead();
                    foodLevel = CRICKET_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Grasshopper) {
                Grasshopper grasshopper = (Grasshopper) animal;
                if(grasshopper.isAlive()) {
                    grasshopper.setDead();
                    foodLevel = GRASSHOPPER_FOOD_VALUE;
                    return where;
                }
            }

        }
        return null;
    }

    /**
     * Check whether or not this Shrew is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newShrews A list to return newly born Shrews.
     */
    protected void giveBirth(List<Actor> newShrews)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shrew) {
                Shrew shrew = (Shrew) animal;
                if(shrew.isMale() != this.isMale()) {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++)
                    {
                        boolean gotSTD = shrew.getSick() || getSick();
                        Location loc = free.remove(0);
                        Shrew young = new Shrew(false, field, loc, false, gotSTD);
                        newShrews.add(young);
                    }
                }
            }

        }
    }

}
