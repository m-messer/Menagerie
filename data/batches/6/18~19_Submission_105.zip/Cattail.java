import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a Cattail.
 * Cattails grow, breed, and die.
 *
 * @version 2019.02.20
 */
public class Cattail extends Plant
{

    /**
     * Constructor for objects of class Cattail
     */
    public Cattail(Field field,Location location)
    {
        super(field, location);
        this.setVal(0.05,3);
    }

    /**
     * Make the Cattail act.
     * @param newAnimals A list to receive newly born animals.
     * @param isDay A boolean indicating whether it is day or night.
     * @param weather A string for a the weather.
     */
    public void act(List<Actor> newCattail, boolean isDay, String weather)
    {

        if (weather.equals("Rainy")) { //if it is rainy, then the plant will grow.
            grow();
        }

        if(isAlive() && isEdible() && !isDay ) { //if the plant is alive, edible and it is day, then they will asexually reproduce.
            giveBirth(newCattail);
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }

    }

    /**
     * Check whether or not this Cattailhopper is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCattail A list to return newly born Cattailhoppers.
     */
    protected void giveBirth(List<Actor> newCattail)
    {
        // New Cattailhoppers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cattail young = new Cattail(field, loc);
            newCattail.add(young);
        }
    }
}
