import java.util.ArrayList;
import java.util.Random;

/**
 * A class for the weather in the simulation.
 *
 * @version 2019.02.20
 */
public class Weather
{

    private ArrayList<String>weather;
    private String currentWeather;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        weather = new ArrayList<>();
        addWeather();
    }

    /**
     * Adds weather conditions ot the arraylist storing the weather
     */
    public void addWeather(){

        weather.add("Clear");
        weather.add("Rainy");
        weather.add("Snowy");

    }

    /**
     * Randomly selects a weather condition.
     */
    public void changeWeather(){
        Random RandomWeather = new Random();
        int index = RandomWeather.nextInt(weather.size());
        currentWeather = weather.get(index);
    }

    /**
     * Return the weather.
     */
    public String getWeather(){
        return currentWeather;
    }
}
