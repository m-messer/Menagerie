import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Cricket.
 * Crickets age, move, breed, and die.
 *
 * @version 2019.02.20
 */
public class Cricket extends Animal
{

    // number of steps a Cricket can go before it has to eat again.
    private static final int CATTAIL_FOOD_VALUE = 20;
    private static final int GRASS_FOOD_VALUE = 15;
    
    /**
     * Create a new Cricket. A Cricket may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Cricket will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomSickness If true, the cricket will randomly get a disease.
     * @param isSick If true, the cricket is sick.
     */
    public Cricket(boolean randomAge, Field field, Location location, boolean randomSickness, boolean isSick)
    {
        super(randomAge, field, location, 5, 40, 0.10, 5, 15, randomSickness, isSick);
    }

    /**
     * This is what the Cricket does most of the time - it may breed or simply die.
     * @param newCrickets A list to return newly born Crickets.
     */
    public void act(List<Actor> newCrickets, boolean isDay, String weather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && isDay) {
            giveBirth(newCrickets);
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this Cricket is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCrickets A list to return newly born Grasshoppers.
     */
    protected void giveBirth(List<Actor> newCrickets)
    {
        // New Crickets are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cricket) {
                Cricket cricket = (Cricket) animal;
                if(cricket.isMale() != this.isMale()) {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++)
                    {
                        boolean gotSTD = cricket.getSick() || getSick();
                        Location loc = free.remove(0);
                        Cricket young = new Cricket(false, field, loc, false, gotSTD);
                        newCrickets.add(young);
                    }
                }
            }

        }
    }

    /**
     * Look for Crickets or Flys adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cattail) {
                Cattail cattail = (Cattail) animal;
                if(cattail.isEdible()) {
                    cattail.setDead();
                    foodLevel = CATTAIL_FOOD_VALUE;
                    return where;
                }
            }

            if(animal instanceof Grass) {
                Grass grass = (Grass) animal;
                if(grass.isEdible()) {
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }

        }
        return null;
    }
}
