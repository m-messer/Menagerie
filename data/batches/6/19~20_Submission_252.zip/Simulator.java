/**
 * A simple safari nature simulator, based on a rectangular field.
 * Containing animals (giraffe, goat, elephant, lion, leopard) and human (hunter).
 *
 * @version 22.02.2019
 */
public class Simulator
{
    // Class variables.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // Instance variables.
    // The generator to generate population and simulate actors' beheviours. 
    private PopulationGenerator generator;
    // The current step of the simulation.
    private int step;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        generator = new PopulationGenerator(depth,width);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && generator.getView().get(0).isViable(generator.getField()); step++) 
        {
            simulateOneStep();
            delay(600); // Run more slowly.
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        generator.actAll(step);  // Let all actors act
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        for (SimulatorView view : generator.getView()) 
        {
            view.reset();
        }
        generator.clearList();  // Clear list of all actors.
        generator.populate(step);  // Add actors into fields.
        // Show the starting state in the view. 
    }

    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }
}
