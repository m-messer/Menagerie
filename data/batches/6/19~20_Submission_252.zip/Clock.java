import java.util.Timer; 
import java.util.TimerTask; 

/**
 * Clock class is responsible for managing and tracking the time of simulation.
 * Alternate day and night according to every given time period.
 *
 * @version 22.02.2019
 */
public class Clock
{
    // The value of day, true of it is day and false otherwise.
    private boolean day;

    /**
     * Initialize the timer. 
     * Start the timer and change it after each given time period.
     * when initialized is morning. 
     */
    public Clock()
    {
        Timer timer = new Timer(); 
        TimerTask task = new Day(); 
        // Switch day and night every 2000ms seconds with no delay. 
        timer.schedule(task, 0, 2000); 
        day = true; 
    }

    /**
     * Class day created in order to support timer to automatically switch day and night.
     * Run is executed in every given time period.
     */
    class Day extends TimerTask 
    {
        int i = 0;
        /**
         * Alternate day and night.
         * isDay and isNight rotate. 
         */
        public void run() 
        {
            if(i == 1)
            {
                i = 0;
                isNight();
                //System.out.println("was set to night");
            }
            else if(i == 0)
            {  
                i = 1;
                isDay();
                //System.out.println("was set to day");
            }
        }
    }
    
    /**
     * Set the day to true.
     */
    private void isDay()
    {
        day = true;
    }

    /**
     * Set the day to false.
     */
    public void isNight()
    {
        day = false;
    }

    /**
     * Return the value of day.
     * @return day True if it is day,night otherwise.
     */
    public boolean getDay()
    {
        return day;
    }
}
