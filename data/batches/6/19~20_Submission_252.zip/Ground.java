import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class Ground stores plants and allow actors and plants to co-exist in one location.
 * At each location there can be only one plant. 
 * Plant will not be cleared, if animal is cleared out of same location.
 *
 * @version 22.02.2019
 */
 public class Ground
 {
    // HashMap stores a location and a plant on that location.
    private HashMap<Location, Plant> ground ;
    
     /**
     * Innitializes Ground class by creating new hashMap ground
     */
    public Ground()
    {
        ground = new HashMap<>();
    }
    
    /**
     * Set the ground with given location and plant.
     * @param location The location allows plants to grow.
     * @param plant The plant which is going to be put in a certain location.
     */
    public void setGround(Location location, Plant plant)
    {
        ground.put(location, plant); 
    }
    
    /**
     * Return plant of a given location. 
     * @param location The location in which we are searching for plant.
     * @return plant Return plant if a plant is found at that location.
     *               Return null otherwise.
     */
    public Plant getPlant(Location location)
    {
        if(ground.containsKey(location))
        {
            return ground.get(location);
        }
        return null;
    }
    
    /**
     * Clear location of plants.
     * @param location which is to be cleared.
     */
    public void clearLocation(Location location)
    {
        ground.put(location,null);
    }
    
    /**
     * Clear the whole ground.
     */
    public void clearGround()
    {
        ground.clear();
    }
}
