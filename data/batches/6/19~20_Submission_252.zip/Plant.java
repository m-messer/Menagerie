import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of plants.
 * It might has different kinds of plant in the future.
 *
 * @version 2020.02.22
 */
public abstract class Plant implements Drawable
{
    // Class variable.
    public static final boolean isDrawable =  false;

    // Instance fields.
    // The plants's ground.
    private Ground ground;
    // The plants's field.
    private Field field;

    /**
     * Create a new plant at ground in field.
     * 
     * @param field The field currently occupied.
     * @param ground The ground within the field.
     */
    public Plant(Field field, Ground ground)
    {
        this.field = field;
        this.ground = ground;
    }

    /**
     * Return ground which plants are on.
     * @return ground The plant's ground.
     */
    protected Ground getGround()
    {
        return ground;
    }

    /**
     * Return the plant's field.
     * @return field The plant's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Let all plants grow.
     * Number of plants depends on the given percetage.
     * @param plant Plants to grow.
     * @param percetage Percentage of field that will be covered with plants.
     */
    public void grow(Plant plant, double percentage)
    {
        List <Location> list = field.getPercantageOfField(percentage);
        Iterator<Location> it = list.iterator();
        while(it.hasNext())
        {
            Location location = it.next();
            ground.setGround(location, plant);
        }
    }
}
