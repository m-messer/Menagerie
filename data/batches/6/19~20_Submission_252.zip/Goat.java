/**
 * A simple model of goat.
 * goats age, move, eat grass and die.
 *
 * @version 2020.02.10 
 */
public class Goat extends Animal
{
    // Characteristics shared by all goats (class variables).
    // The age at which a goat can start to breed.
    private static final int BREEDING_AGE = 31;
    // The age to which a goat can live.
    private static final int MAX_AGE = 3000;
    // The likelihood of a goat breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20;
    // The maximum number of foodlevel.
    private static final int MAX_FOOD_LEVEL = 20;
    // The probability to be male.
    private static final double MALE_PROBABILITY = 0.6;
    // The probability to find food.
    private static final double FINDFOOD_PROBABILITY =0.9;
    // The probability to get virus.
    private static double VIRUS_OUTBREAK_PROBABILITY = 0.02;
    // Goats are not nocturnal Animal.
    private static final boolean isNocturnalAnimal = false;

    /**
     * Create a goat. A goat can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the goat will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ground The ground stores plants.
     */
    public Goat(boolean randomAge, Field field, Location location, Ground ground)
    {
        super(field, location,ground);
        if(randomAge) 
        {
            setAge(getRandomNumber(MAX_AGE));
            setFoodValue(getRandomNumber(MAX_FOOD_LEVEL));
        }
        else 
        { 
            setFoodValue(MAX_FOOD_LEVEL);
        }
    }

    /**
     * Return goat's breeding age.
     * @return BREEDING_AGE Goat's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return goat's maximum foodlevel.
     * @return MAX_FOOD_LEVEL Goat's maximum foodlevel.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return goat's maximum age.
     * @return MAX_AGE Goat's maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return goat's breeding probability.
     * @return BREEDING_PROBABILITY Goat's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return maximum litter number.
     * @return MAX_LITTER_SIZE Goat's maximum litter number.
     */
    public int getMaxLitter()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the probability to be male.
     * @return MALE_PROBABILITY The probability to be male.
     */
    public double getMaleProbability()
    {
        return MALE_PROBABILITY;
    }

    /**
     * Return the probability to find food.
     * @return FINDFOOD_PROBABILITY The probability to find food.
     */
    public double getFindFoodProbability()
    {
        return FINDFOOD_PROBABILITY;
    }

    /**
     * Return the probability to get virus.
     * @return VIRUS_OUTBREAK_PROBABILITY The probability to get virus.
     */
    public double getVirusOutbreakProbability()
    {
        return VIRUS_OUTBREAK_PROBABILITY;
    }

    /**
     * Return whether it is nocturnal animal.
     * @return isNocturnalAnimal True if it is.
     */
    public boolean isNocturnalAnimal()
    {
        return isNocturnalAnimal;
    }
}
