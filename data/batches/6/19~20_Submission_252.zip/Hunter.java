import java.util.List;
import java.util.ArrayList;

/**
 * A simple model of a hunter.
 * Hunter can give birth to their offsprings and hunt prey.
 * Hunter usually will not move from home(birth place) even they find food.
 * If hunter and his enemy are in the neigbhouring cell, hunter will try
 * to move into a new place.
 *
 * @version 2020.02.22
 */
public class Hunter extends Human
{
    // Characteristics shared by all hunters (class variables).
    // The age at which a hunter can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a hunter can live.
    private static final int MAX_AGE = 3900;
    // The likelihood of a elephant breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The maximum number of foodlevel.
    private static final int MAX_FOOD_LEVEL = 40;
    // The probability to be a male.
    private static final double MALE_PROBABILITY = 0.55;
    // The probability to find food.
    private static final double FINDFOOD_PROBABILITY = 0.9;
    // The probability to get virus.
    private static double VIRUS_OUTBREAK_PROBABILITY = 0.01;

    // Individual characteristics (instance fields).
    // The list to store class of hunter's enemy. 
    private List<Class<?>> enemies;

    /**
     * Create a hunter. A hunter can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hunter will have random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ground The ground stores plants.
     */
    public Hunter(boolean randomAge,Field field, Location location,Ground ground)
    {
        super(field, location,ground);
        if(randomAge) {
            setAge(getRandomNumber(MAX_AGE));
            setFoodValue(getRandomNumber(MAX_FOOD_LEVEL));
        }
        else { 
            setFoodValue(MAX_FOOD_LEVEL);
        }
        enemies = new ArrayList<>();
        addEnemy();
    }

    /**
     * Fill the map with human's enemy class.
     */
    protected void addEnemy()
    {
        enemies.add(Lion.class);
        enemies.add(Leopard.class);
    }

    /**
     * Return hunter's breeding age.
     * @return BREEDING_AGE Hunter's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return hunter's maximum foodlevel.
     * @return MAX_FOOD_LEVEL Hunter's maximum foodlevel.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return hunter's maximum age.
     * @return MAX_AGE Hunter's maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return hunter's breeding probability.
     * @return BREEDING_PROBABILITY Hunter's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return maximum litter number.
     * @return MAX_LITTER_SIZE Hunter's maximum litter number.
     */
    public int getMaxLitter()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the probability to be male.
     * @return MALE_PROBABILITY The probability to be male.
     */
    public double getMaleProbability()
    {
        return MALE_PROBABILITY;
    }

    /**
     * Return the probability to find food.
     * @return FINDFOOD_PROBABILITY The probability to find food.
     */
    public double getFindFoodProbability()
    {
        return FINDFOOD_PROBABILITY;
    }

    /**
     * Return the probability to get virus.
     * @return VIRUS_OUTBREAK_PROBABILITY The probability to get virus.
     */
    public double getVirusOutbreakProbability()
    {
        return VIRUS_OUTBREAK_PROBABILITY;
    }

    /**
     * Let hunter acts during the day.
     * Hunter can give birth to their offspring and hunt prey.
     * Hunter usually will not move out from home(birth place) even they find food.
     * If hunter and his enemy are in the neigbhouring cell, hunter will try
     * to move into a new place.
     * @param newHunters A list to receive newly born hunters.
     */
    public void actDay(List<Actor> newHunters)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) 
        {
            giveBirth(newHunters); 
            Location newHome = findFood(); // Potential new home.
            List<Location> adjacents = getField().adjacentLocations(getLocation());
            for(Location adjacent: adjacents)
            {
                Actor neighbour = getField().getObjectAt(adjacent);
                if(enemies.contains(neighbour))
                {
                    if(newHome != null)
                    {
                        // move into a new place.
                        setLocation(newHome);
                    }
                    else
                    {
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Let hunter sleeps at night.
     */
    public void actNight(List<Actor> newActors)
    {
        sleep();
    }
}
