import java.util.List;
import java.util.ArrayList;

/**
 * A class representing shared characteristics of animal.
 *
 * @version 2020.02.22
 */
public abstract class Animal extends Actor implements Drawable 
{
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ground The ground stores plants.
     */
    public Animal(Field field, Location location,Ground ground)
    {
        super(field, location,ground);
    }

    /**
     * Let this animal acts if it is a non-nocturnal animal during daytime.
     * @param newAnimals A list to receive newly born animals.
     */
    public void actDay(List<Actor> newAnimals)
    {
        if(!isNocturnalAnimal())
        {
            incrementAge();
            incrementHunger();
            getSick();
            if(isAlive()) 
            {
                giveBirth(newAnimals);
                Location newLocation = findFood();
                if(newLocation == null) 
                { 
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                if(newLocation != null) 
                {
                    setLocation(newLocation);
                }
                else 
                {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        else
        {
            sleep(); 
        }
    } 

    /**
     * Make this animal act if it is a nocturnal animal at night.
     * @param newAnimals A list to receive newly born animals.
     */
    public void actNight(List<Actor> newAnimals)
    {
        if(isNocturnalAnimal())
        {
            incrementAge();
            incrementHunger();
            getSick();
            if(isAlive()) 
            {
                giveBirth(newAnimals);
                Location newLocation = findFood();
                if(newLocation == null) 
                { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                if(newLocation != null) 
                {
                    setLocation(newLocation);
                }
                else 
                {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        else
        {
            sleep();  
        }
    } 

    /**
     * Get the boolean value of whether current animal is a nocturnal animal.
     */
    abstract protected boolean isNocturnalAnimal();
}
