/**
 * A class representing shared characteristics of human.
 * It might has different human occupations in the future.
 *
 * @version 2020.02.22
 */
public abstract class Human extends Actor implements Drawable
{
    public Human(Field field, Location location, Ground ground)
    {
        super(field, location,ground);
    } 
}
