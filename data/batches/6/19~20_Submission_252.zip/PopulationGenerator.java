import java.awt.Color;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

/**
 * The class is responsible for creating actors into field and simulating their beheviours.
 *
 * @version 21.2.2019
 */
public class PopulationGenerator implements Drawable
{ 
    // Constants representing configuration information for the simulation:
    // The probability that a goat will be created in any given grid position.
    private static final double GOAT_CREATION_PROBABILITY = 0.06;  
    // The probability that a giraffe will be created in any given grid position.
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.05;
    // The probability that a elephant will be created in any given grid position.
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.05;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.9;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.03;
    // The probability that a leopard will be created in any given grid position.
    private static final double LEOPORD_CREATION_PROBABILITY = 0.04;
    // The probability that a hunter will be created in any given grid position.
    private static final double HUNTER_CREATION_PROBABILITY = 0.04;

    // Instance fields.
    // The current state of the ground.
    private Ground ground;
    // The current state of the field.
    private Field field;
    // The clock to track the time of day.
    private Clock clock;
    // A list of graphical views of the simulation.
    private List<SimulatorView> views;
    // A graphical view of the simulation.
    //private SimulatorView view;
    
    private SimulatorView gridView;
    // List of actors in the field.
    private List<Actor> actors;
    // List of female actors in the field.
    private ArrayList<Actor> female;
    // List of male actors in the field.
    private ArrayList<Actor> male;
    // Map of all actor classes and thier corresponding creation probability.
    private HashMap<Class<?>,Double> map;

    /**
     * Constructor for objects of class PopulationGenerator.
     * @para depth Depth of the field.
     * @para width Width of the field.
     */
    public PopulationGenerator(int depth, int width)
    {
        ground = new Ground();
        female = new ArrayList<>();
        male = new ArrayList<>();
        actors = new ArrayList<>();
        field = new Field(depth, width);
        clock = new Clock();
        map = new HashMap<>();
        // Fill a map with all actors in the field and their creation probability.
        fillMap();  
        // Create a view list of the simulation.
        views = new ArrayList<>();
        SimulatorView view = new GridView(depth, width);
        views.add(view);
        
        SimulatorView graphView = new GraphView(500, 150, 500);
        views.add(graphView);
        
        draw();  // Draw all graphs.
    }

    /**
     * Draw all graphs with actors in the filed using their corresponding colors. 
     */
    public void draw()
    {
        fillDrawables();
        HashMap<Class<?>, Color> drawable = new HashMap<>(getMap());
        drawable.forEach((key,value)->
        {
            for(SimulatorView view : views)
            {
                view.setColor(key, value);
            }
        });
    }

    /**
     * Randomly populate field with actors and populate ground with plants.
     * @para step The current step 
     */
    public void populate(int step)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        ground.clearGround();
        for(int r = 0; r < field.getDepth(); r++) 
        {
            for(int col = 0; col < field.getWidth(); col++) 
            {
                int column = col;  
                int row = r;
                // It has to be assigned to an effectively final viriable in the lambda expression.
                map.forEach((key,value)->
                    {
                        if(rand.nextDouble() <= value) 
                        {
                            Location location = new Location(row, column);
                            try
                            {
                                Constructor constructor = key.getConstructor(new Class[]{boolean.class,Field.class,Location.class,Ground.class});
                                Actor actor = (Actor)constructor.newInstance(true,field,location,ground);
                                actors.add(actor);
                                setGender(actor);
                                // Clear male and female list which were genereated if populate has been previously invoked. 
                                actor.clearGenderList(); 
                                actor.addFemaleList(female);
                                actor.addMaleList(male);
                            }
                            catch (InstantiationException e) 
                            {
                                e.printStackTrace();
                            }
                            catch (NoSuchMethodException e) 
                            {
                                e.printStackTrace();
                            }
                            catch (IllegalAccessException e) 
                            {
                                e.printStackTrace();
                            } catch (IllegalArgumentException e) 
                            {
                                e.printStackTrace();
                            } catch (InvocationTargetException e) 
                            {
                                e.printStackTrace();
                            }
                        }
                    });
            }
        }
        updateViews(step);
        setGround();
    }

    /**
     * Fill a map with all actors in the field and their creation probability.
     */
    private void fillMap()
    {
        map.put(Elephant.class,ELEPHANT_CREATION_PROBABILITY);
        map.put(Giraffe.class,GIRAFFE_CREATION_PROBABILITY);
        map.put(Goat.class,GOAT_CREATION_PROBABILITY);
        map.put(Leopard.class,LEOPORD_CREATION_PROBABILITY);
        map.put(Lion.class,LION_CREATION_PROBABILITY);
        map.put(Hunter.class,HUNTER_CREATION_PROBABILITY);
    }

    /**
     * Populate ground with plants.
     */
    private void setGround()
    {
        Plant grass = new Grass(field, ground);
        grass.grow(grass, GRASS_CREATION_PROBABILITY);
    }

    /**
     * Set the gender of an actor.
     * @param actor The actor whose gender is ready to be set. 
     */
    private void setGender(Actor actor)
    {
        Random rand = Randomizer.getRandom();
        if(rand.nextDouble() <= 0.5)
        {
            female.add(actor);
        }
        else
        {
            male.add(actor);
        }
    }

    /**
     * Let all actors act based on the time of day. 
     * If actor is not alive, set dead.
     * Based on the given probability of raining, ground might be populated with plants.
     * Update view at each step.
     * @param step The number of steps to run for.
     */ 
    public void actAll(int step)
    {
        List<Actor> newActors = new ArrayList<>();      
        Random rand = Randomizer.getRandom();
        // Let all actors act 
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) 
        {
            Actor actor = it.next();
            if(actor.isAlive()){
                if(clock.getDay())
                {   
                    actor.actDay(newActors);  // Let actors who act day act.
                } 
                else 
                {
                    actor.actNight(newActors);  // Let actors who act night act.
                }
            }

            else if(!actor.isAlive()) 
            {
                it.remove();
                actor.setDead(); 
            }
        }
        // Set ground, if it is raining.
        if(Weather.rain())
        {
            setGround();
        }
        actors.addAll(newActors);  // Add the new actors to the main list.
        updateViews(step);  // Update views. 
    }

    /**
     * Update all existing views.
     */
    private void updateViews(int step)
    {
        for (SimulatorView view : views) {
            view.showStatus(step, field, clock);
        }
    }
    
    /**   
     * Return the list of simulator views.
     * @return views The simulator views list.
     */
    public List<SimulatorView> getView()
    {
        return views;
    }

    /**
     * Return the Field of population generator.
     * @return field The Field of population generator.
     */
    public Field getField()
    {
        return field;
    }

    /**
     * Clear all lists in population generator.
     */
    public void clearList()
    {
        actors.clear();
        female.clear();
        male.clear();
    }

    /**
     * Return list of all female actors. 
     * @return female The list of all female actors. 
     */
    public ArrayList<Actor> getFemale()
    {
        return female;
    }

    /**
     * Return list of all male actors. 
     * @return male The list of all male actors. 
     */
    public ArrayList<Actor> getMale()
    {
        return male;
    }
}
