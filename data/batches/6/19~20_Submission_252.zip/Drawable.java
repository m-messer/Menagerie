import java.util.HashMap;
import java.awt.Color;

/**
 * 
 * A class stores all actors that can be drawn in a field.
 *
 * @version 22.02.2019
 */
public interface Drawable
{
    // The map associates actor's class with its corresponding color.
    HashMap<Class<?>, Color> drawables = new HashMap<>(); 
     
    /**
     * Fill the map with actor's class and its corresponding color.
     */
    default void fillDrawables()
    {
        drawables.put(Goat.class, Color.CYAN);
        drawables.put(Lion.class, Color.BLUE);
        drawables.put(Giraffe.class, Color.YELLOW);
        drawables.put(Elephant.class, Color.LIGHT_GRAY);
        drawables.put(Leopard.class, Color.MAGENTA);
        drawables.put(Hunter.class, Color.ORANGE);
    }
    
    /**
     * Return a hashMap which associates actor's class with its corresponding color.
     * @return drawables A Map stores actor's class and its corresponding color.
     */
    default HashMap<Class<?>, Color> getMap()
    {
        return drawables;
    }
}
