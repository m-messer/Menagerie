/**
 * A simple model of a leopard.
 * Leopards age, move, eat elephant, girrafe, goat and die.
 *
 * @version 2020.02.22
 */
public class Leopard extends Animal
{
    // Characteristics shared by all leopards (class variables).
    // The age at which a leopard can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a leopard can live.
    private static final int MAX_AGE = 2500;
    // The likelihood of a leopard breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum number of foodlevel.
    private static final int MAX_FOOD_LEVEL = 20;
    // The probability to be male.
    private static final double MALE_PROBABILITY = 0.46;
    // The probability to find food.
    private static final double FINDFOOD_PROBABILITY = 0.9;
    // The probability to get virus.
    private static double VIRUS_OUTBREAK_PROBABILITY = 0.03;
    // Leopards are nocturnal Animal.
    private static final boolean isNocturnalAnimal = true;

    /**
     * Create a leopard. A leopard can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the leopard will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ground The ground stores plants.
     */
    public Leopard(boolean randomAge, Field field, Location location,Ground ground)
    {
        super(field, location,ground);
        if(randomAge) 
        {
            setAge(getRandomNumber(MAX_AGE));
            setFoodValue(getRandomNumber(MAX_FOOD_LEVEL));
        }
        else 
        { 
            setFoodValue(MAX_FOOD_LEVEL);
        }
    }

    /**
     * Return leopard's breeding age.
     * @return BREEDING_AGE Leopard's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return a leopard's maximum foodlevel.
     * @return MAX_FOOD_LEVEL Leopard's maximum foodlevel.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return leopard's maximum age.
     * @return MAX_AGE Leopard's maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return leopard's breeding probability.
     * @return BREEDING_PROBABILITY Leopard's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return leopard's maximum litter number.
     * @return MAX_LITTER_SIZE Leopard's maximum litter number.
     */
    public int getMaxLitter()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return leopard's probability to be male.
     * @return MALE_PROBABILITY The probability to be male.
     */
    public double getMaleProbability()
    {
        return MALE_PROBABILITY;
    }

    /**
     * Return the probability to find food.
     * @return FINDFOOD_PROBABILITY The probability to find food.
     */
    public double getFindFoodProbability()
    {
        return FINDFOOD_PROBABILITY;
    }

    /**
     * Return the probability to get virus.
     * @return VIRUS_OUTBREAK_PROBABILITY The probability to get virus.
     */
    public double getVirusOutbreakProbability()
    {
        return VIRUS_OUTBREAK_PROBABILITY;
    }

    /**
     * Return whether it is nocturnal animal.
     * @return isNocturnalAnimal True if it is.
     */
    public boolean isNocturnalAnimal()
    {
        return isNocturnalAnimal;
    }
}
