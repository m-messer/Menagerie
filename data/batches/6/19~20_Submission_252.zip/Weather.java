import java.util.Random;

/**
 * Class simulating weather.
 *
 * @version 21.02.2020
 */
public class Weather
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom(); 
    // The probability of raining.
    private static final double rainingProbability = 0.4; 
    // State of weather,initial value false - not raining
    private static boolean isRaining = false;

    /**
     * Based on raining probability to return boolean value.
     * @return isRaining True if it is raining.
     */
    public static boolean rain()
    {
        if (rand.nextDouble() <= rainingProbability)
        {
            isRaining = true;
            return isRaining;
        }
        isRaining = false;
        return isRaining ;
    }
}
