import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap; 
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Abstract class Actor - representing shared characteristics of actor.
 *
 * @version 21.02.2019
 */
public abstract class Actor
{  
    // Class variable.
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single goat. 
    private static final int GOAT_FOOD_VALUE = 10;
    // The food value of a single girrafe.
    private static final int GIRAFFE_FOOD_VALUE = 12;
    // The food value of a single elepant.
    private static final int ELEPHANT_FOOD_VALUE = 5;
    // The food value of a single grass.
    private static final int GRASS_FOOD_VALUE = 8;

    // Instance fields.
    // Whether the actor is alive or not.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's ground
    private Ground ground;
    // The actor's position in the field.
    private Location location;
    // The actor's age.
    private int age;
    // The actor's food level.
    private int foodLevel;
    // The list to store female actors.
    private ArrayList<Actor> female;
    // The list to store male actors.
    private ArrayList<Actor> male;
    // The List to store class of animal's prey.
    private ArrayList<Class<?>> animalPreys;
    // The List to store class of human's prey.
    private ArrayList<Class<?>> humanPreys;
    // The List to store plant's class.
    private ArrayList<Class<?>> plants;
    // The map associates actor's class with their food value.
    private HashMap<Class<?>,Integer> foodMap;
    // The map associates actor(predator) class with their corresponding prey list.
    private HashMap<Class,List<?>> map;
    // The heath condition of an actor, true if it gets sick.
    private boolean isSick;

    /**
     * Create a new actor at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ground The ground stores plants.
     */
    public Actor(Field field, Location location, Ground ground)
    {
        alive = true;
        this.field = field;
        this.ground = ground;
        setLocation(location);
        isSick = false;
        female = new ArrayList<>();  // Create list of female actors.
        male = new ArrayList<>();  // Create list of male actors.
        animalPreys = new ArrayList<>();
        humanPreys = new ArrayList<>();
        plants = new ArrayList<>();
        map = new HashMap<>();
        foodMap = new HashMap<>();
        fillList();
        fillFoodMap();
        fillMap();
    }

    /**
     * Return the actor's field.
     * @return field The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the actor's location.
     * @return location The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Check whether the actor is alive or not.
     * @return booelan True if the actor is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) 
        {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Fill the prey and plant lists with animal's classes.
     */
    protected void fillList()
    {
        animalPreys.add(Elephant.class);
        animalPreys.add(Goat.class);
        animalPreys.add(Giraffe.class);
        humanPreys.add(Goat.class);
        plants.add(Grass.class);
    }

    /**
     * Fill the food map with animal's classes and their corresponding food value.
     */
    protected void fillFoodMap()
    {
        foodMap.put(Elephant.class,ELEPHANT_FOOD_VALUE);
        foodMap.put(Giraffe.class,GIRAFFE_FOOD_VALUE);
        foodMap.put(Goat.class,GOAT_FOOD_VALUE);
        foodMap.put(Grass.class,GRASS_FOOD_VALUE);
    }

    /**
     * Fill the map with predator's classes and their corresponding preys(food).
     */
    protected void fillMap()
    {
        map.put(Leopard.class,animalPreys);
        map.put(Lion.class,animalPreys); 
        map.put(Hunter.class,humanPreys);
        map.put(Goat.class, plants);
        map.put(Giraffe.class, plants); 
        map.put(Elephant.class, plants);
    }

    /**
     * Indicate the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) 
        {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Increase the age. This could result in the actors's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > getMaxAge()) 
        {
            setDead();
        }
    }

    /**
     * Check whether or not this actor is to give birth at this step.
     * New births will be made into free adjacent locations.
     * New births will be assigned to be female or male.
     * @param newActor A list to return newly born actors.
     */
    protected void giveBirth(List<Actor> newActor)
    {
        List<Location> free = field.getFreeAdjacentLocations(location);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            Location loc = free.remove(0);
            try
            {
                Constructor constructor = getClass().getConstructor(new Class[]{boolean.class,Field.class,Location.class,Ground.class});
                Actor actor = (Actor)constructor.newInstance(true,field,location,ground);
                newActor.add(actor);
                setGender(actor);
            }
            catch (InstantiationException e) 
            {
                e.printStackTrace();
            }
            catch (NoSuchMethodException e) 
            {
                e.printStackTrace();
            }
            catch (IllegalAccessException e) 
            {
                e.printStackTrace();
            } catch (IllegalArgumentException e) 
            {
                e.printStackTrace();
            } catch (InvocationTargetException e) 
            {
                e.printStackTrace();
            }
        }
    }

    /**
     * Set the gender of an actor.
     * @param actor whose gender is ready to be set. 
     */
    private void setGender(Actor actor)
    {
        if(rand.nextDouble() <= getMaleProbability())
        {
            male.add(actor);
        }
        else
        {
            female.add(actor);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) 
        {
            births = rand.nextInt(getMaxLitter()) + 1;
        }
        return births;
    }

    /**
     * An actor can breed if the same kind of male and female individuals 
     * are in the neighboring cells and both of them reached the breeding age.
     * @return canBreed True if the actor can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        List<Location> adjacents = field.adjacentLocations(location);
        boolean canBreed = false;
        for(Location adjacent: adjacents)
         {
            if(getAge() >= getBreedingAge())
            {
                Actor neighbour = field.getObjectAt(adjacent);
                if(neighbour != null && neighbour.getClass().equals(getClass()) && neighbour.getAge() >= neighbour.getBreedingAge()) 
                // Current actor and its neighbour are the same kind.
                {
                    boolean breed1 = male.contains(this) && female.contains(neighbour);
                    boolean breed2 = female.contains(this) && male.contains(neighbour);
                    canBreed = (breed1||breed2 ? true:false);
                }
            }
        }
        return canBreed;
    }

    /**
     * Make this actor more hungry. This could result in the actor's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) 
        {
            setDead();
        }
    }

    /**
     * Increase its hunger when an actor falls asleep.
     */
    public void sleep()
    {
        incrementHunger();
    }

    /**
     * Look for preys adjacent to the current location.
     * Only the first alive prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        List<Location> adjacent = getField().adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        int futurefoodLevel = 0;
        while(it.hasNext() && this != null)
        {
            Location where = it.next();
            boolean case1 = !Weather.rain();
            boolean case2 = Weather.rain() && rand.nextDouble() <= getFindFoodProbability();
            boolean findfood = (case1 || case2 ? true:false);
            Actor prey =  field.getObjectAt(where);
            Plant plant = ground.getPlant(where);
            List list = map.get(getClass());
            if(findfood && list != null)
            {  
                for(Object cls: list){
                    if(plant != null && plant.getClass().equals(cls))
                    {
                        futurefoodLevel = foodMap.get(plant.getClass()) + getFoodLevel();
                        if(futurefoodLevel < getMaxFoodLevel())
                        {
                            ground.clearLocation(where);
                            setFoodLevel(foodMap.get(plant.getClass()));
                            return where;
                        }
                    }
                    else if(prey != null && prey.getClass().equals(cls))
                    {
                        futurefoodLevel = foodMap.get(prey.getClass()) + getFoodLevel();
                        if(futurefoodLevel < getMaxFoodLevel())
                        {
                            if(prey.isSick())
                            {
                                getSick();
                            }
                            prey.setDead(); 
                            setFoodLevel(foodMap.get(prey.getClass()));
                            return where;
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Clear female and male list.
     */
    public void clearGenderList()
    {
        female.clear();
        male.clear();
    }

    /**
     * Increment actor's food level by a given number.
     * @param number which actor's food level is going to icreased by.
     */
    public void incrementfoodLevel(int number)
    {
        foodLevel += number;
    }

    /**
     * Return food level of an actor.
     * @return food level of an actor.
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * Set the age of an actor to a given number.
     * @param A given number to be assigned towhich actor's age is going to be set to.
     */
    protected void setAge(int number)
    {
        age = number;
    }

    /**
     * Set the food level of an actor to given number.
     * @param number to which actor's food level is going to be set to.
     */
    protected void setFoodValue(int number)
    {
        foodLevel = number;
    }

    /**
     * Set given number to a random number with in given range  and return the random number.
     * @param range of the number.
     * @return random number generated from a given range.
     */
    protected int getRandomNumber(int range)
    {
        return rand.nextInt(range);
    }

    /**
     * Add an ArrayList of actors to female list.
     * @param an ArrayList ready to be added into female list. 
     */
    public void addFemaleList(ArrayList<Actor> list)
    {
        female.addAll(list);
    }

    /**
     * add an ArrayList of actors to male list.
     * @param a ArrayLis which is going to be added to male list. 
     */
    public void addMaleList(ArrayList<Actor> list)
    {
        male.addAll(list);
    }

    /**
     * Returns age of an actor.
     * @return age Age of an actor.
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Increment food level of an actor by an given number.
     * @param number The number adds to current food level.
     */
    protected void setFoodLevel(int number)
    {
        foodLevel += number;
    }

    /**
     * Return the health condition of an actor.
     * @return isSick True if it gets sick, false otherwise.
     */
    protected boolean isSick()
    {
        return isSick;
    }

    /**
     * Let actor to get sick.
     * Increments age of an actor and set isSick to true.
     */
    protected void getSick()
    {
        if(rand.nextDouble() <= getVirusOutbreakProbability())
        {
            incrementAge();
            isSick = true;
        }
    }

    /**
     * Let all actors who act during the daytime act.
     */
    abstract public void actDay(List<Actor> newActors);

    /**
     * Let all actors who act at night act.
     */
    abstract public void actNight(List<Actor> newActors);

    /**
     * Get the maximum foodlevel of an actor.
     */
    abstract public int getMaxFoodLevel();

    /**
     * Get the maximum age of an actor.
     */
    abstract public int getMaxAge();

    /**
     * Get the BreedingAge of an actor.
     */
    abstract public int getBreedingAge();

    /**
     * Get the breeding probability of an actor.
     */
    abstract public double getBreedingProbability();

    /**
     * Get the find food probability of an actor.
     */
    abstract public double getFindFoodProbability();

    /**
     * Get the male probability of an actor.
     */
    abstract public double getMaleProbability();

    /**
     * Get the maximum litter number of an actor.
     */
    abstract public int getMaxLitter();

    /**
     * Get the virus out break probability of an actor.
     */
    abstract protected double getVirusOutbreakProbability();
}