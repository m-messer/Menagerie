import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of grass.
 * Grass grows at a given rate. Grass dies when it is eaten by animals.
 *
 * @version 22.02.2020
 */
public class Grass extends Plant
{
    /**
     * Create a new grass at ground in field.
     * 
     * @param field The field currently occupied.
     * @param ground The ground within the field.
     */
    public Grass(Field field, Ground ground)
    {
        super(field,ground);
    }
}
