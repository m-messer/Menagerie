/**
 * A simple model of elephant.
 * Elephants age, move, eat grass and die.
 *
 * @version 2020.02.22 
 */
public class Elephant extends Animal
{
    // Characteristics shared by all elephants (class variables).
    // The age at which an elephant can start to breed.
    private static final int BREEDING_AGE = 32;
    // The age to which an elephant can live.
    private static final  int MAX_AGE = 3000;
    // The likelihood of an elephant breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum number of foodlevel.
    private static final int MAX_FOOD_LEVEL = 25;
    // The probability to be male.
    private static final double MALE_PROBABILITY = 0.49;
    // The probability to find food.
    private static final double FINDFOOD_PROBABILITY = 0.87;
    // The probability to get virus.
    private static double VIRUS_OUTBREAK_PROBABILITY = 0.01;
    // Elephants are not nocturnal Animal.
    private static final boolean isNocturnalAnimal = false;

    /**
     * Create an elephant. An elephant can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the elephant will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ground The ground stores plants.
     */
    public Elephant(boolean randomAge, Field field, Location location, Ground ground)
    {
        super(field, location,ground);
        if(randomAge) 
        {
            setAge(getRandomNumber(MAX_AGE));
            setFoodValue(getRandomNumber(MAX_FOOD_LEVEL));
        }
        else 
        { 
            setFoodValue(MAX_FOOD_LEVEL);
        }
    }

    /**
     * Return elephant's breeding age.
     * @return BREEDING_AGE Elephant's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return elephant's maximum foodlevel.
     * @return MAX_FOOD_LEVEL Elephant's maximum foodlevel.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return elephant's maximum age.
     * @return MAX_AGE Elephant's maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return elephant's breeding probability.
     * @return BREEDING_PROBABILITY Elephant's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return maximum litter number.
     * @return MAX_LITTER_SIZE Elephant's maximum litter number.
     */
    public int getMaxLitter()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the probability to be male.
     * @return MALE_PROBABILITY The probability to be male.
     */
    public double getMaleProbability()
    {
        return MALE_PROBABILITY;
    }

    /**
     * Return the probability to find food.
     * @return FINDFOOD_PROBABILITY The probability to find food.
     */
    public double getFindFoodProbability()
    {
        return FINDFOOD_PROBABILITY;
    }

    /**
     * Return the probability to get virus.
     * @return VIRUS_OUTBREAK_PROBABILITY The probability to get virus.
     */
    public double getVirusOutbreakProbability()
    {
        return VIRUS_OUTBREAK_PROBABILITY;
    }

    /**
     * Return whether it is nocturnal animal.
     * @return isNocturnalAnimal True if it is.
     */
    public boolean isNocturnalAnimal()
    {
        return isNocturnalAnimal;
    }
}
