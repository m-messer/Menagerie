/**
 * This the coyote class; they are predators in our simulation. They eat cats and deer.
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a coyote.
 * Coyotes age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Coyote extends Animal
{
    // Characteristics shared by all coyotes (class variables).
    // The age at which a coyote can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a coyote can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a coyote breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    
    // Number of steps a fox can go before it has to eat again.
    private static final int CAT_FOOD_VALUE = 5;
    private static final int DEER_FOOD_VALUE = 3;
    // Default food  value of a newborn coyote.
    private static final int NEWBORN_FOOD_VALUE = 28;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a coyote. A coyote can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Coyote(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CAT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(NEWBORN_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the coyote does at day time - it runs 
     * around and searches for food.
     * Sometimes it will breed or die of old age.
     * @param newCoyotes A list to return newly born coyotes.
     */
    public void actDay(List<Animal> newCoyotes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // Give birth if coyotes of opposite gender meet.
            if(meet()){
                giveBirth(newCoyotes);
            }
            
            // Try to move into a location with food.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the coyote does at night time - it runs 
     * around and searches for food.
     * Sometimes it will die of old age.
     * */
    public void actNight(List<Animal> newCoyotes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {            
            // Try to move into a location with food.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Return the maximum age of a coyote to which it will 
     * live, if not eaten or died because of hunger.
     */
    public int getMaxAge()
    {
         return MAX_AGE;   
    }
    
    /**
     * Return the breeding probability of a coyote.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum of offsprings a coyote can have.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the age at which a coyote starts to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Check whether or not this coyote is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCoyotes A list to return newly born coyotes.
     */
    private void giveBirth(List<Animal> newCoyotes)
    {
        // New coyotes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = offSprings();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Coyote young = new Coyote(false, field, loc);
            newCoyotes.add(young);
        }
    }
    
    /**
     * Look for cats and deers adjacent to the current location.
     * Only the first live cat or deer is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object habitat = field.getObjectAt(where);
            if(habitat instanceof Cat) {
                Cat cat = (Cat) habitat;
                if(cat.isAlive()) { 
                    cat.setDead();
                    foodLevel = CAT_FOOD_VALUE;
                    return where;
                }
            }
            else if(habitat instanceof Deer) {
                Deer deer = (Deer) habitat;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel = DEER_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}

 


 