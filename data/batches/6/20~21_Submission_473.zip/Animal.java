/**
 *
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Habitat
{
    // Current age of the animal.
    protected int age;
    // Current food level of the animal.
    protected int foodLevel;
    // Sex of the animlal.
    protected boolean isFemale;
    // Boolean that stores if the animal is infected or not
    protected boolean isInfected;
    // Boolean that determines wheter breeding is possible or not.
    protected boolean breedingPossible;

    // A disease variable to call methods in disease class.
    protected Disease disease = new Disease();
    protected int diseaseLength;
    // A shared random number.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
         super(field, location);
         isInfected = (disease.infectionProbability());
         isFemale = rand.nextBoolean();
    }

    abstract public void actDay(List<Animal> newAnimals);
    
    abstract public void actNight(List<Animal> newAnimals);
    
    abstract protected int getMaxAge();
    
    /**
     * Check the gender of the animal.
     * @return true if female, false if male.
     */
    protected boolean getFemale()
    {
        return isFemale;
    }
    
    /**
     * Check whether animal is infected or not.
     * @return true if infected.
     */
    protected boolean ifInfected()
    {
        return isInfected;
    }
    
    /**
     * Change the infected status of the animal.
     * Infect or disinfect the animal.
     */
    protected void changeInfected()
    {
        isInfected = true;
    }
    
    /**
     * Check if animal has reached the breeding age.
     * @return true if the animal can breed, else false.
     */
    public boolean canBreed()
    {
        return age >= getBreedingAge();
    }
    
    /**
     * Increment animal's age by one at every step.
     * The animal might die if it reaches its maximum age.
     */
    public void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Increment animal's hunger by one with every step.
     * The animal might die of starvation if food
     * is not available in the surroundings.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Calls a method in disease class to determine for how long the
     * disease will stay if animal is alive.
     */
    public void infected()
    {
        diseaseLength = disease.getDiseaseLength(); 
    }
    
    /**
     * Increment animal's hunger by one with every step.
     * The animal might die of starvation if food
     * is not available in the surroundings.
     */
    public void dicrementDisease()
    {
        diseaseLength--;
        if(diseaseLength <= 0) {
            isInfected = false;
            disease.decrementNumInfected();
        }
    }
    
    /**
     * Check if the animal meets another animal of opposite sex
     * and similar species.
     * @return true if met and allow them to reproduce.
     */
    public boolean meet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where); 
            if (animal instanceof Animal){
                Animal currentAnimal = (Animal)animal;
                if (currentAnimal!=null){
                    if(currentAnimal.ifInfected()){
                        if(disease.transferProbability()){
                            changeInfected();
                        }
                    }
                    if(currentAnimal.getClass().equals(this.getClass())){
                        if(currentAnimal.getFemale() != isFemale) { 
                            breedingPossible=true;//make can breed
                        }
                        else{
                            breedingPossible=false;
                        }
                    }
                }
            }
        }
        return breedingPossible;
    }
}