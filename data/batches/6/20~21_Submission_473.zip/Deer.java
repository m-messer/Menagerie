/**
 * his is the hamster class; they are prey in our simulation and eat the catnip plant.
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Deer.
 * Deers age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Deer extends Animal
{
    // Characteristics shared by all deers (class variables).
    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a deer can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    
    // Food value gained after eating a catnip.
    private static final int CATNIP_FOOD_VALUE = 5;
    // Default food  value of a newborn Deer.
    private static final int NEWBORN_FOOD_VALUE = 24;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CATNIP_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(NEWBORN_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the deer does at day time - it runs 
     * around and searches for food.
     * Sometimes it will breed or die of old age.
     * @param newDeers A list to return newly born deers.
     */
    public void actDay(List<Animal> newDeer)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // Give birth if Hamsters of opposite gender meet.
            if (meet()==true){
                giveBirth(newDeer);
            }
            
            // Try to move into a location with food.
            Location newLocation = findPlant();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the deer does at night time - it runs 
     * around and searches for food.
     * Sometimes it will breed or die of old age.
     * @param newDeers A list to return newly born deers.
     */
    public void actNight(List<Animal> newDeer)
    {
        incrementAge();
        incrementHunger();
         if(isAlive()) {
            // Give birth if Hamsters of opposite gender meet.
            if (meet()==true){
                giveBirth(newDeer);
            }
            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else{
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Return the maximum age of a deer to which it will 
     * live, if not eaten or died because of hunger.
     */
    public int getMaxAge()
    {
         return MAX_AGE;   
    }
    
    /**
     * Return the breeding probability of a deer.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum of offsprings a deer can have.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the age at which a deer starts to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeer A list to return newly born deers.
     */
    private void giveBirth(List<Animal> newDeer)
    {
        // New deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = offSprings();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc);
            newDeer.add(young);
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findPlant()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Catnip) {
                Catnip catnip = (Catnip) plant;
                if(catnip.isAlive()) { 
                    catnip.setDead();
                    foodLevel = CATNIP_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
