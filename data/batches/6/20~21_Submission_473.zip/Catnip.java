/**
 *
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a catnip.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Catnip extends Plant
{
    // The age at which a catnip can start to breed.
    private static final int SEEDING_AGE = 1;
    // The age to which a catnip can live.
    private static final int MAX_GROWTH = 8;
    
    private static final double GROWTH_RATE = 2;
    private static final double SLOW_GROWTH_RATE = 1.1;
    
    private static final double SEEDING_PROBABILITY = 0.7;
    
    // A shared random number generator to control breeding.
    private static final int MAX_SEEDS = 15;
    
    /**
     * Create a new catnip. A catnip may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the catnip will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Catnip(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        currentGrowth = 1;
    }
    
    /**
     * This is what the catnip does, it grows.
     * Sometimes it will breed or die of old age.
     * @param newCatnip A list to return newly seeded catnip.
     */
    public void act(List<Plant> newCatnip, String weatherType)
    {
        incrementGrowth(weatherType);
        if(isAlive()){
            reproduce(newCatnip);
        }
    }
    
    /**
     * Return the maximum growth of a catnip to which it will 
     * live, if not eaten.
     */
    public int getMaxAge()
    {
         return MAX_GROWTH;   
    }
    
    /**
     * Return the seeding probability of a catnip.
     */
    public double getBreedingProbability()
    {
        return SEEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum of seeds a catnip can produce.
     */
    public int getMaxLitterSize()
    {
        return MAX_SEEDS;
    }

    /**
     * Return the growth at which a catnip starts to produce seeds.
     */
    public int getBreedingAge()
    {
        return SEEDING_AGE;
    }
    
    /**
     * Return the normal growth rate of catnip.
     */
    public double getGrowthRate()
    {
        return GROWTH_RATE;
    }
    
    /**
     * Return the slow growth rate of catnip.
     * The growth rate of catnip in cloudy weather.
     */
    public double getSlowGrowthRate()
    {
        return SLOW_GROWTH_RATE;
    }
    
    /**
     * Check whether or not this catnip is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCatnip A list to return newly born catnips.
     */
    private void reproduce(List<Plant> newCatnip)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int seeds = offSprings();
         for(int s = 0; s < seeds && free.size() > 0; s++) {
            Location loc = free.remove(0);          
            Catnip young = new Catnip(false, field, loc);
            newCatnip.add(young);
        }
    }
}