/**
 * This is the habitat class which adjusts behaviour of the animals/plants in it.
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Habitat
{
    // Whether the animal/plant is alive or not.
    protected boolean alive;
    // The animal/plant's field.
    private Field field;
    // The animal/plant's position in the field.
    private Location location;
    // A shared random number.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal/plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Habitat(Field field, Location location)
    {
        alive = true;
        this.field = field;
        //disease=new Disease();
        setLocation(location);
    }
    
    abstract protected int getBreedingAge();
    
    abstract protected double getBreedingProbability();
    
    abstract protected int getMaxLitterSize();
    
    /**
     * Check whether the animal/plant is alive or not.
     * @return true if the animal/plant is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Generate a random integer within the range of MAX_LITTER_SIZE
     * that will decide the number of offsprings produced.
     * @return the generated int.
     */
    public int offSprings()
    {
        int offSprings = 0;
        if(rand.nextDouble() <= getBreedingProbability()) {
            offSprings = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return offSprings;
    }
    
    /**
     * Indicate that the animal/plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal/plant's location.
     * @return The animal/plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal/plant at the new location in the given field.
     * @param newLocation The animal/plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal/plant's field.
     * @return The animal/plant's field.
     */
    protected Field getField()
    {
        return field;
    }
}