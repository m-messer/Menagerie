/**
 * This is the hamster class; they are prey in our simulation and eat the catnip plant.
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a hamster.
 * Hamsters age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Hamster extends Animal
{
    // Characteristics shared by all hamsters (class variables).
    // The age at which a hamster can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a hamster can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a hamster breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    
    // Food value gained after eating a catnip.
    private static final int CATNIP_FOOD_VALUE =24;
    // Default food  value of a newborn Hamster.
    private static final int NEWBORN_FOOD_VALUE = 24;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new hamster. A hamster may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the hamster will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hamster(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CATNIP_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = NEWBORN_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the hamster does at day time - it runs 
     * around and searches for food.
     * Sometimes it will breed or die of old age.
     * @param newHamsters A list to return newly born hamsters.
     */
    public void actDay(List<Animal> newHamsters)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // Give birth if Hamsters of opposite gender meet.
            if(meet()){
                giveBirth(newHamsters);   
            }
            // Try to move into a location with food.
            Location newLocation = findPlant();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
     
    /**
     * This is what the hamster does at night time - it sleeps
     * and does not move. Sometimes it will die of old age or hunger.
     */
    public void actNight(List<Animal> newHamsters)
    {
        incrementAge();
        incrementHunger();
    }
    
    /**
     * Return the maximum age of a hamster to which it will 
     * live, if not eaten or died because of hunger.
     */
    public int getMaxAge()
    {
         return MAX_AGE;   
    }
    
    /**
     * Return the breeding probability of a hamster.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum of offsprings a hamster can have.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the age at which a hamster starts to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Check whether or not this hamster is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHamsters A list to return newly born hamsters.
     */
    public void giveBirth(List<Animal> newHamster)
    {
        // New hamsters are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        if(canBreed()){
            int births = offSprings();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Hamster young = new Hamster(false, field, loc);
                newHamster.add(young);
            }
        }
    }
        
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findPlant()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Catnip) {
                Catnip catnip = (Catnip) plant;
                if(catnip.isAlive()) { 
                    catnip.setDead();
                    foodLevel = CATNIP_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
