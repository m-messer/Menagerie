import java.util.ArrayList;
import java.util.Random;
import java.util.List;

/**
 * Write a description of class Weather here.
 *
 * @version (a version number or a date)
 */
public class Disease
{
    //probability an animal is infected with a disease when born
    private static final double INFECTION_PROBABILITY = 0.005;
    //probability a disease kills an infected animal
    private static final double KILLING_PROBABILITY = 0.0001;
    //probability a disease is transferred between animals when they meet
    private static final double TRANSFER_PROBABILITY = 0.0001;
    
    private Random rand;
    public int numOfInfected = 0;
    
    // Maximum length to which a disease can last
    private static final int maxLength = 10;
    // Minimum length to which a disease should last.
    private static final int minLength = 2;
    
    /**
     * Constructor for objects of class Disease
     */
    public Disease()
    {
        rand = Randomizer.getRandom();
    }
    
    /**
     * Infect animals with a very low probability.
     */
    public boolean infect()
    {
        if(rand.nextInt() <= INFECTION_PROBABILITY){
            return true;
        }
        return false;
    }
    
    /**
     * Increment the total number of infected animals in the habitat.
     * An infected animal might have born or some animal must've 
     * transferred it to another animal.
     */
    public void incrementNumInfected()
    {
         numOfInfected++;
    }
    
    /**
     * Decrement the total number of infected animals in the habitat.
     * An infected animal must have died or migth've lived
     * through the disease.
     */
    public void decrementNumInfected()
    {
        numOfInfected--;
    }
    
    /**
     * Reset the total number of infected animals in the Habitat.
     * To keep the statistics of the habitat updated.
     */
    public void resetInfected()
    {
         numOfInfected = 0;   
    }
    
    /**
     * return the the total number of infected animals in the habitat.
     * @return numOfInfected.
     */
    public int getNumInfected()
    {
         return numOfInfected;   
    }
    
    /**
     * Generate a random integer within the life span of any disease.
     * Int will decide the number of steps for which the disease will stay.
     * Animal might die while it is infected.
     * @return the generated int.
     */
    public int getDiseaseLength()
    {
        int diseaseLength = rand.nextInt((maxLength - minLength) + 1) + minLength; 
        return diseaseLength;
    }
    
    /**
     * Return a boolean value with low probability of it being true.
     * @return true if animal is to be infected, false if not.
     */
    public boolean infectionProbability()
    {
         if(rand.nextDouble() <= INFECTION_PROBABILITY){
             return true;
         }
         return false;
    }
    
    /**
     * Return a boolean value with low probability of it being true.
     * @return true if animal infected is spreading the disease around.
     */
    public boolean transferProbability()
    {
         if(rand.nextDouble() <= TRANSFER_PROBABILITY){
             return true;
         }
         return false; 
    }
    
    /**
     * Return a boolean value with low probability of it being true.
     * @return true if the infected animal is to be killed.
     */
    public boolean probabilityKilled()
    {
        if (rand.nextInt() <= KILLING_PROBABILITY){
            return true;
        }
        return false;
    }
}
