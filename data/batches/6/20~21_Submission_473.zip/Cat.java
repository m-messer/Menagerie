/**
 * This is the cat class; they are prey in our simulation and eat the catnip plant.
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a cat.
 * Cats age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Cat extends Animal
{
    // Characteristics shared by all cats (class variables).
    // The age at which a cat can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a cat can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a cat breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 15;
    
    // Food value gained after eating a catnip.
    private static final int CATNIP_FOOD_VALUE = 28;
    // Default food  value of a newborn Cat.
    private static final int NEWBORN_FOOD_VALUE = 26;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new cat. A cat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the cat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cat(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CATNIP_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = NEWBORN_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the cat does at day time - it runs 
     * around.
     * Sometimes it will breed or die of old age.
     * @param newCats A list to return newly born cats.
     */
    public void actDay(List<Animal> newCats)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // Give birth if cats of opposite gender meet.
            if(meet()){
                giveBirth(newCats); 
            }
            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the cat does at night time - it runs 
     * around and searches for food.
     * Sometimes it will breed or die of old age.
     * @param newCats A list to return newly born cats.
     */
    public void actNight(List<Animal> newCats)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // Give birth if cats of opposite gender meet.
            if(meet()){
                giveBirth(newCats); 
            }
            
            // Try to move into a location with food.
            Location newLocation = findPlant();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Return the maximum age of a cat to which it will 
     * live, if not eaten or died because of hunger.
     */
    public int getMaxAge()
    {
         return MAX_AGE;   
    }
    
    /**
     * Return the breeding probability of a cat.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum of offsprings a cat can have.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the age at which a cat starts to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Check whether or not this cat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCats A list to return newly born cats.
     */
    private void giveBirth(List<Animal> newCats)
    {
        // New cats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = offSprings();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cat young = new Cat(false, field, loc);
            newCats.add(young);
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findPlant()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Catnip) {
                Catnip catnip = (Catnip) plant;
                if(catnip.isAlive()) { 
                    catnip.setDead();
                    foodLevel = CATNIP_FOOD_VALUE;
                    return where;
                }
               }
            }
        return null;
    } 
}
        
        
    

 