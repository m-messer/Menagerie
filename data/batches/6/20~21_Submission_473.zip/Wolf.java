/**
 * This the wolf class; they are predators in our simulation. They eat cats and hamsters.
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * Wolves age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 160;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    
    // Number of steps a wolf can go before it has to eat again.
    private static final int HAMSTER_FOOD_VALUE = 5;
    private static final int CAT_FOOD_VALUE = 3;
    // Default food  value of a newborn Wolf.
    private static final int NEWBORN_FOOD_VALUE = 5;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a wolf. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(HAMSTER_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = NEWBORN_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the wolves does at day time - it runs 
     * around and searches for food.
     * Sometimes it will breed or die of old age.
     * @param newWolves A list to return newly born wolves.
     */
    public void actDay(List<Animal> newWolves)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // Give birth if wolves of opposite gender meet.
            if(meet()){
                giveBirth(newWolves);    
            }
            
            // Try to move into a location with food.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null ) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the wolf does at night time - it runs 
     * around and searches for food.
     * Sometimes it will die of old age.
     */
    public void actNight(List<Animal> newWolves)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {           
            // Try to move into a location with food.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Return the maximum age of a wolf to which it will 
     * live, if not eaten or died because of hunger.
     */
    public int getMaxAge()
    {
         return MAX_AGE;   
    }
    
    /**
     * Return the breeding probability of a wolf.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum of offsprings a wolf can have.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the age at which a wolf starts to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
     /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolves.
     */
    private void giveBirth(List<Animal> newWolves)
    {
        // New wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = offSprings();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, field, loc);
            newWolves.add(young);
        }
    }
    
    /**
     * Look for hamsters or cats adjacent to the current location.
     * Only the first live hamster or cat is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hamster) {
                Hamster hamster = (Hamster) animal;
                if(hamster.isAlive()) { 
                    hamster.setDead();
                    foodLevel = HAMSTER_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Cat) {
                Cat cat = (Cat) animal;
                if(cat.isAlive()) { 
                    cat.setDead();
                    foodLevel = CAT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
