/**
 * This is the plant class; plants are eaten by prey in the simulation.
 * @version (02/03/2021)
 */
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version (02/03/2021)
 */

public abstract class Plant extends Habitat
{
    // current growth of the plant.
    protected double currentGrowth;
    
    /**
     * Create a new Plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
         super(field, location);
    }
    
    abstract public void act(List<Plant> newPlants, String weatherType);
    
    abstract protected int getMaxAge();
    
    abstract protected double getGrowthRate();
    
    abstract protected double getSlowGrowthRate();
    
    abstract protected int getBreedingAge();
    
    /**
     * Increment palnt's growth at every step.
     * The growth rate differs depending on the weather.
     * The plant might die if it reaches its maximum age.
     */
    public void incrementGrowth(String weatherType)
    {
        if(weatherType.equals("cloudy"))
        {
            currentGrowth = currentGrowth*getSlowGrowthRate();
        }
        else
        {
            currentGrowth = currentGrowth*getGrowthRate();
        }
        
        if(currentGrowth >= getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Check if plant has reached the seeding age.
     * @return true if the plant can produce seeds, else false.
     */
    public boolean canBreed()
    {
        return currentGrowth >= getBreedingAge();
    }
}