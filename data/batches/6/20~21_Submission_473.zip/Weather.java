/**
 * This is the weather class that models sunshine, rain and cloudy weather in our simulation.
 * @version (02/03/2021)
 */
import java.util.ArrayList;
import java.util.Random;
import java.util.List;

/**
 * The class Weather here has a list of weathers.
 * This class has methods to generate random lengths
 * for random weathers.
 *
 * @version (a version number or a date)
 */
public class Weather
{
    // An arraylist to store the list of all weathers.
    private List<String> weather;
    // Maximum length to which a weather can last.
    private static final int maxLength = 10;
    // Minimum length to which a weather should last.
    private static final int minLength = 2;
    // A shared random number.
    private Random rand = Randomizer.getRandom();
    
    /**
     * Create a list of weathers.
     */
    public Weather()
    {
        weather = new ArrayList<>();
        weather.add("sunshine");
        weather.add("rain");
        weather.add("cloudy");
        
    }

    /**
     * Returns a random weather Type that will last for random 
     * number of steps between 10 and 20.
     * @return weatherType
     */
    public String returnWeatherType()
    {
        int index = rand.nextInt(weather.size());
        String weatherType = weather.get(index);
        return weatherType;
    }
    
    /**
     * Returns a random number of steps for which a particular 
     * weather type will last.
     * @return randomNum
     */
    public int returnWeatherLength()
    {
        int randomNum = rand.nextInt((maxLength - minLength) + 1) + minLength;
        return randomNum;
    }
}
