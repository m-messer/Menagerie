package models.plant.behaviour.abilities;

/**
 * Base behaviour - do nothing.
 *
 */
public class BlankBehaviour implements Behaviour {
    @Override
    public void act() {
        
    }
}
