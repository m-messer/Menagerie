package models.plant.behaviour.abilities;

/**
 * Interface for the behaviour of plants.
 * Implemented using Decorator design pattern.
 *
 */
public interface Behaviour {
    void act();    
}
