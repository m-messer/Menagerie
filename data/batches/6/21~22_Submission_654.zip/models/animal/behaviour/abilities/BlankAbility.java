package models.animal.behaviour.abilities;

/**
 * Used as a foundation for the Ability decorator.
 *
 */
public class BlankAbility implements Ability {
    /**
     * Do nothing.
     */
    @Override
    public void act() {
        
    }
}
