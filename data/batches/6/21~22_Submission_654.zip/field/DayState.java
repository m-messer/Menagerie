package field;

/**
 * Possible states of a full day in the simulation.
 *
 */
public enum DayState {
    DAY, NIGHT
}
