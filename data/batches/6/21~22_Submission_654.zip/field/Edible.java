package field;

/**
 * Interface for something that's edible.
 *
 */
public interface Edible {
    /**
     * @return the nutrition that the Actor will get from eating this
     */
    int getNutrition();
}
