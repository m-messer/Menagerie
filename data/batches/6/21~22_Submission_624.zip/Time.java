
/**
 * This class checks whether it is day time of night time
 *
 * @version v1
 */
public class Time
{
    // initialize time to morning
    public static boolean isNight = false;

    /**
     * Method checks the time, whether it is morning or night time
     * It is called everytime a step is taken
     */
    public static void checkTime()
    {
        int time = Simulator.step;
        if ((time %= 24) == 0){
            isNight = false;
        }
        else if ((time %= 12) == 0){
            isNight = true;
        }
    }
    
}
