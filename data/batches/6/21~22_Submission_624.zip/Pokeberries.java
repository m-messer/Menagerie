import java.util.Random;
import java.util.List;

/**
 * A simple model of a Pokeberries.
 * Pokeberries's age, pollinate and die
 *
 * @version v1
 */
public class Pokeberries extends Plant
{
    // A shared random number generator to control pollination.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new Pokeberry. A Pokeberry may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Pokeberry will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Pokeberries(boolean randomAge, Field field, Location location)
    {
        super(field, location, 10, 80, 0.4, 0.09, 3, 4);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }
    
    /**
     * This is what the Pokeberry does most of the time - ages and pollinates
     * @param newPokeberries A list to return newly pollinate pokeberries.
     */
    public void act(List<Plant> newPokeberries)
    {
        incrementAge();
        if(isAlive()) {
            int birth_Rate = Simulator.step;
            if((birth_Rate %= GROWTH_RATE)==0 ){
                reproduceNew(newPokeberries);
            }
        }
    }

    /**
     * Increase the age. This could result in the pokeberries's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this pokeberries is to pollinate at this step.
     * New births will be made into free adjacent locations.
     * @param newPokeberries A list to return newly pollinates Pokeberries.
     */
    private void reproduceNew(List<Plant> newPokeberries)
    {
        // New pokeberries are pollinated into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = pollinate();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Pokeberries young = new Pokeberries(false, field, loc);
            newPokeberries.add(young);
        }
    }

}
