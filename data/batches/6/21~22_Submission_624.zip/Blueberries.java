import java.util.Random;
import java.util.List;

/**
 * A simple model of a Blueberries.
 * Blueberries's age, pollinate and die
 *
 * @version v1
 */
public class Blueberries extends Plant
{
    // A shared random number generator to control pollination.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new Blueberry. A Blueberry may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Blueberry will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Blueberries(boolean randomAge, Field field, Location location)
    {
        super(field, location, 10, 50, 0.0, 0.14, 6, 3);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }
    
    /**
     * This is what the Blueberry does most of the time - ages and pollinates
     * @param newBlueberries A list to return newly pollinate blueberries.
     */
    public void act(List<Plant> newBlueberries)
    {
        incrementAge();
        if(isAlive()) {
            int birth_Rate = Simulator.step;
            if((birth_Rate %= GROWTH_RATE)==0 ){
                reproduceNew(newBlueberries);
            }
        }
    }

    /**
     * Increase the age. This could result in the blueberries's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this blueberries is to pollinate at this step.
     * New births will be made into free adjacent locations.
     * @param newBlueberries A list to return newly pollinates blueberries.
     */
    private void reproduceNew(List<Plant> newBlueberries)
    {
        // New blueberries are pollinated into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = pollinate();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Blueberries young = new Blueberries(false, field, loc);
            newBlueberries.add(young);
        }
    }

}
