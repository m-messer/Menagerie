import java.util.List;
import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{
    
    // The probability an animal becomes infected without contact
    private static final double DISEASE_PROBABILITY = 0.003;
    // Probability an animal will die if dieseased
    private static final double DEATH_PROBABILITY = 0.02;
    // Probability that disease spreads between animals
    private static final double DISEASE_SPREAD_PROBABILITY = 0.01;
     // Whether the animal is infected or not
    private boolean isInfected;
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * Shows a chance of animal catching disease, minimal chance
     */
    protected void catchDisease() 
    {
        if(rand.nextDouble() <= DISEASE_PROBABILITY) {
            isInfected = true;
        }
        else {
            isInfected = false;
        }
    }
    
    /**
     * Checks whether the animal is infected or not
     * @return true if the animal is infected
     */
    protected boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Small chance of animal obtaining the disease
     */
    protected void infect() 
    {
        if(rand.nextDouble() <= DISEASE_SPREAD_PROBABILITY) {
            isInfected = true;
        }
    }
    
     /**
     * Displays the animal as infected
     */
    protected void infectAnimal()
    {
        isInfected = true;
    }
    
    /**
     * Spreads disease to neighbouring animals that do not currently 
     * have the disease
     */
    protected void spreadDisease()
    {
    
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal adjacentAnimal = (Animal) animal;
                if (!adjacentAnimal.isInfected()) {
                    adjacentAnimal.infect();
                }
            }
        }
    }
    
    /**
     * Animals that are infected are prone to spreading it to other animals
     * However if the animal is not infected there is a chance for them to catch it
     */
    protected void animalIsDiseased()
    {
        if (this.isInfected()){
            spreadDisease();
        }
        else {
            catchDisease();
        }
    }
    
     /**
     * There is a low chance that an animal will die if it
     * is diseased
     * @return true if the animal dies
     */
    protected boolean deathByDisease()
    {
        if (isInfected() && rand.nextDouble() <= DEATH_PROBABILITY) {
            setDead();
            return true;
        }
        return false;
    }
}
