import java.util.Random;
import java.util.List;
/**
 * using the enum to store the Weather names .
 */
enum Weather{SUNNY, CLOUDY, RAINNING}

/**
 * set up the enum collection of different weather and 
 * call the weathers randomly
 */
public class WeatherState{
    private Weather weather;

    /**
     * set weather randomly withe 'setRandomWeather' in field.
     */
    public WeatherState(){
        setRandomWeather();
    }
    
    /**
     * random function with the enum list which call the weathers randomly. 
     */
    public void setRandomWeather(){
        Weather[] weathers = Weather.values();
        Random randomGenerator = new Random();
        weather = weathers[randomGenerator.nextInt(weathers.length)];
    }
    
    /**
     * get the value of weathers.
     */
    public Weather getWeather(){
        return weather;
    }
}
