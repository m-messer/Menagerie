import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Grass.
 * Grasses age, move, eat Antelopes, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Grass extends Animal
{
    // Characteristics shared by all Grasses (class variables).
    // The age to which a Grass can live.
    private static final int MAX_AGE = 350;
    // The likelihood of a Grass breeding.
    private static final double BREEDING_PROBABILITY = 0.01;
    // A shared random number generator to control breeding.
    private static final int MAX_LITTER_SIZE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();  
    // The Grass's age.
    private int age;

    private Simulator simulator;
    /**
     * Create a Grass. A Grass can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Grass will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * This is what the Grass does most of the time: it hunts for
     * Antelopes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newGrasses A list to return newly born Grasses.
     */
    public void act(List<Animal> newGrasses)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newGrasses);            
            // Try to move into a free location.
            Location newLocation = getLocation();
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the Grass's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this Grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrasses A list to return newly born Grasses.
     */
    private void giveBirth(List<Animal> newGrasses)
    {
        // New Grasses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrasses.add(young);
        }
    }
    /**
     * Grass will grow with different rate in different situation
     * RAINNING days will make Grass grow faster.
     */
    private int breed()
    {
        int births = 0;
        if(simulator.checkWeather()=="RAINNING"&&rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;

    }

}
