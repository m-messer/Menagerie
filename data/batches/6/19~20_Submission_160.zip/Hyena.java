import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Hyena.
 * Hyenaes age, move, eat Antelopes, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Hyena extends Animal
{
    // Characteristics shared by all Hyenaes (class variables).

    // The age at which a Hyena can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a Hyena can live.
    private static final int MAX_AGE = 400;
    // The likelihood of a Hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single Antelope. In effect, this is the
    // number of steps a Hyena can go before it has to eat again.
    private static final int Antelope_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    // The Hyena's age.
    private int age;
    // The Hyena's food level, which is increased by eating Antelopes.
    private int foodLevel;
    // setup the gender defination.
    private boolean isFemale;
    // A probability of animal have disease
    private static final double INFECTED_PROBABILITY = 0.001;
    // A probability of animal have disease
    private boolean isInfected = false;

    /**
     * Create a Hyena. A Hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Hyena will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(Antelope_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = Antelope_FOOD_VALUE;
        }
    }

    /**
     * This is what the Hyena does most of the time: it hunts for
     * Antelopes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newHyenaes A list to return newly born Hyenaes.
     */
    public void act(List<Animal> newHyenaes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHyenaes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the Hyena's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Hyena more hungry. This could result in the Hyena's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Antelopes adjacent to the current location.
     * Only the first live Antelope is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) {
                Antelope Antelope = (Antelope) animal;
                if(Antelope.isAlive()) { 
                    Antelope.setDead();
                    foodLevel = Antelope_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check if the Hyena has adjacent male Hyena.
     * @return if the Hyena has adjacent male Hyena.
     */
    private boolean hasAdjacentMale()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Hyena) {
                Hyena Hyena = (Hyena) creature;
                if(Hyena.isAlive() && !Hyena.getIsFemale() && Hyena.getAge() >= BREEDING_AGE){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * return the age value.
     */
    public int getAge()
    {
        return age;
    }

    /**
     * Check whether or not this Hyena is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHyenaes A list to return newly born Hyenaes.
     */
    private void giveBirth(List<Animal> newHyenaes)
    {
        // New Hyenaes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hyena young = new Hyena(false, field, loc);
            newHyenaes.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            infected();
        }
        return births;
    }

    /**
     * A Hyena can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;

    }

    /**
     * A method to judge the anmial will or not get infected
     */

    private void infected(){
        if(rand.nextDouble() <= INFECTED_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }

    /**
     * when animal get infected what will happend
     */
    private void infection(){
        foodLevel = foodLevel - 3;
    }

}
