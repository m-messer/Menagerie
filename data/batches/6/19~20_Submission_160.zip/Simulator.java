import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Antelopes and Liones.
 *
 * @version 2020.02.19 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a Lion will be created in any given grid position.
    private static final double Lion_CREATION_PROBABILITY = 0.025;
    // The probability that a Cheetah will be created in any given grid position.
    private static final double Cheetah_CREATION_PROBABILITY = 0.005;
    // The probability that a Antelope will be created in any given grid position.
    private static final double Antelope_CREATION_PROBABILITY = 0.15;   
    // The probability that a Zebra will be created in any given grid position.
    private static final double Zebra_CREATION_PROBABILITY = 0.05; 
    // The probability that a Hyena will be created in any given grid position.
    private static final double Hyena_CREATION_PROBABILITY = 0.025; 
    // The probability that a Grass will be created in any given grid position.
    private static final double Grass_CREATION_PROBABILITY = 0.045;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // set one time value.
    private int time;
    // define the timezone with boolean type value.
    public boolean night = false;
    // set String type time status.
    public static String timeStatus = "day";
    // the state of the environment.
    private static WeatherState state = new WeatherState();
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        //initialize the depth and width
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        // give the information of the weather by Label
        checkAndSetWeatherLabel();
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Antelope.class, Color.ORANGE);
        view.setColor(Lion.class, Color.MAGENTA);
        view.setColor(Cheetah.class, Color.RED);
        view.setColor(Zebra.class, Color.YELLOW);
        view.setColor(Hyena.class, Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
        // set up the weather label
        checkAndSetWeatherLabel();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Lion and Antelope.
     */
    public void simulateOneStep()
    {
        step++;
        this.time++;
        if(time % 50 == 0)
        {
            state.setRandomWeather();
        }
        checkAndSetWeatherLabel();
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all Antelopes act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born Liones and Antelopes to the main lists.
        animals.addAll(newAnimals);

        if(night == false & time == 50){
            time = 0;
            this.night = true;
        }

        if(night == true & time == 50){
            time = 0;   
            this.night = false;
        }
        //Setup time info
        setTime();
        view.showStatus(step, field, timeStatus);
    }

    /**
     * Run the simulation with the changes of Day and Night.
     */
    public void setTime(){
        if(!night){
            this.timeStatus = "day";
        } 

        if(night){
            this.timeStatus = "night";
        }

    }
    
    /**
     * get time value.
     * 
     */
    public static String getTime(){
        return timeStatus;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, timeStatus);
    }

    /**
     * Randomly populate the field with Liones and Antelopes.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Lion_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion Lion = new Lion(true, field, location);
                    animals.add(Lion);
                }
                else if(rand.nextDouble() <= Cheetah_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah Cheetah = new Cheetah(true, field, location);
                    animals.add(Cheetah);
                }
                else if(rand.nextDouble() <= Antelope_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope Antelope = new Antelope(true, field, location);
                    animals.add(Antelope);
                }
                else if(rand.nextDouble() <= Zebra_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra Zebra = new Zebra(true, field, location);
                    animals.add(Zebra);
                }
                else if(rand.nextDouble() <= Hyena_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena Hyena = new Hyena(true, field, location);
                    animals.add(Hyena);
                }
                else if(rand.nextDouble() <= Grass_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass Grass = new Grass(true, field, location);
                    animals.add(Grass);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * get the Weather status.
     */
    public static WeatherState getState()
    {
        return state;
    }

    /**
     * Return the name of the weatherstates.
     * 
     */
    public static String checkWeather(){
        return state.getWeather().name();
    }

    /**
     * Check if there is normal weather at that moment with SUNNY.
     */
    public boolean checkIfSunny(){
        return checkWeather() == "SUNNY";
    }
    
    /**
     * Check if there is normal weather at that moment with CLOUDY.
     */
    public boolean checkIfCloudy(){
        return checkWeather() == "CLOUDY";
    }
    
    /**
     * Check if there is normal weather at that moment with RAINNING.
     */
    public boolean checkIfRainning(){
        return checkWeather() == "RAINNING";
    }
    
    /**
     * the function of publishing the Weather states in the label.
     */
    private void checkAndSetWeatherLabel(){ 
        if(checkIfSunny()){
            view.setSunnyLabel();
        }
        else if(checkIfCloudy()){
            view.setCloudyLabel();
        }
        else{
            view.setRainningLabel();
        }

    }

}
