import java.util.Random;

/**
 * A weather class that adds a probability for the weather to be clear
 * or rainy. Whenever the weather is rainy, the grass should grow.
 *
 * @version 01/03/2021
 */
public class Weather
{
    // The likelihood of rain's occurance.
    private static final double RAIN_PROBABILITY = 0.129;//0.7;
    // A random number generator to control the weather.
    private static final Random rand = Randomizer.getRandom();
    // If the weather is raining.
    private boolean rain;
    
    /**
     * Update the weather based on the rain probability.
     */
    public void updateWeather()
    {
        rain = false;
        if(rand.nextDouble() <= RAIN_PROBABILITY) {
            rain = true;
        }
    }
    
    /**
     * Return the rain's boolean value.
     * @return true if the weather is raining.
     */
    public boolean isRain()
    {
        return rain;
    }
    
    /**
     * Return the current weather condition.
     * @return String rain.
     */
    public String getCurrentWeather()
    {
        if(rain){
            return "Rain";
        }
        else {
            return "Clear";
        }
    }
}
