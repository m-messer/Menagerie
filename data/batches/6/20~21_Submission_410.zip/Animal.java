import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 03/03/2021
 */
public abstract class Animal extends Actor
{
    // The food level of the animal
    protected int foodLevel;
    // The animal's gender.
    private boolean gender;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        gender = setGender();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Actor> newAnimals)
    {
        incrementAge();
        incrementHunger();
        isFull();
        if(isAlive() && isAwake(Simulator.getSimTime())) {
            giveBirth(newAnimals);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * A zebra can breed if it has reached the breeding age.
     * @return true if the zebra can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New animals will be born only when a male animal meets a female animal
     * of the same class meet.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        if(canBreed()) {
            Animal spouse = findOppositeGender();
            if(spouse != null) {
                List<Location> free = field.getFreeAdjacentLocations(getLocation());
                int births = breed();
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    Animal young = setBornAnimal(false, field, loc);
                    newAnimals.add(young);
                }
            }
        }
    }

    /**
     * Check if an animal is of the same class. If so, then
     * check if they are of opposite gender.
     */
    protected Animal findOppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        ArrayList<Animal> spouseList = new ArrayList<>();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor != null && actor.getClass().equals(this.getClass())) {
                Animal animal = (Animal) actor;
                if((this.getGender() != animal.getGender() && animal.canBreed())) {
                    spouseList.add(animal);
                }
            }
        }
        if(!spouseList.isEmpty()) {
            Animal chooseSpouse = spouseList.get(rand.nextInt(spouseList.size()));
            return chooseSpouse;
        }
        return null;
    }

    /**
     * Determine the gender of an animal.
     */
    protected boolean setGender()
    {
        Random rd = new Random();
        gender = rd.nextBoolean();
        if(gender == true) {
            // Assuming male = true
            boolean male = true;
            return male;
        }
        else {
            // Assuming female = false
            boolean female = false;
            return female;
        }
    }

    /**
     * Return the animal's gender.
     * @return gender The animal's gender.
     */
    protected boolean getGender()
    {
        return gender;
    }

    /**
     * Return true if the animal has reached its full eating capacity.
     * @return full If the maximum food capacity is reached.
     */
    protected boolean isFull()
    {
        boolean full = false;
        if(foodLevel > getMaxFoodLevel()) {
            full = true;
        }
        return full;
    }

    /**
     * Return true if the animal is sleeping.
     * @return sleeping If the animal is sleeping.
     */
    protected boolean isAwake(int time)
    {
        boolean awake = true;
        return awake;
    }

    protected abstract int getBreedingAge();

    protected abstract double getBreedingProbability();

    protected abstract int getMaxLitterSize();

    protected abstract Animal setBornAnimal(boolean randomAge, Field field, Location loc);

    protected abstract Location findFood();

    protected abstract int getMaxFoodLevel();
}
