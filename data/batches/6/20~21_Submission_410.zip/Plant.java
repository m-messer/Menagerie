import java.util.List;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 03/03/2021
 */
public abstract class Plant extends Actor
{
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * This is what the plants does most of the time - if it is raining, 
     * it will grow or die of old age.
     * @param newGrass A list to return newly born grass.
     */
    protected void act(List<Actor> newPlants)
    {
        if(isAlive() && isGrowth()) {
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                Plant smallPlants = setSmallPlants(true, getField(), newLocation);
                newPlants.add(smallPlants);
            }
            if(Simulator.getSimWeather()) {
                incrementAge();
            }
        }
    }
    
    protected abstract int getMaxAge();
    
    protected abstract boolean isGrowth();

    protected abstract Plant setSmallPlants(boolean randomAge, Field field, Location loc);
}
