
/**
 * A time class that adds and controls time in the simulation.
 * Using time in the simulator will enable animals to experience
 * a new behaviour.
 *
 * @version 01/03/2021
 */
public class Time
{
    // A time for the simulator.
    private int time;
    
    /**
     * set an updated time.
     * @param newTime The new time to be set.
     */
    public int setTime(int newTime)
    {
        time = newTime % 24;
        return time;
    }
    
    /**
     * Return the time.
     * @return the current time.
     */
    public int getTime()
    {
        return time;
    }
}
