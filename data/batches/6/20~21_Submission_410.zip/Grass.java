import java.util.List;

/**
 * A simple model of a grass.
 * Grass age, breed, and die.
 *
 * @version 03/03/2021
 */
public class Grass extends Plant
{
    // The age to which a grass can live.
    private static final int MAX_AGE = 5;
    // The likelihood of a grass's growth.
    private static final double GROWTH_RATE = 0.13;

    /**
     * Create a new grass. A grass may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }
    
    /**
     * Return the max age of this grass.
     * @return MAX_AGE the maximum age of this grass.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Check for a growth rate for the grass.
     * @return true The probability of the growth rate.
     */
    protected boolean isGrowth()
    {
        boolean growing = false;
        if(rand.nextDouble() <= GROWTH_RATE) {
            growing =  true;
        }
        return growing;
    }
    
    /**
     * Create a new small grass.
     * @return small New small grass.
     */
    protected Plant setSmallPlants(boolean randomAge, Field field, Location loc)
    {
        Plant small;
        small = new Grass(randomAge, field, loc);
        return small;
    }
}
