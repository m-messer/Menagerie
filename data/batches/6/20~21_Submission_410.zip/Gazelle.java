import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a gazelle.
 * Gazelle age, move, breed, and die.
 *
 * @version 03/03/2021
 */
public class Gazelle extends Animal
{
    // Characteristics shared by all gazelles (class variables).

    // The age at which a gazelle can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a gazelle can live.
    private static final int MAX_AGE = 160;
    // The likelihood of a gazelle breeding.
    private static final double BREEDING_PROBABILITY = 0.24;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of the grass.
    private static final int GRASS_FOOD_VALUE = 10;
    // The maximum number of the animal's eating capacity.
    private static final int MAX_FOOD_LEVEL = 80;

    /**
     * Create a new gazelle. A gazelle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the gazelle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gazelle(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else{
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * Look for gazelles adjacent to the current location.
     * Only the first live gazelle is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if(isFull() == false) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object plant = field.getObjectAt(where);
                if(plant instanceof Grass) {
                    Grass grass = (Grass) plant;
                    if(grass.isAlive()) { 
                        grass.setDead();
                        foodLevel = GRASS_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * This animal is awake most of the time,
     * it sleeps from 20:00 PM till 4:00 AM.
     */
    protected boolean isAwake(int time)
    {
        if((4 <= time) && (time <= 19)) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Create a new young animal of this animal class.
     * @return young New young animals of a class.
     */
    protected Animal setBornAnimal(boolean randomAge, Field field, Location loc)
    {
        Animal young = new Gazelle(false, field, loc);
        return young;
    }

    /**
     * Return the breeding age of this animal.
     * @return BREEDING_AGE the age where this animal can breed.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the max age of this animal.
     * @return MAX_AGE the maximum age of this animal.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return the breeding probability of this animal.
     * @return BREEDING_PROBABILITY this animal's breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the maximum litter size of this animal.
     * @return MAX_LITTER_SIZE The maximum babies of this animal.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return this animal's max food level.
     * @return MAX_FOOD_LEVEL The maximum food that can be consumed.
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
}
