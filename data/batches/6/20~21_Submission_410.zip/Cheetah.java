import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a cheetah.
 * Cheetah age, move, eat gazelles, and die.
 *
 * @version 03/03/2021
 */
public class Cheetah extends Animal
{
    // Characteristics shared by all cheetahs (class variables).

    // The age at which a cheetah can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a cheetah can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a cheetah breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single cheetah. In effect, this is the
    // number of steps a cheetah can go before it has to eat again.
    private static final int GAZELLE_FOOD_VALUE = 12;
    // The maximum number of the animal's eating capacity.
    private static final int MAX_FOOD_LEVEL = 35;

    /**
     * Create a cheetah. A cheetah can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cheetah will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cheetah(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GAZELLE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GAZELLE_FOOD_VALUE;
        }
    }

    /**
     * Look for cheetahs adjacent to the current location.
     * Only the first live gazelle is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if(isFull() == false) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Gazelle) {
                    Gazelle gazelle = (Gazelle) animal;
                    if(gazelle.isAlive()) {
                        gazelle.setDead();
                        foodLevel = GAZELLE_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * This animal is awake most of the time,
     * it sleeps from 21:00 PM till 4:00 AM.
     */
    protected boolean isAwake(int time)
    {
        if((3 <= time) && (time <= 20)) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Create a new young animal of this animal class.
     * @return young New young animals of a class.
     */
    protected Animal setBornAnimal(boolean randomAge, Field field, Location loc)
    {
        Animal young = new Cheetah(false, field, loc);
        return young;
    }

    /**
     * Return the breeding age of this animal.
     * @return BREEDING_AGE the age where this animal can breed.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the max age of this animal.
     * @return MAX_AGE the maximum age of this animal.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return the breeding probability of this animal.
     * @return BREEDING_PROBABILITY this animal's breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the maximum litter size of this animal.
     * @return MAX_LITTER_SIZE The maximum babies of this animal.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return this animal's max food level.
     * @return MAX_FOOD_LEVEL The maximum food that can be consumed.
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
}
