import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a ox.
 * oxen age, move, breed, and die.
 *
 * @version 2019.2.22 (2)
 */
public class Ox extends Animal
{
    // Characteristics shared by all oxen (class variables).

    // The age at which a ox can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a ox can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a ox breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The gender of a ox.
    private String gender;
    // The food value of grass. In effect, this is the
    // number of steps an ox can go before it has to eat again.
    private static final int Grass_FOOD_VALUE = 15;
    // Individual characteristics (instance fields).
    
    // The ox's age.
    private int age;
    // The ox's food level, which is increased by eating plants.
    private int foodLevel;
    //Whether the ox has disease.
    private boolean HasDisease;
    //Days after ox has disease.
    private int DaysAfterDisease;

    /**
     * Create a new ox. An ox may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the ox will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Ox(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        HasDisease = false;
        DaysAfterDisease = 0;
        int sex = rand.nextInt(2);
        if (sex == 0) {
        gender ="male";
        }
        else {
        gender ="female";
        }
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(Grass_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = Grass_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the ox does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newoxen A list to return newly born oxen.
     */
    public void act(List<Animal> newOxen)
    {
        incrementAge();
        incrementHunger();
        //check whether the animal has disease.
        //after 4 days they will die.
        if(rand.nextDouble() <= getDiseaseRate() && !HasDisease) {
             HasDisease = true;
        }
        if(HasDisease){
             DaysAfterDisease ++;
             if(DaysAfterDisease >= 5){
             setDead();
             }
        }
        if(isAlive()) {
            //check whether neigbour of female has male animal and birth if so.
            //check whether neigbour of animal can be infected.
            if(gender == "female"){
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                   Location where = it.next();
                   Object animal = field.getObjectAt(where);
                   if(animal instanceof Ox) {
                       Ox ox = (Ox) animal;
                       if(ox.gender == "male"){
                           giveBirth(newOxen);
                       }
                       if(HasDisease){
                           ox.HasDisease = true;
                       }
                   }
                }
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
            setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the ox's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    /**
     * Make this ox more hungry. This could result in the ox's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this ox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOxen A list to return newly born oxen.
     */
    private void giveBirth(List<Animal> newOxen)
    {
        // New Oxen are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Ox young = new Ox(false, field, loc);
            newOxen.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An Ox can breed if it has reached the breeding age.
     * @return true if the ox can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = foodLevel + Grass_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    /**
     * This is what happened when oxen sleep .
     * They will get older and hungry.
     * @param newSheep A list to return newly born sheep.
     */
    public void sleep(List<Animal> newOxen){
       incrementAge();
       incrementHunger();
    }
}