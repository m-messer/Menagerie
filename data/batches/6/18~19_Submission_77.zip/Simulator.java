
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2019.2.22 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a sheep will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.05;
    // The probability that an ox will be created in any given grid position.
    private static final double OX_CREATION_PROBABILITY = 0.05;  
    // The probability that a tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.025;   
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.025;   
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.05;   
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.3; 
    // The random variable for getting a random weather.
    private static final Random rand1 = Randomizer.getRandom();
    // List of plants in the field.
    private List<Plant> plants;
    // List of animals in the field.
    private List<Animal> animals;
    // List of waethers in the field.
    private ArrayList<String> weathers;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Mouse.class, Color.ORANGE);
        view.setColor(Sheep.class, Color.BLUE);
        view.setColor(Ox.class, Color.YELLOW);
        view.setColor(Tiger.class, Color.BLACK);
        view.setColor(Snake.class, Color.RED);
        view.setColor(Grass.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.Every 5 step, there will be a night.
     */
    public void simulateOneStep()
    {   
        //add some weathers
        ArrayList<String> weathers = new ArrayList<String>();
        weathers.add("cloudy");
        weathers.add("rainy");
        weathers.add("snowy");
        // Provide space for newborn animals.
        
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>(); 
        String weather = "";
        weather = weathers.get(rand1.nextInt(3));
        step++;
        //Check if this step is night.
        if(step % 5 == 0){
            for(Iterator<Plant> itt = plants.iterator(); itt.hasNext(); ) {
                Plant plant = itt.next();
                //if weather is rainy the grass will breed more.
                if(weather == "rainy"){
                    plant.setProbability(0.5);
                }
                else if(weather == "cloudy"){
                    plant.setProbability(0.35);
                }
                else if(weather == "snowy"){
                    plant.setProbability(0);
                }
                plant.act(newPlants);
                if(! plant.isAlive()) {
                    itt.remove();
                }
            }
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                //In weird weather animals are easier to get disease.
                if(weather == "rainy"){
                    animal.setDiseaseRate(0.005);
                }
                else if(weather == "cloudy"){
                    animal.setDiseaseRate(0.001);
                }
                else if(weather == "snowy"){
                    animal.setDiseaseRate(0.008);
                }
                animal.sleep(newAnimals);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
        }
        //every 100 steps there will be an earthquake;
        else if(step % 100 == 0){
        Earthquake();
        }
        else{
            // Let all animals and plants act.
        
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                //In weird weather animals are easier to get disease.
                if(weather == "rainy"){
                    animal.setDiseaseRate(0.005);
                }
                else if(weather == "cloudy"){
                    animal.setDiseaseRate(0.001);
                }
                else if(weather == "snowy"){
                    animal.setDiseaseRate(0.008);
                }
                animal.act(newAnimals);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
        
        
             for(Iterator<Plant> itt = plants.iterator(); itt.hasNext(); ) {
                Plant plant = itt.next();
                //if weather is rainy the grass will breed more.
                if(weather == "rainy"){
                    plant.setProbability(0.5);
                }
                else if(weather == "cloudy"){
                    plant.setProbability(0.35);
                }
                else if(weather == "snowy"){
                    plant.setProbability(0);
                }
                plant.act(newPlants);
                if(! plant.isAlive()) {
                    itt.remove();
                }
            }
               
            // Add the newly born animals and plants to the main lists.
            animals.addAll(newAnimals);
            plants.addAll(newPlants);
        

            
        }
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    /**
     * Earthquake in random location will destroy some animals and plants.
     */
    public void Earthquake()
    {
        int randomrow = 0;
        int randomcol = 0;
        int randomlength = 0;
        //Get the range of Earthquake
        randomrow = rand1.nextInt(35);
        randomcol = rand1.nextInt(55);
        randomlength = rand1.nextInt(25);
        for(int row = randomrow; row < randomrow + randomlength; row++){
            for(int col = randomcol; col < randomcol + randomlength; col++) {
                Location loc = new Location(row,col);
                Object creature = field.getObjectAt(loc);
                if(creature instanceof Animal){
                Animal animal = (Animal) creature;
                animal.setDead();
                }
                else if(creature instanceof Plant){
                Plant plant = (Plant) creature;
                plant.setDead();
                }
            }
        }
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sheep sheep = new Sheep(true, field, location);
                    animals.add(sheep);
                }
                else if(rand.nextDouble() <= OX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Ox ox = new Ox(true, field, location);
                    animals.add(ox);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                }
                
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    plants.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
