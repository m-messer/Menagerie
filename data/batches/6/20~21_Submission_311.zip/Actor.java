import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 *Abstract actor class- stores animal and plants information
 *
 */
public abstract class Actor
{
    // checks if actors are alive
    private boolean alive;

    protected int age;

    protected Field field;

    protected Location location;
    
    //most classes uses randomizer from actor class
    protected static final Random rand = Randomizer.getRandom();

    /**
     * Creates new actors.
     * @param newActors A list for storing newly created actors in the location and field.
     */
    public Actor(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * States that the actor is no longer alive.
     * returns null if removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Increase the age.
     * This could result in the actor's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the actor at the new location in a specific field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * creates new actors
     */
    protected abstract void act(List<Actor> newActors);

    /**
     * gets the max age of an actor
     */
    protected abstract int getMaxAge();

}

