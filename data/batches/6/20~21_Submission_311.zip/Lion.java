import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Lion.
 * Lion age, move, breed, and die.
 *
 */
public class Lion extends Animal
{
    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    //Food lion will hunt for.
    private static final int ZEBRA_FOOD_VALUE = 15;
    private static final int IGUANA_FOOD_VALUE = 15;
    
    //max food intake an animal could have
    private static int MAX_FOOD_LEVEL = 40;

    /**
     * Create a new lion. A lion may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the lion will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super (field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE ) + rand.nextInt(IGUANA_FOOD_VALUE);

        }
        else{
            age = 0;
            foodLevel = ZEBRA_FOOD_VALUE + IGUANA_FOOD_VALUE;

        }
    }

    /**
     * Look for lions adjacent to the current location.
     * Only the first live lion is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if(!isFull()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                //checks if there is a zebra in an adjacent location
                if(animal instanceof Zebra ) {
                    Zebra zebra = (Zebra) animal;
                    if(zebra.isAlive()) { 
                        zebra.setDead();
                        foodLevel = ZEBRA_FOOD_VALUE;
                        return where;
                    }
                }
                else if (animal instanceof Iguana) {
                    Iguana iguana = (Iguana) animal;
                    //checks if there is an iguana in an adjacent location
                    if (iguana.isAlive()) { 
                        iguana.setDead();
                        foodLevel = IGUANA_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    protected int getMaxAge(){
        return MAX_AGE;
    }

    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    protected int getMaxLitterSize (){
        return MAX_LITTER_SIZE;
    }

    /**
     * Checks if lion is asleep within the specific times.
     * @returns a boolean type true if lion is sleeping.
     * @returns a boolean type false is lion is not sleeping.
     */
    protected boolean isNotAsleep(int time)
    {
        if( (0 <= time) && (time <= 12)) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Gets for the max food level a lion could hunt for.
     */
    protected int getMAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }

    /**
     * Creates an object of animal
     * @return new born animals
     * @param boolean age, current field, location to give birth
     */
    protected Animal getNewAnimalBorn(boolean randomAge, Field field, Location loc)
    {
        Animal young;
        return young = new Lion(false, field, loc);
    }

}
