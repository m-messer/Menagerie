
/**
 * Flower class that keeps track of the flower growth 
 */
public class Flower extends Plants {

    private static final int MAX_AGE = 5;
    private static final double GROWTH_RATE = 0.06;

    public Flower(boolean randomAge, Field field, Location location) {
        super(field, location);

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    protected int getMaxAge() {
        return MAX_AGE;
    }

    protected boolean isGrowing() {
        return rand.nextDouble() <= GROWTH_RATE;
    }

    public Plants makeNewPlant(boolean randomAge, Field field, Location location)
    {
        return new Flower(randomAge, field, location);
    }
}