import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a jaguar.
 * Jaguar age, move, breed, and die.
 *
 */
public class Jaguar extends Animal
{
    // The age at which a jaguar can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a jaguar can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a jaguar breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    private static final int ZEBRA_FOOD_VALUE = 15;
    
    //max food intake an animal could have
    private static int MAX_FOOD_LEVEL = 60;

    /**
     * Create a new jaguar. A jaguar may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the jaguar will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Jaguar(boolean randomAge, Field field, Location location)
    {
        super (field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE);
        }
        else{
            age = 0;
            foodLevel = ZEBRA_FOOD_VALUE;
        }
    }

    /**
     * Look for jaguar adjacent to the current location.
     * Only the first live jaguar is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if(!isFull()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                //checks if there is a zebra in an adjacent location
                if(animal instanceof Zebra) {
                    Zebra zebra = (Zebra) animal;
                    if(zebra.isAlive()) { 
                        zebra.setDead();
                        foodLevel = ZEBRA_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    protected int getMaxAge(){
        return MAX_AGE;
    }

    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     *  Gets the max food level a jaguar could hunt for.
     *  @return max food level
     */
    protected int getMAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }

    /**
     * Creates an object of animal
     * @return new born animals
     * @param boolean age, current field, location to give birth
     */
    protected Animal getNewAnimalBorn(boolean randomAge, Field field, Location loc)
    {
        Animal young;
        return young = new Jaguar(false, field, loc);
    }
}
