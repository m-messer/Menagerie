import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a snake.
 * Snake age, move, breed, and die.
 *
 */
public class Snake extends Animal
{
    // The age at which a Snake can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Snake can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a Snake breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    private static final int IGUANA_FOOD_VALUE = 15;

    //max food level an animal could hunt for
    private static int MAX_FOOD_LEVEL= 60;

    /**
     * Create a new Snake. A Snake may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the snake will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(IGUANA_FOOD_VALUE);
        }
        else{
            age = 0;
            foodLevel = IGUANA_FOOD_VALUE;
        }
    }    

    /**
     * Look for Snakes adjacent to the current location.
     * Only the first live Snake is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if(!isFull()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                //Checks if there is an iguana at an adjacent location
                if(animal instanceof Iguana) {
                    Iguana iguana = (Iguana) animal;
                    if(iguana.isAlive()) { 
                        iguana.setDead();
                        foodLevel = IGUANA_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    protected int getMaxAge(){
        return MAX_AGE;
    }

    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    protected int getMaxLitterSize (){
        return MAX_LITTER_SIZE;
    }

    /**
     * Gets for the max food level a Snake could hunt for.
     */
    protected int getMAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }

    /**
     * Creates an object of animal
     * @return new born animals
     * @param boolean age, current field, location to give birth
     */
    protected Animal getNewAnimalBorn(boolean randomAge, Field field, Location loc)
    {
        Animal young;
        return young = new Snake(false, field, loc);
    }
}
