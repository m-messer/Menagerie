import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Zebra.
 * Zebras age, move, breed, and die.
 *
 */
public class Zebra extends Animal
{
    private static final int BREEDING_AGE = 3;
    // The age to which a Zebra can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a Zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.88;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    private static final int GRASS_FOOD_VALUE = 22;
    
    //max food intake an animal could have
    private static int MAX_FOOD_LEVEL = 44;

    /**
     * Create a new Zebra. A Zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else{
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * Look for Zebras adjacent to the current location.
     * Only the first live Zebra is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if(!isFull()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object plants = field.getObjectAt(where);
                //Checks if there is grass in an adjacent location
                if(plants instanceof Grass) {
                    Grass grass = (Grass) plants;
                    if(grass.isAlive()) { 

                        grass.setDead();
                        foodLevel = GRASS_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    protected int getMaxAge(){
        return MAX_AGE;
    }

    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    protected int getMaxLitterSize (){
        return MAX_LITTER_SIZE;
    }

    /**
     * Gets for the max food level a Zebra could hunt for.
     */
    protected int getMAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }

    /**
     * Creates an object of animal
     * @return new born animals
     * @param boolean age, current field, location to give birth
     */
    protected Animal getNewAnimalBorn(boolean randomAge, Field field, Location loc)
    {
        Animal young;
        return young = new Zebra(false, field, loc);
    }

}
