import java.util.List;

/**
 * Abstract class Plants - Creates a plant of different types.
 *
 */
public abstract class Plants extends Actor
{

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(Field field, Location location)
    {
        super(field, location);

    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     */
    protected void act (List<Actor> newPlants){

        if(isAlive()) {
            if(isGrowing()) {
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    Plants newPlant = makeNewPlant(true, getField(), newLocation);
                    newPlants.add(newPlant);
                }
                if(Simulator.getWeather().getRaining()) {
                    incrementAge();
                }
            }
        }
    }

    abstract protected boolean isGrowing();

   abstract protected Plants makeNewPlant(boolean randomAge, Field field, Location location);

}