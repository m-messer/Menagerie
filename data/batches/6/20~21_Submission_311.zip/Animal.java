import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{
    //Checks for Male or female.
    private boolean gender;
    //Checks if foodLevel is enough for animal.
    protected int foodLevel;
    //Checks if animal is full.
    protected boolean Full;

    /**
     * Create a new animal at location in a field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        gender = setGender();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Actor> newActors)
    {
        incrementAge();
        incrementHunger();
        //Checks if the animal is no longer hunting for food
        isFull();
        //Checks the state of an animal at a specific time
        if(isAlive() && isNotAsleep(Simulator.getTime())){
            giveBirth(newActors);   
            // Try to move into a free location.
            Location newLocation = findFood();

            if(newLocation == null || isFull()) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * controls animal hunting for food.
     * @returns if animal is full.
     */
    protected boolean isFull(){
        boolean full = false;
        if(foodLevel > getMAX_FOOD_LEVEL()){
            full = true;
        }
        return full;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        //New animals are born into adjacent locations.
        //Get a list of adjacent free locations.
        //Checks gender of adjacent animal

        if(canBreed() && getGender() == false){
            Animal partner = findOppositeGender();
            if(partner != null){
                List<Location> free = field.getFreeAdjacentLocations(getLocation());
                int births =  breed();
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    Animal young = getNewAnimalBorn(false, field, loc);
                    newAnimals.add(young);
                } 
            }
        }
    }

    /**
     * checks for the oppisite gender in an adjacent location.
     * @returns null if the oppisite gender is not found
     */
    protected Animal findOppositeGender() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        ArrayList<Animal> partnerList = new ArrayList<>();

        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            //if animals have the same class 
            if(actor != null && actor.getClass().equals(this.getClass())){
                Animal animal = (Animal) actor;
                // if animals have the same class and gender they will breed
                if((this.getGender() != animal.getGender() && animal.canBreed())){
                    partnerList.add(animal);
                }
            }
        }
        if(!partnerList.isEmpty()){
            Animal choosePartner = partnerList.get(rand.nextInt(partnerList.size()));
            return choosePartner;
        }
        return null;
    }

    /**
     * Sets each gender to a boolean value
     * @return boolean true for male
     * @return boolean false for female
     */protected boolean setGender()
    {
        Random rd = new Random();
        gender = rd.nextBoolean();
        if(gender == true) {
            // male = true
            return true;
        }
        else {
            // female = false
            return false;
        }
    }

    /**
     * gets the adjacent animal gender
     * @returns the animal gender
     */protected boolean getGender(){
        return gender;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return breedingAge.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Checks whether animal is asleep or not.
     * @return true if animal is asleep.
     */
    protected boolean isNotAsleep(int time)
    {
        return true;
    }

    /**
     * Makes an animal more hungry
     * This might result in their death
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * @return the age when animal breed
     */
    protected abstract int getBreedingAge();

    /**
     * @return the probability of each animal breeding
     */
    protected abstract double getBreedingProbability();

    /**
     * @return the maximum litter size an animal could have
     */
    protected abstract int getMaxLitterSize();

    /**
     * gets max age of an animal
     * @returns max age of an animal
     */
    protected abstract int getMaxAge();

    /**
     * @returns the location of food found by an animal
     */
    protected abstract Location findFood();

    /**
     * gets the max food level an animal can hunt
     */
    protected abstract int getMAX_FOOD_LEVEL();

    /**
     * Creates an object of animal
     * @return new born animals
     * @param boolean age, current field, location to give birth
     */
    protected abstract Animal getNewAnimalBorn(boolean randomAge, Field field, Location loc);
}
