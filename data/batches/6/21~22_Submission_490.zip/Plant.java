
/**
 * All the plants which are generated. These are eaten by rats and deer.
 *
 * @version 2022.03.01 (1)
 */
public class Plant
{
    // The field the plant spawns in.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // Whether or not the plant is alive.
    private boolean alive;

    /**
     * Constructor for objects of class Plant.
     * @param field The field the plant spawns in.
     * @param location The location within the field the plant spawns in.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Returns whether or not the plant is alive.
     * @return Checks if the plant is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Returns the location of the plant.
     * @return The location within the field of the plant.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Moves the plant to a given location.
     * @param newLocation The location you want to move the plant to.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        } //if something exists in the location, it is cleared to place the plant in that location.
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
}
