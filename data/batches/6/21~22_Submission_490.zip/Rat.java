import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Rat.
 * Rats age, move, breed, and die.
 *
 * @version 2022.03.01 (1)
 */
public class Rat extends Animal
{
    // Characteristics shared by all Rats (class variables).
    private static int PLANT_FOOD_VALUE;
    // A shared random number generator to control breeding.

    /**
     * Create a new rat at location in field with the listed parameters.
     * When a rat eats a plant, it is fully replenished. When it eats a blob, it is partially replenished in terms of hunger.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalType The type of animal being generated
     * @param breeding_age The age the animal needs to reach to breed
     * @param max_age The lifespan of the animal
     * @param breeding_probability The likelihood of the animal to breed once a suitable mate is in range.
     * @param max_litter_size The maximum litter size of the animal.
     * @param food_level The maximum food level an animal can have.
     */
    public Rat(Field field, Location location, int breeding_age, int max_age, double breeding_probability, int max_litter_size, int food_Level)
    {
        super(field, location, AnimalType.Rat, breeding_age, max_age, breeding_probability, max_litter_size, food_Level);
        PLANT_FOOD_VALUE = food_Level;
    }
    
    /**
     * This is what the Rat does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * Rats may be infected by disease, or existing disease may be cured.
     * @param newRats A list to return newly born Rats.
     */
    public void act(List<Animal> newRats)
    {
        
        if (Simulator.instance.isDay) {
            incrementAge();
            incrementHunger();
        } //metabolism and aging during night are slowed enough to be negligible.
        
        if(isAlive()) {
            giveBirth(newRats); 
            spreadDisease();
            cureDisease();
            
            if (Simulator.instance.isDay == false){
                return;
            } //Rat is sleeping at night.
            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            } //move towards food if it is adjacent to Rat.
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Finds food for rats within 7 block radius.
     * @return Locations with suitable food for the rat.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.detectedLocations(getLocation(), 7);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Plant) {
                Plant plant = (Plant) food;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            } //ensures that rat only eats plants within suitable radius.
        }
        return null;
    }
    
    /**
     * Check whether or not this Rat is to give birth at this step.
     * New births will be made into free locations within 15 blocks.
     * @param newRats A list to return newly born Rats.
     */
    private void giveBirth(List<Animal> newRats)
    {
        // New Rats are born into adjacent locations.
        // Get a list of adjacent free locations.
        if (!isMateInNeighbourCell(7)){ // checks for suitable mates within 7 blocks.
            return;
        }
        Field field = getField();
        List<Location> free = field.getFreeDetectedLocations(getLocation(), 15); //spawns new Rat within a 15 block radius.
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rat young = new Rat(field, loc, DefultValues.instance.Breeding_Age("Rat"), DefultValues.instance.Max_Age("Rat"), DefultValues.instance.Breeding_Probability("Rat"), DefultValues.instance.Max_Litter("Rat"), DefultValues.instance.Food_Level("Rat"));
            newRats.add(young);
        }
    }
    
}
