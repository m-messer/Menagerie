
/**
 * Enumeration class AnimalType - Contains every single animal type.
 *
 * @version 2022.03.01 (1)
 */
public enum AnimalType
{
    Wolf, Rat, Deer, Tiger, GreyBlob
}
