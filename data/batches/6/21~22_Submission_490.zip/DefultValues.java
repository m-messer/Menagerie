
/**
 * The values used when calling the constructors of each animal are stored in this class.
 * This class also contains the disease parameters and the food level gains from eating certain animals.
 *
 * @version 2022.03.01 (1)
 */
public class DefultValues
{
    
    public static DefultValues instance;
    
    /**
     * This constructor enables you to call the DefultValues class as an object.
     */
    public DefultValues()
    {
        instance = this;
    }
    
    /**
     * Returns breeding ages for corresponding animals.
     * @param animal Animal whose breeding age you would like.
     * @return Breeding age for the animal.
     */
    public int Breeding_Age(String animal){
        animal = animal.toUpperCase();
        switch(animal){
            case "WOLF":
                return 12; 
            case "RAT":
                return 7; 
            case "GREYBLOB":
                return 1; 
            case "TIGER":
                return 12; 
            case "DEER":
                return 7; 
        }
        return -1;
    }
    
    /**
     * Returns maximum ages/lifespans for corresponding animals.
     * @param animal Animal whose maximum ages/lifespan you would like.
     * @return Maximum age for the animal.
     */
    public int Max_Age(String animal){
        animal = animal.toUpperCase();
        switch(animal){
            case "WOLF":
                return 90;
            case "RAT":
                return 60;
            case "GREYBLOB":
                return 48; 
            case "TIGER":
                return 90; 
            case "DEER":
                return 60; 
        }
        return -1;
    }
    
    /**
     * Returns breeding probabilities for corresponding animals.
     * @param animal Animal whose breeding probability you would like.
     * @return Breeding probability for the animal.
     */
    public double Breeding_Probability(String animal){
        animal = animal.toUpperCase();
        switch(animal){
            case "WOLF":
                return 0.11; 
            case "RAT":
                return 0.49;
            case "GREYBLOB":
                return 0.017; 
            case "TIGER":
                return 0.11; 
            case "DEER":
                return 0.49; 
        }
        return -1;
    }
    
    /**
     * Returns the maximum litter size for corresponding animals.
     * @param animal Animal whose maximum litter size you would like.
     * @return Maximum litter size for the animal.
     */
    public int Max_Litter(String animal){
        animal = animal.toUpperCase();
        switch(animal){
            case "WOLF":
                return 2;
            case "RAT":
                return 3;
            case "GREYBLOB":
                return 3;
            case "TIGER":
                return 2; 
            case "DEER":
                return 3; 
        }
        return -1;
    }
    
    /**
     * Returns the maximum hunger/food level for corresponding animals.
     * @param animal Animal whose maximum hunger/food level you would like.
     * @return Maximum hunger/food level for the animal.
     */
    public int Food_Level(String animal){
        animal = animal.toUpperCase();
        switch(animal){
            case "WOLF":
                return 9;
            case "RAT":
                return 6;
            case "GREYBLOB":
                return 1;
            case "TIGER":
                return 9; 
            case "DEER":
                return 6; 
        }
        return -1;
    }
    
    /**
     * Returns the probability of an animal being born with a disease.
     * @return The disease mutation probability.
     */
    public double DiseaseMutationProbability(){
        return 0.07;
    }
    
    /**
     * Returns the probability of an animal being cured for each step they survive.
     * @return The disease cure probability.
     */
    public double DiseaseCureProbability(){
        return 0.25;
    }
    
    /**
     * Returns the probability of an animal spreading the disease for each step they survive.
     * @return The disease spread probability.
     */
    public double DiseaseSpreadProbability(){
        return 0.25;
    }
    
    /**
     * Returns the food value gained from eating a rat.
     * @return The rat's food value.
     */
    public int Rat_Food_Value(){
        return 9;
    }
    
    /**
     * Returns the food value gained from eating an extraterrestrial grey blob.
     * @return The grey blob's food value.
     */
    public int GreyBlob_Food_Value(){
        return 7;
    }
    
    /**
     * Returns the food value gained from eating a deer.
     * @return The deer's food value.
     */
    public int Deer_Food_Value(){
        return 9;
    }
    
    
}
