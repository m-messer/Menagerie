import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Deer.
 * Deers age, move, breed, and die.
 *
 * @version 2022.03.01 (1)
 */
public class Deer extends Animal
{
    // Characteristics shared by all Deers (class variables).
    private static int PLANT_FOOD_VALUE;

    /**
     * Create a new deer at location in field with the listed parameters.
     * When a deer eats a plant, it is fully replenished. When it eats a blob, it is partially replenished in terms of hunger.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalType The type of animal being generated
     * @param breeding_age The age the animal needs to reach to breed
     * @param max_age The lifespan of the animal
     * @param breeding_probability The likelihood of the animal to breed once a suitable mate is in range.
     * @param max_litter_size The maximum litter size of the animal.
     * @param food_level The maximum food level an animal can have.
     */
    public Deer(Field field, Location location, int breeding_age, int max_age, double breeding_probability, int max_litter_size, int food_Level)
    {
        super(field, location, AnimalType.Deer, breeding_age, max_age, breeding_probability, max_litter_size, food_Level);
        PLANT_FOOD_VALUE = food_Level; //deer food level goes to max when it eats a plant.
    }
    
    /**
     * This is what the Deer does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * Deer may be infected by disease, or existing disease may be cured.
     * @param newDeers A list to return newly born Deers.
     */
    public void act(List<Animal> newDeers)
    {
        
        if (Simulator.instance.isDay) {
            incrementAge();
            incrementHunger();
        } //metabolism and aging during night are slowed enough to be negligible.
        
        if(isAlive()) {
            giveBirth(newDeers); 
            spreadDisease();
            cureDisease();
            
            if (Simulator.instance.isDay == false){
                return;
            } //deer is sleeping at night.
            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            } //move towards food if it is adjacent to deer.
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Finds food for deer within 7 block radius.
     * @return Locations with suitable food for the deer.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.detectedLocations(getLocation(), 7);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Plant) {
                Plant plant = (Plant) food;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            } //ensures that deer only eats plants within suitable radius.
        }
        return null;
    }
    
    /**
     * Check whether or not this Deer is to give birth at this step.
     * New births will be made into free locations within 15 blocks.
     * @param newDeers A list to return newly born Deers.
     */
    private void giveBirth(List<Animal> newDeers)
    {
        // New Deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        if (!isMateInNeighbourCell(7)){ // checks for suitable mates within 7 blocks.
            return;
        }
        Field field = getField();
        List<Location> free = field.getFreeDetectedLocations(getLocation(), 15); //spawns new deer within a 15 block radius.
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(field, loc, DefultValues.instance.Breeding_Age("Deer"), DefultValues.instance.Max_Age("Deer"), DefultValues.instance.Breeding_Probability("Deer"), DefultValues.instance.Max_Litter("Deer"), DefultValues.instance.Food_Level("Deer"));
            newDeers.add(young);
        }
    }
}
