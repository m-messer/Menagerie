import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Rats, Wolves, Tiger, Deer, Extraterrestrial Grey blobs and Plants.
 *
 * @version 2022.03.01 (1)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    // The probability that the given animal/plant will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.02; 
    private static final double RAT_CREATION_PROBABILITY = 0.08; 
    private static final double GREYBLOB_CREATION_PROBABILITY = 0.08; 
    private static final double PLANT_CREATION_PROBABILITY = 0.18;
    private static final double TIGER_CREATION_PROBABILITY = 0.025; 
    private static final double DEER_CREATION_PROBABILITY = 0.10; 
    
    private static final double PLANT_RATE_PRODUCTION = 75; //Rate at which plants grow in simulation.
    private static final double BLOB_RATE_PRODUCTION = 4; //Rate at which blobs grow in simulation.
    
    
    private static final double RainProbability = 0.4; //Probability of a step containing rain.
    private static double PlantMultiplier = 1; //Multiplier for plant rate production at a given step.
    
    public static Simulator instance;
    
    public static int NumberOfInfectedAnimals = 0;


    public boolean isDay = true;
    private boolean isRaining;
    // List of animals in the field.
    private List<Animal> animals;
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    private DefultValues defult;
    
    private final Random rand = Randomizer.getRandom();
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        instance = this;
        defult = new DefultValues();
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    private Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        
        defult = new DefultValues();//

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        // Add animals to the simulator and set their representative color.
        view.setColor(Rat.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(GreyBlob.class, Color.RED);
        view.setColor(Tiger.class, Color.BLACK);
        view.setColor(Deer.class, Color.MAGENTA);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for two steps to simulate one day/night cycle.
     * (2 steps).
     */
    public void simulateTwoSteps()
    {
        simulate(2);
    }
    
    /**
     * Run the simulation from its current state for a reasonably short period slowly,
     * (200 steps, 200 ms lag).
     */
    public void simulate200()
    {
        simulateSlow(200, 200);
    }
    
    /**
     * Run the simulation from its current state for a reasonably short period.
     * (200 steps).
     */
    public void simulateFast200()
    {
        simulate(200);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
        }
    }
    
    /**
     * Adds a delay after simulating each step. Helps track simulation more clearly.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     * @param lag The number of milliseconds of delay each step receives.
     */
    public void simulateSlow(int numSteps, int lag)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(lag);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each species present.
     * Updates time of day and weather.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        growPlants(); //maintains plant growth rate
        if (isDay)
        {
            addBlobs(); //grows blobs during daytime.
        }
        DayNightCycle(); //alternates between day and night.
        WeatherCycle(); //updates whether or not it's raining.

        view.showStatus(step, NumberOfInfectedAnimals, field); //updates visible simulator status.
    }
    
    /**
     * Alternates between day and night for each step.
     */
    protected void DayNightCycle(){
        if (step % 2 == 0){
            isDay = true;
        } else{
            isDay = false;
        }
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        NumberOfInfectedAnimals = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, NumberOfInfectedAnimals, field);
    }
    
    /**
     * Randomly populate the field with initial animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(field, location, DefultValues.instance.Breeding_Age("Wolf"), DefultValues.instance.Max_Age("Wolf"), DefultValues.instance.Breeding_Probability("Wolf"), DefultValues.instance.Max_Litter("Wolf"), DefultValues.instance.Food_Level("Wolf"));
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(field, location, DefultValues.instance.Breeding_Age("Rat"), DefultValues.instance.Max_Age("Rat"), DefultValues.instance.Breeding_Probability("Rat"), DefultValues.instance.Max_Litter("Rat"), DefultValues.instance.Food_Level("Rat"));
                    animals.add(rat);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    plants.add(plant);
                }
                else if(rand.nextDouble() <= GREYBLOB_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    GreyBlob greyBlob = new GreyBlob(field, location, DefultValues.instance.Breeding_Age("GreyBlob"), DefultValues.instance.Max_Age("GreyBlob"), DefultValues.instance.Breeding_Probability("GreyBlob"), DefultValues.instance.Max_Litter("GreyBlob"), DefultValues.instance.Food_Level("GreyBlob"));
                    animals.add(greyBlob);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(field, location, DefultValues.instance.Breeding_Age("Tiger"), DefultValues.instance.Max_Age("Tiger"), DefultValues.instance.Breeding_Probability("Tiger"), DefultValues.instance.Max_Litter("Tiger"), DefultValues.instance.Food_Level("Tiger"));
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer= new Deer(field, location, DefultValues.instance.Breeding_Age("Deer"), DefultValues.instance.Max_Age("Deer"), DefultValues.instance.Breeding_Probability("Deer"), DefultValues.instance.Max_Litter("Deer"), DefultValues.instance.Food_Level("Deer"));
                    animals.add(deer);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Randomly populate the field with plants to simulate plant growth rate.
     */
    private void growPlants(){
        int NumberOfPlantsToGrow = (int) (PLANT_RATE_PRODUCTION * PlantMultiplier); //changes plant growth rate based on weather.
        for (int x = 0; x < NumberOfPlantsToGrow; x++){
            int randomRow = rand.nextInt(DEFAULT_DEPTH); 
            int randomColumn = rand.nextInt(DEFAULT_WIDTH);
            Location location = new Location(randomRow,randomColumn);
            //determines area within which plants may be generated.
            int loopCount = 0;
            while(field.getObjectAt(location) != null && loopCount < 20){ 
                randomRow = rand.nextInt(DEFAULT_DEPTH);
                randomColumn = rand.nextInt(DEFAULT_WIDTH);
                location = new Location(randomRow,randomColumn);
                loopCount++;
            } //No plant generated if all 20 randomly generated locations for it aren't empty.
            if (field.getObjectAt(location) == null)
            {
                Plant plant = new Plant(field, location);
                plants.add(plant);
            } //if it finds an empty location, plant is generated there, and is added to list of plants.
            
        }
    }
    
    /**
     * Randomly populate the field with blobs to simulate blob growth rate.
     */
    private void addBlobs(){
        for (int x = 0; x < BLOB_RATE_PRODUCTION; x++){
            int randomRow = rand.nextInt(DEFAULT_DEPTH);
            int randomColumn = rand.nextInt(DEFAULT_WIDTH);
            Location location = new Location(randomRow,randomColumn);
            //determines area within which plants may be generated.
            int loopCount = 0;
            while(field.getObjectAt(location) != null && loopCount < 15){
                randomRow = rand.nextInt(DEFAULT_DEPTH);
                randomColumn = rand.nextInt(DEFAULT_WIDTH);
                location = new Location(randomRow,randomColumn);
                loopCount++;
            } //No blob generated if all 15 randomly generated locations for it aren't empty.
            if (field.getObjectAt(location) == null)
            {
                GreyBlob greyblob = new GreyBlob(field, location, DefultValues.instance.Breeding_Age("GreyBlob"), DefultValues.instance.Max_Age("GreyBlob"), DefultValues.instance.Breeding_Probability("GreyBlob"), DefultValues.instance.Max_Litter("GreyBlob"), DefultValues.instance.Food_Level("GreyBlob"));
                animals.add(greyblob);
            }//if it finds an empty location, blob is generated there, and is added to list of animals.
            
            
        }
    }
    
    /**
     * Updates whether or not it's raining with each step.
     * If it's raining, it changes the PlantMultiplier from 1 to 1.1 and vice versa.
     */
    private void WeatherCycle(){
        if(rand.nextDouble() <= RainProbability){
            isRaining = true;
            PlantMultiplier = 1.1;
        } else{
            isRaining = false;
            PlantMultiplier = 1;
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
