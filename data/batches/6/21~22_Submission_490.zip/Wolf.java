import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Wolf.
 * Wolves age, move, eat rabbits, and die.
 *
 * @version 2022.03.01 (1)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all Wolves (class variables).
    
    // number of steps a Wolf can go before it has to eat again.
    private static int RAT_FOOD_VALUE;
    //amount of hunger replenished when wolf eats grey blob.
    private static int GREYBLOB_FOOD_VALUE;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The Wolf's food level, which is increased by eating rabbits

    /**
     * Create a Wolf. A Wolf can be created as a new born (age zero
     * and not hungry).
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalType The type of animal being generated
     * @param breeding_age The age the animal needs to reach to breed
     * @param max_age The lifespan of the animal
     * @param breeding_probability The likelihood of the animal to breed once a suitable mate is in range.
     * @param max_litter_size The maximum litter size of the animal.
     * @param food_level The maximum food level an animal can have..
     */
    public Wolf(Field field, Location location, int breeding_age, int max_age, double breeding_probability, int max_litter_size, int food_Level)
    {
        super(field, location, AnimalType.Wolf, breeding_age, max_age, breeding_probability, max_litter_size, food_Level);
        RAT_FOOD_VALUE = DefultValues.instance.Rat_Food_Value();
        GREYBLOB_FOOD_VALUE = DefultValues.instance.GreyBlob_Food_Value();
    }
    
    /**
     * This is what the Wolf does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * Wolves may be infected by disease, or existing disease may be cured.
     * @param newWolves A list to return newly born Wolves.
     */
    public void act(List<Animal> newWolves)
    {
        if (Simulator.instance.isDay) {
            incrementAge();
            incrementHunger();
        } //metabolism and aging during night are slowed enough to be negligible.
        
        if(isAlive()) {
            giveBirth(newWolves); 
            spreadDisease();
            cureDisease();
            
            if (Simulator.instance.isDay == false){
                return;
            } //deer is sleeping at night.
            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            } //move towards food if it is adjacent to deer.
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Look for rats and blobs adjacent to the current location.
     * A rat fully replenished the tiger's hunger, while a blob partially replenishes it.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.detectedLocations(getLocation(),1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.isAlive()) { 
                    rat.setDead();
                    foodLevel = RAT_FOOD_VALUE;
                    return where;
                } //verifies if animal is a rat, and if so, fully replenished hunger.
            } else if (animal instanceof GreyBlob){
                GreyBlob greyBlob = (GreyBlob) animal;
                if(greyBlob.isAlive()) { 
                    greyBlob.setDead();
                    if (foodLevel + GREYBLOB_FOOD_VALUE > RAT_FOOD_VALUE){
                        foodLevel = RAT_FOOD_VALUE;
                    } else{
                        foodLevel += GREYBLOB_FOOD_VALUE;
                    } //ensures food level never exceeds max food value
                    return where;
                } //verifies if animal is a blob, and if so, partially replenishes hunger.
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Wolf is to give birth at this step.
     * New births will be made into free adjacent locations within 8 blocks.
     * @param newWolves A list to return newly born Wolves.
     */
    private void giveBirth(List<Animal> newWolfs)
    {
        // New Wolves are born into adjacent locations.
        // Get a list of adjacent free locations in 5 block radius.
        if (!isMateInNeighbourCell(5)){
            return;
        } // searches for suitable mate within 5 block radius.
        Field field = getField();
        List<Location> free = field.getFreeDetectedLocations(getLocation(), 8); //spawns new tigers within 8 block radius.
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(field, loc, DefultValues.instance.Breeding_Age("Wolf"), DefultValues.instance.Max_Age("Wolf"), DefultValues.instance.Breeding_Probability("Wolf"), DefultValues.instance.Max_Litter("Wolf"), DefultValues.instance.Food_Level("Wolf"));
            newWolfs.add(young);
        }
    }
}
