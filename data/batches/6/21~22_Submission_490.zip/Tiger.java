import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Tiger.
 * Tigeres age, move, eat rabbits, and die.
 *
 * @version 2022.03.01 (1)
 */
public class Tiger extends Animal
{
    // Characteristics shared by all Tigeres (class variables).
    
    
    private static int DEER_FOOD_VALUE; // number of steps a Tiger can go before it has to eat again
    private static int GREYBLOB_FOOD_VALUE; //hunger replenished by eating grey blob.

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    

    /**
     * Create a Tiger. A Tiger can be created as a new born (age zero
     * and not hungry).
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalType The type of animal being generated
     * @param breeding_age The age the animal needs to reach to breed
     * @param max_age The lifespan of the animal
     * @param breeding_probability The likelihood of the animal to breed once a suitable mate is in range.
     * @param max_litter_size The maximum litter size of the animal.
     * @param food_level The maximum food level an animal can have..
     */
    public Tiger(Field field, Location location, int breeding_age, int max_age, double breeding_probability, int max_litter_size, int food_Level)
    {
        super(field, location, AnimalType.Tiger, breeding_age, max_age, breeding_probability, max_litter_size, food_Level);
        DEER_FOOD_VALUE = DefultValues.instance.Rat_Food_Value();
        GREYBLOB_FOOD_VALUE = DefultValues.instance.GreyBlob_Food_Value();
        //WOLF_FOOD_VALUE = DefultValues.instance.Wolf_Food_Value();
    }
    
    /**
     * This is what the Tiger does most of the time: it hunts for
     * deer and grey blobs. In the process, it might breed, die of hunger,
     * or die of old age.
     * Tigers may be infected by disease, or existing disease may be cured.
     * @param newTigeres A list to return newly born Tigers.
     */
    public void act(List<Animal> newTigers)
    {
        
        if (Simulator.instance.isDay) {
            incrementAge();
            incrementHunger();
        } //metabolism and aging during night are slowed enough to be negligible.
        
        if(isAlive()) {
            giveBirth(newTigers); 
            spreadDisease();
            cureDisease();
            
            if (Simulator.instance.isDay == false){
                return;
            } //deer is sleeping at night.
            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            } //move towards food if it is adjacent to deer.
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Look for deer and blobs adjacent to the current location.
     * A deer fully replenished the tiger's hunger, while a blob partially replenishes it.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.detectedLocations(getLocation(),1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel = DEER_FOOD_VALUE;
                    return where;
                } //verifies if animal is deer, and if so, fully replenished hunger.
            } else if (animal instanceof GreyBlob){
                GreyBlob greyBlob = (GreyBlob) animal;
                if(greyBlob.isAlive()) { 
                    greyBlob.setDead();
                    if (foodLevel + GREYBLOB_FOOD_VALUE > DEER_FOOD_VALUE){
                        foodLevel = DEER_FOOD_VALUE;
                    } else{
                        foodLevel += GREYBLOB_FOOD_VALUE;
                    } //ensures food level never exceeds max food value
                    return where;
                } //verifies if animal is a blob, and if so, partially replenishes hunger.
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Tiger is to give birth at this step.
     * New births will be made into locations in an 8 block radius.
     * @param newTigers A list to return newly born Tigeres.
     */
    private void giveBirth(List<Animal> newTigers)
    {
        // New Tigers are born into locations in 8 block radius locations.
        // Get a list of adjacent free locations in 5 block radius.
        if (!isMateInNeighbourCell(5)){ 
            return;
        } // searches for suitable mate within 5 block radius.
        Field field = getField();
        List<Location> free = field.getFreeDetectedLocations(getLocation(), 8); //spawns new tigers within 8 block radius.
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tiger young = new Tiger(field, loc, DefultValues.instance.Breeding_Age("Tiger"), DefultValues.instance.Max_Age("Tiger"), DefultValues.instance.Breeding_Probability("Tiger"), DefultValues.instance.Max_Litter("Tiger"), DefultValues.instance.Food_Level("Tiger"));
            newTigers.add(young);
        } 
    }
}
