import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a GreyBlob.
 * GreyBlobs age, move, breed, and die.
 *
 * @version 2022.03.01 (1)
 */
public class GreyBlob extends Animal
{
    // A shared random number geneGreyBlobor to control breeding.

    /**
     * Create a new grey blob at location in field with the listed parameters.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalType The type of animal being generated
     * @param breeding_age The age the animal needs to reach to breed
     * @param max_age The lifespan of the animal
     * @param breeding_probability The likelihood of the animal to breed once a suitable mate is in range.
     * @param max_litter_size The maximum litter size of the animal.
     * @param food_level The maximum food level an animal can have.
     */
    public GreyBlob(Field field, Location location, int breeding_age, int max_age, double breeding_probability, int max_litter_size, int food_Level)
    {
        super(field, location, AnimalType.GreyBlob, breeding_age, max_age, breeding_probability, max_litter_size, food_Level);
    }
    
    /**
     * This is what the extraterrestrial GreyBlob does most of the time - it runs 
     * around. Sometimes it will get eaten or die of old age.
     * 
     * It has no need for eating or sexual reproduction.
     * @param newGreyBlobs A list to return newly born GreyBlobs.
     */
    public void act(List<Animal> newGreyBlobs)
    {
        
        if (Simulator.instance.isDay) { // ages during daytime
            incrementAge();
        }
        if(isAlive()) {
            spreadDisease();
            cureDisease();
            // Try to move into a free location.
            if (Simulator.instance.isDay == false){ // only moves at day, sleeps at night
                return;
            }
            
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
  
    
}
