import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.lang.reflect.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.03.01 (1)
 */

public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    protected Location location;
    // Whether or not the animal is infected.
    private boolean isInfected;
    // The animal's current age.
    private int age;
    // The animal's gender.
    protected boolean gender; // true = male, false = female
    
    private AnimalType animalType;
    
    // The age at which an animal can start to breed.
    private int BREEDING_AGE;
    // The age to which an animal can live.
    private int MAX_AGE;
    // The likelihood of an animal breeding.
    private double BREEDING_PROBABILITY;
    // The maximum number of births.
    private int MAX_LITTER_SIZE;
    
    public int foodLevel;
    
    public double DiseaseMutationProbability;
    public double DiseaseCureProbability;
    public double DiseaseSpreadProbability;
    

    // A shared random number generator to control breeding.
    private final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field with the listed parameters.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalType The type of animal being generated
     * @param breeding_age The age the animal needs to reach to breed
     * @param max_age The lifespan of the animal
     * @param breeding_probability The likelihood of the animal to breed once a suitable mate is in range.
     * @param max_litter_size The maximum litter size of the animal.
     * @param food_level The maximum food level an animal can have.
     */
    public Animal(Field field, Location location, AnimalType animalType, int breeding_age, int max_age, double breeding_probability, int max_litter_size, int food_Level)
    {
        alive = true; //animal is alive.
        
        //sets up animal characteristics
        this.field = field;
        this.age = 0;
        this.animalType = animalType;
        setLocation(location);
        BREEDING_AGE = breeding_age;
        MAX_AGE = max_age;
        BREEDING_PROBABILITY = breeding_probability;
        MAX_LITTER_SIZE = max_litter_size;
        foodLevel = food_Level;
        
        //initialises disease parameters
        DiseaseMutationProbability = DefultValues.instance.DiseaseMutationProbability();
        DiseaseCureProbability = DefultValues.instance.DiseaseCureProbability();
        DiseaseSpreadProbability = DefultValues.instance.DiseaseSpreadProbability();
        
        setGender(); //randomly assigns gender to animal.
        diseaseMutation(); //determines whether or not animal is born with the disease.
    }
    
    /**
     * Randomly determines gender of animal.
     */
    private void setGender(){
        int x = rand.nextInt(2);
        if (x == 0){
            gender = true;
        } else{
            gender = false;
        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     * Disease can no longer infect/affect animal once it's dead.
     */
    protected void setDead()
    {
        alive = false;
        if (isInfected){
            setIsInfected(false);  
        }
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Randomly decides, using the disease mutation probability, whether or not the animal is born with the disease.
     */
    private void diseaseMutation(){
        if (rand.nextDouble() <= DiseaseMutationProbability){
            isInfected = true;
            Simulator.instance.NumberOfInfectedAnimals += 1;
        }
    }
    
    /**
     * Randomly decides whether the animal spreads the disease, based on the disease spread probability.
     */
    protected void spreadDisease(){
        if (!isInfected || rand.nextDouble() > DiseaseSpreadProbability){
            return;
        } //disease doesn't spread if RNG is below probability or the animal isn't infected.
        
        Field field = getField();
        List<Location> adjacent = field.detectedLocations(getLocation(),2); //disease spreads in a 2 block radius.
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if ( object instanceof Animal){ 
                Animal animal = (Animal) object;
                if (!animal.getIsInfected()){
                    animal.setIsInfected(true);
                }
            } //disease can only spread between animals.
        }
    }
    
    /**
     * Randomly determines whether the animal's disease is cured, based on the disease cure probability.
     */
    protected void cureDisease(){
        if (!isInfected || rand.nextDouble() > DiseaseCureProbability){
            return; //method will not toggle if the animal doesn't have the disease or if RNG is below probability.
        } else{
            setIsInfected(false);
        }
    }
    
    /**
     * Abstract method which determines how an animal will act.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Sets animal's infection status, and increments infection counter accordingly.
     * Adds to the counter if you infect the animal, subtracts if you disinfect it.
     * @param infected The animal's infection status you want to set.
     */
    protected void setIsInfected(boolean infected){
        isInfected = infected;
        if(infected){
            Simulator.instance.NumberOfInfectedAnimals += 1;   
        } else{
            Simulator.instance.NumberOfInfectedAnimals -= 1;
        } //infection counter is infected every time an animal is determined as infected or cured.
    }
    
    protected boolean getIsInfected(){
        return isInfected;
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @return Whether or not it's above the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Returns the gender of the animal.
     * @return The animal's gender.
     */
    protected boolean getGender(){
        return gender;
    }
    
    /**
     * Returns the the presence of suitable mates within the given radius.
     * @param radius The radius which is scanned for mates.
     * @return Whether or not suitable mates exist in the radius.
     */
    protected boolean isMateInNeighbourCell(int radius){
        Field field = getField();
        List<Location> neighbours = field.detectedLocations(location, radius);
        for (int x = 0; x < neighbours.size(); x++){
            Object neighbour = field.getObjectAt(neighbours.get(x));
            if (animalType == AnimalType.Wolf && neighbour instanceof Wolf && ((Wolf) neighbour).getGender() != gender){
                return true;
                
            }
            else if (animalType == AnimalType.Rat && neighbour instanceof Rat && ((Rat) neighbour).getGender() != gender){
                return true;
                
            }
            else if (animalType == AnimalType.Deer && neighbour instanceof Deer && ((Deer) neighbour).getGender() != gender){
                return true;
                
            }
            else if (animalType == AnimalType.Tiger && neighbour instanceof Tiger && ((Tiger) neighbour).getGender() != gender){
                return true;
                
            } //checks all species within the radius if they are the same species and opposite gender.
        }
        return false;
    }
}
