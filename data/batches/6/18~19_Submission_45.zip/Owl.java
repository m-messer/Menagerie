import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * An Owl is a Predator. It ages and gets hungry each step. It is nocturnal,
 * and so only moves, eats Mice, and gives birth during the night. Its
 * behavior is affected by fog. An Owl can die from old age, hunger, disease,
 * or if it struck by lightning during a thunderstorm. An Owl can mate with
 * adjacent Owls, if they are of the opposite sex.
 *
 * @version 2019.02.20
 */
public class Owl extends Predator
{
    // The age to which an owl can live.
    private static final int MAX_AGE = 800;
    // The age at which an owl can start to breed.
    private static final int BREEDING_AGE = 60;
    // The likelihood of an owl breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The maximum food level of an owl. In effect, this is the
    // number of steps an owl can go before it has to eat again
    private static final int MAX_FOOD_LEVEL = 60;
    // The food value of a single mouse.
    private static final int MOUSE_FOOD_VALUE = 30;
    // The probability that the owl will be able to find food in the fog.
    private static final double FOG_VISIBILITY = 0.80;

    /**
     * Create an owl. An owl can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the owl will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Owl(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Get the owl's maximum food level.
     * @return the owl's maximum food level.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Get the owl's breeding age.
     * @return the owl's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the owl's maximum age.
     * @return the owl's maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Get the owl's maximum litter size.
     * @return the owl's maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Get the owl's breeding probability.
     * @return the owl's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Check whether there is a compatible mate in an adjacent location.
     * @return True if the adjacent owl is of the oppposite gender and
     * can breed, and False otherwise.
     */
    public boolean adjCompatibleMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location location = it.next();
            Object animal = field.getObjectAt(location);
            if(animal instanceof Owl){
                Owl owl = (Owl) animal;
                if(owl.isFemale() != isFemale() && owl.canBreed()){
                    return true;
                }
            }            
        }
        return false;
    }

    /**
     * This is what the owl does most of the time: it searches for
     * mice. In the process, it might breed, die of hunger, die of old age, 
     * die from disease or die by lightning strike.
     * @param newOwls A list to return newly born owls.
     * @param isNight A boolean to check if it is currently night in the simulation.
     * @param weather A string that states the current weather in the simulation.
     */
    public void act(List<Animal> newOwls, boolean isNight, String weather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(weather.equals("thunderstorm")){
                if(rand.nextDouble()<= LIGHTNING_DEATH){
                    setDead();  // Kill the owl if it is struck by lightning.
                }
                else{
                    defaultAct(newOwls, isNight, false);
                }
            }
            else if(weather.equals("fog")) {
                defaultAct(newOwls, isNight, true);
            }
            else{
                defaultAct(newOwls, isNight, false);
            }
        }
    }

    /**
     * This is the default action of the Owl if it is night.
     * It may give birth, and move according to whether or not it
     * can find food, which is affected by foggy conditions.
     * @param newOwls A list to return newly born owls.
     * @param isNight Whether or not it is night.
     * @param isFoggy Whether or not it is foggy.
     */
    private void defaultAct(List<Animal> newOwls, boolean isNight, boolean isFoggy)
    {
        if(isNight){   // The owl sleeps during the day.
            giveBirth(newOwls);            

            // Move towards a source of food if found.
            // If it's foggy the owl will have a lower probability of finding food.
            Location newLocation;
            if(isFoggy){
                newLocation = fogFindFood();
            }
            else{
                newLocation = findFood();
            }
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for mice adjacent to the current location.
     * Only the first live mouse is eaten. The food value of 
     * the mouse is added onto the owl's food level (but
     * the owl's food level does not go over its maximum food
     * level). If the eaten mouse is infected, the owl dies.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Mouse){
                Mouse mouse = (Mouse) organism;
                if(mouse.isAlive()){
                    // If the mouse is infected the owl will die.
                    if (mouse.isInfected()) {
                        setDead();
                    }
                    else {
                        // Increase the owl's food level by the food value of a mouse.
                        setFoodLevel(getFoodLevel() + MOUSE_FOOD_VALUE);
                        // Ensure that the food level does not go over the maximum.
                        if(getFoodLevel() > MAX_FOOD_LEVEL){
                            setFoodLevel(MAX_FOOD_LEVEL);
                        }
                    }
                    mouse.setDead();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Make it harder for the owl to find food in foggy 
     * weather.
     * @return Where food was found, or null if it wasn't.
     */
    private Location fogFindFood()
    {        
        if(rand.nextDouble() < FOG_VISIBILITY){
            return null;
        }
        else{
            return findFood();
        }
    }

    /**
     * Create a newborn owl.
     * @param field The field of the new owl.
     * @param loc The location in the field of the new owl.
     * @return The new owl.
     */
    public Owl createYoung(Field field, Location loc)
    {
        Owl young = new Owl(false, field, loc);
        return young;
    }

}
