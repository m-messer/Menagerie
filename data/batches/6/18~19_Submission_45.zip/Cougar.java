import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A Cougar is a Predator. It ages and gets hungry each step. It moves, eats
 * Deer, and gives birth only during the day. Its behavior is affected 
 * by fog. A Cougar can die from old age, hunger, disease, or if it struck 
 * by lightning during a thunderstorm. A Cougar can mate with
 * adjacent Cougars, if they are of the opposite sex.
 *
 * @version 2019.02.20
 */
public class Cougar extends Predator
{
    // The age to which a cougar can live.
    private static final int MAX_AGE = 1350;
    // The age at which a cougar can start to breed.
    private static final int BREEDING_AGE = 225;
    // The likelihood of a cougar breeding.
    private static final double BREEDING_PROBABILITY = 0.41;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The maximum food level of a cougar. In effect, this is the
    // number of steps a cougar can go before it has to eat again
    private static final int MAX_FOOD_LEVEL = 75;
    // The food value of a single deer.
    private static final int DEER_FOOD_VALUE = 45;
    // The probability that the bear will be able to find food in the fog.
    private static final double FOG_VISIBILITY = 0.60;

    /**
     * Create a cougar. A cougar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cougar will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cougar(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Get the cougar's maximum food level.
     * @return the cougar's maximum food level.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Get the cougar's breeding age.
     * @return the cougar's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the cougar's maximum age.
     * @return the cougar's maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Get the cougar's maximum litter size.
     * @return the cougar's maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Get the cougar's breeding probability.
     * @return the cougar's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Check whether there is a compatible mate in an adjacent location.
     * @return True if the adjacent animal is a cougar of the oppposite gender and
     * can breed, and False otherwise.
     */
    public boolean adjCompatibleMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location location = it.next();
            Object animal = field.getObjectAt(location);
            if(animal instanceof Cougar){
                Cougar cougar = (Cougar) animal;
                if(cougar.isFemale() != isFemale() && cougar.canBreed()){
                    return true;
                }
            }            
        }
        return false;
    }

    /**
     * This is what the cougar does most of the time: it searches for
     * deer. In the process, it might breed, die of hunger, die of old age, 
     * die from disease, or die by lightning strike. 
     * @param newCougars A list to return newly born cougars.
     * @param isNight A boolean to check if it is currently night in the simulation.
     * @param weather A string that states the current weather in the simulation.
     */
    public void act(List<Animal> newCougars, boolean isNight, String weather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(weather.equals("thunderstorm")){
                if(rand.nextDouble()<= LIGHTNING_DEATH){
                    setDead();  // Kill the cougar if it is struck by lightning.
                }
                else{
                    defaultAct(newCougars, isNight, false);
                }
            }
            else if(weather.equals("fog")) {
                defaultAct(newCougars, isNight, true);
            }
            else{
                defaultAct(newCougars, isNight, false);
            }
        }
    }

    /**
     * This is the default action of the Cougar if it is not night.
     * It may give birth, and move according to whether or not it
     * can find food, which is affected by foggy conditions.
     * @param newCougars A list to return newly born cougars.
     * @param isNight Whether or not it is night.
     * @param isFoggy Whether or not it is foggy.
     */
    private void defaultAct(List<Animal> newCougars, boolean isNight, boolean isFoggy)
    {
        if(!isNight){   // The cougar sleeps during the night.
            giveBirth(newCougars); 

            // Move towards a source of food if found.
            // If it's foggy the cougar will have a lower probability of finding food.
            Location newLocation;
            if(isFoggy){
                newLocation = fogFindFood();
            }
            else{
                newLocation = findFood();
            }
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for deer adjacent to the current location.
     * Only the first live deer is eaten. The food value of 
     * the deer is added onto the cougar's food level (but
     * the cougar's food level does not go over its maximum food
     * level). If the eaten deer is infected, the cougar dies.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Deer){
                Deer deer = (Deer) organism;
                if(deer.isAlive()){
                    // If the deer is infected by disease the cougar will die.
                    if (deer.isInfected()) {
                        setDead();
                    }
                    // Increase the cougar's food level by the food value of deer.
                    setFoodLevel(getFoodLevel() + DEER_FOOD_VALUE);
                    // Ensure that the food level does not go over the maximum.
                    if(getFoodLevel() > MAX_FOOD_LEVEL){
                        setFoodLevel(MAX_FOOD_LEVEL);
                    }
                    deer.setDead();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Make it harder for the cougar to find food in foggy 
     * conditions.
     * @return Where food was found, or null if it wasn't.
     */
    private Location fogFindFood()
    {        
        if(rand.nextDouble() < FOG_VISIBILITY){
            return null;
        }
        else{
            return findFood();
        }
    }

    /**
     * Create a newborn cougar.
     * @param field The field of the new cougar.
     * @param loc The location in the field of the new cougar.
     * @return The new cougar.
     */
    public Cougar createYoung(Field field, Location loc)
    {
        Cougar young = new Cougar(false, field, loc);
        return young;
    }


}
