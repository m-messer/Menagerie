import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of predator animals.
 *
 * @version 2019.02.20
 */
public abstract class Predator extends Animal
{
    // A timer to keep track of day and night.
    private Timer timer;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Predator
     */
    public Predator(Field field, Location location, Timer timer)
    {
        super(field, location, timer);
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.perimeterLocations(getLocation(),
        -1, 1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if (actor instanceof Animal){
                Animal animal = (Animal) actor;
                if(getPreyClass().equals(animal.getClass().toString())){
                    animal.setDead();
                    setFoodLevel(animal.getFoodLevel());
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * @return The food value of the prey.
     */
    abstract protected int getFoodValue();
    
    /**
     * @return The class of the prey that the predator eats.
     */
    abstract protected String getPreyClass();
}
