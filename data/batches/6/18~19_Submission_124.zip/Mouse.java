import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a mouse.
 * Mice age, move, breed, eat, and die.
 *
 * @version 2019.02.20
 */
public class Mouse extends Prey
{
    // Characteristics shared by all mouses (class variables).

    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Probability of moving at night.
    private static final double MOVEMENT_PROBABILITY = 0.5;

    // Individual characteristics (instance fields).

    /**
     * Create a new mouse. A mouse may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the mouse will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mouse(boolean randomAge, Field field, Field plantField, Location location, Timer timer)
    {
        super(field, plantField, location, timer);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(getPlantFoodValue()));
        }
        else{
            setAge(0);
            setFoodLevel(getPlantFoodValue());
        }
    }

    /**
     * Create new mouse.
     * @param randomAge If true, the animal will have a random age, 
     * age 0 otherwise.
     * @param field The field.
     * @param location The location for the new animal.
     */
    protected Animal createAnimal(boolean randomAge, Field field, 
    Location location)
    {
        return new Mouse(randomAge, field, getPlantField(), location, 
        getTimer());
    }

    /**
     * @return The breeding age of mice.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return The maximum age of mice.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return The breeding probability of mice
     */
    protected double getBreedingProb()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return Maximum number of offspring from mice.
     */
    protected int getMaxLitterSz()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return Movement probability at night for mice.
     */
    protected double getMovementProbability()
    {
        return MOVEMENT_PROBABILITY;
    }
}
