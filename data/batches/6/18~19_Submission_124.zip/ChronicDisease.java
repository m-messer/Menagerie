import java.util.Random;
import java.util.Iterator;
import java.util.List;

/**
 * A model of a chronic disease.
 *
 * @version 2019.02.15
 */
public class ChronicDisease
{
    // The probability that the animal will be infected 
    private static final double INFECTION_PROBABILITY = 0.25;
    // The probabilty that the animal will spread the disease.
    private static final double SPREAD_PROBABILITY = 0.03;
    // Steps left before the animal dies.
    private int count;
    // A random number generator to control disease probability.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class ChronicDisease
     */
    public ChronicDisease()
    {
        count = 10;
    }

    public boolean randInfected()
    {
        if(rand.nextDouble() <= INFECTION_PROBABILITY){
            return true;
        }
        return false;
    }
    
    /**
     * Decrease the number of steps that the animals has left.
     */
    public void act()
    {
        count--;
    }
    
    /**
     * If the animal does not have any steps left, return true,
     * return false otherwise.
     */
    public boolean diseased()
    {
        if (count == 0){
            return true;
        }
        return false;
    }
    
    public double getSpreadProbability()
    {
        return SPREAD_PROBABILITY;
    }
}
