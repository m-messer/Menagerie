import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a tiger.
 * Tigers age, move, eat rabbits, and die.
 *
 * @version 2019.02.21
 */
public class Tiger extends Predator
{
    // Characteristics shared by all tigers (class variables).
    
    // The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a tiger can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.47;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a tiger can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 18;
    // Probability of moving at day.
    private static final double MOVEMENT_PROBABILITY = 0.15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The class of the prey that the tiger eats.
    private String preyClass = "class Deer";

    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location, Timer timer)
    {
        super(field, location, timer);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(DEER_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(DEER_FOOD_VALUE);
        }
    }
    
    /**
     * Create new tiger.
     * @param randomAge If true, the animal will have a random age, age 0 otherwise.
     * @param field The field.
     * @param location The location for the new animal.
     */
    protected Animal createAnimal(boolean randomAge, Field field, 
    Location location)
    {
        return new Tiger(randomAge, field, location, getTimer());
    }
    
    /**
     * Get breeding age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * return max age.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * return The breeding probability of this animal.
     */
    protected double getBreedingProb()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return Maximum number of offspring from this animal.
     */
    protected int getMaxLitterSz()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return The food value of a single deer. In effect, this is the 
     * number of steps a tiger can go before it has to eat again.
     */
    protected int getFoodValue()
    {
       return DEER_FOOD_VALUE;
    }
    
    /**
     * @return Probability of movement during night.
     */
    protected double getMovementProbability()
    {
        return MOVEMENT_PROBABILITY;
    }
    
    /**
     * @return The animal that the tiger eats.
     */
    protected String getPreyClass()
    {
       return preyClass;
    }
}
