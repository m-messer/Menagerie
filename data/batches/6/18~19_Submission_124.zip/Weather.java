import java.util.Random;
/**
 * A model of the weather containing information about it.
 *
 * @version 2019.02.20
 */
public class Weather
{
    // Average time between weather changes.
    private int weatherChangeTime;
    // Time for which the weather remains the same.
    private static final int STABLE_TIME = 50;
    // A counter to keep track of weather change
    private int counter;
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    // Moisture content in the air.
    private double humidity;
    // Temperature of the surroundings.
    private double temperature;
    //  Name of the weather type.
    private String name;
    

    /**
     * Constructor for objects of class Weather
     */
    public Weather(double humidity, double temperature, String name)
    {
        // initialise instance variables
        this.name = name;
        this.humidity = humidity;
        this.temperature = temperature;
        counter = 0;
    }

    /**
     * Determine whether the weather should be changed.
     * @return True if the weather should be changed, false otherwise.
     */
    public boolean changeWeather()
    {
        counter++;
        // Generate a random integer between 50 and 100
        int offset = 50;
        int weatherChangeTime = rand.nextInt(STABLE_TIME) + offset;
        return (counter % weatherChangeTime == 0);
    }

    /**
     * @return Humidity in the air.
     */
    public double getHumidity()
    {
        return humidity;
    }

    /**
     * @return Temperature of the surroundings.
     */
    public double getTemperature()
    {
        return temperature;
    }

    /**
     * @return Name of the weather.
     */
    public String getName()
    {
        return name;
    }
}
