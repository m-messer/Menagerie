import java.util.Random;
import java.awt.Color;
import java.util.List;

/**
 * Creates the population and defines colors for the animals.
 *
 * @version 2019.02.15
 */
public class PopulationGenerator
{
    // The probability that a tiger will be created in any given 
    //grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.07;
    // The probability that a deer will be created in any given 
    //grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.40;    
    // The probability that a mouse will be created in any given 
    //grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.2;   
    // The probability that a lion will be created in any given 
    //grid position.
    private static final double LION_CREATION_PROBABILITY = 0.07;
    // The probability that a snake will be created in any given 
    //grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.15;
    // The probability that a hunter will be created in any given 
    //grid position.
    private static final double HUNTER_CREATION_PROBABILITY = 0.003;

    /**
     * Constructor for the population generator.
     */
    public PopulationGenerator()
    {
    }

    /**
     * Randomly populate the field with the animals and populate the 
     * whole field with plants.
     */
    public void populate(Field field, List<Actor> actors, 
    Field plantField, Timer timer)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location, timer);
                    actors.add(tiger);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, plantField, 
                            location, timer);
                    actors.add(deer);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, plantField, 
                            location, timer);
                    actors.add(mouse);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location, timer);
                    actors.add(lion);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location, timer);
                    actors.add(snake);
                } 
                else if(rand.nextDouble() <= HUNTER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Hunter hunter = new Hunter(field, location);
                    actors.add(hunter);
                }
                 
                // Randomly populate the field with plants.
                Location location = new Location(row, col);
                Plants plant = new Plants(rand.nextBoolean(), timer, 
                plantField, location);
                actors.add(plant);
            }
        }
    }

    /**
     * Define the colors of each type of actor.
     */
    public void defineColors(SimulatorView view)
    {
        view.setColor(Deer.class, new Color(102, 59, 0));
        view.setColor(Tiger.class, new Color(255, 136, 0));
        view.setColor(Mouse.class, new Color(255, 218, 198));
        view.setColor(Lion.class, new Color(247, 236, 39));
        view.setColor(Snake.class, new Color(27, 186, 0));
        view.setColor(Hunter.class, new Color(169, 2, 252));
    }

    /**
     * Set the charcteristics of the plant field window.
     */
    public void definePlantField(SimulatorView plantView)
    {
        plantView.setColor(Plants.class, Color.GREEN);
        plantView.setSize(720,360);
        plantView.setLocation(710, 525);
        plantView.setTitle("Plant Field");
    }
}
