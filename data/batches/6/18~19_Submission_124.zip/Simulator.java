import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.Collections;

/**
 * A predator-prey simulator, based on a rectangular field
 * containing plants, mice, deer, tigers, lions, snakes and hunters.
 *
 * @version 2019.02.15
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;

    // List of actors in the field.
    private List<Actor> actors;
    
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    // The current state of the actor field.
    private Field field;
    //The current state of the plant field.
    private Field plantField;
    // The current step of the simulation.
    private int step;
    // The current state of day.
    private  boolean isDay = false;
    // A timer to keep track of day and night.
    private Timer timer;
    // A graphical view of the simulation.
    private SimulatorView view;
    private SimulatorView plantView;
    // Collection of  implemented weathers.
    private ArrayList<Weather> weathers;
    // The population generator. 
    private PopulationGenerator generator;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // Initialize the variables
        actors = new ArrayList<>();
        field = new Field(depth, width);
        plantField = new Field(depth,width);
        timer = new Timer();
        weathers = new  ArrayList<>();
        
        // Create a view of the state of each location in the animal 
        // field and the plant field.
        view = new SimulatorView(depth, width);
        plantView = new SimulatorView(depth, width);
        
        // Create varying weather in the field.
        Weather rainy, sunny, cloudy;
        rainy = new Weather(8, 1, "Rainy");
        sunny = new Weather(1, 4, "Sunny");
        cloudy = new Weather(2, 0.5, "Cloudy");
        
        weathers.add(rainy); 
        weathers.add(sunny); 
        weathers.add(cloudy);
        plantField.setWeathers(weathers);

        // Define the colors displayed for each actor.
        generator = new PopulationGenerator();
        generator.defineColors(view);

        // Set the chacteristics of the plant window.
        generator.definePlantField(plantView);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of 
     * steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); 
        step++) {
            simulateOneStep();
            //delay(100);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * actor.
     */
    public void simulateOneStep()
    {
        step++;

        // Pass on the current step to the timer to evaluate day or night
        timer.setStep(step);
        timer.determineDay();

        // Provide space for new actors.
        List<Actor> newActors = new ArrayList<>();    

        //Randomize weather.
        if(weathers.get(0).changeWeather()){
            Collections.shuffle(plantField.getWeathers(), rand);
        }
        
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors);
            if(! actor.isActive()) {
                it.remove();
            }
        }

        // Add the new actors to the main list.
        actors.addAll(newActors);
        
        // Show the state of the simulationation in the view.
        view.showStatus(timer, field, weathers.get(0).getName());
        plantView.showStatus(timer, plantField, weathers.get(0).getName());
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();

        // Show the starting state in the view.
        generator.populate(field, actors, plantField, timer);
        view.showStatus(timer, field, weathers.get(0).getName());
        plantView.showStatus(timer, plantField, weathers.get(0).getName());
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * @return Step number.
     */
    public int getStep()
    {
        return step;
    }
}
