import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of prey animals.
 *
 * @version 2019.02.15
 */
public abstract class Prey extends Animal
{
    // number of steps prey can go before it has to eat plants again.
    private static final int PLANT_FOOD_VALUE = 15;
    // The plant's field
    private Field plantField;
    // A timer to keep track of day and night.
    private Timer timer;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Constructor for objects of class Prey
     */
    public Prey(Field field, Field plantField, Location location, 
    Timer timer)
    {
        super(field, location, timer);
        this.plantField = plantField;
    }
    
    /**
     * Look for plants adjacent to the current location of the animal.
     * All plants around the animal are eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        List<Location> adjacent = getField().perimeterLocations
        (getLocation(), -1, 1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = plantField.getObjectAt(where);
            if(actor instanceof Plants && getField().isEmpty(where)){
                Plants plant = (Plants) actor;
                if(!plant.isGrowing()) { 
                    plant.setEaten();
                    setFoodLevel(PLANT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * @return The plant field.
     */
    protected Field getPlantField()
    {
        return plantField;
    }
    
    /**
     * @return The plant food value.
     */
    protected int getPlantFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }
}
