import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a hunter.
 *
 * @version 2019.02.15
 */
public class Hunter implements Actor
{
    // Whether the hunter is alive or not.
    private boolean alive; 
    // The hunter's field.
    private Field field;
    // The hunter's position in the field.
    private Location location;
    // The probability that the hunter has of killing
    private static final double HUNT_PROBABILITY = 0.1;
    // A shared random generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Hunter
     */
    public Hunter(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * This is what hunters do most of the time - they hunt and they
     * move around.
     * @param newActors A list receiving newly created actors.
     */
    public void act(List<Actor> newActors)
    {
        hunt();
        // Try to move into a free location.
        Location newLocation = field.freeAdjacentLocation(location);
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Place the hunter at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Kill animals within a given distance of the hunter.
     */
    private void hunt()
    {
        if(rand.nextDouble() <= HUNT_PROBABILITY){
            List<Location> adjacent = field.perimeterLocations
                (location, -5, 5);
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                // Check that the object is an animal.
                if(actor instanceof Animal && rand.nextDouble() 
                <= HUNT_PROBABILITY){
                    Animal animal = (Animal) actor;
                    animal.setDead();
                }
            }
        }
    }

    /**
     * Indicate that the hunter is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * The hunter is active. 
     */
    public boolean isActive()
    {
        return alive;
    }
}
