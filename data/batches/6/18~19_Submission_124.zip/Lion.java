import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat deer, and die.
 *
 * @version 2019.02.21
 */
public class Lion extends Predator
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.55;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 22;
    // Probability of moving at day.
    private static final double MOVEMENT_PROBABILITY = 0.1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The class of the prey that the lion eats.
    private String preyClass = "class Deer";
    

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location, Timer timer)
    {
        super(field, location, timer);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(DEER_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(DEER_FOOD_VALUE);
        }
    }

    /**
     * Create new lion.
     * @param randomAge If true, the animal will have a random age, age 0 otherwise.
     * @param field The field.
     * @param location The location for the new animal.
     */
    protected Animal createAnimal(boolean randomAge, Field field, 
    Location location)
    {
        return new Lion(randomAge, field, location, getTimer());
    }

    /**
     * @ return The animal's breeding age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return The animal's max age.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return The breeding probability of this animal.
     */
    protected double getBreedingProb()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return Maximum number of offspring from this animal.
     */
    protected int getMaxLitterSz()
    {
        return MAX_LITTER_SIZE;
    } 
    
    /**
     * @return The food value of a single deer. In effect, this is the 
     * number of steps a lion can go before it has to eat again.
     */
    protected int getFoodValue()
   {
       return DEER_FOOD_VALUE;
    }

    /**
     * @return Probability of movement during night.
     */
    protected double getMovementProbability()
    {
        return MOVEMENT_PROBABILITY;
    }
    
    /**
     * @return The animal that the lion eats.
     */
    protected String getPreyClass()
   {
       return preyClass;
    }
}
