import java.util.List;

/**
 * Interface describing methods which should be implemented by all 
 * classes which implement Actor.
 *
 * @version 2019.02.15
 */
public interface Actor 
{ 
    /**
     * Perform the actor's regular behaviour. 
     * @param newActors A list receiving newly created actors.
     */
    void act(List<Actor> newActors);

    /**
     * Set a new location for the actor.
     * @param Location to be set to.
     */
    public void setLocation(Location location);

    /**
     * Is the actor still active?
     * @return true if still active, false if not. 
     */
    boolean isActive();
}
