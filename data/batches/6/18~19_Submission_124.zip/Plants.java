import java.util.List;
import java.util.Collections;
import java.util.Random;
/**
 * A simple model of plants.
 * They grow in height and can be eaten by prey animals.
 *
 * @version 2019.02.20
 */
public class Plants implements Actor
{
    // Characteristics shared by all plants (class variables).
    // Maximum height achieved by plants.
    private static final int MAX_GROWTH_HEIGHT = 20;
    // The plant's position in the field.
    private Location location;
    // The plant's field.
    private Field plantField;
    // The plant's height.
    private double height;
    // The plant's clock.
    private Timer timer;
    // If the plant is alive or not.
    private boolean alive;
    // If the plant is growing or not.
    private boolean growing;
    // A shared random generator.
    private static final Random rand = Randomizer.getRandom();
    /**
     * Constructor for objects of class Plants
     */
    public Plants(boolean randomAge, Timer timer, Field field, Location location)
    {
        this.timer = timer;
        alive = true;
        setLocation(location);
        setField(field);
        if(randomAge) {
            setHeight(rand.nextInt(MAX_GROWTH_HEIGHT));
            growing = true;
            
        }
        else{
            setHeight(MAX_GROWTH_HEIGHT);
            growing = false;
            plantField.place(this, location);
        }
        
        
    }

    /**
     * This is what the plant does most of the time - it grows up to
     * a maximum height and reacts to weather.
     * @param newPlants A list to return new plants.
     */
    public void act(List<Actor> newPlants)
    {
        if (height >= MAX_GROWTH_HEIGHT && plantField.isEmpty(location)){
            plantField.place(this, location);
            growing = false;
        }
        reactToWeather();
    }  

    /**
     * Get the properties of current weather and grow accordingly.
     */
    private void reactToWeather()
    {
        double temperature = plantField.getWeathers().get(0).
            getTemperature();
        double humidity = plantField.getWeathers().get(0).
            getHumidity();
        height = height + (humidity * temperature);
    }

    /**
     * Set the height of the plant.
     */
    private void setHeight(double height)
    {
        this.height = height;
    }

    /**
     * Set the location of the plant.
     */
    public void setLocation(Location location)
    {
        this.location = location;
    }

    /**
     * Set the field of the plant.
     */
    private void setField(Field field)
    {
        this.plantField = field;
    }

    /**
     * Get the current field of the plant 
     */
    public Field getField()
    {
        return plantField;
    }

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isActive()
    {
        return alive;
    }

    /**
     * Check whether the plant is growing or not.
     * @return true if the plant is growing.
     */
    public boolean isGrowing()
    {
        return growing;
    }

    /**
     * Remove the plant from the field once it has been
     * eaten by prey.
     */
    public void setEaten()
    {
        if(location != null) {
            plantField.clear(location);
            growing = true;
            height = 0;
        }
    }
}
