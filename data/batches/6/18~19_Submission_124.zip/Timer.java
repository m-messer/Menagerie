
/**
 * Uses step count to determine day or night.
 *
 * @version 2019.02.15
 */
public class Timer
{
    
    private int step = 0;
    private int  dayLength = 20;
    private boolean isDay = true;

    /**
     * Constructor for objects of class Timer
     */
    public Timer()
    {
        
    }

    public void setStep(int step)
    {
        this.step = step;
    }
    
    public String getTime()
    {
        if(isDay){
            return "Day";
        }
        else{
            return "Night";
        }
    }
        
    public int getStep()
    {
        return step;
    }
    
    public void determineDay()
    {
        if(step % dayLength == 0) {
            isDay = !isDay;
        }
    }
    
    /**
     * Determine days and nights.
     */
    public boolean isDay()
    {
        return isDay;
    }
}
