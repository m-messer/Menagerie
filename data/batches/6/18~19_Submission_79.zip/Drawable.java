
/**
 * Write a description of interface Drawable here.
 *
 * @version (a version number or a date)
 */
public interface Drawable
{
}
