import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * This Singleton class describes the weather in the simulation.
 * Through this class other classes can communicate with some of
 * the functions of Time
 *
 * @version 1.0.0
 */
public class Weather
{
    // This will be the only instance of weather
    private static Weather weather = new Weather();

    // The time instance of the simulation
    private Time time = Time.getInstance();

    private Random rand = new Random();


    // Array of all seasons
    private String[] allSeasons = {"spring", "summer", "autumn", "winter"};
    // Array of all weather types
    private String[] allWeatherTypes = {"raining", "snowing", "dry", "hot", "neutral"};
    // Banned season-weather combinations
    private HashMap<String, ArrayList<String>> bannedSeasonWeather = new HashMap<String, ArrayList<String>>();
    // HashMap of the seasons: seasonName -> (weatherType -> chanceOfHappenning)
    private HashMap<String, HashMap<String, Double>> seasonalWeather = new HashMap<String,HashMap<String, Double>>();

    // Current season, weather, and time
    private String currentSeason;
    private String currentWeather;
    private String timeOfDay;

    // How much steps has the current weather have left (in moves)
    private int weatherStepsLeft;

    /**
     * Constructor of Weather class.
     * Made private so we can only instantiate an object
     * inside of the class (Preventing more than one instance
     * of Weather)
     */
    private Weather() {
        initWeather();

        checkSeason();

        checkTimeOfDay();
    }

    /**
     * Returns the Weather object
     * 
     * @return Weather - singleton Weather object
     */
    public static Weather getInstance() {
        return weather;
    }

    private void initWeather() {
        // Initialize banned weather combinations
        initBannedWeather();

        /**
         * Iterates through seasons and assigns a random
         * chance a weather type will occur during the
         * specified season
         */
        for (String season: allSeasons) {
            HashMap<String, Double> weatherChance = new HashMap<String, Double>();
            for (String weatherType: allWeatherTypes) {
                // Continue if combination can't exist
                if (isWeatherBanned(season, weatherType)) continue;

                // Get a random chance the weather will happen
                double weatherRand = rand.nextDouble();
                weatherChance.put(weatherType, weatherRand);
            }
            // Add the season to the hashmap
            seasonalWeather.put(season, weatherChance);
        }
    }

    /**
     * Initialize the HashMap of banned season-weather combinations
     */
    private void initBannedWeather() {
        ArrayList<String> bannedSpring = Tools.stringArrayToArrayList("snowing", "dry");
        bannedSeasonWeather.put("spring", bannedSpring);
        ArrayList<String> bannedSummer = Tools.stringArrayToArrayList("snowing");
        bannedSeasonWeather.put("summer", bannedSummer);
        ArrayList<String> bannedAutumn = Tools.stringArrayToArrayList("snowing", "hot");
        bannedSeasonWeather.put("autumn", bannedAutumn);
        ArrayList<String> bannedWinter = Tools.stringArrayToArrayList("hot", "dry");
        bannedSeasonWeather.put("winter", bannedWinter);
    }

    /**
     * Generates new weather, based on given season.
     * Updates currentWeather var.
     * 
     * @param String season - given season
     */
    private void generateNewWeather(String season) {
        HashMap<String, Double> weatherAvailable = seasonalWeather.get(season);

        for (Map.Entry<String, Double> entry: weatherAvailable.entrySet()) {
            String weatherType = entry.getKey();
            Double weatherChance = entry.getValue();

            if (rand.nextDouble() <= weatherChance) {
                currentWeather = weatherType;

                weatherStepsLeft = rand.nextInt(15) + 1;
                return;
            }
        }

        // If no weather chosen, set to neutral
        if (currentWeather == null) {
            currentWeather = "neutral";
        }
    }

    /**
     * Change the season and generate new weather
     * 
     * @param String season
     */
    private void changeSeason(String season) {
        currentSeason = season;

        // Generate new weather
        generateNewWeather(season);
    }

    /**
     * Check if the season should be changed
     */
    private void checkSeason() {
        int currentMonth = time.getMonth();

        if(Tools.isBetween(currentMonth, 3, 5)) {
            if (currentSeason == "spring") return;
            changeSeason("spring");
        } else if (Tools.isBetween(currentMonth, 6, 8)) {
            if (currentSeason == "summer") return;
            changeSeason("summer");
        } else if (Tools.isBetween(currentMonth, 9, 11)) {
            if (currentSeason == "autumn") return;
            changeSeason("autumn");
        } else if (Tools.isBetween(currentMonth, 1, 2) || currentMonth == 12) {
            if (currentSeason == "winter") return;
            changeSeason("winter");
        }
    }

    /**
     * Check if the weather should be changed
     */
    private void checkWeather() {
        if (weatherStepsLeft <= 0) {
            generateNewWeather(currentSeason);
            return;
        }

        weatherStepsLeft--;
    }

    /**
     * Check the time of the day
     */
    private void checkTimeOfDay() {
        int hour = time.getHour();

        if (Tools.isBetween(hour, 0, 4)){
            timeOfDay = "night";
        } else if (Tools.isBetween(hour, 5, 11)) {
            timeOfDay = "morning";
        } else if (Tools.isBetween(hour, 12, 20)) {
            timeOfDay = "afternoon";
        } else if (Tools.isBetween(hour, 20, 23)) {
            timeOfDay = "night";
        }
    }

    /**
     * Returns the string representation
     * of the time of the day
     * 
     * @return String - time of day string
     */
    public static String getTimeOfDay() {
        return weather.timeOfDay;
    }

    /**
     * Returns the season name
     * 
     * @return String - seasone
     */
    public static String getSeason() {
        return weather.currentSeason;
    }

    /**
     * Returns the weather type
     * 
     * @return String - weather type
     */
    public static String getWeather() {
        return weather.currentWeather;
    }

    /**
     * Increments the time and checks if season/weather
     * should be changed
     */
    public void incrementTime() {
        // First, increment the hours
        time.incrementTime();
        
        // Check if we need to update season
        checkSeason();

        // If we don't change season, check if we need to change weather
        checkWeather();

        // check the time of the day, update if necessary
        checkTimeOfDay();
    }


    /**
     * Returns if the season->weather combination is banned
     * 
     * @param String season - chosen season
     * @param String weather - chosen weather type
     * @return boolean - true if weather is banned, false otherwise.
     */
    private boolean isWeatherBanned(String season, String weather) {
        ArrayList<String> bannedForWeather = bannedSeasonWeather.get(season);

        return bannedForWeather.contains(weather);
    }

}
