import java.util.ArrayList;
import java.util.Arrays;

/**
 * This static class contains useful tools
 * to be used in other classes
 *
 * @version 1.0.0
 */
public final class Tools
{
    private Tools() {}

    /**
     * Convert a string[] to a ArrayList<String>
     * 
     * @param String[] myArray - the array to be converted
     * @return ArrayList<String>
     */
    public static ArrayList<String> stringArrayToArrayList(String ...myArray) {
        return new ArrayList<String>(Arrays.asList(myArray));
    }

    /**
     * Tell if x value is between 2 values. INCLUSIVE!
     * 
     * @param int x - compared value
     * @param int lower - lower value
     * @param int upper - upper value
     * 
     * @return boolean - true if it is between, false otherwise.
     */
    public static boolean isBetween(int x, int lower, int upper) {
        return lower <= x && x <= upper;
    }
}
