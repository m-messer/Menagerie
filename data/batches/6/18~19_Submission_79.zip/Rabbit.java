import java.util.List;
import java.util.Random;
import java.util.Iterator;


/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Rabbit extends Animal implements Drawable
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 110;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.85;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The animal's food value when eaten.
    static final int FOOD_VALUE = 8;
    // The animal's maximum food level.
    private static final int MAX_FOOD_LEVEL = 24;
    
    // Individual characteristics (instance fields).
    
    // The rabbit's age.
    private int age;
    
    private int foodLevel;

    private FoodChain foodChain = new FoodChain();

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        age = 0;
        foodLevel = MAX_FOOD_LEVEL;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE) + 1;
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL) + 1;
        }
        this.initFoodChain();
    }

    private void initFoodChain() {
        this.foodChain.setEatable("Plant");
    }
    
    /**
     * This is what the rabbit does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Animal> newRabbits)
    {
        incrementAge();
        incrementHunger();

        // Check if sick and make the disease act
        if (this.isSick()) {
            this.getDisease().act();
        } 

        if(isAlive()) {
            giveBirth(newRabbits);
            
            // If not sick, but have luck -> get infected with a new Disease
            if (!isSick()) {
                if (rand.nextDouble() <= this.getSicknessProbability()) {
                    // Get infected by a random disease
                    this.becomeInfected();
                }
            }

            Location newLocation = findFood();
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the rabbit's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Increase the hunger.
     * This could result in death
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    private void giveBirth(List<Animal> newRabbits)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rabbit young = new Rabbit(false, field, loc);
            newRabbits.add(young);
        }
    }
        
    private boolean match()
    {

        // If not female, it cannot breed
        if (this.getGender() != true) {
            return false;
        }

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    if(rabbit.getGender() != this.getGender())
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if (foodChain.canEat((Organism<?>) organism)) {
                // if not hungry don't eat
                if (!this.isHungry()) continue;

                Organism targetAnimal = (Organism<?>) organism;
                if (targetAnimal.isAlive()) {
                    targetAnimal.setDead();
                    this.setFoodLevel(foodLevel += targetAnimal.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;

        // Calculate the breeding probability
        double breedingProbability = calculateBreedingProbability();

        if(canBreed() && rand.nextDouble() <= breedingProbability && match()) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Calculates the breeding probability based
     * on factors such as season and weather
     * 
     * @return double - final breeding probability
     */
    private double calculateBreedingProbability() {
        String currentSeason = Weather.getSeason();
        String currentWeather = Weather.getWeather();

        double breedingProbability = BREEDING_PROBABILITY;
        double accumulatedEffect = 0.00;
        // Add changes based on season
        switch(currentSeason) {
            case "winter":
                accumulatedEffect -= 0.02;
                break;
            case "summer":
                accumulatedEffect += 0.02;
                break;
            case "autumn":
                accumulatedEffect -= 0.05;
                break;
            case "spring":
                accumulatedEffect += 0.04;
                break;
        }

        // Add changes based on weather
        switch(currentWeather) {
            case "raining":
                accumulatedEffect -= 0.04;
                break;
            case "dry":
                accumulatedEffect += 0.01;
                break;
            case "hot":
                accumulatedEffect += 0.02;
                break;
            case "neutral":
                accumulatedEffect += 0.03;
                break;
            case "snowing":
                accumulatedEffect -= 0.03;
                break;
        }

        return breedingProbability += accumulatedEffect;
    }

    /**
     * Getter method - returns the food value of the animal
     * 
     * @return int - food value
     */
    public int getFoodValue() {
        return Rabbit.FOOD_VALUE;
    }
    
    /**
     * A rabbit can breed if it has reached the breeding age
     * and it is not too hungry.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && foodLevel > MAX_FOOD_LEVEL/3;
    }

    /**
     * Returns if Fox is hungry or not
     */
    private boolean isHungry() {
        return this.foodLevel <= (3* MAX_FOOD_LEVEL/2);
    }
    
    /**
     * Setter method - food level
     * 
     * @param int newFoodLevel
     */
    private void setFoodLevel(int newFoodLevel) {
        if (newFoodLevel <= MAX_FOOD_LEVEL) this.foodLevel = newFoodLevel;
        else this.foodLevel = MAX_FOOD_LEVEL;
    }
}
