import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@SuppressWarnings("serial")
class FoodChain extends HashMap<String, Integer> {

    /**
     * Constructor for a FoodChain object.
     * Inputs default values in the HashMap for
     * what the animal can eat/kill. 
     * 0 - can't eat it and can't kill it
     * 1 - can eat it
     * 2 - can kill it
     */
    public FoodChain() {
        this.put("Rabbit", 0);
        this.put("Cougar", 0);
        this.put("Elk", 0);
        this.put("Fox", 0);
        this.put("Plant", 0);
        this.put("Wolf", 0);
        this.put("Plant", 0);
    }

    /**
     * Returns if the animal can be eaten
     * 
     * @return boolean
     */
    public boolean canEat(Object animal) {
        if (Objects.isNull(animal)) return false;

        return this.get(animal.toString()) == 1;
    }

    /**
     * Returns if the animal can be klled
     * 
     * @return boolean
     */
    public boolean canKill(Object animal) {
        return this.get(animal.toString()) == 2;
    }

    /**
     * Sets the value in the FoodChain corresponding
     * to the passed animal to 1
     */
    public void setEatable(Animal animal) {
        // check if passed value is wrong (we all make mistakes):
        if (!this.containsKey(animal.toString())) return;

        this.put(animal.toString(), 1);
    }

    /**
     * Sets the value in the FoodChain corresponding
     * to the passed animal to 1
     * 
     * @param animalStr - String relating to animal
     */
    public void setEatable(String animalStr) {
        // check if passed value is wrong (we all make mistakes):
        if (!this.containsKey(animalStr)) return;

        this.put(animalStr, 1);
    }

    /**
     * Sets the value in the FoodChain corresponding
     * to the passed animal to 2
     * 
     * @param animal - Animal
     */
    public void setKillable(Animal animal) {
        // check if passed value is wrong (we all make mistakes):
        if (!this.containsKey(animal.toString())) return;

        this.put(animal.toString(), 2);
    }

    /**
     * Sets the value in the FoodChain corresponding
     * to the passed animal to 2
     * 
     * @param animalStr - String relating to animal
     */
    public void setKillable(String animalStr) {
        // check if passed value is wrong (we all make mistakes):
        if (!this.containsKey(animalStr)) return;

        this.put(animalStr, 2);
    }

    /**
     * Getter method - value of animal in food chain
     * 
     * @return Integer
     */
    public int getStatus(Animal animal) {
        return this.get(animal.toString());
    }

    /**
     * Makes a string representation of the HashMap.
     * Made for future logging purposes.
     * 
     * @return String
     */
    @Override
    public String toString() {
        String foodChainStr = "This animal can:\n";
        for (Map.Entry<String, Integer> entry: this.entrySet()) {
            switch (entry.getValue()) {
                case 1:
                    foodChainStr = foodChainStr.concat("eat a " + entry.getKey() + "\n");
                    break;
                case 2:
                    foodChainStr = foodChainStr.concat("kill a " + entry.getKey() + "\n");
                default:
                    break;
            }
        }
        return foodChainStr;
    }
}