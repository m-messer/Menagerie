import java.util.List;
import java.util.Objects;
import java.util.Iterator;

/**
 * A model of a Cougar.
 *
 * @version 1.0.0
 */
public class Cougar extends Animal implements Drawable
{
    // Characteristics shared by all cougars (class variables).
    
    // The age at which a cougar can start to breed.
    private static final int BREEDING_AGE = 17;
    // The age to which a cougar can live.
    private static final int MAX_AGE = 35;
    // The likelihood of a cougar breeding.
    private static final double BREEDING_PROBABILITY = 0.40;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a cougar. In effect, this is the
    // number of steps a cougar can go before it has to eat again.
    private static final int FOOD_VALUE = 20;
    // The maximum food level of the animal.
    private static final int MAX_FOOD_LEVEL = 30;
    
    // Individual characteristics (instance fields).
    // The cougar's age.
    private int age;
    // The cougar's food level, which is increased by eating rabbits.
    private int foodLevel;

    private FoodChain foodChain = new FoodChain();
    

    /**
     * Create a cougar. A cougar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cougar will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cougar(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE) + 1;
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL) + 1;
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        this.initFoodChain();
    }

    private void initFoodChain() {
        this.foodChain.setEatable("Elk");
        this.foodChain.setEatable("Wolf");
    }
    
    /**
     * This is what the cougar does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newcougars A list to return newly born cougars.
     */
    public void act(List<Animal> newCougars)
    {
        incrementAge();
        incrementHunger();

        // Check if sick and make the disease act
        if (this.isSick()) {
            this.getDisease().act();
        } 

        if(isAlive()) {
            // Make Cougar sleep at night
            String currentTimeOfDay = Weather.getTimeOfDay();
            if (currentTimeOfDay == "night") {
                return;
            }

            giveBirth(newCougars);       
            
            // If not sick, but have luck -> get infected with a new Disease
            if (!isSick()) {
                if (rand.nextDouble() <= this.getSicknessProbability()) {
                    // Get infected by a random disease
                    this.becomeInfected();
                }
            }

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeMovementLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the cougar's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this cougar more hungry. This could result in the cougar's death.
     */
    private void incrementHunger()
    {
        foodLevel --;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);

            // Check if null:
            if (Objects.isNull(animal)) continue;

            if (foodChain.canEat((Organism<?>) animal)) {
                // if not hungry don't eat
                if (!this.isHungry()) continue;

                // Dynamic downcasting?
                Animal targetAnimal = (Animal) animal;
                if (targetAnimal.isAlive()) {
                    targetAnimal.setDead();
                    this.setFoodLevel(foodLevel += targetAnimal.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this cougar is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newcougars A list to return newly born cougars.
     */
    private void giveBirth(List<Animal> newCougars)
    {
        // New cougars are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cougar young = new Cougar(false, field, loc);
            newCougars.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;

        // Calculate the breeding probability:
        double breedingProbability = calculateBreedingProbability();

        if(canBreed() && rand.nextDouble() <= breedingProbability && match()) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    private boolean match()
    {
        // If not female, it cannot breed
        if (this.getGender() != true) {
            return false;
        }

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cougar) {
                Cougar cougar = (Cougar) animal;
                if(cougar.isAlive()) { 
                    if(cougar.getGender() != this.getGender())
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Calculates the breeding probability based
     * on factors such as season and weather
     * 
     * @return double - final breeding probability
     */
    private double calculateBreedingProbability() {
        String currentSeason = Weather.getSeason();
        String currentWeather = Weather.getWeather();

        double breedingProbability = BREEDING_PROBABILITY;
        double accumulatedEffect = 0.00;
        // Add changes based on season
        switch(currentSeason) {
            case "winter":
                accumulatedEffect -= 0.07;
                break;
            case "summer":
                accumulatedEffect += 0.05;
                break;
            case "autumn":
                accumulatedEffect -= 0.03;
                break;
            case "spring":
                accumulatedEffect += 0.04;
                break;
        }

        // Add changes based on weather
        switch(currentWeather) {
            case "raining":
                accumulatedEffect -= 0.02;
                break;
            case "dry":
                accumulatedEffect += 0.01;
                break;
            case "hot":
                accumulatedEffect += 0.02;
                break;
            case "snowing":
                accumulatedEffect -= 0.01;
                break;
        }

        return breedingProbability += accumulatedEffect;
    }
    
    /**
     * Getter method - returns the food value of the animal
     * 
     * @return int - food value
     */
    public int getFoodValue() {
        return Cougar.FOOD_VALUE;
    }

    /**
     * A cougar can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && (foodLevel >= MAX_FOOD_LEVEL/2);
    }

    /**
     * Returns if Cougar is hungry or not
     */
    private boolean isHungry() {
        return this.foodLevel <= MAX_FOOD_LEVEL / 2;
    }
    
    /**
     * Setter method - food level
     * 
     * @param int newFoodLevel
     */
    private void setFoodLevel(int newFoodLevel) {
        if (newFoodLevel <= MAX_FOOD_LEVEL) this.foodLevel = newFoodLevel;
        else this.foodLevel = MAX_FOOD_LEVEL;
    }
}
