import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.HashMap;


/**
 * This singleton class represents the time
 * in the simulation.
 *
 * @version 1.0.0
 */
public class Time
{
    private static Time timeObj = new Time();

    private LocalDateTime date;

    private Random rand = new Random();

    // The hours we increment on each step of simulation
    private int INCREMENTED_HOURS = 6;

    private HashMap<Integer, String> monthString = new HashMap<Integer, String>();
    /**
     * Constructor of Time class.
     * Made private so we can only instantiate an object
     * inside of the class (Preventing more than one instance
     * of Time)
     */
    private Time() {
        int randomYear = rand.nextInt(1000);
        int randomMonth = rand.nextInt(12) + 1;
        int randomDay = rand.nextInt(28) + 1;
        int randomHour = rand.nextInt(23) + 1;
        date = LocalDateTime.of(randomYear, randomMonth, randomDay, randomHour, 0);
    }

    /**
     * Returns the Time object
     * 
     * @return Time - singleton time object
     */
    public static Time getInstance() {
        return timeObj;
    }

    /**
     * Increment the time by constant time
     */
    public void incrementTime() {
        date = date.plusHours(INCREMENTED_HOURS);
    }

    /**
     * Returns the Month of the year.
     * From 1 to 12.
     * 
     * @return int - current month
     */
    public int getMonth() {
        return date.getMonthValue();
    }

    /**
     * Convert the time from integer to English words.
     */
    public void monthConvert(){
        monthString.put(1, "January");
        monthString.put(2, "Febuary");
        monthString.put(3, "March");
        monthString.put(4, "April");
        monthString.put(5, "May");
        monthString.put(6, "June");
        monthString.put(7, "July");
        monthString.put(8, "August");
        monthString.put(9, "September");
        monthString.put(10, "October");
        monthString.put(11, "November");
        monthString.put(12, "December");
        
    }
    
    /**
     * Returns the month in english
     */
    
    public String getMonthString()
    {
        monthConvert();
        return monthString.get(getMonth());
    }
    
    /**
     * Returns the hour of the day.
     * 
     * @return int - hour of day
     */
    public int getHour() {
        return date.getHour();
    }
}
