import java.util.List;
/**
 * Write a description of class Plant here.
 *
 * @version (a version number or a date)
 */

public class Plant extends Organism<Plant> implements Drawable

{
    private static final double BREEDING_PROBABILITY = 0.02;//0.075
     // The animal's food value when eaten.
    static final int FOOD_VALUE = 9;
    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Plant> newPlants)
    {
        // incrementAge();
        if(isAlive()) {
            reproduce(newPlants);
        }
    }


    public int getFoodValue() {
        return Plant.FOOD_VALUE;
    }
    
    private void reproduce(List<Plant> newPlants) {
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breedCount();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(field, loc);
            newPlants.add(young);
        }
    }
    
    private int breedCount() {
        
        return (rand.nextDouble() <= BREEDING_PROBABILITY) ? rand.nextInt(2) + 1 : 0;
    }
}
