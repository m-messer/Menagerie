import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;

/**
 * Class that describes a disease in the simulation
 *
 * @version 1.0.0
 */
public class Disease {

    private double MAX_INFECTION_CHANCE = 0.05;
    private int MAX_SPAN = 50;
    public static int DEFAULT_SPAN = 15;

    private int totalTimeSpan;
    private int currentTimeSpan;
    private Animal infectedAnimal;
    
    private Random rand = new Random();

    public double infectionChance;

    /**
     * Default constructor for objects of class Disease.
     * Makes time span and infection chance random.
     */
    public Disease() {
        int timeSpan = rand.nextInt(MAX_SPAN) + 1;
        this.setTotalSpan(timeSpan);
        this.setCurrentSpan(timeSpan);

        double randomInfectionChance = MAX_INFECTION_CHANCE * rand.nextDouble();
        this.setInfectionChance(randomInfectionChance);
    }

    /**
     * Constructor for objects of class Disease
     * when supplied with a time span value
     * @param newTimeSpan
     */
    public Disease(int newTimeSpan) {
        this();
        this.setTotalSpan(newTimeSpan);
        this.setCurrentSpan(newTimeSpan);
    }

    /**
     * Constructor for objects of class Disease
     * when supplied with an infection chance value
     * 
     * @param newInfectionChance - disease infection chance
     */
    public Disease(double newInfectionChance) {
        this();
        this.setInfectionChance(newInfectionChance);
    }
    
    /**
     * Constructor for objects of class Disease
     * when supplied with a timespan and infection chance values
     * 
     * @param newTimeSpan - time span of disease
     * @param newInfectionChance - disease infection chance
     */
    public Disease(int newTimeSpan, double newInfectionChance)
    {
        this();
        this.setTotalSpan(newTimeSpan);
        this.setCurrentSpan(newTimeSpan);
        this.setInfectionChance(newInfectionChance);
    }
    
    /**
     * Constructor for objects of class Disease
     * when supplied with a Disease object
     * 
     * @param copiedDisease - the copied Disease object
     */
    public Disease(Disease copiedDisease) {
        this.setTotalSpan(copiedDisease.getTotalSpan());
        this.setCurrentSpan(this.getTotalSpan());
        this.setInfectionChance(copiedDisease.getInfectionChance());
    }


    /**
     * Makes the disease act. This will
     * increment the disease lifespan and check if 
     * it should infect others around the infected animal
     */
    public void act() {
        // Return if the infected animal has not been set
        if (infectedAnimal == null) return;

        // If time span ended, make the animal die
        if (this.currentTimeSpan <= 0) {
            this.infectedAnimal.setDead();
            return;
        }

        // Try to infect neighbouring animals
        this.infectNeighbours();

        this.incrementSpan();
    }

    /**
     * Iterates through neighbouring animals
     * and tries to infect them.
     */
    private void infectNeighbours() {
        Field field = this.infectedAnimal.getField();

        /**
         * BUG: For some reason, in absolutely random cases
         * field is null
         * 
         * Temporary fix:
         */
        if (Objects.isNull(field)) return;

        List<Location> adjacent = field.adjacentLocations(this.infectedAnimal.getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);

            if (Objects.isNull(animal)) continue;

            if(animal instanceof Animal) {
                Animal targetAnimal = (Animal) animal;

                // If animal is already sick, no need to infect it
                if (targetAnimal.isSick()) continue;

                // Try to infect based on infection chance
                if (rand.nextDouble() <= this.infectionChance) {
                    // Make a new disease copying current one
                    Disease newDisease = new Disease(this);
                    // Set the infected animal
                    newDisease.setInfectedAnimal(targetAnimal);
                    // Make the animal sick with new disease
                    targetAnimal.setDisease(newDisease);
                }
            }
        }
    }


    /**
     * Getter method - total time span of disease
     * @return int
     */
    public int getTotalSpan() {
        return this.totalTimeSpan;
    }
    
    /**
     * Getter method - current time span of disease
     * @return int
     */
    public int getCurrentSpan() {
        return this.currentTimeSpan;
    }

    /**
     * Returns the infection chance of the disease
     * 
     * @return double - infection chance
     */
    public double getInfectionChance() {
        return this.infectionChance;
    }

    /**
     * Returns the infected animal
     * 
     * @return Animal - infected animal
     */
    public Animal getInfectedAnimal() {
        return this.infectedAnimal;
    }

    /**
     * Setter method - total time span of disease
     * @param newSpan - new total time span of disease
     */
    public void setTotalSpan(int newSpan) {
        if (newSpan > MAX_SPAN) {
            System.out.println("[-] ERROR: New Span is exceeding MAX_SPAN");
            return;
        }

        this.totalTimeSpan = newSpan;
    }

    /**
     * Setter method - current time span of disease
     * @param newSpan - new current time span
     */
    public void setCurrentSpan(int newSpan) {
        if(newSpan > MAX_SPAN || newSpan > this.totalTimeSpan) {
            System.out.println("[-] ERROR: New Span is exceeding MAX_SPAN or totalTimeSpan");
            return;
        }

        this.currentTimeSpan = newSpan;
    }

    /**
     * Setter method - the infected animal
     * 
     * @param Animal animal - infected animal
     */
    public void setInfectedAnimal(Animal animal) {
        this.infectedAnimal = animal;
    }
    
    /**
     * Increments the current time span of the disease
     */
    public void incrementSpan() {
        this.currentTimeSpan -= 1;
    }

    /**
     * Setter method - the infection chance of the disease
     * 
     * @param newInfectionChance - new infection chance of disease
     */
    public void setInfectionChance(double newInfectionChance) {
        this.infectionChance = newInfectionChance;
    }
    
    /**
     * Returns if the disease has reached the end of its lifespan
     * 
     * @return boolean - is the disease finished
     */
    public boolean isDead() {
        return this.currentTimeSpan <= 0;
    }
    
    /**
     * Returns the Disease object
     * 
     * @return Disease - the Disease object
     */
    public Disease getDisease() {
        return this;
    }
    
}
