import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 1.0.0
 */
public abstract class Animal extends Organism<Animal>
{
    // The maximum probability an animal will randomly catch a disease
    private static final double MAX_SICKNESS_PROBABILITY = 0.007;

    // The gender of animals, 0 represents male and 1 represents female.
    // When the number is -1, set the gender randomly.
    private boolean gender;
    
    // The disease of the animal (if any)
    private Disease disease;
    
    // Probability the animal will get sick out of nowhere
    private double sicknessProbability;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // Set random gender
        setGender();
        // Set random sickness probability
        setSicknessProbability(rand.nextDouble() * MAX_SICKNESS_PROBABILITY);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newAnimals A list to receive newly born animals.
     */
    abstract protected void act(List<Animal> newOrganisms);
    
    /**
     * Get the food value of the animal
     */
    abstract protected int getFoodValue();

    /**
     * Getter method - Get the current disease
     * 
     * @return Disease
     */
    protected Disease getDisease() {
        return this.disease;
    }

    /**
     * Getter method - the gender of the animal
     * 
     * @return booelan
     */
    protected boolean getGender()
    {
        return this.gender;
    }

    /**
     * Getter method - the sickness probability of the animal
     * 
     * @return double
     */
    protected double getSicknessProbability() {
        return this.sicknessProbability;
    }

    /**
     * Setter method - sets a disease on the animal
     * 
     * @param newDisease
     */
    public void setDisease(Disease newDisease) {
        this.disease = newDisease;
    }

    /**
     * Sets a random gender to the animal
     */
    protected void setGender()
    {
        this.gender = rand.nextInt(2) == 1;
    }

    /**
     * Setter method - sets a sickness probability
     * 
     * @param double prob
     */
    private void setSicknessProbability(double prob) {
        this.sicknessProbability = prob;
    }

    /**
     * Get yourself infected with a Disease
     * with random properties.
     * WARNING: Use with caution.
     */
    protected void becomeInfected() {
        // Makes a new disease with random properties
        Disease newDisease = new Disease();
        // Set the infected animal
        newDisease.setInfectedAnimal(this);
        // Make the animal sick with new disease
        this.setDisease(newDisease);
    }
    
    /**
     * Returns if the animal is sick or not
     * 
     * @return boolean
     */
    protected boolean isSick() {
        return this.disease != null;
    }

}
