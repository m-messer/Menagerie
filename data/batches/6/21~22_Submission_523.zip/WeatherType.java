/**
 * This file is part of the Predator-Prey Simulation.
 *
 * An enumeration for the types of weather events in the simulation.
 *
 * @version 2022.03.02
 */
public enum WeatherType {
    SUN,
    RAIN,
    FOG,
    SNOW,
    STORM;
}
