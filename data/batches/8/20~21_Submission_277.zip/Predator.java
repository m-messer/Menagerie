import java.util.Random;
import java.util.Iterator;
import java.util.List;

/**
 * A class that represents a predator and it can eat other animal.
 *
 * @version 2021.03.02
 */

public abstract class Predator extends Animal
{
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new predator at location in field.
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setFoodValue();        
    }

    /**
     * Look for preys adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Animal animal = (Animal) field.getObjectAt(where);            
            if(animal != null && getFoodValue().containsKey(animal.getClass())) {                
                if(animal.isAlive()) {
                    animal.setDead();
                    int foodValue = getFoodValue().get(animal.getClass());
                    if (foodLevel <= foodValue) {
                        foodLevel = foodValue;
                    }
                    return where;
                }
            }
        }
        return null;
    }
}
