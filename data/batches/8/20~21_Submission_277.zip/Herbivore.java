import java.util.List;
import java.util.Iterator;

/**
 * A class that represents a herbivore and it can eat plants.
 *
 * @version 2021.03.02
 */
public abstract class Herbivore extends Animal
{
    // The current field for the plant as a food source for the herbivore.
    private Field plantField;

    /**
     * Create a new herbivore at location in field.
     * 
     * @param randomAge If true, the herbivore will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param plantField The current field storing plants.
     */
    public Herbivore(boolean randomAge, Field field, Location location, Field plantField)
    {
        super(randomAge, field, location);
        this.plantField = plantField;
    }

    /**
     * Look for fully grown plants at the current location.
     */
    protected void findFood()
    {
        Field field = plantField;

        Location where = getLocation();
        Plant plant = (Plant) field.getObjectAt(where);            
        if(plant != null && getFoodValue().containsKey(plant.getClass()) && plant.isAlive() && plant.IsFullyGrown()) {            
            plant.setDead();
            foodLevel = getFoodValue().get(plant.getClass());
        }
    }
    
    /**
     * @return The field storing the plants.
     */
    public Field getPlantField()
    {
        return plantField;
    }
}
