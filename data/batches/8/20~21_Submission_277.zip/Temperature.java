
/**
 * Temperature class represents the temperature of a water.
 *
 * @version 2021.03.02 
 */
public class Temperature
{
    private static int temp = 17;

    public Temperature() {}

    /**
     * @return The actual temperature of the sea
     */
    public static int getTemp()
    {
        return temp;
    }

    /**
     * Decreases the temperature of the sea by one.
     * The temperature cannot go below 0.
     */
    public static void decreaseTemp()
    {
        if (temp > 0) {
            temp--;
        }
    }

    /**
     * Increases the temperature of the sea by one.
     * The temperature cannot go above 100.
     */
    public static void increaseTemp()
    {
        if (temp < 100 ) {
            temp++;
        }
    }
    
    /**
     * Resets the temperature to the initial value, that is 17.
     */
    public static void reset()
    {
        temp = 17;
    }
}
