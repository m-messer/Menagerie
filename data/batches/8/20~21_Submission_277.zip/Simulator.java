import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;
import java.util.Collections; 

/**
 * The main class for predator-prey simulator, based on a rectangular field
 * containing sea life creatures.
 *
 * @version 2021.03.02
 */
public class Simulator
{    
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;

    // Collection to store the creation probabilities.
    private static HashMap<Class, Double> probabilities;
    // The current state of the field.
    private Field field;
    // The current state of the plant field.
    private Field plantField;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    private Random rand;    

    private Time time;    
    private Disease disease;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        time = new Time();
        animals = new ArrayList<>();
        plants = new ArrayList<>();

        setProbabilities();
        field = new Field(depth, width);
        plantField = new Field(depth, width);
        rand = Randomizer.getRandom();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        setColor();

        // Setup a valid starting point.
        reset();
    }

    /**
     * Release a disease into the field which can infect animals.
     * Set a random animal infected with the disease.
     */
    public void releaseDisease()
    {
        disease = new Disease(0.1, 3, 5, 0.5); 
        Collections.shuffle(animals, rand);
        Animal animal = animals.get(0);
        animal.setInfected();
        Animal.setDisease(disease);
    }

    /**
     * Release a vaccine which makes all animals not infected.
     */
    public void releaseVaccine()
    {
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.isInfected()) {
                animal.setNotInfected();
            }
        }
        Animal.setDisease(null);
    }

    /**
     * Set the creation probabilities for each sea life.
     */
    private void setProbabilities()
    {
        probabilities = new HashMap<>();
        probabilities.put(Shark.class, 0.04);
        probabilities.put(Shrimp.class, 0.09);
        probabilities.put(Squid.class, 0.05);
        probabilities.put(JellyFish.class, 0.09);
        probabilities.put(Dolphin.class, 0.05);
        probabilities.put(Plant.class, 0.40);
    }

    /**
     * Set a color for each animal.
     * If animal is infected, they change color to black.
     */
    private void setColor()
    {  
        view.setColor(Shrimp.class, Color.ORANGE);
        view.setColor(Shark.class, new Color(45,114,178));
        view.setColor(Dolphin.class, new Color(228,86,60));
        view.setColor(Squid.class, new Color(140,218,149));
        view.setColor(JellyFish .class, new Color(191,136,187));
    }

    /**
     * Create plants into the plant field.
     */
    private void createPlants()
    {        
        List<Location> freeLocations = plantField.getFreeLocations();
        for (Location location : freeLocations) 
        {
            if (rand.nextDouble() <= probabilities.get(Plant.class)) {
                Plant plant = new Plant(plantField, location, false);
                plants.add(plant);
            }
        }
    }

    /**
     * Randomly populate the field with the given animals.
     */
    private void populate()
    {
        field.clear();
        plantField.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                for (Class key: probabilities.keySet()) {
                    if (rand.nextDouble() <= probabilities.get(key)) {
                        Location location = new Location(row, col);
                        if (key.equals(Shrimp.class)) {
                            Shrimp shrimp = new Shrimp(true, field, location, plantField);
                            animals.add(shrimp);
                        }
                        else if (key.equals(JellyFish.class)) {
                            JellyFish jellyFish = new JellyFish(true, field, location, plantField);
                            animals.add(jellyFish);
                        }
                        else if (key.equals(Shark.class)) {
                            Shark shark = new Shark(true, field, location);
                            animals.add(shark);
                        }
                        else if (key.equals(Dolphin.class)) {
                            Dolphin dolphin = new Dolphin(true, field, location);
                            animals.add(dolphin);
                        }
                        else if (key.equals(Squid.class)) {
                            Squid squid = new Squid(true, field, location);
                            animals.add(squid);
                        }
                        else if (key.equals(Plant.class)) {
                            Plant plant = new Plant(plantField, location, true);
                            plants.add(plant);
                        }                        
                    }
                }                
            }
        }
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each sea life.
     */
    public void simulateOneStep()
    {
        step++;
        time.incrementTime();
        createPlants();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all plants grow.        
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.incrementGrowth();
        }
        // Let all animals act.        
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, time.getTime());
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field, time.getTime());
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;

        time.reset();
        Temperature.reset();
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, time.getTime());
    }        

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
