import java.util.Random;
/**
 * A class representing a plant.
 *
 * @version 2021.03.02
 */
public class Plant extends SeaLife
{    
    private int steps;     // The length of life.
    private boolean fullyGrown;    // True if the plant is fully grown and can be eaten.
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomGrow If true, the plant will have random age.
     */
    public Plant(Field field, Location location, boolean randomGrow)
    {
        super(field, location); 
        if(randomGrow) {
            fullyGrown = rand.nextDouble() <= 0.5;
        }
        else {
            fullyGrown = false;
        }
    }
    
    /**
     * After the plant has reached an age of 3, then it is fully grown and can be eaten.
     */
    public void incrementGrowth()
    {
        steps++;
        if (steps == 3) {
            setFullyGrown();
        }
    }    
    
    /**
     * Set the plant to be fully grown.
     */
    private void setFullyGrown()
    {
        fullyGrown = true;
    }

    /**
     * @return True if the plant is fully grown, else false.
     */
    public boolean IsFullyGrown()
    {
        return fullyGrown;
    }
}
