
/**
 * A class that represents a disease.
 * The disease can spread and infect animals throughout the field.
 *
 * @version 2021.03.02
 */
public class Disease
{
    private double mortalityRate;
    private int infectionRadius;
    private int healingTime;
    private double infectionProbability;

    /**
     * Create a new disease to the field.
     * @param mortalityRate The probability of the animal dying.
     * @param infectionRadius The radius from a particular location where it can infect other animals.
     * @param healingTime The longest period an animal can be infected with this disease.
     * @param infectionProbability The probability in which an animal can be infected.
     */
    public Disease(double mortalityRate, int infectionRadius, int healingTime, double infectionProbability)
    {
        this.mortalityRate = mortalityRate;
        this.infectionRadius = infectionRadius;
        this.healingTime = healingTime;
        this.infectionProbability = infectionProbability;
    }

    /**
     * @return The mortality rate.
     */
    public double getMortalityRate()
    {
        return mortalityRate;
    }
    
    /**
     * @return The infection radius.
     */
    public int getInfectionRadius()
    {
        return infectionRadius;
    }
    
    /**
     * @return The healing time.
     */
    public int getHealingTime()
    {
        return healingTime;
    }
    
    /**
     * @return The infection probability.
     */
    public double getInfectionProbability()
    {
        return infectionProbability;
    }
}
