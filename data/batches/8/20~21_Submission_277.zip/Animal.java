import java.util.List;
import java.util.Random;
import java.util.HashMap;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.02
 */
public abstract class Animal extends SeaLife
{    
    private boolean female;
    protected int foodLevel;
    protected int age;

    private boolean infected;
    // The disease that is infecting all the animal in the current field.
    private static Disease disease;
    private int infectedPeriod;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        infected = false;
        setGender();
        setFoodValue();
        if(randomAge) {
            age = rand.nextInt(getMaxAge());            
            foodLevel = rand.nextInt(getMaxFoodValue());
        }
        else {
            age = 0;            
            foodLevel = getMaxFoodValue();
        }
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param time The current time when the animal is acting.
     */
    abstract public void act(List<Animal> newAnimals, int time);

    /**
     * Set the disease to the current field for all the animals.
     * @param d The disease given to the field.
     */
    public static void setDisease(Disease d)
    {
        disease = d;
    }

    /**
     * @return The current age of the animal.
     */
    public int getAge()
    {
        return age;
    }

    /**
     * @return True if the animal is infected, else false.
     */
    public boolean isInfected()
    {
        return infected;
    }

    /**
     * @return The length of time since the animal is infected.
     */
    public int getInfectedPeriod()
    {
        return infectedPeriod;
    }

    /**
     * Set the animal infected.
     */
    public void setInfected()
    {
        infected = true;
    }

    /**
     * Set the animal not infected.
     */
    public void setNotInfected()
    {
        infected = false;
        infectedPeriod = 0;
    }    

    /**
     * @return Return the given disease in the field.
     */
    public Disease getDisease()
    {
        return disease;
    }

    /**
     * Check if the adjacent animal and the animal in the current location is infected.
     * If the adjacent animal is infected and the current animal is not, then this animal might be infected.
     * If current animal is infected, then this animal might die or it can be healed.
     */
    public void checkForDisease()
    {
        Disease disease = getDisease();

        if (disease != null && !isInfected() && foundDiseaseAdjacentLocations(getLocation(), disease.getInfectionRadius())) {
            // The animal might be infected depending on the infection probability.
            if (rand.nextDouble() <= disease.getInfectionProbability()){
                setInfected();
                // The animal might die depending on the mortality rate.
                if (rand.nextDouble() <= disease.getMortalityRate()) {
                    setDead();
                }
            }
        }        
        else if (isInfected() && getInfectedPeriod() < disease.getHealingTime()) {
            if (rand.nextDouble() <= disease.getMortalityRate()) {
                setDead();
            }
            else {
                infectedPeriod++;
            }
        }
        else {
            setNotInfected();
        }
    }

    /**
     * Set a random gender to the given animal.
     */
    private void setGender() 
    {
        Random rand = Randomizer.getRandom();
        female = rand.nextDouble() <= 0.5;
    }

    /**
     * Check whether the animal is a female or not.
     * @return True if the animal is female.
     */
    public boolean isFemale()
    {
        return female;
    }

    /**
     * @return The maximum food value of the given possible food sources.
     */
    public abstract int getMaxFoodValue();

    /**
     * Set the food value for each food source.
     */
    public abstract void setFoodValue();

    /**
     * @return The maximum age of the animal.
     */
    public abstract int getMaxAge();

    /**
     * @return The age when the animal can breed.
     */
    public abstract int getBreedingAge();

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * It can only breed if the male and female meet.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(isFemale() && canBreed() && rand.nextDouble() <= getBreedingProbability() && foundMaleAdjecentLocations(getLocation(), getBreedingDistance())) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Searching the adjacent locations for a male animal,
     * with the given radius from current animal's location.
     * @param location The location of the current animal.
     * @param distance The radius from the given location where the animal can search.
     * @return True if there is a male animal at the adjacent locations, false otherwise.
     * 
     * The implementation for this searching algorithm was found in the given URL below
     * and it is slightly changed to match the project.
     * https://stackoverflow.com/questions/652106/finding-neighbours-in-a-two-dimensional-array
     */
    public boolean foundMaleAdjecentLocations(Location location, int distance)
    {
        int row = location.getRow();
        int col = location.getCol();
        Field field = getField();
        int depth = field.getDepth();
        int width = field.getWidth();
        Object[][] storageField = field.getField();
        if (depth > 0) {
            for (int x = Math.max(0, row - distance); x <= Math.min(row + distance, depth - 1); x++) {
                for (int y = Math.max(0, col - distance); y <= Math.min(col + distance, width - 1); y++){
                    Animal animal = (Animal) storageField[x][y];
                    if ((x != row || y != col) && animal != null && !animal.isFemale() && animal.canBreed()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Searching the adjacent locations for an infected animal,
     * with the given radius from current animal's location.
     * @param location The location of the current animal.
     * @param distance The radius from the given location where the animal can search.
     * @return True if there is an infected animal at the adjacent locations, false otherwise.
     * 
     * The implementation for this searching algorithm was found in the given URL below
     * and it is slightly changed to match the project.
     * https://stackoverflow.com/questions/652106/finding-neighbours-in-a-two-dimensional-array
     */
    public boolean foundDiseaseAdjacentLocations(Location location, int distance)
    {
        int row = location.getRow();
        int col = location.getCol();
        Field field = getField();
        int depth = field.getDepth();
        int width = field.getWidth();
        Object[][] storageField = field.getField();
        if (depth > 0) {
            for (int x = Math.max(0, row - distance); x <= Math.min(row + distance, depth - 1); x++) {
                for (int y = Math.max(0, col - distance); y <= Math.min(col + distance, width - 1); y++){
                    Animal animal = (Animal) storageField[x][y];
                    if ((x != row || y != col) && animal != null && animal.isInfected()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * @return The radius of the distance where it can meet another gender.
     */
    public abstract int getBreedingDistance();

    /**
     * @return The breeding probability of the animal.
     */
    public abstract double getBreedingProbability();

    /**
     * @return The maximum litter size of the animal.
     */
    public abstract int getMaxLitterSize();

    /**
     * Decrease the food level of the animal.
     * If the food level is lesser than 0, it will die.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increase the age of the animal.
     * If the animal is older than the maximum age, then it will die.
     */
    protected void incrementAge()
    {
        age++;
        if (age > getMaxAge()) 
        {
            setDead();
        }
    }

    /**
     * @return A collection of the food value of the food sources.
     */
    protected abstract HashMap<Object, Integer> getFoodValue();

    /**
     * @return The food level of the animal.
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }
}
