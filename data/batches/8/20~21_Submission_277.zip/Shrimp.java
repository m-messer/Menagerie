import java.util.List;
import java.util.Random;
import java.util.HashMap;

/**
 * A model of a shrimp.
 * Shrimps age, move, breed, eat plants, and die.
 *
 * @version 2021.03.02
 */
public class Shrimp extends Herbivore
{
    // The age at which a shrimp can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a shrimp can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a shrimp breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // A collection of the food values of plants.
    private HashMap<Object, Integer> FOOD_VALUE;
    // The radius to find an opposite gender to breed.
    private static final int BREEDING_DISTANCE = 7;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a shrimp. A shrimp can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the shrimp will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param plantField The field where plants stored.
     */
    public Shrimp(boolean randomAge, Field field, Location location, Field plantField)
    {
        super(randomAge, field, location, plantField);
    }

    /**
     * This is what the shrimp does during the day time: it eats
     * plants, breed and might die of hunger. In the process, 
     * it may die of old age.
     * @param newShrimps A list to return newly born shrimp.
     * @param time The current time when the animal is acting.
     */
    public void act(List<Animal> newShrimps, int time)
    {
        if (getLocation() != null) {
            checkForDisease();
        }
        incrementAge();
        if(time < 4 && time < 20) {
            incrementHunger();
            if (isAlive()) {
                giveBirth(newShrimps);
                findFood();
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Set a food value for plants.
     */
    public void setFoodValue()
    {
        FOOD_VALUE = new HashMap<>();
        FOOD_VALUE.put(Plant.class, 10);
    }

    /**
     * @return A collection of the food values of each plant.
     */
    public HashMap<Object, Integer> getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * @return The maximum food value of the given possible food sources.
     */
    public int getMaxFoodValue()
    {
        int max = 0;
        for(Object key : FOOD_VALUE.keySet()) {
            int current = FOOD_VALUE.get(key);
            if(current > max) {
                max = current;
            }
        }
        return max;
    }

    /**
     * @return The maximum age of the shrimp.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Check whether or not this shrimp is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newShrimps A list to return newly born shrimps.
     */
    private void giveBirth(List<Animal> newShrimps)
    {
        Field field = getField();
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        // New shrimps are born into adjacent locations.
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Shrimp young = new Shrimp(false, field, loc, getPlantField());
            newShrimps.add(young);
        }
    }

    /**
     * @return The radius of the distance where it can meet another gender.
     */
    public int getBreedingDistance()
    {
        return BREEDING_DISTANCE;
    }

    /**
     * @return The breeding probability of the shrimp.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return The maximum litter size of the shrimp.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return The age when the shrimp can breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}
