/**
 * A class that represents time in hours for the simulation.
 *
 * @version 2021.03.02
 */
public class Time
{    
    private int time;

    /**
     * Set the initial time to 0.
     */
    public Time()
    {
        reset();
    }

    /**
     * Increment the time and the time is within 24 hours.
     */
    public void incrementTime()
    {
        time = (time + 1) % 24;
    }
    
    /**
     * @return The current time.
     */
    public int getTime()
    {
         return time;
    }
    
    /**
     * Set the time to 0.
     */
    public void reset()
    {
        time = 0;
    }
}
