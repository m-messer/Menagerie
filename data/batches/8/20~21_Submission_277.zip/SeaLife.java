/**
 * A superclass representing the living creatures in the sea.
 *
 * @version 2021.03.02
 */
public abstract class SeaLife
{
    private boolean alive;
    private Field field;
    private Location location;

    /**
     * Create a new sea life living creature at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public SeaLife(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
        alive = true;
    }

    /** 
     * @return Return the current field where the sea life is at.
     */
    public Field getField()
    {
        return field;
    }

    /**
     * @return Return the current location of the given sea life.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * @return True if the animal is alive, else false.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Set the given sea life to not alive.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;

        field.place(this, newLocation);
    }
}
