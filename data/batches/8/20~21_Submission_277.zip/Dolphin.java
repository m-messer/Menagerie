import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;

/**
 * A model of a dolphin.
 * Dolphins age, move, breed, eat shrimps and jellyfishes, and die.
 *
 * @version 2021.03.02
 */
public class Dolphin extends Predator
{
    // The age at which a dolphin can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a dolphin can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a dolphin breeding.
    private static final double BREEDING_PROBABILITY = 0.27;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A collection of the food values of preys.
    private HashMap<Object, Integer> FOOD_VALUE;
    // The radius to find an opposite gender to breed.
    private static final int BREEDING_DISTANCE = 15;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a dolphin. A dolphin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the dolphin will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Dolphin(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the dolphin does most of the time: it hunts for
     * preys. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newDolphins A list to return newly born dolphins.
     * @param time The current time when the animal is acting.
     */
    public void act(List<Animal> newDolphins, int time)
    {
        if (getLocation() != null) {
            checkForDisease();
        }
        incrementAge();
        incrementHunger();
        
        //if temperature is too cold the dolphin will move at a slower rate
        if(isAlive() && (Temperature.getTemp() > 10 || getAge() % 2 == 0)) {
            giveBirth(newDolphins);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Set a food value for each prey.
     */
    public void setFoodValue()
    {
        FOOD_VALUE = new HashMap<>();
        FOOD_VALUE.put(Shrimp.class, 9);        
        FOOD_VALUE.put(JellyFish.class, 9);
    }

    /**
     * @return A collection of the food values of each prey.
     */
    protected HashMap<Object, Integer> getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * @return The maximum food value of the given possible food sources.
     */
    public int getMaxFoodValue()
    {
        int max = 0;
        for(Object key : FOOD_VALUE.keySet()) {
            int current = FOOD_VALUE.get(key);
            if(current > max) {
                max = current;
            }
        }
        return max;
    }

    /**
     * @return The maximum age of the dolphin.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Check whether or not this dolphin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDolphins A list to return newly born dolphins.
     */
    private void giveBirth(List<Animal> newDolphins)
    {
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        // New dolphins are born into adjacent locations.
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Dolphin young = new Dolphin(false, field, loc);
            newDolphins.add(young);
        }
    }

    /**
     * @return The radius of the distance where it can meet another gender.
     */
    public int getBreedingDistance()
    {
        return BREEDING_DISTANCE;
    }

    /**
     * @return The breeding probability of the dolphin.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return The maximum litter size of the dolphin.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return The age when the dolphin can breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}
