import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * Simulator Class - the central timing class of the Predator
 *      and Prey Project
 * 
 * This is the central simulator class of the Predator and Prey
 * project. this class initalizes the manager classes for the
 * graphical display, animals, plants and events as well as
 * sets all the connections between them. this class holds
 * the simulation loop for the project and calls the managers
 * every step to do actions.
 *
 * 
 * @version 2021.02.28
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    // The current step of the simulation.
    private int step;

    // A graphical view of the simulation.
    private SimulatorView view;
    
    //the managers for the simulations objects
    private AnimalManager animalManager;
    private EventManager eventManager;
    private PlantManager plantManager;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }//end of default constructor

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        //initalizes the object managers
        animalManager = new AnimalManager(depth, width);
        eventManager = new EventManager(depth, width);
        plantManager = new PlantManager(depth, width);
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        //sets animal manager's reference to other required managers
        animalManager.setEventManager(eventManager);
        animalManager.setPlantManager(plantManager);
        
        //sets plant manager's reference to event manager
        plantManager.setEventManager(eventManager);
        
        //sets event manager's reference to other required managers
        eventManager.setAnimalManager(animalManager);
        eventManager.setPlantManager(plantManager);
        
        //sets the UI manager's reference to other required managers
        view.setAnimalManager(animalManager);
        view.setEventManager(eventManager);
        
        //sets UI manager's reference colours for different
        //object types for the simulation display
        view.setColor(Pheasant.class, Color.ORANGE);
        view.setColor(Coyote.class, Color.BLUE);
        view.setColor(Wolf.class, Color.GREEN);
        view.setColor(Cougar.class, Color.BLACK);
        view.setColor(Deer.class, Color.MAGENTA);
        view.setColor(Fire.class, Color.RED);

        // Setup a valid starting point.
        reset();
    }//end of initalized constructor

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(500);
    }//end of run long simulation

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
        
        //uncomment this for terminal debug info
        animalManager.DEBUG();
        plantManager.DEBUG();
        System.out.println("************************************\n");
        
    }//end of simulate

    /**
     * Run the simulation from its current state for a single step.
     * Done by calling the managers to cycle thier objects
     */
    public void simulateOneStep()
    {
        step++;

        animalManager.cycleAnimals();
        plantManager.cyclePlants();
        eventManager.cycleEvents(step);
        
        Randomizer.reset();
        
        view.showStatus(step);
    }//end of simulate one step

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        
        animalManager.reset();
        eventManager.reset();
        plantManager.reset();

        // Show the starting state in the view.
        view.showStatus(step);
    }//end of reset

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        } //end of try delay
        catch (InterruptedException ie) {
            // wake up
        } //end of catch
    }//end of delay
}//end of Simulator class
