import java.util.Random;

/**
 * Plant Class - represents a plant in the
 *  Predator and Prey Project
 *  
 * Plants will grow each step depending on
 *  weather conditions and reset to zero 
 *  growth when eaten.
 *
 * 
 * @version 2021.02.28
 */
public class Plant
{
    //used to generate random values
    protected static final Random rand = Randomizer.getRandom();

    //Array for Debugging values
    private static int[] plantsDebug = new int[2];

    //Plant's universal constants
    private final int FULLY_GROWN = 100;
    private final int RAIN_GROWTH_VALUE = 5;
    private final int NO_RAIN_LIMIT = 30;
    private final int DROUGHT_DAMAGE_MIN = 50;
    private final int FOOD_VALUE = 10;

    //Fields for instances of plants
    private int growthStage;
    private int sinceLastRain;

    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;

    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Location location)
    {
        //sets random inital growth value for a plant
        growthStage = rand.nextInt(FULLY_GROWN) + 1;

        //sets the plant in the field
        this.field = field;
        setLocation(location);
    }//end of constructor

    //****** Public Methods *********

    /**
     * cycles the plant update for a step in the simulation
     * @param isRaining A boolean value to tell if its raining
     */
    public void cycle(EventManager eventManager)
    {
        if(eventManager.isHabitableLocation(getLocation())){
            if(eventManager.isRaining()){
                //raining so resets since last rain
                sinceLastRain = 0;
                growthStage += RAIN_GROWTH_VALUE;
            }//end of if raining
            else{
                //if it has rained recently and can still grow
                if(sinceLastRain < NO_RAIN_LIMIT){
                    growthStage++;
                }//end of if

                //else if it has reached no rain damage threshold
                //so plant regresses to as low as zero growth stage
                else if(sinceLastRain >= DROUGHT_DAMAGE_MIN && growthStage > 0){
                    growthStage--;
                }//end of else if

                sinceLastRain++;
            }//end of else not raining
        }//end of if plant's location is habitable
        
    }//end of cycle

    /**
     * called when a plant is eaten
     * resets its growth stage to zero
     */
    public void eaten()
    {
        growthStage = 0;

        //increments debug value
        debugEaten();
    }//end of eaten

    /**
     * @return boolean if the plant is grown 
     *  enough to eat
     */
    public boolean isEatable()
    {
        return (growthStage >= FULLY_GROWN);
    }//end of is Eatable

    /**
     * @return food value of plant
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }//end of get food value

    //******** Protected Methods **********

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }//end of get location

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }//end of set location

    //********** Debugging Methods

    /**
     * increments debug value for plants
     *  eaten successfuly 
     */
    public void debugEaten(){
        plantsDebug[0]++;
    }//end of eaten

    /**
     * increments debug value for plants
     *  eaten unsuccessfuly
     */
    public void debugTriedEaten(){
        plantsDebug[1]++;
    }//end debug tried eaten

    /**
     * prints debug info into terminal
     */
    public static void debugPlants(){
        System.out.println("Plants Eaten: " + plantsDebug[0] + ", Plants Tried: " + plantsDebug[1]);
    }//end of debug plants

}//end of Plant
