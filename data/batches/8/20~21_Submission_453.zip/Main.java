
/**
 * Main Class - main method of Predator 
 *  and Prey Project
 *
 * 
 * @version 2021.02.28
 */

public class Main
{

    public static void main(String[] args){
        Simulator sim = new Simulator();
        sim.runLongSimulation();
    }//end of main emthod

}//end of Main Class

