import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * PlantManager Class - manages the plant objects of
 *      the Predator and Prey Project
 *      
 * This class holds the plants' field and is incharge
 *  of cycling the plant objects on new step as well as
 *  reseting and populating the plant field 
 *
 * 
 * @version 2021.02.28
 */
public class PlantManager
{
    //reference to the event manager object
    private EventManager eventManager;

    //List of plant object as well as a field
    //to manage the plant objects
    private List<Plant> plants;
    private Field plantField;

    /**
     * Constructor for objects of class PlantManager
     * @param depth The depth (aka height) of the field
     *  in rows
     * @param width The width of the field
     *  in columns
     */
    public PlantManager(int depth, int width)
    {
        plants = new ArrayList<>();
        plantField = new Field(depth, width);
    }//end of plantmanager constructor

    //********* public methods ***************
    
    /**
     * called on new step of simulation to
     * cycle all the plants updates for that step
     */
    public void cyclePlants()
    {
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.cycle(eventManager);
        }//end of for every plant object

    }//end of cycle plants 
    
    /**
     * Resets plants objects by clearing the list then
     *  repopulating the field
     */
    public void reset(){
        plants.clear();
        populate();
    }//end of reset
    
    /**
     * gets the plant object from a specific location
     *  in the field
     * @param location The location object used to reference
     *  the field
     * @return the plant object found at that location or
     *  null if none were found
     */
    public Plant getPlantAt(Location location)
    {
        return ((Plant) plantField.getObjectAt(location));
    }//end of get Plant at

    /**
     * @return the field used to store the plants
     */
    public Field getField()
    {
        return plantField;
    }//end of get plant field
    
    /**
     * Set the eventmanager object to reference
     * @param eventManager The eventManger object
     */
    public void setEventManager(EventManager eventManager)
    {
        this.eventManager = eventManager;
    }//end of set event manager

    //***** private methods **********
    
    /**
     * populates the plant field with a plant
     * in every location on the field
     */
    private void populate()
    {
        plantField.clear();
        
        for(int row = 0; row < plantField.getDepth(); row++) {
            for(int col = 0; col < plantField.getWidth(); col++) {
                Location location = new Location(row, col);
                Plant plant = new Plant(plantField, location);
                plants.add(plant);
            }//end of for all columns of fiels
        }//end of for all rows of field
        
    }//end of populate
    
    //******** Debugging methods *********
    
    /**
     * Prints plant debugging info into the
     *  terminal
     */
    public void DEBUG(){
        //debug
        Plant.debugPlants();
    }//end of DEBUG
    
} //end of PlantManager Class
