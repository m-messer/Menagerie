import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * Animal Class - abstract representation of the
 *  general behaviour of a animal in the
 *  Predator and Prey Project
 *  
 * This class implements the generic behaviours
 *  of mating and disease. animal specific behaviour 
 *  comes from the subclass implementation of act 
 *  as well as the subclass constants retrieved 
 *  by abstract methods
 *
 * 
 * @version 2021.02.28
 */
public abstract class Animal
{
    //used to generate random values
    protected static final Random rand = Randomizer.getRandom();
    
    //constants for disease behaviour
    protected static final double DISEASE_PROBABILITY = 0.05;
    protected static final double DISEASE_SPREAD_PROBABILITY = 0.10;
    protected static final double DISEASE_MORTALITY_RATE = 0.05;
    
    // boolean fields for general animal characteristics
    private boolean alive;
    private boolean isFemale;
    private boolean diseased;
    
    // int fields general animal values
    private int age;
    private int foodLevel;
    
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    
    
    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge True if not new born
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        setSex();
        
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(getMaxFoodLevel());
        }//end of if animal is random age
        else {
            age = 0;
            foodLevel = getMaxFoodLevel();
        }//end of else new born
        
        this.field = field;
        setLocation(location);
    }//end of Animal Constructor
    
    //******** Basic Animal Functionality Methods *********
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }//end of is Alive
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }//end of if location is null
    }//end of set dead
    
    /**
     * check what sex the animal is
     * @return true if female or false if male
     */
    protected boolean isFemale()
    {
        return isFemale;
    }//end of isFemale
    
    /**
     * Sets the sex of the animal randomly
     */
    protected void setSex()
    {
        isFemale = rand.nextBoolean();
    }//end of setSex
    
    /**
     * Animal consumes food
     * @param foodValue The int value of the food
     */
    protected void eatFood(int foodValue)
    {
        foodLevel += foodValue;
        if(foodLevel > getMaxFoodLevel()){
            foodLevel = getMaxFoodLevel();
        }//end if food level is greater then max
    }//end of eat food
    
    /**
     * Increase the age. This could result in the Animals's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
            debugAgeDeath();
        }//end of if animal is too old
    }//end of increment age

    /**
     * Make this Animal more hungry. 
     *  This could result in the Animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
            debugHungerDeath();
        }//end of if animal starved
    }//end of icrement hunger
    
    //******** Breeding Methods ******
    
    /**
     * Looks to see if there is a potential mate in to procreate
     *  only if current Animal is female 
     * @param newAnimals A list to return newly born Animals.
     */
    protected void findMate(List<Animal> newAnimals){
        if(isFemale()){
            boolean foundMate = false;
            
            //gets locations to search
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation(), getBreedingRange());
            
            //loops and interates to find mate
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext() && !foundMate) {
                Location where = it.next();
                Object obj = field.getObjectAt(where);
                
                //checks there is a object and if its the same animal type
                if(obj != null && obj.getClass().equals(this.getAnimalType())) {
                    Animal animal = (Animal) obj;
                    
                    //checks to see animal is alive and of opposite sex
                    if(animal.isAlive() && isFemale() != animal.isFemale()) { 
                        giveBirth(newAnimals);
                        foundMate = true;
                    }//end of if is Alive and opposite gender
                }//end of of if is same animal type
            }//end of while has next location
        }//end of if is female
    }//end of findMate

    /**
     * Check whether or not this Animal is able to give birth at 
     * this step. New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born Animals.
     */
    private void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = createChild(field, loc);
            newAnimals.add(young);
        }//end of for births and free locations
    }//end of give birth

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }//end of breed

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if can breed false if otherwise
     */
    private boolean canBreed()
    {
        return age >= getBreedingAge();
    }//end of can breed
    
    //********** Disease Methods *************
    
    /**
     * sets if the animal is diseased
     * @param diseased True if diseased, false if healthy
     */
    protected void setDiseased(boolean diseased)
    {
        this.diseased = diseased;
    }//end of set diseased
    
    /**
     * returns if the animal is diseased
     * @return true if diseased, false if healthy
     */
    protected boolean isDiseased()
    {
        return diseased;
    }//end of is diseased
    
    /**
     * checks if diseased and either
     *  tries to spread if sick
     *  or tries to catch it randomly if healthy
     */
    protected void checkDisease()
    {
        if(isDiseased()){
            spreadDisease();
        }//end of if sick
        else{
            catchDisease();
        }//end of else healthy
    }//end of check disease

    /**
     * tries to spread the disease
     *  to surrounding animals
     */
    private void spreadDisease()
    {
        if(isAlive()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object obj = field.getObjectAt(where);
                if(obj != null && obj instanceof Animal){
                    Animal animal = (Animal) obj;
                    giveDisease(animal);
                }//end of if there is animal at location
            }//end of while has next location
            surviveDisease();
        }//end of if animal is alive
    }//end of spread disease

    /**
     * Tries to give the disease to an animal
     * @param animal The animal that may contract it
     */
    private void giveDisease(Animal animal)
    {
        if(rand.nextDouble() <= DISEASE_SPREAD_PROBABILITY) {
            animal.setDiseased(true);
        }//end of if animal catches disease
    }//end of give disease

    /**
     * Tries to survive disease
     */
    private void surviveDisease()
    {
        if(rand.nextDouble() <= DISEASE_MORTALITY_RATE) {
            setDead();
            debugDiseaseDeath();
        }//end of if animal succumbs to disease
        else{
            setDiseased(false);
        }//else animal survives disease
    }

    /**
     * Check to see if animal catches the
     *  disease enviromentally
     */
    private void catchDisease()
    {
        if(rand.nextDouble() <= DISEASE_PROBABILITY) {
            setDiseased(true);
        }//end of if animal catches disease
    }//end of catch disease
    
    //*********** Abstract Methods **********
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, EventManager eventManager);
    
    /**
     * gets food chain level from the animal
     *  types that inherit from this class
     * @return int value for food chain level
     *  (the higher the value the higher in the
     *  food chain)
     */
    abstract protected int getFoodChainLevel();
    
    /**
     * gets food value of the animal
     *  types that inherit from this class
     * @return int value for food value
     *  (the number of food points the
     *  animal give when consumed)
     */
    abstract protected int getFoodValue();
    
    /**
     * gets max age from the animal
     *  types that inherit from this class
     * @return int value for max age of 
     *  that animal
     */
    abstract protected int getMaxAge();
    
    /**
     * gets max food level from the animal
     *  types that inherit from this class
     * @return int value for max food level
     *  (max food points an animal can store)
     */
    abstract protected int getMaxFoodLevel();
    
    /**
     * gets breeding range from the animal
     *  types that inherit from this class
     * @return int value for breeding range
     *  (int radius it uses to search for 
     *  a mate)
     */
    abstract protected int getBreedingRange();
    
    /**
     * gets breeding age from the animal
     *  types that inherit from this class
     * @return int value for breeding age
     *  (minimum age required to breed)
     */
    abstract protected int getBreedingAge();
    
    /**
     * gets breeding probability from the animal
     *  types that inherit from this class
     * @return double value for breeding probability
     *  (the chances that if it finds a mate it
     *  has offspring)
     */
    abstract protected double getBreedingProbability();
    
    /**
     * gets max litter size from the animal
     *  types that inherit from this class
     * @return int value for max litter size
     *  (the max amount of offspring the animal
     *  can have in one mating)
     */
    abstract protected int getMaxLitterSize();
    
    /**
     * gets new animal object from the animal
     *  types that inherit from this class
     * @param field The field the new object is
     *  placed in
     * @param location The location in the field
     *  the new animal is placed in
     * @return the new animal object
     */
    abstract protected Animal createChild(Field field, Location location);
    
    /**
     * gets Class object from the animal
     *  types that inherit from this class
     * @return Class object of the animal
     */
    abstract protected Class getAnimalType();
    
    //**************** General ********************
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }//end of get location
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }//end of set location
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }//end of get field
    
    //********** Abstract Debug Methods **********
    
    /**
     * Used for debugging to set increment
     *  disease death counter of animal type
     *  from general animal methods
     */
    abstract protected void debugDiseaseDeath();
    
    /**
     * Used for debugging to set increment
     *  eaten death counter of animal type
     *  from general animal methods
     */
    abstract protected void debugEattenDeath();
    
    /**
     * Used for debugging to set increment
     *  age death counter of animal type
     *  from general animal methods
     */
    abstract protected void debugAgeDeath();
   
    /**
     * Used for debugging to set increment
     *  hunger death counter of animal type
     *  from general animal methods
     */
    abstract protected void debugHungerDeath();
    
}//end of Animal Class
