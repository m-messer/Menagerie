import java.util.List;
import java.util.Iterator;

/**
 * Herbivore Class - abstract representation of the
 *  general behaviour of a hebivore animal in the
 *  Predator and Prey Project
 *
 * This class implements the finding food behaviour
 *  of herbivore/strictly prey animals
 *
 * 
 * @version 2021.02.28
 */
public abstract class Herbivore extends Animal
{
    //field to reference plant object
    private Field plantField;

    /**
     * Creates a new carnivore
     * 
     * @param randomAge true if not new born
     * @param field The field it will be in
     * @param plantField The field to refernce
     *  plant objects from
     * @param location The location in the
     *  field it will be in
     */
    public Herbivore(boolean randomAge, Field field, Field plantField, Location location)
    {
        super(randomAge, field, location);
        this.plantField = plantField;
    }//end of herbivore constructor

    /**
     * Tries to find a plant that the
     *  current animal can eat within
     *  adjacent locations
     * @return location if food found or
     *  null if no food found
     */
    protected Location findFood(EventManager eventManager)
    {
        Field field = getField();
        List<Location> adjacent = field.getFreeAdjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Plant plant = (Plant) plantField.getObjectAt(where);
            if(plant.isEatable() && eventManager.isHabitableLocation(where)) { 
                plant.eaten();
                eatFood(plant.getFoodValue());
                return where;
            }//end of if plant is eatable
        }//end of while more locations to check
        return null;
    }//end of find food

    /**
     * Returns the herbivore's plant 
     *  reference field
     * @return Field plantField
     */
    protected Field getPlantField(){
        return plantField;
    }//end of get plant field
    
}//end of Herbivore Class
