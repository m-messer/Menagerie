import java.util.List;
import java.util.Random;

/**
 * Fire Class - sub class of LocalizedEvent that
 *  represents an object of forest fire
 *  
 * Fire kills the animal in the location it is
 *  initalized in as well as resetting the plants
 *  growth value. Fire has a chance to spread where
 *  it will create fire objects around itself
 *
 * 
 * @version 2021.02.28
 */
public class Fire extends LocalizedEvent
{
    //used to create random values
    private final static Random rand = new Random();
    
    //constants that determine the length and
    //spreadability of fire
    private final int MAX_LENGTH = 15;
    private final int MAX_SPREAD = 4;
    private final double SPREAD_PROBABILITY = 0.10;
    
    //how many more steps the fire has left
    private int currentLength;
    
    //object references to manager classes
    private AnimalManager animalManager;
    private PlantManager plantManager;
    
    /**
     * Constructor for objects of class Fire
     */
    public Fire(Field field, Location location, AnimalManager animalManager, PlantManager plantManager)
    {
        super(field, location);
        setHabitable(false);
        
        this.animalManager = animalManager;
        this.plantManager = plantManager;
        
        currentLength = rand.nextInt(MAX_LENGTH);
        burn();
        
    }//end of fire constructor

    /**
     * Overrides the act method and attempts to
     *  spread the fire when it is called
     * @override
     * @param newLocalEvents The list that will
     *  have all new fire objects created in act
     */
    public void act(List<LocalizedEvent> newLocalEvents)
    {
        checkActive();
        if(isActive() && rand.nextDouble() < SPREAD_PROBABILITY) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            
            int spreadNum = rand.nextInt(MAX_SPREAD);
            for(int s = 0; s < spreadNum && free.size() > 0; s++) {
                Location newLocation = free.remove(0);
                Fire newFire = new Fire(getField(), newLocation, animalManager, plantManager);
                newLocalEvents.add(newFire);
            }//end of for number of spreads
        }//end of if fire spreads
        currentLength++;
    }//end of act
    
    /**
     * Checks if fire is active, if it
     *  isnt then it deactivates fire
     */
    public void checkActive(){
        if(currentLength >= MAX_LENGTH){
            setDeactive();
        }
    }//end of check Active
        
    //******* Private Method ******
    
    /**
     * "burns" location of the fire, ie. kills
     *  animal present if there is one and resets
     *  present plant growth.
     */
    private void burn(){
        Animal animal = animalManager.getAnimalAt(getLocation());
        Plant plant = plantManager.getPlantAt(getLocation());
        if(animal !=  null){
            animal.setDead();
        }//end of if animal exists
        if(plant != null){
            plant.eaten();
        }//end of if plant exists
    }//end of burn
    
}//end of Fire class

