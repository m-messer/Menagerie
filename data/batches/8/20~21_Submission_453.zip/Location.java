/**
 * Location Class - represents a location in the field
 *  class in the Predator and Prey Project
 * 
 * Represent a location in a rectangular grid.
 *
 * 
 * @version 2021.02.28
 */
public class Location
{
    // Row and column positions.
    private int row;
    private int col;

    /**
     * Represent a row and column.
     * @param row The row.
     * @param col The column.
     */
    public Location(int row, int col)
    {
        this.row = row;
        this.col = col;
    }//end of location constructor
    
    /**
     * Implements content equality.
     */
    public boolean equals(Object obj)
    {
        if(obj instanceof Location) {
            Location other = (Location) obj;
            return row == other.getRow() && col == other.getCol();
        }//end of if obj is a location
        else {
            return false;
        } //end of else obj isnt a location
    }//end of equals
    
    /**
     * Return a string of the form row,column
     * @return A string representation of the location.
     */
    public String toString()
    {
        return row + "," + col;
    }//end of to string
    
    /**
     * Use the top 16 bits for the row value and the bottom for
     * the column. Except for very big grids, this should give a
     * unique hash code for each (row, col) pair.
     * @return A hashcode for the location.
     */
    public int hashCode()
    {
        return (row << 16) + col;
    }//end of hash code
    
    /**
     * @return The row.
     */
    public int getRow()
    {
        return row;
    }//end of get row
    
    /**
     * @return The column.
     */
    public int getCol()
    {
        return col;
    }//end of get col
    
}//end of Location Class
