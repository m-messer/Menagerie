import java.util.List;

/**
 * LocalizedEvent Class - abstract representation of the
 *  general behaviour of a localized event in the
 *  Predator and Prey Project
 * 
 * The specifics of how the localized event will
 *  be implemented in the subclass as it implements
 *  the abstract act method
 *
 * 
 * @version 2021.02.28
 */
public abstract class LocalizedEvent
{
    
    //boolean fields for characteristics of event
    private boolean isActive;
    private boolean isHabitable;
    
    //fields to hold where the object is stored
    private Field field;
    private Location location;
    
    /**
     * Constructor for objects of class LocalizedEvent
     * @param field The field the event will be stored in
     * @param location The location in the field the event
     *  will be stored in
     */
    public LocalizedEvent(Field field, Location location)
    {
        isActive = true;
        isHabitable = true;
        this.field = field;
        setLocation(location);
    }//end of LocalizedEvent

    //********* Public Methods ***********
    
    /**
     * Used to remove the event object 
     *  from the simulation
     */
    public void setDeactive()
    {
        isActive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }//end of if location is null
        
    }//end of set deactive
    
    /**
     * returns if the event is active
     * @return true if event is active
     */
    public boolean isActive()
    {
        return isActive;
    }//end of is active
    
    /**
     * returns if events location is habitable
     * @return true if event's location
     *  is habitable while it is active
     */
    public boolean isHabitable()
    {
        return isHabitable;
    }//end of is habitable
    
    //********* Protected Methods ***********
    
    /**
     * used to set if the events location
     *  is habitable while it is active
     */
    protected void setHabitable(boolean isHabitable){
        this.isHabitable = isHabitable;
    } //end of set habitable
    
    /**
     * Sets the location of the event
     * @param newLocation The active location of
     *  the event
     */
    protected void setLocation(Location newLocation)
    {
        location = newLocation;
        field.place(this, newLocation);
    }//end of set Location
    
    /**
     * returns the location of event
     * @return Location of event
     */
    protected Location getLocation()
    {
        return location;
    }//end of get location
    
    /**
     * returns the event's field
     * @return the field the event is
     *  stored in
     */
    protected Field getField()
    {
        return field;
    }//end of get field
    
    //********* Abstract Methods ***********
    
    /**
     * Abstract method to be overwritten to
     *  implement the unique behaviour of 
     *  different localized event types
     * @param newLocalEvents A List that all
     *  newly created events as a result of act
     *  can be added to
     */
    abstract public void act(List<LocalizedEvent> newLocalEvents);
    
}//end of LocalizedEvent Class
