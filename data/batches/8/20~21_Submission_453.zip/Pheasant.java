import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * Pheasant Class - representation of the
 *  Pheasant behaviour in the
 *  Predator and Prey Project
 *
 * This class implements the act method and get methods for fields values.
 *
 * 
 * @version 2021.02.28
 */
public class Pheasant extends Herbivore
{
    //Debuging
    private static int[] death = new int[5];

    // Characteristics shared by all Pheasant (class variables).

    // The age at which a Pheasant can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a Pheasant can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a Pheasant breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The number of fields in which radius the female can find male
    private static final int BREEDING_RANGE = 2;
    // The food value of a single plant. In effect, this is the
    // number of steps a pheasant can go before it has to eat again.
    private static final int FOOD_VALUE = 10;
    // The food chain level to which cougars belong
    private static final int FOOD_CHAIN_LEVEL = 1;
    // The maximum food level the pheasant can reach
    private static final int MAX_FOOD_LEVEL = 10;

    /**
     * Create a new Pheasant. A Pheasant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Pheasant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Pheasant(boolean randomAge, Field field, Field plantField, Location location)
    {
        super(randomAge, field, plantField, location);
    }//end of Pheasant Constructor

     /**
     * This is what the Pheasant does most of the time - it runs 
     * around and eats plants. Sometimes it will breed or die of old age or disease. 
     * Pheasant can also be eaten by predators.
     * @param eventManager Object to check occuring events.
     * @param newPheasant A list to return newly born Deer.
     */
    public void act(List<Animal> newPheasants, EventManager eventManager)
    {
        checkDisease();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            findMate(newPheasants); 
            // Try to move into a free location.
            Location newLocation = findFood(eventManager);
            if(newLocation == null) { 
                // No food found - try to move to a free location.

                List<Location> free = getField().getFreeAdjacentLocations(getLocation());
                for(int i = 0; i < free.size() && newLocation == null; i++){
                    if(eventManager.isHabitableLocation(free.get(i))){
                        newLocation = free.get(i);
                    }//end of if is habitable
                }//end of for loop of free locations

                //debug
                if(newLocation != null) {
                    Plant p = (Plant) getPlantField().getObjectAt(newLocation);
                    p.debugTriedEaten();
                }//end of if location is not null

            }//end of if location is null
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }//end if new location is not null and is habitable
            else {
                // Overcrowding.
                setDead();
                death[1]++;
            }//end of else location is null and not habitable
        }//end of if alive
    }//end of act

    //*******************************OVERRIDIND ABSTRACT METHODS*****************************************
    
    /**
     * gets food chain level of Pheasant
     * @override
     * @return int value for food chain level
     *  (the higher the value the higher in the
     *  food chain)
     */
    @Override
    protected int getFoodChainLevel()
    {
        return FOOD_CHAIN_LEVEL;
    } // end of get food chain level
    
    /**
     * gets food value of Pheasant
     * @override
     * @return int value for food value
     * (the number of food points the
     * Pheasant give when consumed)
     */
    @Override
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    } //end of get food value
    
    /**
     * gets max age of Pheasant
     * @return int value for max age of 
     * Pheasant
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    } //end of get max age
    
    /**
     * gets max food level of Pheasant
     * @return int value for max food level
     *  (max food points a Pheasant can store)
     */
    @Override
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    } //end of get max food level
    
    /**
     * gets breeding range of Pheasant
     * @return int value for breeding range
     *  (int radius it uses to search for 
     *  a mate)
     */
    @Override
    protected int getBreedingRange()
    {
        return BREEDING_RANGE;
    } //end of get breeding range
    
    /**
     * gets breeding age of Pheasant
     * @return int value for breeding age
     *  (minimum age required to breed)
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    } //end of get breeding age
    
    /**
     * gets breeding probability of Pheasant
     * @return double value for breeding probability
     *  (the chances that if it finds a mate it
     *  has offspring)
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    } //end of get breeding probability
    
    /**
     * gets max litter size of Pheasant
     * @return int value for max litter size
     *  (the max amount of offspring the Pheasant
     *  can have in one mating)
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    } //end of get max litter size
    
    /**
     * gets new Pheasant object 
     * @param field The field the new object is
     *  placed in
     * @param location The location in the field
     *  the new Pheasant is placed in
     * @return the new Pheasant object
     */
    @Override
    protected Animal createChild(Field field, Location location)
    {
        return new Pheasant(false, field, getPlantField(), location);
    } //end of creat child
    
    /**
     * gets Class object 
     * @return Class object of Pheasant
     */
    @Override
    protected Class getAnimalType()
    {
        return this.getClass();
    } //end of get animal type
    
    //*******************************DEBUG METHODS*****************************************
    
    /**
     * Used for printing out debugging information
     */
    public static void debugDeath()
    {
        System.out.println("Pheasant: Age: " + death[0] + ", Overcrowding: " + death[1] + ", Eaten: " + death[2] 
            + ", Hunger: " + death[3] + ", Disease: " + death[4]);
    } //end of debug death

    /**
     * Used for debugging to set increment
     *  eaten death counter of Pheasant
     */
    @Override
    protected void debugEattenDeath()
    {
        death[2]++;
    } //end of debug eatten death

    /**
     * Used for debugging to set increment
     *  disease death counter of Pheasant
     */
    @Override
    protected void debugDiseaseDeath()
    {
        death[4]++;
    } //end of debug disease death

    /**
     * Used for debugging to set increment
     *  age death counter of Pheasant
     */
    @Override
    protected void debugAgeDeath()
    {
        death[0]++;
    } //end of debug age death
    
    /**
     * Used for debugging to set increment
     *  hunger death counter of Pheasant
     */
    @Override
    protected void debugHungerDeath()
    {
        death[3]++;
    } //end of debug hunger death
    
}//end of Pheasant Class
