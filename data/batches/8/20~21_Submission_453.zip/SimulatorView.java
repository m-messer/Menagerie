import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * SimulatorView Class - the graphical view of the Predator
 *      and Prey Project
 * 
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * 
 * @version 2021.02.28
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    //Prefixs for displayed information
    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String DAY_PREFIX = "Time of Day: ";
    private final String WEATHER_PREFIX = "Weather: ";

    //graphical objects
    private JLabel stepLabel, population, infoLabel, dayLabel, weatherLabel;
    private FieldView fieldView;

    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;

    //holds references to managers required for information to display
    private AnimalManager animalManager;
    private EventManager eventManager;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        //initalized of new objects needed
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        //set up text labels 
        setTitle("Predator and Prey Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        dayLabel = new JLabel(DAY_PREFIX, JLabel.CENTER);
        weatherLabel = new JLabel(WEATHER_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        //set up of view
        setLocation(100, 50);
        fieldView = new FieldView(height, width);
        Container contents = getContentPane();

        //set up for view's layout
        JPanel infoPane = new JPanel(new BorderLayout());
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(dayLabel, BorderLayout.NORTH);
        infoPane.add(weatherLabel, BorderLayout.EAST);
        infoPane.add(infoLabel, BorderLayout.CENTER);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);
        pack();
        
        setVisible(true);
    }//end of Simulator view

    //************ public methods ***********
    
    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }//end of set color

    /**
     * Display a short information label at the top of the window.
     * @param text The text to be displayed by the info label
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }//end of set info text

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step)
    {
        //ensures that the window is visible
        if(!isVisible()) {
            setVisible(true);
        }

        //generates day and weather label texts
        String day = createDayText();
        String weather = createWeatherText();
        
        //sets label texts
        stepLabel.setText(STEP_PREFIX + step);
        dayLabel.setText(DAY_PREFIX + day);
        weatherLabel.setText(WEATHER_PREFIX + weather);
        
        //prepares for status update
        stats.reset();
        fieldView.preparePaint();
        
        //Loops through each column and row of the field to set appropriate
        //colour for the animal or event
        for(int row = 0; row < animalManager.getField().getDepth(); row++) {
            for(int col = 0; col < animalManager.getField().getWidth(); col++) {
                Object animal = animalManager.getField().getObjectAt(row, col);
                Object event = eventManager.getField().getObjectAt(row, col);
                
                if(animal != null) {
                    stats.incrementCount(animal.getClass());
                    fieldView.drawMark(col, row, getColor(animal.getClass()));
                }//end of if animal at position 
                else if(event != null){
                    fieldView.drawMark(col, row, getColor(event.getClass()));
                }//end of else if event at position
                else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }//end of else position is empty
                
            }// end of for all columns 
        }//end of for all rows
        
        //updates stats
        stats.countFinished();
        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(animalManager.getField()));
        
        //updates graphical view
        fieldView.repaint();
        
    }//end of updatestatus

    /**
     * Determine whether the simulation should continue to run.
     * @return true If no animal has gone extinct.
     */
    public boolean isViable()
    {
        return stats.isViable(animalManager.getField());
    }//end of is viable

    /**
     * Sets the animal manager reference
     * @param animalManager The AnimalManager object to reference in this object
     */
    public void setAnimalManager(AnimalManager animalManager)
    {
        this.animalManager = animalManager;
    }//end of set Animal Manager

    /**
     * Sets the event manager reference
     * @param eventManager The EventManager object to reference in this object
     */
    public void setEventManager(EventManager eventManager)
    {
        this.eventManager = eventManager;
    }//end of set event manager

    /**
     * returns the colour associated with a animal class
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass)
    {
        Color col = colors.get(animalClass);
        
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }//end of if no associated color
        else {
            return col;
        }//end of else has color
        
    }//end of get color

    /**
     * Generates the information part of the weather text label
     * @return The formatted info for the the weather text
     */
    private String createWeatherText()
    {
        String weather = "Sunny";

        if(eventManager.isRaining()){
            weather = "Raining";
        }//end of if it is raining

        if(eventManager.isFoggy()){
            weather += " and Foggy ";
        }//end of if foggy
        else{
            weather += " and Clear ";
        }//end of else clear

        return weather;
    }//end of create weather text
    
    /**
     * Generates the information part of the day text label
     * @return The formatted info for the the day text
     */
    private String createDayText()
    {
        String day = "";
        
        if(eventManager.isDay()){
            day = "Day";
        }//end of if day
        else{
            day = "Night";
        }//end of else night
        
        return day;
    }//end of createDayText
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         * @param height The int height of the component
         * @param width The int width of the component
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }//end of Field View constructor

        /**
         * Tell the GUI manager how big we would like to be.
         * @return Dimension object of the component
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                gridHeight * GRID_VIEW_SCALING_FACTOR);
        }//end of get preferred size

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(!size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
            
        }//end of prepare Paint

        /**
         * Paint on grid location on this field in a given color.
         * @param int x coordinate for painted location
         * @param int y coordinate for painted location
         * @param Color object for painted location
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
            
        }//end of draw mark

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         * @param Graphics object to display component on
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
            
        }//end of paint component
        
    }//end of FieldView Class
    
}//end of SimulatorView Class
