import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * EventManager Class - manages the event objects of
 *      the Predator and Prey Project
 *      
 * This class holds the events' field and is incharge
 *  of cycling the Localized event objects on new step, 
 *  create new localized events depending on chance as
 *  well as update globalized events each step
 *
 * 
 * @version 2021.02.28
 */
public class EventManager
{
    //used to generate random values
    private static final Random rand = Randomizer.getRandom();
    
    //constant used to manage day and night cycle
    private static final int DAY_NIGHT_CYCLE = 15;
    
    //constants used to control raining 
    private static final double RAINING_PROBABILITY = 0.05;
    private static final int MAX_RAIN_LENGTH = 20;
    
    //constants usd to control fog
    private static final double FOG_PROBABILITY = 0.10;
    private static final int MAX_FOG_LENGTH = 10;

    //constant used to create local event Fire
    private static final double FIRE_PROBABILITY = 0.05;
    
    //stores if the time is currently day
    private boolean isDay;
    
    //stores if it is curently raining
    private boolean isRaining;
    //stores how many more steps it will rain
    private int rainLength;
    
    //stores if it is currently raining
    private boolean isFoggy;
    //stores how many more steps it will be foggy
    private int fogLength;
   
    //fields used to store and organize localized events
    private List<LocalizedEvent> localEvents;
    private Field eventField;
    
    //fields that hold reference to the
    //other managers
    private AnimalManager animalManager;
    private PlantManager plantManager;
    
    /**
     * Constructor for objects of class EventManager
     * @param depth The depth (aka height) of the field
     *  in rows
     * @param width The width of the field
     *  in columns
     */
    public EventManager(int depth, int width)
    {
        localEvents = new ArrayList<>();
        eventField = new Field(depth, width);
        
    }//end of event manager constructor

    //************* Public Methods **************
    
    /**
     * Called on every step to cycle event
     *  updates
     * @param step The int number of current step
     */
    public void cycleEvents(int step)
    {
        //used to hold all localized events
        List<LocalizedEvent> newEvents = new ArrayList<>();        
        
        for(Iterator<LocalizedEvent> it = localEvents.iterator(); it.hasNext(); ) {
            LocalizedEvent event = it.next();
            event.act(newEvents);
            if(!event.isActive()) {
                it.remove();
            }//end of if event no longer active
        }//end of for all localized events

        //adds all new localized events created
        localEvents.addAll(newEvents);
        
        //checks to create local event at random location
        checkNewLocalEvents();
        
        //checks for changes in global events
        checkRaining();
        checkFog();
        checkTime(step);
    }//end of cycle events
    
    /**
     * @return true if is day
     */
    public boolean isDay()
    {
        return isDay;
    }//end of is day
    
    /**
     * @return true if raining
     */
    public boolean isRaining()
    {
        return isRaining;
    }//end of is raining
    
    /**
     * @return true if is foggy
     */
    public boolean isFoggy()
    {
        return isFoggy;
    }//end of is foggy
    
    /**
     * @param location The Location to be checked 
     *  if it is habitable (aka can be moved onto)
     * @return true if the location is habitable
     */
    public boolean isHabitableLocation(Location location)
    {
        boolean isHabitable = true;
        
        LocalizedEvent event = (LocalizedEvent) eventField.getObjectAt(location);
        if(event != null){
            //sets locations habitability to false
            //if the event makes the location inhabitable
            isHabitable = event.isHabitable();
        }//end of if event at location
        
        return isHabitable;
    }//end of is habitable location
    
    /**
     * Resets the all events back to default
     */
    public void reset()
    {
        isDay = true;
        
        isRaining = false;
        rainLength = 0;
        
        isFoggy = false;
        fogLength = 0;  
        
        localEvents.clear();
        eventField.clear();
    }//end of reset

    /**
     * @returns the events' field
     */
    public Field getField()
    {
        return eventField;
    }//end of get field
    
    /**
     * Sets the animal manager object to reference
     * @param animalManager The AnimalManager object
     */
    public void setAnimalManager(AnimalManager animalManager)
    {
        this.animalManager = animalManager;
    }//end of set animal manager
    
    /**
     * Sets the plant manager object to reference
     * @param plantManager The plantManager object
     */
    public void setPlantManager(PlantManager plantManager)
    {
        this.plantManager = plantManager;
    }//end of set plant manager
    
    //********* Private Methods ************
    
    /**
     * Checks to see if the state of the
     *  Day/Night cycle has changed
     * @param step The int number of current step
     */
    private void checkTime(int step)
    {
        if((step % DAY_NIGHT_CYCLE) == 0){
            isDay = !isDay;
        }//end of if time switch

    }//end of check time

    /**
     * Checks to see if the state of the
     *  global event raining has changed
     */
    private void checkRaining()
    {
        if(!isRaining){
            if(rand.nextDouble() <= RAINING_PROBABILITY){
                isRaining = true;
                rainLength = rand.nextInt(MAX_RAIN_LENGTH) + 1;
            }//end of if start raining
        }//end of if not raining
        else{
            if(rainLength == 0){
                isRaining = false;
            }//end if raining ended
            else{
                rainLength--;
            }//end of else reduce rain length
        }//end of else raining
        
    }//end of check raining
    
    /**
     * Checks to see if the state of the
     *  global event foggy has changed
     */
    private void checkFog()
    {
        if(!isFoggy){
            if(rand.nextDouble() <= FOG_PROBABILITY){
                isFoggy = true;
                fogLength = rand.nextInt(MAX_FOG_LENGTH) + 1;
            }//end of if start fog
        }//end of if not foggy
        else{
            if(fogLength == 0){
                isFoggy = false;
            }//end of if fog has ended
            else{
                fogLength--;
            }//end of else reduce fog length
        }//end of else foggy
    }//end of check fog
    
    /**
     * Checks to see if any new local events
     *  are randomly created
     */
    private void checkNewLocalEvents()
    {
        if(rand.nextDouble() <= FIRE_PROBABILITY){
            Location location = new Location(rand.nextInt(eventField.getDepth()), 
                rand.nextInt(eventField.getWidth()));
            Fire fire = new Fire(eventField, location, animalManager, plantManager);
            
            localEvents.add(fire);
            eventField.place(fire, location);
        }//end of if fire starts
    }//end of check new local events
    
}//end of EventManager Class
