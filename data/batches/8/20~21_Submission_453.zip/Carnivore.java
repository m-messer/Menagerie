import java.util.List;
import java.util.Iterator;

/**
 * Carnivore Class - abstract representation of the
 *  general behaviour of a carnivore animal in the
 *  Predator and Prey Project
 *
 * This class implements the finding food behaviour
 *  of predator animals
 *
 * 
 * @version 2021.02.28
 */
public abstract class Carnivore extends Animal
{

    /**
     * Creates a new carnivore
     * @param randomAge true if not new born
     * @param field The field it will be in
     * @param location The location in the
     *  field it will be in
     */
    public Carnivore(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }//end of Carnivore constructor

    /**
     * gets hunting range from the animal
     *  types that inherit from this class
     * @return int value for hunting range
     *  (int radius in which it searches
     *  for food)
     */
    abstract protected int getHuntingRange();
    
    /**
     * Tries to find an animal that the
     *  current animal can eat within its
     *  hunting radius
     * @return location if food found or
     *  null if no food found
     */
    protected Location findFood()
    {
        Field field = getField();
        //finds locations to search through
        List<Location> adjacent = field.adjacentLocations(getLocation(), getHuntingRange());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Animal) {
                Animal prey = (Animal) obj;
                if(prey.getFoodChainLevel() < getFoodChainLevel() && prey.isAlive()) { 
                    prey.setDead();
                    prey.debugEattenDeath();
                    eatFood(prey.getFoodValue());
                    
                    return where;
                }//end of if can eat the animal
            }//end of if object is an animal
        }//end of while has next location 
        return null;
    }//end of find food
    
}//end of Carnivore Class
