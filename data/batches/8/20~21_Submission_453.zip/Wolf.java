import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Wolf Class - representation of the
 *  Wolf behaviour in the
 *  Predator and Prey Project
 *
 * This class implements the act method and get methods for fields values.
 *
 * 
 * @version 2021.02.28
 */
public class Wolf extends Carnivore
{
    //Debuging
    private static int[] death = new int[5];

    // Characteristics shared by all wolves (class variables).

    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 75;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single pheasant and deers. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int FOOD_VALUE = 10;
    // The maximum food level the wolf can reach
    private static final int MAX_FOOD_LEVEL = 30;
    // The food chain level to which wolves belong
    private static final int FOOD_CHAIN_LEVEL = 2;
    // The number of fields in which radius the wolf can hunt 
    private static final int HUNTING_RANGE = 1;
    // The number of fields in which radius the female can find male
    private static final int BREEDING_RANGE = 2;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }//end of Wolf Constructor

    /**
     * This is what the wolf does most of the time: it hunts for
     * deers and coyotes. In the process, it might breed, die of hunger, die of disease
     * or die of old age.
     * @param eventManager Object to check occuring events.
     * @param newWolfs A list to return newly born wolfs.
     */
    public void act(List<Animal> newWolfs, EventManager eventManager)
    {
        checkDisease();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            findMate(newWolfs);
            // Move towards a source of food if found.
            if(!eventManager.isFoggy() && eventManager.isDay()){
                Location newLocation = findFood();

                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    List<Location> free = getField().getFreeAdjacentLocations(getLocation());
                    for(int i = 0; i < free.size() && newLocation == null; i++){
                        if(eventManager.isHabitableLocation(free.get(i))){
                            newLocation = free.get(i);
                        }//end of if is habitable
                    }//end of for loop of free locations
                }//end of if location is null

                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }//end if new location is not null
                else {
                    // Overcrowding.
                    setDead();
                    death[1]++;
                }//end of else location is null
            }//end of if is not foggy and is a day
        }//end of if alive
    }//end of act

    //*******************************OVERRIDIND ABSTRACT METHODS*****************************************
    
    /**
     * gets hunting range of Wolf
     * @return int value for hunting range
     *  (the higher the value the higher in the
     *  food chain)
     */
    @Override
    protected int getHuntingRange()
    {
        return HUNTING_RANGE;
    }//end of get hunting range
    
    /**
     * gets food chain level of Wolf
     * @return int value for food chain level
     *  (the higher the value the higher in the
     *  food chain)
     */
    @Override
    protected int getFoodChainLevel()
    {
        return FOOD_CHAIN_LEVEL;
    }//end of get food chain level
    
    /**
     * gets food value of Wolf
     * @return int value for food value
     * (the number of food points the
     * Wolf give when consumed)
     */
    @Override
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }//end of get food value
    
    /**
     * gets max age of Wolf
     * @return int value for max age of 
     * Wolf
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    }//end of get max age
    
    /**
     * gets max food level of Wolf
     * @return int value for max food level
     *  (max food points a Wolf can store)
     */
    @Override
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }//end of get max food level
    
    /**
     * gets breeding range of Wolf
     * @return int value for breeding range
     *  (int radius it uses to search for 
     *  a mate)
     */
    @Override
    protected int getBreedingRange()
    {
        return BREEDING_RANGE;
    }//end of get breeding range
    
    /**
     * gets breeding age of Wolf
     * @return int value for breeding age
     *  (minimum age required to breed)
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }//end of get breeding age
    
    /**
     * gets breeding probability of Wolf
     * @return double value for breeding probability
     *  (the chances that if it finds a mate it
     *  has offspring)
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }//end of get breeding probability
    
    /**
     * gets max litter size of Wolf
     * @return int value for max litter size
     *  (the max amount of offspring the Wolf
     *  can have in one mating)
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }//end of get max litter size
    
    /**
     * gets new Wolf object 
     * @param field The field the new object is
     *  placed in
     * @param location The location in the field
     *  the new Wolf is placed in
     * @return the new Wolf object
     */
    @Override
    protected Animal createChild(Field field, Location location)
    {
        return new Wolf(false, field, location);
    }//end of create child
    
    /**
     * gets Class object 
     * @return Class object of Wolf
     */
    @Override
    protected Class getAnimalType()
    {
        return this.getClass();
    }//end of get animal type
    
    //*******************************DEBUG METHODS*****************************************
    
    /**
     * Used for printing out debugging information
     */
    public static void debugDeath()
    {
        System.out.println("Wolf: Age: " + death[0] + ", Overcrowding: " + death[1] + 
            ", Eaten: " + death[2] + ", Hunger: " + death[3] + ", Disease: " + death[4]);
    }//end of debug death

    /**
     * Used for debugging to set increment
     *  eaten death counter of Wolf
     */
    @Override
    protected void debugEattenDeath()
    {
        death[2]++;
    }//end of debug eatten death

    /**
     * Used for debugging to set increment
     *  disease death counter of Wolf
     */
    @Override
    protected void debugDiseaseDeath()
    {
        death[4]++;
    }//end of debug disease death

    /**
     * Used for debugging to set increment
     *  age death counter of Wolf
     */
    @Override
    protected void debugAgeDeath()
    {
        death[0]++;
    }//end of debug age death
    
    /**
     * Used for debugging to set increment
     *  hunger death counter of Wolf
     */
    @Override
    protected void debugHungerDeath()
    {
        death[3]++;
    }//end of debug hunger death
    
}//end of Wolf
