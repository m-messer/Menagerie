import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * AnimalManager Class - manages the animal objects of
 *      the Predator and Prey Project
 *      
 * This class holds the animals' field and is incharge
 *  of cycling the animal objects on new step as well as
 *  reseting and populating the animal field 
 *
 * 
 * @version 2021.02.28
 */
public class AnimalManager
{
    // Constants for the probabilities that the will be 
    //created in any given grid position.
    private static final double COYOTE_CREATION_PROBABILITY = 0.06;
    private static final double PHEASANT_CREATION_PROBABILITY = 0.09; 
    private static final double WOLF_CREATION_PROBABILITY = 0.06; 
    private static final double COUGAR_CREATION_PROBABILITY = 0.06;
    private static final double DEER_CREATION_PROBABILITY = 0.09;
    
    //references to other managers
    private EventManager eventManager;
    private PlantManager plantManager;
    
    // List of animals in the field.
    private List<Animal> animals;
    private Field animalField;
    
    /**
     * Constructor for objects of class AnimalManager
     * @param depth The depth (aka height) of the field
     *  in rows
     * @param width The width of the field
     *  in columns
     */
    public AnimalManager(int depth, int width)
    {
        animals = new ArrayList<>();
        animalField = new Field(depth, width);
    }//end of animal manager constructor

    //********** Public Methods **************
    
    /**
     * called on new step of simulation to
     * cycle all the animal acts for that step
     */
    public void cycleAnimals()
    {
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all Pheasants act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, eventManager);
            if(!animal.isAlive()) {
                it.remove();
            }//end of if animal is dead
        }//end of for all animals

        // Add the newly born Coyotes and Pheasants to the main lists.
        animals.addAll(newAnimals);
    }//end of cycle animals
    
    /**
     * gets the animal object at specified location
     * @param location The location of the animal
     * @return the animal object found or null
     *  if none was found
     */
    public Animal getAnimalAt(Location location)
    {
        return ((Animal) animalField.getObjectAt(location));
    }//end of get animal at
    
    /**
     * clears then repopulates the animals
     */
    public void reset()
    {
        animals.clear();
        populate();
    }//end of reset
    
    /**
     * sets the event manager to reference
     * @param eventManager The EventManager object
     *  to reference
     */
    public void setEventManager(EventManager eventManager)
    {
        this.eventManager = eventManager;
    }//end of set Event Manager
    
    /**
     * sets the plant manager to reference
     * @param plantManager The PlantManager object
     *  to reference
     */
    public void setPlantManager(PlantManager plantManager)
    {
        this.plantManager = plantManager;
    }//end of set plant manager
    
    /**
     * gets the animal field
     * @returns the field for animals
     */
    public Field getField()
    {
        return animalField;
    }//end of get field
    
    //************* Private Methods ****************
    
    /**
     * Randomly populate the field with Coyotes, 
     *  phesants, wolves, cougars and deers.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        animalField.clear();
        for(int row = 0; row < animalField.getDepth(); row++) {
            for(int col = 0; col < animalField.getWidth(); col++) {
                Location location = new Location(row, col); 
                if(rand.nextDouble() <= COYOTE_CREATION_PROBABILITY) {
                    Coyote coyote = new Coyote(true, animalField, location);
                    animals.add(coyote);
                } //end of if spawn coyote
                else if(rand.nextDouble() <= PHEASANT_CREATION_PROBABILITY) {
                    Pheasant pheasant = new Pheasant(true, animalField, plantManager.getField(), location);
                    animals.add(pheasant);
                } //end of else if spawn pheasant
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Deer deer = new Deer(true, animalField, plantManager.getField(), location);
                    animals.add(deer);
                } //end of else if spawn deer
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Wolf wolf = new Wolf(true, animalField, location);
                    animals.add(wolf);
                } //end of else if spawn wolf
                else if(rand.nextDouble() <= COUGAR_CREATION_PROBABILITY) {
                    Cougar cougar = new Cougar(true, animalField, location);
                    animals.add(cougar);
                } //end of else if spawn cougar
                // else leave the location empty.
            }//end of for every column
        }//end of for every row
    }//end of populate
    
    //************ Debugging Methods ************
    
    /**
     * prints all animal debug 
     *  information to the terminal
     */
    public void DEBUG()
    {
        Pheasant.debugDeath();
        Deer.debugDeath();
        Coyote.debugDeath();
        Wolf.debugDeath();
        Cougar.debugDeath();
    }//end of Debug
    
}//end of AnimalManager Class
