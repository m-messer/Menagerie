package simulator;

/**
 * The interface for creating species in the simulator. Every one of them has a probability to
 * determine how many of them will be created in the field.
 *
 * @version 2020.02.21 (1)
 */
public interface SpeciesCreation {

  void createRabbit();

  void createFox();

  void createWolf();

  void createDeer();

  void createPlant();

  void createDisease();
}
