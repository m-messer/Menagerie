package simulator;

import field.DayPeriod;
import field.Field;
import field.FieldStats;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingWorker;
import rx.Observable;

/**
 * A graphical view of the simulation grid. The view displays a colored rectangle for each location
 * representing its contents. It uses a default background color. Colors for each type of species
 * can be defined using the setColor method.
 *
 * @version 2016.02.29
 */
public class SimulatorView extends JFrame {

  // Colors used for empty locations.
  private static final Color EMPTY_COLOR = Color.white;

  // Color used for objects that have no defined color.
  private static final Color UNKNOWN_COLOR = Color.gray;

  private final String STEP_PREFIX = "Step: ";
  private final String POPULATION_PREFIX = "Population: ";
  private JLabel stepLabel, population, infoLabel, dayLabel, dayPeriodLabel;
  private FieldView fieldView;

  // A map for storing colors for participants in the simulation
  private Map<Class, Color> colors;
  // A statistics object computing and storing simulation information
  private FieldStats stats;
  // The two periods of day: daytime and nighttime
  private DayPeriod dayPeriod;
  // The most recent period of the day -
  // periods (morning, afternoon and evening) will change.
  // This is to keep a record of the most period.
  private String mostRecentPeriod;
  // The number of days that have passed
  private int day;

  /**
   * This constructor offers access to methods of SimulatorView class without having to pass
   * parameters.
   */
  public SimulatorView() {
    dayLabel = new JLabel("");
    dayPeriodLabel = new JLabel("");
    dayPeriod = new DayPeriod("Morning", "Afternoon", "Evening");
  }

  /**
   * Create a view of the given width and height.
   *
   * @param height The simulation's height.
   * @param width The simulation's width.
   */
  public SimulatorView(int height, int width) {
    stats = new FieldStats();
    colors = new LinkedHashMap<>();

    setTitle("Ice Field Simulation");
    setLocation(100, 50);
    setLabels();

    fieldView = new FieldView(height, width);

    Container contents = getContentPane();
    setContainerContents(contents);

    changeDayPeriodLabel();
    changeDayLabel();

    dayPeriod = new DayPeriod("Morning", "Afternoon", "Evening");
  }

  /** Set up the labels. */
  private void setLabels() {
    stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
    infoLabel = new JLabel("  ", JLabel.CENTER);
    population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
    dayLabel = new JLabel("");
    dayPeriodLabel = new JLabel("");
  }

  /**
   * Set up the contents pane.
   *
   * @param contents The contents of the container.
   */
  private void setContainerContents(Container contents) {
    JPanel infoPane = new JPanel(new BorderLayout());
    infoPane.add(stepLabel, BorderLayout.WEST);
    infoPane.add(infoLabel, BorderLayout.CENTER);
    infoPane.add(dayLabel, BorderLayout.EAST);
    infoPane.add(dayPeriodLabel, BorderLayout.CENTER);
    contents.add(infoPane, BorderLayout.NORTH);
    contents.add(fieldView, BorderLayout.CENTER);
    contents.add(population, BorderLayout.SOUTH);
    pack();
    setVisible(true);
  }

  /**
   * This method enables the GUI to indicate the changing of the day period (morning, afternoon and
   * evening) by using SwingWorker without blocking the main thread - that is, the thread running
   * the simulator.
   */
  public void changeDayPeriodLabel() {
    SwingWorker<Void, String> worker =
        new SwingWorker<>() {

          /**
           * The tasks in the background - to change the data that will be shown on the
           * dayPeriodLabel.
           *
           * @return Nothing.
           * @throws Exception If the lasting of day periods is interrupted.
           */
          @Override
          protected Void doInBackground() throws Exception {
            publish(dayPeriod.morning());
            publish(dayPeriod.afternoon());
            publish(dayPeriod.evening());
            return null;
          }

          /**
           * After the first method is executed, it will then call the first method again to ensure
           * that the dayPeriodLabel is constantly changing.
           */
          @Override
          protected void done() {
            Runnable r =
                () -> {
                  while (true) {
                    try {
                      // Loop back to morning
                      publish(dayPeriod.morning());
                      doInBackground();
                    } catch (Exception e) {
                      e.printStackTrace();
                    }
                  }
                };
            Thread t = new Thread(r);
            t.start();
          }

          /**
           * This method processes the data from the first method, which means that once the data
           * has been published from the first method, it will immediately be shown on the
           * dayPeriodLabel.
           *
           * @param periods The periods that have been published.
           */
          @Override
          protected void process(List<String> periods) {
            mostRecentPeriod = periods.get(periods.size() - 1);
            dayPeriodLabel.setText(" Period: " + mostRecentPeriod);
          }
        };

    worker.execute();
  }

  /**
   * This method is a timing placeholder that slows down the process of the simulator so that the
   * time interval of morning and afternoon is roughly equal to the interval of one of the periods -
   * daytime.
   *
   * @param periods The two periods - daytime and nighttime.
   * @return An observable which enables getting one of the two periods of day synchronously.
   */
  public Observable<DayPeriod> getMostRecentPeriod(List<String> periods) {
    return Observable.create(
        subscriber -> {
          while (!subscriber.isUnsubscribed()) {
            subscriber.onNext(DayPeriod.period(periods.get(0)));
            subscriber.onNext(DayPeriod.period(periods.get(1)));
          }
        });
  }

  /**
   * This method is similar to the changeDayPeriodLabel() but it changes the dayLabel in the GUI
   * which indicates how many days will have passed in the simulation.
   */
  public void changeDayLabel() {
    SwingWorker<Void, Integer> worker =
        new SwingWorker<>() {
          @Override
          protected Void doInBackground() throws Exception {
            for (int day = 0; day < 4000; day++) {
              Thread.sleep(1000);
              publish(day);
            }
            return null;
          }

          @Override
          protected void done() {
            super.done();
          }

          @Override
          protected void process(List<Integer> daysPassed) {
            day = daysPassed.get(daysPassed.size() - 1);
            dayLabel.setText("Day: " + day);
          }
        };
    worker.execute();
  }

  /**
   * Define a color to be used for a given class of species.animal.
   *
   * @param animalClass The species.animal's Class object.
   * @param color The color to be used for the given class.
   */
  public void setColor(Class animalClass, Color color) {
    colors.put(animalClass, color);
  }

  /** Display a short information label at the top of the window. */
  public void setInfoText(String text) {
    infoLabel.setText(text);
  }

  /** @return The color to be used for a given class of species.animal. */
  private Color getColor(Class animalClass) {
    Color col = colors.get(animalClass);
    if (col == null) {
      // no color defined for this class
      return UNKNOWN_COLOR;
    } else {
      return col;
    }
  }

  /**
   * Show the current status of the field.
   *
   * @param step Which iteration step it is.
   * @param field The field whose status is to be displayed.
   */
  public void showStatus(int step, Field field) {
    if (!isVisible()) {
      setVisible(true);
    }

    stepLabel.setText(STEP_PREFIX + step);
    stats.reset();

    fieldView.preparePaint();

    for (int row = 0; row < field.getDepth(); row++) {
      for (int col = 0; col < field.getWidth(); col++) {
        Object animal = field.getObjectAt(row, col);
        if (animal != null) {
          stats.incrementCount(animal.getClass());
          fieldView.drawMark(col, row, getColor(animal.getClass()));
        } else {
          fieldView.drawMark(col, row, EMPTY_COLOR);
        }
      }
    }
    stats.countFinished();

    population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
    fieldView.repaint();
  }

  /**
   * Determine whether the simulation should continue to run.
   *
   * @return true If there is more than one species alive.
   */
  public boolean isViable(Field field) {
    return stats.isViable(field);
  }

  /**
   * Provide a graphical view of a rectangular field. This is a nested class (a class defined inside
   * a class) which defines a custom component for the user interface. This component displays the
   * field. This is rather advanced GUI stuff - you can ignore this for your project if you like.
   */
  private class FieldView extends JPanel {
    private final int GRID_VIEW_SCALING_FACTOR = 6;

    private int gridWidth, gridHeight;
    private int xScale, yScale;
    Dimension size;
    private Graphics g;
    private Image fieldImage;

    /** Create a new FieldView component. */
    public FieldView(int height, int width) {
      gridHeight = height;
      gridWidth = width;
      size = new Dimension(0, 0);
    }

    /** Tell the GUI manager how big we would like to be. */
    public Dimension getPreferredSize() {
      return new Dimension(
          gridWidth * GRID_VIEW_SCALING_FACTOR, gridHeight * GRID_VIEW_SCALING_FACTOR);
    }

    /**
     * Prepare for a new round of painting. Since the component may be resized, compute the scaling
     * factor again.
     */
    public void preparePaint() {
      if (!size.equals(getSize())) { // if the size has changed...
        size = getSize();
        fieldImage = fieldView.createImage(size.width, size.height);
        g = fieldImage.getGraphics();

        xScale = size.width / gridWidth;
        if (xScale < 1) {
          xScale = GRID_VIEW_SCALING_FACTOR;
        }
        yScale = size.height / gridHeight;
        if (yScale < 1) {
          yScale = GRID_VIEW_SCALING_FACTOR;
        }
      }
    }

    /** Paint on grid location on this field in a given color. */
    public void drawMark(int x, int y, Color color) {
      g.setColor(color);
      g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
    }

    /** The field view component needs to be redisplayed. Copy the internal image to screen. */
    public void paintComponent(Graphics g) {
      if (fieldImage != null) {
        Dimension currentSize = getSize();
        if (size.equals(currentSize)) {
          g.drawImage(fieldImage, 0, 0, null);
        } else {
          // Rescale the previous image.
          g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
        }
      }
    }
  }
}
