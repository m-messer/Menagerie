package simulator;

import field.Disease;
import field.Field;
import field.Location;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import species.Plant;
import species.animal.Animal;
import species.animal.predator.Fox;
import species.animal.predator.Wolf;
import species.animal.prey.Deer;
import species.animal.prey.Rabbit;
import utils.Randomizer;

/**
 * A simple predator-prey simulator, based on a rectangular field containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator {

  // Constants representing configuration information for the simulation.
  // The default width for the grid.
  private static final int DEFAULT_WIDTH = 120;
  // The default depth of the grid.
  private static final int DEFAULT_DEPTH = 80;
  // The probability that a fox will be created in any given grid position.
  private static final double FOX_CREATION_PROBABILITY = 0.10;
  // The probability that a rabbit will be created in any given grid position.
  private static final double RABBIT_CREATION_PROBABILITY = 0.80;
  // The probability that plants will be created in the field.
  private static final double PLANT_CREATION_PROBABILITY = 0.20;
  // The probability that deers will be created in the field.
  private static final double DEER_CREATION_PROBABILITY = 0.60;
  // The probability that wolves will be created in the field.
  private static final double WOLF_CREATION_PROBABILITY = 0.20;
  // The probability that diseases will be created in the field.
  private static final double DISEASE_CREATION_PROBABILITY = 0.20;

  // List of animals in the field.
  private List<Animal> animals;
  // A list of plants
  private List<Plant> plants;
  // A list of diseases
  private List<Disease> diseases;
  // The current state of the field.
  private Field field;
  // The current step of the simulation.
  private int step;
  // A graphical view of the simulation.
  private SimulatorView view;

  /** Construct a simulation field with default size. */
  public Simulator() {
    this(DEFAULT_DEPTH, DEFAULT_WIDTH);
  }

  /**
   * Create a simulation field with the given size.
   *
   * @param depth Depth of the field. Must be greater than zero.
   * @param width Width of the field. Must be greater than zero.
   */
  public Simulator(int depth, int width) {
    if (width <= 0 || depth <= 0) {
      System.out.println("The dimensions must be greater than zero.");
      System.out.println("Using default values.");
      depth = DEFAULT_DEPTH;
      width = DEFAULT_WIDTH;
    }

    createSpeciesLists();
    field = new Field(depth, width);

    // Create a view of the state of each location in the field.
    view = new SimulatorView(depth, width);
    setColorsForSpecies(view);

    // Setup a valid starting point.
    reset();
  }

  /** Create lists of species. */
  private void createSpeciesLists() {
    animals = new ArrayList<>();
    plants = new ArrayList<>();
    diseases = new ArrayList<>();
  }

  /**
   * Set the colours of species.
   *
   * @param view The simulator view.
   */
  private void setColorsForSpecies(SimulatorView view) {
    view.setColor(Rabbit.class, Color.ORANGE);
    view.setColor(Fox.class, Color.BLUE);
    view.setColor(Plant.class, Color.GREEN);
    view.setColor(Deer.class, Color.CYAN);
    view.setColor(Wolf.class, Color.GRAY);
    view.setColor(Disease.class, Color.red);
  }

  /** Run the simulation from its current state for a reasonably long period, (4000 steps). */
  public void runLongSimulation() {
    simulate(4000);
  }

  /**
   * Run the simulation from its current state for the given number of steps. Stop before the given
   * number of steps if it ceases to be viable.
   *
   * @param numSteps The number of steps to run for.
   */
  public void simulate(int numSteps) {
    for (int step = 1; step <= numSteps && view.isViable(field); step++) {
      simulateOneStep();
      delay(1000); // uncomment this to run more slowly
    }
  }

  /**
   * Run the simulation from its current state for a single step. Iterate over the whole field
   * updating the state of each species.
   */
  public void simulateOneStep() {
    step++;
    animalsAct();
    plantsAct();
    diseasesAct();
    view.showStatus(step, field);
  }

  /** The actions of animals. If one of them is dead, then they will be removed from the field. */
  private void animalsAct() {
    List<Animal> newAnimals = new ArrayList<>();
    for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
      Animal animal = it.next();
      animal.act(newAnimals);
      if (!animal.isAlive()) {
        it.remove();
      }
    }
    animals.addAll(newAnimals);
  }

  /** The behaviour of plant. If one of them is dead, then they will be removed from the field. */
  private void plantsAct() {
    List<Plant> newPlants = new ArrayList<>();
    for (Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
      Plant plant = it.next();
      plant.act(newPlants);
      if (!plant.isAlive()) {
        it.remove();
      }
    }
    plants.addAll(newPlants);
  }

  /** The behaviour of disease. */
  private void diseasesAct() {
    List<Disease> newDiseases = new ArrayList<>();
    for (Iterator<Disease> it = diseases.iterator(); it.hasNext(); ) {
      Disease disease = it.next();
      disease.act(newDiseases);
    }
    diseases.addAll(newDiseases);
  }

  /** Reset the simulation to a starting position. */
  public void reset() {
    step = 0;
    clearField();
    populate();

    // Show the starting state in the view.
    view.showStatus(step, field);
  }

  /** Empty the field. */
  private void clearField() {
    animals.clear();
    plants.clear();
    diseases.clear();
  }

  /** Randomly populate the field with different species. */
  private void populate() {
    Random rand = Randomizer.getRandom();
    field.clear();
    SpeciesCreation creation =
        new SpeciesCreation() {

          @Override
          public void createRabbit() {
            for (int row = 0; row < field.getDepth(); row++) {
              for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                  Location location = new Location(row, col);
                  Rabbit rabbit = new Rabbit(true, field, location);
                  animals.add(rabbit);
                }
              }
            }
          }

          @Override
          public void createFox() {
            for (int row = 0; row < field.getDepth(); row++) {
              for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                  Location location = new Location(row, col);
                  Fox fox = new Fox(true, field, location);
                  animals.add(fox);
                }
              }
            }
          }

          @Override
          public void createWolf() {
            for (int row = 0; row < field.getDepth(); row++) {
              for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                  Location location = new Location(row, col);
                  Wolf wolf = new Wolf(true, field, location);
                  animals.add(wolf);
                }
              }
            }
          }

          @Override
          public void createDeer() {
            for (int row = 0; row < field.getDepth(); row++) {
              for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                  Location location = new Location(row, col);
                  Deer deer = new Deer(true, field, location);
                  animals.add(deer);
                }
              }
            }
          }

          @Override
          public void createPlant() {
            for (int row = 0; row < field.getDepth(); row++) {
              for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                  Location location = new Location(row, col);
                  Plant plant = new Plant(field, location);
                  plants.add(plant);
                }
              }
            }
          }

          @Override
          public void createDisease() {
            for (int row = 0; row < field.getDepth(); row++) {
              for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= DISEASE_CREATION_PROBABILITY) {
                  Location location = new Location(row, col);
                  Disease disease = new Disease(field, location);
                  diseases.add(disease);
                }
              }
            }
          }
        };
    creation.createWolf();
    creation.createRabbit();
    creation.createPlant();
    creation.createFox();
    creation.createDisease();
    creation.createDeer();
  }

  /**
   * Pause for a given time.
   *
   * @param millisec The time to pause for, in milliseconds
   */
  private void delay(int millisec) {
    try {
      Thread.sleep(millisec);
    } catch (InterruptedException ie) {
      // wake up
    }
  }

  /** The main() method to start the application. */
  public static void main(String[] args) {
    Simulator simulator = new Simulator();
    simulator.runLongSimulation();
  }
}
