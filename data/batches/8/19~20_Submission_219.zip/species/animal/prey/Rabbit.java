package species.animal.prey;

import static utils.library.animal.AgeAndFoodLevelSetter.getAge;
import static utils.library.animal.AgeAndFoodLevelSetter.getFoodLevel;

import field.Field;
import field.Location;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import species.Plant;
import species.animal.Animal;
import utils.Randomizer;

/**
 * A simple model of a rabbit. Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Rabbit extends Animal {

  // Characteristics shared by all rabbits (class variables).

  // The age at which a rabbit can start to breed.
  private static final int BREEDING_AGE = 3;
  // The age to which a rabbit can live.
  private static final int MAX_AGE = 20;
  // The likelihood of a rabbit breeding.
  private static final double BREEDING_PROBABILITY = 0.8;
  // The maximum number of births.
  private static final int MAX_LITTER_SIZE = 4;
  // The food value of a rabbit
  private static final int PLANT_FOOD_VALUE = 10;
  // A shared random number generator to control breeding.
  private static final Random rand = Randomizer.getRandom();

  // Individual characteristics (instance fields).

  // The rabbit's age.
  private int age;
  private int foodLevel;

  /**
   * Create a new rabbit. A rabbit may be created with age zero (a new born) or with a random age.
   *
   * @param randomAge If true, the rabbit will have a random age.
   * @param field The field currently occupied.
   * @param location The location within the field.
   */
  public Rabbit(boolean randomAge, Field field, Location location) {
    super(field, location);
    getAgeAndFoodLevel(randomAge);
  }

  /**
   * The helper method of getting the age and the food level of a new rabbit.
   *
   * @param randomAge If the rabbit age is random.
   */
  private void getAgeAndFoodLevel(boolean randomAge) {
    age = getAge(randomAge, MAX_AGE);
    foodLevel = getFoodLevel(randomAge, PLANT_FOOD_VALUE);
  }

  /**
   * This is what the rabbit does most of the time - it runs around. Sometimes it will breed or die
   * of old age.
   *
   * @param newRabbits A list to return newly born rabbits.
   */
  public void act(List<Animal> newRabbits) {
    incrementHunger(foodLevel);
    incrementAge(age, MAX_AGE);
    if (isAlive()) {
      if (isDay()) {
        giveBirth(newRabbits);
        // Try to move into a free location.
        Location newLocation = findPlant();
        locationUtils.goToNewLocation(newLocation, this);
      } else {
        sleep(age, MAX_AGE, PLANT_FOOD_VALUE);
      }
    }
  }

  /**
   * Rabbits will find food - plants to eat in the adjacent cells.
   *
   * @return The last location of the rabbit.
   */
  private Location findPlant() {
    Field field = locationUtils.getField();
    List<Location> adjacent = locationUtils.getAdjacentLocations();
    return seekingPlant(adjacent, field);
  }

  /**
   * The helper method simulates a rabbit seeking for its food to eat.
   *
   * @param adjacent Adjacent locations in the field.
   * @param field The field of the simulator.
   * @return
   */
  private Location seekingPlant(List<Location> adjacent, Field field) {
    Iterator<Location> it = adjacent.iterator();
    while (it.hasNext()) {
      Location where = it.next();
      Object plant = field.getObjectAt(where);
      if (plant instanceof Plant) {
        if (((Plant) plant).isAlive()) {
          ((Plant) plant).setDead();
          foodLevel = PLANT_FOOD_VALUE;
          return where;
        }
      }
    }
    return null;
  }

  /**
   * Check whether or not this rabbit is to give birth at this step. New births will be made into
   * free adjacent locations.
   *
   * @param newRabbits A list to return newly born rabbits.
   */
  private void giveBirth(List<Animal> newRabbits) {
    // New rabbits are born into adjacent locations.
    // Get a list of adjacent free locations.
    Field field = locationUtils.getField();
    List<Location> free = locationUtils.getFreeAdjacentLocations();
    int births = breed();
    for (int b = 0; b < births && free.size() > 0; b++) {
      Location loc = free.remove(0);
      Rabbit young = new Rabbit(false, field, loc);
      newRabbits.add(young);
    }
  }

  /**
   * Generate a number representing the number of births, if it can breed.
   *
   * @return The number of births (may be zero).
   */
  private int breed() {
    int births = 0;
    if (canBreed(age, BREEDING_AGE)
        && rand.nextDouble() <= BREEDING_PROBABILITY
        && isFemaleAndMaleMet() == true) {
      births = rand.nextInt(MAX_LITTER_SIZE) + 1;
    }
    return births;
  }

  /**
   * The helper class to decide whether rabbits will breed or not. If male and female individuals
   * meet in an adjacent cell in the field, then they will probably breed.
   *
   * @return True if a female and a male rabbits meet, false otherwise.
   */
  private boolean isFemaleAndMaleMet() {
    List<Location> nextCells = locationUtils.getAdjacentLocations();
    return meeting(nextCells);
  }

  /**
   * This method helps to determine if two individuals in next cells are female and male.
   *
   * @param nextCells The adjacent locations.
   * @return True if a female and a male rabbits meet, false otherwise.
   */
  private boolean meeting(List<Location> nextCells) {
    Iterator<Location> it = nextCells.iterator();
    while (it.hasNext()) {
      Location nextCell = (Location) it.next();
      Object animal = locationUtils.getField().getObjectAt(nextCell);
      if (animal instanceof Rabbit) {
        Rabbit rabbit = (Rabbit) animal;
        if (rabbit.isMale()) {
          return true;
        }
        return false;
      }
    }
    return false;
  }
}
