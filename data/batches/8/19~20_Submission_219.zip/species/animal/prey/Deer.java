package species.animal.prey;

import static utils.library.animal.AgeAndFoodLevelSetter.getAge;
import static utils.library.animal.AgeAndFoodLevelSetter.getFoodLevel;

import field.Field;
import field.Location;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import species.Plant;
import species.animal.Animal;
import utils.Randomizer;

/**
 * Deers are like rabbits but they are much less in their amount. They will move, breed and die.
 *
 * @version 2020.02.19 (1)
 */
public class Deer extends Animal {

  // A deer has to be over this age to breed.
  private static final int BREEDING_AGE = 4;
  // The age that a deer can live up to.
  private static final int MAX_AGE = 20;
  // The probability of deers breeding.
  private static final double BREEDING_PROBABILITY = 0.5;
  // The max amount of young deers that a female deer can give birth to.
  private static final int MAX_LITTER_SIZE = 2;
  // The food value of a deer.
  private static final int PLANT_FOOD_VALUE = 20;
  // A random number controlling the breeding of deer
  private static final Random rand = Randomizer.getRandom();
  // The age of a deer
  private int age;
  // The food level of a deer
  private int foodLevel;

  /**
   * Create a new deer in the field with its age and food level.
   *
   * @param randomAge If the age of the deer will be randomly generated.
   * @param field The filed in the simulator.
   * @param location The location of the deer.
   */
  public Deer(boolean randomAge, Field field, Location location) {
    super(field, location);
    getAgeAndFoodLevel(randomAge);
  }

  /**
   * This method helps the constructor to get the age and food level of a deer.
   *
   * @param randomAge If the age of the deer will be randomly generated.
   */
  private void getAgeAndFoodLevel(boolean randomAge) {
    age = getAge(randomAge, MAX_AGE);
    foodLevel = getFoodLevel(randomAge, PLANT_FOOD_VALUE);
  }

  /**
   * Deers will run around seeking food to eat or finding partners to breed in the day.
   *
   * @param newDeers
   */
  @Override
  public void act(List<Animal> newDeers) {
    incrementHunger(foodLevel);
    incrementAge(age, MAX_AGE);
    if (isAlive()) {
      if (isDay()) {
        giveBirth(newDeers);
        Location newLocation = findPlant();
        locationUtils.goToNewLocation(newLocation, this);
      } else {
        sleep(age, MAX_AGE, PLANT_FOOD_VALUE);
      }
    }
  }

  /**
   * The deer will find plants to eat in the field in the next adjacent cell.
   *
   * @return The last location of the deer
   */
  private Location findPlant() {
    Field field = locationUtils.getField();
    List<Location> adjacent = locationUtils.getAdjacentLocations();
    return seekingPlant(adjacent, field);
  }

  /**
   * This method helps deers to find plants to eat.
   *
   * @param adjacent The adjacent cell.
   * @param field The field of the simulator.
   * @return The last location of the deer.
   */
  private Location seekingPlant(List<Location> adjacent, Field field) {
    Iterator<Location> it = adjacent.iterator();
    while (it.hasNext()) {
      Location where = it.next();
      Object plant = field.getObjectAt(where);
      if (plant instanceof Plant) {
        if (((Plant) plant).isAlive()) {
          ((Plant) plant).setDead();
          foodLevel = PLANT_FOOD_VALUE;
          return where;
        }
      }
    }
    return null;
  }

  /**
   * The deers will give births to newer generations of deers in available adjacent locations.
   *
   * @param newDeers The new deers to be born.
   */
  private void giveBirth(List<Animal> newDeers) {
    Field field = locationUtils.getField();
    List<Location> free = locationUtils.getFreeAdjacentLocations();
    int births = breed();
    for (int i = 0; i < births && free.size() > 0; i++) {
      Location loc = free.remove(0);
      Deer young = new Deer(false, field, loc);
      newDeers.add(young);
    }
  }

  /**
   * @return The amount of breeding of deers according to the age and probability of breeding and
   *     sexes.
   */
  private int breed() {
    int births = 0;
    if (canBreed(age, BREEDING_AGE)
        && rand.nextDouble() <= BREEDING_PROBABILITY
        && isFemaleAndMaleMet() == true) {
      births = rand.nextInt(MAX_LITTER_SIZE) + 1;
    }
    return births;
  }

  /**
   * This method determines if a male and female deer individuals meet in adjacent locations.
   *
   * @return True if they are of different sexes, false otherwise.
   */
  private boolean isFemaleAndMaleMet() {
    List<Location> nextCells = locationUtils.getAdjacentLocations();
    return meeting(nextCells);
  }

  /**
   * Helps the last method to decide if two deers in adjacent locations are of different sexes.
   *
   * @param nextCells The next cell of the deer.
   * @return True if two individuals of different sexes meet, false otherwise.
   */
  private boolean meeting(List<Location> nextCells) {
    Iterator<Location> it = nextCells.iterator();
    while (it.hasNext()) {
      Location nextCell = it.next();
      Object animal = locationUtils.getField().getObjectAt(nextCell);
      if (animal instanceof Deer) {
        Deer deer = (Deer) animal;
        if (deer.isMale()) {
          return true;
        }
        return false;
      }
    }
    return false;
  }
}
