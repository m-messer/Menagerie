package species.animal.predator;

import static utils.library.animal.AgeAndFoodLevelSetter.getAge;
import static utils.library.animal.AgeAndFoodLevelSetter.getFoodLevel;

import field.Field;
import field.Location;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import species.animal.Animal;
import species.animal.prey.Deer;
import species.animal.prey.Rabbit;
import utils.Randomizer;

/**
 * Wolf will move around in the field. They will hunt for rabbits and deer and breed.
 *
 * @version 2020.02.22 (1)
 */
public class Wolf extends Animal {

  // Wolves can only breed if they reach this age
  private static final int BREEDING_AGE = 3;
  // The maximum age that a wolf can live up to
  // if it does not suffer from hunger
  private static final int MAX_AGE = 25;
  // The breeding probability of wolves
  private static final double BREEDING_PROBABILITY = 0.6;
  // The maximum amount of individuals that a wolf can give birth to
  private static final int MAX_LITTER_SIZE = 2;
  // How many food can a wolf eat
  private static final int FOOD_VALUE = 9;
  // A random number which controls the breeding
  private static final Random rand = Randomizer.getRandom();
  // The age of a wolf
  private int age;
  // The food level of a wolf
  private int foodLevel;

  /**
   * Initialise a wolf in the location of the field.
   *
   * @param randomAge If the age of it is randomly generated.
   * @param field The field of the simulator.
   * @param location The location in the field.
   */
  public Wolf(boolean randomAge, Field field, Location location) {
    super(field, location);
    getAgeAndFoodLevel(randomAge);
  }

  /**
   * A helper method which determines the age and food level of a wolf.
   *
   * @param randomAge If the age of the wolf is randomly generated.
   */
  private void getAgeAndFoodLevel(boolean randomAge) {
    foodLevel = getFoodLevel(randomAge, FOOD_VALUE);
    age = getAge(randomAge, MAX_AGE);
  }

  /**
   * The wolf's actions in the field: 1. Its age and hunger will be increased, 2. If it is alive
   * then it will give birth to new wolves, 3. It will find food to eat, 4. If the weather is cold,
   * then it will go to winter sleep.
   *
   * @param newWolves The new wolves to give births to.
   */
  public void act(List<Animal> newWolves) {
    incrementAge(age, MAX_AGE);
    incrementHunger(foodLevel);
    if (isAlive()) {
      if (isDay()) {
        giveBirth(newWolves);
        // Move towards a source of food if found.
        Location newLocation = findFood();
        locationUtils.goToNewLocation(newLocation, this);
      } else {
        if (isCold()) { // Winter sleep
          sleep(age, MAX_AGE, FOOD_VALUE);
        }
      }
    }
  }

  /**
   * Hunting for prey in order not to suffer from hunger.
   *
   * @return The last location of the wolf.
   */
  private Location findFood() {
    Field field = locationUtils.getField();
    List<Location> adjacent = locationUtils.getAdjacentLocations();
    return seeking(field, adjacent);
  }

  /**
   * The process of seeking prey to eat.
   *
   * @param field The field of the simulator.
   * @param adjacent Adjacent cells.
   * @return The last location of the wolf.
   */
  private Location seeking(Field field, List<Location> adjacent) {
    Iterator<Location> it = adjacent.iterator();
    while (it.hasNext()) {
      Location where = it.next();
      Object animal = field.getObjectAt(where);
      if (animal instanceof Rabbit) {
        Rabbit rabbit = (Rabbit) animal;
        eatRabbit(rabbit);
        return where;
      } else if (animal instanceof Deer) {
        Deer deer = (Deer) animal;
        eatDeer(deer);
        return where;
      }
    }
    return null;
  }

  /**
   * If a wolf find a rabbit, then eat it.
   *
   * @param rabbit The rabbit eaten by the wolf.
   */
  private void eatRabbit(Rabbit rabbit) {
    if (rabbit.isAlive()) {
      rabbit.setDead();
      foodLevel = FOOD_VALUE;
    }
  }

  /**
   * If a wolf find a deer, then eat it.
   *
   * @param deer The deer eaten by the wolf.
   */
  private void eatDeer(Deer deer) {
    if (deer.isAlive()) {
      deer.setDead();
      foodLevel = FOOD_VALUE;
    }
  }

  /**
   * Give births to certain amount of young wolves if wolves can breed.
   *
   * @param newWolves The new wolves to give births to.
   */
  private void giveBirth(List<Animal> newWolves) {
    Field field = locationUtils.getField();
    List<Location> free = locationUtils.getFreeAdjacentLocations();
    int births = breed();
    for (int b = 0; b < births && free.size() > 0; b++) {
      Location loc = free.remove(0);
      Wolf young = new Wolf(false, field, loc);
      newWolves.add(young);
    }
  }

  /**
   * Determine the amount of new wolves will be bred if two wolves can breed by: 1. If they are in
   * the next cell to each other; 2. If their ages exceed the age of breeding; 3. If they are of
   * different sexes.
   *
   * @return The amount of new wolves.
   */
  private int breed() {
    int births = 0;
    if (canBreed(age, BREEDING_AGE)
        && rand.nextDouble() <= BREEDING_PROBABILITY
        && isFemaleAndMaleMet() == true) {
      births = rand.nextInt(MAX_LITTER_SIZE) + 1;
    }
    return births;
  }

  /**
   * Determines if two wolves of different sexes have met in adjacent cells.
   *
   * @return True if they have met, false otherwise.
   */
  private boolean isFemaleAndMaleMet() {
    List<Location> nextCells = locationUtils.getAdjacentLocations();
    return meeting(nextCells);
  }

  /**
   * The process of wolves meeting each other and find out if their sexes are different.
   *
   * @param nextCells The adjacent locations.
   * @return True if two individuals of different sexes have met, false otherwise.
   */
  private boolean meeting(List<Location> nextCells) {
    Iterator<Location> it = nextCells.iterator();
    while (it.hasNext()) {
      Location nextCell = it.next();
      Object animal = locationUtils.getField().getObjectAt(nextCell);
      if (animal instanceof Wolf) {
        Wolf wolf = (Wolf) animal;
        if (wolf.isMale()) {
          return true;
        }
        return false;
      }
    }
    return false;
  }
}
