package species.animal;

import field.Field;
import field.Location;
import field.Season;
import java.util.List;
import java.util.Random;
import utils.Randomizer;
import utils.library.LocationUtils;
import utils.library.Timer;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal {

  // Whether the animal is alive or not.
  private boolean alive;
  // The animal's field.
  private Field field;
  // The species.animal's position in the field.
  private boolean isFemale;
  // A random number controls the sexes of animals
  private static final Random rand = Randomizer.getRandom();
  // The location library.
  protected LocationUtils locationUtils;
  // The timer of day periods.
  protected Timer timer;
  // The season of the field.
  private Season season;

  /**
   * Create a new species.animal at location in field.
   *
   * @param field The field currently occupied.
   */
  public Animal(Field field, Location location) {
    alive = true;
    this.field = field;
    isFemale = rand.nextBoolean();
    locationUtils = new LocationUtils(field, location);
    timer = new Timer();
    season = new Season();
  }

  /**
   * The sleeping behaviour of animals. It will only increase the age and hunger of animals. Animal
   * will not do anything else in their sleep.
   *
   * @param age The age of the animal.
   * @param maxAge The maximum age that the animal can live up to.
   * @param foodLevel The food level of the animal.
   */
  protected void sleep(int age, int maxAge, int foodLevel) {
    incrementAge(age, maxAge);
    incrementHunger(foodLevel);
  }

  /** @return True if the animal is male and false if it is female. */
  protected boolean isMale() {
    return !isFemale;
  }

  /**
   * Make this species.animal act - that is: make it do whatever it wants/needs to do.
   *
   * @param newAnimals A list to receive newly born animals.
   */
  public abstract void act(List<Animal> newAnimals);

  /**
   * Check whether the species.animal is alive or not.
   *
   * @return true if the species.animal is still alive.
   */
  public boolean isAlive() {
    return alive;
  }

  /** Indicate that the species.animal is no longer alive. It is removed from the field. */
  public void setDead() {
    alive = false;
    locationUtils.clearLocation();
  }

  /**
   * Increment the hunger of animals. If food level is lower than or equal to zero, then it will be
   * dead.
   *
   * @param foodLevel The food level of the animal.
   */
  protected void incrementHunger(int foodLevel) {
    foodLevel--;
    if (foodLevel <= 0) {
      setDead();
    }
  }

  /**
   * Increment the ages of animals. They cannot live beyond their maximum ages.
   *
   * @param age The current age of the animal.
   * @param maxAge The maximum age that an animal can live up to.
   */
  protected void incrementAge(int age, int maxAge) {
    age++;
    if (age > maxAge) {
      setDead();
    }
  }

  /**
   * If the animal exceeds its breeding age, then it cannot breed.
   *
   * @param age The current age of the animal.
   * @param breedingAge The breeding age of the animal.
   * @return True if it can still breed, false if it cannot.
   */
  protected boolean canBreed(int age, int breedingAge) {
    return age >= breedingAge;
  }

  /**
   * Judge if it is day or night in the field
   *
   * @return True if it is day, false if it is night.
   */
  protected boolean isDay() {
    return timer.dayPeriod().equals("Day");
  }

  /**
   * If the season is winter, then it will be cold in the field.
   *
   * @return True if it is cold, false if not.
   */
  protected boolean isCold() {
    return season.isWinter();
  }
}
