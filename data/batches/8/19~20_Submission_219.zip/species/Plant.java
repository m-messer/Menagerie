package species;

import field.Field;
import field.Location;
import java.util.List;
import java.util.Random;
import utils.Randomizer;
import utils.library.LocationUtils;

/**
 * The plant in the field. It will not move around as the animals do. It will only grow by a certain
 * rate.
 *
 * @version 2020.02.22 (1)
 */
public class Plant {

  private boolean isAlive;
  private Field field;
  // The location library
  private LocationUtils locationUtils;
  // The growing rate of the plant
  private static final double GROWING_PROBABILITY = 0.5;
  // The amount that the plant can grow
  private static final int GROWING_AMOUNT = 3;
  // A random number controlling the growing of the plant
  private static final Random rand = Randomizer.getRandom();

  /**
   * Initialise the plant in the field.
   *
   * @param field The field of the simulator.
   * @param location The location in the field.
   */
  public Plant(Field field, Location location) {
    isAlive = true;
    this.field = field;
    locationUtils = new LocationUtils(field, location);
    setInitialLocation(location);
  }

  /**
   * Set the initial location of the plant.
   *
   * @param location The location in the field.
   */
  private void setInitialLocation(Location location) {
    locationUtils.setLocation(location);
    field.placePlant(this, location);
  }

  /**
   * The plant will grow and will be eaten.
   *
   * @param newPlants Future plants that will grow.
   */
  public void act(List<Plant> newPlants) {
    if (isAlive()) {
      grow(newPlants);
    } else {
      setDead();
    }
  }

  /** Set the plant dead and remove it from the location in the field. */
  public void setDead() {
    isAlive = false;
    locationUtils.clearLocation();
  }

  /**
   * The process of the plants' growing.
   *
   * @param newPlants The new plants will grow.
   */
  private void grow(List<Plant> newPlants) {
    List<Location> free = locationUtils.getFreeAdjacentLocations();
    int growingAmount = growHelper();
    for (int i = 0; i < growingAmount && free.size() > 0; i++) {
      Location loc = free.remove(0);
      Plant grew = new Plant(field, loc);
      newPlants.add(grew);
    }
  }

  /**
   * The method controlling the rate of the plants' growing.
   *
   * @return The amount of plants that will grow.
   */
  private int growHelper() {
    int growingAmount = 0;
    if (rand.nextDouble() <= GROWING_PROBABILITY) {
      growingAmount = rand.nextInt(GROWING_AMOUNT);
    }
    return growingAmount;
  }

  /** @return True if the plant is still alive, false if it is dead. */
  public boolean isAlive() {
    return isAlive;
  }
}
