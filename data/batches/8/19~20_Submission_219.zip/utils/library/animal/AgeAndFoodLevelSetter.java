package utils.library.animal;

import java.util.Random;
import utils.Randomizer;

/**
 * This class determines the food levels and ages of animals by a random number (if the user wants
 * it random).
 *
 * @version 2020.02.19 (1)
 */
public class AgeAndFoodLevelSetter {

  private static final Random rand = Randomizer.getRandom();

  /**
   * Get the ages for animals.
   *
   * @param randomAge If the age of the animal is random or not.
   * @param maxAge The max age that an animal can live up to.
   * @return The current age of the animal.
   */
  public static int getAge(boolean randomAge, int maxAge) {
    int age;
    if (randomAge) {
      age = rand.nextInt(maxAge);
    } else {
      age = 0;
    }
    return age;
  }

  /**
   * Get the food levels for animals.
   *
   * @param randomAge If the age of the animal is random or not.
   * @param foodValue The food value of an animal.
   * @return The food level of an animal.
   */
  public static int getFoodLevel(boolean randomAge, int foodValue) {
    // The amount of food that an animal has eaten
    // It will decrease over time.
    // If it reaches 0, the animal will die of hunger
    int foodLevel;
    if (randomAge) {
      foodLevel = rand.nextInt(foodValue);
    } else {
      foodLevel = foodValue;
    }
    return foodLevel;
  }
}
