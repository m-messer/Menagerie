package utils.library;

import field.DayPeriod;
import java.util.ArrayList;
import java.util.List;
import rx.Observable;
import simulator.SimulatorView;

/**
 * The class that determines the two periods of the field - daytime and nighttime.
 *
 * @version 2020.02.21 (1)
 */
public class Timer {

  private SimulatorView simulatorView;
  // The list of two periods
  private List<String> periods;

  /**
   * Initialise the timer with specifying the two periods - day and night, equivalent to daytime and
   * nighttime, respectively.
   */
  public Timer() {
    simulatorView = new SimulatorView();
    periods = new ArrayList<>();
    periods.add("Day");
    periods.add("Night");
  }

  /**
   * A placeholder method slows down the simulation process in order to match the time of morning
   * and afternoon with the time of daytime.
   *
   * @return "Day".
   */
  public String dayPeriod() {
    Observable<DayPeriod> observable = simulatorView.getMostRecentPeriod(periods);
    String period = observable.toBlocking().first().toString();
    return period;
  }
}
