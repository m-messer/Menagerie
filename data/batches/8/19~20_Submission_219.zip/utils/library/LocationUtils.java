package utils.library;

import field.Field;
import field.Location;
import java.util.List;
import species.animal.Animal;

/**
 * This class is the location utils library and it contains methods which can be used while
 * determining the locations of species and diseases.
 *
 * @version 2020.02.18 (1)
 */
public class LocationUtils {

  private Location location;
  private Field field;

  /**
   * Initialise the location library.
   *
   * @param field The field in the simulator.
   * @param location The location of the field.
   */
  public LocationUtils(Field field, Location location) {
    this.location = location;
    this.field = field;
  }

  /**
   * Set the initial location of species when the simulation begins.
   *
   * @param newLocation The location of the species.
   */
  public void setLocation(Location newLocation) {
    if (location != null) {
      field.clear(location);
    }
    location = newLocation;
  }

  /**
   * Determine the new location of species.
   *
   * @param newLocation The new location of species.
   */
  public void goToNewLocation(Location newLocation, Object object) {
    if (newLocation == null) {
      newLocation = getField().freeAdjacentLocation(getLocation());
    }
    if (newLocation != null) {
      setLocation(newLocation);
      if (object instanceof Animal) {
        getField().place(object, newLocation);
      }
    } else {
      if (object instanceof Animal) {
        ((Animal) object).setDead();
      }
    }
  }

  /** @return A list of free adjacent locations in the field. */
  public List<Location> getFreeAdjacentLocations() {
    Field field = getField();
    List<Location> free = field.getFreeAdjacentLocations(getLocation());
    return free;
  }

  public Location getOneAdjacentLocation() {
    return getField().freeAdjacentLocation(getLocation());
  }

  /** @return A list of adjacent locations in the field. */
  public List<Location> getAdjacentLocations() {
    Field field = getField();
    List<Location> adjacent = field.adjacentLocations(getLocation());
    return adjacent;
  }

  /** Clear the location if species die. */
  public void clearLocation() {
    if (location != null) {
      field.clear(location);
      location = null;
      field = null;
    }
  }

  /** @return The field in the simulator. */
  public Field getField() {
    return field;
  }

  /** @return The location of the field. */
  public Location getLocation() {
    return location;
  }
}
