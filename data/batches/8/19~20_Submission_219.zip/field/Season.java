package field;

/**
 * There are two seasons of the field - winter and non-winter. After some time, it will be winter in
 * the field and the season will not change again.
 *
 * @version 2020.02.22 (1)
 */
public class Season {

  // If it is winter or not
  private boolean isWinter;

  /** At the beginning, it is not winter. */
  public Season() {
    isWinter = false;
  }

  /** The season will change to winter after around 10 seconds after starting the simulator. */
  public void changeToWinter() {
    // A thread that will not block the main thread
    // The simulator will freeze if there is not other thread
    Runnable r =
        () -> {
          try {
            Thread.sleep(10000);
          } catch (InterruptedException e) {
            e.printStackTrace();
          }
          isWinter = true;
        };
    new Thread(r).start();
  }

  /** @return If it is winter after some time. */
  public boolean isWinter() {
    changeToWinter();
    return isWinter;
  }
}
