package field;

/**
 * This class is the helper class for SimulatorView class to display the information about periods
 * of one day. The day has three periods - morning, afternoon and evening. Morning and afternoon are
 * also referred as 'day' - the time after sunrise and before sunset.
 *
 * @version 2020.02.21 (1)
 */
public class DayPeriod {

  // Three periods of the day
  private String morning;
  private String afternoon;
  private String evening;
  // The period of the day
  // Helps to determine if it is daytime or not
  private String period;

  /**
   * Initialises the day with its three periods.
   *
   * @param morning Morning.
   * @param afternoon Afternoon.
   * @param evening Evening.
   */
  public DayPeriod(String morning, String afternoon, String evening) {
    this.morning = morning;
    this.afternoon = afternoon;
    this.evening = evening;
  }

  /**
   * Initialises the day with two periods - daytime period and nighttime period.
   *
   * @param period The periods of the day - daytime and nighttime.
   */
  public DayPeriod(String period) {
    this.period = period;
  }

  /**
   * The period is morning and it will last for a certain time.
   *
   * @return A string which will shown in the GUI.
   * @throws InterruptedException If the last of morning is interrupted.
   */
  public String morning() throws InterruptedException {
    dayPeriodLast();
    return morning;
  }

  /**
   * The period is afternoon and it will last for a certain time.
   *
   * @return A string which will shown in the GUI.
   * @throws InterruptedException If the last of afternoon is interrupted.
   */
  public String afternoon() throws InterruptedException {
    dayPeriodLast();
    return afternoon;
  }

  /**
   * The period is evening and it will last for a certain time.
   *
   * @return A string which will shown in the GUI.
   * @throws InterruptedException If the last of evening is interrupted.
   */
  public String evening() throws InterruptedException {
    dayPeriodLast();
    return evening;
  }

  /**
   * Determines if it is daytime or nighttime.
   *
   * @param period Daytime or nighttime.
   * @return One of these periods (daytime or nighttime) of the day.
   */
  public static DayPeriod period(String period) {
    return new DayPeriod(period);
  }

  /**
   * Using thread to make the three periods last for a while.
   *
   * @throws InterruptedException If the thread is interrupted.
   */
  private static void dayPeriodLast() throws InterruptedException {
    Thread.sleep(500);
  }

  /** @return The indication of daytime and nighttime. */
  @Override
  public String toString() {
    return period;
  }
}
