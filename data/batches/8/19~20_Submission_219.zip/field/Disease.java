package field;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import species.Plant;
import species.animal.Animal;
import utils.Randomizer;
import utils.library.LocationUtils;

/**
 * This disease will eliminate the plants and animals if it has infected by certain probabilities.
 *
 * @version 2020.02.18 (1)
 */
public class Disease {

  // The probability that the disease will infect species
  private static final double INFECTION_PROBABILITY = 0.01;
  // The amount of species that the disease will infect
  private static final int INFECTION_AMOUNT = 5;
  // Once infected, species will be killed by the disease by this probability
  private static final double KILLING_PROBABILITY = 0.30;

  // Fields used to locate the disease in the field
  private Field field;
  private LocationUtils locationUtils;

  // The random number that determines the actions of the disease
  private static final Random rand = Randomizer.getRandom();

  /**
   * Initialise the disease by putting it in the field.
   *
   * @param field The field of the simulator.
   * @param location The location in the field.
   */
  public Disease(Field field, Location location) {
    this.field = field;
    locationUtils = new LocationUtils(field, location);
    setInitialLocation(location);
  }

  /**
   * Set the beginning location of the disease.
   *
   * @param location The location of the field.
   */
  private void setInitialLocation(Location location) {
    locationUtils.setLocation(location);
    field.placeDisease(this, location);
  }

  /**
   * The actions of the disease: 1. spread to the next available location, 2. kills species.
   *
   * @param newDiseases The new diseases spread to adjacent locations.
   */
  public void act(List<Disease> newDiseases) {
    spread(newDiseases);
    Location newLocation = kill();
    locationUtils.goToNewLocation(newLocation, this);
  }

  /**
   * The disease will spread in the field if the adjacent location is free.
   *
   * @param newDiseases
   */
  private void spread(List<Disease> newDiseases) {
    List<Location> freeAdjacentLocation = locationUtils.getFreeAdjacentLocations();
    // How many new diseases will be spread
    int spreadAmount = getSpreadAmount();
    for (int i = 0; i < spreadAmount && freeAdjacentLocation.size() > 0; i++) {
      Location loc = freeAdjacentLocation.remove(0);
      Disease spread = new Disease(field, loc);
      newDiseases.add(spread);
    }
  }

  /** @return The field that the disease is in. */
  public Field getField() {
    return field;
  }

  /**
   * The amount of disease spread is determined by the infection probability.
   *
   * @return The amount of new diseases will be spread.
   */
  public int getSpreadAmount() {
    int spreadAmount = 0;
    if (rand.nextDouble() <= INFECTION_PROBABILITY) {
      spreadAmount = rand.nextInt(INFECTION_AMOUNT);
    }
    return spreadAmount;
  }

  /**
   * The disease will kill animals and plants.
   *
   * @return The location where the disease killed species.
   */
  private Location kill() {
    List<Location> adjacent = locationUtils.getAdjacentLocations();
    Iterator<Location> it = adjacent.iterator();
    while (it.hasNext()) {
      Location where = it.next();
      where = removeObjectAfterKill(where);
      return where;
    }
    return null;
  }

  /**
   * Remove the object in the field after killed by the disease.
   *
   * @param where The location where a individual of species was killed.
   * @return The location where a individual of species was killed.
   */
  private Location removeObjectAfterKill(Location where) {
    Object object = field.getObjectAt(where);
    if (rand.nextDouble() <= KILLING_PROBABILITY) {
      if (object instanceof Animal) {
        ((Animal) object).setDead();
        return where;
      }
      if (object instanceof Plant) {
        ((Plant) object).setDead();
        return where;
      }
    }
    return where;
  }
}
