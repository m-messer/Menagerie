import java.lang.Math;

/**
 * Models time in the simulation
 *
 * @version 23.02.20
 */
public class Time {
    // Number of steps per day (represents 12 hours).
    private int stepsPerDay;
    private boolean isDay = true; // false = night
    // How long (in terms of steps) the simulation has been running for
    private int currentTime;
    // How long (in terms of days and nights) the simulation has been running for
    private int numberOfDays;
    // How long (in terms of days) the simulation has been running for
    private int numberOfWholeDays;

    /**
     * Constructor for class Time
     * @param stepsPerDay Number of steps per day
     */
    public Time(int stepsPerDay) {
        this.stepsPerDay = stepsPerDay;
    }
    
    /**
     * Keeps track of how much time has passed since beginning of simulation in terms on days
     * Controls whether the simulation is experiencing day or night
     */
    public void update() {
        currentTime++; // time has passed 
        if(currentTime % stepsPerDay == 0) {
            isDay = !isDay;
            numberOfDays++;
            numberOfWholeDays = numberOfDays / 2;            
        }
        
    }
    
    /**
     * @return true if it is the day, false otherwise
     */
    public boolean getIsDay() {
        return isDay;
    }

    /**
     * @return steps per day
     */
    public int getStepsPerDay() {
        return stepsPerDay;
    }   

    /**
     * @return how long (in terms of steps) the simulation has been running for
     */
    public int getCurrentTime() {
        return currentTime;
    }
    
    /**
     * @return how long (in terms of days) the simulation has been running for
     */
    public int getNumberOfWholeDays() {
        return numberOfWholeDays;
    }
    
    /**
     * @return true if a day (24 hours has passed), false otherwise
     */
    public boolean getIsNewDay() {
        return getCurrentTime() % (getStepsPerDay()*2) == 0;
    }

    /**
     * Resets the simulation to the initial state (before running)
     */
    public void reset() {
        isDay = true;
        currentTime = 0;
        numberOfDays = 0;
        numberOfWholeDays = 0;
    }
}
    