import java.util.Random;
import java.util.List;

/**
 * A simple model of a plant.
 * Plants age, reproduce and die. They grow faster in the rain and can only grow during the day.
 *
 * @version 23.02.20
 */
public class Plant extends Organism {
    // Characteristics shared by all Plants (class variables).
    
    private static final Random rand = Randomizer.getRandom();
    // The age to which a Plant can live.
    private static final int MAX_AGE = 15;
    // How long a Plant can survive without rain.
    private static final int RAIN_FOOD_LEVEL = 2;
    // The maximum number of new plants.
    private static final int MAX_LITTER_SIZE = 1;
    // How likely a plant is going to reproduce.
    private static double GROWTH_PROBABILITY = 0.04;

    /**
     * Create a Plant. A Plant can be created as a new born (age zero
     * and not hungry) or with a random age.
     * 
     * @param randomAge If true, the Plant will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location) {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            changeFoodLevel(rand.nextInt(RAIN_FOOD_LEVEL));
        } else {
            changeFoodLevel(RAIN_FOOD_LEVEL);
        }
    }

    @Override
    public void act(List<Organism> newOrganisms, Time time, Weather currentWeather) {
        if(time.getIsNewDay()) { // Plants age per day
            incrementAge();
        }
        
        if(isAlive() && time.getIsDay()) {
            weatherEffect(currentWeather);
            reproduce(newOrganisms);
            diseaseEffectUpdate();
        } else {
            changeFoodLevel(-1);
        }
    }
    
    @Override
    protected void weatherEffect(Weather currentWeather) {
        GROWTH_PROBABILITY = setGrowthProbability(currentWeather);
        
        if(currentWeather == Weather.RAIN) {
            changeFoodLevel(RAIN_FOOD_LEVEL);  // Plants cannot grow without rain
        }
    }
    
    /**
     * Changes the growth probability of plants depending on the weather conditions
     * @param currentWeather The weather the simulation is experiencing
     * @return a growth probability value depending on currentWeather
     */
    private double setGrowthProbability(Weather currentWeather) {
        if(currentWeather == Weather.RAIN) {
            return 0.06; // Plants grow faster in the rain
        }
        return 0.04;
    }

    @Override
    public int getMaxAge() {
        return MAX_AGE;
    }

    @Override
    protected double getBreedingProbability() {
        return GROWTH_PROBABILITY;
    }

    @Override
    public int getBreedingAge() {
        return 0;
    }

    @Override
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }    
}
