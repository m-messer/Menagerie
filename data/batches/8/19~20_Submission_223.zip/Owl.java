import java.util.Random;

/**
 * A simple model of an Owl.
 * Owls age, move, eat Rats, and die.
 *
 * @version 23.02.20
 */
public class Owl extends Animal {
    // Characteristics shared by all Owls (class variables).

    // The age to which an Owl can live.
    private static final int MAX_AGE = 1500;
    /* The food value of a single rat. In effect, this is the
       number of steps an Owl can go before it has to eat again. */
    private static final int RAT_FOOD_VALUE = 50;
    // The age at which an Owl can start to breed.
    private static final int BREEDING_AGE = 300;    
    // The likelihood of an Owl breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create an Owl. An Owl can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Owl will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Owl(boolean randomAge, Field field, Location location) {
        super(field, location);

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            changeFoodLevel(rand.nextInt(RAT_FOOD_VALUE));
        } else {
            changeFoodLevel(RAT_FOOD_VALUE);
        }
    }

    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    @Override
    public int getMaxAge() {
        return MAX_AGE;
    }
    
    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected void weatherEffect(Weather currentWeather) {

    }

    @Override
    protected int getPreyFoodLevel() {
        return RAT_FOOD_VALUE;
    }

    @Override
    protected boolean isEdible(Organism org) {
        return org instanceof Rat;
    }
}
