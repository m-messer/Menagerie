/**
 * Representation of all the weather conditions the simulation could experience
 *
 * @version 23.02.20
 */
public enum Weather {
    CLEAR, RAIN;
}