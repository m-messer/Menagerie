import java.util.Random;

/**
 * A simple model of a Insect.
 * Insects age, move, breed, eat Plants and die. Insects are nocturnal.
 *
 * @version 23.02.20
 */
public class Insect extends Animal {
    // Characteristics shared by all Insects (class variables).
    
    // The age to which an Insect can live.
    private static final int MAX_AGE = 500;
    /* The food value of a single Plant. In effect, this is the
       number of steps an Insect can go before it has to eat again. */
    private static final int PLANT_FOOD_VALUE = 60;
    // The age at which an Insect can start to breed.
    private static final int BREEDING_AGE = 30;  
    // The likelihood of an Insect breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();    
    
    /**
     * Create a new Insect. A Insect may be created with age
     * zero (a new born) or with a random age. It is nocturnal.
     * 
     * @param randomAge If true, the Insect will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Insect(boolean randomAge, Field field, Location location) {
        super(field, location);
        setNocturnal();

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            changeFoodLevel(rand.nextInt(PLANT_FOOD_VALUE));
        } else {
            changeFoodLevel(PLANT_FOOD_VALUE);
        }
    }

    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    @Override
    public int getMaxAge() {
        return MAX_AGE;
    }
    
    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected void weatherEffect(Weather currentWeather) {

    }

    @Override
    protected int getPreyFoodLevel() {
        return PLANT_FOOD_VALUE;
    }

    @Override
    protected boolean isEdible(Organism org) {
        return org instanceof Plant;
    }
}
