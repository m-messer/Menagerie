/**
 * Representation of all the diseases the Organisms could catch
 *
 * @version 23.02.20
 */
public enum Disease {
    HUNGER {
        @Override
        void sideEffects(Organism org) { 
            org.changeFoodLevel(-1); 
        }

        @Override
        double getInfectionProbabilty() { 
            return 0.2; 
        }
    },
    
    SUPER_AGEING {
        @Override
        void sideEffects(Organism org) { 
            org.incrementAge(); 
        }

        @Override
        double getInfectionProbabilty() { 
            return 0.8; 
        }
    };

    /**
     * The side effects associated with each disease
     * Each disease type will override this method
     */
    abstract void sideEffects(Organism org);
    
    /**
     * The probability of getting the disease
     * Each disease type will override this method
     */
    abstract double getInfectionProbabilty();
}