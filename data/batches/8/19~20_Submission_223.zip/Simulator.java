import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and Foxs.
 *
 * @version 23.02.20
 */
public class Simulator {
    /* Constants representing configuration information for the simulation. */
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120; 
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 250;
    // The default steps per day.
    private static final int DEFAULT_STEPS_PER_DAY = 6;
    // The probability that a Owl will be created in any given grid position.
    private static final double OWL_CREATION_PROBABILITY = 0.1; 
    // The probability that a Rat will be created in any given grid position.
    private static final double RAT_CREATION_PROBABILITY = 0.17; 
    // The probability that a Mongoose will be created in any given grid position.
    private static final double MONGOOSE_CREATION_PROBABILITY = 0.14; 
    // The probability that a Snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.12; 
    // The probability that an Insect will be created in any given grid position.
    private static final double INSECT_CREATION_PROBABILITY = 0.11;
    // The probability that a Frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.1;
    // The probability that a Plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.09; 
    // The probability that the simulation will experience rain each step.
    private static final double RAIN_PROBABILITY = 0.2;
    private static Random rand; 

    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current time in the simulation.
    private Time time;
    // The current weather in the simulation.
    private Weather currentWeather;
        
    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH, DEFAULT_STEPS_PER_DAY);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * @param stepsPerDay Steps in one day. Must be greater than zero.
     */
    public Simulator(int depth, int width, int stepsPerDay) {
        if(width <= 0 || depth <= 0 || stepsPerDay <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
            stepsPerDay = DEFAULT_STEPS_PER_DAY;
        }

        time = new Time(stepsPerDay);

        organisms = new ArrayList<>();
        currentWeather = Weather.CLEAR;

        field = new Field(depth, width);
        
        rand = Randomizer.getRandom();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rat.class, Color.PINK);
        view.setColor(Owl.class, Color.BLUE);
        view.setColor(Mongoose.class, Color.MAGENTA);
        view.setColor(Snake.class, Color.YELLOW);
        view.setColor(Insect.class, Color.CYAN);
        view.setColor(Frog.class, Color.ORANGE);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(75);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each Organism.
     */
    public void simulateOneStep() {        
        // Updates how much time has passed since beginning of simulation
        time.update();
        // Decide weather conditions
        currentWeather = generateWeather();            

        // Provide space for newborn organisms.
        List<Organism> newOrganisms = new ArrayList<>();
        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms, time, currentWeather);
            if(!organism.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(time.getCurrentTime(), field, time, currentWeather);
    }
    
    /**
     * Controls the weather the simulation is experiencing
     * @return a weather condition from those specified in Weather
     */
    private Weather generateWeather() {
        Random rand = new Randomizer().getRandom();
        if(rand.nextDouble() <= RAIN_PROBABILITY) {
            return Weather.RAIN;
        }
        
        return Weather.CLEAR; // default weather condition
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        organisms.clear();
        time.reset();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(time.getCurrentTime(), field, time, Weather.CLEAR);
    }
    
    /**
     * Randomly populate the field with Organisms
     */
    private void populate() {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    organisms.add(owl);
                } else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(true, field, location);
                    organisms.add(rat);
                } else if(rand.nextDouble() <= MONGOOSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mongoose mongoose = new Mongoose(true, field, location);
                    organisms.add(mongoose);
                } else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    organisms.add(snake);
                } else if(rand.nextDouble() <= INSECT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Insect insect = new Insect(true, field, location);
                    organisms.add(insect);
                } else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    organisms.add(frog);
                } else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    organisms.add(plant);
                } // else leave the location empty.
            }
        }
        
        generateInfected();
    }
    
    /**
     * Randomly infects an Organism that was created
     */
    private void generateInfected() {
        int randomAnimal = rand.nextInt(organisms.size()); // select a random animal
        Disease[] diseases = Disease.values(); 
        int pickDisease = rand.nextInt(diseases.length); // select a random disease
        Disease selectedDisease = diseases[pickDisease];
        
        organisms.get(randomAnimal).infect(selectedDisease); // and infect the animal with this disease
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }    
}
