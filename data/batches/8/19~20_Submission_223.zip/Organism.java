import java.util.Random;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Superclass for all living organisms to inherit from
 *
 * @version 23.02.20
 */
public abstract class Organism {
    // Characteristics shared by all Organisms (class variables).

    // The random number generator used by the organism
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields)

    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // The organism's age.
    private int age;
    /* The organism's food/energy level
     * This is effectively how long the organism can survive without eating */
    private int foodLevel;
    // The diseases the organism is currently carrying
    private Set<Disease> activeDiseases;

    /**
     * Create a new organism at location in field
     *
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Organism(Field field, Location location) {
        alive = true;
        foodLevel = 0;
        this.field = field;

        activeDiseases = new HashSet<>();

        setLocation(location);
        setAge(0);
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }
    
    /**
     * @return The current food level of the organism
     */
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Change the food level of the organism
     * @param amount Positive parameter value increases the how long the organism
     *               can go without needing to eat,
     *               negative decreases the food level
     */
    public void changeFoodLevel(int amount) {
        foodLevel += amount;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation) {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Set the age of the organism to a new value
     * @param newAge the age of organism
     */
    protected void setAge(int newAge) {
        age = newAge;
    }  

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Increase the age.
     * This could result in the organism's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * @return The age of the organism
     */
    protected int getAge() {
        return age;
    }

    /**
     * @return The maximum age of the organism
     */
    abstract protected int getMaxAge();

    /**
     * Create new Organisms and place them in empty neighbouring cells
     * @param newOrganisms An array holding all the new organisms to be created at this step
     */
    protected void reproduce(List<Organism> newOrganisms) {
        List<Location> free = getField().getFreeAdjacentLocations(getLocation());

        // Create new organisms only if there are free adjacent locations
        if(free != null) {
            int births = breed();

            // Check for free locations to place new animals
            for (int b = 0; b < births && free.size() > 0; b++) {

                Location loc = free.remove(0);

                // Create new organisms of the relevant subclass of organism
                Constructor constructor = null;
                Class<?> organismClass = this.getClass();

                try { // Getting the constructor for this species
                    constructor = organismClass.getDeclaredConstructor(boolean.class, Field.class, Location.class);
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                }

                // Initialise this new young
                Organism young = initYoung(constructor, loc);

                newOrganisms.add(young);
            }
        }
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField() {
        return field;
    }
    
    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation() {
        return location;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An organism can breed if it has reached the breeding age.
     */
    protected boolean canBreed() {
        return getAge() >= getBreedingAge();
    }

    /**
     * @return The age at which an organism can breed
     */
    abstract protected int getBreedingAge();

    /**
     * @return The probability of an organism creating offspring
     */
    abstract protected double getBreedingProbability();

    /**
     * @return The max litter size of the organism
     */
    abstract protected int getMaxLitterSize();

    /**
     * Creates new instance of a organism from the constructor in a certain location
     * @param constructor The constructor of the animal or plant the new organism should be
     * @param loc   The location of the where this new animal or plant should be created
     * @return The instance of the new organism that is created
     */
    private Organism initYoung(Constructor constructor, Location loc) {
        Organism young = null;

        try { // creating a new instance
            young = (Organism) constructor.newInstance(false, getField(), loc);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return young;
    }
    
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born animals.
     */
    abstract public void act(List<Organism> newOrganisms, Time time, Weather currentWeather);

    /**
     * Implements the side effects on each organism
     */
    protected void diseaseEffectUpdate() {
        for(Disease disease : activeDiseases) {
            disease.sideEffects(this); // Uses methods from enum
        }
    }

    /**
     * @return true if the animal is carrying at least one disease, false otherwise
     */
    protected boolean hasDisease() {
        return !activeDiseases.isEmpty();
    }

    /**
     * Spreads all diseases the infector has to the infected Organism
     * @param infector The Organism that is currently has the diseases
     * @param infected The Organism that the diseases is being spread to
     */
    protected void infectAll(Organism infector, Organism infected) {
        for(Disease disease : infector.getActiveDiseases()) {
            infected.infect(disease);
        }
    }
    
    /**
     * @return The set of all diseases that is currently being carried
     */
    protected Set<Disease> getActiveDiseases() {
        return activeDiseases;
    }
    
    /**
     * Call this method to make an organism carry this disease
     */
    protected void infect(Disease disease) {
        if(rand.nextDouble() <= disease.getInfectionProbabilty()) {
            activeDiseases.add(disease);
        }
    }    
    
    /**
     * Allocates how each weather event affects each species
     * @param currentWeather The weather the simulation is currently experiencing
     */
    abstract protected void weatherEffect(Weather currentWeather);
}
