import java.util.Random;

/**
 * A simple model of a Frog.
 * Frogs age, move, eat Insects, and die. They are nocturnal and get less hungry when it rains.
 *
 * @version 23.02.20
 */
public class Frog extends Animal {
    // Characteristics shared by all Frogs (class variables).

    // The age to which a Frog can live.
    private static final int MAX_AGE = 1000;
    /* The food value of a single Insect. In effect, this is the
       number of steps a Frog can go before it has to eat again. */
    private static final int INSECT_FOOD_VALUE = 25;
    // The age at which a Frog can start to breed.
    private static final int BREEDING_AGE = 200;
    // The likelihood of a Frog breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 60;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Frog. A Frog can be created as a new born (age zero
     * and not hungry) or with a random age and food level. It is nocturnal.
     * 
     * @param randomAge If true, the Frog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog(boolean randomAge, Field field, Location location) {
        super(field, location);
        setNocturnal();

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            changeFoodLevel(rand.nextInt(INSECT_FOOD_VALUE));
        } else {
            changeFoodLevel(INSECT_FOOD_VALUE);
        }
    }

    @Override
    protected void weatherEffect(Weather currentWeather) {
        if(currentWeather == Weather.RAIN) {
            this.changeFoodLevel(5);
        }
    }

    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    @Override
    public int getMaxAge() {
        return MAX_AGE;
    }

    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected int getPreyFoodLevel() {
        return INSECT_FOOD_VALUE;
    }

    @Override
    protected boolean isEdible(Organism org) {
        return org instanceof Insect;
    }
}
