import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 23.02.20
 */
public abstract class Animal extends Organism {    
    // Individual characteristics (instance fields).
    
    // Gender of each animal
    private boolean gender;
    // Stores whether animal is nocturnal
    private boolean isNocturnal;

    /**
     * Create a new animal at location in field
     * and generate gender for the animal
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        super(field, location);
        gender = setGender();
    }

    /**
    * Randomly allocates a gender to each animal
    * @return a boolean value that corresponds to the animal's gender 
    */
    protected boolean setGender() {
        Random rand = Randomizer.getRandom();
        int number = rand.nextInt(10);
        return number <= 5; // true = female
    }

    /**
     * Returns the gender of this animal
     * @return true if female, false otherwise
     */
    protected boolean getGender() {
        return gender;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born animals.
     */
    @Override
    public void act(List<Organism> newOrganisms, Time time, Weather currentWeather) {
        if(time.getIsNewDay()) { // Animals age per day
            incrementAge();
        }
        
        if(isActive(time.getIsDay())) { // Animals get hungry every time they move
            incrementHunger();
        }

        if(isAlive() && isActive(time.getIsDay())) {
                // Processes the effects taken from weather
                weatherEffect(currentWeather);
                
                giveBirth(newOrganisms);
                
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                    // Processes the effects taken from disease
                    diseaseEffectUpdate();
                } else {
                    // Overcrowding.
                    setDead();
                }
        }
    }

    /**
     * Decreases the food level of the animal
     */
    protected void incrementHunger() {
        changeFoodLevel(-1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }

    /**
     * Outputs whether the animal moves depending on what time of day it is and its
     * nocturnality/diurnality
     * @return true if the animal if getIsNocturnal() and isDay have different values, false otherwise
     */
    protected boolean isActive(boolean isDay) {
        return getIsNocturnal() ^ isDay;
    }

    /**
     * @return true if the animal is nocturnal, false otherwise
     */
    protected boolean getIsNocturnal() {
        return isNocturnal;
    }

    /**
     * Call this method if an animal is to be nocturnal
     */
    protected void setNocturnal() {
        isNocturnal = true;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrganisms A list to return newly born animals.
     */
    protected void giveBirth(List<Organism> newAnimals) {
        // New animals are born into adjacent locations.
        // Get field
        Field field = getField();
        // Get a list of adjacent free locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
     
        // Check all adjacent locations for the animals that occupy them
        for(Location location : adjacent) {
            Object obj = field.getObjectAt(location);

            if(obj != null && !(obj instanceof Plant)) {
                // Get animal in adjacent location
                Animal animal = (Animal) obj;

                // Check if animal is capable of breeding
                if(sameType(animal) && animal.getGender() != this.getGender()) {
                    spreadDisease(animal); // Disease can be spread through reproduction
                    reproduce(newAnimals);
                }
            }
        }
    }    

    /**
     * Look for food (other animals or plants) adjacent to the current location.
     * Only the first live food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        
        // Get adjacent locations
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            
            // Get the object in the neighbouring location
            Object obj = field.getObjectAt(where); 
            
            // Check if animal can be eaten
            if(obj != null && isEdible((Organism) obj) ) { 
                Organism organism = (Organism) obj;
                
                if(organism.isAlive()) {
                    spreadDisease(organism);
                    organism.setDead();
                    changeFoodLevel(getPreyFoodLevel()); // Reset foodLevel to its assigned value
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Checks if any animals currently reproducing have diseases and spreads them to each other
     * @param organism The other animal involved in reproduction
     */
    private void spreadDisease(Organism organism) {
        if(organism.hasDisease()) {
            infectAll(organism, this);
        } else if(this.hasDisease()) {
            infectAll(this, organism);
        }
    }

    /**
     * Checks whether an animal is of the same species as this instance's
     * @param animal The animal to compare to
     * @return true if the two animals are of the same species, false otherwise
     */
    private boolean sameType(Animal animal) {
        return animal.getClass().equals(this.getClass());
    }
    
    /**
     * @return The number of steps an animal can go before it has to eat again
     */
    abstract protected int getPreyFoodLevel();  
    
    /**
     * Checks if an organism can be eaten by another organism
     * @param org The organism that could be eaten
     * @return true if the organism can be eaten, false otherwise
     */
    abstract protected boolean isEdible(Organism org);
}
