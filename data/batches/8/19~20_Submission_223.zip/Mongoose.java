import java.util.Random;

/**
 * A simple model of a Mongoose.
 * Mongooses age, move, eat Snakes, and die.
 *
 * @version 23.02.20
 */
public class Mongoose extends Animal {
    // Characteristics shared by all Mongooses (class variables).
    
    // The age to which a Mongoose can live.
    private static final int MAX_AGE = 600;
    /* The food value of a single snake. In effect, this is the
       number of steps a Mongoose can go before it has to eat again. */
    private static final int SNAKE_FOOD_VALUE = 10;
    // The age at which a Mongoose can start to breed.
    private static final int BREEDING_AGE = 50;
    // The likelihood of a Mongoose breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Mongoose. A Mongoose can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Mongoose will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mongoose(boolean randomAge, Field field, Location location) {
        super(field, location);

        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            changeFoodLevel(rand.nextInt(SNAKE_FOOD_VALUE));
        } else {
            changeFoodLevel(SNAKE_FOOD_VALUE);
        }
    }
   
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    @Override
    public int getMaxAge() {
        return MAX_AGE;
    }

    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected void weatherEffect(Weather currentWeather) {

    }

    @Override
    protected int getPreyFoodLevel() {
        return SNAKE_FOOD_VALUE;
    }

    @Override
    protected boolean isEdible(Organism org) {
        return org instanceof Snake;
    }
}
