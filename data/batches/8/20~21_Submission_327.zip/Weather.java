import java.util.Random;
/**
 * This class models weather, which influences plants' growth.
 *
 * @version 1.0
 */
public class Weather
{
    private String weather; // the current weather in the simulation
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
    }
    
    /**
     * Randomly set weather in the simulation.
     */
    public void setWeather()
    {
        Random rand = new Random();
        double weatherProbability = rand.nextDouble();
        
        if(weatherProbability < 0.4) {
            weather = "Clear";
        } 
        else if(weatherProbability >= 0.4 && weatherProbability < 0.75) {
            weather = "Rainy";
        } 
        else {
            weather = "Foggy";
        }
    }
    
    /**
     * Get the current weather.
     * @return the current weather
     */
    public String getWeather()
    {
        return weather;
    }
}
