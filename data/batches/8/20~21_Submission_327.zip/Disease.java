import java.util.Random;
/**
 * This class simulates disease in the habitat.
 *
 * @version 1.0
 */
public class Disease
{

    /**
     * Constructor for objects of class Disease
     */
    public Disease()
    {
    }

    /**
     * Simulate disease, that is randomly generate a disease outbreak, can happen every 50 steps
     * @param currentStep The current step in the simulation
     * @return true when disease outbreaks, false otherwise
     */
    public boolean simulateDisease(int currentStep)
    {
        if(currentStep % 50 == 0 && currentStep != 0) {
            Random randomGenerator = new Random();
            int randomNumber = randomGenerator.nextInt(5);
            
            return randomNumber == 0; // 20% chance of disease
        }
        // else do nothing, disease can occur every 50 steps
        return false;
    }
}
