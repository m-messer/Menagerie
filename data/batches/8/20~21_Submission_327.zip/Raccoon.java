import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * A simple model of a raccon.
 * Raccoons age, move, eat prey, and die.
 *
 * @version 1.0
 */
public class Raccoon extends Predator
{
    // Characteristics shared by all raccoons (class variables).
    
    // The age at which a raccoon can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a raccoon can live.
    private static final int MAX_AGE = 110;
    // The likelihood of a raccoon breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single raccoon. In effect, this is the
    // number of steps a raccoon can go before it has to eat again.
    private static final int PREY_FOOD_VALUE = 17;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The raccoon's age.
    private int age;
    // The raccoon's food level, which is increased by eating frogs or mice
    private int foodLevel;
    
    /**
     * Create a raccoon. A raccoon can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the raccoon will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Is the raccoon male?
     */
    public Raccoon(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PREY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PREY_FOOD_VALUE;
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this raccoon is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRaccoons A list to return newly born raccoons.
     */
    protected void giveBirth(List<Animal> newRaccoons)
    {
        // New raccoons are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Raccoon young = new Raccoon(false, field, loc, getRandomSex());
            newRaccoons.add(young);
        }
    }
    
    /**
     * Get the breeding age.
     * @return The breeding age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Get the max age.
     * @return The max age.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Get the breeding probability.
     * @return The breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Get the max number of offspring.
     * @return The max no of offspring.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Get the current age.
     * @return The current age.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Increment age by one.
     */
    protected void changeAge()
    {
        age++;
    }
    
    /**
     * Get the current food level.
     * @return The current food level.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Decrement food level by one.
     */
    protected void decrementFoodLevel()
    {
        foodLevel--;
    }
}
