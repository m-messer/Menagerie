import java.util.Random;
import java.util.List;
/**
 * A simple model of poison mushroom.
 * poison mushroom ages, reproduces, and dies.
 *
 * @version 1.0
 */
public class PoisonMushroom extends Plant
{
    // Characteristics shared by all poison mushroom (class variables).

    // The age at which poison mushroom can start to reproduce.
    private static final int REPRODUCTION_AGE = 4;
    // The age to which poison mushroom can live.
    private static final int MAX_AGE = 30;
    // The likelihood of poison mushroom breeding.
    private static final double REPRODUCE_PROBABILITY = 0.11;
    // The maximum number of reproductions.
    private static final int MAX_NO_OF_SEEDS = 3;
    // The age at which the poison mushroom can be eaten
    private static final int READY_TO_BE_EATEN_AGE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The poison mushroom' age.
    private int age;

    /**
     * Create new poison mushroom. Poison mushroom may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the poison mushroom will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isReadyToBeEaten Is the poison mushroom ready to be eaten?
     * @param isPoisonous Is the poison mushroom poisonous?
     */
    public PoisonMushroom(boolean randomAge, Field field, Location location, boolean isReadyToBeEaten, boolean isPoisonous)
    {
        super(field, location, isReadyToBeEaten, isPoisonous);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * Check whether or not this poison mushroom is to reproduce at this step.
     * New reproductions will be made into free adjacent locations.
     * @param newPoisonMushrooms A list to return new grass.
     * @param currentWeather The current weather in the simulation
     */
    protected void giveBirth(List<Plant> newPoisonMushrooms, String currentWeather)
    {
        // New grass is born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(currentWeather);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            PoisonMushroom young = new PoisonMushroom(false, field, loc, false, true);
            newPoisonMushrooms.add(young);
        }
    }
    
    /**
     * Get the reproduction age.
     * @return The reproduction age
     */
    protected int getReproductionAge()
    {
        return REPRODUCTION_AGE;
    }
    
    /**
     * Get the max age.
     * @return The max age.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Get the reproduce probability.
     * @return The reproduce probability.
     */
    protected double getReproduceProbability()
    {
        return REPRODUCE_PROBABILITY;
    }
    
    /**
     * Get the max no of seeds, that is offspring
     * @return The max no of offspring
     */
    protected int getMaxNoOfSeeds()
    {
        return MAX_NO_OF_SEEDS;
    }
    
    /**
     * Get the current age.
     * @return The current age.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Increment age by one.
     */
    protected void changeAge()
    {
        age++;
    }
    
    /**
     * Get the ready to be eaten age.
     * @return The ready to be eaten age
     */
    protected int getReadyToBeEatenAge()
    {
        return READY_TO_BE_EATEN_AGE;
    }
}