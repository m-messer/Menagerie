import java.util.List;

/**
 * Write a description of class Predator here.
 *
 * @version 1.0
 */
public abstract class Predator extends Animal
{
    /**
     * Constructor for objects of class Predator
     */
    public Predator(Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
    }

    /**
     * Make this predator act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPredators A list to receive newly born animals.
     * @param timeOfDay The time of day in the simulation, affects behaviour of predators
     * @param isDiseaseHappening Is the disease happening, if so some predators will be infected
     */
    public void act(List<Animal> newPredators, String timeOfDay, boolean isDiseaseHappening)
    {
        incrementAge();
        incrementHunger();
        
        if(isInfected()) {
            incrementDaysInfected();
        }
        
        //if the disease is happening, randomly infect some of the predtors in the simulation
        if(isDiseaseHappening) {
            randomInfection();
        }
        
        //animals that have been infected for more than 4 steps will die
        deathDueToInfection();
        
        if(isAlive()) {
            giveBirth(newPredators);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                setDead();
            }
        }
    }
    
    /**
     * Predator consumes its food level at every step. Check if the current food level is not 0 or below, if so make this predator object dead.
     */
    protected void incrementHunger()
    {
        decrementFoodLevel();
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this predator object is to reproduce at this step.
     * New reproductions will be made into free adjacent locations.
     * @param newPrey A list to return new predators.
     */
    abstract protected void giveBirth(List<Animal> newPredators);
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood();
    
    /**
     * Get the current food level.
     * @return The current food level.
     */
    abstract protected int getFoodLevel();
    
    /**
     * Decrement food level by one.
     */
    abstract protected void decrementFoodLevel();
    
}
