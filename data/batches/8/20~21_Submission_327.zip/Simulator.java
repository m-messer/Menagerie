import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants.
 *
 * @version 1.0
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a hawk will be created in any given grid position.
    private static final double HAWK_CREATION_PROBABILITY = 0.02;
    // The probability that a poisonous mushroom will be created in any given grid position.
    private static final double POISONMUSHROOM_CREATION_PROBABILITY = 0.02;
    // The probability that a raccoon will be created in any given grid position.
    private static final double RACCOON_CREATION_PROBABILITY = 0.03;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.03;
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.04;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.06;
    // The probability that a frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.06;
    
    
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //represents time in the simulation, helps to model some behaviour
    private Time time;
    //the current weather of the simulation
    private Weather currentWeather;
    //used to simulate disease outbreaks at random
    private Disease diseaseSimulator;
    //number of disease outbreaks
    private int diseaseCounter;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Frog.class, Color.LIGHT_GRAY);
        view.setColor(Snake.class, Color.BLUE);
        view.setColor(Mouse.class, Color.RED);
        view.setColor(Raccoon.class, Color.ORANGE);
        view.setColor(Hawk.class, Color.BLACK);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(PoisonMushroom.class, Color.MAGENTA);
        
        time = new Time();
        currentWeather = new Weather();
        diseaseSimulator = new Disease();
        diseaseCounter = 0;
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        setWeather(); //set weather at each step, influences the behaviour of prey
        //check whether a disease is happening at a given step, if so increment the counter
        boolean isDiseaseHappening = diseaseSimulator.simulateDisease(step);
        if(isDiseaseHappening) {
            diseaseCounter++;
        }

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        
        // Let all plants act
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants, getWeather());
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, getTime(), isDiseaseHappening);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly grown plants to the main list.
        plants.addAll(newPlants);
        
        // Add the newly born animals to the main list.
        animals.addAll(newAnimals);
        
        view.showStatus(step, getWeather(), field, diseaseCounter);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        diseaseCounter = 0;
        animals.clear();
        plants.clear();
        populate();
        setWeather();
        
        // Show the starting state in the view.
        view.showStatus(step, getWeather(), field, diseaseCounter);
    }
    
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(true, field, location, getRandomSex());
                    animals.add(hawk);
                }
                else if(rand.nextDouble() <= POISONMUSHROOM_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    PoisonMushroom poisonmushroom = new PoisonMushroom(true, field, location, false, true);
                    plants.add(poisonmushroom);
                }
                else if(rand.nextDouble() <= RACCOON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Raccoon raccoon = new Raccoon(true, field, location, getRandomSex());
                    animals.add(raccoon);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location, getRandomSex());
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location, false, false);
                    plants.add(grass);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location, getRandomSex());
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location, getRandomSex());
                    animals.add(frog);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Models sex of an animal - male or female object
     * @return true if male, false if female
     */
    private boolean getRandomSex()
    {
        Random randomizer = new Random();
        int value = randomizer.nextInt(2);
        if(value == 0) {
            return true; // a given object is a male animal
        }
        else {
            return false; // a given object is a female animal
        }
    }
    
    /**
     * Get the current time in the simulation.
     * @return current time
     */
    private String getTime()
    {
        return time.getTimeOfDay(step);
    }
    
    /**
     * Set the weather in the simulation.
     */
    private void setWeather()
    {
        currentWeather.setWeather();
    }
    
    /**
     * Get the current weather.
     * @return current weather
     */
    private String getWeather()
    {
        return currentWeather.getWeather();
    }
}
