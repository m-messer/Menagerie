import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 1.0
 */
public abstract class Plant
{
    // is the plant alive?
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // random generator
    private static final Random rand = Randomizer.getRandom();
    // is the plant ready to be eaten?
    private boolean isReadyToBeEaten;
    // is the plant poisonous, that is, will it kill the animal if eaten?
    private boolean isPoisonous;    
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isReadyToBeEaten Is the plant ready to be eaten by animals?
     * @param isPoisonous Is the plant poisonous?
     */
    public Plant(Field field, Location location, boolean isReadyToBeEaten, boolean isPoisonous)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.isReadyToBeEaten = isReadyToBeEaten;
        this.isPoisonous = isPoisonous;
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list of plants, to which new plants will be added after "breeding"
     * @param currentWeather The current weather in the simulation
     */
    public void act(List<Plant> newPlants, String currentWeather)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newPlants, currentWeather);            
        }
    }
    
    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return "newly born" plants.
     * @param currentWeather The current weather.
     */
    abstract protected void giveBirth(List<Plant> newPlants, String currentWeather);
    
    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Is the plant ready to be eaten?
     * @return true if ready to be eaten, false otherwise
     */
    public boolean isReadyToBeEaten()
    {
        return isReadyToBeEaten;
    }
    
    /**
     * Is the plant poisonous?
     * @return true if the plant is poisonous, false otherwise
     */
    public boolean isPoisonous()
    {
        return isPoisonous;
    }
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Generate the number of new births, but first check if plant can breed and is ready to breed
     * @param currentWeather The current weather in the simulation
     * @return The number of offspring, can be 0.
     */
    protected int breed(String currentWeather)
    {
        int newPlants = 0;
        if(canBreed(currentWeather) && (rand.nextDouble() <= getReproduceProbability())) {
            newPlants = rand.nextInt(getMaxNoOfSeeds()) + 1;
        }
        return newPlants;
    }

    /**
     * Can the plant breed, checking the breeding conditions
     * @currentWeather The current weather, affects whether a plant can breed
     * @return true if the plant can breed, false otherwise.
     */
    protected boolean canBreed(String currentWeather)
    {   
        // if the weather isn't clear, the plant won't breed
        if(!(currentWeather.equals("Clear"))) {
            return false;
        }
        
        return getAge() >= getReproductionAge();
    }
    
    /**
     * Increment age, check if a plant reached its max age, if so set dead and return.
     * What's more check if a plant (after having its age incremented) is ready to be eaten.
     */
    protected void incrementAge()
    {
        changeAge();
        if(getAge() > getMaxAge()) {
            setDead();
            return; // no need to check for other conditions
        }
        
        if(getAge() >= getReadyToBeEatenAge() && !isReadyToBeEaten()) {
            isReadyToBeEaten = true;
        }
    }
    
    /**
     * Get the reproduction age.
     * @return The reproduction age
     */
    abstract protected int getReproductionAge();
    
    /**
     * Get the ready to be eaten age.
     * @return The ready to be eaten age
     */
    abstract protected int getReadyToBeEatenAge();

    /**
     * Get the max age.
     * @return The max age.
     */
    abstract protected int getMaxAge();

    /**
     * Get the reproduce probability.
     * @return The reproduce probability.
     */
    abstract protected double getReproduceProbability();

    /**
     * Get the max no of seeds, that is offspring
     * @return The max no of offspring
     */
    abstract protected int getMaxNoOfSeeds();

    /**
     * Get the current age.
     * @return The current age.
     */
    abstract protected int getAge();

    /**
     * Increment age by one.
     */
    abstract protected void changeAge();
    
}
