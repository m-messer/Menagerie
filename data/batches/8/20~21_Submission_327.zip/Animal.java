import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 1.0
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // random generator
    private static final Random rand = Randomizer.getRandom();
    // Whether the animal is a male or not.
    private boolean isMale;
    // Is the animal infected with disease?
    private boolean isInfected;
    // how many days has the animal been infected with the disease
    private int daysInfected;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Is the animal a male?
     */
    public Animal(Field field, Location location, boolean isMale)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.isMale = isMale;
        isInfected = false; // no animals are infected at the begining of the simulation
        daysInfected = 0;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param timeOfDay The time of day in the simulation, affects behaviour of prey
     * @param isDiseaseHappening Is the disease happening, if so some animals will be infected
     */
    abstract public void act(List<Animal> newAnimals, String timeOfDay, boolean isDiseaseHappening);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Generate new births, but first check if breeding conditions are satisfied.
     * @return number of new births.
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && (rand.nextDouble() <= getBreedingProbability()) && foundMatingPartner()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Can the given animal breed, that is check if the breeding age was reached.
     * @return true if the animal can breed, false otherwise
     */
    protected boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }

    /**
     * Increment the animal's age by one, if the max age has been exceeded, make the animal dead
     */
    protected void incrementAge()
    {
        changeAge();
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Is the animal male?
     * @return true if male, false otherwise.
     */
    public boolean isMale()
    {
        return isMale;
    }
    
    /**
     * Generate random sex of an animal, 50/50 chance being male/female.
     * @return true if an animal will be male, false if female.
     */
    protected boolean getRandomSex()
    {
        int value = rand.nextInt(2);
        if(value == 0) {
            return true; // a given object is a male animal
        }
        else {
            return false; // a given object is a female animal
        }
    }
    
    /**
     * Find mating partner - delegates work to Field class, which checks whether there's an animal of opposite sex around the current location
     * of the animal that is searching for a partner.
     * @return true if mating partner found, false otherwise.
     */
    protected boolean foundMatingPartner()
    {
        return getField().isMatingPartnerAvailable(location, isMale, isInfected);
    }

    /**
     * Is the animal infected with disease?
     * @return true if infected, false otherwise
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the animal infected with disease.
     */
    public void setInfected()
    {
        isInfected = true;
    }
    
    /**
     * Randomly decide if the animal will be infected with disease, 50/50 chance.
     */
    protected void randomInfection()
    {
        int value = rand.nextInt(2);
        if(value == 0) {
            isInfected = true;
        }
        // otherwise a given animal is not infected
    }
    
    /**
     * Get the current number of days since the animal was infected with disease.
     * @return The number of days with disease.
     */
    protected int getDaysInfected()
    {
        return daysInfected;
    }
    
    /**
     * Make the animal dead if the number of days with disease exceeded four.
     */
    protected void deathDueToInfection()
    {
        if(daysInfected > 4) {
            setDead();
        }
    }
    
    /**
     * Increment number of days with disease by one.
     */
    protected void incrementDaysInfected()
    {
        daysInfected++;
    }
    
    /**
     * Get the breeding age.
     * @return The breeding age.
     */
    abstract protected int getBreedingAge();

    /**
     * Get the max age.
     * @return The max age.
     */
    abstract protected int getMaxAge();

    /**
     * Get the breeding probability.
     * @return The breeding probability.
     */
    abstract protected double getBreedingProbability();

    /**
     * Get the max number of offspring.
     * @return The max no of offspring.
     */
    abstract protected int getMaxLitterSize();

    /**
     * Get the current age.
     * @return The current age.
     */
    abstract protected int getAge();

    /**
     * Increment age by one.
     */
    abstract protected void changeAge();
    
}
