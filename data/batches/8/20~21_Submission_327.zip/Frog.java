import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a frog.
 * Frogs age, move, eat plants, and die.
 *
 * @version 1.0
 */
public class Frog extends Prey
{
    // Characteristics shared by all frogs (class variables).
    
    // The age at which a frog can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a frog can live.
    private static final int MAX_AGE = 42;
    // The likelihood of a frog breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single frog. In effect, this is the
    // number of steps a frog can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The frog's age.
    private int age;
    // The frog's food level, which is increased by eating plants
    private int foodLevel;

    /**
     * Create a frog. A frog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the frog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Is the frog male?
     */
    public Frog(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if(object instanceof Plant) {
                Plant plant = (Plant) object;
                if(plant.isAlive() && plant.isReadyToBeEaten()) { 
                    plant.setDead();
                    if(plant.isPoisonous()) {
                        foodLevel = 0; // if the plant is poisonous, it will kill the frog
                    }
                    else {
                        foodLevel = PLANT_FOOD_VALUE;
                    }
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this frog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFrogs A list to return newly born frogs.
     */
    protected void giveBirth(List<Animal> newFrogs)
    {
        // New frogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Frog young = new Frog(false, field, loc, getRandomSex());
            newFrogs.add(young);
        }
    }
    
    /**
     * Get the breeding age.
     * @return The breeding age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Get the max age.
     * @return The max age.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Get the breeding probability.
     * @return The breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Get the max number of offspring.
     * @return The max no of offspring.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Get the current age.
     * @return The current age.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Increment age by one.
     */
    protected void changeAge()
    {
        age++;
    }
    
    /**
     * Get the current food level.
     * @return The current food level.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Decrement food level by one.
     */
    protected void decrementFoodLevel()
    {
        foodLevel--;
    }
}
