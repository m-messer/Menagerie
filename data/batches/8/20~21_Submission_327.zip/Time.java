
/**
 * This class models time of day, which influences the behaviour of animals.
 *
 * @version 1.0
 */
public class Time
{
    
    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
    }
    
    /**
     * Returns the current time in a 24 time units format - determined by the current step
     * @param currentStep of the simulation
     * @return current time, that is a number between 0 and 23
     */
    private int getCurrentTime(int currentStep)
    {
        return currentStep % 24;
    }
    
    /**
     * Returns the time of day provided that current step is given.
     * @param currentStep of the simulation
     * @return time of day, "night", "morning", "afternoon" or "evening" 
     */
    public String getTimeOfDay(int currentStep)
    {
        int currentTime = getCurrentTime(currentStep);
        if(currentTime >= 0 && currentTime < 7) {
            return "night";
        }
        else if(currentTime >= 7 && currentTime < 13) {
            return "morning";
        }
        else if(currentTime >= 13 && currentTime < 19) {
            return "afternoon";
        }
        else {
            return "evening";
        }
    }
}
