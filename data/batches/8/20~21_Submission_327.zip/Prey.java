import java.util.List;

/**
 * A class representing shared characteristics of prey.
 *
 * @version 1.0
 */
public abstract class Prey extends Animal
{
    /**
     * Constructor for objects of class Prey
     */
    public Prey(Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
    }

    /**
     * Make this prey act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param timeOfDay The time of day in the simulation, affects behaviour of prey
     * @param isDiseaseHappening Is the disease happening? (in this version prey cannot get infected)
     */
    public void act(List<Animal> newPrey, String timeOfDay, boolean isDiseaseHappening)
    {
        incrementAge();
        if(!(timeOfDay.equals("night"))) {
            incrementHunger(); // do not increment hunger when the prey is asleep
            if(isAlive()) {
                giveBirth(newPrey);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    setDead();
                }
            }
        }
        // else do nothing, prey is asleep
    }

    /**
     * Check whether or not this prey object is to reproduce at this step.
     * New reproductions will be made into free adjacent locations.
     * @param newPrey A list to return new prey.
     */
    abstract protected void giveBirth(List<Animal> newPrey);

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood();
    
    /**
     * Get the current food level.
     * @return The current food level.
     */
    abstract protected int getFoodLevel();
    
    /**
     * Decrement food level by one.
     */
    abstract protected void decrementFoodLevel();
    
    /**
     * Prey consumes its food level at every step. Check if the current food level is not 0 or below, if so make this prey object dead.
     */
    protected void incrementHunger()
    {
        decrementFoodLevel();
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
}
