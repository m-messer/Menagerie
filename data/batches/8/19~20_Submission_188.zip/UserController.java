import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/**
 * This javaFX userController class allow the user to controll the simulator through
 * a nicer user interface.
 *
 * @version 18/02/2020
 */
public class UserController extends Application
{
    Simulator simulator;
    Stage window;
    Scene scene1, scene2, scene3;

    /**
     * The start method is the main entry point for every JavaFX application. 
     * It is called after the init() method has returned and after 
     * the system is ready for the application to begin running.
     *
     * @param  stage the primary stage for this application.
     */
    @Override
    public void start(Stage primaryStage)
    {
        // Create a Button or any control item
        window = primaryStage;
        
        Label label1 = new Label("Welcome to the underwater Simulator!");
        Button createSimButton = new Button("Create Simulation");
        
        createSimButton.setOnAction(this::createSimButtonClick);
        
        VBox layout1 = new VBox(20);
        layout1.setAlignment(Pos.CENTER);
        layout1.getChildren().addAll(label1, createSimButton);
        scene1 = new Scene(layout1, 300, 200);
        
        Button simOneStepButton = new Button("Simulate One Step");
        simOneStepButton.setOnAction(this::simOneStepButtonClick);
        
        Button runLongSimButton = new Button("Run long simulation");
        runLongSimButton.setOnAction(this::runLongSimButtonClick);
       
        VBox layout2 = new VBox(20);
        layout2.setAlignment(Pos.CENTER);
        layout2.getChildren().addAll(simOneStepButton, runLongSimButton);
        scene2 = new Scene(layout2, 200, 200);
        
        window.setScene(scene1);
        window.setTitle("Underwater Simulation");
        window.show();
    }

    /**
     * This will be executed when the 'create simulation button is clicked
     * It creates the simulation and desplays the next scene
     */
    private void createSimButtonClick(ActionEvent event)
    {
        simulator = new Simulator();
        window.setScene(scene2);
    }
    
    /**
     * This will be executed when the 'simulate one step' button is clicked
     * It simulates one step.
     */
    private void simOneStepButtonClick(ActionEvent event)
    {
        simulator.simulateOneStep();
    }
    
    /**
     * This will be executed when 'run long simulation' button is clicked
     * It simulates until one animal type is left.
     */
    private void runLongSimButtonClick(ActionEvent event)
    {
        simulator.runLongSimulation();
        window.setScene(scene1);
    }
}