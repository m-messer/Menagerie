import java.util.*;
/**
 * Abstract class Predator - Momentarily used for classification of animals
 * when they are eating.
 *
 * @version 2020.02.20 (1)
 */
public abstract class Predator extends Animal
{
    /**
     * New Predator objects are created.
     * 
     * {@inheritDoc Actor class}
     */
    public Predator(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
    }
    
    /**
     *{@inheritDoc Animal class}
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), getFoodDistance());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    if (prey.isDiseased() == true){
                        setDiseased(); 
                    }
                    prey.setDead();
                    eat(prey.getNutriValue());
                    return where;
                }
            }
        }
        return null;
    }
}


