import java.util.*;
import java.util.List;
import java.util.Random;

/**
 * The Shrimp class which contains behaviours of Shrimps.
 * In this simulation the shrimps breed, eat and eventually dies,
 * similar to all other animals. 
 *
 * @version 2020.02.22 (3)
 */
public class Shrimp extends Prey
{
    private static int BREEDING_DISTANCE = 6;
    private static int FOOD_DISTANCE = 1;
    private static final int BREEDING_AGE = 6;
    private static final int MAX_AGE = 15;
    private static double BREEDING_PROBABILITY = 0.8;
    private static int MAX_BIRTH_SIZE = 8;
    private static final int NUTRITION_VALUE = 3;
    private static final int MAX_HUNGER_LEVEL = 5; 

    /**
     * Create a Shrimp. A Shrimp can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @see Actor class for superclass parameters.
     */
    public Shrimp(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
    }
    
    /**The Shrimps maximum birth size decreases when a storm is occuring.
     * 
     * {@inheritDoc Actor class}
     */
    public void act(List<Actor> newShrimps, boolean isDay, boolean highSun, boolean isStorm)
    {  
       MAX_BIRTH_SIZE = 7;

       if (isStorm){
           MAX_BIRTH_SIZE--;
       }
       super.act(newShrimps, isDay, highSun, isStorm);
    }
    
    /**
     * Getter method which returns the Shrimps maximum age.
     * 
     * @return MAX_AGE the Shrimps maximum age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE; 
    }
    
    /**
     * Getter method which returns the Shrimps maximum hunger level.
     * 
     * @return MAX_HUNGER_LEVEL the Shrimps maximum hunger level.
     */
    @Override
    public int getMaxHunger()
    {
        return MAX_HUNGER_LEVEL; 
    }
    
    /**
     * {@inheritDoc Animal class}
     */
    public int getFoodDistance() {
        return FOOD_DISTANCE;
    }
    
    /**
     * {@inheritDoc Actor class}
     * 
     * @param newShrimps A list to return newly born Shrimps.
     */
    public void giveBirth(List<Actor> newShrimps)
    {
        // New Shrimps are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), BREEDING_DISTANCE);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shrimp) {
                Shrimp shrimp = (Shrimp) animal;
                if(shrimp.getIsFemale() != this.getIsFemale()) { 
                    List<Location> free = field.getFreeAdjacentLocations(getLocation(), 2);
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        // use OR operator, if any one parent is diseased
                        Shrimp young = new Shrimp(false, field, loc, isDiseased()|shrimp.isDiseased());
                        newShrimps.add(young);
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= BREEDING_PROBABILITY) {
            births = getRandom().nextInt(MAX_BIRTH_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Shrimp can breed if it has reached the breeding age.
     * @return true if the Shrimp can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Getter method returns the nutrition value of the Shrimp
     * 
     * @return NUTRITION_VALUE Shrimps nutrition value.
     */
    public int getNutriValue()
    {
        return NUTRITION_VALUE;
    }
}
