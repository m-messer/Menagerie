import java.util.*;
/**
 * A class representing shared characteristics of animals
 * which does not include the Plankton.
 * 
 * 
 * @version 2020.02.21 (4)
 */
public abstract class Animal extends Actor
{
    private int hungerLevel;
    private final boolean isFemale;
    private int diseasedCounter = 0;
    
    /**
     * Create a new animal at location in field
     * and set a random gender and hunger level up to 10.
     * 
     * @see Actor class for superclass parameters.
     */
    public Animal(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
        isFemale = getRandom().nextBoolean();
        hungerLevel = getRandom().nextInt(10);
    }

    /**
     * This act method is shared amongst all animals as they all perform
     * the same actions including aging, getting hungry etc. If they are
     * hungry enough they will look for food, eat and set themselves a new
     * location (their foods location) or if they don't eat, a free location.
     * 
     * {@inheriDoc Actor class}
     */
    @Override
    protected void act(List<Actor> newAnimals, boolean isDay, boolean highSun, boolean isStorm)
    {
        incrementAge();
        incrementHunger(getMaxHunger());
        if (isDiseased()) { incrementDiseaseCounter(); }
        
         if (isAlive()) {
            if (isDay) 
                giveBirth(newAnimals);     
                // Move towards a source of food if found.
                Location newLocation = null; 
                // eat when the hunger level is greater than a third of the max hunger level.           
                if (hungerLevel >= getMaxHunger() / 3) newLocation = findFood();
                
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), 1);
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }

        }
    }
    
    /**
     * This method is called each step and increments the animals hunger
     * levels and checks if they are too hungry. This compares their hunger
     * level to their maximum hunger level value, if it's equal to or over
     * the animals die.
     * 
     * @param maxHunger the threshold hunger level for the animal to die.
     */
    protected void incrementHunger(int maxHunger)
    {
        hungerLevel++;
        if(hungerLevel >= maxHunger) {
            setDead();
        }
    }

    /**
     * This is called upon an animal being diseased and keeps track of 
     * the number of steps the animal can survive with the disease before dying.
     */
    private void incrementDiseaseCounter()
    {
        diseasedCounter++;
        if (diseasedCounter >= 17) {
            setDead();
        }
    }
    
    /**
     * A getter method which returns the value of the hunger level
     * of the animal.
     * 
     * @return hungerLevel the animals current hunger level.
     */
    protected int getHungerLevel(){
        return hungerLevel; 
    }
    
    /**
     * This is an abstract method which is individually overriden for prey and predators 
     * since they all have their specific subgroup to eat.
     * 
     * Look for Animals of the same type adjacent to the current location.
     * Only the first live is eaten. If the animal being eaten is diseased,
     * the predator will also 'catch' the disease.
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood(); 
      
    /**
     * This method is called for each animal and decreases an animals hunger 
     * level by the amount of the nutrition value of the animal being eaten.
     */
    protected void eat(int nutritionValue)
    {
        hungerLevel -= nutritionValue;
    }
    
    /**
     * Getter method which returns if the animal is a female or not.
     * 
     * @return isFemale true or false if it's female or not.
     */
    protected boolean getIsFemale()
    {
        return isFemale;
    }
    
    /**
     * Overriden in the animals individually. 
     * @return the distance at which animal can spot its food source. 
     */
    abstract protected int getFoodDistance();
    
    /**
     * Overriden in the animals individually.
     */
    abstract protected int getNutriValue();
    
    /**
     * Overriden in the animals individually.
     */
    abstract protected int getMaxHunger();
}
