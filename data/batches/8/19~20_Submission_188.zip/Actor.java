import java.util.*;
/**
 * Actor is an abstract superclass which represents shared
 * characteristics and methods across all existing objects in the
 * simulation, which includes the animals and the Plankton
 * and any future existing objects in future development.
 *
 * @version 2020.02.22 (3)
 */
public abstract class Actor
{
    private static final Random rand = Randomizer.getRandom();
    private boolean diseased = false;
    private boolean alive;
    private Field field; 
    private Location location; 
    private static final double INHERIT_DISEASE_PROBABILITY = 0.07;
    private static final double DISEASE_PROBABILITY = 0.03;
    private int age;
    
    /**
     * Constructor method to set actors (objects on the field) alive,
     * their field and location on the field, determine if they are 
     * diseased and set their age randomly or not (depending if they are new borns).
     * 
     * @param randomAge whether or not it's a new born or intial animal
     * (with a random age).
     * @param parentsDiseased If any of the two animals parents are diseased.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Actor (boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
        }
        determineIfDiseased(parentsDiseased);
    }
    
    /**
     * Animals are set to dead by removing them from the field and clearing 
     * their location value.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    } 
    
    /**
     * Defined in Animal and Plankton classes and overriden individually 
     * by the Animal subclasses.
     * 
     * @param newActors a list which will contain all new borns to be added.
     * @param isDay true if the time of day is day and false if it's night.
     * @param highSun true if there's high levels of sunlight.
     * @param isStorm true if there is currently a storm occuring.
     */
    abstract protected void act(List<Actor> newActors, boolean isDay, boolean highSun, boolean isStorm);

    /**
     * Overriden in individual Actor subclasses.
     */
    abstract protected int getMaxAge(); 
    
    /** 
     * Place the animal at the new location in the given field.
     * 
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Increase the age. This could result in the Actor's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Getter method which returns if the actor is diseased or not.
     */
    protected boolean isDiseased(){
        return diseased; 
    }
    
    /**
     * Setter method which sets the actor to diseased if the probability
     * matches.
     */
    protected void setDiseased(){
        diseased = true;
    }
    
    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * A getter method to check if the actor is alive.
     * @return alive to reveal if it's true or false.
     */
    protected boolean isAlive() 
    {
        return alive;
    }
    
    /**
     * If the parents are diseased the higher probability is used to
     * determine if the new born will be diseased, otherwise the normal 
     * probability will be used which is significantly lower.
     * 
     * @param parentsDiseased true or false if the parents are diseased or not.
     */
    protected void determineIfDiseased(boolean parentsDiseased)
    {
        if (!parentsDiseased && rand.nextDouble() <= DISEASE_PROBABILITY)
        {
            diseased = true;
        }
        else if (parentsDiseased && rand.nextDouble() <= INHERIT_DISEASE_PROBABILITY)
        {
            diseased = true;
        }
    }
    
    /**
     * Getter method returns the row of the actor's current location.
     * 
     * @return location.getRow() the actor's row.
     */
    protected int getLocationRow()
    {
        return location.getRow();
    }
    
    /**
     * Gtter method returns the column of the actor's current location.
     * 
     * @return location.getCol() the actor's column.
     */
    protected int getLocationCol()
    {
        return location.getCol();
    }
    
    /**
     * Getter method to return the actor's age.
     * 
     * @return age the actor's age.
     */
    protected int getAge(){
        return age; 
    }
    
    /**
     * Getter method to return the random object created with a seed in the
     * randomizer.
     * 
     * @return rand the object used as a randomizer.
     */
    protected Random getRandom(){
        return rand; 
    }
    
    /**
     * This method is overriden by the animals themselves, since they
     * can only mate with their own kind.
     * 
     * Check whether or not this 'Actor' is to give birth at this step.
     * New births will be made into free adjacent locations. If either or 
     * the two mating Actor's have the disease the probability of the new
     * born inheriting the disease is greater.
     * @param newActor A list to return newly born Actors.
     */
    abstract void giveBirth(List<Actor> newActor);
}
