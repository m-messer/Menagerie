import java.util.*;
/**
 * Abstract class Prey - Momentarily used for classification of animals
 * when they are eating.
 *
 * @version 2020.02.20 (1)
 */
public abstract class Prey extends Animal
{
    /**
     * New Prey objects are created.
     * 
     * {@inheritDoc Actor class}
     */
    public Prey(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
    }
    
    /**
     * {@inheritDoc Animal class}
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), getFoodDistance());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plankton) {
                Plankton plankton = (Plankton) animal;
                if(plankton.isAlive()) { 
                    if (plankton.isDiseased() == true){ 
                        setDiseased(); 
                    }
                    plankton.setDead();
                    eat(plankton.getNutriValue());
                    return where;
                }
            }
        }
        return null;
    }
}

