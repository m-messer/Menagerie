import java.util.*;
import java.awt.Color;

/**
 * A simple predator-prey underwater simulator, based on a rectangular field
 * containing plankton as vegetation, shrimp and mackerel as prey, seal, tuna
 * and shark as predators. The simulator simulates a certain area of the sea,
 * which can be wandered into by other underwater creatures during the migration. 
 * Natural disasters may occur, as well as weather and daytime changes.
 * 
 * @version 2020.02.14 (3)
 */
public class Simulator
{
    private static final Random rand = Randomizer.getRandom();

    private static final int DEFAULT_WIDTH = 130;
    private static final int DEFAULT_DEPTH = 80;

    private static final double SHARK_CREATION_PROBABILITY = 0.07;
    private static final double SEAL_CREATION_PROBABILITY = 0.065; //
    private static final double TUNA_CREATION_PROBABILITY = 0.0781; 
    private static final double SHRIMP_CREATION_PROBABILITY = 0.0812; //
    private static final double MACKEREL_CREATION_PROBABILITY = 0.075;
    private static final double PLANKTON_CREATION_PROBABILITY = 0.068;

    private Setting setting = new Setting();
    private List<Actor> actors;
    private Field field;
    private int step;
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setWaterColour(setting.isDay());
        view.setColor(Shrimp.class, new Color(229, 131, 249));//purple light
        view.setColor(Seal.class, Color.WHITE);
        view.setColor(Shark.class, Color.BLACK);
        view.setColor(Tuna.class, new Color(212, 15, 81));//darker pink
        view.setColor(Plankton.class, new Color(73, 215, 96));//green
        view.setColor(Mackerel.class, new Color(255, 239, 87));//yellow

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep()
    {   
        step++;
        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>();
        setWeatherConditions();
        naturalDisaster();
        migration();

        boolean day = false;
        boolean storm = false;
        boolean highSunlight = false;
        // Let all 'actors' act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) 
        {
            Actor actor = it.next();

            if (setting.isStorm()){
                storm = true;
            }
            if (setting.isDay()){ 
                view.setWaterColour(true);
                day = true;
                if (setting.isHighSunlight()) {
                    highSunlight = true;
                } 
            }
            else 
            {
                view.setWaterColour(false);
            }

            actor.act(newActors, storm, day, highSunlight);
            if(! actor.isAlive()) {
                it.remove();
            } 
        }
        // Add the newly born actors to the main list containing all existing actors.
        actors.addAll(newActors);
        view.showStatus(step, field);
    }

    /**
     * Change the day to night or vice versa every 5 steps.
     */
    private void determineDayTime() 
    {
        if (step%5 == 0) setting.changeDay();
    }

    /**
     * Storms occur every every night or every day then also depend on probability.
     */    
    private void determineStorm()
    {
        if (step%5 == 0) {
            setting.setStorm();
        }
    }

    /**
     * A whirlpool can only occur every 12 steps and with that has a low 
     * probability of occuring on those steps also.
     */
    private void determineWhirlpool()
    {
        if (step%12 == 0) {
            setting.setWhirlpool();
        }
    }

    /**
     * Set the value of the sunlight levels.
     */
    private void determineSunLight()
    {
        setting.setHighSunlight();
    }

    /**
     * Call the methods which implement the affects of the disasters.
     */
    private void naturalDisaster(){
        if(setting.isStorm()) storm(); 
        if(setting.isWhirlpool()) whirlpool(); 
    }

    /**
     * Set the weather condition values of the setting class.
     */
    private void setWeatherConditions()
    {
        determineWhirlpool();
        determineDayTime();
        determineSunLight();
        determineStorm();
    }

    /**
     * Migration occurs every 20 steps. During this time, there is an influx of more actors
     * on the simulation field.
     */
    private void migration(){
        if(step%10 == 0) populate(); 
    }

    /**
     * The whirlpool occurs based on a low probability and kills the actors
     * located within the circle of a random radius at a random location on the field.
     */
    private void whirlpool()
    {
        int whirlpoolX = rand.nextInt(DEFAULT_WIDTH); // make these -40 from edges to fix error
        int whirlpoolY = rand.nextInt(DEFAULT_DEPTH);
        int radius = rand.nextInt(40);
        //random location on field
        Location whirlpoolLocation = new Location(whirlpoolX, whirlpoolY);
        List<Location> adjacent = field.adjacentLocations(whirlpoolLocation, radius);

        adjacent.add(whirlpoolLocation);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);

            if(animal instanceof Actor) {
                Actor actor = (Actor) animal;
                if (insideCircle(whirlpoolX, whirlpoolY, actor.getLocationRow(), actor.getLocationCol(), radius)) {
                    actor.setDead();
                    actors.remove(actor);
                }
            }
        }
        setting.endWhirlpool();
    }

    /**
     * Storm occurs based on a probability and kills a twelfth of the 
     * actors on the field. This is done randomly by first shuffling the list.
     */
    private void storm()
    {
        int fractionOfPopulation = actors.size() / 12;
        int count = 0;

        Collections.shuffle(actors);
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = (Actor) it.next();
            actor.setDead();
            it.remove();
            if (count == fractionOfPopulation) break;
            count++;
        }

    }
    

    /**
     * This method checks if the coordinates of the point on the field passed lie
     * within the circle of a specified radius which is randomly selected.
     * 
     * @param circle_x the x coordinate of the circle
     * @param circle_y the y coordinate of the circle
     * @param x the x coordinate of the actor's location
     * @param the y coordinate of the actor's location
     * @param radius the radius of the whirlpool (circle area)
     * 
     * @return true or false depending on if it lies within the 'whirlpool' or not
     */
    private static boolean insideCircle(int circle_x, int circle_y, int x, int y, int radius) 
    { 
        // Compare radius of circle with 
        // distance of its center from 
        // given point 
        if ((x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= radius * radius) 
            return true; 
        else
            return false; 
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with Sharks, Seals, Tuna, Mackerel,
     * Shrimp and Plankton.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Actor actor = null;
                if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    actor = new Shark(true, field, new Location(row, col), false);
                }
                else if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    actor = new Seal(true, field, new Location(row, col), false);
                }
                else if(rand.nextDouble() <= TUNA_CREATION_PROBABILITY) {
                    actor = new Tuna(true, field, new Location(row, col), false);
                }
                else if(rand.nextDouble() <= SHRIMP_CREATION_PROBABILITY) {
                    actor = new Shrimp(true, field, new Location(row, col), false);
                }
                else if(rand.nextDouble() <= PLANKTON_CREATION_PROBABILITY) {
                    actor = new Plankton(true, field, new Location(row, col), false);
                }
                else if(rand.nextDouble() <= MACKEREL_CREATION_PROBABILITY) {
                    actor = new Mackerel(true, field, new Location(row, col), false);
                }

                if (actor != null) actors.add(actor);
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
