import java.util.*;
/**
 * The Plankton class which contains behaviours of Plankton.
 * In this simulation the plankton only breeds and eventually dies,
 * similar to plants.
 *
 * @version 2020.02.22 (3)
 */
public class Plankton extends Actor
{
    private static final int MAX_AGE = 100;
    private static final int NUTRITION_VALUE = 20;
    private static double REPRODUCTIVE_PROBABILITY = 0.8;

    /**
     * Create new Plankton objects and set their intial values.
     * @see Actor class for superclass parameters.
     */
    public Plankton(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
    }

    /**
     * This is what the Plankton does. Sometimes it will breed or 
     * die of old age / being eaten. The Plankton's reproductiveness is also
     * affected differently depending on the levels of sunlight. At night
     * they do not reproduce, since there is no "sunlight".
     * 
     * {@inheritDoc Actor class}
     */ 
    @Override
    public void act(List<Actor> newPlanktons, boolean isDay, boolean highSun, boolean isStorm)
    {
        incrementAge();
        REPRODUCTIVE_PROBABILITY = 0.8;

        if (!isDay) {
            REPRODUCTIVE_PROBABILITY = 0;
        }
        else {
            if (highSun) {
                REPRODUCTIVE_PROBABILITY = 1;
            }
        }

        if(isAlive()) {
            giveBirth(newPlanktons);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation(), 1);
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Getter method which returns the Planktons maximum age.
     * 
     * @return MAX_AGE the planktons maximum age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE; 
    }
    
    /**
     * Plankton's will give birth to 3 Planktons given a certain probability.
     * 
     * @param newPlanktons will contain these new born Plankton objects.
     */
    @Override
    public void giveBirth(List<Actor> newPlanktons)
    {
        Field field = getField();
        if (getRandom().nextDouble() <= REPRODUCTIVE_PROBABILITY) {
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), 1);
            for (int b = 0; b <=3 && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Plankton young = new Plankton(false, field, loc, isDiseased());
                newPlanktons.add(young);
            }
        }
    }
    
    /**
     * Getter method which returns the Planktons nutrition value.
     * 
     * @return NUTRITION_VALUE the Plankton's nutrition value.
     */
    public int getNutriValue()
    {
        return NUTRITION_VALUE;
    }
}
