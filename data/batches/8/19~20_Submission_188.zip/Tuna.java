import java.util.*;
/**
 * The Tuna class which contains behaviours of Tunas.
 * In this simulation the Tunas breed, eat and eventually dies,
 * similar to all other animals. 
 *
 * @version 2020.02.22 (3)
 */
public class Tuna extends Predator
{
    private static int BREEDING_DISTANCE = 4;
    private static int FOOD_DISTANCE = 2;
    private static final int BREEDING_AGE = 15;
    private static final int MAX_AGE = 50;
    private static double BREEDING_PROBABILITY = 0.4;
    private static int MAX_BIRTH_SIZE = 5;
    private static final int NUTRITION_VALUE = 10;
    private static final int MAX_HUNGER_LEVEL = 11; 

    /**
     * Create a Tuna. A Tuna can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @see Actor class for superclass parameters.
     */
    public Tuna(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
    }
    
    /**
     * Getter method which returns the Tunas maximum age.
     * 
     * @return MAX_AGE theTunas maximum age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE; 
    }
    
    /**
     * Getter method which returns the Tunas maximum hunger level.
     * 
     * @return MAX_HUNGER_LEVEL the Tunas maximum hunger level.
     */
    @Override
    public int getMaxHunger()
    {
        return MAX_HUNGER_LEVEL; 
    }
    
    /**
     * {@inheritDoc Animal class}
     */
    public int getFoodDistance() {
        return FOOD_DISTANCE;
    }
    
    /**
     * {@inheritDoc Actor class}
     * @param newTunas A list to return newly born Tunaes.
     */
    public void giveBirth(List<Actor> newTunas)
    {
        // New Tunas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), BREEDING_DISTANCE);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Tuna) {
                Tuna tuna = (Tuna) animal;
                if(tuna.getIsFemale() != this.getIsFemale()) { 
                    List<Location> free = field.getFreeAdjacentLocations(getLocation(), 1);
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Tuna young = new Tuna(false, field, loc, isDiseased()|tuna.isDiseased());
                        newTunas.add(young);
                    }
                }
            }
        }
    }
    
    /**The Tuna birth size and food distance decrease when a storm is occuring.
     * 
     * {@inheritDoc Actor class}
     */
    public void act(List<Actor> newTunas, boolean isDay, boolean highSun, boolean isStorm)
    {   MAX_BIRTH_SIZE = 5;
        FOOD_DISTANCE = 3;
        if (isStorm){
            MAX_BIRTH_SIZE = 3;
            FOOD_DISTANCE = 2;
        }
        super.act(newTunas, isDay, highSun, isStorm);
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= BREEDING_PROBABILITY) {
            births = getRandom().nextInt(MAX_BIRTH_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A Tuna can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Getter method returns the nutrition value of the Tuna
     * 
     * @return NUTRITION_VALUE Tunas nutrition value.
     */
    public int getNutriValue()
    {
        return NUTRITION_VALUE;
    }
}
