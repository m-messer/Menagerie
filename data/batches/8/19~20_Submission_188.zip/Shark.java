import java.util.*;
/**
 * The Shark class which contains behaviours of Sharks.
 * In this simulation the sharks breed, eat and eventually dies,
 * similar to all other animals. 
 *
 * @version 2020.02.22 (3)
 */
public class Shark extends Predator
{
    private static int BREEDING_DISTANCE = 2;
    private static int FOOD_DISTANCE = 4; // can change if a storm occurs
    private static final int BREEDING_AGE = 20;
    private static final int MAX_AGE = 100;
    private static double BREEDING_PROBABILITY = 0.3; // changes at night
    private static int MAX_BIRTH_SIZE = 3;
    private static final int NUTRITION_VALUE = 20;
    private static final int MAX_HUNGER_LEVEL = 20; 

    /**
     * Create a Shark. A Shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @see Actor class for superclass parameters.
     */
    public Shark(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
    }
    
    /**
     * The Sharks breeding and food distance decrease when a storm is occuring
     * and their breeding probability increases during the night.
     * 
     * {@inheritDoc Actor class}
     */
    public void act(List<Actor> newSharks, boolean isDay, boolean highSun, boolean isStorm)
    {  
       BREEDING_DISTANCE = 2;
       FOOD_DISTANCE = 5; 
       BREEDING_PROBABILITY = 0.3; 

       if (isStorm){
           BREEDING_DISTANCE--;
           FOOD_DISTANCE --;
        }
       if (!isDay){
           BREEDING_PROBABILITY += 0.2;
       }
       
       super.act(newSharks, isDay, highSun, isStorm);
    }
        
    /**
     * Getter method which returns the Sharks maximum age.
     * 
     * @return MAX_AGE the Sharks maximum age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE; 
    }
    
    /**
     * Getter method which returns the Sharks maximum hunger level.
     * 
     * @return MAX_HUNGER_LEVEL the Sharks maximum hunger level.
     */
    @Override
    public int getMaxHunger()
    {
        return MAX_HUNGER_LEVEL; 
    }

    /**
     * {@inheritDoc Animal class}
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), FOOD_DISTANCE);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Predator && !(animal instanceof Shark)) {
                Predator predator = (Predator) animal;
                if(predator.isAlive()) { 
                    if (predator.isDiseased() == true){ 
                        setDiseased(); 
                    }
                    predator.setDead();
                    eat(predator.getNutriValue());
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * {@inheritDoc Animal class}
     */
    public int getFoodDistance() {
        return FOOD_DISTANCE;
    }
    
    /**
     * {@inheritDoc Actor class}
     * 
     * @param newSharks A list to return newly born Sharks.
     */
    public void giveBirth(List<Actor> newSharks)
    {
        // New Sharkes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), BREEDING_DISTANCE);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shark) {
                Shark shark = (Shark) animal;
                if(shark.getIsFemale() != getIsFemale()) { 
                    List<Location> free = field.getFreeAdjacentLocations(getLocation(), 2);
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Shark young = new Shark(false, field, loc, isDiseased()|shark.isDiseased());
                        newSharks.add(young);
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= BREEDING_PROBABILITY) {
            births = getRandom().nextInt(MAX_BIRTH_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A Shark can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }

    /**
     * Getter method returns the nutrition value of the Shark
     * 
     * @return NUTRITION_VALUE Sharks nutrition value.
     */
    public int getNutriValue()
    {
        return NUTRITION_VALUE;
    }
}

