import java.util.List;
import java.util.Iterator;

/**
 * The Seal class which contains behaviours of Seals.
 * In this simulation the seals breed, eat and eventually dies,
 * similar to all other animals. 
 *
 * @version 2020.02.22 (3)
 */
public class Seal extends Predator
{
    private static int BREEDING_DISTANCE = 2;
    private static int FOOD_DISTANCE = 3;
    private static final int BREEDING_AGE = 16;
    private static final int MAX_AGE = 20;
    private static double BREEDING_PROBABILITY = 0.6;
    private static int MAX_BIRTH_SIZE = 4;
    private static final int NUTRITION_VALUE = 12;
    private static final int MAX_HUNGER_LEVEL = 12;

    /**
     * Create a Seal. A Seal can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @see Actor class for superclass parameters.
     */
    public Seal(boolean randomAge, Field field, Location location, boolean parentsDiseased)
    {
        super(randomAge, field, location, parentsDiseased);
    }
    
    /**
     * The Seals breeding probability and food distance increase during
     * the day. Thei rfodd distance de creases during a storm.
     * 
     * {@inheritDoc Actor class}
     */
    public void act(List<Actor> newSeals, boolean isDay, boolean highSun, boolean isStorm)
    {  
       FOOD_DISTANCE = 2;
       BREEDING_PROBABILITY = 0.2;
       
       if (isDay){
           FOOD_DISTANCE++;
           BREEDING_PROBABILITY += 0.1;
           if (isStorm) {
               FOOD_DISTANCE--;
           }
           super.act(newSeals, isDay, highSun, isStorm);
       }
       else {
           incrementAge();
       }
    }
    
    /**
     * Getter method which returns the Seals maximum age.
     * 
     * @return MAX_AGE the Seals maximum age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE; 
    }
    
    /**
     * Getter method which returns the Seals maximum hunger level.
     * 
     * @return MAX_HUNGER_LEVEL the Seals maximum hunger level.
     */
    @Override
    public int getMaxHunger()
    {
        return MAX_HUNGER_LEVEL; 
    }
        
    /**
     * {@inheritDoc Animal class}
     */
    public int getFoodDistance() {
        return FOOD_DISTANCE;
    }
    
    /**
     * {@inheritDoc Animal class}
     * @param newSeals A list to return newly born Seals.
     */
    public void giveBirth(List<Actor> newSeals)
    {
        // New Seales are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), BREEDING_DISTANCE);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Seal) {
                Seal seal = (Seal) animal;
                if(seal.getIsFemale() != this.getIsFemale()) { 
                    List<Location> free = field.getFreeAdjacentLocations(getLocation(), 2);
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Seal young = new Seal(false, field, loc, isDiseased()|seal.isDiseased());
                        newSeals.add(young);
                    }
                }
            }
        }
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= BREEDING_PROBABILITY) {
            births = getRandom().nextInt(MAX_BIRTH_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A Seal can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Getter method returns the nutrition value of the Seals
     * 
     * @return NUTRITION_VALUE Seals nutrition value.
     */
    public int getNutriValue()
    {
        return NUTRITION_VALUE;
    }
}
