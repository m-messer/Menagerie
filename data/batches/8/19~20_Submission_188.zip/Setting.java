import java.util.*;
/**
 * The Setting class contains characteristics of the weather and the state of 
 * any natural disasters that may be occuring for example a whirlpool.
 *
 * @version 2020.02.18 (2)
 */
public class Setting
{
    private static final Random rand = Randomizer.getRandom();
    private static boolean highSunlight;
    private static boolean isDay;
    private static boolean isStorm;
    private static boolean isWhirlpool;
    
    private static final double STORM_PROBABILITY = 0.04;
    private static final double WHIRLPOOL_PROBABILITY = 0.02;
    
    /**
     * Constructor for objects of class Setting which randomly
     * initialises the weather conditions randomly and the whirlpool to false.
     * 
     */
    public Setting()
    {
        highSunlight = rand.nextBoolean();
        isDay = rand.nextBoolean();
        isStorm = rand.nextBoolean();
        isWhirlpool = false; 
    }
    
    /**
     * Getter method returns if it's day or not.
     * 
     * @return isDay true if it's day.
     */
    public static boolean isDay()
    {
        return isDay;
    }
    
    /**
     * Method which inverts the value of isDay when called upon.
     */
    public void changeDay()
    {
        isDay = !isDay;
    }

    /**
     * Stops the storm by setting isStorm to false.
     */
    public void stopStorm()
    {
        isStorm = false;
    }
    
    /**
     * Setter method which depending on probability sets the storm to true
     * otherwise by default is left at false.
     */
    public void setStorm()
    {
        if (rand.nextDouble() <= STORM_PROBABILITY) {
            isStorm = true;
        }
    }
    
    /**
     * returns if there is a storm or not.
     * 
     * @return isStorm
     */
    public boolean isStorm()
    {
       return isStorm;
    }
    
    /**
     * Setter method which sets the levels of sunlight randomly if it's daytime
     * because if it's night time, there is no "sunlight" therefore sets to false.
     */
    public void setHighSunlight()
    {
       if (isDay) highSunlight = rand.nextBoolean();
       else highSunlight = false;
    }

    /**
     * Set the whirlpool to true based on a probability.
     */
    public void setWhirlpool(){
        if (rand.nextDouble() <= WHIRLPOOL_PROBABILITY){
            isWhirlpool = true; 
        }
    }
    
    /**
     * set the whirlpool state to false.
     */
    public void endWhirlpool()
    {
        isWhirlpool = false;
    }
    
    /**
     * Returns if the whirlpool is occuring or not.
     * 
     * @return isWhirlpool true if there is a whirlpool.
     */
    public boolean isWhirlpool(){
        return isWhirlpool; 
    }
    
    /**
     * @return true if theres a high sunlight level
     */
    public boolean isHighSunlight()
    {
        return highSunlight;
    }
}
