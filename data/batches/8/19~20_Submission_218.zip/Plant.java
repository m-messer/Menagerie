import java.util.Random;
/**
 * A class representing shared characteristics of plants.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Plant
{
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // Plants are worth a certain resource value for  some animals to eat.
    private int worth;
    // A shared random number generator to control growing of plants.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * 
     */
    public Plant(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Set the plant's worth level.
     * @param resources
     */
    protected void setWorth(int worth)
    {
        this.worth = worth;
    }
    
    /**
     * Get the plant's worth level.
     * @param resources
     */
    protected int getWorth()
    {
        return this.worth;
    }
    
    /**
     * During rain, plants regenerate.
     */
    public void regenerate()
    {
        this.worth = getMaxWorth();
    }
    
     /**
     * During sunny days, plants grow slowly.
     */
    public void incrementWorth()
    {
        this.worth++;
    }
    
    /**
     * Animals can eat plants.
     * A single point from a plants' worth value is enough to fully feed the animal.
     */
    public void feedAnimal()
    {
        this.worth -= 3;
    }
    
    /**
     * @return max value of resources to be provided from a single plant to an animal that eats it.
     */
    abstract protected int getMaxWorth();
    
    /**
     * @return the plant species number.
     */
    abstract protected int getSpeciesNo();
    
}
