import java.util.List;
/**
 * A simple model of a deer.
 * Deer age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Deer extends Animal
{
    // Characteristics shared by all deer (class variables).

    // The deer's species number.
    private static final int speciesNo = 3;
    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a deer can live.
    private static final int MAX_AGE = 28;
    // Deer cannot eat more than this. 
    private static final int MAX_FOOD_CAPACITY = 20;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.57;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // number of steps a deer can go before it has to eat again.
    private static final int COMMONPLANT_FOOD_VALUE = 15;
    // The deer is not active at night.
    private boolean actsAtNight = false;
    // The probability of a deer moving during rain.
    private static final double RAIN_MOVEMENT_PROBABILITY = 0.82;
    
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        if(randomAge) {
            age = rand.nextInt(getMAXAGE());
            this.foodLevel = rand.nextInt(MAX_FOOD_CAPACITY);
        }
        else {
            age = 0;
            this.foodLevel = MAX_FOOD_CAPACITY;
        }
        foodValue.put(100, COMMONPLANT_FOOD_VALUE);
    }
    
    /**
    * Checks if the deer acts during night.
    */
    public boolean actsAtNight()
    {
        return actsAtNight;
    }
    
    /**
     * @return the deer's breeding age.
     */
    protected int getBREEDINGAGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age of a deer.
     */
    protected int getMAXAGE()
    {
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of a deer.
     */
    protected double getBREEDINGPROBABILITY()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return the maximum litter size of a deer.
     */
    protected int getMAXLITTERSIZE()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the deer's maximum eating capacity.
     */
    protected int getMaxFoodCapacity()
    {
        return MAX_FOOD_CAPACITY;
    }
    
    /**
     * @return deer's species number.
     */
    protected int getSpeciesNo()
    {
        return speciesNo;
    }
    
    /**
     * @return 0 probability, because deer sleep during the night.
     */
    protected double getNightHuntingProbability()
    {
        return (double) 0;
    }
    
    /**
     * @return the probability of a deer to move during rain.
     */
    protected double getRAINMOVEMENTPROBABILITY()
    {
        return RAIN_MOVEMENT_PROBABILITY;
    }
}
