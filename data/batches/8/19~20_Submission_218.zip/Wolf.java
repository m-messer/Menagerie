import java.util.List;
/**
 * A simple model of a wolf.
 * Wolves age, move, eat marmots, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).

    // The wolf's species number.
    private static final int speciesNo = 2;
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 36; 
    // Marmot's cannot eat more than this. 
    private static final int MAX_FOOD_CAPACITY = 28;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.35;//0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of an animal. In effect, this is the
    // number of steps a wolf can go after eating that animal.
    private static final int LYNX_FOOD_VALUE = 20;
    private static final int DEER_FOOD_VALUE = 28;
    private static final int PRIMITIVE_FOOD_VALUE = 28;
    // The probability of a wolf moving during rain.
    private static final double RAIN_MOVEMENT_PROBABILITY = 0.40;
    // wolves can hunt during the night
    private static final double NIGHT_HUNTING_PROBABILITY = 0.25;
    // The wolf can be active during nighttime.
    private boolean actsAtNight = true;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        foodValue.put(1, LYNX_FOOD_VALUE);
        foodValue.put(3, DEER_FOOD_VALUE);
        foodValue.put(4, PRIMITIVE_FOOD_VALUE);
        if(randomAge) 
        {
            age = rand.nextInt(getMAXAGE());
            this.foodLevel = rand.nextInt(PRIMITIVE_FOOD_VALUE);
        }

        else 
        {
            age = 0;
            this.foodLevel = PRIMITIVE_FOOD_VALUE;
        }
    }
    
    /**
    * Checks if the wolf can be active during night.
    */
    public boolean actsAtNight()
    {
        return actsAtNight;
    }
    
    /**
     * @return the wolf's breeding age.
     */
    protected int getBREEDINGAGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age of a wolf.
     */
    protected int getMAXAGE()
    {
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of a wolf.
     */
    protected double getBREEDINGPROBABILITY()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return the maximum litter size of a wolf.
     */
    protected int getMAXLITTERSIZE()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the wolf's maximum eating capacity.
     */
    protected int getMaxFoodCapacity()
    {
        return MAX_FOOD_CAPACITY;
    }
    
    /**
     * @return wolf's species number.
     */
    protected int getSpeciesNo()
    {
        return speciesNo;
    }
    
    /**
     * @return the probability of a wolf hunting at night.
     */
    protected double getNightHuntingProbability()
    {
        return NIGHT_HUNTING_PROBABILITY;
    }
    
    /**
     * @return the probability of a wolf to move during rain.
     */
    protected double getRAINMOVEMENTPROBABILITY()
    {
        return RAIN_MOVEMENT_PROBABILITY;
    }
}
