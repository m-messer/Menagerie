import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of predators.
 *
 * @version 2020.03.03
 */
public abstract class Predator extends Animal
{
    protected Class[] diet = new Class[0];
    
    public Predator(Field field, Location location) {
        super(field, location);
    }
    
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            for(int i=0; i < diet.length; ++i) {
                if(diet[i].isInstance(animal)) {
                    Animal prey = (Animal) animal;
                    if(prey.isAlive()) {    
                        prey.setDead();
                        foodLevel += prey.getFoodValue();
                        if(foodLevel > 20) {
                            foodLevel = 20;
                        }
                        return where;
                    }
                }
            }
        }
        return null;
    }
}
