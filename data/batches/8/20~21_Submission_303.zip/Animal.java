import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.03.03
 */
public abstract class Animal
{    
    // The age at which an animal can start to breed.
    protected int BREEDING_AGE;
    // The age to which an animal can live.
    protected int MAX_AGE;
    // The likelihood of an animal breeding.
    protected double BREEDING_PROBABILITY;
    // The maximum number of births.
    protected int MAX_LITTER_SIZE;
    // The food value of this animal. In effect, this is the
    // number of steps an animal can go before it has to eat again.
    protected int FOOD_VALUE_GIVEN;
    // Determines if the animal is active during the day
    protected boolean DIURNAL = true;
    private double DISEASE_SPREAD_CHANCE = 0.01;
    private double BECOME_DISEASED_CHANCE = 0.005;
    
    protected boolean isDiseased = false; 
    
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
     
    // The animal's age.
    protected int age;
    // The animal's gender
    private int gender;
    // The animal's food level, which is increased by eating food.
    protected int foodLevel;       
    
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    
    private static final Class[] params = new Class[] {boolean.class, Field.class, Location.class};
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        gender = rand.nextInt(2);
        setLocation(location);        
    }        
    
    abstract protected Animal getYoungAnimal(boolean randomAge, Field field, Location location);
    
    abstract protected Location findFood();
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newAnimals, boolean isDay) {
        incrementAge();                
        
        if(isAlive() && !isDiseased) {
            if(rand.nextDouble() <= BECOME_DISEASED_CHANCE) {
                becomeDiseased();              
            }
        }                     
        
        if(isAlive()) {
            if(isDiseased) 
            {
                spreadDisease();
            }
            if(DIURNAL && isDay || !DIURNAL && !isDay) {
                incrementHunger();                
                if(isAlive()) {                           
                    if (gender == 1) {
                        giveBirth(newAnimals);
                    }
                    // Move towards a source of food if found.
                    Location newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
            else {              
                if(isAlive()) {                           
                    Location newLocation = getField().freeAdjacentLocation(getLocation());
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }
    
    private void giveBirth(List<Animal> newAnimals) {
        Field field = getField();                
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(getClass().isInstance(animal)) {
                Animal partner = (Animal) animal;
                if(partner.getGender() == 0 && partner.isAlive()) {
                    // New animals are born into adjacent locations.
                    // Get a list of adjacent free locations.
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Animal young = getYoungAnimal(false, field, loc);
                        newAnimals.add(young);
                    }
                    return;
                }
            }
        }                
    }
    
    private void spreadDisease() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            Animal other_animal = (Animal) animal; 
            if(other_animal != null) {
                if(rand.nextDouble() <= DISEASE_SPREAD_CHANCE) {
                    if(other_animal.isAlive()) {
                        other_animal.becomeDiseased();
                    }
                }
            }
        }
    }    

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return how much hunger is restored once eaten.
     */
    protected int getFoodValue() {
        return FOOD_VALUE_GIVEN;
    }
    
    /**
     * Increase the age. This could result in the fox's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    protected int getGender() {
        return gender;
    }
    
    protected boolean isDiseased() {
        return isDiseased;
    }
    
    public void becomeDiseased() {
        if(!isDiseased) {
            MAX_AGE /= 2;
        }
        isDiseased = true;
        if(age > MAX_AGE) {
            setDead();
        }        
    }
}
