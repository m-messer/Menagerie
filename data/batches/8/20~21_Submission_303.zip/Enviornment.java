import java.util.*;
/**
 * A class that controls the weather of the simulation.
 *
 * @version (a version number or a date)
 */
public class Enviornment
{
    private static final double DROUGHT_CHANCE = 0.05;
    private static final double RAIN_CHANCE = 0.2;
    private String condition; 
    // The current time of the simulation
    private int dayDuration;
    private boolean isDay;
    // The ammount of rainfall that happens per step of the simulation.
    private double rainFall;
    private Random rand = Randomizer.getRandom();
    
    public Enviornment(){
        condition = "Normal Day";
        dayDuration = 12;
        isDay = true;
        rainFall = 1;
    }
    
    public void changeWeather() {
        if(rand.nextDouble() <= DROUGHT_CHANCE) {
                rainFall = 0;
                condition = "Drought";
        }
        else if(rand.nextDouble() <= RAIN_CHANCE) {
                rainFall = 1 + 2 * rand.nextDouble();
                condition = "Heavy Rain";
        }
        else {
                rainFall = 1;
                condition = "Normal Day";
        }
    }
    
    public String getCondition() {
        return condition;
    }
    
    public int dayDuration() {
        return dayDuration;
    }
    
    public double getRainFall() {
        return rainFall; 
    }
    
    public boolean isDay() {
        return isDay;
    }
    
    public void changeDay() {
        isDay = !isDay;
    }
}
