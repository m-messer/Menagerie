import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2020.03.03
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String WEATHER_PREFIX = "Weather: ";
    private final String DAY_PREFIX = "Time: ";
    private Class disease = null;
    private boolean slow = false;
    private JLabel stepLabel, population, infoLabel, weatherLabel, timeLabel, diseaseLabel;
    private JButton slowButton, deerButton, sheepButton, zebraButton, wolfButton, jaguarButton;
    private FieldView fieldView;
    
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Fox and Rabbit Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        weatherLabel = new JLabel(WEATHER_PREFIX, JLabel.LEFT);
        timeLabel = new JLabel(DAY_PREFIX, JLabel.RIGHT);
        diseaseLabel = new JLabel("Press Buttons to infect", JLabel.CENTER);
        slowButton = new JButton("Press to slow");
        deerButton = new JButton("Deer");
        sheepButton = new JButton("Sheep");
        zebraButton = new JButton("Zebra");
        wolfButton = new JButton("Wolf");
        jaguarButton = new JButton("Jaguar");
        
        deerButton.setBackground(Color.RED);
        sheepButton.setBackground(Color.GRAY);
        zebraButton.setBackground(Color.BLACK);
        jaguarButton.setBackground(Color.ORANGE);
        wolfButton.setBackground(Color.BLUE);
        
        deerButton.setForeground(Color.WHITE);
        sheepButton.setForeground(Color.WHITE);
        zebraButton.setForeground(Color.WHITE);
        jaguarButton.setForeground(Color.WHITE);
        wolfButton.setForeground(Color.WHITE);
        
        deerButton.setOpaque(true);
        sheepButton.setOpaque(true);
        zebraButton.setOpaque(true);
        jaguarButton.setOpaque(true);
        wolfButton.setOpaque(true);
        
       
        
        deerButton.addActionListener(e -> disease=Deer.class);
        sheepButton.addActionListener(e -> disease=Sheep.class);
        zebraButton.addActionListener(e -> disease=Zebra.class);
        wolfButton.addActionListener(e -> disease=Wolf.class);
        jaguarButton.addActionListener(e -> disease=Jaguar.class);
        slowButton.addActionListener(e -> slow=true);
      
        
        setLocation(100, 50);
        
        fieldView = new FieldView(height, width);

        Container contents = getContentPane();
        
        JPanel aniCol = new JPanel();
        aniCol.setLayout(new BoxLayout(aniCol, BoxLayout.Y_AXIS));
            aniCol.add(new JPanel());
            aniCol.add(diseaseLabel);
            aniCol.add(deerButton);
            aniCol.add(sheepButton);
            aniCol.add(zebraButton);
            aniCol.add(wolfButton);
            aniCol.add(jaguarButton);
            aniCol.add(new JPanel());
            aniCol.add(slowButton);
        
        diseaseLabel.setAlignmentX(aniCol.CENTER_ALIGNMENT);
        deerButton.setAlignmentX(aniCol.CENTER_ALIGNMENT);
        sheepButton.setAlignmentX(aniCol.CENTER_ALIGNMENT);
        zebraButton.setAlignmentX(aniCol.CENTER_ALIGNMENT);
        wolfButton.setAlignmentX(aniCol.CENTER_ALIGNMENT);
        jaguarButton.setAlignmentX(aniCol.CENTER_ALIGNMENT);
        slowButton.setAlignmentX(aniCol.CENTER_ALIGNMENT);
            
      
        
        JPanel envPane = new JPanel(new FlowLayout());
            envPane.add(weatherLabel);
            envPane.add(timeLabel);
        
        JPanel infoPane = new JPanel(new BorderLayout());
            infoPane.add(stepLabel, BorderLayout.WEST);
            infoPane.add(envPane, BorderLayout.EAST);
            infoPane.add(infoLabel, BorderLayout.CENTER);
            
           
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);
        contents.add(aniCol, BorderLayout.EAST);
        
        pack();
        setVisible(true);
    }
    
    
    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }
    
    public void setWeatherText(String text)
    {
        weatherLabel.setText(WEATHER_PREFIX + text);
    }
    
    public void setTimeText(String text) 
    {
        timeLabel.setText(DAY_PREFIX + text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Object animal, Field field)
    {
        if(field.castObject(animal).isDiseased()) {
            return Color.GREEN;
        }
        else {
            Color col = colors.get(animal.getClass());
            if(col == null) {
                // no color defined for this class
                return UNKNOWN_COLOR;
            }
            else {
                return col;
            }
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }
            
        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();
        
        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    stats.incrementCount(animal.getClass());
                    fieldView.drawMark(col, row, getColor(animal, field));
                }
                else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                                 gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
    
    public Class getDisease() {return disease;}
    
    public void resetDisease() {disease = null;}
    
    public boolean isSlow() {return slow;}
}
