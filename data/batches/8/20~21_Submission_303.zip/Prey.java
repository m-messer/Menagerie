import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of prey.
 *
 * @version 2020.03.03
 */
public abstract class Prey extends Animal
{
    public Prey (Field field, Location location) {
        super(field, location);
    }
    
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            int vegetationLevel = field.getVegetationAt(where);
            if(vegetationLevel > 0) {                     
                if(vegetationLevel >= 12 - foodLevel) { 
                    field.eatVegetationAt(where, 12 - foodLevel);
                    foodLevel = 12;
                } else
                {
                    field.eatVegetationAt(where, vegetationLevel);
                    foodLevel += vegetationLevel;
                }
                return where;
            }            
        }
        return null;
    }
}
