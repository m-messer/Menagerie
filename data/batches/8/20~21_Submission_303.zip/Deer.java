import java.util.List;
import java.util.Random;

/**
 * A simple model of a deer.
 * Deer's age, eat plants, move, breed, and die.
 *
 * @version 2020.03.03
 */
public class Deer extends Prey
{
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        BREEDING_AGE = 8;
        MAX_AGE = 100;
        BREEDING_PROBABILITY = 0.2;
        // MAX_LITTER_SIZE = 15;
        MAX_LITTER_SIZE = 6;
        FOOD_VALUE_GIVEN = 16;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(12);
        }
        else {
            age = 0;
            foodLevel = 12;
        }        
    }
    
    protected Deer getYoungAnimal(boolean randomAge, Field field, Location location) {
        return new Deer(randomAge, field, location);
    }
}
