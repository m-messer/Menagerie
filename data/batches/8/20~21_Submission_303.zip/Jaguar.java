import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a jaguar.
 * Jaguars age, move, eat zebra and deer, and die.
 *
 * @version 2020.03.03
 */
public class Jaguar extends Predator
{
    /**
     * Create a jaguar. A jaguar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the jaguar will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Jaguar(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        BREEDING_AGE = 10;
        DIURNAL = true;
        MAX_AGE = 200;
        BREEDING_PROBABILITY = 0.30;
        MAX_LITTER_SIZE = 8;
        FOOD_VALUE_GIVEN = 5;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(12);
        }
        else {
            age = 0;
            foodLevel = 12;
        }
        diet = new Class[]{Zebra.class, Deer.class};
    }   
    
    protected Jaguar getYoungAnimal(boolean randomAge, Field field, Location location) {
        return new Jaguar(randomAge, field, location);
    }
}
