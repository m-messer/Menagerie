import java.util.List;
import java.util.Random;

/**
 * A simple model of a zebra.
 * Zebra's age, eat plants, move, breed, and die.
 *
 * @version 2020.03.03
 */
public class Zebra extends Prey
{
    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        BREEDING_AGE = 10;
        MAX_AGE = 120;
        BREEDING_PROBABILITY = 0.2;
        // MAX_LITTER_SIZE = 15;
        MAX_LITTER_SIZE = 4;
        FOOD_VALUE_GIVEN = 20;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(12);
        }
        else {
            age = 0;
            foodLevel = 12;
        }        
    }
    
    protected Zebra getYoungAnimal(boolean randomAge, Field field, Location location) {
        return new Zebra(randomAge, field, location);
    }
}
