
import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.01
 */
public abstract class Animal implements Creature, Infectable
{

    // an animal has a gender, breeding can only happen between opposite genders.
    enum Gender{ female, male }

    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    // the current age of the animal.
    protected int age;

    protected int foodLevel;

    private Gender gender;

    protected List<Disease> diseases;

    private double fertilityModifiers = 0;

    // All animals exists on the middle layer, 1
    private static final int ANIMAL_LAYER = 1;

    /**
     * Create a new animal at location  n field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(7);
        }
        else {
            age = 0;
            foodLevel = 7;
        }
        this.diseases = new LinkedList<>();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    /**
     * This is what the rabbit does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newCreatures A list to return newly born rabbits.
     */
    public void act(List<Creature> newCreatures, int hour, Field.Weather weather)
    {
        incrementAge();
        if(isAlive()) {
            if (isActive(hour)) {
                giveBirth(newCreatures);
                // Try to move into a free location.
                Location newLocation = foodLevel < getMinFoodLevel() ? findFood() : getField().freeAdjacentLocation(getLocation(),1);
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
            --foodLevel;

        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clearAnimal(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clearAnimal(location);
        }
        location = newLocation;
        field.placeAnimal(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    // A list of abstract methods that each animal type should implement.
    abstract protected int getFoodValue();
    abstract protected int getMaxAge();
    abstract protected double getBreedingProbability();
    abstract protected int getMaxLitterSize();
    abstract protected int getBreedingAge();
    abstract protected <Species extends Animal> Species createChild();
    abstract protected int getWakeUpTime();
    abstract protected int getSleepTime();
    abstract protected int getMinFoodLevel();

    /**
     * When the animal is awake, it should be active, meaning it can move and breed.
     * @param time the current time in the simulation.
     * @return
     */
    protected boolean isActive(int time){
        return time < getSleepTime() ^ time >= getWakeUpTime();
    }

    public int getAge() {
        return age;
    }

    /**
     * An animal needs to look for a partner that is in the neighbouring cell to it, if they are opposite genders they have the
     * ability to breed.
     * @return true if they can breed.
     */
    private boolean  canBreed(){
        Animal partner = null;
        for(Location otherLocation : field.adjacentLocations(location)){
            Object canditate = field.getAnimalAt(otherLocation);
            if(getClass().isInstance(canditate) && ((Animal) canditate).getGender() == Gender.male){
                partner = (Animal) field.getAnimalAt(otherLocation);
                break;
            }
        }
        return age>=getBreedingAge() && gender == Gender.female && partner != null && partner.getAge()>=partner.getBreedingAge();
     };
    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Creature> newAnimals)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.

        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(),1);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = createChild();

            newAnimals.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= (getBreedingProbability()+fertilityModifiers)) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }


    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Plant nextFoodSource = field.getPlantAt(where);
            if(nextFoodSource != null){
                if(nextFoodSource.canBeEaten()) {
                    foodLevel += nextFoodSource.eatPlant();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Increase the age. This could result in the fox's death.
     */
    protected void incrementAge(){
        if(++age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }


    public void catchDisease(Disease disease){
        if(!diseases.contains(disease))diseases.add(disease);
    }

    public void cureDisease(Disease disease){
        diseases.remove(disease);
    }
    public List<Disease> getDiseases(){
        return diseases;
    }

    public Gender getGender() {
        return gender;
    }

    public void tweakFertility(double modifier){
        fertilityModifiers+=modifier;
    }

    public static int getLayer(){
        return ANIMAL_LAYER;
    }

}
