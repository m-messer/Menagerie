import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Random;


/**
 *
 * An experimental test that is used to trial and error all of the creates private fields in order
 * to try and get values which returns a stable population.
 *
 * After running it for a while the population is stable for around 1200 steps.
 *
 *  * @version 2021.03.01
 */

public class Calibrator {


    // A shared random number generator to control breeding.
    protected  static final Random rand = new Random();
    protected  final double minTweak;
    protected  final double maxTweak;
    private  JFrame calibrationWindow;
    private  JTextField runNoDisplay,maxStepIndexDisplay,maxStepNoDisplay;
    private boolean hasDisplay, interrupt;

    private int max = 0;
    private long simc = 1,maxIndex = -1;

    private Simulator sim;

    public HashMap<Class<? extends Creature>, CreatureState> getMaxVars() {
        return maxVars;
    }

    HashMap<Class<? extends  Creature>, CreatureState> maxVars = (HashMap<Class<? extends Creature>, CreatureState>) initVars.clone();

    private static final int CALIBRATION_GOAL = 1000;

    private static double bound(double min, double val, double max){
        return Math.max(min,Math.min(val,max));
    }

    public Calibrator(Simulator sim){
        this(sim,-0.030,0.030, true);
    }
    public Calibrator(Simulator sim, double minTweak, double maxTweak, boolean hasDisplay){
        this.sim = sim;
        this.minTweak = minTweak;
        this.maxTweak = maxTweak;
        this.hasDisplay = hasDisplay;

        if(hasDisplay){
            // Display Setup
            calibrationWindow = new JFrame("Simulation variable calibrator");
            calibrationWindow.getContentPane().setLayout(new GridLayout(4,2));
            calibrationWindow.getContentPane().add(new JLabel("Run no."));
            runNoDisplay = new JTextField("0");
            runNoDisplay.setEditable(false);
            calibrationWindow.getContentPane().add(runNoDisplay);
            calibrationWindow.getContentPane().add(new JLabel("Longest run at:"));
            maxStepIndexDisplay = new JTextField("0");
            maxStepIndexDisplay.setEditable(false);
            calibrationWindow.getContentPane().add(maxStepIndexDisplay);
            calibrationWindow.getContentPane().add(new JLabel("Longest run length:"));
            maxStepNoDisplay = new JTextField("0");
            maxStepNoDisplay.setEditable(false);
            calibrationWindow.getContentPane().add(maxStepNoDisplay);

            calibrationWindow.getContentPane().add(new JLabel());

            JButton toggleButton = new JButton("Stop");
            toggleButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new SwingWorker<Void,Void>(){
                        @Override
                        protected Void doInBackground() throws Exception {
                            toggleButton.setText(interrupt ? "Stop": "Start");
                            if(interrupt) calibrateVariables();
                            else interrupt = true;
                            return null;
                        }

                        @Override
                        protected void done() {
                            super.done();
                        }
                    }.execute();
                }
            });
            calibrationWindow.getContentPane().add(toggleButton);

            calibrationWindow.pack();
        }

    }

    public void updateDisplay(){
        if(hasDisplay){
            runNoDisplay.setText(Long.toString(simc));
            maxStepIndexDisplay.setText(Long.toString(maxIndex));
            maxStepNoDisplay.setText(Integer.toString(max));
        }
    }

    interface CreatureState{
        void randomTweak(double minTweak, double maxTweak);
    }
    public  HashMap<Class<? extends  Creature>, CreatureState> generateVars(HashMap<Class<? extends  Creature>, CreatureState> maxVars){
        HashMap<Class<? extends  Creature>, CreatureState> nextVars = ( HashMap<Class<? extends  Creature>, CreatureState>) maxVars.clone();
        nextVars.values().forEach(state -> state.randomTweak(minTweak,maxTweak));
        return nextVars;
    }
    static class DieaseState implements  CreatureState{
        private double LETHALITY,FERITLITY_EFFECTS,CURE_CHANCE,SPREAD_CHANCE;
        protected final double MIN_LETHALITY = 0.01, MIN_FERTILITY = -0.63, MIN_CURE_CHANCE = 0.05, MIN_SPREAD_CHANCE = 0.05;
        protected final double MAX_LETHALITY = 0.6,  MAX_FERITLITY = 0.1, MAX_CURE_CHANCE = 0.7, MAX_SPREAD_CHANCE = 0.9;
        public DieaseState(double LETHALITY, double FERITLITY_EFFECTS, double CURE_CHANCE, double SPREAD_CHANCE) {
            this.LETHALITY = LETHALITY;
            this.FERITLITY_EFFECTS = FERITLITY_EFFECTS;
            this.CURE_CHANCE = CURE_CHANCE;
            this.SPREAD_CHANCE = SPREAD_CHANCE;
        }

        public double getLETHALITY() {
            return LETHALITY;
        }

        public double getFERITLITY_EFFECTS() {
            return FERITLITY_EFFECTS;
        }

        public double getCURE_CHANCE() {
            return CURE_CHANCE;
        }

        public double getSPREAD_CHANCE() {
            return SPREAD_CHANCE;
        }

        public void randomTweak(double minTweak, double maxTweak){
            LETHALITY=bound(MIN_LETHALITY, LETHALITY* (1+minTweak + (maxTweak - minTweak) * rand.nextDouble()),MAX_LETHALITY);
            FERITLITY_EFFECTS=bound(MIN_FERTILITY,LETHALITY * (1+minTweak + (maxTweak - minTweak) * rand.nextDouble()),MAX_FERITLITY);
            CURE_CHANCE= bound(MIN_CURE_CHANCE,CURE_CHANCE * (1+minTweak + (maxTweak - minTweak) * rand.nextDouble()),MAX_CURE_CHANCE);
            SPREAD_CHANCE=bound(MIN_SPREAD_CHANCE, SPREAD_CHANCE * (1+minTweak + (maxTweak - minTweak) * rand.nextDouble()),MAX_SPREAD_CHANCE);
        }

        @Override
        public String toString() {
            return "DieaseState{" +
                    "LETHALITY=" + LETHALITY +
                    ", FERITLITY_EFFECTS=" + FERITLITY_EFFECTS +
                    ", CURE_CHANCE=" + CURE_CHANCE +
                    ", SPREAD_CHANCE=" + SPREAD_CHANCE +
                    '}';
        }
    }
    static class PlantState implements  CreatureState{
        double SPREAD_PROBABILITY, SPREAD_PROBABILITY_RAIN_BONUS;
        int MAX_FOOD_VALUE, FOOD_VALUE_GROWTH;
        private static final double MIN_SPREAD_PROBABILITY = 0.1, MIN_SPREAD_PROBABILITY_RAIN_BONUS = 0.1;
        private static final int MIN_MAX_FOOD_VALUE = 5, MIN_FOOD_VALUE_GROWTH = 1;
        private static final double MAX_SPREAD_PROBABILITY = 0.3, MAX_SPREAD_PROBABILITY_RAIN_BONUS = 0.2;
        private static final int MAX_MAX_FOOD_VALUE = 1000, MAX_FOOD_VALUE_GROWTH = 100;
        public PlantState(double SPREAD_PROBABILITY, double SPREAD_PROBABILITY_RAIN_BONUS, int MAX_FOOD_VALUE, int FOOD_VALUE_GROWTH ) {
            this.SPREAD_PROBABILITY = SPREAD_PROBABILITY;
            this.SPREAD_PROBABILITY_RAIN_BONUS = SPREAD_PROBABILITY_RAIN_BONUS;
            this.MAX_FOOD_VALUE = MAX_FOOD_VALUE;
            this.FOOD_VALUE_GROWTH = FOOD_VALUE_GROWTH;
        }

        public double getSPREAD_PROBABILITY() {
            return SPREAD_PROBABILITY;
        }

        public double getSPREAD_PROBABILITY_RAIN_BONUS() {
            return SPREAD_PROBABILITY_RAIN_BONUS;

        }

        public int getMAX_FOOD_VALUE() {
            return MAX_FOOD_VALUE;
        }

        public int getFOOD_VALUE_GROWTH() {
            return FOOD_VALUE_GROWTH;
        }

        public void randomTweak(double minTweak, double maxTweak){
            SPREAD_PROBABILITY=bound(MIN_SPREAD_PROBABILITY,SPREAD_PROBABILITY*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble()),MAX_SPREAD_PROBABILITY);
            SPREAD_PROBABILITY_RAIN_BONUS=bound(MIN_SPREAD_PROBABILITY_RAIN_BONUS, SPREAD_PROBABILITY_RAIN_BONUS * (1+minTweak + (maxTweak - minTweak) * rand.nextDouble()),MAX_SPREAD_PROBABILITY_RAIN_BONUS);
            MAX_FOOD_VALUE = (int) bound(MIN_MAX_FOOD_VALUE,Math.ceil(MAX_FOOD_VALUE*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())),MAX_MAX_FOOD_VALUE);
            FOOD_VALUE_GROWTH = (int) bound(MIN_FOOD_VALUE_GROWTH,Math.ceil(FOOD_VALUE_GROWTH*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())),MAX_FOOD_VALUE_GROWTH)  ;
        }

        @Override
        public String toString() {
            return "PlantState{" +
                    "SPREAD_PROBABILITY=" + SPREAD_PROBABILITY +
                    ", SPREAD_PROBABILITY_RAIN_BONUS=" + SPREAD_PROBABILITY_RAIN_BONUS +
                    ", MAX_FOOD_VALUE=" + MAX_FOOD_VALUE +
                    ", FOOD_VALUE_GROWTH=" + FOOD_VALUE_GROWTH +
                    '}';
        }
    }
    static class AnimalState implements CreatureState{
        private int BREEDING_AGE,MAX_AGE;
        private double BREEDING_PROBABILITY;
        private int MAX_LITTER_SIZE,MIN_FOOD_LEVEL,FOOD_VALUE,WAKEUP_TIME,SLEEP_TIME;


        private static final int MIN_BREEDING_AGE = 3, MIN_MAX_AGE=80;
        private static final double MIN_BREEDING_PROBABILITY=0.05;
        private static final int MIN_MAX_LITTER_SIZE=1,MIN_MIN_FOOD_LEVEL = 3, MIN_FOOD_VALUE = 5, MIN_WAKEUP_TIME=0,MIN_SLEEP_TIME=0;
        private static final int MAX_BREEDING_AGE = 30, MAX_MAX_AGE = 1000,MAX_MAX_LITTER_SIZE = 5, MAX_MIN_FOOD_LEVEL = 1000, MAX_FOOD_VALUE = 56, MAX_WAKEUP_TIME = 24, MAX_SLEEP_TIME = 24;
        private static final double MAX_BREEDING_PROBABILITY = 0.7;
        public AnimalState(int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, int MIN_FOOD_LEVEL, int FOOD_VALUE, int WAKEUP_TIME, int SLEEP_TIME) {
            this.BREEDING_AGE = BREEDING_AGE;
            this.MAX_AGE = MAX_AGE;
            this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
            this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
            this.MIN_FOOD_LEVEL = MIN_FOOD_LEVEL;
            this.FOOD_VALUE = FOOD_VALUE;
            this.WAKEUP_TIME = WAKEUP_TIME;
            this.SLEEP_TIME = SLEEP_TIME;
        }

        public void randomTweak(double minTweak, double maxTweak){
            BREEDING_AGE = (int) bound(MIN_BREEDING_AGE,Math.ceil(BREEDING_AGE*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())),MAX_BREEDING_AGE );
            MAX_AGE = (int) bound(MIN_MAX_AGE,Math.ceil(MAX_AGE*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())),MAX_MAX_AGE);
            BREEDING_PROBABILITY= bound(MIN_BREEDING_PROBABILITY,BREEDING_PROBABILITY*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble()) ,MAX_BREEDING_PROBABILITY);
            MAX_LITTER_SIZE= (int) bound(MIN_MAX_LITTER_SIZE,Math.ceil(MAX_LITTER_SIZE*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())),MAX_MAX_LITTER_SIZE);
            MIN_FOOD_LEVEL= (int) bound(MIN_MIN_FOOD_LEVEL,Math.ceil(MIN_FOOD_LEVEL*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())),MAX_MIN_FOOD_LEVEL);
            FOOD_VALUE= (int) bound(MIN_FOOD_VALUE,Math.ceil(FOOD_VALUE*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())),MAX_FOOD_VALUE);
            WAKEUP_TIME=(int) bound(MIN_WAKEUP_TIME,Math.ceil(WAKEUP_TIME*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())) % 24,MAX_WAKEUP_TIME);
            SLEEP_TIME= (int) Math.abs(WAKEUP_TIME-bound(MIN_SLEEP_TIME,Math.ceil(SLEEP_TIME*(1+minTweak + (maxTweak - minTweak) * rand.nextDouble())) % 24,MAX_SLEEP_TIME));
        }

        @Override
        public String toString() {
            return "AnimalState{" +
                    "BREEDING_AGE=" + BREEDING_AGE +
                    ", MAX_AGE=" + MAX_AGE +
                    ", BREEDING_PROBABILITY=" + BREEDING_PROBABILITY +
                    ", MAX_LITTER_SIZE=" + MAX_LITTER_SIZE +
                    ", MIN_FOOD_LEVEL=" + MIN_FOOD_LEVEL +
                    ", FOOD_VALUE=" + FOOD_VALUE +
                    ", WAKEUP_TIME=" + WAKEUP_TIME +
                    ", SLEEP_TIME=" + SLEEP_TIME +
                    '}';
        }

        public int getMIN_FOOD_VALUE() {
            return MIN_FOOD_LEVEL;
        }

        public int getBREEDING_AGE() {
            return BREEDING_AGE;
        }

        public int getMAX_AGE() {
            return MAX_AGE;
        }

        public int getMAX_LITTER_SIZE() {
            return MAX_LITTER_SIZE;
        }

        public int getWAKEUP_TIME() {
            return WAKEUP_TIME;
        }

        public int getSLEEP_TIME() {
            return SLEEP_TIME;
        }

        public int getFOOD_VALUE() {
            return FOOD_VALUE;
        }

        public double getBREEDING_PROBABILITY() {
            return BREEDING_PROBABILITY;
        }
    }
    private static final HashMap<Class<? extends  Creature>, CreatureState> initVars = new HashMap<>(){{
            put(Lion.class, new AnimalState(30,734,0.6050605182001124,5,891,56,0,0));
            put(Zebra.class, new AnimalState(30,696,0.18194395913677647,5,956,56,0,0));
            put(Gazelle.class, new AnimalState(30,695,0.05468192549694008,5,842,56,0,0));
            put(Vulture.class, new AnimalState(30,928,0.09855408484261238,5,1000,56,0,0));
            put(Hyena.class, new AnimalState(30,170,0.11947882001021407,5,714,56,0,0));
            put(Grass.class, new PlantState(0.2782479483802033,0.2,994,100));
            put(YellowFever.class,new DieaseState(0.013292862163901376,0.013204660181269784,0.054274755362526274,0.05153925789218166));
    }};

    private static HashMap<Class<? extends Creature>, Double> initProbs = new HashMap<>(){{
        put(Lion.class,0.02);
        put(Vulture.class,0.03);
        put(Hyena.class,0.03);
        put(Gazelle.class,0.05);
        put(Zebra.class,0.06);
        put(Grass.class,0.1);
        put(YellowFever.class,0.05);
    }};

    public static HashMap<Class<? extends Creature>, Double> generateCreationProb(){
        return initProbs;
    }


    public static String stateString(int max,long maxId, HashMap<Class<? extends Creature>, CreatureState> simState){
        StringBuilder outstr = new StringBuilder();
        outstr.append("Simulation no:");
        outstr.append(maxId);
        outstr.append("\n");
        outstr.append("Extinction at step:");
        outstr.append(max);
        outstr.append("\n");
        for(Class<? extends Creature> c : simState.keySet()){
            outstr.append(c.getName());
            outstr.append(" : ");
            outstr.append(simState.get(c).toString());
            outstr.append("\n");
        }

        return outstr.toString();
    }

    public void calibrateVariables(){
        interrupt = false;

        while(max<CALIBRATION_GOAL && !interrupt) {
            HashMap<Class<? extends  Creature>, CreatureState> currVars = generateVars(maxVars) ;
            sim.setCreationProbabilities(generateCreationProb());
            sim.setAllVars(currVars);
            sim.reset();
            sim.simulate(1100);
            updateDisplay();
            if (sim.getStep() > max) {
                max = sim.getStep();
                maxVars = (HashMap<Class<? extends Creature>, CreatureState>) currVars.clone();
                maxIndex = simc;
                try {
                    FileWriter outfile = new FileWriter("calibration.txt");
                    outfile.write(stateString(max,maxIndex,maxVars));
                    outfile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            ++simc;
        }

        sim.setAllVars(maxVars);
    }


    public void toggleInfoWindow(){
        if(hasDisplay) calibrationWindow.setVisible(!calibrationWindow.isVisible());
    }
    public void displayInfoWindow(){
        if(hasDisplay) calibrationWindow.setVisible(true);
    }


}
