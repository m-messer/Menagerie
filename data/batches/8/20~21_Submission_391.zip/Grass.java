/**
 * An implementation of a type of plant
 * It's ability to spread and the spread bonus with rain has been added.
 *
 * @version 2021.03.01
 */


public class Grass extends Plant{

    // the probability that grass will move to a free neighbouring tile without rain
    private static double SPREAD_PROBABLILITY=0.2782479483802033;
    // the probability with rain.
    private static double SPREAD_PROBABLITY_RAIN_BONUS = 0.2;
    private static int MAX_FOOD_VALUE = 994;
    private static int FOOD_VALUE_GROWTH = 100;


    public Grass(boolean randomSize, Field field, Location location){
        super(randomSize,field,location);
    }
    public Grass(Field field, Location location){this(false,field,location);}

    /**
     * If the grass spreads add a new plant at that location
     * @param field there is only one field, our habitat.
     * @param location the location that the plant has just spread to.
     * @return the new grass.
     */
    protected Grass createChild(Field field, Location location) {
        return new Grass(true,field,location);
    }

    protected double getSpreadProbablility() {
        return SPREAD_PROBABLILITY;
    }

    protected double getSpreadProbablityRainBonus() {
        return SPREAD_PROBABLITY_RAIN_BONUS;
    }

    public int getMaxFoodValue() {
        return MAX_FOOD_VALUE;
    }


    public  int getFoodValueGrowth() {
        return FOOD_VALUE_GROWTH;
    }

    public static void setVars(Calibrator.CreatureState vars){
        Calibrator.PlantState state = (Calibrator.PlantState) vars;
        SPREAD_PROBABLILITY = state.getSPREAD_PROBABILITY();
        SPREAD_PROBABLITY_RAIN_BONUS =  state.getSPREAD_PROBABILITY_RAIN_BONUS();
        MAX_FOOD_VALUE = state.getMAX_FOOD_VALUE();
        FOOD_VALUE_GROWTH = state.getFOOD_VALUE_GROWTH();
    }
}
