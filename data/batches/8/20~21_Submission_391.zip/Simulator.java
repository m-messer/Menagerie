import java.util.*;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 * *
 *
 *  * @version 2021.03.01
 */

public class Simulator
{

    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    private static final int DEFAULT_LAYER_COUNT = 3;

    private static final int DEFAULT_DELAY = 30;



    private Calibrator calibrator;

    public static void setCreationProbabilities(HashMap<Class<? extends Creature>, Double> creationProbabilities) {
        CREATION_PROBABILITIES = creationProbabilities;
    }

    /**
     * Creation probabilities for all animals have been stored in a hashmap.
     */
    private static HashMap<Class<? extends Creature>, Double> CREATION_PROBABILITIES = new HashMap<>(){{
        put(Lion.class,0.02);
        put(Vulture.class,0.03);
        put(Hyena.class,0.03);
        put(Gazelle.class,0.05);
        put(Zebra.class,0.06);
        put(Grass.class,0.1);
        put(YellowFever.class,0.05);
    }};

    /**
     * The field has 3 layers now, in each square plants can live on layer 0, animals have the ability to live on
     * layer 1 and diseases populate the top layer.
     */
    private static final HashMap<Integer,String> LAYER_NAMES = new HashMap<>(){{
        put(0,"Plants");
        put(1,"Animals");
        put(2,"Diseases");
    }};

    // a final field which limits the wether from changing for at least 5 steps.
    private static final int WHEATHER_COOLDOWN = 5;
    private int wheatherCurrentCooldown = WHEATHER_COOLDOWN;

    // when a plant is starting to grow it's food value has been initialized to 0, too small to be eaten.
    private int initialPlantFoodValue = 0;

    // variable which holds and displays the simulated time in our simulation.
    private byte hour = 0;


    // List of animals in the field.
    private List<Creature> creatures;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    private int stepQueue;
    private boolean simActive, stopped;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH,DEFAULT_LAYER_COUNT);
    }

    public Calibrator getCalibrator() {
        return calibrator;
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width, int layerCount)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        calibrator = new Calibrator(this);
        
        creatures = new ArrayList<>();
        field = new Field(depth, width,layerCount);


        // Create a view of the state of each location in the field.
        view = new SimulatorView(this, depth, width);
        view.addSpecies(Zebra.class, Color.ORANGE);
        view.addSpecies(Lion.class, Color.BLUE);
        view.addSpecies(Gazelle.class, Color.MAGENTA);
        view.addSpecies(Vulture.class, Color.DARK_GRAY);
        view.addSpecies(Hyena.class, Color.RED);
        view.addSpecies(Grass.class, Color.GREEN);
        view.addSpecies(YellowFever.class,Color.RED);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(5000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps, int delay)
    {
        stepQueue+=numSteps;
        if(simActive) return;
        simActive = true;
        while(simActive && view.isViable(field) && stepQueue>0){
            simulateOneStep();
            --stepQueue;
            delay(delay);
        }
        simActive = false;
    }

    public void simulate(int numSteps) {
        simulate(numSteps,0)  ;
    }

    public int getStepQueue() {
        return stepQueue;
    }

    /**
     * (Re)start the simulation
     */
    public void start(int delay){
        simulate(0, delay);
    }
    public void start(){start(0);}

    /**
     * Stop (Pause) the simulation
     */
    public void stop(){
        stopped = true;
        simActive = false;
    }

    public byte getHour() {
        return hour;
    }

    public Field getField() {
        return field;
    }

    public int getStep() {
        return step;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each creature
     */
    public void simulateOneStep()
    {
        if(hour == 24) hour = 0;
        if(wheatherCurrentCooldown == 0){
            field.setWheather(Field.randomWheather());
            wheatherCurrentCooldown = WHEATHER_COOLDOWN;
        } else -- wheatherCurrentCooldown;
        ++step;


        // Provide space for newborn animals.
        List<Creature> newCreatures = new ArrayList<>();
        // Let all rabbits act.
        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
            Creature creature = it.next();
            if(!creature.isAlive()) {
                it.remove();
                continue;
            }
            creature.act(newCreatures,hour, field.getWheather());

        }



        // Add the newly born foxes and rabbits to the main lists.
        creatures.addAll(newCreatures);

        ++hour;
        view.showStatus(step, field, hour);

    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        stop();
        step = 0;
        hour = 0;
        creatures.clear();
        Randomizer.reset();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field,hour);
    }
    
    /**
     * Randomly populate the field with creatures.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();

        Disease testis = new YellowFever(field);
        creatures.add(testis);

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++)
            {
                Animal animal = null;
                Location location = new Location(row, col);
                if(rand.nextDouble() <= CREATION_PROBABILITIES.get(Lion.class)) {
                    animal = new Lion(true, field, location);
                }
                else if (rand.nextDouble() <= CREATION_PROBABILITIES.get(Hyena.class))
                {
                    animal = new Hyena(true, field, location);
                }
                else if (rand.nextDouble() <= CREATION_PROBABILITIES.get(Vulture.class))
                {
                    animal = new Vulture(true, field, location);
                }
                else if(rand.nextDouble() <= CREATION_PROBABILITIES.get(Zebra.class))
                {
                    animal = new Zebra(true, field, location);
                }
                else if(rand.nextDouble() <= CREATION_PROBABILITIES.get(Gazelle.class)) {
                    animal = new Gazelle(true, field, location);
                }
                if(animal != null) {
                    if(rand.nextDouble()<=CREATION_PROBABILITIES.get(YellowFever.class) && testis.canInfect(animal)) testis.spreadTo((Infectable) animal);
                    creatures.add(animal);
                }

                if(rand.nextDouble() <= CREATION_PROBABILITIES.get(Grass.class)){
                    creatures.add(new Grass(field, location));
                }

            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * A getter which returns the layers name based on the layers number
     * @param layerNo The layer number we want the name for (0, 1 or 2)
     * @return The name of the layer which corresponds to the layer number inputted.
     */
    public String getLayerName(int layerNo){
        return LAYER_NAMES.containsKey(layerNo) ? LAYER_NAMES.get(layerNo) : Integer.toString(layerNo);
    }

    public int endless(int delay){
        stopped = false;
        while(view.isViable(field) && !stopped) simulate(1,delay);
        return step;
    }

    public int endless(){
        return endless(0);
    }

    public static Map<Class, Map<String, ?>> getVars(){
        return new HashMap<>();
    }

    public void setVars(HashMap<String,Double> vars){

    }

    /**
     * Sets all simulation variables
     * @param vars the set of variables to be used
     */
    public void setAllVars(HashMap<Class<? extends  Creature>, Calibrator.CreatureState > vars){
        for(Class<? extends  Creature> c  : vars.keySet()){
            try {
                c.getMethod("setVars", Calibrator.CreatureState.class).invoke(null,vars.get(c));
            }catch(Exception e){
                System.err.println("Method "+c.getName()+".setVars not found ("+e.toString()+")");
            };
        }
    }


    public void toggleVisibility(){
        view.setVisible(!view.isVisible());
    }

    public static int getDefaultDelay(){
        return DEFAULT_DELAY;
    }

}
