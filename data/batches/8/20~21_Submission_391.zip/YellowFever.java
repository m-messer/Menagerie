/**
 * A special type of disease called Yellow Fever that can spread to our animals.
 *
 * The lethality and other rates of the disease have been defined here
 *
 *
 *  * @version 2021.03.01
 */

public class YellowFever extends Disease{
    private static double LETHALITY = 0.013292862163901376, FERTILITY_EFFECTS = 0.013204660181269784, CURE_CHANCE = 0.054274755362526274, SPREAD_CHANCE = 0.05153925789218166;
    public YellowFever(Field field){
        super(field,LETHALITY,FERTILITY_EFFECTS,CURE_CHANCE,SPREAD_CHANCE, Hyena.class, Lion.class );
    }
    public static void setVars(Calibrator.CreatureState vars){
        Calibrator.DieaseState state = (Calibrator.DieaseState) vars;
        LETHALITY = state.getLETHALITY();
        FERTILITY_EFFECTS =  state.getFERITLITY_EFFECTS();
        CURE_CHANCE = state.getCURE_CHANCE();
        SPREAD_CHANCE = state.getSPREAD_CHANCE();
    }
}
