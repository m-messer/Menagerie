import java.util.List;

public interface Infectable {
    List<Disease> getDiseases();
    void catchDisease(Disease disease);
    void cureDisease(Disease disease);
    void setDead();
    void tweakFertility(double modifier);
    Location getLocation();

}
