import java.util.Random;

/**
 * A simple model of a Hyena, a predator.
 * Hyenas age, breed, move and eat other preys and die.
 *
 * Depending on the weather their ability to hunt can be effected.
 *  @version 2021.03.01
 */


public class Hyena extends Predator
{

    // A shared random number generator to control breeding.
    private static Random rand = Randomizer.getRandom();

    // The age at which a fox can start to breed.
    private static int BREEDING_AGE = 30;
    // The age to which a fox can live.
    public static int MAX_AGE = 974;
    // The likelihood of a fox breeding.
    private static double BREEDING_PROBABILITY = 0.11947882001021407;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 5;
    //
    private static int FOOD_VALUE=56;

    private static int MIN_FOOD_LEVEL = 714;

    protected static int WAKEUP_TIME = 0;
    protected static int SLEEP_TIME = 0;

    /**
     * Create a new Hyena. A vulture may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the hyena will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location){
        super(randomAge,field,location,Gazelle.class);
    }


    /**
     * When hyenas breeds a new hyena is created with age 0 at the breeding location.
     * @return newly born hyena.
     */
    protected Hyena createChild(){
        return new Hyena(false,getField(),getLocation());
    }

    public int getFoodValue() {
        return FOOD_VALUE;
    }


    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    protected int getMaxAge() {
        return MAX_AGE;
    }

    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    protected  int getMinFoodLevel() { return MIN_FOOD_LEVEL; }

    protected int getSleepTime(){return SLEEP_TIME;}
    protected int getWakeUpTime(){return WAKEUP_TIME;}

    public static void setVars(Calibrator.CreatureState vars){
        Calibrator.AnimalState state = (Calibrator.AnimalState) vars;
        BREEDING_AGE = state.getBREEDING_AGE();
        MAX_AGE =  state.getMAX_AGE();
        BREEDING_PROBABILITY = state.getBREEDING_PROBABILITY();
        MAX_LITTER_SIZE = state.getMAX_LITTER_SIZE();
        WAKEUP_TIME = state.getWAKEUP_TIME();
        SLEEP_TIME = state.getSLEEP_TIME();
        FOOD_VALUE = state.getFOOD_VALUE();
        MIN_FOOD_LEVEL = state.getMIN_FOOD_VALUE();
    }
}
