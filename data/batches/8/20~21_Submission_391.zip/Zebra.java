import java.util.Random;

/**
 * A simple model of a Zebra.
 * Zebras age, move, breed, and die.
 * @version 2021.03.01

 */
public class Zebra extends Animal
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static int BREEDING_AGE = 30;
    // The age to which a rabbit can live.
    private static int MAX_AGE = 696;
    // The likelihood of a rabbit breeding.
    private static double BREEDING_PROBABILITY = 0.18194395913677647; //0.12
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 5;
    //  shared random number generator to control breeding.
    private static Random rand = Randomizer.getRandom();

    // The time when Zebras wake up
    protected static int WAKEUP_TIME = 0;
    // The time when Zebras go to sleep (whilst sleeping they do not move or breed).
    protected static int SLEEP_TIME = 0;

    // The Zebra's foodValue when it is eaten.
    private static int FOOD_VALUE = 56;

    private static int MIN_FOOD_LEVEL = 956;

    
    /**
     * Create a new Zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
    }


    /**
     * When a Zebra breeds a new Zebra is created with age 0 at the breeding location.
     * @return newly born Zebra.
     */
    protected Zebra createChild(){
        return new Zebra(false,getField(),getLocation());
    }

    /**
     * A zebra can breed if it has reached the breeding age.
     * @return true if the zebra can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Public getters to have access to private fields
     * @return food value.
     */
    public int getFoodValue() {
        return FOOD_VALUE;
    }

    protected int getMaxAge() {
        return MAX_AGE;
    }

    protected  int getBreedingAge() {
        return BREEDING_AGE;
    }

    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    protected  int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    protected int getSleepTime(){return SLEEP_TIME;}
    

    protected int getWakeUpTime(){return WAKEUP_TIME;}

    protected int getMinFoodLevel(){ return MIN_FOOD_LEVEL;}

    /**
     * A trial and error method to get field values which keeps the zebras population stable in the simulation
     * @param vars all the field values for the Zebra class
     */
    public static void setVars(Calibrator.CreatureState vars){
        Calibrator.AnimalState state = (Calibrator.AnimalState) vars;
        BREEDING_AGE = state.getBREEDING_AGE();
        MAX_AGE =  state.getMAX_AGE();
        BREEDING_PROBABILITY = state.getBREEDING_PROBABILITY();
        MAX_LITTER_SIZE = state.getMAX_LITTER_SIZE();
        WAKEUP_TIME = state.getWAKEUP_TIME();
        SLEEP_TIME = state.getSLEEP_TIME();
        FOOD_VALUE = state.getFOOD_VALUE();
        MIN_FOOD_LEVEL = state.getMIN_FOOD_VALUE();
    }
}
