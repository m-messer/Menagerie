import java.util.LinkedList;
import java.util.List;
import java.util.Random;


/**
 * A simple abstract model of a plant.
 * A plant has a food value, and a location, the place where it grows
 *
 * Plants are not able to move, and once they are eaten their food value goes back down to 0.
 *
 * A plant can spread to neighbouring tiles, and if it is raining, there is a higher chance that the plant
 * will spread.
 *
 * @version 2021.03.01
 */

public abstract class Plant implements Creature, Infectable
{
    // the amount of food the plant is currently worth
    private int foodValue;
    // the place where the plant grows.
    private Location location;
    private Field field;

    private static int MINIMUM_FOOD_VALUE = 4;

    //a plant can spread to neighboring field
    protected abstract double getSpreadProbablility();

    // when it rains the plant has a higher chance of spreading to neighbouring tiles.
    protected abstract double getSpreadProbablityRainBonus() ;

    private boolean alive;

    protected List<Disease> diseases;

    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    /**
     * A plant just like an animal is able to catch a disease.
     * @param disease the disease that the plant has catched.
     */
    public void catchDisease(Disease disease){
        if(!diseases.contains(disease))diseases.add(disease);
    }

    /**
     * If the disease has been cured, the plant should no longer be infected.
     * @param disease The disease that has just been cured.
     */
    public void cureDisease(Disease disease){
        diseases.remove(disease);
    }
    public List<Disease> getDiseases(){
        return diseases;
    }

    private static final int PLANT_LAYER = 0;



    /**
     * Constructor to create a plant. Has a food value and the location where it grows.
     * @param field
     * @param location
     */
    public Plant(boolean randomSize, Field field, Location location)
    {
        this.foodValue = randomSize ? rand.nextInt(getMaxFoodValue()) : 0;
        this.field = field;
        this.location = location;
        alive=true;
        if(location != null) {
            field.clearPlant(location);
        }
        field.placePlant(this, location);
        this.diseases = new LinkedList<>();
    }

    abstract protected <Species extends Plant> Species createChild(Field field, Location location);

    public double getFoodValue() {
        return foodValue;
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    private Field getField()
    {
        return field;
    }


    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean canBeEaten()
    {
        return foodValue >= MINIMUM_FOOD_VALUE;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     * @return The plant's food value before being eaten
     */
    public int eatPlant()
    {
        setDead();
        return foodValue;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * A plant has the ability to spread to neighbouring tiles, and if a tile is free it may spread there.
     * @param newCreatures
     */
    public void spread(List<Creature> newCreatures){
        if(field.getFreeAdjacentLocations(location,0).size() > 0){
            Plant young = createChild(field,field.getFreeAdjacentLocations(location,0).get(0));
            newCreatures.add(young);
        }

    }

    /**
     * If it is raining the probability of the plant spreading has been increased by a bonus.
     * @param newCreatures
     * @param hour
     * @param weather
     */
    public void act(List<Creature> newCreatures, int hour, Field.Weather weather) {
        if(rand.nextDouble()<= getSpreadProbablility()+(weather == Field.Weather.RAIN ? getSpreadProbablityRainBonus() : 0 )) spread(newCreatures);
        if(foodValue<getMaxFoodValue()) foodValue += getFoodValueGrowth();
    }

    public boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clearPlant(location);
            location = null;
            field = null;
        }
    }

    public static int getLayer(){
        return PLANT_LAYER;
    }

    public void tweakFertility(double fertilityModifier){}


    abstract int getFoodValueGrowth();
    abstract int getMaxFoodValue();
}
