import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2021.03.01
 */
public abstract class Predator extends Animal
{
    // Characteristics shared by all foxes (class variables).

    protected List<Class<? extends Animal>> preys;


    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param preys The animal or animals that predator is capable of eating.
     */
    public Predator( boolean randomAge, Field field, Location location, Class<? extends Animal>... preys)
    {
        super(randomAge, field, location);
        this.preys=List.of(preys);

    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newCreatures A list to return newly born foxes.
     */
    @Override
    public void act(List<Creature> newCreatures, int hour, Field.Weather weather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(isActive(hour)) {
                giveBirth(newCreatures);
                // Move towards a source of food if found.
                Location newLocation = foodLevel < getMinFoodLevel() && weather != Field.Weather.FOG ? findFood() : null;

                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), getLayer());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
            --foodLevel;
        }
    }

    /**
     * Get the minimum food level that a predator should be able to consume.
     * @return the minimum food level.
     */



    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    @Override
    protected Location findFood()
    {

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Animal nextPrey = field.getAnimalAt(where);
            if(nextPrey!= null && preys.contains(nextPrey.getClass())){
                if(nextPrey.isAlive()) {
                    nextPrey.setDead();
                    foodLevel += nextPrey.getFoodValue();
                    return where;
                }
            }
        }
        return null;
    }

}
