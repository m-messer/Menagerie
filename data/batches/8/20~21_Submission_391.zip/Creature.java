import java.util.HashMap;
import java.util.List;

public interface Creature {
    int DEFAULT_LAYER = 0;
    boolean isAlive();
    void act(List<Creature> newCreatures, int hour, Field.Weather weather);
    static int getLayer(){
        return DEFAULT_LAYER;
    };
    static HashMap<String,Integer> getVars(){
        return new HashMap<>();
    }
    static void setVars(Calibrator.CreatureState vars){}
}
