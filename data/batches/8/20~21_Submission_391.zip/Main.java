public class Main {
    public static void main(String[] Args){
        Simulator sim = new Simulator();
    }
}
