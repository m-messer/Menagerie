import java.util.Random;

/**
 * A simple model of a Gazelle.
 * Gazelle age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Gazelle extends Animal
{
    // Characteristics shared by all gazelles (class variables).

    // The age at which a gazelle can start to breed.
    private static int BREEDING_AGE = 30;
    // The age to which a gazelle can live.
    private static int MAX_AGE = 695;
    // The likelihood of a gazelle breeding.
    private static double BREEDING_PROBABILITY = 0.05468192549694008; 
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static Random rand = Randomizer.getRandom();

    protected static int WAKEUP_TIME = 0;
    protected static int SLEEP_TIME = 0;

    // The gazelle's foodValue
    private static int FOOD_VALUE = 56;

    private static int MINIMUM_FOOD_VALUE = 842;
    
    // Individual characteristics (instance fields).



    /**
     * Create a new gazelle. A gazelle may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the gazelle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gazelle(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
    }


    /**
     * When Gazelles breeds a new gazelle is created with age 0 at the breeding location.
     * @return newly born gazelle.
     */
    protected Gazelle createChild(){
        return new Gazelle(false,getField(),getLocation());
    }


    public int getFoodValue() {
        return FOOD_VALUE;
    }
    protected int getMaxAge() {
        return MAX_AGE;
    }

    protected  int getBreedingAge() {
        return BREEDING_AGE;
    }

    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    protected  int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    protected int getSleepTime(){return SLEEP_TIME;}
    protected int getWakeUpTime(){return WAKEUP_TIME;}
    protected int getMinFoodLevel() {return MINIMUM_FOOD_VALUE;}

    public static void setVars(Calibrator.CreatureState vars){
        Calibrator.AnimalState state = (Calibrator.AnimalState) vars;
        BREEDING_AGE = state.getBREEDING_AGE();
        MAX_AGE =  state.getMAX_AGE();
        BREEDING_PROBABILITY = state.getBREEDING_PROBABILITY();
        MAX_LITTER_SIZE = state.getMAX_LITTER_SIZE();
        WAKEUP_TIME = state.getWAKEUP_TIME();
        SLEEP_TIME = state.getSLEEP_TIME();
        FOOD_VALUE = state.getFOOD_VALUE();
        MINIMUM_FOOD_VALUE = state.getMIN_FOOD_VALUE();
    }
}
