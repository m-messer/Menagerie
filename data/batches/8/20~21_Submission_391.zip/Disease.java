import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * An abstract class to define what properties a disease must have.
 *
 * Diseases should have a name so they can be identified, lethality, whether it effects fertility
 * the chance that it can be cured and also how quickly does it spread.
 *
 * @version 2021.03.01 *
 */

public abstract class Disease implements Creature {
    private List<Class<? extends Animal>> targets;
    // A shared random number generator to control.
    private static final Random rand = Randomizer.getRandom();
    private Field field;

    private List<Infectable> casualities;

    private final double LETHALITY, FERTILITY_EFFECTS, CURE_CHANCE, SPREAD_CHANCE;
    private static final int DISEASE_LAYER = 2;

    /**
     * When creating a disease the following attributes must be specified.
     * @param field in which habitat it exists in (we only have one)
     * @param lethality how lethal is it, probability that it kills the animal/plant
     * @param fertilityEffects whether it stops or slows down fertility within the animal that is carrying it
     * @param cureChance probability that it is cured and animal does not die
     * @param spreadChance how quickly it can spread to nearby creates.
     * @param targets a list of things it can spread to
     */
    public Disease(Field field, double lethality, double fertilityEffects, double cureChance, double spreadChance, Class<? extends Animal>... targets) {
        this.field = field;
        this.LETHALITY = lethality;
        this.FERTILITY_EFFECTS = fertilityEffects;
        this.CURE_CHANCE = cureChance;
        this.SPREAD_CHANCE = spreadChance;
        this.targets = List.of(targets);
        casualities = new LinkedList<>();
    }
    public void act(List<Creature> newCreatures, int hour, Field.Weather weather){
       casualities.forEach(casuality -> act(casuality));
    }

    /**
     * This logic describes how a disease will spread, very similar to how plants spread.
     * if the target is in an adjacent tile, and its of a type that the disease can spread to
     * it has a chance of becoming infected.
     * @param target
     */
    public void act(Infectable target) {
        if (rand.nextDouble() <= CURE_CHANCE) {
            remove(target);
            return;
        }
        field.adjacentLocations(target.getLocation()).forEach(location -> {
            for(Object targat : field.getObjectsAt(location)){
                if (targets.contains(target.getClass())){
                    spreadTo((Infectable) field.getAnimalAt(location));
                }

            }

        });
        if (rand.nextDouble() <= LETHALITY) target.setDead();
    }

    /**
     * if the animal survives the disease and is cured, it goes back to normal.
     * @param animal
     */
    public void remove(Infectable animal) {
        animal.tweakFertility(-FERTILITY_EFFECTS);
        animal.cureDisease(this);
    }

    /**
     * The animal that the disease will spread to.
     * @param creature
     */
    public void spreadTo(Infectable creature) {
        if(!canInfect(creature)) return;
        if (rand.nextDouble() > SPREAD_CHANCE) return;
        creature.catchDisease(this);
        creature.tweakFertility(FERTILITY_EFFECTS);
    }

    public boolean isAlive(){
        return casualities.size() > 0;
    }
    public static int getLayer(){
        return DISEASE_LAYER;
    }

    public boolean canInfect(Infectable creature){
        return targets.contains(creature.getClass());
    }
}
