import java.util.List;

/**
 * A class of representing shared charactersistics of Asexually Reproducing animals. They cannot get infected
 *
 * @version 1.1
 */
public abstract class AsexualReproducing extends Animal
{
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public AsexualReproducing(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * Return if the animal is infected
     * @return true, If the animal is infected, false otherwise
     */
    @Override
    protected void setIsInfected(boolean infected){
        infected = false; //return a dummy value
    }

    /**
     * Return if the animal is infected
     * @return true, If the animal is infected, false otherwise
     */
    @Override
    public boolean getIsInfected(){
        return false;
    }

    /**
     * Check weather the animal can give birth
     * return true, If yes, false otherwise
     */
    @Override
    protected boolean canBirth()
    {
        return false;
    }
}
