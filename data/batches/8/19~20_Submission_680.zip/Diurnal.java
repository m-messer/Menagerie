
/**
 * Interface of Diurnal animals. Diurnal Animals are active during the day, and inactive during night time
 *
 * @version 1.1
 */
public interface Diurnal
{

}
