import java.util.List;
import java.util.Random;

/**
 * A simple model of a Sardine
 * Sardines age, move and die
 */
public class Clownfish extends SexualReproducing implements Diurnal
{
    // The age at which a sardine can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a sardine can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a sardine breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 90;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Clownfish food value
    private static final int FOOD_VALUE = 20;
    // Clownfish stomach capacity
    private static final int STOMACH_VALUE = 70;
    // The animal's age.
    private int age;
    // The animal's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a clownfish. A clownfish can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the clownfish will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Clownfish(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(STOMACH_VALUE);
        }
        else {
            age = 0;
            foodLevel = STOMACH_VALUE;
        }
    }

    /**
     * Get FoodValue of the animal, if the animal is prey
     * @return int FOOD_VALUE, the value of food the animal is worth when eaten
     */
    @Override
    public int getFoodValue(){
        return FOOD_VALUE;
    }

    /**
     * Get the food value of the organism
     * @return int, the value of food the organism is worth when eaten
     */
    @Override
    public int getStomach(){
        return STOMACH_VALUE;
    }

    /**
     * Set the Food Level of the particular object
     * @param level, The value to set as foodlevel
     */
    @Override
    protected void setFoodLevel(int level)
    {
        foodLevel = level;
    }

    /**
     * The animal looks for a new location to move, feed, and reproduce. In the process its age and hunger are increased.
     * @param newAnimals A list to return newly born animals.
     */
    @Override
    public void act(List<Animal> newAnimals)
    {
        incrementAge(age,MAX_AGE);
        if(isActive()){
            incrementHunger(foodLevel); 
            if(!isAlive()){
                return;
            }
            reproduce(newAnimals,age, BREEDING_AGE, BREEDING_PROBABILITY,MAX_LITTER_SIZE);
            move();
        }
    }

    /**
     * Set the age of the animal
     * @param age, The age of the animal
     */
    @Override
    protected void setAge(int age){
        this.age = age;
    }

    /**
     * Return the food level of the animal
     * @return foodLevel, The food level of the organism
     */
    @Override
    protected int getFoodLevel()
    {
        return foodLevel;
    }
}