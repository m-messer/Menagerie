
/**
 * A class of represetning shared charactersistics of elements on the grid.
 *
 * @version 1.1
 */
public class Element
{
    // The elemet's field.
    private Field field;
    // The element's position in the field.
    private Location location;

    /**
     * Constructor for objects of class Element
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Element(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }

    /**
     * Return the element's location.
     * @return location, The element's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the element at the new location in the given field.
     * @param newLocation The element's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the element's field.
     * @return field, The element's field.
     */
    protected Field getField()
    {
        return field;
    }

}
