
/**
 * A class of represetning shared charactersistics of Organism.
 *
 * @version 1.1
 */
public abstract class Organism extends Element
{
    //Whether the organism is alive or not
    private boolean alive;

    /**
     * Constructor for objects of class Organism
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        super(field,location);
        alive = true;
    }

    /**
     * Check whether the organism is alive or not.
     * @return true, If the organism is still alive, false otherwise
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        Location location = getLocation();
        Field field = getField();
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Get the food value of the organism
     * @return int, the value of food the organism is worth when eaten
     */
    abstract protected  int getFoodValue();
}
