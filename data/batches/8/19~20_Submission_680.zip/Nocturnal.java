
/**
 * Interface of Nocturnal animals. Nocturnal animals are active during the night, and inactive during day time
 *
 * @version 1.1
 */
public interface Nocturnal
{
}
