
/**
 * This class shows the shared methods of the infected animals.
 * Animals get infected if they mate.
 * If the animal's parent is infected the young animal will be infected as well
 *
 * @version 1.1
 */
public interface Infection
{
    // The probability of an animal being infected
    double INFECTION_PROB = 1;

    /**
     * Return the infected probability
     * @return INFECTION _PROB, The probability of an animal born as infected
     */
    static double getInfectionProb(){
        return INFECTION_PROB;
    }

    /**
     * Make the young animal infected if the animal's parent is infected as well.
     */
    static void infectOffspring(Animal parent, Animal young){
        if(parent.getIsInfected() && parent instanceof SexualReproducing){
            young.setIsInfected(true); //infect the young animal
        }
    }

}
