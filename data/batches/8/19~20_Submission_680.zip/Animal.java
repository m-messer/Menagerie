import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.lang.reflect.Constructor;

/**
 * A class representing shared characteristics of Animals.
 *
 * @version 1.1
 */
public abstract class Animal extends Organism
{
    // The animal's sex.
    private boolean isFemale;
    // Randomizer
    private Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field,location);
        isFemale = setIsFemale();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Return sex of animal Object
     * @return true, if female, False if femal
     */
    protected boolean checkIsFemale()
    {
        return isFemale;
    }

    /**
     * Randomly returns true or false, a boolean used again later
     * to assign if 'isFemale' is true or false for each animal
     * @return true or false, randomly. 
     */
    protected boolean setIsFemale()
    {
        return rand.nextInt(2) == 1;
    }

    /**
     * Check if the species of the animals is the same
     * @param  animal, animal to do the comparison with 
     * @return true, If it is the same, false otherwise
     * 
     */
    protected boolean sameSpecies(Object animal)
    {
        if(getClass().equals(animal.getClass())){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Fill animal stomach up by the food value of eaten animal. If stomach value is exceeded set 
     * it to stomach value
     * @param food, The organism eaten
     * @param foodlevel, The food level of the consumer animal
     */
    private void eatFood(Object food, int foodlevel)
    {
        if(food instanceof Organism){
            Organism eaten = (Organism) food; 
            int foodValue = eaten.getFoodValue(); //food value of the organism to be eaten
            if(foodValue + getFoodLevel() >= getStomach()){
                setFoodLevel(getStomach()); //set the food level as the stomach value
            }
            else{
                setFoodLevel(getFoodLevel() + foodValue);
            }
        }
    }    

    /**
     * Move the animal to a new location. If the animal feeds on another organism take the location of that organism on the field
     */
    protected void move()
    {
        Location newLocation = findFood();
        if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Check if the animal is active. To be active an animal should be alive and either nocturnal in night time, diurnal in day time or both
     * @return true, If the animal is active, false otherwise
     */
    protected boolean isActive()
    {
        return isAlive()&& ((Simulator.isDayTime() && this instanceof Diurnal) || (!Simulator.isDayTime() && this instanceof Nocturnal));
    }

    /**
     * Look for food in adjacent locations.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if(getIsInfected()){ //if animal is infected it stops eating
            return null;
        }
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food != null){
                List<Object> foodChoices = getConsumerFood();
                if (foodChoices.contains(food.getClass()) && food instanceof Organism){
                    Organism foodType = (Organism) food;
                    if(foodType.isAlive()) { 
                        foodType.setDead();
                        eatFood(foodType,getFoodLevel());
                        return where;
                    }
                }

            }
        }
        return null;
    }

    /**
     * Makes the animal reproduce. If mating is succesfull the animal will breed
     * @param age, The curretn age of the animal
     * @param breedingAge, The breeding age of the animal
     * @param breedingProb, The breeding probability of an animal
     * @param maxLitter, The maximum litter size an animal can give birth to
     */
    protected void reproduce(List<Animal> newAnimals, int age, int breedingAge,double breedingProb,int maxLitterSize)
    {
        //Check how the animal reproduces
        if(this instanceof SexualReproducing){ 
            //If the animal is not female, it cannot give birth
            if(!canBirth()){    
                return;
            }
        }
        Constructor constructor;
        try{
            constructor = getClass().getConstructor(boolean.class,Field.class,Location.class);
        }
        catch(Exception e){
            return;
        }
        giveBirth(newAnimals,age,breedingAge,breedingProb, maxLitterSize,constructor);
    }

    /**
     * Check weather the animal can give birth
     * return true, If yes, false otherwise
     */
    abstract protected boolean canBirth();

    /**
     * Return the stomach value of the object this is called on.
     * @return an int stomach value.
     */
    abstract protected int getStomach();

    /**
     * returns a list of objects that 
     * the consuming species is able to eat
     */
    private List<Object> getConsumerFood()
    {
        return Simulator.getFoodWeb().get(getClass()); //may return null if it cannot find the consumer
    }

    /**
     * Get the infection propability
     * @param infected, If the animal is infected or not
     */
    abstract protected void setIsInfected(boolean infected);

    /**
     * Return if the animal is infected
     * @return true, If the animal is infected, false otherwise
     */
    abstract public boolean getIsInfected();

    /**
     * Set the age of the animal
     * @param age, The age of the animal
     */
    abstract protected void setAge(int age);

    /**
     * Check if the animal can breed, by checking its breeding age with its actual age.
     * @param age, The current age of the animal
     * @param breedingAge, The breeding age of the animal
     * @return true, if the animal can breed, false otherwise 
     */
    private boolean canBreed(int age, int breedingAge)
    {
        return age >= breedingAge;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @param age, The curretn age of the animal
     * @param breedingAge, The breeding age of the animal
     * @param breedingProb, The breeding probability of an animal
     * @param maxLitter, The maximum litter size an animal can give birth to
     * @return birth, The number of births (may be zero).
     */
    private int breed(int age, int breedingAge, double breedingProb, int maxLitter)
    {
        int births = 0;
        if(canBreed(age,breedingAge) && rand.nextDouble() <= breedingProb) {
            births = rand.nextInt(maxLitter) + 1;
        }
        return births;
    }

    /**
     * Check whether or not this Animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born Sharkes.
     * @param age, The curretn age of the animal
     * @param breedingAge, The breeding age of the animal
     * @param breedingProb, The breeding probability of an animal
     * @param maxLitter, The maximum litter size an animal can give birth to
     * @param constructor, The constructor used to create the new animal object
     */
    protected void giveBirth(List<Animal> newAnimals, int age, int breedingAge, double breedingProb, int maxLitter, Constructor constructor)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(age,breedingAge,breedingProb,maxLitter);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Object young;
            //Check if the method creates any errors
            try{
                young = constructor.newInstance(false,field,loc); //create a new instance using the constructor of the object
            }
            catch(Exception e){
                return;
            }

            if(young instanceof Animal){
                Animal youngAnimal = (Animal) young;
                Infection.infectOffspring(this,youngAnimal);
                newAnimals.add(youngAnimal);
            }
        }
    }

    /**
     * Increase the age. This could result in the Animal's death.
     * @param age, The current age of the animal
     * @param maxAge, The maximum age of the animal
     */
    protected void incrementAge(int age, int maxAge)
    {
        setAge(age++);
        if(age > maxAge) {
            setDead();
        }
    }

    /**
     * Make this Animal more hungry. This could result in the Animal's death.
     * @param foodlevel, The foodlevel of the animal to get more hungry
     */
    protected void incrementHunger(int foodlevel)
    {
        setFoodLevel(foodlevel--);
        if(foodlevel <= 0) {
            setDead();
        }
    }

    /**
     * Return the food level of the animal
     * @return int, The food level of the organism
     */
    abstract protected int getFoodLevel();

    /**
     * Set the Food Level of the particular object
     * @param level, The value to set as foodlevel
     */
    abstract protected void setFoodLevel(int level);
}
