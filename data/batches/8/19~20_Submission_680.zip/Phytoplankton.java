import java.util.List;
import java.util.Random;

/**
 * The model of phyloplankton. The only thing Phytoplankton can do is grow.
 *
 * @version v1.1
 */
public class Phytoplankton extends Plant
{
    //Number of births
    private static final int OFFSPRING = 1;
    //plant food value
    private static final int FOOD_VALUE = 2;
    //Phytoplankton growth probability
    private static final double GROWTH_PROBABILITY = 0.4;
    //Randomiser
    private Random rand = Randomizer.getRandom();

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Phytoplankton(Field field, Location location)
    {       
        super(field,location);
    }

    /**
     * Get FoodValue of the animal, if the plant is to be eaten
     * @return FOOD_VALUE, The value of food the animal is worth when eaten
     */
    public int getFoodValue(){
        return FOOD_VALUE;
    }

    /**
     * The plant grows to nearby locations
     * @param newPlants, The newly added plants.
     */
    public void grow(List<Plant> newPlants)
    {
        if(isAlive()){
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            for(int b = 0; b < OFFSPRING && free.size() > 0 && rand.nextDouble() > GROWTH_PROBABILITY; b++) {
                Location loc = free.remove(0);
                Phytoplankton young = new Phytoplankton(field, loc);
                newPlants.add(young);
            }
        }
    }
}
