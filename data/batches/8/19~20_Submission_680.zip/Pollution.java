import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Creates the pollution objects on the grid. Pollution kills every organism it finds.
 *
 * @version 1.1
 */
public class Pollution extends Element
{
    // Randomizer
    private Random rand = Randomizer.getRandom();
    // Spreading probability of pollution
    private static final double SPREAD_PROB = 1;

    /**
     * Constructor for objects of class pollution
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Pollution(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * Let pollution spread to nearby locations.
     * @param newPollutionDots, The list of all pollution objects
     */
    public void spread(List<Pollution> newPollutionDot)
    {
        Field field = getField();
        if(rand.nextDouble() < SPREAD_PROB){
            Location newLocation = killOrganism();
            if(newLocation == null && field.freeAdjacentLocation(getLocation()) == null){
                return;
            }
            else{
                newLocation = field.freeAdjacentLocation(getLocation());
            }
            Pollution dot = new Pollution(field,newLocation);
            newPollutionDot.add(dot);
        }
    }

    /**
     * Look for organisms to kill in adjacent locations.
     * Only the first living organism is killed
     * @return Where the organism was killed, or null if it wasn't.
     */
    private Location killOrganism()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food != null){
                if(food instanceof Organism){
                    Organism foodType = (Organism) food;
                        foodType.setDead();
                }
            }
            return null; //spread less evenly
        }
        return null;
    }

}
