import java.util.List;
import java.util.ArrayList;

/**
 * A model of a plant. Plants grow on adjacent locations, get eaten and thus can die.
 *
 * @version v1.1
 */
public abstract class Plant extends Organism
{
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field,location);
        setLocation(location);
    }

    /**
     * Let the plant spread to nearby locations.
     * @param newPlant, The new plant objects created 
     */
    abstract public void grow(List<Plant> newPlant);

}
