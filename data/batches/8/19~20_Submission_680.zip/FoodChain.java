import java.util.ArrayList;
import java.util.List;

/**
 * FoodChains will be instansiated containing a single predator and its prey as
 * an list
 *
 * @version 1.1
 */
public class FoodChain
{
    private Object consumerType;
    private List<Object> foodType;

    /**
     * Constructor for objects of class FoodChain
     * Create the FoodChain instances
     */
    public FoodChain(Object consumer)
    {
        this.consumerType = consumer;
        foodType = new ArrayList<>(); //maybe do this in the same line
    }

    /**
     * Add food to a specific consumer
     * @param  Class preyType, type of prey the predator eats
     */
    public void addFood(Object type)
    {
        foodType.add(type);
    }

    /**
     * Return the list of food of a certain foodchain
     * @return foodType, The list of food types the predator feeds on
     */
    public List<Object> getFood()
    {
        return foodType;
    }

    /**
     * Return the consumer of a foodchain
     * @return consumerType, The type of predator in a foodchain;
     */
    public Object getConsumer()
    {
        return consumerType;
    }
}
