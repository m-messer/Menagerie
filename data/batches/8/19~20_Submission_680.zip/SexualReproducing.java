import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class of representing shared charactersistics of Sexually Reproducing animal. Sexually reproducing animals must mate first to give birth.
 * What is more, they can get infected and as a result stop eating
 *
 * @version 1.1
 */
public abstract class SexualReproducing extends Animal
{
    // If the organism is infected
    protected boolean isInfected;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor of the Sexually Reproducing animals
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public SexualReproducing(Field field, Location location)
    {
        super(field, location);
        isInfected = false;
    }

    /**
     * Check if the animals can mate (they have to be of 
     * the same species and opposite gender)
     * @return true, if they can mate false, otherwise
     */
    protected boolean canBirth()
    {
        boolean canMate = false;
        if(checkIsFemale()){ //check if the current animal object is female
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext() && !canMate) {   
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal != null && sameSpecies(animal)) { //check for null
                    Animal mate = (Animal) animal; 
                    if(!mate.checkIsFemale()){ //check if the partner is of opposite sex
                        canMate = true;
                        if(mate.getIsInfected() && getIsInfected()){ //both animals get infected if at least one of them is infected
                            setIsInfected(true);
                            mate.setIsInfected(true);
                        }
                    }
                }
            }
        }
        return canMate;
    }

    /**
     * Return if the animal is infected
     * @return true, If the animal is infected, false otherwise
     */
    protected void setIsInfected(boolean infected){
        isInfected = infected;
    }

    /**
     * Return if the animal is infected
     * @return true, If the animal is infected, false otherwise
     */
    @Override
    public boolean getIsInfected(){
        return isInfected;
    }
}

