import java.util.List;
import java.util.Random;

/**
 * A simple model of a Turtle.
 * Turtles age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Turtle extends SexualReproducing implements Nocturnal, Infection
{
    // The age at which a Turtle can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Turtle can live.
    private static final int MAX_AGE = 101;
    // The likelihood of a Turtle breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single rabbit. In effect, this is the
    private static final int FISH_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //Animal food value
    private static final int FOOD_VALUE = 15;
    // Animal stomach capacity
    private static final int STOMACH_VALUE = 200;
    // The Turtle's age.
    private int age;
    // The Turtle's food level. This is increased based on what the animal eats. Food level decreases with every movement of the animal
    private int foodLevel;

    /**
     * Create a Turtle. A Turtle can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Turtle will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Turtle(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(STOMACH_VALUE);
        }
        else {
            age = 0;
            foodLevel = STOMACH_VALUE;
        }
    }

    /**
     * Get FoodValue of the animal, if the animal is prey
     * @return int FOOD_VALUE, the value of food the animal is worth when eaten
     */
    @Override
    public int getFoodValue(){
        return FOOD_VALUE;
    }

    /**
     * Get the food value of the organism
     * @return int, the value of food the organism is worth when eaten
     */
    @Override
    public int getStomach(){
        return STOMACH_VALUE;
    }

    /**
     * Set the Food Level of the particular object
     * @param level, The value to set as foodlevel
     */
    @Override
    protected void setFoodLevel(int level)
    {
        foodLevel = level;
    }

    /**
     * The animal looks for a new location to move, feed, and reproduce. In the process its age and hunger are increased.
     * @param newAnimals A list to return newly born animals.
     */
    @Override
    public void act(List<Animal> newAnimals)
    {
        incrementAge(age,MAX_AGE);
        if(isActive()){
            incrementHunger(foodLevel); 
            if(!isAlive()){
                return;
            }
            reproduce(newAnimals,age, BREEDING_AGE, BREEDING_PROBABILITY,MAX_LITTER_SIZE);
            move();
        }
    }

    /**
     * Set the age of the animal
     * @param age, The age of the animal
     */
    @Override
    protected void setAge(int age){
        this.age = age;
    }

    /**
     * Return the food level of the animal
     * @return foodLevel, The food level of the organism
     */
    @Override
    protected int getFoodLevel()
    {
        return foodLevel;
    }
}
