import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;

/**
 * A simple simulator, based on a rectangular field
 * containing Sharks, Clownfish, Jellyfish, Sardines, Turtles  and plants such as Seaweed and Phytoplankton.
 *
 * @version 2016.02.29 (3)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.04;
    // The probability that a jellyfish will be created in any given grid position.
    private static final double JELLYFISH_CREATION_PROBABILITY = 0.06; 
    // The probability that a sardine will be created in any given grid position.
    private static final double SARDINE_CREATION_PROBABILITY = 0.9;
    // The probability that a turtle will be created in any given grid position.
    private static final double TURTLE_CREATION_PROBABILITY = 0.1;
    // The probability that a plant will be created in any given grid position.
    private static final double SEAWEED_CREATION_PROBABILITY = 0.0003;
    // The probability that a plant will be created in any given grid position.
    private static final double PHYTOPLANKTON_CREATION_PROBABILITY = 0.005;
    // The probability that a clownfish will grow the current step
    private static final double CLOWNFISH_CREATION_PROBABILITY = 0.1;

    // List of animals in the field.
    private List<Animal> animals;

    //FoodChain creations
    private FoodChain sharkChain, sardineChain, turtleChain, jellyChain,clownChain;
    // The simulator's FoodWeb
    private static HashMap<Object,List<Object>> foodweb;

    // List of plants in the field
    private List<Plant> plants;

    // List of pollution dots on the field
    private List<Pollution> pollutionDots;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private static int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    //Pause button used to stop the simulation
    public static boolean pause = false;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH); //other constructor is still called

    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {

        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        pollutionDots = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width,this);
        view.setColor(Jellyfish.class, Color.PINK);
        view.setColor(Shark.class, Color.WHITE);
        view.setColor(Sardine.class, Color.GRAY);
        view.setColor(Turtle.class,Color.YELLOW);
        view.setColor(Seaweed.class,Color.GREEN);
        view.setColor(Clownfish.class,Color.ORANGE);
        view.setColor(Phytoplankton.class, new Color(0,140, 20));
        view.setColor(Pollution.class,Color.BLACK);

        view.createKey();
        //hard coded water key as unable to somehow get list of all classes
        view.createWaterKey();

        // Setup a valid starting point.
        reset();
        createFoodWeb();
    }

    /**
     * Create foodchains and put them in 
     * the foodweb.
     */
    private void createFoodWeb()
    {
        //FoodChain of Sharks
        sharkChain = new FoodChain(Shark.class);
        sharkChain.addFood(Turtle.class);
        sharkChain.addFood(Jellyfish.class);
        sharkChain.addFood(Sardine.class);
        sharkChain.addFood(Clownfish.class);

        //FoodChain of sardines 
        sardineChain = new FoodChain(Sardine.class);
        sardineChain.addFood(Seaweed.class);
        sardineChain.addFood(Phytoplankton.class);

        //FoodChain of turtles
        turtleChain = new FoodChain(Turtle.class);
        turtleChain.addFood(Jellyfish.class);
        turtleChain.addFood(Sardine.class);
        turtleChain.addFood(Seaweed.class);
        turtleChain.addFood(Phytoplankton.class);
        turtleChain.addFood(Clownfish.class);

        //FoodChain of jellyfish
        jellyChain = new FoodChain(Jellyfish.class);
        jellyChain.addFood(Sardine.class);
        jellyChain.addFood(Phytoplankton.class);

        //FoodChain of clownfish
        clownChain = new FoodChain(Clownfish.class);
        clownChain.addFood(Seaweed.class);
        clownChain.addFood(Phytoplankton.class);

        //Add the FoodChains in the FoodWeb
        foodweb = new HashMap<>();

        foodweb.put(sharkChain.getConsumer(),sharkChain.getFood());
        foodweb.put(sardineChain.getConsumer(),sardineChain.getFood());
        foodweb.put(turtleChain.getConsumer(),turtleChain.getFood());
        foodweb.put(jellyChain.getConsumer(),jellyChain.getFood());
        foodweb.put(clownChain.getConsumer(),clownChain.getFood());
    }

    /**
     * @return a hashMap containing objects as keys and
     * a list of objects as values.
     */
    public static HashMap<Object,List<Object>> getFoodWeb()
    {
        return foodweb;
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            if(!pause){
                simulateOneStep();
                //delay(100);
            }else{
                step--;
            }
            // change value or delete to alter delay or remove it
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep()
    {
        step++; //increment step counter

        spreadPollution();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);

            if(!animal.isAlive()) {
                it.remove();
            }

        }

        // Add the newly animal to the main lists.
        animals.addAll(newAnimals);
        
        if(isDayTime()){
            growOneStep(); //let plants grow
        }

        view.showStatus(step, field);
    }

    /**
     * Make every plant spread or grow once.
     */
    public void growOneStep()
    {
        //Newly created plants
        List<Plant> newPlants = new ArrayList<>();
        //Let all plants grow
        Iterator<Plant> it = plants.iterator();
        while( it.hasNext()){
            Plant plant = it.next();
            plant.grow(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        plants.addAll(newPlants);
        view.showStatus(step, field);
    }

    /**
     * Spread pollution on the field.
     */
    public void spreadPollution()
    {
        List<Pollution> newPollutionDots = new ArrayList<>();

        Iterator<Pollution> it = pollutionDots.iterator();
        while( it.hasNext()){
            Pollution dot = it.next();
            dot.spread(newPollutionDots);
        }
        pollutionDots.addAll(newPollutionDots);
        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        pollutionDots.clear();
        populatePlants();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with only animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SARDINE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Sardine sardine = new Sardine(true, field, location);
                    animals.add(sardine);
                }
                else if(rand.nextDouble() <= CLOWNFISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Clownfish fish = new Clownfish(true, field, location);
                    animals.add(fish);
                }
                else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= JELLYFISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Jellyfish jellyfish = new Jellyfish(true, field, location);
                    animals.add(jellyfish);
                }
                else if(rand.nextDouble() <= TURTLE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Turtle turtle = new Turtle(true, field, location);
                    animals.add(turtle);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Let plants spread for a given number of steps 
     * (needs to be parametrized but testing for now)
     */
    private void populatePlants()
    {
        Random rand = Randomizer.getRandom();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seaweed plant = new Seaweed(field, location);
                    plants.add(plant);
                    // else leave the location empty.
                }
                else if(rand.nextDouble() <= PHYTOPLANKTON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Phytoplankton plant = new Phytoplankton(field, location);
                    plants.add(plant);
                    // else leave the location empty.
                }
            }
        }
        for(int i =0; i <= 10; i++){
            growOneStep();
        }
    }

    /**
     * Introduce pollution
     */
    public void introPollution()
    {
        Random rand = Randomizer.getRandom();
        boolean placed = false;

        for(int row = 0; row < field.getDepth() && !placed; row++) {
            for(int col = 0; col < field.getWidth() && !placed; col++) {
                Location where = new Location(row,col);
                Object obj = field.getObjectAt(where);
                if(obj == null){
                    Pollution dot = new Pollution(field, where);
                    pollutionDots.add(dot);
                    placed = true;
                }

            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Return string daytime or nightime
     * @return String specifying time of day
     */
    public static String getStringTime()
    {
        if(isDayTime()){
            return "DAY-TIME";
        }
        else{
            return "NIGHT-TIME";   
        }
    }

    /**
     * Return if it is "Day-Time" or "Night-Time"
     * return True, If Day-Time, false otherwise.
     */
    public static boolean isDayTime()
    {
        return (step / 100) % 2 == 0;
    }

    /**
     * Introduce Infection in the population.
     * Infect the animals that can be infected
     * This method is called using a button
     */
    public void introInfection()
    {
        Random rand = Randomizer.getRandom();
        Iterator<Animal> it = animals.iterator();
        while (it.hasNext()){
            Animal animal = it.next();
            if(animal instanceof Infection && animal instanceof SexualReproducing){
                if(rand.nextDouble() >= Infection.getInfectionProb()){
                    animal.setIsInfected(true);
                }
            }
        }
    }
}
