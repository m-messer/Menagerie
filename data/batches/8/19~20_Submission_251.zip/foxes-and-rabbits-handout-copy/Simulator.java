    import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    private static final int DEFAULT_LANDWIDTH = 80;
    private static final int DEFAULT_WATERWIDTH = 40;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.02;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.04;    
    private static final double FISH_CREATION_PROBABILITY = 0.06;  
    private static final double WOLF_CREATION_PROBABILITY = 0.08; 
    private static final double OTTER_CREATION_PROBABILITY = 0.10;  
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    private int dayornight=0;  //0-day, 1-night
    private int rain=0;  //0-no rain, 1-rain
    private static final double RAIN_PROBABILITY = 0.10;  

    private int disease=0;  //0-no disease, 1-disease
    private static final double DISEASE_PROBABILITY = 0.10;  
    
    public static void main(String args[]){ 
           new Simulator();         
    }                           

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_LANDWIDTH,DEFAULT_WATERWIDTH );
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int landWidth, int waterWidth)
    {
        if(landWidth <= 0 || waterWidth <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            landWidth = DEFAULT_LANDWIDTH;
            waterWidth = DEFAULT_WATERWIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, landWidth, waterWidth);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, landWidth+ waterWidth );
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Fish.class, Color.GREEN);
        view.setColor(Otter.class, Color.RED);
        view.setColor(Wolf.class, Color.YELLOW);
        
        // Setup a valid starting point.
        reset();
        runLongSimulation();   
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
		
            if(step%10==0) {
                 if(dayornight==1) dayornight=0;
                 else dayornight=1;
            }
		rain=0;
		Random rand = Randomizer.getRandom();
             if(rand.nextDouble()<=RAIN_PROBABILITY)
		   rain=1;
            	disease=0;
             if(rand.nextDouble()<=DISEASE_PROBABILITY)
		   disease=1;


		simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals,dayornight,rain,disease);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getLandWidth(); col++) { //put animals on land
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,0);
			int sex=0;
			Random sexrand = Randomizer.getRandom();
			if(sexrand.nextDouble()<=0.5)
				sex=1;
                    Fox fox = new Fox(true, sex,field, location);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,0);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,0);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }

                // else leave the location empty.
            }
                  for(int col = field.getLandWidth()+1; col < field.getWidth(); col++) { //put animals in water
                if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,1);
                    Fish fish= new Fish(true, field, location);
                    animals.add(fish);
                }
                else if(rand.nextDouble() <= OTTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,1);
                    Otter otter = new Otter(true, field, location);
                    animals.add(otter);
                }

            }

        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
