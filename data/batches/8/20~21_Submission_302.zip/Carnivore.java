import java.util.Iterator;
import java.util.List;

/**
 * A carnivore is a kind of {@link Animal} that also has a food level. It needs
 * to feed on {@link Herbivore Herbivores} to survive and eventually breed.
 *
 * @version 2020.02.09
 *
 */
public abstract class Carnivore extends Animal {

	/**
	 * Create a new carnivore at the given {@link Location} in the {@link World}.
	 * 
	 * @param world    The world currently occupied.
	 * @param location The location within the world.
	 */
	public Carnivore(World world, Location location) {
		super(world, location);
	}

	/**
	 * Look for food adjacent to the current location. Only the first live animal is
	 * eaten.
	 * 
	 * @return Where food was found, or null if it wasn't.
	 */
	protected Location findFood() {
		if (foodLevel > getTargetFoodLevel())
			return null;

		Field field = world.getAboveGround();
		List<Location> adjacent = field.adjacentLocations(getLocation());
		Iterator<Location> it = adjacent.iterator();
		while (it.hasNext()) {
			Location where = it.next();
			Species animal = field.getObjectAt(where);
			if (animal instanceof Herbivore) {
				Herbivore herbivore = (Herbivore) animal;
				if (herbivore.isAlive()) {
					herbivore.setDead();
					foodLevel += herbivore.getFoodValue();
					return where;
				}
			}
		}
		return null;
	}

	/**
	 * This is what a basic carnivore does most of the time: it moves around and
	 * hunts for animals. In the process, it might breed, die of hunger, or die of
	 * old age.
	 * 
	 * @param field         The field currently occupied.
	 * @param newCarnivores A list to return newly born animals.
	 */
	@Override
	public void act(List<Species> newCarnivores) {
		if (!isAwake())
			return;

		incrementAge();
		incrementHunger();
		if (isAlive()) {
			spreadDisease();
			giveBirth(newCarnivores);
			// Move towards a source of food if found.
			Location newLocation = findFood();
			if (newLocation == null) {
				// No food found - try to move to a free location.
				newLocation = world.getAboveGround().freeAdjacentLocation(getLocation());
			}

			if (newLocation != null) {
				setLocation(newLocation);
			} else {
				// Overcrowding.
				setDead();
			}
		}
	}

}
