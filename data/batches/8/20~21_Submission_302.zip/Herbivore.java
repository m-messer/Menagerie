import java.util.Iterator;
import java.util.List;

/**
 * A herbivore is a kind of {@link Animal} that can be eaten, and that can eat
 * plants.
 *
 * @version 2020.02.09
 *
 */
public abstract class Herbivore extends Animal {

	/**
	 * Create a new herbivore at the given {@link Location} in the {@link World}.
	 * 
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Herbivore(World world, Location location) {
		super(world, location);
	}

	/**
	 * @return The food value obtained by an animal that eats this.
	 */
	public abstract int getFoodValue();

	/**
	 * Look for food adjacent to the current location. Only the first plant is
	 * eaten.
	 * 
	 * @return Where food was found, or null if it wasn't.
	 */
	protected Location findFood() {
		if (foodLevel > getTargetFoodLevel())
			return null;

		Field field = world.getFloor();
		List<Location> adjacent = field.adjacentLocations(getLocation());
		Iterator<Location> it = adjacent.iterator();
		while (it.hasNext()) {
			Location where = it.next();
			Species species = field.getObjectAt(where);
			if (species instanceof Plant) {
				Plant plant = (Plant) species;
				if (plant.isAlive()) {
					plant.setDead();
					foodLevel += plant.getFoodValue();
					return where;
				}
			}
		}
		return null;
	}

	/**
	 * This is what a basic herbivore does most of the time - it walks around and
	 * eats plants. Sometimes it will breed or die of old age.
	 * 
	 * @param newSpecies A list to return newly born herbivores.
	 */
	@Override
	public void act(List<Species> newSpecies) {
		if (!isAwake())
			return;

		incrementAge();
		incrementHunger();
		if (isAlive()) {
			spreadDisease();
			giveBirth(newSpecies);
			// Try to move into a free location.
			Location newLocation = findFood();
			if (newLocation == null)
				newLocation = world.getAboveGround().freeAdjacentLocation(getLocation());

			if (newLocation != null) {
				setLocation(newLocation);
			} else {
				// Overcrowding.
				setDead();
			}
		}
	}

}
