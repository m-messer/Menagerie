import static java.lang.Math.round;
import static java.lang.Math.sqrt;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A World represents the environment in which the simulation's {@link Species}
 * evolve. It is composed of two different levels, a floor and an aboveground,
 * that can be retrieved with their respective methods.
 *
 * @version 2020.23.02
 * @see Field
 * @see Weather
 *
 */
public class World {

	/** Odds of a thunderstrike happening each hour, when it's thundering. */
	private static final float THUNDERSTIKE_ODDS = 0.4f;
	/** The minimum size of a thunderstrike. */
	private static final int MIN_THUNDERSTRIKE_RADIUS = 5;
	/** The max size of a thunderstrike. */
	private static final int MAX_THUNDERSTRIKE_RADIUS = 12;

	/** Random object used. */
	private static final Random rand = Randomizer.getRandom();

	/** The world's floor level. */
	private final Field floor;
	/** The world's above ground level. */
	private final Field aboveGround;
	/** The current weather in this world. */
	private Weather weather;
	/** The current time since the creation of the world. */
	private int time;
	/** The locations where thunder hit last time. */
	private final List<Location> thunderLocations;

	/**
	 * Will create a new world with the given dimensions. By default, the
	 * {@link Weather} is cloudy.
	 * 
	 * @param width The world's width - it's size on the X axis.
	 * @param depth The world's depth - it's size on the Y axis.
	 */
	public World(int width, int depth) {
		floor = new Field(width, depth);
		aboveGround = new Field(width, depth);
		time = 0;
		weather = Weather.CLOUDY;
		thunderLocations = new ArrayList<>();
	}

	/**
	 * @return The world's width - it's size on the X axis.
	 */
	public int getWidth() {
		return floor.getWidth();
	}

	/**
	 * @return The world's depth - it's size on the Y axis.
	 */
	public int getDepth() {
		return floor.getDepth();
	}

	/**
	 * @return Will return the Field for this world's floor, where most plants are.
	 */
	public Field getFloor() {
		return floor;
	}

	/**
	 * @return Will return the Field for this world's above ground, where most
	 *         animals are.
	 */
	public Field getAboveGround() {
		return aboveGround;
	}

	/**
	 * @return The world's current weather.
	 */
	public Weather getWeather() {
		return weather;
	}

	/**
	 * Will clear the world, removing everything from its fields.
	 */
	public void clear() {
		floor.clear();
		aboveGround.clear();
	}

	/**
	 * Will increment by one hour the time in this world. If a day passes, will
	 * randomly change the weather. If it's thundering, might randomly create
	 * thunder.
	 */
	public void incrementTime() {
		int prevDay = getDay();
		this.time++;
		if (getDay() != prevDay) { // new day
			float value = rand.nextFloat();
			float x = 0;
			for (Weather w : Weather.values()) {
				x += w.getOdds();
				if (value < x) {
					weather = w;
					break;
				}
			}
		}

		else if (weather == Weather.THUNDER && rand.nextFloat() < THUNDERSTIKE_ODDS) {
			doThunderstrike();
		}
	}

	/**
	 * Will randomly create a thunderstrike in the world.
	 */
	private void doThunderstrike() {
		int thunderstrikeX = rand.nextInt(floor.getWidth());
		int thunderstrikeY = rand.nextInt(floor.getDepth());
		int thunderstrikeSize = MIN_THUNDERSTRIKE_RADIUS
				+ rand.nextInt(MAX_THUNDERSTRIKE_RADIUS - MIN_THUNDERSTRIKE_RADIUS);

		for (int offX = -thunderstrikeSize; offX <= thunderstrikeSize; offX++) {
			int posX = thunderstrikeX + offX;
			if (posX < 0 || posX >= floor.getWidth())
				continue;

			for (int offY = -thunderstrikeSize; offY <= thunderstrikeSize; offY++) {
				int posY = thunderstrikeY + offY;
				if (posY < 0 || posY >= floor.getDepth())
					continue;

				float dist = round(sqrt((posX - thunderstrikeX) * (posX - thunderstrikeX)
						+ (posY - thunderstrikeY) * (posY - thunderstrikeY)));
				if (dist > thunderstrikeSize)
					continue;

				Location loc = new Location(posX, posY);

				Species s;
				if ((s = floor.getObjectAt(loc)) != null)
					s.setDead();
				if ((s = aboveGround.getObjectAt(loc)) != null)
					s.setDead();

				thunderLocations.add(loc);
			}
		}
	}

	/**
	 * @return The hour of day.
	 */
	public int getHour() {
		return time % 24;
	}

	/**
	 * @return The day number, since the start of simulation.
	 */
	public int getDay() {
		return time / 24 + 1;
	}

	/**
	 * @return A string with the current time formatted in a user-friendly way.
	 */
	public String getFormattedTime() {
		return "Day " + getDay() + ", " + (((getHour() + 11) % 12) + 1) + (getHour() < 12 ? "AM" : "PM");
	}

	/**
	 * @return All locations that were struck by thunder in the last world tick.
	 *         Accessing this method will empty the list.
	 */
	public List<Location> getThunderLocations() {
		List<Location> copy = List.copyOf(thunderLocations);
		thunderLocations.clear();
		return copy;
	}

}
