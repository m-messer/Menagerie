import java.awt.Color;

/**
 * A simple model of a dire wolf. Dire wolves age, move, eat {@link Herbivore
 * Herbivores}, and die.
 *
 * @version 2021.02.09
 * @see Carnivore
 */
public class DireWolf extends Carnivore {
	/** The dire wolf's color. */
	public static final Color COLOR = new Color(0x85b8d6);
	/** The age at which a dire wolf can start to breed. */
	private static final int BREEDING_AGE = 7;
	/** The age to which a dire wolf can live. */
	private static final int MAX_AGE = 26;
	/** The likelihood of a dire wolf breeding. */
	private static final double BREEDING_PROBABILITY = 0.81;
	/** The maximum number of births. */
	private static final int MAX_LITTER_SIZE = 3;
	/** The value to reach before the dire wolf stops hunting for a bit. */
	private static final int TARGET_FOOD_LEVEL = 13;

	/**
	 * Create a dire wolf. A dire wolf can be created as a new born (age zero and
	 * not hungry) or with a random age and food level.
	 * 
	 * @param randomAge If true, the dire wolf will have random age and hunger
	 *                  level.
	 * @param world     The {@link World} currently occupied.
	 * @param location  The {@link Location} within the world.
	 */
	public DireWolf(boolean randomAge, World world, Location location) {
		super(world, location);
		if (randomAge) {
			age = rand.nextInt(MAX_AGE);
			foodLevel = rand.nextInt(10);
		} else {
			age = 0;
			foodLevel = 2;
		}
	}

	@Override
	protected Animal makeBaby(World world, Location location) {
		return new DireWolf(false, world, location);
	}

	@Override
	public int getBreedingAge() {
		return BREEDING_AGE;
	}

	@Override
	public double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	@Override
	public int getMaxAge() {
		return MAX_AGE;
	}

	@Override
	public int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	@Override
	public boolean isActiveTime(int hour) {
		return hour <= 9 || hour >= 17;
	}

	@Override
	public Color getColor() {
		return COLOR;
	}

	@Override
	public int getTargetFoodLevel() {
		return TARGET_FOOD_LEVEL;
	}
}
