import java.awt.Color;

/**
 * A simple model of reindeer. Reindeer age, eat plants, move, breed, and die.
 *
 * @version 2020.02.09
 * @see Herbivore
 */
public class Reindeer extends Herbivore {
	/** The reindeer's color. */
	public static final Color COLOR = new Color(0xa11708);
	/** The age at which a reindeer can start to breed. */
	private static final int BREEDING_AGE = 10;
	/** The age to which a reindeer can live. */
	private static final int MAX_AGE = 39;
	/** The likelihood of a reindeer breeding. */
	private static final double BREEDING_PROBABILITY = 0.15;
	/** The maximum number of births. */
	private static final int MAX_LITTER_SIZE = 3;
	/**
	 * The food value of a single reindeer. In effect, this is the number of steps a
	 * carnivore can go before it has to eat again.
	 */
	private static final int FOOD_VALUE = 20;
	/** The food level after which the reindeer will stop looking for food. */
	private static final int TARGET_FOOD_LEVEL = 16;

	/**
	 * Create a new reindeer. A reindeer may be created with age zero (a new born)
	 * or with a random age.
	 * 
	 * @param randomAge If true, the reindeer will have a random age.
	 * @param world     The {@link World} currently occupied.
	 * @param location  The {@link Location} within the world.
	 */
	public Reindeer(boolean randomAge, World world, Location location) {
		super(world, location);
		foodLevel = 3;
		if (randomAge) {
			age = rand.nextInt(MAX_AGE);
			foodLevel += 5 + rand.nextInt(TARGET_FOOD_LEVEL);
		}
	}

	@Override
	protected Animal makeBaby(World world, Location location) {
		return new Reindeer(false, world, location);
	}

	@Override
	public int getBreedingAge() {
		return BREEDING_AGE;
	}

	@Override
	public double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	@Override
	public int getMaxAge() {
		return MAX_AGE;
	}

	@Override
	public int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	@Override
	public int getFoodValue() {
		return FOOD_VALUE;
	}

	@Override
	public boolean isActiveTime(int hour) {
		return hour >= 8 && hour <= 21;
	}

	@Override
	public Color getColor() {
		return COLOR;
	}

	@Override
	public int getTargetFoodLevel() {
		return TARGET_FOOD_LEVEL;
	}
}
