import java.util.List;

/**
 * A class representing shared characteristics of animals. This class extends
 * Species, and contains methods to indicate the properties of this animal, as
 * well as some methods that it may need to reproduce.
 *
 * @version 2021.02.09
 * @see Species
 */
public abstract class Animal extends Species {

	/** The chance of an animal becoming sick upon creation */
	private static final float DISEASE_GENERATION_CHANCE = 0.0002f;
	/** The chance of an animal becoming immune to a disease it's carrying */
	private static final float IMMUNITY_CHANCE = 0.03f;
	/**
	 * The amount of steps removed from a species' lifespan whey they get the
	 * disease.
	 */
	private static final int DISEASE_IMPACT = 10;
	/**
	 * The odds an immune individual has of passing a "good" immunity to its
	 * children
	 */
	private static final float IMMUNITY_PASS_ODDS = 0.6f;

	/** This animal's age */
	protected int age;
	/** The animal's sex(female or male) */
	protected boolean isFemale;
	/** This animal's food level. At a food level of 0, it dies. */
	protected int foodLevel;
	/** The animal's disease state. */
	protected DiseaseState diseaseState;

	/**
	 * Create a new animal at the given {@link Location} in the {@link World}.
	 * 
	 * @param world    The world currently occupied.
	 * @param location The location within the world.
	 */
	public Animal(World world, Location location) {
		super(world, location);
		isFemale = rand.nextBoolean();
		diseaseState = DiseaseState.HEALTHY;
		if (rand.nextFloat() <= DISEASE_GENERATION_CHANCE)
			diseaseState = DiseaseState.SICK;
	}

	/**
	 * Method used to easily instantiate new types of this particular Animal.
	 * 
	 * @param world    The {@link World} the baby will appear in.
	 * @param location The {@link Location} within the world.
	 * @return A new Animal instance of the same type as the one this was called on.
	 */
	protected abstract Animal makeBaby(World world, Location location);

	/**
	 * Increase the age. This could result in the animal's death. Sick animals age
	 * double the amount as healthy animals. Sick animals have a chance of becoming
	 * immune.
	 * 
	 * @see #getMaxAge()
	 * @see #getDiseaseState()
	 */
	protected void incrementAge() {
		age++;
		if (diseaseState == DiseaseState.SICK) {
			if (rand.nextFloat() < IMMUNITY_CHANCE)
				diseaseState = DiseaseState.IMMUNE_NATURALLY;
			else
				age += DISEASE_IMPACT;
		}

		if (age > getMaxAge())
			setDead();
	}

	/**
	 * Make this animal more hungry. This could result in its death.
	 */
	protected void incrementHunger() {
		foodLevel--;
		if (foodLevel <= 0) {
			setDead();
		}
	}

	/**
	 * @return The minimum age (in steps lived) before this animal can start
	 *         breeding.
	 * @see #getBreedingProbability()
	 * @see #getMaxLitterSize()
	 */
	public abstract int getBreedingAge();

	/**
	 * @return The max age this animal can live before it dies.
	 */
	public abstract int getMaxAge();

	/**
	 * @return The probability in the range [0;1] this animal has of breeding, when
	 *         all other conditions are met.
	 */
	public abstract double getBreedingProbability();

	/**
	 * @return The max litter size this animal can produce.
	 */
	public abstract int getMaxLitterSize();

	/**
	 * @return The food level this animal will try to reach. If it's food level is
	 *         above this, it won't try eating anything.
	 */
	public abstract int getTargetFoodLevel();

	/**
	 * @return The {@link DiseaseState state} this animal is in regarding diseases.
	 */
	public DiseaseState getDiseaseState() {
		return diseaseState;
	}

	/**
	 * Check whether or not this animal is to give birth at this step. New births
	 * will be made into free adjacent locations.
	 * 
	 * @param newAnimals A list to return newly born animals.
	 * @see #canBreed()
	 * @see #breed()
	 * @see #makeBaby(World, Location)
	 */
	protected void giveBirth(List<Species> newAnimals) {
		// New animals are born into adjacent locations.
		// Get a list of adjacent free locations.
		List<Location> free = world.getAboveGround().getFreeAdjacentLocations(getLocation());
		int births = breed();
		for (int b = 0; b < births && free.size() > 0; b++) {
			Location loc = free.remove(0);
			Animal young = makeBaby(world, loc);
			if (diseaseState == DiseaseState.IMMUNE_NATURALLY)
				young.diseaseState = 
					rand.nextFloat() < IMMUNITY_PASS_ODDS ? 
						DiseaseState.IMMUNE_NATURALLY :
						DiseaseState.IMMUNE_HEREDITARY;
			newAnimals.add(young);
		}
	}

	/**
	 * Generate a number representing the number of births, if it can breed.
	 * 
	 * @return The number of births (may be zero).
	 * @see #canBreed()
	 * @see #getBreedingProbability()
	 * @see #getMaxLitterSize()
	 */
	protected int breed() {
		int births = 0;
		if (rand.nextDouble() <= getBreedingProbability() && canBreed()) {
			births = rand.nextInt(getMaxLitterSize()) + 1;
		}
		return births;
	}

	/**
	 * Checks if this animal can breed. An animal is able to breed if:
	 * <ul>
	 * <li>It is female</li>
	 * <li>It has reached its {@link #getBreedingAge() breeding age}</li>
	 * <li>There is a male of the same species in an adjacent location</li>
	 * </ul>
	 * 
	 * @return If this animal can breed.
	 */
	protected boolean canBreed() {
		if (isFemale && age >= getBreedingAge())
			for (Animal a : world.getAboveGround().adjacentAnimals(getClass(), location))
				if (!a.isFemale && a.age >= a.getBreedingAge() && a.getClass().equals(getClass()))
					return true;
		return false;
	}

	/**
	 * Checks whether an animal will spread its disease if it is sick. All adjacent
	 * animals of the same species of the carrier will become sick if the carrier is
	 * sick.
	 */
	protected void spreadDisease() {
		if (diseaseState == DiseaseState.SICK) {
			for (Animal a : world.getAboveGround().adjacentAnimals(getClass(), location)) {
				if (a.diseaseState == DiseaseState.HEALTHY && a.getClass().equals(this.getClass())) {
					a.diseaseState = DiseaseState.SICK;
				}
			}
		}
	}
}
