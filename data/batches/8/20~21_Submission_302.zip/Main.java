/**
 * The Main class, that setups the initial simulator and makes it run at 60
 * steps per second.
 *
 * @version 2020.02.09
 */
public class Main {

	/**
	 * The main method, that will continuously run a simulation, incrementing it by
	 * one step every 100ms.
	 * 
	 * @param args The arguments. Unused.
	 */
	public static void main(String[] args) {
		Simulator simulator = new Simulator(250, 250);

		while (true) {
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			simulator.simulateOneStep();
		}
	}

}
