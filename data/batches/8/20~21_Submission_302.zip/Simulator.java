import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field containing
 * animals.
 *
 * @version 2020.02.28
 * @see SimulatorView
 * @see World
 */
public class Simulator {
	/** The default width for the grid. */
	private static final int DEFAULT_WIDTH = 120;
	/** The default depth of the grid. */
	private static final int DEFAULT_DEPTH = 80;
	/** The probability that a dire wolf will be created in any given grid position. */
	private static final double DIRE_WOLF_CREATION_PROBABILITY = 0.012;
	/** The probability that a mammoth will be created in any given grid position. */
	private static final double SMILODON_CREATION_PROBABILITY = 0.012;
	/** The probability that a dire wolf will be created in any given grid position. */
	private static final double REINDEER_CREATION_PROBABILITY = 0.16;
	/** The probability that a mammoth will be created in any given grid position. */
	private static final double MAMMOTH_CREATION_PROBABILITY = 0.16;
	/** The probability that a dire wolf will be created in any given grid position. */
	private static final double RHINO_CREATION_PROBABILITY = 0.14;

	/** The probability that grass will be created in any given grid position. */
	private static final double GRASS_CREATION_PROBABILITY = 0.6;
	/** The probability that a bush will be created in any given grid position. */
	private static final double BUSH_CREATION_PROBABILITY = 0.4;
	
	/** List of species in the field. */
	private List<Species> animals;
	/** The current state of the field. */
	private World world;
	/** The current step of the simulation. */
	private int step;
	/** A graphical view of the simulation. */
	private SimulatorView view;
	
	/**
	 * Construct a simulation field with default size.
	 */
	public Simulator() {
		this(DEFAULT_DEPTH, DEFAULT_WIDTH);
	}

	/**
	 * Create a simulation with the given size.
	 * 
	 * @param width Width of the world - it's size on the X axis. Must be greater than zero.
	 * @param depth Depth of the world - it's size on the Y axis. Must be greater than zero.
	 */
	public Simulator(int width, int depth) {
		if (width <= 0 || depth <= 0) {
			System.out.println("The dimensions must be greater than zero.");
			System.out.println("Using default values.");
			width = DEFAULT_WIDTH;
			depth = DEFAULT_DEPTH;
		}

		animals = new ArrayList<>();
		world = new World(width, depth);

		// Create a view of the state of each location in the field.
		view = new SimulatorView(width, depth);
		
		// Setup a valid starting point.
		reset();
	}
	
	/**
	 * @return The simulator view used for this simulation.
	 */
	public SimulatorView getView() {
		return view;
	}

	/**
	 * @return The world the simulation is running on.
	 */
	public World getWorld() {
		return world;
	}
	
	/**
	 * Run the simulation from its current state for a reasonably long period, (4000
	 * steps).
	 */
	public void runLongSimulation() {
		simulate(4000);
	}

	/**
	 * Run the simulation from its current state for the given number of steps. Stop
	 * before the given number of steps if it ceases to be viable.
	 * 
	 * @param numSteps The number of steps to run for.
	 */
	public void simulate(int numSteps) {
		for (int i = 0; i < numSteps && view.isViable(world); i++)
			simulateOneStep();
	}

	/**
	 * Run the simulation from its current state for a single step. Iterate over the
	 * whole field updating the state of each animal.
	 */
	public void simulateOneStep() {
		step++;

		world.incrementTime();
		
		// Provide space for newborn animals.
		List<Species> newAnimals = new ArrayList<>();
		// Let all rabbits act.
		for (Iterator<Species> it = animals.iterator(); it.hasNext();) {
			Species animal = it.next();
			if(animal.isAlive())
				animal.act(newAnimals);
			
			if (!animal.isAlive())
				it.remove();
		}

		animals.addAll(newAnimals);

		view.showStatus(step, world);
	}

	/**
	 * Reset the simulation to a starting position.
	 */
	public void reset() {
		step = 0;
		animals.clear();
		populate();

		// Show the starting state in the view.
		view.showStatus(step, world);
	}

	/**
	 * Randomly populate the field with animals.
	 */
	private void populate() {
		Random rand = Randomizer.getRandom();
		world.clear();
		for (int x = 0; x < world.getWidth(); x++) {
			for (int y = 0; y < world.getDepth(); y++) {
				float value = rand.nextFloat();
				float r = 0;
				
				r+=DIRE_WOLF_CREATION_PROBABILITY;
				if (value < r) {
					Location location = new Location(x, y);
					DireWolf direWolf = new DireWolf(true, world, location);
					animals.add(direWolf);
					continue;
				}

				r+=SMILODON_CREATION_PROBABILITY;
				if (value < r) {
					Location location = new Location(x, y);
					Smilodon smilodon = new Smilodon(true, world, location);
					animals.add(smilodon);
					continue;
				}
				
				r+=REINDEER_CREATION_PROBABILITY;
				if (value < r) {
					Location location = new Location(x, y);
					Reindeer reindeer = new Reindeer(true, world, location);
					animals.add(reindeer);
					continue;
				}
				
				r+=MAMMOTH_CREATION_PROBABILITY;
				if (value < r) {
					Location location = new Location(x, y);
					Mammoth mammoth = new Mammoth(true, world, location);
					animals.add(mammoth);
					continue;
				}
				
				r+=RHINO_CREATION_PROBABILITY;
				if (value < r) {
					Location location = new Location(x, y);
					Rhino rhino = new Rhino(true, world, location);
					animals.add(rhino);
					continue;
				}
			}
		}
		
		for (int x = 0; x < world.getWidth(); x++) {
			for (int y = 0; y < world.getDepth(); y++) {
				float value = rand.nextFloat();
				float r = 0;
				
				r += GRASS_CREATION_PROBABILITY;
				if(value < r) {
					Location location = new Location(x, y);
					Grass grass = new Grass(world, location);
					animals.add(grass);
					continue;
				}
				
				r += BUSH_CREATION_PROBABILITY;
				if(value < r) {
					Location location = new Location(x, y);
					Bush bush = new Bush(world, location);
					animals.add(bush);
				}
			}
		}
	}

}
