import java.util.HashMap;

/**
 * This class collects and provides some statistical data on the state of a
 * {@link World}. It is flexible: it will create and maintain a counter for any
 * class of object that is found within it.
 *
 * @version 2020.02.24
 */
public class FieldStats {
	// Counters for each type of entity (dire wolf, mammoth, etc.) in the
	// simulation.
	private HashMap<Class<? extends Species>, Counter> counters;
	// Whether the counters are currently up to date.
	private boolean countsValid;

	/**
	 * Construct a FieldStats object.
	 */
	public FieldStats() {
		// Set up a collection for counters for each type of species that
		// we might find
		counters = new HashMap<>();
		countsValid = true;
	}

	/**
	 * Get details of what is in the world.
	 * 
	 * @return A string describing what is in the world.
	 */
	public String getPopulationDetails(World world) {
		StringBuilder builder = new StringBuilder();
		if (!countsValid) {
			generateCounts(world);
		}
		for (Class<? extends Species> key : counters.keySet()) {
			Counter info = counters.get(key);
			builder
				.append(info.getName())
				.append(": ")
				.append(info.getCount())
				.append(' ');
		}
		return builder.toString();
	}

	/**
	 * Invalidate the current set of statistics; reset all counts to zero.
	 */
	public void reset() {
		countsValid = false;
		for (Class<? extends Species> key : counters.keySet()) {
			Counter count = counters.get(key);
			count.reset();
		}
	}

	/**
	 * Increment the count for one type of {@link Species}.
	 * 
	 * @param speciesClass The class of species to increment.
	 */
	public void incrementCount(Class<? extends Species> speciesClass) {
		Counter count = counters.get(speciesClass);
		if (count == null) {
			// We do not have a counter for this species yet.
			// Create one.
			count = new Counter(speciesClass.getName());
			counters.put(speciesClass, count);
		}
		count.increment();
	}

	/**
	 * Indicate that an species count has been completed.
	 */
	public void countFinished() {
		countsValid = true;
	}

	/**
	 * Determine whether the simulation is still viable. I.e., should it continue to
	 * run.
	 * 
	 * @param world The {@link World} to inspect.
	 * 
	 * @return true If there is more than one {@link Animal} alive.
	 */
	public boolean isViable(World world) {
		if (!countsValid)
			generateCounts(world);

		for (Class<? extends Species> key : counters.keySet())
			if (Animal.class.isAssignableFrom(key) && counters.get(key).getCount() > 0)
				return true;
		return false;
	}

	/**
	 * @param species The {@link Species} to lookup the count of.
	 * @return The count for the given species class.
	 */
	public int getCountFor(Class<? extends Species> species) {
		return counters.get(species).getCount();
	}

	/**
	 * Generate counts of the number of each {@link Species}. These are not kept up to date
	 * as they are placed in the world, but only when a request is made for the
	 * information.
	 * 
	 * @param world The {@link World} to generate the stats for.
	 */
	public void generateCounts(World world) {
		reset();
		for (int row = 0; row < world.getDepth(); row++) {
			for (int col = 0; col < world.getWidth(); col++) {
				Species species = world.getAboveGround().getObjectAt(row, col);
				if (species != null) {
					incrementCount(species.getClass());
				}

				species = world.getFloor().getObjectAt(row, col);
				if (species != null) {
					incrementCount(species.getClass());
				}
			}
		}
		countsValid = true;
	}
}
