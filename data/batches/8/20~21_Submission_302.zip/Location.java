/**
 * Represent a location in a rectangular grid.
 *
 * @version 2020.03.02
 */
public class Location {
	/** The Location's X coordinate */
	private int x;
	/** The Location's Y coordinate */
	private int y;

	/**
	 * Represent a location in 2D space.
	 * 
	 * @param x The location's X coordinate.
	 * @param y The location's Y coordinate.
	 */
	public Location(int x, int y) {
		this.x = x;
		this.y = y;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Location))
			return false;

		Location other = (Location) obj;
		return x == other.x && y == other.y;
	}

	@Override
	public String toString() {
		return x + "," + y;
	}

	@Override
	public int hashCode() {
		return (y << 16) + x;
	}
	
	/**
	 * @return The location's X coordinate.
	 */
	public int getX() {
		return x;
	}

	/**
	 * @return The location's Y coordinate.
	 */
	public int getY() {
		return y;
	}
}
