import java.util.List;

/**
 * A Plant is a type of {@link Species} that can grow. It won't age, and won't
 * move.
 *
 *
 */
public abstract class Plant extends Species {

	/** The plant's age. At 6, it sprouts plants around and goes back to stage 3. */
	protected int age;

	/**
	 * Create a new plant at the given location in the field.
	 * 
	 * @param world    The {@link World} currently occupied.
	 * @param location The {@link Location} within the world.
	 */
	public Plant(World world, Location location) {
		super(world, location);
		age = 0;
	}

	/**
	 * This method must be implemented by all subclasses of Plant, to support plant
	 * growth. It must return a new instance of Plant, at the given location in the
	 * given World. In most cases, the return Plant type will be of the same type as
	 * the Plant this method was called on - this is however not mandatory.
	 * 
	 * @param world The World the sprout will spawn in.
	 * @param loc   The location the sprout will grow in.
	 * @return The new sprout.
	 */
	protected abstract Plant makeSprout(World world, Location loc);

	@Override
	protected void setDead() {
		alive = false;
		if (location != null) {
			world.getFloor().clear(location);
			location = null;
			world = null;
		}
	}

	@Override
	protected void setLocation(Location newLocation) {
		if (location != null) {
			world.getFloor().clear(location);
		}
		location = newLocation;
		world.getFloor().place(this, newLocation);
	}

	/**
	 * @return The odds in the range [0;1] this plant has of growing.
	 */
	public abstract double getGrowthOdds();

	/**
	 * @return How many plants should sprout when this plant pollinates.
	 */
	public abstract int getGrowthAmount();

	/**
	 * @return The food value returned by eating this plant.
	 */
	public abstract int getFoodValue();

	/**
	 * Will try to make this plant grow, and possibly sprout new plants around it.
	 * 
	 * @see #getGrowthOdds()
	 * @see #getGrowthAmount()
	 */
	protected void grow(List<Species> newSprouts) {
		if (rand.nextFloat() < getGrowthOdds()) {
			age++;
			if (age >= 6) {
				age = 3;
				if (!canGrow())
					return;
				List<Location> free = world.getFloor().getFreeAdjacentLocations(getLocation());
				for (int b = 0; b < getGrowthAmount() && free.size() > 0; b++) {
					Location loc = free.remove(0);
					Plant sprout = makeSprout(world, loc);
					newSprouts.add(sprout);
				}
			}
		}
	}

	/**
	 * @return If this plant can grow; will simply check around itself looking for
	 *         free space.
	 */
	protected boolean canGrow() {
		for (int x = -1; x <= 1; x++) {
			int xpos = location.getX() + x;
			if (xpos < 0 || xpos >= world.getWidth())
				continue;
			for (int y = -1; y <= 1; y++) {
				int ypos = location.getY() + y;
				if (ypos < 0 || ypos >= world.getDepth())
					continue;
				if (world.getFloor().getObjectAt(xpos, ypos) == null)
					return true;
			}
		}
		return false;
	}

	/**
	 * This is what a basic plant does most of the time: it randomly grows.
	 * 
	 * @param field     The field currently occupied.
	 * @param newPlants A list to return newly sprouted plants.
	 */
	@Override
	public void act(List<Species> newPlants) {
		if (!isAlive())
			return;
		if (!isAwake())
			return;

		grow(newPlants);
	}

}
