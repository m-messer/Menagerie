import java.awt.Color;

/**
 * A very basic Grass class that extends {@link Plant}. It can grow around,
 * quite fast.
 *
 * @version 2021.02.23
 *
 */
public class Grass extends Plant {
	/** The grass' color. */
	public static final Color COLOR = new Color(0xb9edbb);
	/** The grass' color when it's fully grown. */
	public static final Color GROWN_COLOR = new Color(0xa6e3a8);
	/** The odds a grass has of growing. */
	private static final double GROWTH_ODDS = 0.87;
	/** The max amount of sprouts resulting from grass growing. */
	private static final int GROWTH_AMOUNT = 3;
	/** The max amount of sprouts resulting from grass growing when it's sunny. */
	private static final int GROWTH_AMOUNT_SUNNY = 4;
	/**
	 * The max amount of sprouts resulting from grass growing when it's
	 * raining/thundering.
	 */
	private static final int GROWTH_AMOUNT_RAIN = 2;
	/** The food value of eating grass. */
	private static final int FOOD_VALUE = 16;

	/**
	 * Will create a grass at the given {@link Location} in the {@link World}.
	 * 
	 * @param world    The world the grass will grow in.
	 * @param location The location where the grass will be.
	 */
	public Grass(World world, Location location) {
		super(world, location);
	}

	@Override
	protected Plant makeSprout(World world, Location loc) {
		return new Grass(world, loc);
	}

	@Override
	public double getGrowthOdds() {
		return GROWTH_ODDS;
	}

	@Override
	public int getGrowthAmount() {
		switch (world.getWeather()) {
		case SUNNY:
			return GROWTH_AMOUNT_SUNNY;

		case THUNDER:
		case RAIN:
			return GROWTH_AMOUNT_RAIN;

		case CLOUDY:
		default:
			return GROWTH_AMOUNT;
		}
	}

	@Override
	public int getFoodValue() {
		return FOOD_VALUE;
	}

	@Override
	public boolean isActiveTime(int hour) {
		return hour > 6 && hour < 21;
	}

	@Override
	public Color getColor() {
		return age > 2 ? GROWN_COLOR : COLOR;
	}
}
