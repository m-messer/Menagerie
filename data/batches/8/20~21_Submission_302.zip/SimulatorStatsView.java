import static java.awt.Color.BLACK;
import static java.awt.Color.GRAY;
import static java.awt.Color.WHITE;
import static java.lang.Math.max;
import static java.lang.Math.min;
import static java.lang.Math.round;
import static javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
import static javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JViewport;

/**
 * A SimulatorStatsView is a JFrame type that can show stats. The values and
 * axis must be specified at creation, and values can be added dynamically.
 *
 * @version 2021.03.01
 *
 */
public class SimulatorStatsView extends JFrame {
	private static final long serialVersionUID = -5937077689805812985L;

	/** The default width of this window. */
	private static final int DEFAULT_WIDTH = 800;
	/** The default height of this window. */
	private static final int DEFAULT_HEIGHT = 450;
	/** The min width allowed */
	private static final int MIN_WIDTH = 400;
	/** The min height allowed */
	private static final int MIN_HEIGHT = 300;
	/** The list of elements that'll serve as labels. */
	private final String[] labels;
	/** The list of colors for each element */
	private final Color[] colors;
	/** All stats to display. */
	private final List<int[]> stats;
	/** A possibly null string containg the label for the graph's X axis. */
	private String xAxisLabel;
	/** A possibly null string containg the label for the graph's Y axis. */
	private String yAxisLabel;
	/**
	 * The max stat value contained in this view. Value is stored rather than
	 * calculated to avoid continuously looping over the same arrays
	 */
	private int maxStatValue;
	/**
	 * The min stat value contained in this view. Value is stored rather than
	 * calculated to avoid continuously looping over the same arrays
	 */
	private int minStatValue;
	/** The panel where the stats are drawn */
	private final SimulatorStatsPanel statsPanel;
	/** The panel where the legend is shown. */
	private final SimulatorGraphLegend legendPanel;

	/**
	 * Will create a new SimulatorStatsView element, with at first no stats.
	 */
	public SimulatorStatsView(String[] labels, Color[] colors) {
		super();

		if (labels == null || labels.length == 0)
			throw new IllegalArgumentException("The label array can't be null or empty!");
		if (colors == null || colors.length == 0)
			throw new IllegalArgumentException("The colors array can't be null or empty!");
		if (colors.length != labels.length)
			throw new IllegalArgumentException("The colors and label arrays must have the same length.");

		this.labels = labels;
		this.colors = colors;
		this.stats = new ArrayList<>();
		this.statsPanel = new SimulatorStatsPanel();
		this.legendPanel = new SimulatorGraphLegend();

		setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		setMinimumSize(new Dimension(MIN_WIDTH, MIN_HEIGHT));
		setTitle("JurasSimulation Stats");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		Container contents = getContentPane();

		JPanel pane = new JPanel(new BorderLayout());
		pane.add(statsPanel, BorderLayout.CENTER);

		JScrollPane scrollPane = new JScrollPane(legendPanel, VERTICAL_SCROLLBAR_NEVER, HORIZONTAL_SCROLLBAR_AS_NEEDED);
		// Use this to avoid having a weird graphical glitch when scrolling
		scrollPane.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
		pane.add(scrollPane, BorderLayout.SOUTH);

		contents.add(pane);

		pack();
		setVisible(true);
	}

	/**
	 * Will add stats to the view.
	 * 
	 * @param stats The stats to add. The given array must of the same length as the
	 *              label array the view was initialized with.
	 */
	public void addStats(int[] stats) {
		this.stats.add(stats);

		for (int x : stats) {
			if (x < minStatValue)
				minStatValue = x;
			else if (x > maxStatValue)
				maxStatValue = x;
		}

		repaint();
	}

	/**
	 * Will set the label displayed to indicate what the graph's X axis is. If set
	 * to null, no label will be shown.
	 * 
	 * @param label The label to show.
	 */
	public void setXAxisLabel(String label) {
		this.xAxisLabel = label == null ? null : "X: " + label;
		legendPanel.redoPreferredSize();
	}

	/**
	 * Will set the label displayed to indicate what the graph's Y axis is. If set
	 * to null, no label will be shown.
	 * 
	 * @param label The label to show.
	 */
	public void setYAxisLabel(String label) {
		this.yAxisLabel = label == null ? null : "Y: " + label;
		legendPanel.redoPreferredSize();
	}

	/**
	 * @return The max stat value stored.
	 */
	private int getMax() {
		return maxStatValue;
	}

	/**
	 * @return The min stat value stored.
	 */
	private int getMin() {
		return minStatValue;
	}

	/**
	 * A class used to draw the content of the stats view, by drawing a graph that's
	 * updated with the latest data.
	 *
	 * @version 2020.03.01
	 *
	 */
	private class SimulatorStatsPanel extends JPanel {
		private static final long serialVersionUID = 5737045212603912818L;

		/** The padding on the left, that's left for the Y axis labels. */
		private static final int LEFT_PADDING = 48;
		/** The padding on the right */
		private static final int RIGHT_PADDING = 10;
		/** The padding at the bottom, that's left for the X axis labels. */
		private static final int BOTTOM_PADDING = 25;
		/** The padding at the top */
		private static final int TOP_PADDING = RIGHT_PADDING;
		/** The default size of a division of the X axis. */
		private static final int X_DIV_SIZE = 50;
		/** The default size of a division of the Y axis. */
		private static final int Y_DIV_SIZE = 50;
		/** The stroke used for drawing the graph. */
		private final Stroke STROKE = new BasicStroke(2, BasicStroke.JOIN_ROUND, BasicStroke.CAP_BUTT);
		/** A thinner stroke used for drawing the graph's lines. */
		private final Stroke THIN_STROKE = new BasicStroke(1, BasicStroke.JOIN_ROUND, BasicStroke.CAP_BUTT);

		@Override
		protected void paintComponent(Graphics graphics) {
			if (stats.size() < 2)
				return;

			// Calculate all values
			int graphWidth = (int) (getSize().getWidth() - LEFT_PADDING - RIGHT_PADDING);
			int graphHeight = (int) (getSize().getHeight() - BOTTOM_PADDING - TOP_PADDING);

			int max = getMax();
			int min = getMin();

			int xRange = stats.size() - 1;
			int yRange = max - min;

			int xDivs = min(max(1, graphWidth / X_DIV_SIZE), xRange);
			int yDivs = min(max(1, graphHeight / Y_DIV_SIZE), yRange);

			// Prepare canvas
			Graphics2D g = (Graphics2D) graphics;

			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

			g.setColor(WHITE);
			g.fillRect(LEFT_PADDING, TOP_PADDING, graphWidth, graphHeight);

			g.setStroke(THIN_STROKE);

			// Draw grid and add labels
			int textHeight = g.getFontMetrics().getHeight();
			for (int i = 0; i <= yDivs; i++) {
				int y = Math.round((float) graphHeight / yDivs * i + TOP_PADDING);
				g.setColor(GRAY);
				g.drawLine(LEFT_PADDING, y, LEFT_PADDING + graphWidth, y);

				String display = Integer.toString(round(min + (float) yRange * (yDivs - i) / yDivs));
				int textWidth = g.getFontMetrics().stringWidth(display);
				g.setColor(BLACK);
				g.drawString(display, LEFT_PADDING - 3 - textWidth, y + textHeight / 2);
			}

			for (int i = 0; i <= xDivs; i++) {
				int x = Math.round(LEFT_PADDING + (float) graphWidth / xDivs * i);
				g.setColor(GRAY);
				g.drawLine(x, TOP_PADDING, x, TOP_PADDING + graphHeight);

				String display = Integer.toString(round((float) i / xDivs * xRange));
				int textWidth = g.getFontMetrics().stringWidth(display);
				g.setColor(BLACK);
				g.drawString(display, x - textWidth / 2, TOP_PADDING + graphHeight + textHeight);
			}

			// Draw graph content
			g.setStroke(STROKE);
			int[] lastYCoords = null;
			int lastXCoord = 0;
			for (int i = 0; i < stats.size(); i++) {
				int[] values = stats.get(i);
				int[] yCoords = new int[values.length];

				int xCoord = round(LEFT_PADDING + ((float) graphWidth * i / xRange));

				for (int j = 0; j < values.length; j++) {
					// map to screen coordinates
					yCoords[j] = round(graphHeight + TOP_PADDING - (float) (values[j] - min) / yRange * graphHeight);
				}

				if (lastYCoords != null) {
					for (int j = 0; j < values.length; j++) {
						g.setColor(colors[j]);
						g.drawLine(lastXCoord, lastYCoords[j], xCoord, yCoords[j]);
					}
				}

				lastYCoords = yCoords;
				lastXCoord = xCoord;
			}

			// Redraw edges
			g.setColor(BLACK);
			g.drawLine(LEFT_PADDING, TOP_PADDING, LEFT_PADDING + graphWidth, TOP_PADDING);
			g.drawLine(LEFT_PADDING, TOP_PADDING + graphHeight, LEFT_PADDING + graphWidth, TOP_PADDING + graphHeight);
			g.drawLine(LEFT_PADDING, TOP_PADDING, LEFT_PADDING, TOP_PADDING + graphHeight);
			g.drawLine(LEFT_PADDING + graphWidth, TOP_PADDING, LEFT_PADDING + graphWidth, TOP_PADDING + graphHeight);

		}

	}

	/**
	 * A class used to draw the legend of the stats, by simply displaying the axis'
	 * labels (if needed), and what each of the graph's colors represents.
	 *
	 * @version 2020.03.01
	 *
	 */
	private class SimulatorGraphLegend extends JPanel {
		private static final long serialVersionUID = 3466737670753422633L;

		// Padding used in this panel to add whitespace to it.
		private static final int PADDING = 10;
		// The size in pixels of the color boxes.
		private static final int COLOR_BOX_SIZE = 10;
		// Object to keep track of the needed dimension
		private final Dimension preferredSize = new Dimension();

		/**
		 * Will create a SimulatorGraphLegend panel, that will show this
		 * SimulatorStatsView's stats.
		 */
		private SimulatorGraphLegend() {
			super();
			redoPreferredSize();
		}

		/**
		 * Will recalculate this panel's preffered size. This method should be called
		 * when any labels that appear in the legend are changed.
		 */
		private void redoPreferredSize() {
			FontMetrics fm = getFontMetrics(getFont());

			int width = PADDING * 2;
			for (String label : labels)
				width += fm.stringWidth(label) + COLOR_BOX_SIZE + PADDING * 2;

			if (xAxisLabel != null)
				width += fm.stringWidth(xAxisLabel) + PADDING;
			if (yAxisLabel != null)
				width += fm.stringWidth(yAxisLabel) + PADDING;

			preferredSize.setSize(width, PADDING * 4 + max(fm.getHeight(), COLOR_BOX_SIZE));
		}

		@Override
		protected void paintComponent(Graphics g) {
			FontMetrics fm = getFontMetrics(getFont());

			int x = PADDING;
			int y = PADDING * 2 + fm.getHeight();

			g.setColor(BLACK);

			if (xAxisLabel != null) {
				g.drawString(xAxisLabel, x, y);
				x += fm.stringWidth(xAxisLabel) + PADDING;
			}
			if (yAxisLabel != null) {
				g.drawString(yAxisLabel, x, y);
				x += fm.stringWidth(yAxisLabel) + PADDING;
			}

			for (int i = 0; i < labels.length; i++) {
				String label = labels[i];
				g.setColor(colors[i]);

				g.fillRect(x, y - COLOR_BOX_SIZE, COLOR_BOX_SIZE, COLOR_BOX_SIZE);
				x += COLOR_BOX_SIZE + PADDING;

				g.setColor(BLACK);
				g.drawString(label, x, y);
				x += fm.stringWidth(label) + PADDING;
			}
		}

		@Override
		public Dimension getPreferredSize() {
			return preferredSize;
		}

	}

}
