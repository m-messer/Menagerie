import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Represent a rectangular grid of field positions. Each position is able to
 * store a single {@link Species}.
 *
 * @version 2020.02.01
 */
public class Field {
	/** A random number generator for providing random locations. */
	private static final Random rand = Randomizer.getRandom();

	/** The field's width - it's size on the X axis. */
	private final int width;
	/** The field's depth - it's size on the Y axis. */
	private final int depth;
	/** Storage for the species. */
	private final Species[][] field;

	/**
	 * Represent a field of the given dimensions.
	 *
	 * @param width The width of the field - it's size on the X axis.
	 * @param depth The depth of the field - it's size on the Y axis.
	 */
	public Field(int width, int depth) {
		this.width = width;
		this.depth = depth;
		this.field = new Species[width][depth];
	}

	/**
	 * Empty the field.
	 */
	public void clear() {
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < depth; y++) {
				field[x][y] = null;
			}
		}
	}

	/**
	 * Clear the given {@link Location}.
	 *
	 * @param location The location to clear.
	 */
	public void clear(Location location) {
		field[location.getX()][location.getY()] = null;
	}

	/**
	 * Place a {@link Species} at the given coordinates. If there is already a
	 * species there it will be lost.
	 *
	 * @param species The species to be placed.
	 * @param x       The X coordinate in the field where the species is placed.
	 * @param y       The Y coordinate in the field where the species is placed.
	 */
	public void place(Species species, int x, int y) {
		field[x][y] = species;
	}

	/**
	 * Place a {@link Species} at the given {@link Location}. If there is already a
	 * species at the location it will be lost.
	 *
	 * @param species  The species to be placed.
	 * @param location Where to place the species.
	 */
	public void place(Species species, Location location) {
		place(species, location.getX(), location.getY());
	}

	/**
	 * Return the {@link Species} at the given {@link Location}, if any.
	 *
	 * @param location Where in the field.
	 * @return The species at the given location, or null if there is none.
	 */
	public Species getObjectAt(Location location) {
		return getObjectAt(location.getX(), location.getY());
	}

	/**
	 * Return the {@link Species} at the given coordinates, if any.
	 *
	 * @param x   The X coordinate.
	 * @param col The Y coordinate.
	 * @return The species at the given coordinates, or null if there is none.
	 */
	public Species getObjectAt(int x, int y) {
		return field[x][y];
	}

	/**
	 * Generate a random {@link Location} that is adjacent to the given location.
	 * The returned location will be within the valid bounds of the field.
	 *
	 * @param location The location from which to generate an adjacency.
	 * @return A valid location within the grid area.
	 * @see #adjacentLocations(Location)
	 */
	public Location randomAdjacentLocation(Location location) {
		List<Location> adjacent = adjacentLocations(location);
		return adjacent.get(0);
	}

	/**
	 * Get a shuffled list of the free adjacent {@link Location Locations}.
	 *
	 * @param location Get locations adjacent to this.
	 * @return A list of free adjacent locations.
	 */
	public List<Location> getFreeAdjacentLocations(Location location) {
		List<Location> adjacent = adjacentLocations(location);
		for (Iterator<Location> it = adjacent.iterator(); it.hasNext();) {
			Location loc = it.next();
			if (getObjectAt(loc) != null)
				it.remove();
		}
		return adjacent;
	}

	/**
	 * Try to find a free {@link Location} that is adjacent to the given location.
	 * If there is none, return null. The returned location will be within the valid
	 * bounds of the field.
	 *
	 * @param location The location from which to generate an adjacency.
	 * @return A valid location within the grid area.
	 * @see #getFreeAdjacentLocations(Location)
	 */
	public Location freeAdjacentLocation(Location location) {
		// The available free ones.
		List<Location> free = getFreeAdjacentLocations(location);
		return free.size() > 0 ? free.get(0) : null;
	}

	/**
	 * Return a shuffled list of {@link Location Locations} adjacent to the given
	 * one. The list will not include the location itself. All locations will lie
	 * within the grid.
	 *
	 * @param location The location from which to generate adjacencies.
	 * @return A list of locations adjacent to that given.
	 */
	public List<Location> adjacentLocations(Location location) {
		assert location != null : "Null location passed to adjacentLocations";
		// The list of locations to be returned.
		List<Location> locations = new LinkedList<>();

		int x = location.getX();
		int y = location.getY();
		for (int xOffset = -1; xOffset <= 1; xOffset++) {
			int nextX = x + xOffset;
			if (nextX >= 0 && nextX < width) {
				for (int yOffset = -1; yOffset <= 1; yOffset++) {
					int nextY = y + yOffset;
					// Exclude invalid locations and the original location.
					if (nextY >= 0 && nextY < depth && (xOffset != 0 || yOffset != 0)) {
						locations.add(new Location(nextX, nextY));
					}
				}
			}
		}

		// Shuffle the list. Several other methods rely on the list
		// being in a random order.
		Collections.shuffle(locations, rand);

		return locations;
	}

	/**
	 * Returns a list of all animals of the given class that are adjacent
	 * to the given {@link Location}.
	 * 
	 * @return List of all adjacent animals (may be empty).
	 */
	@SuppressWarnings("unchecked")
	public <T extends Species> List<T> adjacentAnimals(Class<T> clazz, Location location) {
		List<T> animals = new ArrayList<>();
		List<Location> adjacent = adjacentLocations(location);
		for (Location loc : adjacent) {
			Species species = getObjectAt(loc);
			if (species != null && clazz.isInstance(species))
				animals.add((T) species);
		}
		return animals;
	}

	/**
	 * @return The width of the field - it's size on the X axis.
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * @return The depth of the field - it's size on the Y axis.
	 */
	public int getDepth() {
		return depth;
	}
}
