import java.awt.Color;
import java.util.List;
import java.util.Random;

/**
 * A Species represent an individual in the simulation that can act on it, by
 * moving, eating, dying, etc. This is the most abstract form of individiual in
 * the simulation, and must be extended by other classes to implement
 * interesting behaviour. By default, the species is set to exist on the upper
 * ground; methods must be overriden to support ground-leveled species.
 *
 * @version 2020.02.09
 * @see World
 */
public abstract class Species {

	/** Whether the species is alive or not. */
	protected boolean alive;
	/** The species's world. */
	protected World world;
	/** The species's position in the world. */
	protected Location location;
	/** A Random object to create random numbers. */
	protected Random rand = Randomizer.getRandom();

	/**
	 * Create a new species at location in the world's above ground field.
	 * 
	 * @param world    The world currently occupied.
	 * @param location The location within the field.
	 */
	public Species(World world, Location location) {
		if (world == null)
			throw new IllegalArgumentException();

		alive = true;
		this.world = world;
		setLocation(location);
	}

	/**
	 * Make this species act - that is: make it do whatever it wants/needs to do.
	 * 
	 * @param newSpecies A list to receive newly born species.
	 */
	public abstract void act(List<Species> newSpecies);

	/**
	 * @param hour The hour to check.
	 * @return If this species should be active at the given hour.
	 */
	public abstract boolean isActiveTime(int hour);

	/**
	 * @return This species' color.
	 */
	public abstract Color getColor();
	
	/**
	 * @return If this species is awake, i.e. it's in its {@link #isActiveTime(int) active time}. It may also
	 *         be randomly awake during its inactive time.
	 */
	public boolean isAwake() {
		return isActiveTime(world.getHour()) || rand.nextFloat() < 0.4f;
	}

	/**
	 * @return If the species is still alive.
	 */
	protected boolean isAlive() {
		return alive;
	}

	/**
	 * Indicate that the species is no longer alive. It is removed from the {@link World}.
	 * @see #isAlive()
	 */
	protected void setDead() {
		alive = false;
		if (location != null) {
			world.getAboveGround().clear(location);
			location = null;
		}
	}

	/**
	 * @return The species's {@link Location}.
	 */
	public Location getLocation() {
		return location;
	}

	/**
	 * Place the species at the new {@link Location} in its current {@link World}.
	 * 
	 * @param newLocation The species's new location.
	 */
	protected void setLocation(Location newLocation) {
		if (location != null) 
			world.getAboveGround().clear(location);
		if(newLocation != null)
			world.getAboveGround().place(this, newLocation);
		location = newLocation;
	}

	/**
	 * @return The species's {@link World}.
	 */
	public World getWorld() {
		return world;
	}

}
