import static java.awt.Color.WHITE;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * A graphical view of the simulation grid. The view displays a colored
 * rectangle for each location representing its contents. It uses a default
 * background color. Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2020.03.02
 */
public class SimulatorView extends JFrame implements KeyListener {
	private static final long serialVersionUID = -6388123017006610823L;

	/** Colors used for empty locations. */
	private static final Color EMPTY_COLOR = new Color(0xe8dab3);

	private final String STEP_PREFIX = "Step: ";
	private final String WEATHER_PREFIX = "Weather: ";
	private final String POPULATION_PREFIX = "Population: ";
	private JLabel stepLabel, population, infoLabel;
	private FieldView fieldView;

	/** A statistics object computing and storing simulation information */
	private FieldStats stats;

	/** If this window is currently showing the species' diseases. */
	private boolean showsDisease = false;

	/**
	 * Create a view of the given width and height.
	 * 
	 * @param width  The simulation's width.
	 * @param height The simulation's height.
	 */
	public SimulatorView(int width, int height) {
		stats = new FieldStats();

		setTitle("JurasSimulation");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		stepLabel = new JLabel(STEP_PREFIX, SwingConstants.CENTER);
		infoLabel = new JLabel("  ", SwingConstants.CENTER);
		population = new JLabel(POPULATION_PREFIX, SwingConstants.CENTER);
		
		fieldView = new FieldView(width, height);

		Container contents = getContentPane();

		JPanel infoPane = new JPanel(new BorderLayout());
		infoPane.add(stepLabel, BorderLayout.WEST);
		infoPane.add(infoLabel, BorderLayout.CENTER);
		contents.add(infoPane, BorderLayout.NORTH);
		contents.add(fieldView, BorderLayout.CENTER);
		contents.add(population, BorderLayout.SOUTH);
		pack();
		setVisible(true);

		simulatorStatsView = new SimulatorStatsView(
				new String[] { 
						"Mammoth", 
						"Reindeer", 
						"Rhino",
						"Dire Wolf", 
						"Smilodon"
				},
				new Color[] {
						Mammoth.COLOR,
						Reindeer.COLOR,
						Rhino.COLOR,
						DireWolf.COLOR,
						Smilodon.COLOR
				}
		);
		simulatorStatsView.setXAxisLabel("Hours passed");
		simulatorStatsView.setYAxisLabel("Individuals");

		this.addKeyListener(this);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		/* Do nothing */}

	@Override
	public void keyReleased(KeyEvent e) {
		/* Do nothing */}

	@Override
	public void keyTyped(KeyEvent e) {
		if (e.getKeyChar() == ' ')
			showsDisease = !showsDisease;
	}

	SimulatorStatsView simulatorStatsView;

	/**
	 * @return The stats for this view.
	 */
	public FieldStats getStats() {
		return stats;
	}

	/**
	 * Display a short information label at the top of the window.
	 */
	public void setInfoText(String text) {
		infoLabel.setText(text);
	}

	/**
	 * Show the current status of the field.
	 * 
	 * @param step  Which iteration step it is.
	 * @param field The field whose status is to be displayed.
	 */
	public void showStatus(int step, World world) {
		if (!isVisible()) {
			setVisible(true);
		}

		stepLabel.setText(STEP_PREFIX + step + " - " + world.getFormattedTime() + " - " + WEATHER_PREFIX
				+ world.getWeather().getName());
		stats.reset();

		fieldView.preparePaint();

		for (int x = 0; x < world.getWidth(); x++) {
			for (int y = 0; y < world.getDepth(); y++) {
				Species species = world.getFloor().getObjectAt(x, y);
				if (species != null) {
					stats.incrementCount(species.getClass());
					fieldView.drawMarkFull(x, y, species.getColor());
				} else {
					fieldView.drawMarkFull(x, y, EMPTY_COLOR);
				}

				species = world.getAboveGround().getObjectAt(x, y);
				if (species != null) {
					stats.incrementCount(species.getClass());

					if (!showsDisease || !(species instanceof Animal))
						fieldView.drawMark(x, y, species.getColor());
					else {
						fieldView.drawMark(x, y, ((Animal) species).getDiseaseState().getColor());
					}
				}
			}
		}
		stats.countFinished();

		fieldView.drawTimeOverlay(world.getHour());

		for (Location thunderLoc : world.getThunderLocations())
			fieldView.drawMarkFull(thunderLoc.getX(), thunderLoc.getY(), WHITE);

		population.setText(POPULATION_PREFIX + stats.getPopulationDetails(world));
		fieldView.repaint();

		simulatorStatsView.addStats(new int[] { 
				stats.getCountFor(Mammoth.class), 
				stats.getCountFor(Reindeer.class),
				stats.getCountFor(Rhino.class), 
				stats.getCountFor(DireWolf.class), 
				stats.getCountFor(Smilodon.class) 
		});
	}

	/**
	 * Determine whether the simulation should continue to run.
	 * 
	 * @return true If there is more than one species alive.
	 */
	public boolean isViable(World world) {
		return stats.isViable(world);
	}

	/**
	 * Provide a graphical view of a rectangular field. This is a nested class (a
	 * class defined inside a class) which defines a custom component for the user
	 * interface. This component displays the field. This is rather advanced GUI
	 * stuff - you can ignore this for your project if you like.
	 */
	private class FieldView extends JPanel {
		private static final long serialVersionUID = -5639320443455245917L;

		private final int GRID_VIEW_SCALING_FACTOR = 4;

		private int gridWidth, gridHeight;
		private int xScale, yScale;
		private Dimension size;
		private Graphics imageGraphics;
		private Image fieldImage;

		/**
		 * Create a new FieldView component.
		 * 
		 * @param width  The panel's width.
		 * @param height The panel's height.
		 */
		public FieldView(int width, int height) {
			gridWidth = width;
			gridHeight = height;
			size = new Dimension(0, 0);
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR, gridHeight * GRID_VIEW_SCALING_FACTOR);
		}

		/**
		 * Prepare for a new round of painting. Since the component may be resized,
		 * compute the scaling factor again.
		 */
		public void preparePaint() {
			if (!size.equals(getSize())) { // if the size has changed...
				size = getSize();
				fieldImage = fieldView.createImage(size.width, size.height);
				imageGraphics = fieldImage.getGraphics();

				xScale = size.width / gridWidth;
				if (xScale < 1) {
					xScale = GRID_VIEW_SCALING_FACTOR;
				}
				yScale = size.height / gridHeight;
				if (yScale < 1) {
					yScale = GRID_VIEW_SCALING_FACTOR;
				}
			}
		}

		/**
		 * Paint on grid location on this field in a given color.
		 */
		public void drawMark(int x, int y, Color color) {
			imageGraphics.setColor(color);
			imageGraphics.fillRect(x * xScale + 1, y * yScale + 1, xScale - 2, yScale - 2);
		}

		/**
		 * Paint on grid location on this field in a given color, filling the entire
		 * square instead of just the center.
		 */
		public void drawMarkFull(int x, int y, Color color) {
			imageGraphics.setColor(color);
			imageGraphics.fillRect(x * xScale, y * yScale, xScale, yScale);
		}

		/**
		 * Will draw a color overlay to match
		 * 
		 * @param hour The hour of day matching the overlay.
		 */
		public void drawTimeOverlay(int hour) {
			// offset by 4 hours, to have an effect between 8PM and 7AM
			hour = (hour + 4) % 24;
			if (hour < 11) {
				// polynomial function, f(0)=0.1, f(5)=0.3, f(10)=0.1
				float opacity = -1f / 125 * hour * hour + 2f / 25 * hour + 0.1f;
				imageGraphics.setColor(new Color(0, 0, 0, opacity));
				imageGraphics.fillRect(0, 0, size.width, size.height);
			}
		}

		@Override
		public void paintComponent(Graphics g) {
			if (fieldImage != null) {
				Dimension currentSize = getSize();
				if (size.equals(currentSize)) {
					g.drawImage(fieldImage, 0, 0, null);
				} else {
					// Rescale the previous image.
					g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
				}
			}
		}
	}
}
