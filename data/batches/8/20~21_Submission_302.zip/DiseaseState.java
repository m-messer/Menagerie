import static java.awt.Color.BLUE;
import static java.awt.Color.RED;
import static java.awt.Color.WHITE;

import java.awt.Color;

/**
 * A very basic enum used to specify what's the state of an animal regarding
 * it's disease. The state also contains a color that can be used in the disease
 * mode of the {@link SimulatorView}.
 *
 * @version 2021.03.02
 *
 */
public enum DiseaseState {
	HEALTHY(WHITE), 
	SICK(RED), 
	IMMUNE_NATURALLY(BLUE), 
	IMMUNE_HEREDITARY(new Color(0x1dafbf));

	/** The state's color. */
	private final Color color;

	/**
	 * Will create a disease state with the given color.
	 * 
	 * @param c The state's color.
	 */
	private DiseaseState(Color c) {
		this.color = c;
	}

	/**
	 * @return The color associated to this disease state.
	 */
	public Color getColor() {
		return color;
	}
}
