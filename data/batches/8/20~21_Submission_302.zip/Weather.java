
/**
 * A basic enum containing all weather types, and their odds of appearing every
 * day.
 *
 * @version 2021.02.27
 * @see World
 */
public enum Weather {
	CLOUDY("Cloudy", 0.55f), 
	SUNNY("Sunny", 0.25f), 
	RAIN("Rain", 0.15f),
	THUNDER("Thunder", 0.05f);

	/** The weather's name. */
	private final String name;
	/** The weather's odds of appearing each day. */
	private final float odds;

	/**
	 * Will create a weather type, with the given name and probability.
	 * 
	 * @param name The weather's name.
	 * @param odds The odds of it appearing every day.
	 */
	Weather(String name, float odds) {
		this.name = name;
		this.odds = odds;
	}
	
	/**
	 * @return The weather type's name.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * @return The odds of this weather type to appear every day.
	 */
	public float getOdds() {
		return odds;
	}
}
