import java.awt.Color;

/**
 * A simple model of wooly rhino. Rhins age, age plants, move, breed, and die.
 *
 * @version 2020.02.09
 * @see Herbivore
 */
public class Rhino extends Herbivore {
	/** The Rhino's color. */
	public static final Color COLOR = new Color(0xa764b0);
	/** The age at which a rhino can start to breed. */
	private static final int BREEDING_AGE = 6;
	/** The age to which a rhino can live. */
	private static final int MAX_AGE = 56;
	/** The likelihood of a rhino breeding. */
	private static final double BREEDING_PROBABILITY = 0.104;
	/** The maximum number of births. */
	private static final int MAX_LITTER_SIZE = 2;
	/**
	 * The food value of a single rhino. In effect, this is the number of steps a
	 * carnivore can go before it has to eat again.
	 */
	private static final int FOOD_VALUE = 28;
	/** The food level after which the rhino will stop looking for food. */
	private static final int TARGET_FOOD_LEVEL = 19;

	/**
	 * Create a new rhino. A rhino may be created with age zero (a new born) or with
	 * a random age.
	 * 
	 * @param randomAge If true, the rhino will have a random age.
	 * @param world     The {@link World} currently occupied.
	 * @param location  The {@link Location} within the world.
	 */
	public Rhino(boolean randomAge, World world, Location location) {
		super(world, location);
		foodLevel = 3;
		if (randomAge) {
			age = rand.nextInt(MAX_AGE);
			foodLevel += 5 + rand.nextInt(TARGET_FOOD_LEVEL);
		}
	}

	@Override
	protected Animal makeBaby(World world, Location location) {
		return new Rhino(false, world, location);
	}

	@Override
	public int getBreedingAge() {
		return BREEDING_AGE;
	}

	@Override
	public double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	@Override
	public int getMaxAge() {
		return MAX_AGE;
	}

	@Override
	public int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	@Override
	public int getFoodValue() {
		return FOOD_VALUE;
	}

	@Override
	public boolean isActiveTime(int hour) {
		return hour >= 8 && hour <= 21;
	}

	@Override
	public Color getColor() {
		return COLOR;
	}

	@Override
	public int getTargetFoodLevel() {
		return TARGET_FOOD_LEVEL;
	}
}
