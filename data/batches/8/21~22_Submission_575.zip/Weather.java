
/**
 * Representations for all possible types of weather.
 *
 * @version 2022.2.24
 */
public enum Weather {
    // A value for each weather.
    Sunny, Rainy
}
