import java.util.Random;
/**
 * Some animals are occasionally infected. 
 * Infection can spread to other animals when they meet.
 *
 * @version 2021.02.28 
 */

public class Disease
{
    private int mortalityRate = 10;
    private int infectionRate = 25;
    Random rand = new Random();
    
    public boolean willAnimalDie() {      
        int upper_limit = 100;
        int chanceOfDying = rand.nextInt(upper_limit);
        if (chanceOfDying <= mortalityRate) {
            return true;
        }
        else{
            return false;
        }
    }
    
    public boolean infectNewAnimal() {
        int upper_limit = 100;
        int chanceOfInfection = rand.nextInt(upper_limit);
        if (chanceOfInfection <= infectionRate) {
            return true;
        }
        else{
            return false;
        }
        
    }}
