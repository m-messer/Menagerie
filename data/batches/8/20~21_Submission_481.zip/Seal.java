import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Seals are one of our predators. They hunt and eat fish.
 *
 * @version 2021.02.28 
 */
public class Seal extends Predator
{
    // The age at which a seal can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a seal can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a seal breeding.
    private static final double BREEDING_PROBABILITY = 0.125;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single fish. In effect, this is the
    // number of steps a seal can go before it has to eat again.
    private static final int FISH_FOOD_VALUE = 13;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The seal's age.
    private int age;
    // The seal's food level, which is increased by eating fish.
    private int foodLevel;

    /**
     * Create a seal. A seal can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the seal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seal (boolean randomAge, Field field, Location location, Time t, String weather, Disease disease)
    {
        super(field, location, t, weather, disease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FISH_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FISH_FOOD_VALUE;
        }
    }
    

    /**
     * Increase the age. This could result in the seal's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this seal more hungry. This could result in the seal's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for fish adjacent to the current location.
     * Only the first live fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if(weather.equals("Fog")) //fish cannot eat when there is fog
        {
            return null;
        }
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setDead();
                    foodLevel = FISH_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this seal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSeals A list to return newly born seals.
     */
    public void giveBirth(List<Animal> newSeals)
    {
        // New seales are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                
        List<Location> allAdjacentLocations = field.adjacentLocations(getLocation());
        
        int births;
        boolean breedPossible = false;
        boolean gender = getGender();
        // Checks all adjacent locations to see if it can find a seal of the opposite gender and proceeds to breed if that is the case.
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Seal) {
                Seal seal = (Seal) obj;
                if(seal.getGender() != gender) { 
                    breedPossible = true;                     
                }
            }
        }
        
        if (breedPossible = true) {       
            births = breed();       
        }
        else {
            births = 0;
        }
        
        if(t.isNight() == true && !weather.equals("Sunshine")) // seals cannot breed when it is sunny and can only breed at night
        {
            for(int b = 0; b < births && free.size() > 0; b++) 
            {
                Location loc = free.remove(0);
                Seal young = new Seal(false, field, loc, t, weather, disease);
                newSeals.add(young);
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A seal can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    /**
     * This code is used to infect other animals of the same type (ie. whale only infects a whale) 
     * Will also check to see if the disease kills the said animal
     */
    public void diseaseSimulation() { 
        Field field = getField();
        if (isInfected() == true) {
            boolean willAnimalDie = disease.willAnimalDie();
            
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object obj = field.getObjectAt(where);
                if(obj instanceof Seal) {
                    Seal seal = (Seal) obj;
                    if(seal.isInfected() == false && disease.infectNewAnimal() == true && seal.isImmune() == false) { 
                        seal.infectAnimal();                     
                    }
                }
            }
            if (willAnimalDie == true) {
                setDead();
            }
            else if (willAnimalDie == false) {
                giveImmunity();
            }
        }
        
    }
}
