import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Sea birds are one of our prey animals.
 * They eat plants and are hunted by whales.
 *
 * @version 2021.02.28 
 */
public class SeaBird extends Prey
{
    // Characteristics shared by all sea birds (class variables).

    // The age at which a sea bird can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a sea bird can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a sea bird breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The number of steps a sea bird can go before it has to eat again 
    private static final int PLANT_FOOD_VALUE = 24; 
    
    // Individual characteristics (instance fields).
    
    // The sea bird's age.
    private int age;
    // The sea bird's food level which is increased by eating plants.
    private int foodLevel;

    /**
     * Create a new sea bird. A sea bird may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the sea bird will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public SeaBird(boolean randomAge, Field field, Location location, Time t, String weather, Disease disease)
    {
        super(field, location, t, weather, disease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * Increase the age.
     * This could result in the sea bird's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this sea bird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSeaBirds A list to return newly born sea birds.
     */
    public void giveBirth(List<Animal> newSeaBirds)
    {
        // New sea birds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        int births;
        boolean breedPossible = false;
        boolean gender = getGender();
        // Checks all adjacent locations to see if it can find a sea bird of the opposite gender and proceeds to breed if that is the case.
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof SeaBird) {
                SeaBird seabird = (SeaBird) obj;
                if(seabird.getGender() != gender) { 
                    breedPossible = true;                     
                }
            }
        }
        
        if (breedPossible = true) {       
            births = breed();       
        }
        else {
            births = 0;
        }
        
        if (t.isNight() == true && !weather.equals("Snow")) {  // Sea bird can only breed at night
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            SeaBird young = new SeaBird(false, field, loc, t, weather, disease);
            newSeaBirds.add(young);
        }}
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A sea bird can breed if it has reached the breeding age.
     * @return true if the sea bird can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Make this sea bird more hungry. This could result in the sea bird's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if(weather.equals("Snow") || weather.equals("Fog")) //sea birds cannot eat when it snows or when there is fog
        {
            return null;
        }
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Plants) {
                Plants plant = (Plants) obj;
                if(plant.isExisting()) { 
                    plant.remove();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * This code is used to infect other animals of the same type (ie. whale only infects a whale) 
     * Will also check to see if the disease kills the said animal
     */
    public void diseaseSimulation() { 
        Field field = getField();
        if (isInfected() == true) {
            boolean willAnimalDie = disease.willAnimalDie();
            
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object obj = field.getObjectAt(where);
                if(obj instanceof SeaBird) {
                    SeaBird seabird = (SeaBird) obj;
                    if(seabird.isInfected() == false && disease.infectNewAnimal() == true && seabird.isImmune() == false) { 
                        seabird.infectAnimal();                     
                    }
                }
            }
            if (willAnimalDie == true) {
                setDead();
            }
            else if (willAnimalDie == false) {
                giveImmunity();
            }
        }
        
    }
}
