import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;


/**
 * A predator-prey simulator, based on a rectangular field
 * containing whales, seals, penguins, sea birds and fish. 
 * The prey are the sea birds and fish and the predators
 * are the other animals.
 * Whales eat birds and seal and penguins eat fish. 
 * Seals and fish eat plants.
 *
 * @version 2021.02.28 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a fox will be created in any given grid position.
    private static final double PREDATOR_CREATION_PROBABILITY = 0.385;
    // The probability that a rabbit will be created in any given grid position.
    private static final double PREY_CREATION_PROBABILITY = 0.38;   
    // The probability that a plant will be created in any given grid position
    private static final double PLANT_CREATION_PROBABILITY = 0.35;

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plants> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The time duraton of the simulation.
    private Time t = new Time();
    // The weather of the simulation.
    private Weather w = new Weather();
    // Weather at beginning of the simulation
    private String currentWeather = w.getWeather();
    // The disease simulation 
    private Disease disease = new Disease();
       
    private boolean diseaseExists = false;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Penguin.class, Color.ORANGE);
        view.setColor(Seal.class, Color.BLUE);
        view.setColor(Whale.class, Color.PINK);
        view.setColor(Fish.class, Color.YELLOW);
        view.setColor(Prey.class, Color.RED);
        view.setColor(Plants.class, Color.GREEN);
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (3000 steps).
     */
    public void runLongSimulation()
    {
        simulate(2000);
        
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(30);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        //Provide space for new plants.
        List<Plants> newPlants = new ArrayList<>();
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        for(Iterator<Plants> it = plants.iterator(); it.hasNext(); ) {
            Plants plant = it.next();
            plant.act(newPlants);
            if(! plant.isExisting()) {
                it.remove();
            }
        }        
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        // Add the new plants to the main lists.
        plants.addAll(newPlants);
        view.showStatus(step, field, t, currentWeather);
        
        timeChanger();
        getCurrentWeather();  
        
    }
    
    public void timeChanger()
    {
        // Allows the programme to keep track of the time
        t.changeTime();
    }
    
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, t, currentWeather);
    }
    
    /**
     * Every time there is a new night - the weather changes.
     * This ensures that the weather is changing regularly during the 
     * simulation, allowing different events to take place,
     * depending on the weather.
     */
    private String getCurrentWeather()
    {
        if(t.isNight() && (step % 20 == 0))
        {
            currentWeather = w.getWeather();
        }
        return currentWeather;
    }
    
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                int randomPredatorNum = ThreadLocalRandom.current().nextInt(1, 4);
                int randomPreyNum = ThreadLocalRandom.current().nextInt(1, 3);
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Plants plant = new Plants(field, location, t, currentWeather);
                    plants.add(plant);
                }
                else if(rand.nextDouble() <= PREY_CREATION_PROBABILITY) {
                    if(randomPreyNum == 1){
                        Location location = new Location(row, col);
                        Fish fish = new Fish(true, field, location, t, currentWeather, disease);
                        animals.add(fish);
                    }
                    else if(randomPreyNum == 2){
                        Location location = new Location(row, col);
                        SeaBird seaBird = new SeaBird(true, field, location, t, currentWeather, disease);
                        animals.add(seaBird);
                    }
                }
                else if(rand.nextDouble() <= PREDATOR_CREATION_PROBABILITY) {
                    if(randomPredatorNum == 1) {
                        Location location = new Location(row, col);
                        Penguin penguin = new Penguin(true, field, location, t, currentWeather, disease);
                        animals.add(penguin);
                    }
                    else if(randomPredatorNum == 2) {
                        Location location = new Location(row, col);
                        Seal seal = new Seal(true, field, location, t, currentWeather, disease);
                        animals.add(seal);
                    }
                    else if(randomPredatorNum == 3) {
                        Location location = new Location(row, col);
                        Whale whale = new Whale(true, field, location, t, currentWeather, disease);
                        animals.add(whale);
                    }
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
