import java.util.Random;
import java.util.List;

/**
 * Prey animals are eaten by other animals and need to eat plants
 * so as to survive. In our simulation the prey are the 
 * sea birds and fish.
 *
 * @version 2021.02.28 
 */
abstract public class Prey extends Animal
{
    // Characteristics shared by all preys (class variables).

    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey (Field field, Location location, Time t, String weather, Disease disease)
    {
        super(field, location, t, weather, disease);
    }
    
    /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newprey A list to return newly born prey.
     */
    public void act(List<Animal> newPrey)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPrey);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the prey's death.
     */
    abstract public void incrementAge();
    
    abstract public void incrementHunger();
    
    abstract public Location findFood();
    
    /**
     * Check whether or not this prey is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newprey A list to return newly born prey.
     */
    abstract public void giveBirth(List<Animal> newPrey);
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    abstract public int breed();

    /**
     * A prey can breed if it has reached the breeding age.
     * @return true if the prey can breed, false otherwise.
     */
    abstract public boolean canBreed();
}
