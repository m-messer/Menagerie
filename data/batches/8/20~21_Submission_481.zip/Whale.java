import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Whales are one of our predators. They hunt and eat sea birds.
 *
 * @version 2021.02.28 
 */
public class Whale extends Predator
{
    // The age at which a whale can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a whale can live.
    private static final int MAX_AGE = 110;
    // The likelihood of a whale breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single sea bird. In effect, this is the
    // number of steps a whale can go before it has to eat again.
    private static final int SEABIRD_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The whale's age.
    private int age;
    // The whale's food level, which is increased by eating sea birds.
    private int foodLevel;

    /**
     * Create a whale. A whale can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the whale will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Whale (boolean randomAge, Field field, Location location, Time t, String weather, Disease disease)
    {
        super(field, location, t, weather, disease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SEABIRD_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SEABIRD_FOOD_VALUE;
        }
    }

    /**
     * Increase the age. This could result in the whale's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
        
        
    }
    
    /**
     * Make this whale more hungry. This could result in the whale's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for sea birds adjacent to the current location.
     * Only the first live sea bird is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        if (t.isNight() == true){ // ensures that whales can only hunt during the day
            
            return getLocation();
        }
        else {
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof SeaBird) {
                    SeaBird seaBird = (SeaBird) animal;
                    if(seaBird.isAlive()) { 
                        seaBird.setDead();
                        foodLevel = SEABIRD_FOOD_VALUE;         
                        return where;
                    }
                }
                
        }
        return null;
    
        }
        
    }
    
    /**
     * Check whether or not this whale is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWhales A list to return newly born whales.
     */
    public void giveBirth(List<Animal> newWhales)
    {
        // New whales are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        int births;
        boolean breedPossible = false;
        boolean gender = getGender();
        // Checks all adjacent locations to see if it can find a whale of the opposite gender and proceeds to breed if that is the case.
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Whale) {
                Whale whale = (Whale) obj;
                if(whale.getGender() != gender) { 
                    breedPossible = true;                     
                }
            }
        }
        
        
        if (breedPossible = true) {       
            births = breed();       
        }
        else {
            births = 0;
        }
        
        if (!weather.equals("Snow")) //whales cannot breed when it is snowing
        {
            for(int b = 0; b < births && free.size() > 0; b++) 
            {
                Location loc = free.remove(0);
                Whale young = new Whale(false, field, loc, t, weather, disease);
                newWhales.add(young);
            }
        }
    
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A whale can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * This code is used to infect other animals of the same type (ie. whale only infects a whale) 
     * Will also check to see if the disease kills the said animal
     */
    
    public void diseaseSimulation() { 
        Field field = getField();
        if (isInfected() == true) {
            boolean willAnimalDie = disease.willAnimalDie();
            
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object obj = field.getObjectAt(where);
                if(obj instanceof Whale) {
                    Whale whale = (Whale) obj;
                    if(whale.isInfected() == false && disease.infectNewAnimal() == true && whale.isImmune() == false) { 
                        whale.infectAnimal();                     
                    }
                }
            }
            if (willAnimalDie == true) {
                setDead();
            }
            else if (willAnimalDie == false) {
                giveImmunity();
            }
        }
        
    }
    
    
}
