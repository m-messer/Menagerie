import java.util.ArrayList;
import java.util.Random;

/**
 * Weather can change, and it influences the behaviour of some simulated aspects. 
 * Possible weather conditions: Rain, Snow, Fog, Sunshine, Storm
 * Plants can not grow without rain.
 * Sea birds can not eat or breed during snowfall.
 * Whales can not breed during snowfall.
 * Penguins can not hunt when it is sunny.
 * Seals can not breed when it is sunny.
 * Fish can not breed when it is raining.
 * No one can eat in fog.
 * No one can breed in stormy conditions, and only predators can hunt at this time.
 *
 * @version 2021.02.28 
 */
public class Weather
{
    private ArrayList<String> type;
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        type = new ArrayList<>();
        addWeather();
    }

    private void addWeather()
    {
        type.add("Rain");
        type.add("Snow");
        type.add("Fog");
        type.add("Sunshine");
        type.add("Storm");
    }
    
    public String getWeather()
    {
        Random rand = Randomizer.getRandom();
        int index = rand.nextInt(type.size());
        return type.get(index);
    }
}
