import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Penguins are one of our predators. They hunt and eat fish.
 *
 * @version 2021.02.28 
 */
public class Penguin extends Predator
{
   // The age at which a penguin can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a penguin can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a penguin breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single fish. In effect, this is the
    // number of steps a penguin can go before it has to eat again.
    private static final int FISH_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The penguin's age.
    private int age;
    // The penguin's food level, which is increased by eating fish.
    private int foodLevel;

    /**
     * Create a penguin. A penguin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the penguin will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Penguin (boolean randomAge, Field field, Location location, Time t, String weather, Disease disease)
    {
        super(field, location, t, weather, disease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FISH_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FISH_FOOD_VALUE;
        }
    }

    /**
     * Increase the age. This could result in the penguin's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this penguin more hungry. This could result in the penguin's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for fish adjacent to the current location.
     * Only the first live fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if (t.isNight() == true && !weather.equals("Sunshine")) { // penguins can only hunt at night & not when it is sunny
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Fish) {
                    Fish fish = (Fish) animal;
                    if(fish.isAlive()) { 
                        fish.setDead();
                        foodLevel = FISH_FOOD_VALUE;
                        return where;
                    }
                }
            }
            return null;
            }
        else {
            return getLocation();
        }
        
    }
    
    /**
     * Check whether or not this penguin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPenguins A list to return newly born penguins.
     */
    public void giveBirth(List<Animal> newPenguins)
    {
        // New penguins are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        // Checks to see if there is a penguin of the other gender in an adjacent location so that breeding can take place.
        
        
        boolean gender = getGender();
        List<Location> allAdjacentLocations = field.adjacentLocations(getLocation());
        
        int births;
        boolean breedPossible = false;
        
        // Checks all adjacent locations to see if it can find a penguin of the opposite gender and proceeds to breed if that is the case.
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Penguin) {
                Penguin penguin = (Penguin) obj;
                if(penguin.getGender() != gender) { 
                    breedPossible = true;                     
                }
            }
        }
        
        if (breedPossible = true) {       
            births = breed();       
        }
        else {
            births = 0;
        }        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Penguin young = new Penguin(false, field, loc, t, weather, disease);
            newPenguins.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A penguin can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * This code is used to infect other animals of the same type (ie. whale only infects a whale) 
     * Will also check to see if the disease kills the said animal
     */
    public void diseaseSimulation() { 
        Field field = getField();
        if (isInfected() == true) {
            boolean willAnimalDie = disease.willAnimalDie();
            
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object obj = field.getObjectAt(where);
                if(obj instanceof Penguin) {
                    Penguin penguin = (Penguin) obj;
                    if(penguin.isInfected() == false && disease.infectNewAnimal() == true && penguin.isImmune() == false) { 
                        penguin.infectAnimal();                     
                    }
                }
            }
            if (willAnimalDie == true) {
                setDead();
            }
            else if (willAnimalDie == false) {
                giveImmunity();
            }
        }
        
    }
}
