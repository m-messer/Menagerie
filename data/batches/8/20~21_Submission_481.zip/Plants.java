import java.util.List;
import java.util.Random;

/**
 * For our prey animals (sea birds and fish)
 * they do not eat other animals but eat plants 
 * instead. The plants grow at a given rate, but 
 * they do not move. 
 *
 * @version 2021.02.28 
 */
public class Plants
{
    // Whether the plant exists or not.
    private boolean exists;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // The age to which a plant can live.
    private static final int MAX_AGE = 7;
    //The plant's age
    private int age;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    // The maximum number of births.
    private static final int MAX_BIRTHS = 3;
    // Time duration of simulation
    private Time t;
    // Current weather of simulation
    private String weather;

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(Field field, Location location, Time t, String weather)
    {   
        exists = true;
        this.field = field;
        setLocation(location);
        this.t = t;
        this.weather = weather;
        age = 0;
    }
    
    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newpredators A list to return newly born predators.
     */
    public void act(List<Plants> newPlants)
    {
        incrementAge();
        if(exists) {
            reproduce(newPlants);            
        }
    }

    /**
     * Increase the age. This could result in the plants's death.
     */
    private void incrementAge()
    {
       // plants cannot grow during the night & can only grow when it rains
        if (t.isNight() == false && weather.equals("Rain")) {  
            age++;
        if(age > MAX_AGE) {
            remove();
        }}
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    private void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    private Field getField()
    {
        return field;
    }
    
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    private Location getLocation()
    {
        return location;
    }
    
    /**
     * Check whether the plant exists or not.
     * @return true if the plant still exists.
     */
    public boolean isExisting()
    {
        return exists;
    }
    
    /**
     * Indicate that the plant no longer exists.
     * It is removed from the field.
     */
    public void remove()
    {
        exists = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Check whether or not this plant is to reproduce at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     */
    private void reproduce(List<Plants> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plants young = new Plants(field, loc, t, weather);
            newPlants.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_BIRTHS) + 1;
        }
        return births;
    }
}
