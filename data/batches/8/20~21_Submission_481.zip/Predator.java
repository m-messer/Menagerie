import java.util.List;
import java.util.Iterator;

/**
 * Predators are animals that eat other animals.
 * In our simulation the predators are the whales, seals and penguins.
 * This is an abstract class, which other than the 'act' method,
 * only holds abstract methods to be overwritten in subclasses.
 *
 * @version 2021.02.28 
 */
abstract public class Predator extends Animal
{


    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator (Field field, Location location, Time t, String weather, Disease disease)
    {
        super(field, location, t, weather, disease);
    }
    
    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newpredators A list to return newly born predators.
     */
    public void act(List<Animal> newPredators)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPredators);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the predator's death.
     */
    abstract public void incrementAge();

    
    /**
     * Make this predator more hungry. This could result in the predator's death.
     */
    abstract public void incrementHunger();
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    abstract public Location findFood();

    /**
     * Check whether or not this predator is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newpredators A list to return newly born predators.
     */
    abstract public void giveBirth(List<Animal> newpredators);
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    abstract public int breed();

    /**
     * A predator can breed if it has reached the breeding age.
     */
    abstract public boolean canBreed();
}
