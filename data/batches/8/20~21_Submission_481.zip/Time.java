
/**
 * Write a description of class Time here.
 *
 * @version 2021.02.28 
 */
public class Time
{
    // instance variables - replace the example below with your own
    private int numberOfSteps;
    private boolean checkNight = false;
    
    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        // initialise instance variables
        numberOfSteps = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void changeTime()
    {
        // put your code here
        numberOfSteps++;
        
    }
    
    public int getTime()
    {
        return numberOfSteps;
    }
    
    public boolean isNight()
    {
        if (checkNight == false && getTime() == 20){
            checkNight = true;  
            numberOfSteps = 0;
        }
        else if (checkNight == true && getTime() == 20) {
            checkNight = false;
            numberOfSteps = 0;
        }
        return checkNight;
    }
    
    
}
