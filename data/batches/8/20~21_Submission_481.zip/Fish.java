import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Fish are one of our prey animals. They survive on plants
 * and are hunted by sealsand penguins.
 *
 * @version 2021.02.28 
 */
public class Fish extends Prey
{
    // Characteristics shared by all fishs (class variables).

    // The age at which a fish can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a fish can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a fish breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The number of steps a fish can go before it has to eat again 
    private static final int PLANT_FOOD_VALUE = 15; 
    
    // Individual characteristics (instance fields).
    
    // The fish's age.
    private int age;
    // The fish's food level which is increased by eating plants.
    private int foodLevel;

    /**
     * Create a new fish. A fish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the fish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fish (boolean randomAge, Field field, Location location, Time t, String weather, Disease disease)
    {
        super(field, location, t, weather, disease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }

    /**
     * Increase the age.
     * This could result in the fish's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this fish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newfish A list to return newly born fish.
     */
    public void giveBirth(List<Animal> newfish)
    {
        // New fishs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        // Checks to see if there is a fish in an adjacent location of the opposite gender so that breeding may occur
        int births;
        boolean breedPossible;
        boolean gender = getGender();
        List<Location> allAdjacentLocations = field.adjacentLocations(getLocation());
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Fish) {
                Fish fish = (Fish) obj;
                if(fish.getGender() != gender) { 
                    breedPossible = true;                     
                }
            }
        }
        
        if (breedPossible = true) {       
            births = breed();       
        }
        else {
            births = 0;
        }
        
        if (!weather.equals("Rain")) {  // Fish can only breed when it is not raining
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fish young = new Fish(false, field, loc, t, weather, disease);
            newfish.add(young);
        }}
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fish can breed if it has reached the breeding age.
     * @return true if the fish can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Make this fish more hungry. This could result in the fish's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if(weather.equals("Fog")) //fish cannot eat when there is fog
        {
            return null;
        }
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plants) {
                Plants plant = (Plants) animal;
                if(plant.isExisting()) { 
                    plant.remove();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * This code is used to infect other animals of the same type (ie. whale only infects a whale) 
     * Will also check to see if the disease kills the said animal
     */
    public void diseaseSimulation() { 
        Field field = getField();
        if (isInfected() == true) {
            boolean willAnimalDie = disease.willAnimalDie();
            
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object obj = field.getObjectAt(where);
                if(obj instanceof Fish) {
                    Fish fish = (Fish) obj;
                    if(fish.isInfected() == false && disease.infectNewAnimal() == true && fish.isImmune() == false) { 
                        fish.infectAnimal();                     
                    }
                }
            }
            if (willAnimalDie == true) {
                setDead();
            }
            else if (willAnimalDie == false) {
                giveImmunity();
            }
        }
        
    }
}
