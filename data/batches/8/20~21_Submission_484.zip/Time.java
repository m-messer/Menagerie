/**
 * Provide a suitable time for the habitat simulation, identify the night and daytime.
 *
 * @version 01.03.2021 
 */
public class Time
{
    //Interger number that represented for the hour
    private static int hour;
    
    //Interger number that represented for the minutes
    private static int minutes;
    
    //Interger number that represented for the days
    private static int days;
    /**
     * Constructor in order to make the simluation more realistic, we introduced the time to 
     * distinguish between daytime and nighttime.
     * 
     * Create a time system for the habitat simulation
     * @ param hour The hour part for the time system
     * @ param minutes The minutes part for the time system
     * @ param days The days part for the time system
     */
    public Time(int hour, int minutes, int days)
    {
        this.hour = hour;
        this.minutes = minutes;
        this.days = days;
    }
    
    /**
     * Increments the days by one
     */
    public void incrementDay()
    {
        days++;
    }
    public void resetTime()
    {
        hour = 0;
        minutes = 0;
        days = 1;
    }
    /**
     *  returns the variable days as a string.
     *  @return String 
     */
    public String getDaysString()
    {
        return ""+days;
    }
    
     /**
     *  Increments  minutes by 30 after every simulation step, when minutes it equal to 
     *  60, clear the minute to 0 and increment the hour by 1.
     */
    public void incrementMinute()
    {
        minutes = minutes +30 ;
        if(minutes ==60)
        {
            minutes = 0;
            incrementHour();
        }
    }
    
    /**
     * Increments hour by 1, when the number of hour reach to 24, clear the hour to 0 and 
     * increment the day by 1.
     */
    public void incrementHour()
    {
        hour++;
        if(hour == 24)
        {
            hour = 0 ;
            incrementDay();
        }
    }
    
     /**
     * Method returns the number of hours as String
     * @return String
     */
    public static String getHourString()
    {
        if(hour<10)
        {
            return "0"+hour;
        }
        return ""+ hour;
    }
    
    /**
     * Method returns minutes as String
     * @return String
     */
    public static String getMinuteString()
    {
        if(minutes<10)
        {
            return "0"+minutes;
        }
        return ""+ minutes;
    }
    
    /**
     * Method returns the minutes
     * @return the number of minutes
     */
    public static int getMinute()
    {
        return minutes;
    }
    
    /**
     * Method returns hour
     * @return the number of hour
     */
    public static int getHour()
    {
        return hour;
    }
}
    