import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    //The probability that a plant will be created in any given grid position
    private static final double PLANT_CREATION_PROBABILITY = 0.05;
    
    //The probability that a zebra will be created in any given grid position
    private static final double ZEBRA_CREATION_PROBABILITY = 0.03;
    
    //The probability that a lion will be created in any given grid position
    private static final double LION_CREATION_PROBABILITY = 0.01;
    
    //The probability that a leopard will be created in any given grid position
    private static final double LEOPARD_CREATION_PROBABILITY = 0.01;
    
    //The probability that a antelope will be created in any given grid position
    private static final double HYENA_CREATION_PROBABILITY = 0.02;
    
    //The probability that a antelope will be created in any given grid position
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.03;
    
    // List of animals in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    // //Claas field Time
    private Time time;

    // //Class Weather weather
    private Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    
        
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        
        time = new Time(0,0,1);

        weather = new Weather();
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Hyena.class, Color.BLUE);
        view.setColor(Leopard.class, Color.BLACK);
        view.setColor(Antelope.class, Color.RED);
        view.setColor(Lion.class, Color.YELLOW);
        
        
        view.setWeatherText(weather.getWeather());
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Method displays the current time.
     */
    public void incrementTime()
    {
        time.incrementMinute();
        view.setTimeText("Day "+time.getDaysString()+" Time "+time.getHourString()+":"+time.getMinuteString());
    }

    /**
     * Method changes weather when at certain times.
    // */
    public void simulateWeather()
    {
        if(time.getHour() == 4 && time.getMinute()== 0)
        {
            weather.setWeather();
            changeWeather();
        }

        if(time.getHour() == 20 && time.getMinute() == 0)
        {
            weather.setNightWeather();
            changeWeather();
        }
    }
    
    /**
     *  Method displays new weather
     */
    public void changeWeather()
    {
        view.setWeatherText(weather.getWeather());
    } 
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        incrementTime();
        simulateWeather();
        // Provide space for newborn animals.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            if(time.getHour() < 20 && time.getHour() >=4 || organism instanceof Hyena)
            {
                if((weather.getIsRaining() == false)|| organism instanceof Zebra)
                {
                    organism.act(newOrganisms);
                }
            }
            if(! organism.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        weather.setNightWeather();
        time.resetTime();
        view.setTimeText("Day "+time.getDaysString()+" Time "+time.getHourString()+":"+time.getMinuteString());
        changeWeather();
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    organisms.add(plant);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(field,location,rand.nextBoolean());
                    organisms.add(zebra);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(field,location,rand.nextBoolean());
                    organisms.add(lion);
                }
                else if(rand.nextDouble() <= LEOPARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Leopard leopard = new Leopard(field,location,rand.nextBoolean());
                    organisms.add(leopard);
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(field,location,rand.nextBoolean());
                    organisms.add(hyena);
                }
                else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope = new Antelope(field,location,rand.nextBoolean());
                    organisms.add(antelope);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
