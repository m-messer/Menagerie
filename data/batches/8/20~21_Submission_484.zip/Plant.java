import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Plant extends Organism
{
    // Characteristics shared by all rabbits (class variables).

    // The likelihood of a rabbit breeding.
    private static final double GROWING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    private Animal animal;

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * This is what the rabbit does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Organism> newPlants)
    {
        // if(isAlive()){
            // reGrow(newPlants);

        // }
        // else{
            // setDead();
        // }
    }
    
    /**
     * This method will be override the Organism class setDead()
     * This method for keeping the eaten plant wihout remove them,
     * then the plant will be alive again.
     * 
     */
    protected void setDead()
    {
        super.setDead();
        boolean alive = true;
    }
    
     /**
     * Store the initial field of the Plant
     * @return currentField The inital field for the plant.
     */
    protected Field currentField()
    {
        Field currentField = field;
        return currentField;
    }

    /**
     * Store the initial location of the Plant.
     * @return currentLocation The initial location for the plant.
     */
    protected Location currentLocation()
    {
        Location currentLocation = location;
        return currentLocation;
    }
    
    protected void reGrow(List<Organism> newPlants)
    {
        // Field field = getField();
        // List<Location> free = field.getFreeAdjacentLocations(getLocation());

        // int births = breed();
        // for(int b = 0; b < births && free.size() > 0; b++) {
            // Location loc = free.remove(0);
            // Plant plant = new Plant(field, loc);
            // newPlants.add(plant);
        // }
        
        Location loc = currentLocation();
        Field fie = currentField();
        Plant plant = new Plant(fie, loc);
        newPlants.add(plant);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int grows = 0;
        if(rand.nextDouble() <= GROWING_PROBABILITY) {
            grows = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return grows;
    }
}
