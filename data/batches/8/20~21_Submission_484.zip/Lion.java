import java.util.List;
/**
 * A simple model of a Lion.
 * Lions age, move, eat zebras, and die.
 *
 * @version 01.03.2021 
 */
public class Lion extends Animal
{
    // The age at which an animal can start to breed.
    private static int BREEDING_AGE = 4;

    // The age to which an animal can live.
    private static int MAX_AGE = 40;

    // The likelihood of an animal breeding.
    private double BREEDING_PROBABILITY = 0.2;

    // The likelihood of an animal meeting.
    private double MEETING_PROBABILITY = 0.6;

    // The maximum number of births.
    private int MAX_LITTER_SIZE = 4;

    // The food value of a single prey. In effect, this is the
    // number of steps a predator can go before it has to eat again.
    private int FOOD_VALUE = 20;

    // The food source class
    private Class FOOD_CLASS = Zebra.class;
    
    //The breeding class
    private Class BREEDING_CLASS = Lion.class;
    
    //The Name of steps on plant class
    private Class STEP_ON_PLANT_CLASS = Plant.class;
    /**
     *
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param randomAge If true, the lion will have random age and hunger level.
     */
    public Lion(Field field, Location location,boolean randomAge)

    {
        super(field,location);
        if(randomAge) {
            setAge(getRandom().nextInt(getMaxAge()));
            setFoodLevel(getRandom().nextInt(FOOD_VALUE));
            setRandomGender();
        }
        else{
            setAge(0);
            setFoodLevel(FOOD_VALUE);
            setRandomGender();
        }
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * zebra. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLions A list to return newly born lions.
     */
    public void act(List<Organism> newLions)
    {
        super.incrementAge();
        super.incrementHunger();
        if(isAlive()){  
            if(meet()){
                giveBirth(newLions);
            }
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(location);
                showStarvation();
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                //Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    protected Animal getNewBornAnimal()
    {
        Animal youngLion = new Lion(field,location,false);
        return youngLion;
    }
    
    /**
     * @return the food value;
     */
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * @return the food source class name;
     */
    protected Object getFoodClass()
    {
        return FOOD_CLASS;
    }

    /**
     * @return the max age of the lion.
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * @return the breeding age of the lion.
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @return the class of Lion for breeding identification.
     */
    protected Object getBreedClass()
    {
        return BREEDING_CLASS;
    }

    /**
     * @return the breeding probability of the lion.
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
    // * @return the meeting probability of the lion.
    // */
    protected double getMeetingProbability(){
        return MEETING_PROBABILITY;
    }

    /**
     * @return the maximum number of the oppspring of the lion.
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the class of the plant of Lion steps on.
     */
    protected Object getStepOnPlantClass()
    {
        return STEP_ON_PLANT_CLASS;
    }

    /**
     * Increase the age. This could result in the lion's death.
     */
    protected void incrementAge()
    {
        super.incrementAge();
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make the lion more hungry. This could result in the lion's death.
     */
    protected void incrementHunger()
    {
        super.incrementHunger();
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
}