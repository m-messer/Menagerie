import java.util.Random;
/**
 * Write a description of class Weather here.
 *
 * @version (a version number or a date)
 */
public class Weather
{
    // instance variables - replace the example below with your own
    private boolean isRaining;
    
    private boolean isSunny;
    
    private boolean isCloudy;
    
    private static final Random rand = Randomizer.getRandom();
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        // initialise instance variables
        setNightWeather();
        getWeather();
    }
    
    /**
     * Sets each variable when its night.
     * @return No return value
     */
    public void setNightWeather()
    {
        isSunny = false;
        isRaining = rand.nextBoolean();
        isCloudy = rand.nextBoolean();
    }
    
    /**
     *  sets each variable when its day.
     *  @return No return value
     */
    public void setWeather()
    {
        isRaining = rand.nextBoolean();
        isSunny = rand.nextBoolean();
        isCloudy = rand.nextBoolean();
    }
    
    /**
     * Method returns the weather as a String.
     * @return String
     */
    public String getWeather()
    {
        if(isRaining == true)
        {
            return "Rainy";
        }
        else if(isSunny == true)
        {
            return "Sunny";
        }
        else
        {
            return "Cloudy";
        }
    }
    
    /**
     *  Method returns a boolean to check whether it is raining or not.
     *  @return boolean
     */
    public boolean getIsRaining()
    {
        return isRaining;
    }
    
    /**
     * Method returns a boolean to check whether it is sunny or not.
     */
    public boolean getIsSunny()
    {
        return isSunny;
    }
    
    /**
     * Method returns a boolean to check whether it is cloudy or not.
     */
    public boolean getIsCloudy()
    {
        return isCloudy;
    }
}
