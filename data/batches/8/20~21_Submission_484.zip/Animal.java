import java.util.Iterator;
import java.util.List;
import java.util.Random;
//import java.util.HashMap;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 01.03.2021
 */
public abstract class Animal extends Organism
{
    //The animal's age.
    private int age;

    //The animal's food level which is increased by eating food.
    protected int food_level;

    // A shared random number generator to control breeding.
    //private Random rand = Randomizer.getRandom();

    // //The hashmap foodSource is store the animal's food source
    // private HashMap<String,Class> foodSource;
    
    private Plant plant;

    //The animal's gender.
    private boolean isMale;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field,location);
        //age = 0;
        this.isMale = isMale;
        //foodSource = new HashMap <>();
    }
    
    
    
    /**
     * Use this boolean to aviod eating too much food
     * (food level larger or equal to 3 times of food value)
     * @return boolean for control animal find too much food.
     */
    protected boolean stopEating()
    {
        if(food_level >=3*getFoodValue()){
            return true;
        }
        return false;
    }
    
    
    /**
     * Look for food adjacent to the current location.
     * Only the first live food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location>adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext() && !stopEating()){
            Location where = it.next();
            Object Organism = getFoodClass();
            Object food = field.getObjectAt(where);
            Object trample = getStepOnPlantClass();
            if(food instanceof Organism){
                Organism organism  = (Organism) food ;
                if(organism.isAlive()) { 
                    if(Organism != trample) { 
                        organism.setDead();
                        //organism.setStepOn();
                        return where;
                    }
                    else{
                        organism.setDead();
                        getFoodLevel();
                        return where;
                    }
                    
                }
                
            }
        }
        return null;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= getBreedingProbability()) {
            births = getRandom().nextInt(getMaxAge()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age and there is same species 
     * but request different gender.
     * @return whether true or false to decide the animal's breeding action.
     */
    protected boolean canBreed()
    {
        boolean canItBreed = false;
        if((getAge() >= getBreedingAge()))  {
            canItBreed = true;
        }
        return canItBreed;
    }

    /**
     * Return the random gender for the animal.
     */
    protected void setRandomGender()
    {
        Random random = new Random();
        isMale = random.nextBoolean();
    }
    
    /**
     * Look for same species near by. It has chance to get breed.
     * Only meet for one from the adjacent position once.
     * @return whether true or false to desicde aniamls are 
     * meet successfully or not.
     */
    protected boolean meet()
    {
        boolean meetSuccessfully = false;
        Field field = getField();
        List<Location>adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object sameSpecies = field.getObjectAt(where);

            Object Organism = getBreedClass();

            if(sameSpecies instanceof Organism){
                Organism organism  = (Organism) sameSpecies;
                if(getRandom().nextDouble() >= getMeetingProbability())
                {
                    meetSuccessfully  = true;
                    canBreed();
                }
            }
        }
        return meetSuccessfully ;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrganisms A list to return newly born organisms.
     */
    protected void giveBirth(List<Organism> newOrganisms)
    {
        Field field = getField();
        
        Object Animal = getBreedClass();
        Animal organism = getNewBornAnimal();
        
        List<Location> free = getField().getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Location location = loc;
            newOrganisms.add(organism);
        }
    }

    /**
     * @return the plant by stepping on
     */
    abstract Object getStepOnPlantClass();

    /**
     * @return the animal's breeding age
     */
    abstract int getBreedingAge();

    /**
     * @return the animal's breeding class name
     */
    abstract Object getBreedClass();
    
    /**
     * @return the animal's food source class name.
     */
    abstract Object getFoodClass();
    
    /**
     * @return the Max age of the animal can live.
     */
    abstract int getMaxAge();

    /**
     * @return the probability of the animal breeding.
     */
    abstract double getBreedingProbability();

    /**
     * @return the probability of the animal meeting.
     */
    abstract double getMeetingProbability();

    /**
     * @return the animal's new born animal class
     */
    abstract Animal getNewBornAnimal();

    /**
     * @return the maximum number of oppsprings can breed.
     */
    abstract int getMaxLitterSize();

    /**
     * @return the aniaml's singele value of food energy. 
     */
    abstract int getFoodValue();
    
    /**
     * Set the animal's initial food level.
     * @param food_level A food_level you want to set for the animal.
     */
    protected void setFoodLevel(int initFoodValue)
    {
        food_level = initFoodValue;
    }
    
    /**
     * If the animal did find any food, update the food level plus the food value.
     * else return the current food level
     * @return food_level 
     */
    protected int getFoodLevel()
    {
        return food_level = food_level + getFoodValue();
    }

    /**
     * Increment the animal's food level.
     */
    protected void incrementFoodLevel()
    {
        food_level++;
    }

    /**
     * Decrement the animal's food level.
     * This may cause animal dead if the level is is low.
     */
    protected void incrementHunger()
    {
        food_level--;
    }
    
    protected void showStarvation()
    {
        if(getFoodLevel() <= 0){
            setDead();
        }
    }
    
    /**
     * Set the animal's age.
     * @param age An age you want to set for the animal.
     */
    protected void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * Get animal's age.
     * @return the age.
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Increment the animal's age.
     * This may cause animal dead if reach to it max age.
     */
    protected void incrementAge()
    {
        age++;
    }
}

