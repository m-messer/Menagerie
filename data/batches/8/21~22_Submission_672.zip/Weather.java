/**
 * A class representing weather.
 *
 * 
 * @version 2022.02.28
 */
enum Weather {
    SUNNY, RAIN, FOG    
}
