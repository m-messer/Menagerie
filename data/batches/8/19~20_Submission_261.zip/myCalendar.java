import java.util.*;
/**
 * Create a calendar which keeps track of day and night.
 *
 */
public class myCalendar
{
    private boolean isDay;
    private Calendar cal;
    
    /**
     * Constructor for objects of class Calendar
     */
    public myCalendar()
    {
       cal = cal.getInstance();
       
       if(5<= cal.get(Calendar.HOUR_OF_DAY) && cal.get(Calendar.HOUR_OF_DAY) < 18)
       {
           isDay = true;
       }
       
       else
       {
           isDay = false;
       }
    }
    
    public void addHour()
    {
        cal.add(Calendar.HOUR_OF_DAY, 1);
        
        if( 5 <= cal.get(Calendar.HOUR_OF_DAY) && cal.get(Calendar.HOUR_OF_DAY) < 18)
        {
            isDay = true;
        }
        
        else
        {
            isDay = false;
        }
    }
    
    
    public boolean IsDay()
    {
        return isDay;
    }


}
