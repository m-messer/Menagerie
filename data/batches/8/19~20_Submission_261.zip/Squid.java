import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class that creates a squid object 
 *
 * 
 */
public class Squid extends Animal
{
    // characteristics shared by all squids(class variables)
    
    // the age at which a squid can start to breed
    private static final int BREEDING_AGE= 5;
    // the oldest a squid can be, its max age
    private static final int MAX_AGE = 65;
    // likelihood of a squid breeding
    private static final double BREEDING_PROBABILITY = 0.30;
    // the maximum number of births
    private static final int MAX_LITTER_SIZE = 12;
    // shared random number generator to control breeding
    private static final Random rand = Randomizer.getRandom();
    // probability of the gender being male
    private static final double GENDER_PROBABILITY = 0.50;
    
    //individual characteristics (instance fields)
    // the squids age
    private int age;
    //squids gender
    private boolean male;


    /**
     * Creates a new squid
     * a squid may be created with age 0 (newly born) or it may be given a random age
     * 
     * @ param randAge If true the squid will have a random age
     * @ param field The field currently occupied
     * @ param location The location within the field
     */
    public Squid(boolean randAge, Field field, Location location)
    {
        super(field,location);
        age=0;
        male= true;
        if(randAge)
        {
            age = rand.nextInt(MAX_AGE);
        }
        if(rand.nextDouble()>= GENDER_PROBABILITY)
        {
            male = false;
        }
    }
    /**
     * 
     */
    public boolean getGender()
    {
        return male;
    }
    /**
     * This is what the squid will be doing most of the time
     * it either moves around or
     * it breeds or
     * it dies
     */
    public void act(List<Animal>newSquids)
    {
        incrementAge();
        if(isAlive())
        {
            if(findMate()){
                giveBirth(newSquids);
            }
            
            //try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            
            if(newLocation != null)
            {
                setLocation(newLocation);
            }
            
            else{
                //Overcrowding.
                setDead();
            }
        
    
        }   
    }
    
    
    /**
     * Look for squid adjacent to the current locatioon.
     * Only the first live opposite gender squid is used as a mate.
     * Return True if there is an opposite gender squid in an adjacent location
     */
    private boolean findMate(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squid){
                Squid squid = (Squid) animal;
                if(squid.isAlive() && male!= squid.getGender()){
                    return true;
                }
            }
            else{
                return false;
            }
        }
        return false;
    }
    
    /**
     * Check whether or not the squid is to give birth at this step.
     * new births will be made into free adjacent locations
     * @param newSquids A list to return newly born squids
     */
    public void giveBirth(List<Animal> newSquids)
    {
        //NewTurtles are born into adjacent locations.
        //get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b= 0; b<births && free.size() > 0; b++)
        {
            Location loc = free.remove(0);
            Squid young = new Squid(false, field, loc);
            newSquids.add(young);
        }
    }
    
    /**
     *  Increases the age of the squid
     *  this could result in the eventual death of the squid if the age exceeds
     *  a squids MAX_AGE
     */
    public void incrementAge()
    {
        age++;
        if(age> MAX_AGE)
        {
            setDead();
        }
    
    }
    
    
    /**
     * Generate a number representing the number of births,
     * if it can breed
     * @return the number of births (may be zero)
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble()<= BREEDING_PROBABILITY)
        {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A squid can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    
    }

}
