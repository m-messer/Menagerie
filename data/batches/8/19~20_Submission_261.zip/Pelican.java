import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Create a pelican object
 *
 */
public class Pelican extends Animal
{
    //Characteristics shared by all Pelican (class variables).
    
    //the age at which a pelican can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a pelican can live.
    private static final int MAX_AGE = 24;
    //the likelihood of a pelican breeding.
    private static final double BREEDING_PROBABILITY = 0.18;
    //the maximum number of births.
    private static final int MAX_LITTER_SIZE= 4;
    //The food value of a single turtle. In effect, this is the
    //number of steps a pelican can go before it has to eat again.
    private static final int TURTLE_FOOD_VALUE = 5;
    //A shared randon number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //the likelihood of the gender being male
    private static final double GENDER_PROBABILITY = 0.50;
    
    
    //Individual characteristics(instance fields).
    //The pelican's age.
    private int age;
    //The pelican's food level, which is increased by eating turl.
    private int foodLevel;
    // The pelican's gender
    private boolean male;
    
    /**
     * Create a pelican. A pelican can be created as a new born(age zero
     * and not hungry) or with a random age and foodLevel.
     * 
     * @param randAge if true, the pelican will have random age 
     * and hunger level.
     * 
     * @param field The field currently occupied.
     * 
     * @param location The location within the field.
     */
    
    public Pelican(boolean randAge, Field field, Location location)
    {
        super(field, location);
        male = true;
        if(randAge)
        {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(TURTLE_FOOD_VALUE);
        }
        
        else
        {
            age = 0;
            foodLevel = TURTLE_FOOD_VALUE;
            
        }
        
        if(rand.nextDouble()>= GENDER_PROBABILITY)
        {
            male = false;
        }
    }
    
    public boolean getGender()
    {
        return male; 
    }

    /**
     * This is what the pelican does most of the time: it hunts for
     * turtles. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newPelicans A list to return newly born Pelicans.
     */
    public void act(List<Animal> newPelicans)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive()) 
        {
            
        if(super.getField().getIsDay()==true)
        {
            System.out.println("is acting");
            
            if(findMate())
            {
                giveBirth(newPelicans);
            }
            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
        }
        else if(super.getField().getIsDay()== false)
        {
            System.out.println("is not acting");
            
        }
        
        }
    }
    
    /**
     * Increases the age. This could result in the pelican's death
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE)
        {
            System.out.println("pelican is dying of old age");
            setDead();
        }
    }
    
    
    
    /**
     * Make this pelican hungrier. this could result in the pelican's death
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0)
        {
            System.out.println("pelican is dying of hunger");
            setDead();
        }
    }
    
    /**
     * Look for pelicans adjacent to the current location.
     * Only the first live opposite gender pelican is used as 
     * mate.
     * return True if there is a opposite gender pelican in an 
     * adjacent location
     */
    private boolean findMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Pelican)
            {
                Pelican pelican = (Pelican) animal;
                if(pelican.isAlive() && male!= pelican.getGender())
                {
                    return true;
                }
            }
            
            else
            {
                return false;
            }
            
        }
        return false;
    }    
    
    /**
     * Look for the turtle adjacent to the current location.
     * Only the first live turtle is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location>it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Turtle)
            {
                Turtle turtle = (Turtle) animal;
                
                if(turtle.isAlive())
                {
                    turtle.setDead();
                    foodLevel = TURTLE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    
    /**
     * Check whether or not this pelican is to give birth at this step.
     * new births will be made into free adjacent locations.
     * @param newPelicans A  list to return newly born pelicans.
     */
    private void giveBirth(List<Animal> newPelicans)
    {
        // new pelicans are born into adjacent locations.
        //get a list of adjacent free locations
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b< births && free.size()> 0; b++)
        {
            Location loc = free.remove(0);
            Pelican young= new Pelican(false, field, loc);
            newPelicans.add(young);
            
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)
        {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A shark can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    
    
}
