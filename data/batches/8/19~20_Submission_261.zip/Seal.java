import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Create a seal object
 *
 */
public class Seal extends Animal
{
    //Characteristics shared by all Seals (class variables).
    
    //the age at which a seal can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a seal can live.
    private static final int MAX_AGE = 26;
    //the likelihood of a seal breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    //the maximum number of births.
    private static final int MAX_LITTER_SIZE= 2;
    //The food value of a single squid. In effect, this is the
    //number of steps a seal can go before it has to eat again.
    private static final int SQUID_FOOD_VALUE = 6;
    //A shared randon number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    
    //Individual characteristics(instance fields).
    //The seals age.
    private int age;
    //The seal's food level, which is increased by eating squid.
    private int foodLevel;
    
    

    /**
     * Create a seal. A seal can be created as a new born(age zero
     * and not hungry) or with a random age and foodLevel.
     * 
     * @param randAge if true, the seal will have random age 
     * and hunger level.
     * 
     * @param field The field currently occupied.
     * 
     * @param location The location within the field.
     */
    public Seal(boolean randAge, Field field, Location location)
    {
        super(field, location);
        if(randAge)
        {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SQUID_FOOD_VALUE);
        }
        else
        {
            age = 0;
            foodLevel = SQUID_FOOD_VALUE;
        }
        
    }

    /**
     * This is what the Seal does most of the time: it hunts for
     * squid. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSeals A list to return newly born Seals.
     */
    public void act(List<Animal>newSeals)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSeals);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        
    }
    
    /**
     * Increases the age. This could result in the Seal's death
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE)
        {
            setDead();
        }
    }
    
    /**
     * Make this seal hungrier. This could result in the seal's
     * death
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <=0 )
        {
            setDead();
        }
    }
    
    
    /**
     * Look for squid adjacent to the current location.
     * Only the first live squid is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location>it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squid)
            {
                Squid squid = (Squid) animal;
                
                if(squid.isAlive())
                {
                    squid.setDead();
                    foodLevel= SQUID_FOOD_VALUE;
                    return where;
                }
            }
            
        }
        return null;
    }
    
    /**
     * Check whether or not this seal is to giv e birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSeals A list to return newly born seals.
     */
    private void giveBirth(List<Animal> newSeals)
    {
        // new seals are born into adjacent location.
        // get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b< births && free.size() > 0; b++)
        {
            Location loc = free.remove(0);
            Seal young = new Seal(false, field, loc);
            newSeals.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A seal can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    
}