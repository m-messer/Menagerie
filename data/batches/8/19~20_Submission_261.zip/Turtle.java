import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Creates a turtle object
 *
 */
public class Turtle extends Animal
 {
    //Characteristics shared by all turtles 
    
    // The age at which a turtle can breed
    private static final int BREEDING_AGE = 3;
    // the max age a turtle can reach
    private static final int MAX_AGE = 9;
    // the likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // the maximum number of births
    private static final int MAX_LITTER_SIZE = 4;
    // a shared random number generator to control breeding
    private static final Random rand = Randomizer.getRandom();
    //the likelihood of the gender being male
    private static final double GENDER_PROBABILITY = 0.50;
    
   
    
    
    //The turtles age
    private int age;
    //the turtles gender
    private boolean male;

    /**
     * Constructor for objects of class turtle, create a new turtle.
     * age can be zero or it is set to a random age
     * 
     * @Param randomAge if true, the rabbit will have a random age.
     * @Param field the Field currently occupied.
     * @Param location the Location within the field
     */
    public Turtle(boolean randAge, Field field, Location location)
    {
        super(field, location);
        age= 0;
        male = true;
        if(randAge){
            age = rand.nextInt(MAX_AGE);
        }
        if(rand.nextDouble()>= GENDER_PROBABILITY){
            male= false;
        }
    }
    
    public boolean getGender(){
        return male; 
     }
    
    /**
     * This is what the turtle does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newTurtles A list to return newly born turtles.
     */    
    public void act(List<Animal> newTurtles)
    {
        incrementAge();
        if(isAlive()) {
            if(super.getField().getIsDay()==true)
            {
            if(findMate()){
                giveBirth(newTurtles);
            }
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null){
                setLocation(newLocation);
            }
            else{
                //Overcrowding.
                setDead();
            }
            }
            
            
            else if(super.getField().getIsDay()==false)
            {
                if(findMate())
                {
                    giveBirth(newTurtles);
                }
            }
        }
    }
    
    /**
     * Increases the age
     * Could result in the turtles death
     */
    public void incrementAge(){
        age++;
        if(age>MAX_AGE){
            setDead();
        }
    }
    
    
    /**
     * Look for turtles adjacent to the current location.
     * Only the first live opposite gender turtles is used as 
     * mate.
     * return True if there is a opposite gender turtle in an 
     * adjacent location
     */
    private boolean findMate(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Turtle){
                Turtle turtle = (Turtle) animal;
                if(turtle.isAlive() && male!= turtle.getGender()){
                    return true;
                }
            }
            else{
                return false;
            }
        }
        return false;
    }
     
    /**
     * check whether or not the turtle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @Param newTurtles, a list to return newly born turtles
     */
     private void giveBirth(List<Animal> newTurtles){
        //new Turtles are born into adjacent locations.
        //Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b<births && free.size() > 0; b++){
            Location loc = free.remove(0);
            Turtle young = new Turtle(false, field, loc);
            newTurtles.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @Return the number of births(may be zero).
     */
    private int breed(){
        int births = 0;
        if(canBreed()&& rand.nextDouble()<= BREEDING_PROBABILITY){
            births = rand.nextInt(MAX_LITTER_SIZE)+1;
        }
        return births;
    }
    
    /**
     * A turtle can breed if it has reached the breeding age.
     * @return true if the turtle can breed, false otherwise.
     */    
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}