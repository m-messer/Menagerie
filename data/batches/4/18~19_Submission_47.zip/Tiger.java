import java.util.Iterator;
import java.util.List;

/**
 * A simple model of a tiger.
 * tiger's age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Tiger extends Animal {
    // Characteristics shared by all tigers (class variables).

    // The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a tiger can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single item of food.
    private static final int FOOD_VALUE = 7;
    // the quality of this animals eyesight.
    private static final double EYE_SIGHT = 0.8;

    public Tiger(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
    }

    /**
     * @return a tigers max age.
     */
    public int maxAge() {
        return MAX_AGE;
    }

    /**
     * Return the Tiger's breeding age.
     *
     * @return The Tiger's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the Tiger's max litter.
     *
     * @return The Tiger's max litter.
     */
    public int getMaxLitter() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the Tiger's breeding probability.
     *
     * @return The Tiger's breeding probability.
     */
    public double getBreedingProb() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Add newborns to the list of all life forms
     * Boolean randomAge false, newborns are aged zero.
     * @param location the location of this animal
     * @param newPredators a list to add new animals to.
     */
    public void addYoung(List<LifeForm> newPredators, Location location) {
        newPredators.add(new Tiger(false, getField(), location));
    }

    /**
     * Check if the animal is Tiger's food or not.
     *
     * @param animal the animal being checked
     * @return true if it's an antelope.
     */
    public boolean isFood(Object animal) {
        if (animal instanceof Antelope) {
            return true;
        }
        return false;
    }

    /**
     * Tigers can store unlimited food and can hunt in a wider area.
     * @return the new Location for this Tiger to occupy.
     */
    public Location findFood() {
        // Iterate through a list of adjacent locations
        Iterator<Location> it = adjacentIterator();
        Location newLoc = null;
        while(it.hasNext()) {
            Location location = it.next();
            // create an iterator for the adjacent locations of each adjacent location.
            Iterator<Location> it2= adjacentIterator(location);
            while (it2.hasNext()) {
                Location where = it2.next();
                Object object = getField().getObjectAt(where);
                // check if an object is food.
                if (canBeEaten(object)) {
                    // if so, consume.
                    consume(object);
                    increaseFoodLevel(FOOD_VALUE);
                    newLoc = where;
                }
            }
        }
        return newLoc;
    }

    /**
     * Return the Tiger's food value.
     *
     * @return The Tiger's food value.
     */
    public int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * check if an object is a Tiger.
     *
     * @param object the object being checked
     * @return true if the object is a Tiger
     */
    public boolean sameSpecies(Object object) {
        if (object instanceof Tiger) {
            return true;
        }
        return false;
    }

    /**
     * check the animals eye sight.
     * @return the animals eye sight.
     */
    @Override
    public double getEyeSight() {
            return EYE_SIGHT;
    }
}
