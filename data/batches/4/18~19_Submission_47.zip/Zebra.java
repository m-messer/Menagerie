import java.util.List;

/**
 * A simple model of a zebra.
 * Zebras age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Zebra extends Animal
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // the value of each item of food to a zebra.
    private static final int FOOD_VALUE = 5;

    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra (boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Return the Zebra's breeding age.
     * @return The Zebra's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the Zebra's breeding probability.
     * @return The Zebra's breeding probability.
     */
    public double getBreedingProb() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the Zebra's max litter.
     * @return The Zebra's max litter.
     */
    public int getMaxLitter() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Add newborns to the list of all life forms
     * Boolean randomAge false, newborns are aged zero.
     * @param location the location of this animal
     * @param newZebra a list to add new animals to.
     */
    public void addYoung(List<LifeForm> newZebra, Location location) {
        newZebra.add(new Zebra(false, getField(), location));
    }
    
    /**
     * Check if the animal is zebra's food or not.
     * If it's a plant, return true.
     */
    public boolean isFood(Object object) {
        if(object instanceof Plant) {
            return true;
        }
        return false;
    }
    
    /**
     * Return the Zebra's max age.
     * @return The Zebra's max age.
     */
    public int maxAge() {
        return MAX_AGE;
    }

    public int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * check if an object is a zebra.
     * @param object the object
     * @return true if it is a zebra.
     */
    @Override
    public boolean sameSpecies(Object object) {
        if(object instanceof Zebra){
            return true;
        }
        return false;
    }
}
