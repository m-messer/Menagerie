import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * This is an abstract class representing a life-form.
 * all life-forms have an age and die.
 * They all exist in a particular location in a particular field.
 */
public abstract class LifeForm {

    // Whether the LifeForm is alive or not.
    private boolean alive;
    // The LifeForm's field.
    private Field field;
    // The LifeForm's position in the field.
    private Location location;
    // the LifeForm's age
    private int age;
    // A shared random number generator to control reproduction.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Construct a LifeForm. a new life form can either have a random age or start at age 0.
     * Every Life form starts at a specific Location on the field.
     * @param randomAge should this LifeForm start with a random age or not
     * @param field the field this life form is in
     * @param location the location of this life form in the field.
     */
    public LifeForm(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        if(randomAge) {
            age = rand.nextInt(maxAge());
        }
        else {
            age = 0;
        }
    }

    public abstract void act(List<LifeForm> newLife, Environment environment);

    /**
     * Check whether the LifeForm is alive or not.
     * @return true if the LifeForm is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the LifeForm is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the LifeForms's location.
     * @return The LifeForm's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the LifeForm at the new location in the given field.
     * @param newLocation The LifeForm's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the LifeForm's field.
     * @return The LifeForm's field.
     */
    protected Field getField()
    {
        return field;
    }

    public void incrementAge() {
        age++;
        if(age > maxAge()) {
            setDead();
        }
    }

    /**
     * Create an iterator through a list of adjacent locations
     * @return the Iterator of locations.
     */
    public Iterator<Location> adjacentIterator() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        return it;
    }

    /**
     * return the random number generator rand
     * @return
     */
    public Random getRand() {
        return rand;
    }

    /**
     * @return the age of the LifeForm
     */
    public int getAge() {
        return age;
    }

    public abstract int maxAge();

}