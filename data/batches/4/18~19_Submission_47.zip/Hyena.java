import java.util.List;

/**
 * A simple model of a hyena.
 * Hyena age, move, eat, and die.
 */
public class Hyena extends Animal
{
    // Characteristics shared by all hyenas (class variables).

    // The age at which a hyena can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a hyena can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single item of food.
    private static final int FOOD_VALUE = 9;
    // the quality of this animals eyesight.
    private static final double EYE_SIGHT = 0.7;
    
    /**
     * Create a new hyena. A hyena may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the hyena will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location){
        super(randomAge, field, location);
    }

    /**
     * Return the Hyena's max age.
     * @return The Hyena's max age.
     */
    public int maxAge(){
        return MAX_AGE;
    }

    /**
     * Return the Hyena's breeding age.
     * @return The Hyena's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the Hyena's max litter.
     * @return The Hyena's max litter.
     */
    public int getMaxLitter() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the Hyena's breeding probability.
     * @return The Hyena's breeding probability.
     */
    public double getBreedingProb() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Add newborns to the list of all life forms
     * Boolean randomAge false, newborns are aged zero.
     * @param location the location of this animal
     * @param newPredators a list to add new animals to.
     */
    public void addYoung(List<LifeForm> newPredators, Location location){
        newPredators.add(new Hyena(false, getField(), location));
    }

    /**
     * Check if the animal is hyena's food or not.
     * @param animal the animal being checked
     * @return true if it's a zebra
     */
    public boolean isFood(Object animal) {
        if(animal instanceof Zebra) {
            return true;
        }
        return false;
    }
    
    /**
     * Return the Hyena's food value.
     * @return The Hyena's food value.
     */
    public int getFoodValue(){
        return FOOD_VALUE;
    }

    /**
     * check if an object is a hyena.
     * @param object the object being checked
     * @return true if the object is a hyena
     */
    public boolean sameSpecies(Object object) {
        if(object instanceof Hyena) {
            return true;
        }
        return false;
    }

    /**
     * Hyena can eat dead animals as well as live ones.
     * @param object the possible food.
     * @return whether the object is food for the hyena.
     */
    @Override
    public boolean canBeEaten(Object object) {
        if(isFood(object)) {
            return true;
        }
        return false;
    }

    /**
     * check whether the animal is awake
     * @param isDay true if it is day, false if it is night.
     * @return true, the hyena can hunt at night as well.
     */
    public boolean isAwake(boolean isDay) {
        return true;
    }

    /**
     * check the animals eye sight.
     * @return the animals eye sight.
     */
    public double getEyeSight() {
        return EYE_SIGHT;
    }
}
