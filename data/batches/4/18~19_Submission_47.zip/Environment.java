/**
 * this represents the the environment of the field.
 * it keeps track of whether it is day or night, and the water level.
 * different animals act differently at different times in the day
 * and plants need high water levels to survive. Water levels are replenished by rain.
 *
 */
public class Environment {
    private boolean isDay;
    private int waterLevel;
    private Weather weather;
    private double visibility;
    private int time;

    /**
     * create a new environment.
     */
    public Environment() {
        time = 0;
        isDay = true;
        waterLevel = 30;
        weather = new Weather();
        visibility = 1;
    }

    /**
     * change the environment each round
     */
    public void change(){
        time++;
        setDay(time);
        decrementWaterLevel();
        // Every day, change the weather
        if (time == 1) {
            changeWeather();
            changeWaterLevel(weather.waterLevelChange());
        }
        setVisibility(weather.getVisibility());
    }

    /**
     * @return the time.
     */
    public int getTime(){
        return time;
    }

    /**
     * create a String of the time to be printed.
     * @return the time String
     */
    public String getTimeString(){
        time = time%8;
        int actualTime = time*3;
        if(time >= 0 && time < 4){
            return actualTime%12+1 + "am";
        }
        else{
            return actualTime%12+1 + "pm";
        }
    }

    /**
     * @return true if it is day.
     */
    public boolean isDay() {
        return isDay;
    }

    /**
     * decrease the waterLevel of the environment by one.
     */
    public void decrementWaterLevel() {
        waterLevel --;
    }

    /**
     * @return the waterLevel.
     */
    public int getWaterLevel() {
        return waterLevel;
    }

    /**
     * set th environment to day or night according to the time.
     * @param time the time.
     */
    public void setDay(int time) {
        if (time > 2 && time <= 7 ) {
            isDay = true;
        }
        else {
            isDay = false;
        }
    }

    /**
     * change the waterLevel by a certain amount
     * @param waterLevel the amount to change the waterLevel by. Can be negative.
     */
    public void changeWaterLevel(int waterLevel) {
        this.waterLevel += waterLevel;
    }

    /**
     * @return the weather.
     */
    public String getWeather() {
        return weather.getWeather();
    }

    /**
     * Affect a change in weather
     */
    public void changeWeather(){
        weather.changeWeather();
    }

    /**
     * @return the visibility.
     */
    public double getVisibility() {
        return visibility;
    }

    /**
     * set the visibility to a new amount.
     * @param visibility the new visibility value.
     */
    public void setVisibility(double visibility) {
        this.visibility = visibility;
    }

    /**
     * reset the environment to its starting setting.
     */
    public void reset() {
        time = 0;
        visibility = 1;
        waterLevel = 30;
        changeWeather();
    }
}
