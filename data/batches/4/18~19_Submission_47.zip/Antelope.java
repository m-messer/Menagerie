import java.util.List;

/**
 * A simple model of an antelope.
 * Antelopes age, move, eat, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Antelope extends Animal
{
    // Characteristics shared by all antelopes (class variables).

    // The age at which an antelope can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which an antelope can live.
    private static final int MAX_AGE = 70;
    // The likelihood of an antelope breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // the value of each item of food to this animal
    private static final int FOOD_VALUE = 5;

    /**
     * Create a new antelope. An antelope may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Antelope (boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Return the Antelope's breeding age.
     * @return The Antelope's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the Antelope's breeding probability.
     * @return The Antelope's breeding probability.
     */
    public double getBreedingProb() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the Antelope's max litter.
     * @return The Antelope's max litter.
     */
    public int getMaxLitter() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Add newborns to the list of all life forms
     * Boolean randomAge false, newborns are aged zero.
     * @param location the location of this animal
     * @param newAntelopes a list to add new animals to.
     */
    public void addYoung(List<LifeForm> newAntelopes, Location location) {
        newAntelopes.add(new Antelope(false, getField(), location));
    }
    
    /**
     * Check if the animal is antelope's food or not.
     * If it's a plant, return true.
     */
    public boolean isFood(Object object) {
        if(object instanceof Plant) {
            return true;
        }
        return false;
    }
    
    /**
     * Return the Antelope's max age.
     * @return The Antelope's max age.
     */
    public int maxAge() {
        return MAX_AGE;
    }

    /**
     * @return The antelopes food value.
     */
    public int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * check an object to see if its an antelope.
     * @param object object being checked
     * @return true if it is an antelope.
     */
    public boolean sameSpecies(Object object) {
        if(object instanceof Antelope){
            return true;
        }
        return false;
    }
}
