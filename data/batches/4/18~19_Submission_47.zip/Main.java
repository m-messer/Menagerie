import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean quit = false;
        Simulator sim = new Simulator();
        sim.reset();
        while (!quit) {
            String input = scanner.nextLine();
            switch(input) {
                case "quit":
                    quit = true;
                    break;
                case "1":
                    sim.simulateOneStep();
                    break;
                case "long":
                    sim.runLongSimulation();
                    break;
                case "choose":
                    int length = scanner.nextInt();
                    sim.simulate(length);
                    break;
                case "reset":
                    sim.reset();
                    break;
                default: System.out.println("please enter an appropriate command");
            }
        }
    }
}
