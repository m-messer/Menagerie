import java.util.List;

/**
 * this class represents a lion.
 * lions age, eat, move, breed and die.
 *
 * @version 01 19/02/2019
 */
public class Lion extends Animal{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single item of food.
    private static final int FOOD_VALUE = 6;
    // the quality of this animals eyesight.
    private static final double EYE_SIGHT = 0.7;



    public Lion(boolean randomAge, Field field, Location location){
        super(randomAge, field, location);
    }
    /**
     * Return the lion's max age.
     * @return The lion's max age.
     */
    public int maxAge(){
        return MAX_AGE;
    }

    /**
     * Return the lion's breeding age.
     * @return The lion's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the lion's max litter.
     * @return The lion's max litter.
     */
    public int getMaxLitter() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the lion's breeding probability.
     * @return The lion's breeding probability.
     */
    public double getBreedingProb() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Add newborns to the list of all life forms
     * Boolean randomAge false, newborns are aged zero.
     * @param location the location of this animal
     * @param newPredators a list to add new animals to.
     */
    public void addYoung(List<LifeForm> newPredators, Location location){
        newPredators.add(new Lion(false, getField(), location));
    }

    /**
     * Check if the animal is lion's food or not.
     * @param animal the animal being checked
     * @return true if it's a zebra or an antelope.
     */
    public boolean isFood(Object animal) {
        if(animal instanceof Zebra|| animal instanceof Antelope) {
            return true;
        }
        return false;
    }

    /**
     * Return the lion's food value.
     * @return The lion's food value.
     */
    public int getFoodValue(){
        return FOOD_VALUE;
    }

    /**
     * check if an object is a lion.
     * @param object the object being checked
     * @return true if the object is a lion
     */
    public boolean sameSpecies(Object object) {
        if(object instanceof Lion) {
            return true;
        }
        return false;
    }

    /**
     * check the animals eye sight.
     * @return the animals eye sight.
     */
    public double getEyeSight() {
        return EYE_SIGHT;
    }

}
