import java.util.ArrayList;
import java.util.Random;

/**
 * This class chooses and implements different weather types. different weather types have
 * different impacts on the environment.
 */
public class Weather {
    // the maximum increase in waterLevel during rain
    public final static int MAX_RAIN_FALL = 25;
    // the maximum decrease in waterLevel during sun
    public final static int MAX_WATER_DECREASE = 4;
    // the maximum increase in waterLevel due to fog
    public final static int MAX_FOG_PRECIPITATION = 3;
    // the visibility during fog.
    public final static double FOG_VISIBILITY = 0.4;
    // the visibility during rain.
    public final static double RAIN_VISIBILITY = 0.7;
    // list of weather types.
    private ArrayList<String> weatherTypes;
    // the weather.
    private String weather;

    /**
     * create a Weather object
     */
    public Weather() {
        weatherTypes = new ArrayList<>();
        fillList();
    }

    /**
     * fill the list of weather types.
     */
    public void fillList() {
        weatherTypes.add("rain");
        weatherTypes.add("foggy");
        weatherTypes.add("sunny");
    }

    /**
     * change the weather using a random number generator.
     */
    public void changeWeather(){
        Random random = new Random();
        weather = weatherTypes.get(random.nextInt(weatherTypes.size()));
    }

    /**
     * each weather type causes a different change in the waterLevel.
     * @return the change in waterlevel according to the weather.
     */
    public int waterLevelChange() {
        String weather = getWeather();
        Random ran = new Random();
        switch(weather){
            case "rain":
                return ran.nextInt(MAX_RAIN_FALL)+1;
            case "sunny":
                return - (ran.nextInt(MAX_WATER_DECREASE) +1);
            case "foggy":
                return ran.nextInt(MAX_FOG_PRECIPITATION +1);
            default:
                return 0;
        }
    }

    /**
     * @return the weather.
     */
    public String getWeather() {
        return weather;
    }

    /**
     * Different weather types affect the visibility of the field.
     * Lower visibility means there is less chance animals will be abelto see food.
     * @return the visibility
     */
    public double getVisibility() {
        String weather = getWeather();
        switch (weather) {
            case "rain":
                return RAIN_VISIBILITY;
            case "foggy":
                return FOG_VISIBILITY;
            default:
                return 1;
        }
    }
}
