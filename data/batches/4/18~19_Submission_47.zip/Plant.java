import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing characteristics of plants.
 * Plants grow to a maximum age and then die.
 * Plants cannot move.
 */
public class Plant extends LifeForm
{
    // The max age of the plant
    private static final int MAX_AGE = 200;
    private static final int MINIMUM_WATER_LEVEL = 10;

    /**
     * Create a new plant at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     * @param environment the environment of the field.
     */
    public void act(List<LifeForm> newPlants, Environment environment) {
        boolean isDay = environment.isDay();
        int waterLevel = environment.getWaterLevel();
        incrementAge();
        checkWaterLevel(waterLevel);
    }

    /**
     * check the waterLevel of the environment. If it is below a minimum.
     * @param waterLevel the waterLevel.
     */
    public void checkWaterLevel(int waterLevel) {

        double liveProbability = waterLevel / MINIMUM_WATER_LEVEL;
        if(getRand().nextDouble() > liveProbability) {
            setDead();
        }
    }
    /**
     * @return the max age of this plant
     */
    @Override
    public int maxAge() {
        return MAX_AGE;
    }

}
