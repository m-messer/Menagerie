import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 * This class fills a field with Life and helps control that life.
 * it sets the color of each species on the simulation.
 * it contains a method to spawn new plants in empty space.
 */
public class PopulationGenerator {
    private static final double TIGER_CREATION_PROBABILITY = 0.01;
    // The probability that a Lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.01;
    // The  probability that a Plant will be created in any given position
    private static final double PLANT_CREATION_PROBABILITY = 0.05;
    // The probability a plant will spawn in an empty spot.
    private static final double PLANT_SPAWNING_PROBABILITY = 0.02;
    // The  probability that a Hyena will be created in any given position
    private static final double HYENA_CREATION_PROBABILITY = 0.05;
    // The  probability that an Antelope will be created in any given position
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.05;
    // The  probability that a zebra will be created in any given position
    private static final double ZEBRA_CREATION_PROBABILITY = 0.05;
    // A random number generator.
    private Random rand;
    // The field this generator populates
    private Field field;

    /**
     * Construct a population generator.
     * @param field the field it populates
     */
    public PopulationGenerator(Field field) {
        rand = Randomizer.getRandom();
        this.field = field;
    }

    /**
     * fill a field with life using the creation probability of each life form.
     * @param life a List of all life to add all new life forms to.
     */
    public void populate(List<LifeForm> life){
        field.clear();
        // loop through every location in the field.
        for(int row = 0; row<field.getDepth();row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                LifeForm lifeForm = null;
                if (rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    lifeForm = new Tiger(true, field, location);
                }
                else if (rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    lifeForm = new Lion(true, field, location);
                }
                else if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    lifeForm= new Plant(true, field, location);
                }
                else if (rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    lifeForm= new Hyena(true, field, location);
                }
                else if (rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    lifeForm = new Antelope(true, field, location);
                }
                else if (rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    lifeForm =  new Zebra(true, field, location);
                }
                // check there is a lifeForm created and add to the list.
                if(lifeForm != null) {
                    life.add(lifeForm);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Set the colors for each life form in the simulation.
     * @param view the simulator view which shows the simulation.
     */
    public void setColors(SimulatorView view){
        view.setColor(Tiger.class, Color.ORANGE);
        view.setColor(Lion.class, Color.yellow);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Antelope.class, Color.CYAN);
        view.setColor(Hyena.class, Color.gray);
        view.setColor(Zebra.class, Color.MAGENTA);

    }

    /**
     * Loop through the field and possibly create a plant in each empty space.
     * @param newPlants a list of life forms to add newly created life forms to.
     */
    public void spawnPlants(List<LifeForm> newPlants ) {

        // Pass through the whole field.
        for(int row = 0; row < field.getDepth();row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                // check for an empty location
                Object object = field.getObjectAt(row, col);
                Location loc = new Location(row, col);
                // If a location is empty, possibly spawn a plant.
                if (object == null) {
                    if(rand.nextDouble() <= PLANT_SPAWNING_PROBABILITY) {
                        Plant plant = new Plant(false, field, loc);
                        field.place(plant, loc);
                        newPlants.add(plant);
                    }
                }
            }
        }
    }
}