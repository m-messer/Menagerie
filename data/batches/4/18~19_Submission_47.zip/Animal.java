import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals and actions of animals
 * All animals find food or else they'll die, and find mates in order to breed.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends LifeForm
{
    // the animal's food level
    private int foodLevel;
    // the gender of the animal.
    private boolean isMale;

    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge is this animal created with a random age (and food value) or not
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        if(randomAge) {
            foodLevel = getRand().nextInt(getFoodValue());
        }
        else {
            foodLevel = getFoodValue();
        }
        // Half the time, a new animal is male and half the time it is female.
        if(getRand().nextInt(2) == 1) {
            isMale = true;
        }
        else {
            isMale = false;
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param environment the environment of the field
     */
    public void act(List<LifeForm> newAnimals, Environment environment) {
        boolean isDay = environment.isDay();
        String weather = environment.getWeather();
        double visibility = environment.getVisibility();
        incrementAge();
        incrementHunger();
        // some animals are awake all the time, some only during the day.
        if (isAwake(isDay)) {
            if (isAlive()) {
                // males find females to breed with.
                if (isMale) {
                    giveBirth(newAnimals);
                }
                // If it can see food Move towards a source of food if found.
                if(canSee(visibility)) {
                    Location newLocation = findFood();
                    if (newLocation == null) {
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if (newLocation != null) {
                        setLocation(newLocation);
                    } else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Decrease the food level by 1. If the level is below 0, the animal is dead.
     */
    public void incrementHunger(){
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Find the number of offspring from a particular animal and create the new animals.
     * @param newAnimals list of LifeForms to add newborn animals to.
     */
    public void giveBirth(List<LifeForm> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // find the number of births.
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            // add the new animals to the list of new animals.
            addYoung(newAnimals, loc);
        }
    }

    /**
     * Calculate the numbers of births for each animal.
     * @return the number of births.
     */
    public int breed(){
        int births = 0;
        // Each male animal could breed with any/all of the females of the same species around him.
        for ( int i = 0; i <= mates(); i++){
            if (canBreed() && getRand().nextDouble() <= getBreedingProb()) {
                births = getRand().nextInt(getMaxLitter()) + 1;
            }
        }
        return births;
    }

    /**
     * Check for appropriate mates in the vicinity.
     * @return number of mates.
     */
    public int mates() {
        int mates = 0;
        Iterator<Location> it = adjacentIterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = getField().getObjectAt(where);
            // check if an object is a good mate
            if(isMate(object)) {
                mates++;
            }
        }
        return mates;
    }

    /**
     * Check if an object is an appropriate mate.
     * @param object the object to be checked.
     * @return whether it is a mate or not.
     */
    public boolean isMate(Object object) {
        if (sameSpecies(object)) {
            Animal animal = (Animal)object;
            // ensure the animal is female and old enough.
            if(!animal.isMale && animal.canBreed()) {
                return true;
            }
        }
            return false;
    }

    /**
     * @return if the animal is male or not.
     */
    public boolean isMale() {
        return isMale;
    }

    /**
     * @return if the animal is old enough to breed or not.
     */
    private boolean canBreed() {
        if (getAge() < getBreedingAge()) {
            return false;
        }
        else {
            return true;
        }
    }

    /**
     * allow the animal to find food in the area it is in, and if it finds kill it, eat it
     * and move to that location. If the animal has multiple food sources around,
     * move to the location of the last kill.
     * @return the location the animal is moving to.
     */
    public Location findFood()
    {
        // Iterate through a list of adjacent locations
        Iterator<Location> it = adjacentIterator();
        Location newLoc = null;
        while(it.hasNext()) {
            Location where = it.next();
            Object object = getField().getObjectAt(where);
            // check if an object is food.
            if(canBeEaten(object)) {
                // if so, consume.
                consume(object);
                // increase food level up to a maximum.
                if(foodLevel < 20) {
                    increaseFoodLevel(getFoodValue());
                    newLoc = where;
                }
            }
        }
        return newLoc;
    }

    /**
     * Check if an object can be eaten - that is to say it is food for this
     * particular animal and it is alive.
     * @param object the possible food.
     * @return whether it can be eaten.
     */
    public boolean canBeEaten(Object object) {
        // check if it is a valid foodstuff.
        if (isFood(object)) {
            LifeForm food = (LifeForm) object;
            if (food.isAlive()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Kill the item of food.
     * @param object the item of food.
     */
    public void consume(Object object) {
        LifeForm food = (LifeForm)object;
        food.setDead();
    }

    /**
     * Create an iterator through a list of adjacent locations of a location
     * @param location the location, the adjacent locations of which we are iterating through.
     * @return the Iterator of locations.
     */
    public Iterator<Location> adjacentIterator(Location location) {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        return it;
    }

    /**
     * increase the animals food level by a value.
     * @param value the amount to increase the food level by.
     */
    public void increaseFoodLevel(int value) {
        foodLevel = foodLevel + value;
    }

    /**
     * check whether the animal is awake at this time to function.
     * Most animals are awake only in the day, some override this method
     * @param isDay true if it is day, false if it is night.
     * @return true if the animal is awake.
     */
    public boolean isAwake(boolean isDay) {
        return isDay;
    }

    /**
     * Check if the animal can see. if it cannot see, it cannot hunt.
     * this is affected by the animals eyesight and the field visibility.
     * @param visibility the visibility at the time.
     * @return true if the animal can see.
     */
    public boolean canSee(double visibility) {
        if (getRand().nextDouble() <= getEyeSight() * visibility) {
            return true;
        }
        return false;
    }

    /**
     * get the animals eyesight. most have perfect eyesight.
     * Those that don't override this method.
     * @return the animals eyesight.
     */
    public double getEyeSight(){
        return 1;
    }

    public abstract int getBreedingAge();

    public abstract double getBreedingProb();

    public abstract boolean isFood(Object object);

    public abstract int getFoodValue();

    public abstract int getMaxLitter();

    public abstract void addYoung(List<LifeForm> newAnimals, Location location);

    public abstract boolean sameSpecies(Object object);

}