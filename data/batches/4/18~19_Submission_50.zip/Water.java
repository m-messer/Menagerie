/**
 * A class representing shared characteristics of water objects
 *
 * @version 2018.02.22
 */
public class Water
{
    // instance variables - replace the example below with your own
    // Whether the water is alive or not.
    private boolean alive;
    // The water's field.
    private Field field;
    // The water's position in the field.
    private Location location;

    /**
     * Create a new water at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Water(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }


    /**
     * @return The water's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the water at the new location in the given field.
     * @param newLocation The water's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * @return The water's field.
     */
    protected Field getField()
    {
        return field;
    }
}
