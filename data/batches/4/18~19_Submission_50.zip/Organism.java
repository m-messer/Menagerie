import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of organisms.
 * Holds animals and plants which are used in the simulator
 *
 * @version 2018.02.22
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // Used for random number generator.
    private Random rand;

    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    abstract public void act(List<Organism> newOrganisms, int time, String weather);
    protected abstract int getAge();
    protected abstract int getMaxAge();
    protected abstract void setAge(int age);
    protected abstract int getBreedingAge();
    protected abstract double getBreedingProbability();
    protected abstract int getMaxLitterSize();
    protected abstract Random getRand(); 
    protected abstract boolean isInfected();
    protected abstract double getDiseaseProbability();
    protected abstract double getDiseaseModifier();
    protected abstract void setInfection();

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

     /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Increase the age.
     * This could result in the organism's death.
     */
    public void incrementAge()
    {
        int newAge = getAge() + 1;
        if(newAge > getMaxAge()) {
            setDead();
        }
        else {
            setAge(newAge);
        }
    }

    
    /**
     * Check whether or not this organism is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrganisms A list to return newly born organisms.
     */
    protected void giveBirth(List<Organism> newOrganisms)
    {
        // New organisms are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Object organism = field.getObjectAt(getLocation());
            if (organism instanceof GrassHopper){
                GrassHopper young = new GrassHopper(false, field, loc);
                newOrganisms.add(young);
            }
            else if (organism instanceof Caterpillar){
                Caterpillar young = new Caterpillar(false, field, loc);
                newOrganisms.add(young);
            }
            else if (organism instanceof Frog){
                Frog young = new Frog(false, field, loc);
                newOrganisms.add(young);
            }
            else if (organism instanceof Snake){
                Snake young = new Snake(false, field, loc);
                newOrganisms.add(young);
            }
            else if (organism instanceof Bird){
                Bird young = new Bird(false, field, loc);
                newOrganisms.add(young);
            }
            else if (organism instanceof Hawk){
                Hawk young = new Hawk(false, field, loc);
                newOrganisms.add(young);
            }
            else if (organism instanceof Grass){
                Grass young = new Grass(false, field, loc);
                newOrganisms.add(young);
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        rand = Randomizer.getRandom();
        int births = 0;
        double breedingProbability = getBreedingProbability();
        int maxLitterSize = getMaxLitterSize();
       
        if(isInfected()){
            breedingProbability *= getDiseaseModifier();
            maxLitterSize = (int)(maxLitterSize*getDiseaseModifier());
        }

        else if(canBreed() && rand.nextDouble() <= breedingProbability) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * An organism can breed if it has reached the breeding age.
     * @return true if the organism can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }
        
    /**
     * Speads the disease to other organisms if surrouding another organism
     */
    protected void spreadDisease()
    {   
        Random rand = new Random();
        if(isAlive()){
            List<Location> locations = field.adjacentLocations(getLocation()); //gets all locations around the organism
            for (int i=0; i < locations.size(); i++){
                Object organism = field.getObjectAt(locations.get(i));
                if(organism instanceof Organism){
                    Organism organism2 = (Organism) organism;
                    if(rand.nextDouble() <= organism2.getDiseaseProbability()){
                        organism2.setInfection();
                    }
                }           
            }
        }
    }
}
