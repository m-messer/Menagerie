import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2018.02.22
 */
public abstract class Animal extends Organism
{
    // Holds all types of weather
    private static final ArrayList<String> allWeather = new ArrayList<>(Arrays.asList("Snowy","Rainy","Cloudy","Sunny","Windy","Stormy"));
    // Holds values for different weathers and their breeding probablity
    private static final ArrayList<Double> weatherBreed = new ArrayList<>(Arrays.asList(0.90,0.80,1.00,1.00,0.90,0.80));
    // Holds values for different weathers and their infection probability probablity
    private static final ArrayList<Double> weatherInfection = new ArrayList<>(Arrays.asList(0.90,0.70,0.50,0.40,0.90,0.80));
    // Random number generator
    private Random rand;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
    }

    protected abstract ArrayList<Integer> getBed();
    protected abstract boolean getGender();
    protected abstract int getFoodLevel();
    protected abstract void setFoodLevel(int newFoodLevel);
    protected abstract Location findFood();
    protected abstract String getType();

    /**
     * Checks whether 2 animals are able to propagate based
     * on 2 statements: if they are of the same species of animal
     * (So 2 hawks) and if they are of the opposite gender.
     */
    protected boolean ableToPropagate()
    {
        List<Location> locations = getField().adjacentLocations(getLocation()); //gets all locations around the animal
        boolean sameSpecies = false;
        for (int i=0; i < locations.size(); i++){
            Object potentialMate = getField().getObjectAt(locations.get(i));
            if (potentialMate instanceof Animal){
                Animal mate = (Animal) potentialMate;
                if (getClass().equals(potentialMate.getClass())){       
                    sameSpecies = true;
                }
                if (sameSpecies){
                    //compares current animals gender to the potential mate. If opposite, they're able to mate
                    if (getGender() != mate.getGender()){
                        return true;
                    }
                    else {
                        sameSpecies = false; //otherwise, although they're the same species, they are the same gender. Moves on to check the next location
                    }
                }
            }
        }
        return false;
    }

    /**
     * Changes the food level of the animal.
     */
    protected void incrementHunger()
    {
        int newFoodLevel = getFoodLevel() - 1;
        if(newFoodLevel <= 0) {
            setDead();
        }
        else {
            setFoodLevel(newFoodLevel);
        }
    }
    
    /**
    * After every step the animal will age, move to a free location,
    * get hungrier and could potential spread a disease. 
    * If the animal cannot move to another location it dies.
    */
    public void act(List<Organism> newAnimals, int time, String weather)
    {
        Random rand = new Random();
        incrementAge();
        incrementHunger();
        if((isAlive()) && (!getBed().contains(time))) {       
            if ((isInfected()) && (rand.nextDouble() <= (weatherInfection.get(allWeather.indexOf(weather))))){
                spreadDisease();
            }
            if ((ableToPropagate()) && ((rand.nextDouble()) <= (weatherBreed.get(allWeather.indexOf(weather))))) {
                giveBirth(newAnimals);
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if((newLocation == null) && (getType().equals("Predator"))) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            else if (getType().equals("Prey")) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        else if ((isAlive()) && (getBed().contains(time))) {
            int newFoodLevel = getFoodLevel() + 3;
            setFoodLevel(newFoodLevel);
        }
    }
}