import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A simple model of a frog.
 * Frogs age, move, eats caterpillars and grasshoppers, sleeps, gets infected and die.
 *
 * @version 2018.02.22
 */
public class Frog extends Animal
{
    // Characteristics shared by all frogs (class variables).
    
    // The age at which a frog can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a frog can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a frog breeding.
    private static final double BREEDING_PROBABILITY = 0.39;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single prey. In effect, this is the
    // number of steps a grass hopper or caterpillar can go before it has to eat again.
    private static final int GRASSHOPPER_FOOD_VALUE = 90;
    private static final int CATERPILLAR_FOOD_VALUE = 70;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // When the frog is sleeping
    private static final ArrayList<Integer> bed = new ArrayList<>(Arrays.asList(20,21,22,23,0,1));
    // The probability of the frog getting a disease.
    private static final double DISEASE_PROBABILITY = 0.01;
    // The probability of how much the frog's stats will be affected by the disease.
    private static final double DISEASE_MODIFIER = 0.4;
    // What type of animal is the frog, prey or predator.
    private static final String type = "Predator";
    
    // Individual characteristics (instance fields).
    // Holds whether the frog is infected.
    private boolean isInfected;
    // The frog's age.
    private int age;
    // The frog's gender. True represents one gender and false represents the other.
    private boolean gender;
    // Frog's food level.
    private int foodLevel;
    
    /**
     * Create a frog. A frog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the frog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        gender = rand.nextBoolean();
        int initFoodLevel = rand.nextInt(2);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            if (initFoodLevel == 0){
                foodLevel = rand.nextInt(GRASSHOPPER_FOOD_VALUE);
            }
            else{
                foodLevel = rand.nextInt(CATERPILLAR_FOOD_VALUE);
            }
        }
        else {
            age = 0;
            if (initFoodLevel == 0){
                foodLevel = GRASSHOPPER_FOOD_VALUE;
            }
            else {
                foodLevel = CATERPILLAR_FOOD_VALUE;
            }
        }
        
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * @return The age of the frog
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set the age of the frog
     * @param newAge The new age of the frog
     */
    public void setAge(int newAge){
        age = newAge;
    }
    
    /**
     * @return The maximum age of the frog
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return The breeding age of the frog
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return the breeding probability of the frog
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return the maximum litter size of the frog
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return Rand which is used for the randomiser
     */
    public Random getRand()
    {
        return rand;
    }
    
    /**
     * @return The food level of the frog
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the food level
     * @param newFoodLevel The new food level of the frog.
     */
    public void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }
    
    /**
     * @return The food value for a grass hopper
     */
    public int getFoodValueGrassHopper()
    {
        return GRASSHOPPER_FOOD_VALUE;
    }
    
    /**
     * @return The food value for a caterpillar
     */
    public int getFoodValueCaterpillar()
    {
        return CATERPILLAR_FOOD_VALUE;
    }

    /**
     * Look for caterpillars and grass hoppers adjacent to the current location.
     * Only the first live caterpillars or grass hoppers is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof GrassHopper) {
                GrassHopper grasshopper = (GrassHopper) animal;
                if(grasshopper.isAlive()) { 
                    grasshopper.setDead();
                    foodLevel = GRASSHOPPER_FOOD_VALUE;
                    return where;
                }
            }
            else if (animal instanceof Caterpillar) {
                Caterpillar caterpillar = (Caterpillar) animal;
                if(caterpillar.isAlive()) { 
                    caterpillar.setDead();
                    foodLevel = CATERPILLAR_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * @returns The bedtime for the animal.
     */
    public ArrayList<Integer> getBed()
    {
        return bed;
    }
    
    /**
     * @return The gender of the frog.
     */
    public boolean getGender()
    {
        return gender;
    }
    
    /**
     * @return The probability of disease happening.
     */
    public double getDiseaseProbability()
    {
        return DISEASE_PROBABILITY;
    }
    
    /**
     * @return How much frog's stats will be affected by disease.
     */
    public double getDiseaseModifier()
    {
        return DISEASE_MODIFIER;
    }
    
    /**
     * @return whether the frog is infected.
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the frog infected with the disease.
     */
    public void setInfection()
    {
        isInfected = true;
    }
    
    /**
     * @return The frog's classification type.
     */
    public String getType()
    {
        return type;
    }
}
