import java.util.Random;

/**
 * A simple model of the grass
 * Grass can age, breed, get infected and die.
 *
 * @version 2018.02.22
 */
public class Grass extends Plant
{
    // Characteristics shared by all grass (class variables).
    
    // The age at which the grass can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which the grass can live.
    private static final int MAX_AGE = 50;
    // The likelihood of the grass breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The probability of the grass getting a disease.
    private static final double DISEASE_PROBABILITY = 0.012;
    // The probability of how much the grass's stats will be affected by the disease.
    private static final double DISEASE_MODIFIER = 0.2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The grass's age.
    private int age;
    // Holds whether the grass is infected.
    private boolean isInfected;
    /**
     * Create a grass. 
     * 
     * @param randomAge If true, the grass will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */

    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if (randomAge){
            age = rand.nextInt(MAX_AGE);
        }
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * @return The age of the grass.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set the age of the grass.
     * @param newAge The new age of the grass
     */
    public void setAge(int newAge){
        age = newAge;
    }
    
    /**
     * @return The maximum age of the grass.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return The breeding age of the grass.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return The breeding probability of the grass.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return The maximum litter size of the grass.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return Rand which is used for the randomiser.
     */
    public Random getRand()
    {
        return rand;
    }
    
    /**
     * @return The probability of disease happening.
     */
    public double getDiseaseProbability()
    {
        return DISEASE_PROBABILITY;
    }
    
    /**
     * @return How much grass's stats will be affected by disease.
     */
    public double getDiseaseModifier()
    {
        return DISEASE_MODIFIER;
    }
    
    /**
     * @return Whether the grass is infected.
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the grass infected with the disease.
     */
    public void setInfection()
    {
        isInfected = true;
    }
}
