import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A simple model of a grasshoppers.
 * Grass Hoppers age, move, breed, eat, sleep, get infected and die.
 *
 * @version 2018.02.22
 */
public class GrassHopper extends Animal
{
    // Characteristics shared by all grasshoppers (class variables).

    // The age at which a grasshopper can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a grasshopper can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a grasshopper breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // How much each grass is valued in terms of food.
    private static final int GRASS_FOOD_VALUE = 70;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // When the grasshopper is sleeping
    private static final ArrayList<Integer> bed = new ArrayList<>(Arrays.asList(21,22,23,0,1,2));
    // The probability of the grasshopper getting a disease.
    private static final double DISEASE_PROBABILITY = 0.05;
    // The probability of how much the grasshopper's stats will be affected by the disease.
    private static final double DISEASE_MODIFIER = 0.4;
    // What type of animal is the grasshopper, prey or predator.
    private static final String type = "Prey";
    
    // Individual characteristics (instance fields).
    // Holds whether the grasshopper is infected.
    private boolean isInfected;
    // The grasshopper's age.
    private int age;
    // The grasshopper's gender. True represents one gender and false represents the other.
    private boolean gender;
    // Grass hopper's food level.
    private int foodLevel;

    /**
     * Create a new grass hoppers. A grass hoppers may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass hoppers will have a random age and starting food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public GrassHopper(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        gender = rand.nextBoolean();
        foodLevel = GRASS_FOOD_VALUE;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * @return The age of the grass hopper
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set the age of the grass hopper
     * @param newAge The new age of the grasshopper
     */
    public void setAge(int newAge){
        age = newAge;
    }
    
    /**
     * @return The maximum age of the grass hopper
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return The breeding age of the grass hopper
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return The breeding probability of the grass hopper
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return The maximum litter size of the grass hopper
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return Rand which is used for the randomiser
     */
    public Random getRand()
    {
        return rand;
    }
    
     /**
     * @return The food level of the grasshopper
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the food level
     * @param newFoodLevel The new food level for the grasshopper
     */
    public void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }

            }
        }
        return null;
    }
    
    /**
     * @return The bedtime for the animal.
     */
    public ArrayList<Integer> getBed()
    {
        return bed;
    }
    
    /**
     * @return gender of the grass hopper.
     */
    public boolean getGender()
    {
        return gender;
    }
    
    /**
     * @return The probability of being infected.
     */
    public double getDiseaseProbability()
    {
        return DISEASE_PROBABILITY;
    }
    
    /**
     * @return how much grass hopper's stats will be affected by disease.
     */
    public double getDiseaseModifier()
    {
        return DISEASE_MODIFIER;
    }
    
    /**
     * @return Whether the grass hopper is infected.
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the grass hopper infected with the disease.
     */
    public void setInfection()
    {
        isInfected = true;
    }
    
    /**
     * @return The grass hopper's classification type.
     */
    public String getType()
    {
        return type;
    }
}