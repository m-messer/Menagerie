import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A simple model of a bird.
 * Birds age, move, eats frogs and grasshoppers, sleep and get infected and die.
 *
 * @version 2018.02.22
 */
public class Bird extends Animal
{
    // Characteristics shared by all birds (class variables).
    
    // The age at which a bird can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a bird can live.
    private static final int MAX_AGE = 130;
    // The likelihood of a bird breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single prey. In effect, this is the
    // number of steps a grass hopper or frog can go before it has to eat again.
    private static final int GRASSHOPPER_FOOD_VALUE = 100;
    private static final int FROG_FOOD_VALUE = 90;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // When the bird is sleeping.
    private static final ArrayList<Integer> bed = new ArrayList<>(Arrays.asList(20,21,22,23,0,1));
    // The probability of the bird getting a disease.
    private static final double DISEASE_PROBABILITY = 0.01;
    // The probability of how much the bird's stats will be affected by the disease.
    private static final double DISEASE_MODIFIER = 0.4;
    // What type of animal is the bird, prey or predator.
    private static final String type = "Predator";
    
    // Individual characteristics (instance fields).
    // Holds whether the bird is infected.
    private boolean isInfected;
    // The bird's age.
    private int age;
    // The bird's gender. True represents one gender and false represents the other.
    private boolean gender;
    // Bird's food level.
    private int foodLevel;

    /**
     * Create a bird. A bird can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the bird will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bird(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        gender = rand.nextBoolean();
        int initFoodLevel = rand.nextInt(2);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            if (initFoodLevel == 0){
                foodLevel = rand.nextInt(GRASSHOPPER_FOOD_VALUE);
            }
            else{
                foodLevel = rand.nextInt(FROG_FOOD_VALUE);
            }
        }
        else {
            age = 0;
            if (initFoodLevel == 0){
                foodLevel = GRASSHOPPER_FOOD_VALUE;
            }
            else {
                foodLevel = FROG_FOOD_VALUE;
            }
        }
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * @return The age of the bird
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set the age of the bird
     * @param newAge The new age of the bird
     */
    public void setAge(int newAge){
        age = newAge;
    }
    
    /**
     * @return The maximum age of the bird
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return The breeding age of the bird
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return The breeding probability of the bird
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return The maximum litter size of the bird
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return Rand which is used for the randomiser
     */
    public Random getRand()
    {
        return rand;
    }
    
    /**
     * @return The food level of the bird
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the food level
     * @param newFoodLevel THe new food level of the bird
     */
    public void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }
    
    /**
     * @return The food value for a grass hopper
     */
    public int getFoodValueGrassHopper()
    {
        return GRASSHOPPER_FOOD_VALUE;
    }
    
    /**
     * @return The food value for a frog
     */
    public int getFoodValueFrog()
    {
        return FROG_FOOD_VALUE;
    }
        

    /**
     * Look for frogs and grass hoppers adjacent to the current location.
     * Only the first live frog or grass hopper is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof GrassHopper) {
                GrassHopper grasshopper = (GrassHopper) animal;
                if(grasshopper.isAlive()) { 
                    grasshopper.setDead();
                    foodLevel = GRASSHOPPER_FOOD_VALUE;
                    return where;
                }
            }
            else if (animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isAlive()) { 
                    frog.setDead();
                    foodLevel = FROG_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * @return The bedtime for the animal.
     */
    public ArrayList<Integer> getBed()
    {
        return bed;
    }
    
    /**
     * @return The gender of the bird.
     */
    public boolean getGender()
    {
        return gender;
    }
    
    /**
     * @return The probability of disease happening.
     */
    public double getDiseaseProbability()
    {
        return DISEASE_PROBABILITY;
    }
    
    /**
     * @return How much bird's stats will be affected by disease.
     */
    public double getDiseaseModifier()
    {
        return DISEASE_MODIFIER;
    }
    
    /**
     * @return Whether the bird is infected.
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the bird infected with the disease.
     */
    public void setInfection()
    {
        isInfected = true;
    }
    
    /**
     * @return Whether the bird is infected.
     */
    public String getType()
    {
        return type;
    }
}