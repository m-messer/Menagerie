import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A simple model of a caterpillar.
 * Caterpillars age, move, breed, sleep, eat, get infected and die.
 *
 * @version 2018.02.22
 */
public class Caterpillar extends Animal
{
    // Characteristics shared by all caterpillars (class variables).

    // The age at which a caterpillar can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a caterpillar can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a caterpillar breeding.
    private static final double BREEDING_PROBABILITY = 0.119;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // How much each grass is valued in terms of food.
    private static final int GRASS_FOOD_VALUE = 60;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // When the caterpillar is sleeping.
    private static final ArrayList<Integer> bed = new ArrayList<>(Arrays.asList(22,23,0,1,2));
    // The probability of the caterpillar getting a disease.
    private static final double DISEASE_PROBABILITY = 0.05;
    // The probability of how much the caterpillar's stats will be affected by the disease.
    private static final double DISEASE_MODIFIER = 0.4;
    // What type of animal is the caterpillar, prey or predator.
    private static final String type = "Prey";
    
    // Individual characteristics (instance fields).
    // Holds whether the caterpillar is infected.
    private boolean isInfected;
    // The caterpillars's age.
    private int age;
    // The caterpillar's gender. True represents one gender and false represents the other. 
    private boolean gender;
    // Caterpillar's food level.
    private int foodLevel;

    /**
     * Create a new caterpillar. A caterpillar may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the caterpillar will have a random age and starting food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Caterpillar(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        foodLevel = GRASS_FOOD_VALUE;
        gender = rand.nextBoolean();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }

    /**
     * @return The age of the caterpillar
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Set the age of the caterpillar
     * @param newAge The new age of the caterpillar
     */
    public void setAge(int newAge){
        age = newAge;
    }

    /**
     * @return The maximum age of the caterpillar
     */
    public int getMaxAge()
    {
        if (isInfected){
            return (int)(MAX_AGE * DISEASE_MODIFIER);
        }
        return MAX_AGE;
    }

    /**
     * @return The breeding age of the caterpillar
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return The breeding probability of the caterpillar
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return The maximum litter size of the caterpillar
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return Rand which is used for the randomiser
     */
    public Random getRand()
    {
        return rand;
    }

     /**
     * @return The food level of the caterpillar
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the food level
     * @param newFoodLevel The new food level of the caterpillar
     */
    public void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }

    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }

            }
        }
        return null;
    }
    
    /**
     * @return The bedtime for the animal.
     */
    public ArrayList<Integer> getBed()
    {
        return bed;
    }
    
    /**
     * @return The gender of the caterpillar.
     */
    public boolean getGender()
    {
        return gender;
    }
    
    /**
     * @return The probability of disease happening.
     */
    public double getDiseaseProbability()
    {
        return DISEASE_PROBABILITY;
    }
    
    /**
     * @return How much caterpillar's stats will be affected by disease.
     */
    public double getDiseaseModifier()
    {
        return DISEASE_MODIFIER;
    }
    
    /**
     * @return Whether the caterpillar is infected.
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the caterpillar infected with the disease.
     */
    public void setInfection()
    {
        isInfected = true;
    }
    
    /**
     * @return The caterpillar's classification type.
     */
    public String getType()
    {
        return type;
    }
}