import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A simple model of a hawk.
 * Hawks age, move, eats snakes and birds, sleep, get infected and die.
 *
 * @version 2018.02.22
 */
public class Hawk extends Animal
{
    // Characteristics shared by all hawks (class variables).
    
    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a hawk can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.09;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single prey. In effect, this is the
    // number of steps a bird and snake can go before it has to eat again.
    private static final int BIRD_FOOD_VALUE = 120;
    private static final int SNAKE_FOOD_VALUE = 100;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // When the hawk is sleeping.
    private static final ArrayList<Integer> bed = new ArrayList<>(Arrays.asList(2,3,4,5,6));
    // The probability of the hawk getting a disease.
    private static final double DISEASE_PROBABILITY = 0.01;
    // The probability of how much the hawk's stats will be affected by the disease.
    private static final double DISEASE_MODIFIER = 0.4;
    // What type of animal is the hawk, prey or predator.
    private static final String type = "Predator";
    
    // Individual characteristics (instance fields).
    // Holds whether the hawk is infected.
    private boolean isInfected;
    // The hawk's age.
    private int age;
    // The hawk's gender. True represents one gender and false represents the other.
    private boolean gender;
    // Hawk's food level.
    private int foodLevel;
    
    /**
     * Create a hawk. A hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hawk will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hawk(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        gender = rand.nextBoolean();
        int initFoodLevel = rand.nextInt(2);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            if (initFoodLevel == 0){
                foodLevel = rand.nextInt(BIRD_FOOD_VALUE);
            }
            else{
                foodLevel = rand.nextInt(SNAKE_FOOD_VALUE);
            }
        }
        else {
            age = 0;
            if (initFoodLevel == 0){
                foodLevel = BIRD_FOOD_VALUE;
            }
            else {
                foodLevel = SNAKE_FOOD_VALUE;
            }
        }
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * @return The age of the hawk
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set the age of the hawk
     * @param newAge The new age of the hawk
     */
    public void setAge(int newAge){
        age = newAge;
    }
    
    /**
     * @return The maximum age of the hawk
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return The breeding age of the hawk
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return The breeding probability of the hawk
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return The maximum litter size of the hawk
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return Rand which is used for the randomiser
     */
    public Random getRand()
    {
        return rand;
    }
    
    /**
     * @return  The food level of the hawk
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the food level
     * @param newFoodLevel The new food level of the hawk
     */
    public void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }
    
    /**
     * @return The food value for a bird
     */
    public int getFoodValueBird()
    {
        return BIRD_FOOD_VALUE;
    }
    
    /**
     * Return food value for a snake
     */
    public int getFoodValueSnake()
    {
        return SNAKE_FOOD_VALUE;
    }

    /**
     * Look for snakes and birds adjacent to the current location.
     * Only the first live snake or bird is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bird) {
                Bird bird = (Bird) animal;
                if(bird.isAlive()) { 
                    bird.setDead();
                    foodLevel = BIRD_FOOD_VALUE;
                    return where;
                }
            }
            else if (animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if(snake.isAlive()) { 
                    snake.setDead();
                    foodLevel = SNAKE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * @returns The bedtime for the animal.
     */
    public ArrayList<Integer> getBed()
    {
        return bed;
    }
    
    /**
     * @return The gender of the hawk.
     */
    public boolean getGender()
    {
        return gender;
    }
    
    /**
     * @return The probability of disease happening.
     */
    public double getDiseaseProbability()
    {
        return DISEASE_PROBABILITY;
    }
    
    /**
     * @return How much hawk's stats will be affected by disease.
     */
    public double getDiseaseModifier()
    {
        return DISEASE_MODIFIER;
    }
    
    /**
     * @return Whether the hawk is infected.
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the hawk infected with the disease.
     */
    public void setInfection()
    {
        isInfected = true;
    }
    
    /**
     * @return The hawk's classification type.
     */
    public String getType()
    {
        return type;
    }
}