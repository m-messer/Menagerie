import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2018.02.22
 */
public abstract class Plant extends Organism
{
    // Holds all types of weather
    private static final ArrayList<String> allWeather = new ArrayList<>(Arrays.asList("Snowy","Rainy","Cloudy","Sunny","Windy","Stormy"));
    // Holds probabilities of what will happen depending on weather
    private static final ArrayList<Double> weatherPlant = new ArrayList<>(Arrays.asList(0.50,1.00,0.90,1.00,0.70,0.60));
    
    /**   
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */

    public Plant(Field field, Location location)
    {
        super(field,location);
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     * @param time Is the current time in the simulation
     */
    public void act(List<Organism> newPlants, int time, String weather)
    {
        Random rand = new Random();
        incrementAge();
        if ((isAlive()) && ((rand.nextDouble()) <= (weatherPlant.get(allWeather.indexOf(weather))))) {
            if (isInfected()){
                spreadDisease();
            }
            giveBirth(newPlants);
        }
        else {
            setDead();
        }
    }
    
    public abstract boolean isInfected();
}