import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing caterpillars, grasshoppers, frogs, snakes, hawks, birds and water.
 *
 * @version 2018.02.22
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a hawk will be created in any given grid position.
    private static final double HAWK_CREATION_PROBABILITY = 0.05;
    // The probability that a caterpillar will be created in any given grid position.
    private static final double CATERPILLAR_CREATION_PROBABILITY = 0.055;
    // The probability that a grass hopper will be created in any given grid position.
    private static final double GRASSHOPPER_CREATION_PROBABILITY = 0.06;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.07;
    // The probability that a bird will be created in any given grid position.
    private static final double BIRD_CREATION_PROBABILITY = 0.075;
    // The probability that a frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.078;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.08;
    // The probability that a pond will be created in any given grid position when it's raining.
    private static final double POND_CREATION_PROBABILITY = 0.00015;
    // The radius of the pond when it appears in the simulation
    private static final int POND_RADIUS = 3;
    // The types of weather patterns in the simulation.
    private static final ArrayList<String> allWeather = new ArrayList<>(Arrays.asList("Snowy","Rainy","Cloudy","Sunny","Windy","Stormy"));

    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private int time;
    // Keeps track of time of day
    private int day;
    // Keeps track of weather
    private String weather;
    // Keeps track of the day the simulation is on.
    private SimulatorView view;
    // Random number generator.
    private Random rand;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();
        field = new Field(depth, width);
        rand = new Random();
        weather = "Sunny";

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(GrassHopper.class, Color.ORANGE);
        view.setColor(Caterpillar.class, Color.BLACK);
        view.setColor(Frog.class, Color.RED);
        view.setColor(Snake.class, Color.PINK);
        view.setColor(Bird.class, Color.CYAN);
        view.setColor(Hawk.class, Color.MAGENTA);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Water.class, Color.BLUE);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     * 
     * It also checks the current weather conditions in the simulation
     * and generates or evaporates ponds accordingly.
     */
    public void simulateOneStep()
    {
        step++;
        if (step % 5 == 0){ //Every 5 steps is equal to 1 hour.
            updateTime();
            updateWeather();
            updateDay(); //Checks after each hour if a new day has past.
        }

        // Provide space for newborn organisms.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms, time, weather);
            //System.out.println(time);
            if(! organism.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganisms);

        if(weather.equals("Rainy") || weather.equals("Stormy")){
            renderPond();
        }
        else if(weather.equals("Sunny")){
            evaporatePond();
        }

        view.showStatus(step, field, getDayWeatherString(), getTimeString());
    }

    /**
     * Update time and keep the time in between 0 and 23.
     */
    private void updateTime()
    {
        time++;
        time = time % 24;
    }

    /**
     * @return The time as a string.
     */
    private String getTimeString()
    {
        if (time < 10){
            return "0"+time+":00";
        }
        else {
            return time+":00";
        }
    }

    /**
     * Increases the day by 1 if the time has just rolled over.
     */
    private void updateDay()
    {
        if (time == 0){
            day++;
        }
    }

    /**
     * @return The day and current weather as a string.
     */
    private String getDayWeatherString()
    {
        return ""+day+" ("+weather+")";
    }

    /**
     * Method to draw the ponds in the simulation
     *
     * Goes through every grid position that is capable of drawing
     * a pond. If the probability is less than or equal to the 
     * pond creation probability, it then creates water objects to 
     * fill the circle.
     * 
     * Formula for this is based on the modification of the formula at
     * https://stackoverflow.com/questions/1201200/fast-algorithm-for-drawing-filled-circles 
     */
    private void renderPond()
    {
        for(int centreY = POND_RADIUS + 1; centreY < (field.getWidth() - POND_RADIUS -1 ); centreY++){
            for(int centreX = POND_RADIUS + 1; centreX < (field.getDepth() - POND_RADIUS - 1); centreX++){
                Random rand = Randomizer.getRandom();
                if (rand.nextDouble() <= POND_CREATION_PROBABILITY){
                    for(int y = -POND_RADIUS; y <= POND_RADIUS; y++){
                        for(int x = -POND_RADIUS; x<= POND_RADIUS; x++){
                            if(x*x+y*y < POND_RADIUS * POND_RADIUS + POND_RADIUS){
                                Location location = new Location(centreX+x, centreY+y);
                                if (!(field.getObjectAt(location) instanceof Water)){
                                    field.clear(location);
                                }
                                field.place(new Water (field,location), location);
                            }
                        }
                    }
                }
            }
        }
    }
    

    /**
     * Method to remove the ponds from the simulation.
     * 
     * Goes through every grid position to check if there's a
     * water object in that location. If so, it removes it.
     */
    private void evaporatePond()
    {
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row,col);
                if (field.getObjectAt(location) instanceof Water){
                    field.clear(location);
                }
            }
        }
    }    

    /**
     * Updates weather based on current weather patterns.
     */
    private void updateWeather()
    {
        Double number = rand.nextDouble();
        if (number > 0.79) {
            for (int i=0;i<allWeather.size();i++) {
                if ((allWeather.get(i).equals(weather)) && (number >= 0.8) && (number < 0.9)) {
                    if (i==allWeather.size() - 1) {
                        weather = allWeather.get(0);
                        break;
                    }
                    else {
                        weather = allWeather.get(i+1);
                        break;
                    }
                }
                else if ((allWeather.get(i).equals(weather)) && (number >= 0.75) && (number < 0.8)) {
                    if (i==allWeather.size() - 1) {
                        weather = allWeather.get(1);
                        break;
                    }
                    else if (i==allWeather.size() - 2) {
                        weather = allWeather.get(0);
                        break;
                    }
                    else {
                        weather = allWeather.get(i+2);
                        break;
                    }
                }
                else if ((allWeather.get(i).equals(weather)) && (number >= 0.69) && (number < 0.70)) {
                    if (i==allWeather.size() - 1) {
                        weather = allWeather.get(2);
                        break;
                    }
                    else if (i==allWeather.size() - 2) {
                        weather = allWeather.get(1);
                        break;
                    }
                    else if (i==allWeather.size() - 3) {
                        weather = allWeather.get(0);
                        break;
                    }
                    else {
                        weather = allWeather.get(i+3);
                        break;
                    }
                }
                else if ((allWeather.get(i).equals(weather)) && number >= 0.9) {
                    if (i==0) {
                        weather = allWeather.get(allWeather.size() - 1);
                        break;
                    }
                    else {
                        weather = allWeather.get(i-1);
                        break;
                    }
                }
                else if ((allWeather.get(i).equals(weather)) && (number >= 0.70) && (number < 0.75)) {
                    if (i==0) {
                        weather = allWeather.get(allWeather.size() - 2);
                        break;
                    }
                    else if (i==1) {
                        weather = allWeather.get(allWeather.size() - 1);
                        break;
                    }
                    else {
                        weather = allWeather.get(i-2);
                        break;
                    }
                }
                else if ((allWeather.get(i).equals(weather)) && (number >= 0.68) && (number < 0.69)) {
                    if (i==0) {
                        weather = allWeather.get(allWeather.size() - 3);
                        break;
                    }
                    else if (i==1) {
                        weather = allWeather.get(allWeather.size() - 2);
                        break;
                    }
                    else if (i==2) {
                        weather = allWeather.get(allWeather.size() - 1);
                        break;
                    }
                    else {
                        weather = allWeather.get(i-3);
                        break;
                    }
                }
            }
        }

    }
    /**
     * Reset the simulation to a starting position.
     */
    private void reset()
    {
        step = 0;
        day = 1;
        time = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, getDayWeatherString(), getTimeString());
    }

    /**
     * Randomly populate the field with the organisms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(true, field, location);
                    organisms.add(hawk);
                }
                else if(rand.nextDouble() <= CATERPILLAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Caterpillar caterpillar = new Caterpillar(true, field, location);
                    organisms.add(caterpillar);
                }
                else if(rand.nextDouble() <= GRASSHOPPER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    GrassHopper grasshopper = new GrassHopper(true, field, location);
                    organisms.add(grasshopper);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    organisms.add(snake);
                }
                else if(rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bird bird = new Bird(true, field, location);
                    organisms.add(bird);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    organisms.add(frog);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    organisms.add(grass); 
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}