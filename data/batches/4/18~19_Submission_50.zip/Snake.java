import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A simple model of a snake.
 * Snakes age, move, eats frogs and caterpillars,sleep, gets infected and die.
 *
 * @version 2018.02.22
 */
public class Snake extends Animal
{
    // Characteristics shared by all snakes (class variables).
    
    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a snake can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.36;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single prey. In effect, this is the
    // number of steps a frog or caterpillar can go before it has to eat again.
    private static final int FROG_FOOD_VALUE = 100;
    private static final int CATERPILLAR_FOOD_VALUE = 90;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // When the snake is sleeping.
    private static final ArrayList<Integer> bed = new ArrayList<>(Arrays.asList(1,2,3,4,5,6));   
    // The probability of the snake getting a disease.
    private static final double DISEASE_PROBABILITY = 0.01;
    // The probability of how much the snake's stats will be affected by the disease.
    private static final double DISEASE_MODIFIER = 0.4;
    // What type of animal is the snake, prey or predator.
    private static final String type = "Predator";
    
    // Individual characteristics (instance fields).
    // Holds whether the snake is infected.
    private boolean isInfected;
    // The snake's age.
    private int age;
    // The snake's gender. True represents one gender and false represents the other.
    private boolean gender;
    // Snakee's food level.
    private int foodLevel;

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        gender = rand.nextBoolean();
        int initFoodLevel = rand.nextInt(2);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            if (initFoodLevel == 0){
                foodLevel = rand.nextInt(FROG_FOOD_VALUE);
            }
            else{
                foodLevel = rand.nextInt(CATERPILLAR_FOOD_VALUE);
            }
        }
        else {
            age = 0;
            if (initFoodLevel == 0){
                foodLevel = FROG_FOOD_VALUE;
            }
            else {
                foodLevel = CATERPILLAR_FOOD_VALUE;
            }
        }
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * @return The age of the snake
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set the age of the snake
     * @param newAge The new age of the snake
     */
    public void setAge(int newAge){
        age = newAge;
    }
    
    /**
     * @return The maximum age of the snake
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return The breeding age of the snake
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return The breeding probability of the snake
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return the maximum litter size of the snake
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return Rand which is used for the randomiser
     */
    public Random getRand()
    {
        return rand;
    }
    
    /**
     * @return food level the snake is at
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the food level
     * @param newFoodLevel The new food level of the snake
     */
    public void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }
    
    /**
     * @return The food value for a frog
     */
    public int getFoodValueFrog()
    {
        return FROG_FOOD_VALUE;
    }
    
    /**
     * @return The food value for a caterpillar
     */
    public int getFoodValueCaterpillar()
    {
        return CATERPILLAR_FOOD_VALUE;
    }   

    /**
     * Look for caterpillars and frogs adjacent to the current location.
     * Only the first live caterpillars or frogs is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isAlive()) { 
                    frog.setDead();
                    foodLevel = FROG_FOOD_VALUE;
                    return where;
                }
            }
            else if (animal instanceof Caterpillar) {
                Caterpillar caterpillar = (Caterpillar) animal;
                if(caterpillar.isAlive()) { 
                    caterpillar.setDead();
                    foodLevel = CATERPILLAR_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * @return The bedtime for the animal.
     */
    public ArrayList<Integer> getBed()
    {
        return bed;
    }
    
    /**
     * @return The gender of the snake.
     */
    public boolean getGender()
    {
        return gender;
    }
    
    /**
     * @return probability of disease happening.
     */
    public double getDiseaseProbability()
    {
        return DISEASE_PROBABILITY;
    }
    
    /**
     * @return how much snake's stats will be affected by disease.
     */
    public double getDiseaseModifier()
    {
        return DISEASE_MODIFIER;
    }
    
    /**
     * @return whether the snake is infected.
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the snake infected with the disease.
     */
    public void setInfection()
    {
        isInfected = true;
    }
    
    /**
     * @return The snake's classification type.
     */
    public String getType()
    {
        return type;
    }
}