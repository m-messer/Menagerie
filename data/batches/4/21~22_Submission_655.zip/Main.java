/**
 * A simple Main class which is used to quickly initialise the 
 * simulation.
 *
 * @version 26/02/2022
 */
public class Main
{
    public static void main(String[] args) {
        Simulator simulator = new Simulator();
    }
}
