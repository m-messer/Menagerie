package environment.livingthings;

import java.util.List;
import java.util.Random;

import simulator.Randomizer;
import simulator.field.Field;
import simulator.field.entity.Entity;
import simulator.field.entity.Location;

/**
 * A class representing shared characteristics of all Living Things in this
 * simulation A Living Thing is a Entity Living things must be alive, have a
 * location, and be on a field.
 * 
 * @version 2019.02.20
 */
public abstract class LivingThing extends Entity {

	protected static final Random rand = Randomizer.getRandom();

	// Determine whether the living thing is alive or not.
	private boolean alive;

	/**
	 * Create a new Living Thing at location in field.
	 * 
	 * @param field
	 *            The field currently occupied.
	 * @param location
	 *            The location within the field.
	 */
	public LivingThing(Field field, Location location) {
		super(field, location);
		alive = true;
	}

	/**
	 * Determine whether the living thing is alive or not.
	 * 
	 * @return true if the living thing is still alive.
	 */
	public boolean isAlive() {
		return alive;
	}

	/**
	 * Indicate that the living thing is no longer alive.
	 */
	public void setDead() {
		alive = false;
		if (location != null) {
			field.clear(location);
			location = null;
			field = null;
		}
	}

	/**
	 * The living thing can be removed from the field whenever it is dead.
	 * 
	 * @return true if the living thing is dead and can be removed from the field.
	 */
	@Override
	protected boolean canRemove() {
		return !isAlive();
	}

	/**
	 * Check whether or not this living thing is reproducing at this step.
	 * Reproduced living things will be added to free adjacent locations.
	 * 
	 * @param newAnimals
	 *            A list to return newly added living things.
	 */
	protected void reproduce(List<LivingThing> newLivingThings) {
		// New foxes are born into adjacent locations.
		// Get a list of adjacent free locations.
		Field field = getField();
		List<Location> free = field.getFreeAdjacentLocations(getLocation());
		int offSprings = breed();
		for (int b = 0; b < offSprings && free.size() > 0; b++) {
			Location location = free.remove(0);
			LivingThing offSpring = createOffSpring(location);
			newLivingThings.add(offSpring);
		}
	}

	/**
	 * Generate a number representing the number of births, if it can breed.
	 * 
	 * @return The number of births (may be zero).
	 */
	private int breed() {
		int births = 0;
		if (canBreed() && rand.nextDouble() <= getBreedingProbability()) {
			births = rand.nextInt(getMaxLitterSize()) + 1;
		}
		return births;
	}

	/**
	 * Return whether or not a Living Thing can breed (at this time).
	 * 
	 * @return whether or not a Living Thing can breed (at this time).
	 */
	protected abstract boolean canBreed();

	/**
	 * Return a newly created LivingThing.
	 * 
	 * @return a newly created LivingThing.
	 */
	protected abstract LivingThing createOffSpring(Location location);

	/**
	 * Return the probability a living thing can breed.
	 * 
	 * @return the probability a living thing can breed.
	 */
	protected abstract double getBreedingProbability();

	/**
	 * Return the maximum amount of living things which can produced.
	 * 
	 * @return the maximum amount of living things which can be produced.
	 */
	protected abstract int getMaxLitterSize();

}
