package environment.livingthings.animals.properties;

import java.util.Arrays;
import java.util.List;

import simulator.field.Field;
import simulator.field.entity.Location;

/**
 * This is the Predator interface. It is created to help with future
 * implementation of what a predator must do in this application. At the moment
 * all Predators must compete. This should be extended in the future. All
 * Predators are Carnivores, thus extending the Carnivore interface.
 *
 * @version 2019.20.2
 */
public interface Predator extends Carnivore {

	/**
	 * Return the predator's food sources.
	 * 
	 * @return the predator's food sources.
	 */
	Class[] getFoodSources();

	/**
	 * Return the strengh of a predator.
	 * 
	 * @return the strength of the predator.
	 */
	int getStrength();

	/**
	 * Return the predator's location.
	 * 
	 * @return the predator's location.
	 */
	Location getLocation();

	/**
	 * Return the predator's field.
	 * 
	 * @return the predator's field.
	 */
	Field getField();

	/**
	 * Return whether a predator is alive.
	 * 
	 * @return true if the predator is alive.
	 */
	boolean isAlive();

	/**
	 * Sets the predator to be dead.
	 */
	void setDead();

	/**
	 * The compete method has a predator compete with any predators who eats the
	 * same food source. When a predator competes they will kill the other predator
	 * if their strength is higher than or equal to theirs and they will die if
	 * their strength is higher than or equal to the other predators. Two predators
	 * of the same species will not compete with each other.
	 */
	default void compete() {
		Class[] foodSources = getFoodSources();
		Location location = getLocation();
		Field field = getField();

		if (location != null) {
			field.adjacentObjects(location).stream().filter(obj -> obj instanceof Predator)
					.filter(obj -> obj.getClass() != this.getClass()).map(obj -> (Predator) obj).forEach(predator -> {

						for (int i = 0; i < foodSources.length; i++) {
							List<Class> predatorFoodSources = Arrays.asList(predator.getFoodSources());
							if (predatorFoodSources.contains(foodSources[i])) {
								if (getStrength() > predator.getStrength()) {
									predator.setDead();
								} else if (getStrength() < predator.getStrength()) {
									setDead();
								} else {
									predator.setDead();
									setDead();
								}
							}
						}
					});
		}
	}

}
