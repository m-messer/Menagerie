/**
 * This is the Carnivore interface. It is created to help with future implementation of what a carnivore
 * must do in this application. At the moment all Carnivores must eat food but this should be extended in the future.
 * @version 2019.20.2
 */

package environment.livingthings.animals.properties;

import environment.livingthings.Food;

/**
 * This is the Carnivore interface. It is created to help with future
 * implementation of what a Carnivore must do in this application. At the moment
 * all Carnivores must eat food but this should be extended in the future.
 * Could be used as a marker interface.
 *
 * @version 2019.20.2
 */
public interface Carnivore {
	
	/**
	 * Method for a Carnivore to eat food
	 * 
	 * @param food
	 */
	void eat(Food food);
}
