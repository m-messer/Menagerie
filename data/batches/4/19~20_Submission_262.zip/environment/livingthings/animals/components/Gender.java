package environment.livingthings.animals.components;

/**
 * An enumeration class containing variables representing gender in this
 * simulation
 * 
 * @version 2019.02.20
 */
public enum Gender {
	MALE, FEMALE
}
