package environment.livingthings.animals.components.diseases;

import environment.livingthings.animals.Animal;

/**
 * This is a class representing Diseases in this simulation Diseases are
 * obtained by animals and affect them in different ways.
 * 
 * @version 2019.02.20
 */
public abstract class Disease {
	/**
	 * A method describing how a disease will impact an animal.
	 * 
	 * @param animal
	 *            The animal to be impacted by the disease.
	 */
	public abstract void affect(Animal animal);

	/**
	 * Specify whether or not a disease spreads upon birth.
	 * 
	 * @return true by default.
	 */
	public boolean affectsOffSpring() {
		return true;
	}

	/**
	 * Return a new instance of the same disease.
	 * 
	 * @return a new instance of the same disease.
	 */
	public abstract Disease newDiseaseInstance();

}
