package environment.time;

/**
 * An enumeration class containing variables representing the time of day in
 * this simulation. Some of these are unused but can be implemented in the future.
 *
 * @version 2019.02.20
 */
public enum TimeOfDay {
	MORNING, NOON, EVENING, NIGHT
}
