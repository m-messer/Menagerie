package environment.time;

/**
 * A class representing the time in the simulation The TimeStorage object holds
 * the days, hours, and minutes since the begininning of the simulation and
 * updates them.
 *
 * @version 2019.02.20
 */
public class TimeStorage {
	private int days;
	private int hours;
	private int minutes;
	private TimeOfDay timeOfDay;

	/**
	 * A constructor creating a TimeStorage object at a specific time.
	 * 
	 * @param days
	 * @param hours
	 * @param minutes
	 */
	public TimeStorage(int days, int hours, int minutes) {
		this.days = days;
		this.hours = hours;
		this.minutes = minutes;
		updateTimeOfDay();
	}

	/**
	 * A default constructor creating a Time Storage object at 1 day, 0 hours, 0
	 * minutes (the start of a simulation)
	 */
	public TimeStorage() {
		this(1, 0, 0);
	}

	/**
	 * Increases the time in the simulation by the given minutes.
	 * 
	 * @param minutes
	 *            Minutes to increase the time by.
	 */
	public void increaseTimeByMinutes(int minutes) {
		if ((this.minutes + minutes) > 59) {
			increaseTimeByHours(1);
		}
		this.minutes = (this.minutes + minutes) % 60;
		updateTimeOfDay();
	}

	/**
	 * Increases the time in the simulation by the given hours.
	 * 
	 * @param minutes
	 *            Hours to increase the time by.
	 */
	public void increaseTimeByHours(int hours) {
		if ((this.hours + hours) > 23) {
			increaseTimeByDays(1);
		}
		this.hours = (this.hours + hours) % 24;
		updateTimeOfDay();
	}

	/**
	 * Increases the time in the simulation by the given days.
	 * 
	 * @param minutes
	 *            Days to increase the time by.
	 */
	public void increaseTimeByDays(int days) {
		this.days += days;
		updateTimeOfDay();
	}

	/**
	 * Updates the time of day (Morning/ Night) in the simulation depending on what
	 * the current hour in the day is.
	 * 
	 * Night & Day each last 12 hours.
	 */
	private void updateTimeOfDay() {
		if (hours >= 6 && hours < 18)
			timeOfDay = TimeOfDay.MORNING;
		if (hours < 6 || hours >= 18)
			timeOfDay = TimeOfDay.NIGHT;
	}

	/**
	 * Set the current time to a different time using a different TimeStorage
	 * object.
	 * 
	 * @param timeStorage
	 *            Time to set.
	 */
	public void setTime(TimeStorage timeStorage) {
		this.days = timeStorage.days;
		this.hours = timeStorage.hours;
		this.minutes = timeStorage.minutes;
	}

	/**
	 * Set the current time of the simulation by inputting days, hours, and minutes.
	 * 
	 * @param days
	 * @param hours
	 * @param minutes
	 */
	public void setTime(int days, int hours, int minutes) {
		this.days = days;
		this.hours = hours;
		this.minutes = minutes;
	}

	/**
	 * Return the time of the day.
	 * 
	 * @return the time of the day.
	 */
	public TimeOfDay getTimeOfDay() {
		return timeOfDay;
	}

	@Override
	public String toString() {
		return "Day: " + days + " Time: " + hours + ":" + minutes;
	}

	/**
	 * Compares the given time (TimeStorage object) with this one.
	 * 
	 * @param time
	 *            Time to compare with.
	 * 
	 * @return 1 if this TimeStorage object has greater time value, 0 if equal, -1
	 *         if inputted parameter has greater TimeStorage value.
	 * 
	 */
	public int compare(TimeStorage time) {
		if (days > time.days)
			return 1;
		if (days < time.days)
			return -1;
		if (hours > time.hours)
			return 1;
		if (hours < time.hours)
			return -1;
		if (minutes > time.minutes)
			return 1;
		if (minutes < time.minutes)
			return -1;
		return 0;
	}

	/**
	 * Return the days.
	 * 
	 * @return the days.
	 */
	public int getDays() {
		return days;
	}

	/**
	 * Return the hours.
	 * 
	 * @return the hours.
	 */
	public int getHours() {
		return hours;
	}

	/**
	 * Return the minutes.
	 * 
	 * @return the minutes.
	 */
	public int getMinutes() {
		return minutes;
	}
}
