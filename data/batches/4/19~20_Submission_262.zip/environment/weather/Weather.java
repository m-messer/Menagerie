package environment.weather;

import java.util.Random;

import environment.time.TimeStorage;
import simulator.Randomizer;

/**
 * A class representing the weather of the simulation The Weather of the
 * simulation gives the current weather condition and a boolean showing if it is
 * raining or not. The stopping time is used to determine when the current
 * weather condition will stop so that a new random weather condition can be set.
 *
 * @version 2019.02.20
 */

public class Weather {
	
	private static final Random rand = Randomizer.getRandom();

	// How many days a weather condition will last.
	private static final int MAX_DAYS_DURATION = 0;
	// How many hours a weather condition will last.
	private static final int MAX_HOURS_DURATION = 5;
	// How many minutes a weather condition will last.
	private static final int MAX_MINUTES_DURATION = 0;

	// The condition of the weather.
	private Condition condition;

	// Determine whether it is raining.
	private boolean isRaining;

	// Determine when the current weather condition will stop and the weather will
	// change.
	private TimeStorage stopTime;

	/**
	 * Constructor creating a Weather object with a Condition and isRaining boolean
	 * 
	 * @param condition
	 *            The initial condition of the weather.
	 * @param isRaining
	 *            Determine if it is initially raining.
	 */
	public Weather(Condition condition, boolean isRaining) {
		this.condition = condition;
		this.isRaining = isRaining;
		stopTime = new TimeStorage();
	}

	/**
	 * Sets the current time of the simulation to an inputted TimeStorage object
	 * 
	 * @param timeStorage
	 */
	public void setCurrentTime(TimeStorage timeStorage) {
		stopTime.setTime(timeStorage);
	}

	/**
	 * Changes the weather randomly
	 */
	public void change() {
		setRandomCondition();
		setRandomDuration();
	}

	/**
	 * Set a random condition of the weather.
	 */
	private void setRandomCondition() {
		Condition[] conditions = Condition.values();
		condition = conditions[rand.nextInt(conditions.length)];
		isRaining = rand.nextBoolean();
	}

	/**
	 * Set a random stopping time of the current condition.
	 */
	private void setRandomDuration() {
		stopTime.increaseTimeByDays(rand.nextInt(MAX_DAYS_DURATION + 1));
		stopTime.increaseTimeByHours(rand.nextInt(MAX_HOURS_DURATION + 1));
		stopTime.increaseTimeByMinutes(rand.nextInt(MAX_MINUTES_DURATION + 1));
	}

	/**
	 * Return the condition of the weather.
	 * 
	 * @return the condition of the weather.
	 */
	public Condition getCondition() {
		return condition;
	}

	/**
	 * Return whether it is raining or not.
	 * 
	 * @return whether it is raining or not.
	 */
	public boolean isRaining() {
		return isRaining;
	}

	/**
	 * Returns the stopping time of the current condition.
	 * 
	 * @return the stopping time of the current condition.
	 */
	public TimeStorage getStopTime() {
		return stopTime;
	}

	/**
	 * Returns the condition of the weather in a string format.
	 * 
	 * @return the condition of the weather in a string format.
	 */
	public String getConditionString() {
		return condition.toString();
	}

	/**
	 * Returns whether it is raining or not in a string format.
	 * 
	 * @return "Yes" if it is raining, "No" if it is not raining
	 */
	public String isRainingString() {
		return isRaining ? "Yes" : "No";
	}
}
