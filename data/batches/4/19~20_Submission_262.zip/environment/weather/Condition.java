package environment.weather;

/**
 * An enumeration class containing variables representing the Weather Condition
 * of the simulation
 *
 * @version 2019.02.20
 */
public enum Condition {
	SUNNY, FOGGY, CLOUDY
}
