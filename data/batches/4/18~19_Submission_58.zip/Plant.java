import java.util.List;
import java.util.Iterator;

/**
 * A model for the plants.
 * They can age, breed and die. 
 *
 * @version 2019.02.15
 */
public class Plant extends Animal
{
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge If true, the age will be random.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location, randomAge, 
            Config.Plant_BREEDING_AGE, Config.Plant_MAX_AGE,
            Config.Plant_BREEDING_PROBABILITY, Config.Plant_MAX_LITTER_SIZE,
            false, false);
    }

    /**
     * Make this plant act - age and breed.
     * @param newPlants A list to receive newly born plants.
     */
    public void act(List<Animal> newPlants)
    {
        incrementAge();
        if(Simulator.getRain() && isAlive()){
            giveBirth(newPlants);
        }
    }

    /**
     * Checks if the plant will breed at this step.
     * @param newPlants A list that stores newly born plants.
     */
    private void giveBirth(List<Animal> newPlants)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc);
            newPlants.add(young);
        }
    }
}