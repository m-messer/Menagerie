import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing plants, zebras, lions, wilddogs, antelopes and tigers.
 *
 * @version 2019.02.15
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Whether or not it is day or not
    private static boolean day;
    // Whether it is raining or not
    private static boolean rain;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Zebra.class, Color.BLUE);
        view.setColor(Antelope.class, Color.RED);
        view.setColor(Tiger.class, Color.YELLOW);
        view.setColor(WildDog.class, Color.BLACK);
        view.setColor(Plant.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        day = !day;
        rain = false;
        if(step % 3 == 0){
            rain = !rain;
        }

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        day = true;
        rain = false;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if(rand.nextDouble() <= Config.Zebra_CREATION_PROBABILITY) {
                    Zebra zebra = new Zebra(true, field, location, true, false);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= Config.Antelope_CREATION_PROBABILITY) {
                    Antelope antelope = new Antelope(true, field, location, true, false);
                    animals.add(antelope);
                }
                else if(rand.nextDouble() <= Config.WildDog_CREATION_PROBABILITY) {
                    WildDog wildDog = new WildDog(true, field, location, true, false);
                    animals.add(wildDog);
                }
                else if(rand.nextDouble() <= Config.Tiger_CREATION_PROBABILITY) {
                    Tiger tiger = new Tiger(true, field, location, true, false);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= Config.Lion_CREATION_PROBABILITY) {
                    Lion lion = new Lion(true, field, location, true, false);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= Config.Plant_CREATION_PROBABILITY){
                    Plant plant = new Plant(true, field, location);
                    animals.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Returns true if it is day
     */
    public static boolean getDay() {
        return day;
    }

    /**
     * Returns true if it is raining
     */
    public static boolean getRain(){
        return rain;
    }
}
