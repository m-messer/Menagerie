
/**
 * Stores all the values for each animal.
 *
 * @version 2019.02.15
 */
public class Config
{
    public static final double Lion_CREATION_PROBABILITY = 0.05;
    public static final int Lion_BREEDING_AGE = 13;
    public static final int Lion_MAX_AGE = 100;
    public static final double Lion_BREEDING_PROBABILITY = 0.3;
    public static final int Lion_MAX_LITTER_SIZE = 4;

    public static final int Lion_TIGER_FOOD_VALUE = 10;
    public static final int Lion_ANTELOPE_FOOD_VALUE = 9;
    public static final int Lion_ZEBRA_FOOD_VALUE = 8;
    public static final int Lion_WILDDOG_FOOD_VALUE = 5;
    public static final int Lion_PLANT_FOOD_VALUE = 2;

    public static final double Tiger_CREATION_PROBABILITY = 0.06;
    public static final int Tiger_BREEDING_AGE = 13;
    public static final int Tiger_MAX_AGE = 100;
    public static final double Tiger_BREEDING_PROBABILITY = 0.5;
    public static final int Tiger_MAX_LITTER_SIZE = 4;

    public static final int Tiger_ANTELOPE_FOOD_VALUE = 8;
    public static final int Tiger_ZEBRA_FOOD_VALUE = 7;
    public static final int Tiger_WILDDOG_FOOD_VALUE = 4;
    public static final int Tiger_PLANT_FOOD_VALUE = 2;

    public static final double WildDog_CREATION_PROBABILITY = 0.03;
    public static final int WildDog_BREEDING_AGE = 13;
    public static final int WildDog_MAX_AGE = 100;
    public static final double WildDog_BREEDING_PROBABILITY = 0.6;
    public static final int WildDog_MAX_LITTER_SIZE = 4;

    public static final int WildDog_ANTELOPE_FOOD_VALUE = 8;
    public static final int WildDog_ZEBRA_FOOD_VALUE = 7;
    public static final int WildDog_PLANT_FOOD_VALUE = 2;

    public static final double Antelope_CREATION_PROBABILITY = 0.06;
    public static final int Antelope_BREEDING_AGE = 5;
    public static final int Antelope_MAX_AGE = 40;
    public static final double Antelope_BREEDING_PROBABILITY = 0.4;
    public static final int Antelope_MAX_LITTER_SIZE = 4;

    public static final int Antelope_PLANT_FOOD_VALUE = 7;

    public static final double Zebra_CREATION_PROBABILITY = 0.07;
    public static final int Zebra_BREEDING_AGE = 5;
    public static final int Zebra_MAX_AGE = 40;
    public static final double Zebra_BREEDING_PROBABILITY = 0.4;
    public static final int Zebra_MAX_LITTER_SIZE = 4;

    public static final int Zebra_PLANT_FOOD_VALUE = 7;

    public static final double Plant_CREATION_PROBABILITY = 0.40;
    public static final int Plant_BREEDING_AGE = 5;
    public static final int Plant_MAX_AGE = 10;
    public static final double Plant_BREEDING_PROBABILITY = 0.5;
    public static final int Plant_MAX_LITTER_SIZE = 5;

    public static final double FOOD_DISEASE_PROBABILITY = 0.02;
    public static final double AIDS_PROBABILITY = 0.05;
}
