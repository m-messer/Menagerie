import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.15
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    
    // The animal's gender
    private boolean isMale;
    
    // The animal's age.
    protected int age;
    
    // The age at which an animal can start to breed.
    private int breedingAge;
    // The age to which an animal can live.
    private int maxAge;
    // The likelihood of an animal breeding.
    private double breedingProbability;
    // The maximum number of births.
    private int maxLitterSize;
    // The food level of the animal
    protected int foodLevel;
    // The animals disease (food or aids)
    private boolean foodDisease;
    private boolean aids;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge If true, the age will be random.
     * @param breedingAge The age at which the animal can begin to breed.
     * @param maxAge The maximum age of the animal.
     * @param breedingProbability The likelihood that an animal will breed.
     * @param maxLitterSize The maximum number of offspring an animal can have.
     * @param randomDisease If true, the animal will be infected randomly.
     * @param aids If true the animal has aids.
     */
    public Animal(Field field, Location location, boolean randomAge, 
        int breedingAge, int maxAge, double breedingProbability, 
        int maxLitterSize, boolean randomDisease, boolean aids)
    {
        alive = true;
        this.field = field;
        setLocation(location);

        age = 0;
        if (randomAge)
            age = rand.nextInt(maxAge);

        isMale = rand.nextBoolean();
        this.breedingAge = breedingAge;
        this.maxAge = maxAge;
        this.breedingProbability = breedingProbability;
        this.maxLitterSize = maxLitterSize;

        foodDisease = false;
        this.aids = aids;
        if (randomDisease) {
            foodDisease = (rand.nextDouble() <= Config.FOOD_DISEASE_PROBABILITY);
            aids = (rand.nextDouble() <= Config.AIDS_PROBABILITY);
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null)
            field.clear(location);

        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Returns true if they are male.
     */
    protected boolean getGender()
    {
        return isMale;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= breedingProbability)
            births = rand.nextInt(maxLitterSize) + 1;

        return births;
    }

    /**
     * A animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= breedingAge;
    }

    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > maxAge)
            setDead();
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if (foodDisease)
            foodLevel--;

        if (aids)
            foodLevel--;

        if(foodLevel <= 0)
            setDead();

    }
    
    /**
     * Make this eat.
     * @param animal The animal to be eaten
     * @param foodValue The food value of the animal eaten
     */
    protected void eat(Animal animal, int foodValue)
    {
        if (animal.isAlive()) {
            if (animal.getFoodDisease())
                foodDisease = true;

            animal.setDead();
            foodLevel = foodLevel + foodValue;
        }
    }
    
    /**
     * Returns true if they have the disease.
     */
    protected boolean getFoodDisease() 
    {
        return foodDisease;
    }
    
    /**
     * Returns true if they have aids.
     */
    protected boolean getAids() 
    {
        return aids;
    }
}
