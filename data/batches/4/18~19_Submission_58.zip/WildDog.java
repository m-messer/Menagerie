import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wilddog.
 * WildDogs age, move, eat animals, and die.
 *
 * @version 2019.02.15
 */
public class WildDog extends Animal
{
    // Characteristics shared by all wilddoges (class variables).

    // The food value of a single animal that is eaten by a wilddog. In effect, this is the
    // number of steps a wilddog can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = Config.WildDog_ANTELOPE_FOOD_VALUE;
    private static final int ZEBRA_FOOD_VALUE = Config.WildDog_ZEBRA_FOOD_VALUE;
    private static final int PLANT_FOOD_VALUE = Config.WildDog_PLANT_FOOD_VALUE;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a wilddog. A wilddog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wilddog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.    
     * @param randomDisease If true, the wilddog will be infected randomly.
     * @param aids If true the wilddog has aids.
     */
    public WildDog(boolean randomAge, Field field, Location location,
    boolean randomDisease, boolean aids)
    {
        super(field, location, randomAge, 
            Config.WildDog_BREEDING_AGE, Config.WildDog_MAX_AGE,
            Config.WildDog_BREEDING_PROBABILITY, Config.WildDog_MAX_LITTER_SIZE,
            randomDisease, aids);

        if(randomAge)
            foodLevel = rand.nextInt(30);
        else
            foodLevel = 30;
    }

    /**
     * This is what the wilddog does most of the time: it hunts for
     * animals. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newWildDogs A list to return newly born wild dogs.
     */
    public void act(List<Animal> newWildDogs)
    {
        incrementAge();
        incrementHunger();
        if (!Simulator.getDay() && !Simulator.getRain() && isAlive()) {
            giveBirth(newWildDogs);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {   
        int counter = -1;
        int eatLocation = 0;
        boolean isAntelope = false;
        boolean isZebra = false;
        boolean isPlant = false;
        int FOOD_VALUE = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            counter++;
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) {
                eatLocation = counter;
                FOOD_VALUE = ANTELOPE_FOOD_VALUE;
                isAntelope = true;
            } else if (animal instanceof Zebra && !isAntelope) {
                eatLocation = counter;
                FOOD_VALUE = ZEBRA_FOOD_VALUE;
                isZebra = true;
            } else if (animal instanceof Plant && !isAntelope && !isZebra){
                eatLocation = counter;
                FOOD_VALUE = PLANT_FOOD_VALUE;
                isPlant = true;
            }
        }
        if(isZebra || isAntelope || isPlant){
            eat((Animal) field.getObjectAt(adjacent.get(eatLocation)), FOOD_VALUE);
            return adjacent.get(eatLocation);
        }
        return null;
    }

    /**
     * Check whether or not this wilddog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWildDogs A list to return newly born wilddogs.
     */
    private void giveBirth(List<Animal> newWildDogs)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while (it.hasNext()) {
            Location where = it.next();
            Object thing = field.getObjectAt(where);
            if (thing instanceof WildDog) {
                Animal animal = (Animal) thing;
                if (animal.getGender() != getGender()) {
                    // New wilddogs are born into adjacent locations.
                    // Get a list of adjacent free locations.
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        boolean gotAids = getAids() || animal.getAids();
                        Location loc = free.remove(0);
                        WildDog young = new WildDog(false, field, loc, false, gotAids);
                        newWildDogs.add(young);
                    }
                }
            }
        }
    }
}
