import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A model of the antelope.
 *
 * @version 2019.02.15
 */
public class Antelope extends Animal
{
    private static final int PLANT_FOOD_VALUE = Config.Antelope_PLANT_FOOD_VALUE;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create an antelope. An antelope can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the antelope will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.    
     * @param randomDisease If true, the antelope will be infected randomly.
     * @param aids If true the antelope has aids.
     */
    public Antelope(boolean randomAge, Field field, Location location,
    boolean randomDisease, boolean aids)
    {
        super(field, location, randomAge, 
            Config.Antelope_BREEDING_AGE, Config.Antelope_MAX_AGE,
            Config.Antelope_BREEDING_PROBABILITY, Config.Antelope_MAX_LITTER_SIZE,
            randomDisease, aids);

        if(randomAge)
            foodLevel = rand.nextInt(20);
        else
            foodLevel = 20;
    }
    
    /**
     * This is what the antelope does most of the time: it hunts for
     * animals. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newAntelopes A list to return newly born antelopes.
     */
    public void act(List<Animal> newAntelopes)
    {
        incrementAge();
        incrementHunger();
        if(Simulator.getDay() && isAlive()){
            giveBirth(newAntelopes);            
            Location newLocation = findFood();

            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if(newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }
    /**
     * Check whether or not this antelope is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAntelopes A list to return newly born antelopes.
     */
    private void giveBirth(List<Animal> newAntelopes)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while (it.hasNext()) {
            Location where = it.next();
            Object thing = field.getObjectAt(where);
            if (thing instanceof Antelope) {
                Animal animal = (Animal) thing;
                if (animal.getGender() != getGender()) {
                    // New antelopes are born into adjacent locations.
                    // Get a list of adjacent free locations.
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        boolean gotAids = getAids() || animal.getAids();
                        Location loc = free.remove(0);
                        Antelope young = new Antelope(false, field, loc, false, gotAids);
                        newAntelopes.add(young);
                    }
                }
            }
        }

    }

    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                eat((Animal) animal, PLANT_FOOD_VALUE);
                return where;
            }
        }
        return null;
    }
}
