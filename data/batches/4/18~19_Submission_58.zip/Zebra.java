import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A model for zebras - they can move, breed, eat and die.
 *
 * @version 2019.02.15
 */
public class Zebra extends Animal
{
    private static final int PLANT_FOOD_VALUE = Config.Zebra_PLANT_FOOD_VALUE;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new zebra at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge If true, the age will be random.
     * @param randomDisease If true, the zebra will be infected randomly.
     * @param aids If true the zebra has aids.
     */
    public Zebra(boolean randomAge, Field field, Location location,
    boolean randomDisease, boolean aids)
    {
        super(field, location, randomAge, 
            Config.Zebra_BREEDING_AGE, Config.Zebra_MAX_AGE,
            Config.Zebra_BREEDING_PROBABILITY, Config.Zebra_MAX_LITTER_SIZE,
            randomDisease, aids);

        if(randomAge)
            foodLevel = rand.nextInt(20);
        else
            foodLevel = 20;
    }

    /**
     * Make this zebra act.
     * @param newZebras A list to receive newly born zebras.
     */
    public void act(List<Animal> newZebras)
    {
        incrementAge();
        incrementHunger();
        if(!Simulator.getRain() && !Simulator.getDay() && isAlive()){
            giveBirth(newZebras);            
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Checks if the zebra will breed at this step.
     * @param newZebras A list that stores newly born zebras.
     */
    private void giveBirth(List<Animal> newZebras)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while (it.hasNext()) {
            Location where = it.next();
            Object thing = field.getObjectAt(where);
            if (thing instanceof Zebra) {
                Animal animal = (Animal) thing;
                if (animal.getGender() != getGender()) {
                    // New zebras are born into adjacent locations.
                    // Get a list of adjacent free locations.
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        boolean gotAids = getAids() || animal.getAids();
                        Location loc = free.remove(0);
                        Zebra young = new Zebra(false, field, loc, false, gotAids);
                        newZebras.add(young);
                    }
                }
            }
        }

    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                eat((Animal) animal, PLANT_FOOD_VALUE);
                return where;
            }
        }
        return null;
    }

}
