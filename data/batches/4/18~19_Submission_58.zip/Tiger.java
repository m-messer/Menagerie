import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a tiger.
 * Tigers age, move, eat animals, and die.
 *
 * @version 2019.02.15
 */
public class Tiger extends Animal
{
    // Characteristics shared by all tigeres (class variables).
    
    // The food value of a single rabbit. In effect, this is the
    // number of steps a tiger can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = Config.Tiger_ANTELOPE_FOOD_VALUE;
    private static final int ZEBRA_FOOD_VALUE = Config.Tiger_ZEBRA_FOOD_VALUE;
    private static final int WILDDOG_FOOD_VALUE = Config.Tiger_WILDDOG_FOOD_VALUE;
    private static final int PLANT_FOOD_VALUE = Config.Tiger_PLANT_FOOD_VALUE;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    
    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomDisease If true, the tiger will be infected randomly.
     * @param aids If true the tiger has aids.
     */
    public Tiger(boolean randomAge, Field field, Location location,
                 boolean randomDisease, boolean aids)
    {
        super(field, location, randomAge, 
            Config.Tiger_BREEDING_AGE, Config.Tiger_MAX_AGE,
            Config.Tiger_BREEDING_PROBABILITY, Config.Tiger_MAX_LITTER_SIZE,
            randomDisease, aids);
        if(randomAge)
            foodLevel = rand.nextInt(ANTELOPE_FOOD_VALUE);
        else
            foodLevel = ANTELOPE_FOOD_VALUE;
    }
    
    /**
     * This is what the tiger does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newTigers A list to return newly born tigers.
     */
    public void act(List<Animal> newTigers)
    {
        incrementAge();
        incrementHunger();
        if (Simulator.getDay() && isAlive()) {
            giveBirth(newTigers);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {   
        int counter = -1;
        int eatLocation = 0;
        boolean isWildDog = false;
        boolean isAntelope = false;
        boolean isZebra = false;
        boolean isPlant = false;
        int FOOD_VALUE = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            counter++;
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) {
                eatLocation = counter;
                FOOD_VALUE = ANTELOPE_FOOD_VALUE;
                isAntelope = true;
            } else if (animal instanceof Zebra && !isAntelope) {
                eatLocation = counter;
                FOOD_VALUE = ZEBRA_FOOD_VALUE;
                isZebra = true;
            } else if (animal instanceof WildDog && !isAntelope && !isZebra) {
                eatLocation = counter;
                FOOD_VALUE = WILDDOG_FOOD_VALUE;
                isWildDog = true;
            } else if (animal instanceof Plant && !isAntelope && !isWildDog && !isZebra){
                eatLocation = counter;
                FOOD_VALUE = PLANT_FOOD_VALUE;
                isPlant = true;
            }
        }
        if(isWildDog || isZebra || isAntelope || isPlant){
            eat((Animal) field.getObjectAt(adjacent.get(eatLocation)), FOOD_VALUE);
            return adjacent.get(eatLocation);
        }
        return null;
    }
    
    /**
     * Check whether or not this tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTigers A list to return newly born tigers.
     */
    private void giveBirth(List<Animal> newTigers)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while (it.hasNext()) {
            Location where = it.next();
            Object thing = field.getObjectAt(where);
            if (thing instanceof Tiger) {
                Animal animal = (Animal) thing;
                if (animal.getGender() != getGender()) {
                    // New tigeres are born into adjacent locations.
                    // Get a list of adjacent free locations.
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        boolean gotAids = getAids() || animal.getAids();
                        Location loc = free.remove(0);
                        Tiger young = new Tiger(false, field, loc, false, gotAids);
                        newTigers.add(young);
                    }
                }
            }
        }
    }
}
