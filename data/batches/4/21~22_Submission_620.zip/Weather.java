/**
 * Enumeration class Weather - The different possible types of weather simulated in the safari simulation.
 *
 * @version 2022.03.01
 */
public enum Weather
{
    SUNNY, RAINY, FOGGY;

}
