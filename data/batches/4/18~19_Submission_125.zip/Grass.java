import java.util.List;
import java.util.Random;

/**
 * Write a description of class Grass here.
 * @version (a version number or a date)
 */
public class Grass extends Plant
{
    // instance variables - replace the example below with your own
    // The age at which a grass can start to breed.
    private static final int POLLINATION_AGE = 10;
    // The age to which a grass can live.
    private static final int MAX_AGE = 300;
    // The likelihood of a grass pollination.
    private static final double POLLINATION_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_SEEDS_SIZE = 4;
    // A shared random number generator to control pollination.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The grass's age.
    private int age;
    
    //pollination increases depending on a number of different factors.
    private static double pollination_MODIFIER;
    /**
     * Constructor for objects of class Grass
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        age = 0;
        pollination_MODIFIER = 1;
        if(randomAge) {
           age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the grass does most of the time - it runs 
     * around. Sometimes it will grow or die of old age.
     * Different weather situations affect how it will grow
     * @param newgrasss A list to return newly born grasss.
     */
    public void act(List<Plant> newGrass, boolean isNight, String currentWeather)
    {
        incrementAge();
        if(isNight == false){
            pollination_MODIFIER = 1;  
        }
        else{
            pollination_MODIFIER = 0.8;        //Grass grows less during night.
        }
        
        if(currentWeather.equals("Sunny")) {
            pollination_MODIFIER = 1;
        }
        else if(currentWeather.equals("Rainy")){
            pollination_MODIFIER = 1.2;       //Grass will grow very fast during rain.
        }
        else if(currentWeather.equals("Foggy")){
            pollination_MODIFIER = 0.5; //grass will slow very slowly when it is foggy.
        }
        
        if(isAlive()) {
            pollination(newGrass);   
        }
        else {
            // Overcrowding.
            setDead();
            }
    }
    
    /**
     * Increase the age.
     * This could result in the grass's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newgrasss A list to return newly born grasss.
     */
    private void pollination(List<Plant> newGrass)
    {
        // New grasss are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = pollin();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int pollin()
    {
        int pollin = 0;
        if(canBreed() && rand.nextDouble() <= POLLINATION_PROBABILITY*pollination_MODIFIER) {
            pollin = rand.nextInt(MAX_SEEDS_SIZE) + 1;
        }
        return pollin;
    }

    /**
     * A grass can breed if it has reached the pollination age.
     * @return true if the grass can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= POLLINATION_AGE;
    }
}