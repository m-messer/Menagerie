import java.util.List;
import java.util.Random;
/**
 * Write a description of class Plants here.
 *
 * @version (a version number or a date)
 */
public abstract class Plant extends Organism
{
    // Whether the plant is alive or not.
    private Random randomGenerator = new Random();
    /**
     * Constructor for objects of class Plantd
     */
    public Plant(boolean randomAge,Field field, Location location)
    {
        // initialise instance variables
        super(randomAge, field, location);
       
    }
    
    abstract public void act(List<Plant> newPlants, boolean isNight, String currentWeather);    
}
