import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Organism 
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //The animals gender, true if they are male, false if they are female. 
    private boolean isMale;
    //random generator used to generate random number in gender assigment.
    private Random randomGenerator = new Random();
    //Whether or not the animal is infected with the disease.
    private boolean isInfected;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge,Field field, Location location)
    {
        super(randomAge, field, location);
        int randomNumber = randomGenerator.nextInt(2) + 0;
        
        //Give the animals a gender.
        if (randomNumber == 0){
            isMale = true;
        }
        else{
            isMale = false;
        }
        
        randomNumber = randomGenerator.nextInt(100);
        //give some animals a disease.
        if (randomNumber < 25){
            isInfected = true;
        }
        else{
            isInfected = false;
        }        
        
        alive = true;
        this.field = field;
        setLocation(location);        
    }
    
    /**
     * return the animals gender.
     */
    protected boolean getIsMale(){
        return isMale;
    }
    
    /**
     * return the animals disease
     */
    protected boolean getIsInfected(){
        return isInfected;
    }
    
    /**
     * Infect the animal with a disease.
     */
    protected void setInfected(){
        isInfected = true; 
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, boolean isNight, String weather);
    

}
