/**
 * Write a description of class Organism here.
 *
 * @version (a version number or a date)
 */
public class Organism
{
    // instance variables - replace the example below with your own
    // Whether the Organism is alive or not.
    private boolean alive;
    // The Organism's field.
    private Field field;
    // The Organism's position in the field.
    private Location location;
    /**
     * Constructor for objects of class Organism
     */
    protected Organism(boolean randomAge, Field field, Location location)
    {
        // initialise instance variables
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Check whether the Organism is alive or not.
     * @return true if the Organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Return the Organism's location.
     * @return The Organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
   
    /**
     * Return the Organism's field.
     * @return The Organism's field.
     */
    protected Field getField()
    {
        return field;
    }
   
    /**
     * Indicate that the Organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Place the Organism at the new location in the given field.
     * @param newLocation The Organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
}