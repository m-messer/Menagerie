import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.03;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.035;    
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.023;
    // The probability that a hippo will be created in any given grid position.
    private static final double HIPPO_CREATION_PROBABILITY = 0.00;    
    // The probability that a Antelope will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.015;    
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.001;
    // List of animals in the field.
    private List<Animal> animals;
    //List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //A counter for the time.
    private int timer = 12;
    //A boolean value that states whether it is night time. 
    private boolean isNight;
    //A boolean value that states whether an earthquake is occuring. 
    private boolean earthquakeStatus;
    //A list that stores all the weather types
    private List<String> weathers;
    //The current weather in the simulation
    private String currentWeather;
    // A random generator used for randomly choosing the weather
    private Random randomGenerator = new Random();
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        //Create new array.
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        weathers = new ArrayList<>();

        //add different weather situations 
        weathers.add("Sunny");
        weathers.add("Rainy");
        weathers.add("Foggy");

        field = new Field(depth, width);
        updateNight();
        updateWeather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Lion.class, Color.BLUE);
        view.setColor(Hyena.class, Color.CYAN);
        view.setColor(Hippo.class, Color.RED);
        view.setColor(Antelope.class, Color.BLACK);
        view.setColor(Grass.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * lion and zebra and all other animals.
     * Update the current time and weather and possibly simulate an earthquake.
     */
    public void simulateOneStep()
    {
        step++;
        if (step % 5 == 0){ //1 hour is equal to 5 steps. 
            updateTime();
            updateNight();
        }

        if (step % 120 == 0){   //weather changes every 120 steps.
            updateWeather();
        }

        if (step % 150 == 0){  //Chance of earthquake every 150 steps.
            earthquakeCheck();
        }

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();

        //let all plants act.
        if (!earthquakeStatus){
            for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
                Plant plant = it.next();
                plant.act(newPlants, isNight, currentWeather);
                if(! plant.isAlive()) {
                    it.remove();
                }
            }

            // Let all animals act.
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                animal.act(newAnimals, isNight, currentWeather);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
        }
        else{
            
            view.showStatus(step, field, getTimeString(), getIsNight(), currentWeather, earthquakeStatus);
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                int randomNumber = randomGenerator.nextInt(101);
                if (randomNumber >= 10){
                    animal.setDead();
                    delay(1); //Delay will stop the simulation for some time to show the impact of the earthquake.
                }
                else{
                    animal.act(newAnimals, isNight, currentWeather);
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }
            }
            earthquakeStatus = false; 
        }
        // Add the newly born lions and zebras to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);
        view.showStatus(step, field, getTimeString(), getIsNight(), currentWeather, earthquakeStatus);

    }
    
    /**
     * Randomly generates a number which determines whether an earthquake will occurr. 
     */
    private void earthquakeCheck(){
        int randomNumber = randomGenerator.nextInt(1000);
        if (randomNumber > 995){
            earthquakeStatus = true;
        }
        else{
            earthquakeStatus = false;
        }
    }

    /**
     * Get the current time and check to see if it's day time or night.
     */
    private void updateNight(){
        int time = getTime();
        //checks time of day.
        if(time <=6 || time >= 21){
            isNight = true;
        }
        else{
            isNight = false;
        }
    }

    /**
     * Sets a random weather situation.
     * Either sunny, rainy or foggy.
     */
    private void updateWeather(){
        int randomNumber = randomGenerator.nextInt(3);
        currentWeather = weathers.get(randomNumber);
    }

    /**
     * Return night.
     */
    private boolean getIsNight(){
        return isNight;
    }

    /**
     * Increments the timer variable by one and then uses the % operator to-
     * -determine the hour within a 24 hour period. 
     */
    private void updateTime(){
        timer++;                //increment time.
        timer = timer % 24;
    }

    /**
     * Returns the time at the given moment.
     */
    private int getTime(){
        return timer; 
    }

    /**
     * return timeString.
     */
    private String getTimeString(){
        //int time = getTime();
        if(timer<10){
            String timeString = "0" + timer + ":00";
            return timeString;
        }
        else{
            String timeString = timer + ":00";
            return timeString;
        }
    } 

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, getTimeString(), getIsNight(), currentWeather, earthquakeStatus);
    }

    /**
     * Randomly populate the field with lions, zebras, hyenas and hippos.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true , field, location);
                    plants.add(grass);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }

                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(true, field, location);
                    animals.add(hyena);
                }
                else if(rand.nextDouble() <= HIPPO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hippo hippo = new Hippo(true, field, location);
                    animals.add(hippo);
                }
                else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope = new Antelope(true, field, location);
                    animals.add(antelope);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
