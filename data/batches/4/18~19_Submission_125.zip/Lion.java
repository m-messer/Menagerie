import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Lion.
 * Lions age, move, eat Zebras, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Lion extends Animal
{
    // Characteristics shared by all Lions (class variables).

    // The age at which a Lion can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Lion can live.
    private int MAX_AGE = 60;
    // The likelihood of a Lion breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single Zebra. In effect, this is the
    // number of steps a Lion can go before it has to eat again.
    private static final int ZEBRA_FOOD_VALUE = 15;
    // The food value of a single Hippo. In effect, this is the
    // number of steps a Lion can go before it has to eat again.
    private static final int HIPPO_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Lion's age.
    private int age;
    // The Lion's food level, which is increased by eating Zebras or Hippos.
    private int foodLevel;

    /**
     * Create a Lion. A Lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(HIPPO_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = HIPPO_FOOD_VALUE;
        }
        
        //If infected, life expectancy will half
        if (getIsInfected() == true){ 
            MAX_AGE = MAX_AGE / 2;
        }
    }

    /**
     * This is what the Lion does most of the time: it hunts for
     * Lions. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLions A list to return newly born Lions.
     */
    public void act(List<Animal> newLions, boolean isNight, String weather)
    {
        if(isNight == false){
            incrementAge();             //Lion ages.
            incrementHunger();          //Lion gets hungry.
            if(isAlive()) {
                giveBirth(newLions);            
                // Move towards a source of food if found.

                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        } 
        else
        {
              incrementAge();
              //ageing
        }
    }
    
    /**
     * Increase the age. This could result in the Lion's death.
     */
    private void incrementAge()
    {
        age++;      
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Lion more hungry. This could result in the Lion's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Zebras or Hippos adjacent to the current location.
     * Only the first live Zebra or Hippo is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hippo) {       //Lion looks for Hippos
                Hippo hippo = (Hippo) animal;
                if(hippo.isAlive()) { 
                    hippo.setDead();            //Lion eats Hippo
                    foodLevel = HIPPO_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Zebra) {
                Zebra Zebra = (Zebra) animal;
                if(Zebra.isAlive()) {           //Lion looks for zebras
                    Zebra.setDead();            //Lion eats Zebra
                    foodLevel = ZEBRA_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * A Lion will only breed if two Lions of oppostite genders meet.
     * @param newLions A list to return newly born Lions.
     */
    private void giveBirth(List<Animal> newLions)
    {
        // New Lions are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        boolean animalNearby = false;
        for(int i = 0; i < adjacent.size(); i++){
            Location loc = adjacent.get(i);
            if(field.getObjectAt(loc) != null){
                Object animal = field.getObjectAt(loc);
                if(animal instanceof Lion){     
                    Lion lion = (Lion) animal; 
                    if(lion.getIsMale() != this.getIsMale()){
                        animalNearby = true;
                    }
                   /* //Infection spreads through contact.
                    if((this.getIsInfected() == true) || lion.getIsInfected()) {
                         setInfected();
                         lion.setInfected();
                    } */       
                }
            }
        }
        int births = breed();
        // if another Lion is nearby, give birth.
        if(animalNearby == true){
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Lion young = new Lion(false, field, loc);
                if(getIsInfected() == true) {
                    young.setInfected();
                }
                newLions.add(young);
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Lion can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
