import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Hippo.
 * Hippos age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Hippo extends Animal
{
    // Characteristics shared by all Hippos (class variables).

    // The age at which a Hippo can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Hippo can live.
    private int MAX_AGE = 100;
    // The likelihood of a Hippo breeding.
    private static final double BREEDING_PROBABILITY = 0.14;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The Hippo's food value from grass
    private static final int GRASS_FOOD_VALUE = 50;
    
    // Individual characteristics (instance fields).
    // The Hippo's age.
    private int age;
    //The Hippo's foodLevel
    private int foodLevel;
    //The Hippo's Breeding modifier
    private static double BREEDING_MODIFIER;

    /**
     * Create a new Hippo. A Hippo may be created with age
     * zero (a new born) or with a random age.
     * @param randomAge If true, the Hippo will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hippo(boolean randomAge, Field field, Location location)
    {                 
        super(randomAge, field, location);
        age = 0;
        BREEDING_MODIFIER = 1;          
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }       
        
        //If infected, life expectancy will half.
        if(getIsInfected() == true) {
            MAX_AGE = MAX_AGE/2;
        }
    }

    /**
     * This is what the Hippo does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.   
     * Breeding will change depending on time of day.
     * @param newHippos A list to return newly born Hippos.
     */
    public void act(List<Animal> newHippos, boolean isNight, String weather)
    {
        incrementAge();             //Animal ages             
        if(isNight == false){
            BREEDING_MODIFIER = 1;  
        }
        else{
            BREEDING_MODIFIER = 0.8;        //Hippo breeds less during night.
        }

        if(isAlive())
        {
            giveBirth(newHippos);                        
            Location newLocation = getField().freeAdjacentLocation(getLocation());                    
            if(newLocation != null)
            {
                super.setLocation(newLocation);
            }
            else
            {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age.
     * This could result in the Hippo's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Hippo is to give birth at this step.
     * New births will be made into free adjacent locations.
     * A baby Hippo will only be born if two hippos of opposite gender meet.
     * @param newHippos A list to return newly born Hippos.
     */
    private void giveBirth(List<Animal> newHippos)
    {
        // New Hippos are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        boolean animalNearby = false;
        for(int i = 0; i < adjacent.size(); i++){
            Location loc = adjacent.get(i);
            if(field.getObjectAt(loc) != null){
                Object animal = field.getObjectAt(loc);
                if(animal instanceof Hippo){
                    Hippo Hippo = (Hippo) animal; 
                    if(Hippo.getIsMale() != this.getIsMale()){
                        animalNearby = true;
                    }
                }
            }
        }
        int births = breed();
        // if another Hippo is nearby, give birth.
        if(animalNearby == true){
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Hippo young = new Hippo(false, field, loc);
                if(getIsInfected() == true) {       //If adult is infected,baby will also be.
                    young.setInfected();
                }
                newHippos.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY*BREEDING_MODIFIER) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Hippo can breed if it has reached the breeding age.
     * @return true if the Hippo can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
