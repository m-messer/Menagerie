import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Hyena.
 * Hyenas age, move, eat Zebras, Antelopes, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Hyena extends Animal
{
    // Characteristics shared by all Hyenas (class variables).

    // The age at which a Hyena can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Hyena can live.
    private int MAX_AGE = 56;
    // The likelihood of a Hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.195;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single Zebra. In effect, this is the
    // number of steps a Hyena can go before it has to eat again.
    private static final int ZEBRA_FOOD_VALUE = 13;
    // The food value of a single Zebra. In effect, this is the
    // number of steps a Hyena can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 14;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    // The Hyena's age.
    private int age;
    // The Hyena's food level, which is increased by eating Zebras.
    private int foodLevel;
    /**
     * Create a Hyena. A Hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level. 
     * @param randomAge If true, the Hyena will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ZEBRA_FOOD_VALUE;
        }
           
        //Infected Hyenas will have half of the life expectancy of normal Hyenas.
        if(getIsInfected() == true) {
            MAX_AGE = MAX_AGE/2;
        }
    }

    /**
     * This is what the Hyena does most of the time: it hunts for
     * Zebras and Antelopes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newHyenas A list to return newly born Hyenas.
     */
    public void act(List<Animal> newHyenas, boolean isNight, String weather)
    {
        if (isNight == false){
            incrementAge();
            incrementHunger();
            if(isAlive()) {
                giveBirth(newHyenas);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        else{
            incrementAge();
        }
    }

    /*
     * 
     *
    public void nightAct(List<Animal> newHyenas)
    {
        incrementAge();
    }*/

    /**
     * Increase the age. This could result in the Hyena's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Hyena more hungry. This could result in the Hyena's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Zebras or Antelopes adjacent to the current location.
     * Only the first live Zebra or Antelope is eaten.     
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) {    //look for Antelopes
                Antelope antelope = (Antelope) animal;
                if(antelope.isAlive()) { 
                    antelope.setDead();
                    foodLevel = ANTELOPE_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Zebra) {      //look for Zebras
                Zebra Zebra = (Zebra) animal;
                if(Zebra.isAlive()) { 
                    Zebra.setDead();
                    foodLevel = ZEBRA_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Hyena is to give birth at this step.
     * New births will be made into free adjacent locations.
     * A Hyena will only breed when two Hyenas of opposite genders meet.
     * @param newHyenas A list to return newly born Hyenas.
     */
    private void giveBirth(List<Animal> newHyenas)
    {
        // New Hyenas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        boolean animalNearby = false;
        for(int i = 0; i < adjacent.size(); i++){
            Location loc = adjacent.get(i);
            if(field.getObjectAt(loc) != null){
                Object animal = field.getObjectAt(loc);
                if(animal instanceof Hyena){
                    Hyena hyena = (Hyena) animal; 
                    if(hyena.getIsMale() != this.getIsMale()){
                        animalNearby = true;
                    }
                    /*//Infection spreads through contact.
                    if((this.getIsInfected() == true) || hyena.getIsInfected()) {
                         setInfected();
                         hyena.setInfected();
                    }  */       
                }
            }
        }
        int births = breed();
        // if another Hyena is nearby, give birth.
        if(animalNearby == true){
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Hyena young = new Hyena(false, field, loc);
                if(getIsInfected() == true) { //infected adults will pass on disease to young.
                    young.setInfected();
                }
                newHyenas.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Hyena can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
