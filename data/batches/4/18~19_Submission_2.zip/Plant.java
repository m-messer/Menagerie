import java.util.List;
/**
 * Abstract class Plant - Represents grass and other plants
 * in the simulation. Plants can act, be eaten, and are affected
 * by the time of day and the weather.
 *
 * @version 21.2.18
 */
public abstract class Plant
{
    // Whether the plant is eaten or not.
    private boolean eaten;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // Time in the simulation (day/night).
    private Time time;
    // Weather conditions in the simulation.
    private Weather weather;
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time  Day/night in the simulator.
     * @param weather Weather conditions in the simulator.
     */
    public Plant(Field field, Location location, Time time, Weather weather)
    {
        eaten = false;
        this.field = field;
        setLocation(location);
        this.time = time;
        this.weather = weather;
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plant.
     */
    abstract public void act(List<Plant> newPlants);
    
    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is dead.
     */
    protected boolean isEaten()
    {
        return eaten;
    }
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        eaten = true;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the simulation's time (day/night).
     * @return The simulation's time (day/night).
     */
    protected Time getTime()
    {
        return time;
    }
    
    /**
     * Return the simulation's weather.
     * @return The simulation's weather.
     */
    protected Weather getWeather()
    {
        return weather;
    }
    
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * @return A random boolean value.
     */
    private boolean randomBoolean() {
        return Math.random() < 0.5;
    }
    
}
