import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a blue jay.
 * Blue Jay's age, move, breed eat, and die.
 *
 * @version 2016.02.29 (2)
 */
public class BlueJay extends Animal
{
    // Characteristics shared by all blue jays (class variables).

    // The age at which a blue jay can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a blue jay can live.
    private static final int MAX_AGE = 30;
    // The age to which a blue jay can live when sick
    private static final int MAX_SICK_AGE = 10;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The likelihood of a blue jay breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The food value of grass. In effect, this is the
    // number of steps a blue jay can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 11;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The blue jay's age.
    private int age;
    // Food level of the blue jay.
    private int foodLevel;
    
    /**
     * Create a new blue jay. A blue jay may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the blue jay will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time  Day/night in the simulator.
     * @param weather Weather conditions in the simulator.
     * @param isSick true If the animal is infected with a disease.
     */
    public BlueJay(boolean randomAge, Field field, Location location, Time time, Weather weather, boolean isSick)
    {
        super(field, location, time, weather, isSick);
        age = 0;
        foodLevel = 11;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the blue jay does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newBlueJays A list to return newly born blue jays.
     */
    public void act(List<Animal> newBlueJays)
    {
        incrementAge();
        incrementHunger();
        Time time = getTime();
        if(isAlive()) {
            giveBirth(newBlueJays);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        } 
    }
   
    /**
     * Increase the age.
     * This could result in the blue jay's death.
     * Depends on the health of the blue jay.
     */
    private void incrementAge()
    {
        age++;
        if(!getSick() && age > MAX_AGE) {
            setDead();
        }
        else if(getSick() && age > MAX_SICK_AGE) {
            setDead();
        }
    }
    
    /**
     * Make the blue jay more hungry.
     * This could make the blue jay die.
     */
    private void incrementHunger()
    {
        foodLevel --;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        Time time = getTime();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass && time.getDay()) {
                Grass grass = (Grass) plant;
                if(! grass.isEaten()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this blue jay is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBlueJays A list to return newly born blue jays.
     */
    private void giveBirth(List<Animal> newBlueJays)
    {
        // New blue jays are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        Time time = getTime();
        boolean sick = getSick();
        Weather weather = getWeather();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            BlueJay young = new BlueJay(false, field, loc, time, weather, sick);
            newBlueJays.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && findPartner() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A blue jay can breed if it has reached the breeding age.
     * @return true if the blue jay can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
