import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * Weather describes the current weather conditions 
 * in the simulator.
 *
 * @version 22.2.19
 */
public class Weather
{
    // instance variables
    List<String> weathers; //available weathers
    String currentWeather;
    int step; //current step of the simulator
    Random rand;
    
    /**
     * Constructor of Weather. Add potential weathers.
     */
    public Weather()
    {
        weathers = new ArrayList<String>();
        rand = new Random();
        weathers.add("foggy");
        weathers.add("clear");
        weathers.add("rainy");
        currentWeather = weathers.get(rand.nextInt(weathers.size()));
    }
    
    /**
     * Return a random value for the weather to be used
     * in the simulator.
     * @param step Current step of the simulator.
     * @return The new value for the simulator's weather.
     */
    public String getRandomWeather(int step){
        this.step = step;
        if (step % 5 == 0){
            currentWeather = weathers.get(rand.nextInt(weathers.size()));
            return currentWeather;
        }
        else{
            return currentWeather;
        }
    }
    
    /**
     * @return The current value for the simulator's weather.
     */
    public String getCurrentWeather(){
        return currentWeather;
    }
}
