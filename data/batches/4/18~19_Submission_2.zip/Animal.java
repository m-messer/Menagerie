import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // Whether the animal is male or female.
    private boolean isMale, isSick;
    // Day/night in the simulator.
    private Time time;
    // Weather conditions in the simulator.
    private Weather weather;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time  Day/night in the simulator.
     * @param weather Weather conditions in the simulator.
     * @param isSick true If the animal is infected with a disease.
     */
    public Animal(Field field, Location location, Time time, Weather weather, boolean isSick)
    {
        alive = true;
        this.isSick = isSick;
        this.field = field;
        this.weather = weather;
        setLocation(location);
        isMale = randomBoolean();
        this.time = time;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
    * Indicate that the animal is no longer alive.
    * It is removed from the field.
    */
    protected void setSick()
    {
        isSick = true;
    }
    
    /**
    * Indicate that the animal is no longer alive.
    * It is removed from the field.
    * @param sick The value to set "isSick" to.
    */
    protected void setSick(boolean sick)
    {
        isSick = sick;
    }
    
    /**
    * Indicate that the animal is no longer alive.
    * It is removed from the field.
    */
    protected boolean getSick()
    {
        return isSick;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            //remove the mark from the simulation
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the simulation's time (day/night).
     * @return The simulation's time (day/night).
     */
    protected Time getTime()
    {
        return time;
    }
    
    /**
     * Return the simulation's weather.
     * @return The simulation's weather.
     */
    protected Weather getWeather()
    {
        return weather;
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Allow animals to find partners of the opposite
     * sex to breed with and also pass on the disease
     * if either animal has the disease.
     * @return true If the animal found a valid partner.
     */
    protected boolean findPartner()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal == null) {
                continue;
            } else {
                if (animal.getClass() == this.getClass()) {
                    Animal partner = (Animal) animal;
                    if(partner.getIsMale() != this.getIsMale()) {
                        if(partner.getSick()){
                            this.setSick();
                        }else if(this.getSick()){
                            partner.setSick();
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the animal's gender.
     * @return true The animal is male.
     */
    protected boolean getIsMale() {
        return isMale;
    }
    
    /**
     * @return A random boolean value.
     */
    private boolean randomBoolean() {
        return Math.random() < 0.5;
    }
}
