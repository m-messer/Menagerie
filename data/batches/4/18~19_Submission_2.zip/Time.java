
/**
 * Time represents whether it is day or night
 * currently in the simulator.
 *
 * @version 22.2.19
 */
public class Time
{
    // instance variables
    boolean day;
    int step; //step in the simulation
    /**
     * Constructor for Time.
     */
    public Time()
    {
        day = true;
    }
    
    /**
     * Return a value for whether it is day or not.
     * The value changes every 5 steps.
     * @return true If it is daytime.
     */
    public boolean isDay(int step){
        this.step = step;
        if (step%10 < 5){
            day = true;
            return true;
        }
        else {
            day = false;
            return false;
        }
    }
    
    /**
     * @return The value for day or night.
     */
    public boolean getDay(){
        return day;
    }
}
