import java.util.Random;
import java.util.List;
/**
 * A model of a patch of grass.
 * The grass can grow and spread, as well as be eaten
 * by different animals.
 * Animals can stand on top of grass.
 *
 * @version 21.2.18
 */
public class Grass extends Plant
{
    // Characteristics of grass (class variables).
    
    //Max age of one patch of grass
    private static final int MAX_AGE = 25;
    // The likelihood of a grass growing.
    private static final double GROWING_PROBABILITY = 0.1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The grass patch's age.
    private int age;
    /**
     * Create some new grass. Grass may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time Time of day, either day or night.
     * @param weather Weather conditions in the simulation.
     */
    public Grass(Field field, Location location, Time time, Weather weather)
    {
        super(field, location, time, weather);
    }
    
    /**
     * Increase the age.
     * This could result in the patch of grass dying.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * This is what the grass does most of the time - if it 
     * hasn't been eaten and it is clear, it can grow.
     * @param newGrass A list to return newly grown grass.
     */
    public void act(List<Plant> newGrass)
    {
        incrementAge();
        Time time = getTime();
        Weather weather = getWeather();
        if(!isEaten() && weather.getCurrentWeather().equals("clear") ) {
            grow(newGrass);
        }
    }
    
    /**
     * Check whether or not this grass is to grow at this step.
     * New grass will be made into free adjacent locations.
     * @param newGrass A list to return newly grown grass.
     */
    private void grow(List<Plant> newGrass)
    {
        // New grass grows into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        Time time = getTime();
        Weather weather = getWeather();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        if (rand.nextDouble() <= GROWING_PROBABILITY) {
            int babyGrasses = 3;
            for(int b = 0; b < babyGrasses && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Grass young = new Grass(field, loc, time, weather);
                newGrass.add(young);
            }
        }
    }
}
