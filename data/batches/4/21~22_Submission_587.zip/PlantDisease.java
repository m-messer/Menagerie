/**
 * A disease that can only be spread between plants
 *
 * @version 2022.03.02
 */
public abstract class PlantDisease extends Disease
{
    /**
     * Constructor for objects of class PlantDisease
     */
    public PlantDisease()
    {
        //
    }
}
