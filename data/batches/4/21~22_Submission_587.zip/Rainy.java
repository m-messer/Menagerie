
/**
 * Weather of type sunny, A plant thrives in this weather type.
 *
 * @version 2022.03.02
 */
public class Rainy extends Weather
{
    /**
     * Constructor for objects of class Rainy
     */
    public Rainy()
    {
        breedingMultiplier = 1.25f;
    }
}
