
/**
 * A disease that only be spread between animals
 *
 * @version 2022.03.02
 */
public abstract class AnimalDisease extends Disease
{
    /**
     * Constructor for objects of class AnimalDisease
     */
    public AnimalDisease()
    {
        //
    }
}
