import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A kind of predators called vultures, 
 * which eats foxes as foods.
 * Vultures age, move, eat foxes, and die.
 *
 * @version 2021.02.27
 */
public class Vulture extends Animal
{
    // Characteristics shared by all vultures (class variables).
    
    // The age at which vultures can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which vultures can live.
    private static final int MAX_AGE = 20;
    // The likelihood of vultures breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single vulture. In effect, this is the
    // number of steps vultures can go before it has to eat again.
    private static final int FOX_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The vultures' age.
    private int age;
    // The vultures' food level, which is increased by eating foxes.
    private int foodLevel;

    /**
     * Creating vultures as a predators of foxes.
     * Vultures can be created as a new born (age zero and not hungry) 
     * or with a random age and food level.
     * 
     * @param randomAge If true, the vultures will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Vulture(boolean randomAge, Field field, Location location)
    {
        super(field, location); //Age zero or random age decided.
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOX_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOX_FOOD_VALUE;
        }
    }
    
    /**
     * Vultures may move to new locations, grow ages to death,looking for foods
     * or breeding new births.
     * @param field The field currently occupied.
     * @param newVultures A list to return newly born vultures.
     */
    public void act(List<Animal> newVultures)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newVultures);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            
        }
    }

    /**
     * Increase the age. This could result in the vultures' death.
     */
    private void incrementAge()
    {
        age++; //Age limitation.
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this vulture more hungry. 
     * This could result in the vulture's death.
     */
    private void incrementHunger()
    {
        foodLevel--; //Eating foods could increase levels.
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for foxes adjacent to the current location.
     * Only the first live foxes is eaten.
     * Eating foxes will decrease hungry.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fox) { //Look for foxes.
                Fox fox = (Fox) animal;
                if(fox.isAlive()) {  //Find foxes and make fox death to be eaten if foxes are alive.
                    fox.setDead();
                    foodLevel = FOX_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
        
    }
    
    /**
     * Decide whether vulture will give birth to new vultures.
     * New births will be located into diffent adjacent locations.
     * @param newVultures A list to return newly born vultures.
     */
    private void giveBirth(List<Animal> newVultures)
    {
        // New vultures are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Vulture young = new Vulture(false, field, loc);
            newVultures.add(young);
        }
    }
        
    /**
     * If breeds, decided the number of new births.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * check whether animals can propagate
     * @return true if can
     */
    private boolean propagate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Vulture) {
                Vulture vulture = (Vulture) animal;
                if(sex!=vulture.sex){
                return true;
            }
            }
        }
        return false;
        
    }
}