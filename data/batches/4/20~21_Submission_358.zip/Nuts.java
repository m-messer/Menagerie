import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A new kind of plants which is nuts.
 * Nuts are foods for squirrels.
 * Nuts age, move, breed, and die.
 *
 * @version 2221.02.27
 */
public class Nuts extends Animal
{
    // Characteristics shared by all nuts (class variables).

    // The age at which nuts can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which nuts can live.
    private static final int MAX_AGE = 17;
    // The likelihood of nuts breeding.
    private static final double BREEDING_PROBABILITY = 0.14;
    // The maximum number of nuts.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The nuts' age.
    private int age;

    /**
     * Creatig a nut class as food for squirrels.
     * Nuts may be created with age zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the nuts will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Nuts(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0; //Check age zero or random ages.
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * The nuts running activities and movenment.
     * Sometimes it will breed or die of old age.
     * @param newNuts A list to return newly growth of nuts.
     */
    public void act(List<Animal> newNuts)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newNuts);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            
        }
    }

    /**
     * Increase the age.
     * This could result in the nuts' death.
     */
    private void incrementAge()
    {
        age++; //Age limitaion.
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Deciding whether the nuts could grow new nuts.
     * New nuts will be moved to adjacent locations.
     * @param newNuts A list to return newly growth of nuts.
     */
    private void giveBirth(List<Animal> newNuts)
    {
        // New nuts are grown into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Nuts young = new Nuts(false, field, loc);
            newNuts.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of new growth,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0; //Following the breeding probability.
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A nut can breed if it has reached the breeding age.
     * @return true if the nuts can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;//Limitaion breeding age.
    }
}