/**
 * track of time.
 *
 * @1.0
 */
public class Time
{
    private int hours;
    private int minutes;
    private int seconds;
    public int day;
    public boolean night=false;
    /**
     * Constructor for objects of class Time
     */
    public Time(int newhours, int newmin,int newsec)
    {
        // initialise instance variables
        hours=newhours;
        minutes=newmin;
        seconds=newsec;
        day=0;
    }
    
    
    /**
     * increment a unit of time
     */
    public void incrementTime()
    {
        minutes=minutes+60;
        if (minutes==60){
            hours++;
            minutes=0;
        }
        
        if(hours==24){
            day++;
            hours=0;
        }
        
    }
    
    /**
     * @return current hour
     */
    public int getHours()
    {
        return hours;
    }
    
    /**
     * @return current minutes
     */
    public int getMinutes()
    {
     return minutes;   
    }
    
    /**
     * @return current second
     */
    public int getSeconds()
    {
     return seconds;   
    }
    
    /**
     * @return current day
     */
    public int getDay()
    {
        return day;
    }
    
    /**
     * determine whether it is night
     * @return true if it is at night
     */
    public boolean getNight()
    {
     return hours>=19&&hours<=7;   
    }
}
    

