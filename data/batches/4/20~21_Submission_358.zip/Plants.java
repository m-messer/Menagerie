import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of plants. 
 * Plants age, move, breed, and die.
 * Plants can be eaten by rabbits.
 *
 * @version 2021.02.26
 */
public class Plants extends Animal
{
    // Characteristics shared by all plants (class variables).

    // The age at which plants can start to breed.
    private static final int BREEDING_AGE = 2;
    // The maxmimum age for plants to live.
    private static final int MAX_AGE = 10;
    // The probability of plants breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of plants.
    private static final int MAX_LITTER_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The plants' age.
    private int age;

    /**
     * Create a kind of food for rabbits, which is plants class. 
     * Plants may be created with age zero (a new born) or with a random age. 
     * 
     * @param randomAge If true, the plants will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;// Starting with zero age or random.
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is plants acting process.
     * Sometimes it will breed or die of old age.
     * @param newPlants A list to return newly growth of plants.
     */
    public void act(List<Animal> newPlants)
    {
        incrementAge();  //Age increasing until death.
        if(isAlive()) {
            giveBirth(newPlants);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            
        }
    }

    /**
     * Increase the age until death.
     * This could result in the plants's death.
     */
    private void incrementAge()
    {
        age++; //Once reaching the maxmium age plants could death.
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Checking plants whether grow to new plants.
     * If there are new plants, they would be located to different locations.
     * @param newPlants A list to return newly born plants.
     */
    private void giveBirth(List<Animal> newPlants)
    {
        // New plants are grew into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plants young = new Plants(false, field, loc);
            newPlants.add(young);
        }
    }
        
    /**
     * If a plant could breed, it could give new birth to next plant.
     * @return The number of plants (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }    // Followed the breeding probability in Field class.
        return births;
    }

    /**
     * A plant can breed if it has reached the breeding age.
     * @return true if the plant can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;//A limitation for breeding.
    }
}