
/**
 * Time class count each hour
 * Return the hour, increment the hour
 * 
 * 
 */
public class Time
{
    private int hour;

    /**
     * Constructor for objects of class Time
     */
    public Time(int hour)
    {
        this.hour = hour;
    }
    
    /**
     * Setter for hour
     */
    public void setHour(int hour)
    {
        this.hour = hour;
    }

    /**
     * Getter for hour
     * Return hour
     */
    public int getHour()
    {
        // put your code here
        return hour;
    }
    
    /**
     * increment the value of hour
     * if it = 24, sets it to 0
     */
    public void incrementTime()
    {
        hour++;
        if (hour == 24){
            hour = 0;
        }
    }


}
