import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * Wolves age, move, breed, eat rabbits, cows, deers and die.
 *
 * @version 2021.03.03
 */
public class Wolf extends Animal
{
    private static final int BREEDING_AGE = 9;

    private static final int MAX_AGE = 70;

    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;

    private static final int RABBIT_FOOD_VALUE = 6;
    private static final int COW_FOOD_VALUE = 15;
    private static final int DEER_FOOD_VALUE = 18;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private int age;
    // The wolf's food level, which is increased by eating rabbits, cows and deers.
    private int foodLevel;
    
    private Sex sex;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * A wolf may be male or female.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        this.sex = rand.nextBoolean() ? Sex.Male : Sex.Female;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }

    /**
     * This is what the wolf does most of the time: it hunts for
     * rabbits, cows and deers. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param //field The field currently occupied.
     * @param newWolves A list to return newly born wolves.
     */
    public void act(List<Animal> newWolves)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWolves);

            Location newLocation = findFood();
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the wolf's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this wolf more hungry. This could result in the wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for rabbits, cows and deers adjacent to the current location.
     * Only the first live rabbit, cow or deer is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hare) {
                Hare hare = (Hare) animal;
                if(hare.isAlive()) {
                    hare.setDead();
                    foodLevel = foodLevel + RABBIT_FOOD_VALUE;
                    return where;
                }
            }   else if(animal instanceof Cow) {
                Cow cow = (Cow) animal;
                if(cow.isAlive()) {
                    cow.setDead();
                    foodLevel = foodLevel + COW_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) {
                    deer.setDead();
                    foodLevel = foodLevel + DEER_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolves.
     */
    private void giveBirth(List<Animal> newWolves)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, field, loc);
            newWolves.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A wolf can breed if it has reached the breeding age
     * and is a female.
     * @return true if the hare can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE) && (this.sex == Sex.Female);
    }
}
