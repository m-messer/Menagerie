/**
 * Specifies all the valid genders.
 *
 * @version 2021.03.03
 */
public enum Sex {
    Male, 
    Female;
}
