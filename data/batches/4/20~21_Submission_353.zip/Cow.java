import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a cow.
 * Cows age, move, breed, eat grass and die.
 *
 * @version 2021.03.03
 */
public class Cow extends Animal
{
    private static final int BREEDING_AGE = 10;

    private static final int MAX_AGE = 100;

    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    private int age;

    private Sex sex;
    
    // The cow's food level, which is increased by eating grass.
    private int foodLevel = 2;

    /**
     * Create a new cow. A cow may be created with age
     * zero (a new born) or with a random age.
     * A cow may be male or female.
     * 
     * @param randomAge If true, the cow will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cow(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        this.sex = rand.nextBoolean() ? Sex.Male : Sex.Female;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * This is what the cow does most of the time - it walks 
     * around. Sometimes it will breed, eat or die of old age.
     * @param newCows A list to return newly born cows.
     */
    public void act(List<Animal> newCows)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            boolean isDay = getField().step() % 2 != 0 ? true : false;
            if(isDay) feed();
            if(!isDay) giveBirth(newCows);
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * The cow eats grass.
     */
    private void feed()
    {
        int[][] grass = getField().grass();
    
        int grassLevel = grass[getLocation().getRow()][getLocation().getCol()];
    
        this.foodLevel += grassLevel;
        grass[getLocation().getRow()][getLocation().getCol()] = 0;
    }
    
    /**
     * Make this cow more hungry. This could result in the cow's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increase the age.
     * This could result in the cow's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Get cow's gender.
     * @return Gender (may be Male or Female).
     */
    public Sex getSex() {
        return this.sex;
    }
    
    /**
     * Check whether or not this cow is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCows A list to return newly born cows.
     */
    private void giveBirth(List<Animal> newCows)
    {
        Field field = getField();
        boolean isNeighborMale = false;
        for (Location l : field.getFilledAdjacentLocations(getLocation())) {
            Object object = field.getObjectAt(l);
            if(object instanceof Cow) {
                if (((Cow)object).getSex() == Sex.Male) {
                    isNeighborMale = true;
                    break;
                }

            }
        }
        
        if(isNeighborMale) {
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Cow young = new Cow(false, field, loc);
                newCows.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A cow can breed if it has reached the breeding age
     * and is a female.
     * @return true if the cow can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE) && (this.sex == Sex.Female);
    }
}
