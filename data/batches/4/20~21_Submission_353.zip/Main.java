/**
 * The Main class of a predator-prey simulator.
 *
 * @version 2021.03.03
 */
public class Main {
    /**
     * Runs the long simulation.
     */
    public static void main(String[] args) {
        Simulator simulator = new Simulator();
        simulator.runLongSimulation();

    }
}
