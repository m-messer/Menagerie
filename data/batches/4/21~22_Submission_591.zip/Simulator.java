import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.lang.Math ; 

/**
 * A simple predator-prey simulator, based on a rectangular field
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.03;
    // The probability that a rabbit will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.08;    
    // The probability that a hawk will be created in any given grid position
    private static final double HAWK_CREATION_PROBABILITY = 0.03;
    //The probability that a chicken will be created in any given grid position
    private static final double CHICKEN_CREATION_PROBABILITY = 0.08;
    //The probability that a frog will be created in any given grid position
    private static final double FROG_CREATION_PROBABILITY = 0.08;
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current time of the simulation.
    public int hours;
    // The arraylist of all the seasons.
    private ArrayList<String> seasons;
    // The current season.
    private String season;
    // The index of the first season.
    private int firstSeason;
    // Random.
    private Random random;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        seasons = new ArrayList<>();
        createSeasons();
        random = new Random();
        season = getSeason(random.nextInt(4));
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        seasons = new ArrayList<>();
        createSeasons();
        random = new Random();
        firstSeason = random.nextInt(4);
        season = getSeason(firstSeason);
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Squirrel.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Hawk.class, Color.BLACK);
        view.setColor(Chicken.class, Color.PINK);
        view.setColor(Frog.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        hours = (hours+1) % 24;
        step++;

        season = getSeason();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if((animal.getCond1() <= hours) && (hours <= animal.getCond2())) {
                animal.act(newAnimals);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
        }

        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field, hours, season);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        hours = 0;
        season = getSeason(random.nextInt(4));
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, hours, season);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    animals.add(squirrel);
                }
                else if (rand.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(true, field, location);
                    animals.add(hawk);
                }
                else if (rand.nextDouble() <= CHICKEN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Chicken chicken = new Chicken(true, field, location);
                    animals.add(chicken);
                }
                else if (rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    animals.add(frog);
                }
                // else leave the location empty
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * @return the time.
     */
    public int getTime() {
        return hours;
    }
    
    /**
     * Adds all the seasons, avoids code duplication.
     */
    public void createSeasons() {
        seasons.add("Spring");
        seasons.add("Summer");
        seasons.add("Autumn");
        seasons.add("Winter");
    }
    
    /**
     * Generates the index number to access the correct season from the
     * Seasons ArrayList.
     * @return The index number.
     */
    public int getCurrentSeasonNum(){
        double temp = ((step % 400)/100) ;
        int num = (int) Math.round(temp);
        int countSeason = (firstSeason + num) % 4 ;
        return countSeason;

    }
    
    /**
     * Gets the season from the Seasons ArrayList.
     * @param i The index.
     * @return The season.
     */
    public String getSeason(int i) {
        return seasons.get(i);

    }
    
    /**
     * Calculates the current index and retrieves a season from the Season
     * ArrayList.
     * @return The season.
     */
    public String getSeason(){
        return getSeason(getCurrentSeasonNum());

    }
}
