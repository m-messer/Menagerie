import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's sex
    private boolean IsMale;
    //A random to assign a random gender
    private Random random;
    // The conditions for the animals to act
    private int cond1;
    private int cond2;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, int condition1, int condition2)
    {
        alive = true;
        this.cond1 = condition1;
        this.cond2 = condition2;
        this.field = field;
        setLocation(location);
        this.random = new Random();
        this.IsMale = this.random.nextBoolean();
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the animal's sex
     * @return is the animal a male
     */
    public boolean getMale()
    {
        return IsMale;
    }
    
    protected int getCond1() {
        return cond1;
    }
    
    protected int getCond2() {
        return cond2;
    }
    
    /**
     * Animals can meet  if another animal of the same type is adjacent and they are opposite sexes
     * @return true if the animals can meet, false otherwise.
     */
    public boolean canMeet()
    {
        boolean meet = false;
        List<Location> adjLocations = field.adjacentLocations(location);
        for (Location loc : adjLocations){
            try{
            if(field.getObjectAt(loc).getClass().equals(field.getObjectAt(location).getClass())){
                Animal animal = (Animal) field.getObjectAt(loc);
                Animal animal1 = (Animal) field.getObjectAt(location);
                if(animal.getMale() != animal1.getMale())
                {
                    meet = true;
                }
                else{
                    meet = false;
                }
            }
            else{
                meet = false;
            }
        }
        catch(Exception e){}
            
        }
        return meet;
    }
    
    
}
