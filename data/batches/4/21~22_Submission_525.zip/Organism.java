import java.util.*;

/**
 * A class representing shared characteristics of organisms.
 *
 * @version 01/03/2022
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // The organism's cause of death
    private String deathCause;
    // A shared random number generator for calculating probability of getting Chlamajadia
    protected Random rand = Randomizer.getRandom();
    // The current climate (in 0.1C)
    static protected double climate;
    // The current organism population
    protected int currentPopulation;
    // The current Chlamajadia infections
    private static int chlamajadiaCases;
    // The organism's health status, which is either negative (false) or positive (true)
    // for the disease chlamajadia
    private boolean hasChlamajadia;

    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        deathCause = "";
    }
    
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born organisms.
     */
    public abstract void act(List<Organism> newOrganisms, int step);

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(hasChlamajadia) {
            chlamajadiaCases--;
        }
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Returns a truth value for if the organism has chlamajadia
     * @return true if the organism has chlamajadia
     */
    protected boolean hasChlamajadia() {
        return hasChlamajadia;
    }

    /**
     * @param hasChlamajadia Whether the organism should have the disease
     */
     protected void setChlamajadia(boolean hasChlamajadia) {
         if(!this.hasChlamajadia && hasChlamajadia) {
             chlamajadiaCases++;
         } else if (this.hasChlamajadia && !hasChlamajadia) {
             chlamajadiaCases--;
         }
         this.hasChlamajadia = hasChlamajadia;

     }

    /**
     * When an organism makes contact with another organism with chlamajadia, they can
     * possibly catch chlamajadia based on their resistance to the disease
     * @param chlamajadiaProbability
     */
    protected void hasContactWithChlamajadia(double chlamajadiaProbability) {
         double randNum = rand.nextDouble();
         if(randNum < chlamajadiaProbability) {
             setChlamajadia(true);
         }
     }

    /**
     * Returns the organism's death cause.
     * @return the organism's death cause.
     */
    protected String getDeathCause() {
        return deathCause;
    }

    /**
     * Sets deathCause to the input
     * @param deathBy The reason for the organism's death
     */
    protected void setDeathCause(String deathBy) {
        deathCause = deathBy;
    }

    /**
     * Sets climate change equal to newClimate
     * @param newClimate The current climate change
     */
    protected void setClimate(double newClimate) {
        climate = newClimate;
    }

    /**
     * Calculates the birth rate of the organism, which depends on its current population
     * @param cPopulation The current population of the organism
     */
    public void updatePopulation(int cPopulation) {
        currentPopulation = cPopulation;
    }

    /**
     * @return How many organisms currently have Chlamajadia
     */
    static public int ChlamajadiaCases() {
        return chlamajadiaCases;
    }
}
