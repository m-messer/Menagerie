import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Shivamfish age, move, eat, breed, and die.
 *
 * @version 01/03/2022
 */
public class Shivamfish extends Fish
{
    /**
     * Create a shivamfish. A shivamfish can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the shivamfish will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shivamfish(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        breedingAge = 28;
        breedingProbability = 0.009;
        maxLitterSize = 2;
        foodValue = 2900;
        maxAge = 4000;
        chlamajadiaProbability = 0.1;
        preyList = new ArrayList<>(Arrays.asList(Shark.class, Piranha.class));
        likelihoodOfMoving = new ArrayList<>(List.of(0.0, 0.15, 0.6, 0.8));
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(maxAge);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }

    /**
     * This is what the shivamfish does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age. It can also catch chlamajadia.
     * @param newShivamfish A list to return newly born shivamfish.
     */
    public void act(List<Organism> newShivamfish, int step)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newShivamfish);
            // Move towards a source of food if found.
            // Move towards a source of food if allowed to move and food found.
            int indexToGet = step % 4;
            double movementProbability = likelihoodOfMoving.get(indexToGet);
            double actualMovementProbability = rand.nextDouble();
            if(actualMovementProbability <= movementProbability){
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDeathCause("overcrowding");
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether this shivamfish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newShivamfish A list to return newly born sharks.
     */
    private void giveBirth(List<Organism> newShivamfish)
    {
        Field field = getField();

        // New shivamfish are born into adjacent locations if breeding conditions fulfilled
        if(breedingConditionsFulfilled(field)){
            List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && freeAdjacentLocations.size() > 0; b++) {
                Location loc = freeAdjacentLocations.remove(0);
                Shivamfish young = new Shivamfish(false, field, loc);
                newShivamfish.add(young);
            }
        }
    }


    /**
     * A method checking whether the shivamfish's breeding conditions are fulfilled, like whether it's
     * next to a mate of the opposing sex.
     * @param field The shivamfish's field.
     * @return Whether the breeding conditions are fulfilled.
     */
    private boolean breedingConditionsFulfilled(Field field) {
        // Get a list of adjacent locations.
        // check for males of the same species in adjacent locations
        boolean breedingConditionsFulfilled = false;

        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int adjacentLocationsSize = adjacentLocations.size();
        for(int l = 0; l < adjacentLocationsSize; l++){
            Location thisLocation = adjacentLocations.get(l);
            if(field.getObjectAt(thisLocation) instanceof Shivamfish &&
                    ((Shivamfish) field.getObjectAt(thisLocation)).getGender() &&
                    ((Shivamfish) field.getObjectAt(thisLocation)).canBreed()) {
                breedingConditionsFulfilled = true;
            }
        }
        return breedingConditionsFulfilled;
    }

}
