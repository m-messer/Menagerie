import javax.swing.*;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing many species of organisms.
 *
 * @version 02/03/2022
 */
public class Simulator
{

    public static void main(String[] args) {
        Simulator sim = new Simulator();
        //sim.simulate(2000);

    }

    //Random
    Random rand;

    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    //The probability that an organism will be created in any given grid position.
    private static final double SEAWEED_CREATION_PROBABILITY = 0.20;
    private static final double SARDINE_CREATION_PROBABILITY = 0.06;
    private static final double SALMON_CREATION_PROBABILITY = 0.025;
    private static final double SHARK_CREATION_PROBABILITY = 0.04;
    private static final double SHIVAMFISH_CREATION_PROBABILITY = 0.02;
    private static final double PIRANHA_CREATION_PROBABILITY = 0.04;

    // List of animals in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The fields statistics.
    private FieldStats stats;

    // Counts the causes of death
    private int overcrowdingDeaths;
    private int starvationDeaths;
    private int ageDeaths;
    private int eatenDeaths;

    // The number of degrees that the temperature has been increased by
    private double currentClimateChange;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        organisms = new ArrayList<>();
        field = new Field(depth, width);
        stats = new FieldStats();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Seaweed.class, new Color(34,139,34));
        view.setColor(Sardine.class, new Color(102, 178, 205));
        view.setColor(Salmon.class, new Color(161, 135, 154));
        view.setColor(Shark.class, new Color(62, 66, 84, 255));
        view.setColor(Shivamfish.class, new Color(116, 6, 6));
        view.setColor(Piranha.class, new Color(255, 99, 52));

        view.setImage(Seaweed.class, new ImageIcon("seaweed.png"));
        view.setImage(Sardine.class, new ImageIcon("sardine.png"));
        view.setImage(Salmon.class, new ImageIcon("salmon.png"));
        view.setImage(Shark.class, new ImageIcon("shark.png"));
        view.setImage(Shivamfish.class, new ImageIcon("shivamfish.png"));
        view.setImage(Piranha.class, new ImageIcon("piranha.png"));

        currentClimateChange = view.getClimateChange();
        
        // Setup a valid starting point.
        reset();

        simulate(2000);
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        /*
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }

         */

        int step = 1;
        while(step < numSteps && view.isViable(field)) {
            if(!view.isPaused()) {
                simulateOneStep();
                delay(view.getDelay());
                step++;
            }
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public void simulateOneStep()
    {
        step++;
        boolean climateChanged = false;
        stats.generateCounts(field);

        //Checks whether climate settings have been changed
        if(currentClimateChange != view.getClimateChange()) {
            currentClimateChange = view.getClimateChange();
            climateChanged = true;
        }
        // Provide space for newborn animals.
        List<Organism> newOrganisms = new ArrayList<>();
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            if(climateChanged) {
                organism.setClimate(currentClimateChange);
            }

            organism.updatePopulation(stats.getPopulationCount(organism));

            organism.act(newOrganisms, step);
            if(! organism.isAlive()) {
                if(organism.getDeathCause().equals("starvation")) {
                    starvationDeaths++;
                } else if (organism.getDeathCause().equals("age")) {
                    ageDeaths++;
                } else if (organism.getDeathCause().equals("overcrowding")) {
                    overcrowdingDeaths++;
                } else if (organism.getDeathCause().equals("eaten")) {
                    eatenDeaths++;
                }
                it.remove();
            }
        }
        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field, overcrowdingDeaths, starvationDeaths, ageDeaths, eatenDeaths);

        createSeaweed();
    }

    /**
     * Creates seaweed ('toddweed') in random empty locations across the field
     */
    public void createSeaweed() {
        for(int x = 0; x < field.getDepth(); x++) {
            for(int y = 0; y < field.getWidth(); y++) {
                if(field.getObjectAt(x, y) == null && rand.nextInt(200) == 0) {
                    field.place(new Seaweed(true, field, new Location(x, y)), x, y);
                    }
                }
            }
        }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        overcrowdingDeaths = 0;
        starvationDeaths = 0;
        ageDeaths = 0;
        organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, overcrowdingDeaths, starvationDeaths, ageDeaths, eatenDeaths);
    }
    
    /**
     * Randomly populate the field with organisms.
     */
    private void populate()
    {
        rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);

                if (rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY) {
                    Seaweed seaweed = new Seaweed(true, field, location);
                    organisms.add(seaweed);
                } else if (rand.nextDouble() <= SARDINE_CREATION_PROBABILITY) {
                    Sardine sardine = new Sardine(true, field, location);
                    organisms.add(sardine);
                } else if (rand.nextDouble() <= SALMON_CREATION_PROBABILITY) {
                    Salmon salmon = new Salmon(true, field, location);
                    organisms.add(salmon);
                } else if (rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Shark shark = new Shark(true, field, location);
                    organisms.add(shark);
                } else if (rand.nextDouble() <= SHIVAMFISH_CREATION_PROBABILITY) {
                    Shivamfish shivamfish = new Shivamfish(true, field, location);
                    organisms.add(shivamfish);
                } else if (rand.nextDouble() <= PIRANHA_CREATION_PROBABILITY) {
                    Piranha piranha = new Piranha(true, field, location);
                    organisms.add(piranha);
                }
            }
                // else leave the location empty.
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
