import java.util.*;

/**
 * A simple model of a sardine.
 * Sardines age, move, breed, eat seaweed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Sardine extends Fish
{
    /**
     * Create a sardine. A sardine can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the sardine will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sardine(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        breedingAge = 20;
        breedingProbability = 0.15;
        maxLitterSize = 3;
        foodValue = 160;
        maxAge = 600;
        chlamajadiaProbability = 0.9;
        preyList = new ArrayList<>(Arrays.asList(Seaweed.class));
        likelihoodOfMoving = new ArrayList<>(List.of(0.9, 0.35, 0.3, 0.7));
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(maxAge);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }

    /**
     * This is what the sardine does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age. It can also catch chlamajadia.
     * @param newSardines A list to return newly born sardines.
     */
    public void act(List<Organism> newSardines, int step)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSardines);

            // Move towards a source of food if allowed to move and food found.
            int indexToGet = step % 4;
            double movementProbability = likelihoodOfMoving.get(indexToGet);
            double actualMovementProbability = rand.nextDouble();
            if(actualMovementProbability <= movementProbability){
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDeathCause("overcrowding");
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether this sardine is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSardines A list to return newly born sardines.
     */
    private void giveBirth(List<Organism> newSardines)
    {


        Field field = getField();

        // New sardines are born into adjacent locations if breeding conditions fulfilled
        if(breedingConditionsFulfilled(field)){
            List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && freeAdjacentLocations.size() > 0; b++) {
                        Location loc = freeAdjacentLocations.remove(0);
                        Sardine young = new Sardine(false, field, loc);
                        newSardines.add(young);
                    }
        }
    }

    /**
     * A method checking whether the sardine's breeding conditions are fulfilled, like whether it's
     * next to a mate of the opposing sex.
     * @param field The sardine's field.
     * @return Whether the breeding conditions are fulfilled.
     */
    private boolean breedingConditionsFulfilled(Field field) {
        // Get a list of adjacent locations.
        // check for males of the same species in adjacent locations
        boolean breedingConditionsFulfilled = false;

        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int adjacentLocationsSize = adjacentLocations.size();
        for(int l = 0; l < adjacentLocationsSize; l++){
            Location thisLocation = adjacentLocations.get(l);
            if(field.getObjectAt(thisLocation) instanceof Sardine &&
                    ((Sardine) field.getObjectAt(thisLocation)).getGender() &&
                    ((Sardine) field.getObjectAt(thisLocation)).canBreed()) {
                breedingConditionsFulfilled = true;
            }
        }
        return breedingConditionsFulfilled;
    }
}


