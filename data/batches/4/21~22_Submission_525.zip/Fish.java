/**
 * @version 1.0
 */
import java.util.*;

/**
 * The superclass of all fish, defining typical fish behaviour.
 * Fish age, move, eat prey, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Fish extends Organism
{
    // Characteristics shared by all fish (class variables).

    // The age at which a fish can start to breed.
    protected int breedingAge;
    // The age to which a fish can live.
    protected int maxAge;
    // The likelihood of a sardine breeding.
    protected double breedingProbability;
    // The maximum number of births.
    protected int maxLitterSize;    

    // The food value of a single prey. In effect, this is the
    // number of steps a fish can go before it has to eat again.
    protected int foodValue;

    // The list of prey for the fish.
    protected ArrayList<Class> preyList;

    // A shared random number generator to control breeding.
    protected Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The fish's age.
    protected int age;

    // The fish's food level, which is increased by eating rabbits.
    protected int foodLevel;

    // The fish's gender, which is either male (true) or female (false)
    protected boolean gender;

    // The fish's likelihood of moving at any given time
    protected ArrayList<Double> likelihoodOfMoving;
    
    // The fish's likelihood of getting the disease chlamajadia
    protected double chlamajadiaProbability;

    /**
     * Create a fish. A fish can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fish(Boolean randomAge, Field field, Location location)
    {
        super(field, location);
        gender = rand.nextBoolean();
    }

    /**
     * Filler class for the act method of fish, which details what
     * they can do each turn.
     * @param newFish A list to return newly born fish.
     */
    public void act(List<Organism> newFish, int step) {}

    /**
     * Increase the age. This could result in the fish's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDeathCause("age");
            setDead();
        }
    }

    /**
     * Make this fish more hungry. This could result in the fish's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDeathCause("starvation");
            setDead();
        }
    }

    /**
     * Calculates the probability that a fish will move based on
     * the time of day and if the fish has chlamajadia.
     * @param step the current step that the simulation is on
     */
    protected double calculateMovementProbability(int step) {
        int indexToGet = step % 4;
        double movementProbability = likelihoodOfMoving.get(indexToGet);
        if(hasChlamajadia()) { // Chlamajadia (the fish disease) halves the likelihood of movement
            movementProbability /= 2;
        }
        movementProbability /= (climate+1);
        return movementProbability;
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first live food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Organism organism = (Organism)field.getObjectAt(where);
            if(organism != null && preyList.contains(organism.getClass())) {
                if(organism.hasChlamajadia()) {
                    hasContactWithChlamajadia(chlamajadiaProbability);
                }
                if(organism instanceof Fish) {
                    organism.setDeathCause("eaten");
                    if(organism.isAlive()) {
                        organism.setDead();
                        foodLevel += foodValue;
                        return where;
                    }
                }
                else if(organism instanceof Seaweed) {
                    Seaweed seaweed = (Seaweed) organism;
                    if (seaweed.isAlive()) {
                        seaweed.setDead();
                        foodLevel += foodValue;
                        return where;
                    }
               }
            }
        }
        return null;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (maybe zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= (100 * breedingProbability) / currentPopulation) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * A fish can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        if(!gender){ // if male, cannot breed
            return false;
        }
        else {
            return age >= breedingAge;
        }
    }

    /**
     * Accesses the gender of a fish
     * @return the gender of a fish
     */
    protected boolean getGender() {
        return gender;
    }


    /**
     * Sets the gender of a fish.
     * @param newGender the new gender of the fish, either male (true) or female (false)
     */
    private void setGender(boolean newGender)
    {
        gender = newGender;
    }

}


