import javax.swing.*;
import java.awt.*;

/**
 * Responsible for controlling and updating the details window.
 * @version 16/02/2022
 */

public class DetailsView extends JFrame {

    private final String POPULATION_PREFIX = "<html>Population: <br><br>";
    private final String POPULATION_SUFFIX = "<br></html>";
    private JLabel populationLabel;

    private final String DEATHS_PREFIX = "<html>Death Reasons: <br><br>";
    private final String DEATHS_SUFFIX = "<br></html>";
    private JLabel deathsLabel;

    private final String CHLAMAJADIA_PREFIX = "<html><br>Current Chlamajadia Infections: ";
    private JLabel chlamajadiaLabel;

    public DetailsView() {
        setTitle("Hungry Details 9.0");

        setLocation(900, 200);

        Container contents = getContentPane();

        JPanel mainPane = new JPanel();
        populationLabel = new JLabel("Run the simulation...");
        deathsLabel = new JLabel("");
        chlamajadiaLabel = new JLabel("");
        mainPane.setLayout(new BorderLayout());
        JPanel dataPane = new JPanel();
        dataPane.setLayout(new BoxLayout(dataPane, BoxLayout.PAGE_AXIS));
        dataPane.add(populationLabel);
        dataPane.add(deathsLabel);
        dataPane.add(chlamajadiaLabel);
        mainPane.add(dataPane, BorderLayout.CENTER);
        contents.add(mainPane);
        setSize(300,450);
        setVisible(true);
    }

    /**
     * Displays current data for the fish population count, deaths, and chlamajadia cases.
     * @param data Population details
     * @param overcrowdingDeaths The deaths resulting from overcrowding
     * @param starvationDeaths The deaths resulting from starvation
     * @param ageDeaths The deaths resulting from old age
     * @param eatenDeaths The deaths resulting from being eaten
     */
    public void updateDetails(String data, int overcrowdingDeaths, int starvationDeaths, int ageDeaths, int eatenDeaths) {
        populationLabel.setText(POPULATION_PREFIX + data + POPULATION_SUFFIX);
        String newDeathsText = DEATHS_PREFIX +
                "Overcrowding Deaths: " + overcrowdingDeaths + "<br>" +
                "Starvation Deaths: " + starvationDeaths + "<br>" +
                "Old Age Deaths: " + ageDeaths + "<br>" +
                "'Turned into Dinner' Deaths: " + eatenDeaths + DEATHS_SUFFIX;
        deathsLabel.setText(newDeathsText);
        chlamajadiaLabel.setText(CHLAMAJADIA_PREFIX + Organism.ChlamajadiaCases());
    }
}
