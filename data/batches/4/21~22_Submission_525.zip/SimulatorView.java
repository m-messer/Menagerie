import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.image.BufferedImage;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 16/02/2022
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String TIME_PREFIX = "Time: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String CLIMATE_CHANGE_PREFIX = "Set Climate Change (ÃÂ°C): ";
    private JLabel stepLabel, populationLabel, infoLabel, timeLabel, climateLabel;
    private FieldView fieldView;
    private JToggleButton pauseBtn, slowBtn, fastBtn, fastestBtn;
    private JButton moreBtn;
    private JSlider climateSlider;
    private DetailsView detailsView;

    //Climate change slider values (in 0.1ÃÂ°C!)
    private final int MIN_CLIMATE_CHANGE = 0;
    private final int MAX_CLIMATE_CHANGE = 30; //3.0ÃÂ°C
    private final int INITIAL_CLIMATE_CHANGE = 0;
    Hashtable<Integer, JLabel> labelTable;



    private boolean paused;
    private double climateChange; //stores the climate change that is being simulated (ÃÂ°C)

    private int delay;
    
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A map for storing icons for participants in the simulation
    private Map<Class, ImageIcon> icons;
    // A statistics object computing and storing simulation information
    private FieldStats stats;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();
        icons = new LinkedHashMap<>();
        climateChange = INITIAL_CLIMATE_CHANGE;

        setTitle("Hungry Fish 9.0");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        timeLabel = new JLabel(TIME_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        populationLabel = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        climateLabel = new JLabel(CLIMATE_CHANGE_PREFIX, JLabel.RIGHT);



        setLocation(100, 50);
        
        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        //Adds a pause button
        pauseBtn = new JToggleButton("||");
        pauseBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!paused) {
                    paused = true;
                    slowBtn.setSelected(false);
                    fastBtn.setSelected(false);
                    fastestBtn.setSelected(false);
                } else {
                    paused = false;
                    slowBtn.doClick();
                }
            }
        });

        //Adds a slow button
        slowBtn = new JToggleButton(">");
        slowBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                delay = 150;
                paused = false;
                pauseBtn.setSelected(false);
                slowBtn.setSelected(true);
                fastBtn.setSelected(false);
                fastestBtn.setSelected(false);
            }
        });

        //Adds a fast button
        fastBtn = new JToggleButton(">>");
        fastBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                delay = 50;
                paused = false;
                pauseBtn.setSelected(false);
                slowBtn.setSelected(false);
                fastBtn.setSelected(true);
                fastestBtn.setSelected(false);
            }
        });

        //Adds a fastest button
        fastestBtn = new JToggleButton(">>>");
        fastestBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                delay = 10;
                paused = false;
                pauseBtn.setSelected(false);
                slowBtn.setSelected(false);
                fastBtn.setSelected(false);
                fastestBtn.setSelected(true);
            }
        });

        //Adds an "INFO" button to open the statistics frame
        moreBtn = new JButton("INFO");
        moreBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                detailsView.setVisible(!detailsView.isVisible());
            }
        });

        //Makes paused the default option when starting the simulation
        pauseBtn.doClick();


        //Sets up the climate change slider
        climateSlider = new JSlider(JSlider.HORIZONTAL, MIN_CLIMATE_CHANGE,
                MAX_CLIMATE_CHANGE, INITIAL_CLIMATE_CHANGE);

        labelTable = new Hashtable<>();
        for(double n = MIN_CLIMATE_CHANGE; n <= MAX_CLIMATE_CHANGE; n += 10) {
            //n is a double because otherwise we'd need to cast it each time anyway
            labelTable.put((int) n, new JLabel(n/10+"ÃÂ°C"));
        }
        climateSlider.setLabelTable(labelTable);
        climateSlider.setMajorTickSpacing(10);
        climateSlider.setMinorTickSpacing(1);
        climateSlider.setPaintTicks(true);
        climateSlider.setPaintLabels(true);
        climateSlider.setSnapToTicks(true);


        

        climateSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSlider source = (JSlider) e.getSource();
                System.out.println(source.getValue());
                climateChange = ((double) source.getValue())/10;
            }
        });

        //Sets the scene
        JPanel mainPane = new JPanel();
        mainPane.setLayout(new BorderLayout(5, 5));
        mainPane.setBorder(BorderFactory.createLineBorder(Color.black));

        JPanel timePane = new JPanel();
        timePane.setLayout(new BoxLayout(timePane, BoxLayout.PAGE_AXIS));
        timePane.add(timeLabel);
        timePane.add(stepLabel);

        JPanel infoPane = new JPanel(new BorderLayout());
        infoPane.add(timePane, BorderLayout.WEST);
        infoPane.add(moreBtn, BorderLayout.EAST);
        infoPane.add(infoLabel, BorderLayout.CENTER); // kept for extendability and maintainability.

        mainPane.add(infoPane, BorderLayout.NORTH);
        mainPane.add(fieldView, BorderLayout.CENTER);
        contents.add(mainPane, BorderLayout.CENTER);

        //Plots speed related buttons
        JPanel speedPane = new JPanel();
        speedPane.setLayout(new BoxLayout(speedPane, BoxLayout.X_AXIS));
        speedPane.add(pauseBtn);
        speedPane.add(slowBtn);
        speedPane.add(fastBtn);
        speedPane.add(fastestBtn);

        JPanel buttonsPane = new JPanel(new BorderLayout());
        buttonsPane.add(speedPane, BorderLayout.WEST);
        buttonsPane.add(climateLabel, BorderLayout.CENTER);
        buttonsPane.add(climateSlider, BorderLayout.EAST);
        contents.add(buttonsPane, BorderLayout.SOUTH);



        pack();
        setVisible(true);


        detailsView = new DetailsView();
    }
    
    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of organism.
     * @param organismClass the given class of organism to be represented by a colour
     */
    private Color getColor(Class organismClass)
    {
        Color col = colors.get(organismClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * @return The icon to be used for a given class of organism.
     * @param organismClass the given class of organism to be represented by an icon
     */
    private ImageIcon getIcon(Class organismClass) {
        ImageIcon icon = icons.get(organismClass);
        if(icon == null) {
            //no icon defined for this class
            return new ImageIcon("unknown.png");
        }
        else {
            return icon;
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field, int overcrowdingDeaths, int starvationDeaths,
                           int ageDeaths, int eatenDeaths)
    {
        if(!isVisible()) {
            setVisible(true);
        }

        if(step % 4 == 0) {
            timeLabel.setText(TIME_PREFIX + "Morning");
        } else if (step % 4 == 1) {
            timeLabel.setText(TIME_PREFIX + "Afternoon");
        } else if (step % 4 == 2) {
            timeLabel.setText(TIME_PREFIX + "Evening");
        } else if (step % 4 == 3) {
            timeLabel.setText(TIME_PREFIX + "Night");
        }
        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();
        
        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    stats.incrementCount(animal.getClass());
                    fieldView.drawImage(col, row, getIcon(animal.getClass()));
                }
                else {
                    fieldView.drawMark(col, row, EMPTY_COLOR); //TODO: add the image
                }
            }
        }
        stats.countFinished();

        detailsView.updateDetails(stats.getPopulationDetails(field, icons), overcrowdingDeaths, starvationDeaths,
                ageDeaths, eatenDeaths);
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.#
     * @param field the grid containing all organisms and activity
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * Determines whether the simulation is currently paused.
     * @return true if the simulation is paused.
     */
    public boolean isPaused() {
        return paused;
    }

    /**
     * Returns the climate change value
     * @return The amount of climate change that has occurred (ÃÂ°C)
     */
    public double getClimateChange() {
        return climateChange;
    }

    /**
     * Returns the current delay
     * @return current delay
     */
    public int getDelay() {
        return delay;
    }

    /**
     * Puts the organism class and organism icon in a Map so that the class is always represented by the same icon
     * @param organismClass
     * @param organismIcon
     */
    public void setImage(Class organismClass, ImageIcon organismIcon) {
        icons.put(organismClass, organismIcon);
    }

    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         * @param height the height of the FieldView
         * @param width the width of the FieldView
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                                 gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = (Graphics) fieldImage.getGraphics();
                //g = fieldImage.getGraphics()


                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         *
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawImage(int x, int y, ImageIcon image)
        {
            //super.paint(g);
            //System.out.println(image.getIconHeight());
            Image image2 = image.getImage();
            Image image3 = image2.getScaledInstance(xScale, yScale, Image.SCALE_FAST);
            Image image4 = image2.getScaledInstance(64, 64, Image.SCALE_FAST);
            BufferedImage resizedImage = new BufferedImage(xScale, yScale, BufferedImage.TYPE_INT_RGB);

            g.drawImage(image2, x * xScale, y * yScale, xScale-1, yScale-1, this);
            //g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
            //g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
