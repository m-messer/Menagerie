import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Piranhas age, move, breed, eat, and die.
 *
 * @version 26/02/2022
 */
public class Piranha extends Fish
{
    /**
     * Create a piranha. A piranha can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the piranha will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Piranha(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        breedingAge = 7;
        breedingProbability = 0.17;
        maxLitterSize = 3;
        foodValue = 2000;
        maxAge = 4500;
        chlamajadiaProbability = 0.9;
        preyList = new ArrayList<>(Arrays.asList(Seaweed.class, Sardine.class));
        likelihoodOfMoving = new ArrayList<>(List.of(0.0, 0.45, 0.6, 0.9));
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(maxAge);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }

    /**
     * This is what the piranha does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newPiranhas A list to return newly born piranhas.
     * @param step The step that the simulator is on when act is called
     */
    public void act(List<Organism> newPiranhas, int step)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPiranhas);
            // Move towards a source of food if allowed to move and food found.
            double movementProbability = calculateMovementProbability(step);
            double actualMovementProbability = rand.nextDouble();
            if(actualMovementProbability <= movementProbability){
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDeathCause("overcrowding");
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether this piranha is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPiranhas A list to return newly born piranhas.
     */
    private void giveBirth(List<Organism> newPiranhas)
    {
        Field field = getField();

        // New piranhas are born into adjacent locations if breeding conditions fulfilled
        if(breedingConditionsFulfilled(field)) {
            List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && freeAdjacentLocations.size() > 0; b++) {
                Location loc = freeAdjacentLocations.remove(0);
                Piranha young = new Piranha(false, field, loc);
                newPiranhas.add(young);
            }
        }
    }

    /**
     * A method checking whether the piranha's breeding conditions are fulfilled, like whether it's
     * next to a mate of the opposing sex.
     * @param field The piranha's field.
     * @return Whether the breeding conditions are fulfilled.
     */
    private boolean breedingConditionsFulfilled(Field field) {
        // Get a list of adjacent locations.
        // check for males of the same species in adjacent locations
        boolean breedingConditionsFulfilled = false;

        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int adjacentLocationsSize = adjacentLocations.size();
        for(int l = 0; l < adjacentLocationsSize; l++){
            Location thisLocation = adjacentLocations.get(l);
            if(field.getObjectAt(thisLocation) instanceof Piranha &&
                    ((Piranha) field.getObjectAt(thisLocation)).getGender() &&
                    ((Piranha) field.getObjectAt(thisLocation)).canBreed()) {
                breedingConditionsFulfilled = true;
            }
        }
        return breedingConditionsFulfilled;
    }
}
