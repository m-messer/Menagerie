import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Salmon eat, sleep, breed, move, catch chlamajadia, and die.
 *
 * @version 07/02/2022
 */
public class Salmon extends Fish
{
    /**
     * Create a salmon. A salmon can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the salmon will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Salmon(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        breedingAge = 13;
        breedingProbability = 0.06;
        maxLitterSize = 8;
        foodValue = 500;
        maxAge = 3000;
        chlamajadiaProbability = 0.5;
        preyList = new ArrayList<>(Arrays.asList(Seaweed.class));
        likelihoodOfMoving = new ArrayList<>(List.of(0.2, 0.2, 0.1, 0.4));
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(maxAge);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }

    /**
     * This is what the salmon does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newSalmon A list to return newly born salmon.
     */
    public void act(List<Organism> newSalmon, int step)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSalmon);
            // Move towards a source of food if found.
            // Move towards a source of food if allowed to move and food found.
            int indexToGet = step % 4;
            double movementProbability = likelihoodOfMoving.get(indexToGet);
            double actualMovementProbability = rand.nextDouble();
            if(actualMovementProbability <= movementProbability){
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDeathCause("overcrowding");
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether this salmon is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSalmon A list to return newly born salmon.
     */
    private void giveBirth(List<Organism> newSalmon)
    {
        Field field = getField();

        // New salmon are born into adjacent locations if breeding conditions fulfilled
        if(breedingConditionsFulfilled(field)){
            List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && freeAdjacentLocations.size() > 0; b++) {
                Location loc = freeAdjacentLocations.remove(0);
                Salmon young = new Salmon(false, field, loc);
                newSalmon.add(young);
            }
        }
    }

    /**
     * A method checking whether the salmon's breeding conditions are fulfilled, like whether it's
     * next to a mate of the opposing sex.
     * @param field The salmon's field.
     * @return Whether the breeding conditions are fulfilled.
     */
    private boolean breedingConditionsFulfilled(Field field) {
        // Get a list of adjacent locations.
        // check for males of the same species in adjacent locations
        boolean breedingConditionsFulfilled = false;

        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int adjacentLocationsSize = adjacentLocations.size();
        for(int l = 0; l < adjacentLocationsSize; l++){
            Location thisLocation = adjacentLocations.get(l);
            if(field.getObjectAt(thisLocation) instanceof Salmon &&
                    ((Salmon) field.getObjectAt(thisLocation)).getGender() &&
                    ((Salmon) field.getObjectAt(thisLocation)).canBreed()) {
                breedingConditionsFulfilled = true;
            }
        }
        return breedingConditionsFulfilled;
    }

}
