package src;
import java.util.Random;

/**
 * Class which allows for control of weather over an area
 * @version (19/02/2020)
 */
public class Weather {

    private String type; //stores the type of weather


    public Weather() {

        //automatically set weather to sunny to begin with
    this.type = "Sunny";

    }

    /**
     * @return the current weather
     */
    public String getWeather() {

        return type;
    }

    /**
     * randomly change the weather to one of 3 states (Sunny, Rain, Fog)
     */
    public void changeWeather() {

        Random rand = new Random();

        //generate random number to randomly determine weather
        int weatherType = rand.nextInt(3);
        
        //randomly choose a weather
        if (weatherType == 0) {
            type = "Sunny";
        } else if (weatherType == 1) {
            type = "Rain";
        } else {
            type = "Fog";
        }


    }


}
