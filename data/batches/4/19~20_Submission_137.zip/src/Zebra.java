package src;

import java.util.List;
import java.util.Random;
/**
 * Class for Animal Zebra (Prey)
 *
 * @version (a version number or a date)
 */
public class Zebra extends Prey
{
    // instance variables - replace the example below with your own
    public static int ZEBRA_ID = 2; //id for all zebras
    private int age;


    /**
     * Constructor for objects of class Zebra
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        breedingAge = 13;
        maxAge = 120;
        this.age = rand.nextInt(maxAge);

    }

    /**
     * gives birth to new animals
     * @param newZebras - list of new zebras
     */
    public void giveBirth(List<Animal> newZebras) {


        //get free adjacent spaces around zebra
        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
        boolean mateNearby = false;

        //checks adjacent squares to see if there is a mate to breed with
        for (Location next: adjacentLocations) {
            if (field.getObjectAt(next) != null) {
                if (canBreed(this, (Animal) field.getObjectAt(next))) {
                    mateNearby = true;
                }
            }
        }

        //give birth to new animals if there is a mate nearby
        if (mateNearby) {
            int births = rand.nextInt(MAX_LITTER_SIZE) + 1;

            //add new animals to lit
            for (int i = 0; i < births && freeAdjacentLocations.size() > 0; i++) {
                Location loc = freeAdjacentLocations.remove(0);
                Zebra young = new Zebra(false, field, loc);
                newZebras.add(young);

            }
        }
    }
    /**
     * @return the ID of the animal
     */
    public int getID() {
        //return ID
        return ZEBRA_ID;
    }

    /**
     * @param a1, a2, two animals to check if they are compatible to breed
     * @return true if two animals are okay to breed
     * conditions for breeding are that both animals are the same species, one is male and the other is female, and the animal is of good age to breed
     */
    public boolean canBreed(Animal a1, Animal a2) {

        boolean comboWorks = false;
        boolean probabilityOK = false;
        boolean ageOK = false;

        //check if the two animals are of the same species
        if (a1.getID() == a2.getID()) {
            //check that one of the animals is male and the other is female
            if ((a1.isMale() && !a2.isMale()) || ((!a1.isMale() && a2.isMale()))) {
                comboWorks = true;
            } else {
                comboWorks = false;
            }
        }

        //check if the probability to breed is successful
        if (comboWorks) {
            if (rand.nextDouble() <= BREEDING_PROBABILITY) {
                probabilityOK = true;
            } else {
                probabilityOK = false;
            }
        }

        //check if the animal is of breeding age
        if (age >= breedingAge ) {
            ageOK = true;
        } else {
            ageOK = false;
        }

        //if all three apply then return true, else return false
        if (comboWorks && probabilityOK && ageOK) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This is what the Zebra does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newZebras A list to return newly born Zebras.
     */
    public void act(List<Animal> newZebras)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newZebras); //give birth to new zebras
            giveDiseaseToOthers(); //give disease to other zebras if applicable
            // Move towards a source of food if found.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

}
