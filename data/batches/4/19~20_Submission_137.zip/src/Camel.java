package src;

import java.util.List;
import java.util.Random;
/**
 * Class for Animal Camel (Prey)
 *
 * @version (19/02/2020)
 */
public class Camel extends Prey
{
    public static final int CAMEL_ID = 3; //id for all camels
    private int age;

    /**
     * Constructor for objects of class Camel
     */
    public Camel(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        breedingAge = 9;
        maxAge = 140;
        this.age = rand.nextInt(maxAge);

    }

    /**
     * @return the ID of the camel
     */
    public int getID() {
        return CAMEL_ID;
    }

    /**
     * gives disease to other animals nearby randomly
     */
    public void giveDiseaseToOthers() {

        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());

        for (Location next : adjacentLocations) {
            if (field.getObjectAt((next)) != null) {
                Animal nearbyAnimal = (Animal) field.getObjectAt(next);
                nearbyAnimal.giveDisease();

            }
        }
    }

    /**
     * gives birth to new animals
     * @param newcCamels - list of new camels
     */
    public void giveBirth(List<Animal> newCamels) {


        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
        boolean mateNearby = false;

        for (Location next: adjacentLocations) {
            if (field.getObjectAt(next) != null) {
                if (canBreed(this, (Animal) field.getObjectAt(next))) {
                    mateNearby = true;
                }
            }
        }

        //give birth to new animals if there is a mate nearby
        if (mateNearby) {
            int births = rand.nextInt(MAX_LITTER_SIZE) + 1;

            for (int i = 0; i < births && freeAdjacentLocations.size() > 0; i++) {
                Location loc = freeAdjacentLocations.remove(0);
                Camel young = new Camel(false, field, loc);
                newCamels.add(young);


            }
        }
    }

    /**
     * @param a1, a2, two animals to check if they are compatible to breed
     * @return boolean if two animals are okay to breed
     * conditions for breeding are that both animals are the same species, one of them is male and the other is female, and the animals are of age to breed
     */
    public boolean canBreed(Animal a1, Animal a2) {

        boolean comboWorks = false;
        boolean probabilityOK = false;
        boolean ageOK = false;

        //check if the two animals are of the same species
        if (a1.getID() == a2.getID()) {
            //check one of the animals is male and the other is female
            if ((a1.isMale() && !a2.isMale()) || ((!a1.isMale() && a2.isMale()))) {
                comboWorks = true;
            } else {
                comboWorks = false;
            }
        }

        //check if the probability to breed is successful
        if (comboWorks) {
            if (rand.nextDouble() <= BREEDING_PROBABILITY) {
                probabilityOK = true;
            } else {
                probabilityOK = false;
            }
        }

        //check if the animal is of breeding age
        if (age >= breedingAge) {
            ageOK = true;
        } else {
            ageOK = false;
        }

        //if all three apply then return true, else return false
        if (comboWorks && probabilityOK && ageOK) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This is what the Camel does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newCamels A list to return newly born Camels.
     */
    public void act(List<Animal> newCamels)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newCamels); //give birth to new camels
            giveDiseaseToOthers(); //spread disease to other camels where applicable
            // Move towards a source of food if found.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
}

