package src;

import java.util.List;
import java.util.Random;
/**
 * Class for Animal Antelope (Prey)
 *
 * @version (19/02/2020)
 */
public class Antelope extends Prey
{
    public static final int ANTELOPE_ID = 1;
    private int age;

    /**
     * Constructor for objects of class Antelope
     */
    public Antelope(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        breedingAge = 20;
        maxAge = 120;

        this.age = rand.nextInt(maxAge);
    }

    /**
     * @return the id of the antelope
     */
    public int getID() {
        return ANTELOPE_ID;
    }

    /**
     * gives birth to new animals
     * @param newAntelopes - list of new antelopes
     */
    public void giveBirth(List<Animal> newAntelopes) {

        //get free locations surrounding the animal
        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
        boolean mateNearby = false;

        //check adjacent locations for another animal to mate with
        for (Location next: adjacentLocations) {
            if (!(field.getObjectAt(next) == (null))) {

                if (canBreed(this, (Animal) field.getObjectAt(next))) {
                    mateNearby = true;

                }
            }
        }

        //if mate nearby then give birth to new animals
        if (mateNearby) {
            int births = rand.nextInt(MAX_LITTER_SIZE) + 1;

            //add new animals to list
            for (int i = 0; i < births && freeAdjacentLocations.size() > 0; i++) {
                Location loc = freeAdjacentLocations.remove(0);
                Antelope young = new Antelope(false, field, loc);
                newAntelopes.add(young);

            }
        }


    }

    /**
     * @param a1, a2, two animals to check if they are compatible to breed
     * @return boolean if two animals are okay to breed
     * conditions for breeding are that both animals are the same species, one of the animals is male and the other is female, and that the animal is of age to breed
     */
    public boolean canBreed(Animal a1, Animal a2) {

        boolean comboWorks = false;
        boolean probabilityOK = false;
        boolean ageOK = false;

        //check if the two animals are of the same species
        if (a1.getID() == a2.getID()) {
            //check one of the animals is male and the other animal is female
            if ((a1.isMale() && !a2.isMale()) || ((!a1.isMale() && a2.isMale()))) {
                comboWorks = true;

            } else {
                comboWorks = false;
            }
        }

        //check if the probability to breed is successful
        if (comboWorks) {
            if (rand.nextDouble() <= BREEDING_PROBABILITY) {
                probabilityOK = true;
            } else {
                probabilityOK = false;
            }
        }

        //check if the animal is of breeding age
        if (age >= breedingAge) {
            ageOK = true;
        } else {
            ageOK = false;
        }

        //if all three apply then return true, else return false
        if (comboWorks && probabilityOK && ageOK) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This is what the Antelope does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newAntelopes A list to return newly born Antelopes.
     */
    public void act(List<Animal> newAntelopes)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newAntelopes); //give birth to new antelopes
            giveDiseaseToOthers(); //spread disease if applicable
            // Move towards a source of food if found.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
}


