package src;

import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Write a description of class Predator here.
 *
 * @version (a version number or a date)
 */
public class Predator extends Animal
{
    // Characteristics shared by all predators (class variables).

    // The age at which a predator can start to breed.
    protected static int breedingAge = 15;;
    // The age to which a predator can live.
    protected static int maxAge = 100;
    // The likelihood of a predator breeding.
    public static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    public static final int MAX_LITTER_SIZE = 3;
    // The food value of a single prey. In effect, this is the
    // number of steps a predator can go before it has to eat again.
    public static final int PREY_FOOD_VALUE = 700;
    // A shared random number generator to control breeding.
    public static Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The predator's age.
    private int age;
    // The predators's food level, which is increased by eating rabbits.
    private int foodLevel;
    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(PREY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PREY_FOOD_VALUE;
        }
    }

    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newPredators A list to return newly born predators.
     */
    public void act(List<Animal> newPredators)
    {

        incrementAge(); //increase age
        incrementHunger(); //increase hunger
        if(isAlive()) {
            giveBirth(newPredators); //give birth to new predators
            // Move towards a source of food if found.
            Location newLocation = findFood(); //search for food
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the predator's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }

    /**
     * Make this predator more hungry. This could result in the predators's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) {
                    prey.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this predator is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPredators A list to return newly born predator.
     */
    private void giveBirth(List<Animal> newPredators)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Predator young = new Predator(false, field, loc);
            newPredators.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A predator can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= breedingAge;
    }

    /**
     * give disease to animals adjacent to animals that already have disease
     */
    public void giveDiseaseToOthers() {

        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());

        //loop through adjacent locations and give disease to animals around
        for (Location next : adjacentLocations) {
            if (field.getObjectAt((next)) != null) {
                Animal nearbyAnimal = (Animal) field.getObjectAt(next);
                nearbyAnimal.giveDisease();

            }
        }
    }

    /**
     *
     * @return age of the animal
     */
    protected int getAge() {
        return age;
    }
}

