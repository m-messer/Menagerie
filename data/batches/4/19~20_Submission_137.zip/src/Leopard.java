package src;

import java.util.List;
import java.util.Random;
/**
 * Class for Animal Leopard (Predator)
 *
 * @version (19/02/2020)
 */
public class Leopard extends Predator {
    public static final int LEOPARD_ID = 4; //id for all leopards
    private int age;

    /**
     * Constructor for objects of class Leopard
     */
    public Leopard(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        breedingAge = 15;
        maxAge = 85;

        this.age = rand.nextInt(maxAge);

    }

    /**
     * @return the ID of the leopard
     */
    public int getID() {
        return LEOPARD_ID;
    }

    /**
     * gives birth to new animals
     * @param newLeopards - list of new leopards
     */
    public void giveBirth(List<Animal> newLeopard) {


        //find locations nearby which are free
        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
        boolean mateNearby = false;


        //get animals nearby that are ready to breed
        for (Location next : adjacentLocations) {
            if (field.getObjectAt(next) != null) {

                if (canBreed(this, (Animal) field.getObjectAt(next))) {
                    mateNearby = true;
                }
            }
        }

        //randomly give birth to offspring
        if (mateNearby) {
            int births = rand.nextInt(MAX_LITTER_SIZE) + 1;

            //add new offspring to new animal list
            for (int i = 0; i < births && freeAdjacentLocations.size() > 0; i++) {
                Location loc = freeAdjacentLocations.remove(0);
                Leopard young = new Leopard(false, field, loc);
                newLeopard.add(young);


            }
        }
    }

    /**
     * @param a1, a2, two animals to check if they are compatible to breed
     * @return boolean if two animals are okay to breed
     * conditions for breeding are that both animals are the same species, one of them is male and the other is female, and they are both of age to breed
     */
    public boolean canBreed(Animal a1, Animal a2) {

        boolean comboWorks = false;
        boolean probabilityOK = false;
        boolean ageOK;
        boolean timeOK = false;

        //check if the two animals are of the same species
        if (a1.getID() == a2.getID()) {
            //check one of the two animals is male and the other is female
            if ((a1.isMale() && !a2.isMale()) || ((!a1.isMale() && a2.isMale()))) {
                comboWorks = true;
            } else {
                comboWorks = false;
            }
        }

        //check if the probability to breed is successful
        if (comboWorks) {
            if (rand.nextDouble() <= BREEDING_PROBABILITY) {
                probabilityOK = true;
            } else {
                probabilityOK = false;
            }
        }

        //check if the animal is of breeding age
        if (age >= breedingAge) {
            ageOK = true;
        } else {
            ageOK = false;
        }

        //only breed between a certain time
        if (!((Simulator.getTime() > 10) && (Simulator.getTime() < 22))) {
            timeOK = true;
        }

        //if all three apply then return true, else return false
        if (comboWorks && probabilityOK && ageOK && timeOK) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This is what the Leopard does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newLeopards A list to return newly born Leopards.
     */
    public void act(List<Animal> newLeopards) {
        incrementAge();
        if (isAlive()) {
            //sleeping during this time - don't do anything
            if ((Simulator.getTime() > 10) && (Simulator.getTime() < 22)) {
                return;
            } else {

                giveBirth(newLeopards); //give birth to new leopards
                giveDiseaseToOthers(); //spread disease to other leopards where applicable
                // Move towards a source of food if found.

                //if weather is not foggy then search for food
                if (!Simulator.weather.getWeather().equals("Fog")) {
                    Location newLocation = findFood();
                    if (newLocation == null) {
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if (newLocation != null) {
                        setLocation(newLocation);
                    } else {
                        // Overcrowding.
                        setDead();
                }

                    //weather is foggy. just move randomly
                } else {
                    Location newLocation = getField().freeAdjacentLocation((getLocation()));
                    // See if it was possible to move.
                    if (newLocation != null) {
                        setLocation(newLocation);
                    } else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }
}





