package src;

import java.util.List;
import java.util.Random;

/**
 * A simple model of a prey.
 * preys age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Prey extends Animal
{
    // Characteristics shared by all preys (class variables).

    // The age at which a prey can start to breed.
    protected static int breedingAge = 3;
    // The age to which a prey can live.
    protected static int maxAge = 670;
    // The likelihood of a prey breeding.
    public static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    public static final int MAX_LITTER_SIZE = 10;
    // A shared random number generator to control breeding.
    public static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The prey's age.
    private int age;

    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(maxAge);
        }
    }

    public void act(List<Animal> newPrey) {

    }

    /**
     * Increase the age.
     * This could result in the prey's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }

    /**
     * gives disease to animals around other animals which already have the disease
     */
    public void giveDiseaseToOthers() {

        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());

        //check each location to see if there is an animal nearby
        //if there is then give it the disease
        for (Location next : adjacentLocations) {
            if (field.getObjectAt((next)) != null) {
                Animal nearbyAnimal = (Animal) field.getObjectAt(next);
                nearbyAnimal.giveDisease();


            }
        }
    }
    /**
     * Check whether or not this prey is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPrey A list to return newly born prey.
     */
    private void giveBirth(List<Animal> newPrey)
    {
        // New preys are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Prey young = new Prey(false, field, loc);
            newPrey.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A prey can breed if it has reached the breeding age.
     * @return true if the prey can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= breedingAge;
    }

    /**
     *
     * @return age of the animal
     */
    protected int getAge() {
        return age;
    }
}
