package src;


import java.util.List;
import java.util.Random;
/**
 * Class for animal Lion (Predator)
 *
 * @version (19/02/2020)
 */
public class Lion extends Predator {
    public static final int LION_ID = 5;
    private int age;

    /**
     * Constructor for objects of class Lion
     */
    public Lion(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        breedingAge = 15;
        maxAge = 85;

        this.age = rand.nextInt(maxAge);
    }

    /**
     * @return the id of the lion
     */
    public int getID() {
        return LION_ID;
    }


    /**
     * gives birth to new animals
     * @param newLion - list of new lions
     */
    public void giveBirth(List<Animal> newLions) {


        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        List<Location> freeAdjacentLocations = field.getFreeAdjacentLocations(getLocation());
        boolean mateNearby = false;

        for (Location next : adjacentLocations) {
            if (field.getObjectAt(next) != null) {
                if (canBreed(this, (Animal) field.getObjectAt(next))) {
                    mateNearby = true;
                }
            }
        }

        //give birth to new animals if there is a mate nearby
        if (mateNearby) {
            int births = rand.nextInt(MAX_LITTER_SIZE) + 1;

            for (int i = 0; i < births && freeAdjacentLocations.size() > 0; i++) {
                Location loc = freeAdjacentLocations.remove(0);
                Lion young = new Lion(false, field, loc);
                newLions.add(young);


            }
        }
    }

    /**
     * @param a1, a2, two animals to check if they are compatible to breed
     * @return boolean if two animals are okay to breed
     * conditions for breeding are that both animals are the same species, one is male and the other is female, and both are of age to breed
     */
    public boolean canBreed(Animal a1, Animal a2) {

        boolean comboWorks = false;
        boolean probabilityOK = false;
        boolean ageOK;
        boolean timeOK = false;

        //check if the two animals are of the same species
        if (a1.getID() == a2.getID()) {
            //check if one animal is male and the other is female
            if ((a1.isMale() && !a2.isMale()) || ((!a1.isMale() && a2.isMale()))) {
                comboWorks = true;
            } else {
                comboWorks = false;
            }
        }

        //check if the probability to breed is successful
        if (comboWorks) {
            if (rand.nextDouble() <= BREEDING_PROBABILITY) {
                probabilityOK = true;
            } else {
                probabilityOK = false;
            }
        }

        //check if the animal is of breeding age
        if (age >= breedingAge) {
            ageOK = true;
        } else {
            ageOK = false;
        }

        //only breed between a certain time
        if (!((Simulator.getTime() > 10) && (Simulator.getTime() < 22))) {
            timeOK = true;
        }

        //if all three apply then return true, else return false
        if (comboWorks && probabilityOK && ageOK && timeOK) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This is what the Lion does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newLions A list to return newly born Lions.
     **/

    public void act(List<Animal> newLions) {
        incrementAge();
        if (isAlive()) {
            //sleeping during this time - don't do anything
            if ((Simulator.getTime() > 10) && (Simulator.getTime() < 22)) {
                return;
            } else {

                giveBirth(newLions); //give birth to new leopards
                giveDiseaseToOthers(); //spread disease to other leopards where applicable
                // Move towards a source of food if found.

                //if weather is not foggy then search for food
                if (!Simulator.weather.getWeather().equals("Fog")) {
                    Location newLocation = findFood();
                    if (newLocation == null) {
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if (newLocation != null) {
                        setLocation(newLocation);
                    } else {
                        // Overcrowding.
                        setDead();
                    }

                    //weather is foggy. just move randomly
                } else {
                    Location newLocation = getField().freeAdjacentLocation((getLocation()));
                    // See if it was possible to move.
                    if (newLocation != null) {
                        setLocation(newLocation);
                    } else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }
}


