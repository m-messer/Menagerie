package src;

import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that an will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.045;
    private static final double LEOPARD_CREATION_PROBABILITY = 0.045  ;
    private static final double ZEBRA_CREATION_PROBABILITY = 0.20;
    private static final double CAMEL_CREATION_PROBABILITY = 0.20;
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.20;
    private static int simulatorTime; // monitors the time
    private static int dayCount; //monitors days that have passed
    public static Weather weather; //weather object

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;


    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;

        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        this.simulatorTime = 0; //set time to 0
        weather = new Weather(); //instantiate new weather object

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Leopard.class, Color.BLUE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Camel.class, Color.ORANGE);
        view.setColor(Zebra.class, Color.PINK);
        view.setColor(Antelope.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        //increment time
        incrementTime();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        //show status of different elements of simulation
        view.showStatus(step, field, simulatorTime, dayCount);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, simulatorTime, dayCount) ;
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= LEOPARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Leopard leopard = new Leopard(true, field, location);
                    animals.add(leopard);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= CAMEL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Camel camel = new Camel(true, field, location);
                    animals.add(camel);
                }
                else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope = new Antelope(true, field, location);
                    animals.add(antelope);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * method for controlling time and incrementing it as steps pass
     */
    private void incrementTime() {

        //increment time by 1 hour every 10 steps
        if (step % 5 == 0) {
            simulatorTime += 1;
            //control disease every 5 steps
            controlDisease();
            //change weather
            weather.changeWeather();

            //increment the time an animal has had the disease if they had it
            for (int i = 0; i < animals.size() - 1; i++) {
                if (animals.get(i).hasDisease()) {
                    animals.get(i).diseaseTimeCount += 1;
                }
            }
        }

        //if time reaches 24 then revert back to 0 i.e. new day
        if (simulatorTime == 24) {

            simulatorTime = 0;
            dayCount +=1;
        }
    }

    /**
     * get time taken in simulator so far (in hours)
     * @return number of hours that have passed
     */
    public static int getTime() {

        return simulatorTime;

    }

    /**
     * get the number of days that have passed
     * @return number of days that have passed
     */
    public static int getDayCount() {

        return dayCount;
    }

    /**
     * method which controls the development and spread of disease
     */
    public void controlDisease() {

        Random rand = new Random();

        //loop through entire list of animals to randomly give disease
        for (int i = 0; i < animals.size() - 1; i++) {

            //randomly determine whether to give disease
            if (rand.nextDouble() < 0.125) {

                //if the animal is alive then give them the disease
                if (animals.get(i).isAlive()) {
                    animals.get(i).giveDisease();

                    //if animal has had disease for 4 hours then kil it
                    if (animals.get(i).diseaseTimeCount >= 4) {
                        SimulatorView.drawDisease(animals.get(i).getLocation().getRow(), animals.get(i).getLocation().getCol());
                        animals.get(i).setDead();
                    }

                }

            }

        }


    }

}
