import java.util.ArrayList;
import java.util.Random;



/**
 * Setting different weather when simulation 
 * different situation when different weather
 *
 * @version 2021.02.25
 */


public class Weather
{
    private ArrayList<String> weathers; 
    private Random rand;
    private String currentWeather;
    private Weather weather;
    
   
    /**
     * Constructor of the weather class
     */
    public Weather()
    {
        weathers = new ArrayList<>();//using arraylist to store different weather
        rand = new Random();//random weather appears
        
        
        weathers.add("Rainy");
        weathers.add("Foggy");
        
    }

    /**
     * 
     * return the current weather
     */
    public String getWeather()
    {   
        return currentWeather;
    }
    
    /**
     * Make a random choice of weather
     */
    public void randomWeather()
    {
        currentWeather =  weathers.get(rand.nextInt(weathers.size()));
    }
    
   
    
    
    
    
}
