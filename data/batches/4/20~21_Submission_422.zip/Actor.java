import java.util.List;
/**
 * Write a description of class Actors here.
 *
 * @version 2021.02.23
 */

// A class represents shared characteristics
public interface Actor
{
    
    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born Actors.
     */
	void act(List<Actor> newActors);
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
	void setLocation(Location newLocation);
}
