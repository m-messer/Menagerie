

 
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sheeps and wolfes.
 *
 * @version 2021.02.22)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.05;
    // The probability that a sheep will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.06;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.05;
    // The probability that a snake will be created in any given grid position.
    private static final double RHIZOMYS_CREATION_PROBABILITY = 0.06;
    // The probability that a bamboo will be created in any given grid position.
    private static final double BAMBOO_CREATION_PROBABILITY = 0.08;
    // The probability that a elephant will be created in any given grid position.
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.02;
    // The probability that a bamboo will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.08;
    
    
    // List of actorss in the field.
    private List<Actor> actors;
    
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The gender of animals
    private Gender gender;
    // Check if is night
    private boolean night;
    // create weather object
    private Weather weather;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);
        gender = new Gender();
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Sheep.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Snake.class, Color.RED);
        view.setColor(Rhizomys.class, Color.BLACK);
        view.setColor(Bamboo.class, Color.MAGENTA);
        view.setColor(Elephant.class, Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
            
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * wolf and sheep.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();   
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            night();//check the time of the day
            weather.randomWeather();
            if(!night && actor instanceof Animal)
            {
                Animal animal = (Animal) actor;
                animal.checkDisease();
                if(!weather.getWeather().equals("Foggy"))
                {
                    animal.act(newActors);
                }
                else
                {
                    animal.incrementAge();
                    animal.incrementHunger();
                    if(animal.isAlive())
                    {
                        animal.giveBirth(newActors);
                    }
                }
            }
            else if(actor instanceof Plant)
            {
                Plant plant = (Plant) actor;
                plant.checkFire();
                if(!weather.getWeather().equals("Rainy"))//
                {
                    plant.act(newActors);
                }
                else
                {
                    plant.incrementAge();
                }
            }
            // check if the actor is animal
            if(actor instanceof Animal) {
                Animal animal = (Animal) actor;
                if(!animal.isAlive())
                {
                    it.remove();
                }
            }
            else if (actor instanceof Animal){
                Animal animal = (Animal) actor;
                if(!animal.isAlive())
                {
                    it.remove();
                }
            }
        }
        
               
        // Add the newly born actors to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();
        
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with wolfes and sheeps.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location, gender.getGender());
                    actors.add(wolf);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sheep sheep = new Sheep(false, field, location, gender.getGender());
                    actors.add(sheep);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location, gender.getGender());
                    actors.add(snake);
                }
                else if(rand.nextDouble() <= RHIZOMYS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rhizomys rhizomys = new Rhizomys(true, field, location, gender.getGender());
                    actors.add(rhizomys);
                }
                else if(rand.nextDouble() <= ELEPHANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Elephant elephant = new Elephant(true, field, location, gender.getGender());
                    actors.add(elephant);
                }
                else if(rand.nextDouble() <= BAMBOO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bamboo bamboo = new Bamboo(true, field, location);
                    actors.add(bamboo);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    actors.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     *  Check if now is night
     */
    private void night()
    {
        if(step%16 <= 8)
            {
                night = true;
            }
        else
            {
                night = false;
            }
    }
   
}
