import java.util.Random;
/**
 * Write a description of class Gender here.
 *
 * @version (a version number or a date)
 */
public class Gender
{
    // instance variables - replace the example below with your own
    private Random rand;

    /**
     * Constructor for objects of class Gender
     */
    public Gender()
    {
        rand = new Random();
    }

    /**
     *  Check if the animal is female
     */
    public String getGender()
    {
        if(rand.nextDouble() <= 0.5)
        {   
            return "Male";
        }
        else
        {
            return "Female";
        }
    }
}
