import java.util.Random;
/**
 * Write a description of class Disease here.
 *  Simulate disease
 *  Some  animals  are  occasionally  infected.  
 *  Infection  can  spread  to  otheranimals when they meet
 *
 * @version 2021.02.26
 */
public class Disease
{
    // instance variables - replace the example below with your own
    private boolean isInfected;
    private boolean disease;
    private Random rand;
    private Double DISEASE_APPEAR_PROBABILITY = 0.00000125;
    /**
     * Constructor for objects of class Disease
     */
    public Disease()
    {
       isInfected = false;
       disease = false;
       rand = new Random();
    }

    /**
     * Check if the animal is infected by the disease
     */
    public boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Check if the animal is infected by the other animals
     */
    public void infected()
    {
        isInfected = true;
    }
    
    /**
     * The probability of the disease appears
     */
    public void makeDisease()
    {
        if(rand.nextDouble() <= DISEASE_APPEAR_PROBABILITY)
        {
            disease = true;
        }
        else
        {
            disease = false;
        }
    }
    
    public boolean checkDisease()
    {
        return disease;
    }
    
}
