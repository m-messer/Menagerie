import java.util.Random;
/**
 * There is a probablity that the plants get fired
 * 
 *
 * @version (a version number or a date)
 */
public class Fire
{
    private boolean isFired;
    private boolean fire;
    private Random rand;
    private Double FIRE_APPEAR_PROBABILITY = 0.000000015;
    
    public Fire()
    {
        isFired = false;
        fire = false;
        rand = new Random();
    }
    
    /**
     * Check if the animal is fired
     */
    public boolean isFired()
    {
        return isFired;
        
    }
    
    /**
     * Check if the plant is fired by the other plants
     */
    public void fired()
    {
        fire = true;
    }
    
    /**
     * The probability of the fire appears
     */
    public void makeFire()
    {
        if(rand.nextDouble() <= FIRE_APPEAR_PROBABILITY)
        {
            fire = true;
        }
        else
        {
            fire = false;
        }
    }
    
    public boolean checkFire()
    {
        return fire;
    }
}
