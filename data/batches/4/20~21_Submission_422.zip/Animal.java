import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal implements Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    protected Disease disease;
    
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        disease = new Disease();
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * let the animal have a chance to birth
     */
    
    abstract public void giveBirth(List<Actor> newAnimals);
    
    /**
     * Look for spouse adjacent to the current location.
     */
    abstract public Location findLove(List<Actor> newAnimals);
    
    /**
     * Look for food adjacent to the current location.
     */
    abstract public Location findFood();
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    abstract public void incrementAge();
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    abstract public void incrementHunger();
    
    /**
     * check if the animal is infected by the disease
     * if it is infected, it can spread to the other animals
     */
    abstract public Location spreadDisease();
    
    /**
     * check if there is disease
     */
    public void checkDisease()
    {
        if(disease.checkDisease())
        {
            System.out.println("There is disease found!");
        }
    }
}
