import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a grass.
 * Grasss age, move, breed, and die.
 *
 * @version 2021.02.24
 */
public class Grass extends Plant
{
    // Characteristics shared by all grasses (class variables).

    // The age at which a grass can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a grass can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a grass breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The grass's age.
    private int age;
    

    /**
     * Create a new grass. A grass may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the grass does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGrasss A list to return newly born grasses.
     */
    public void act(List<Actor> newGrasss)
    {
        incrementAge();
        fire.makeFire();
        
        if(isAlive())
        {
            giveBirth(newGrasss);
            if(fire.isFired())// if the plant is fired, then spread
            {
                Location newLocation = spreadFire();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the grass's death.
     * @override the method in plant class
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrasss A list to return newly born grasses.
     * @override the giveBirth() in Plant class
     * 
     */
    public void giveBirth(List<Actor> newGrasses)
    {
        // New grasses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrasses.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A grass can breed if it has reached the breeding age.
     * @return true if the grass can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * check if the plant is fired 
     * if it is fired, it can spread to the other plants
     */
    public Location spreadFire()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant) {
                Plant plants = (Plant) plant;
                if(plants.isAlive() && !fire.isFired()){
                    fire.fired();
                    plants.setDead();
                    return where;
                }
                else if (fire.isFired())
                {
                    plants.setDead();
                }
            }
        }
        return null;
    }
    
}
