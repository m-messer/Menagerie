import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a elephant.
 * Elephants age, move, breed, and die.
 *
 * @version 2021.02.22
 */
public class Elephant extends Animal
{
    // Characteristics shared by all elephants (class variables).

    // The age at which a elephant can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a elephant can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a elephant breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The food value of a single grass. In effect, this is the
    // number of steps a rhizomy can move before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 8;

    // Individual characteristics (instance fields).

    // The elephant's age.
    private int age;
    // The gender of the animals
    private Gender temp;
    // The instance variable for storing the current animal's gender
    private String currentGender;
    //The Elephant's food level, which is increased by eating grass.
    private int foodLevel;
    /**
     * Create a new elephant. A elephant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the elephant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Elephant(boolean randomAge, Field field, Location location, String gender)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
        temp = new Gender();
    }

    /**
     * return the gender of the animal
     */
    public String getGender()
    {
        return currentGender;
    }

    /**
     * This is what the elephant does most of the time: it hunts for
     * grass. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newElephant A list to return newly born wolves.
     */
    public void act(List<Actor> newElephants)
    {
        incrementAge();
        incrementHunger();
        disease.makeDisease();
        if(isAlive()) {
            giveBirth(newElephants);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            newLocation = findLove(newElephants);
            if(disease.isInfected())// if the plant is infected, then spread
            {
                newLocation = spreadDisease();
            }
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the elephant's death.
     * @override the method in animal class
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this elephant more hungry. This could result in the elephant's death.
     * @override the method in animal class
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this elephant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newElephants A list to return newly born elephants.
     * @override the method in the animal class
     */
    public void giveBirth(List<Actor> newElephants)
    {
        // New elephants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Elephant young = new Elephant(false, field, loc, temp.getGender());
            newElephants.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A elephant can breed if it has reached the breeding age.
     * @return true if the elephant can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Look for spouse adjacent to the current location.
     * @override the method in the animal class
     */
    public Location findLove(List<Actor> newElephants)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Elephant) {
                Elephant elephant = (Elephant) animal;
                if(elephant.isAlive() && currentGender != elephant.getGender()){
                    giveBirth(newElephants);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Look for grasses adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     * @override the method in the animal class
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) {
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
       
     /**
     * check if the animal is infected by the disease
     * if it is infected, it can spread to the other animals
     */
    public Location spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal animals = (Animal) animal;
                if(animals.isAlive() && !disease.isInfected()){
                    animals.incrementHunger();
                    disease.infected();
                    return where;
                }
            }
        }
        return null;
    }
}
