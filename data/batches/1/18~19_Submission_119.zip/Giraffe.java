import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Giraffe.
 * Giraffes age, move, breed, and die.
 *
 */
public class Giraffe extends Animal
{
    /**
     * Create a new giraffe. A giraffe may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the giraffe will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Giraffe(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        BREEDING_AGE = 200;
        MAX_AGE = 600;
        BREEDING_PROBABILITY = 0.2;
        MAX_LITTER_SIZE = 3;
        height = 500;
        FOOD_VALUE = 30;
        
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        sex = rand.nextBoolean();
        foodLevel = 30;
    }
    
    /**
     * This is what the mice does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newmices A list to return newly born mices.
     */
    public void act(List<Animal> newAnimals, boolean daytime)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newAnimals);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
                Location temp = location;
                Plant newPlant = new Plant(false, field, temp);
                newAnimals.add(newPlant);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * The mice moves around, looks for food. And eats whatever is around it. If it is still alive and is able
     * to reach taller food. It eats them and survives, otherwise, it dies.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Plant) {
                Animal animal = (Animal) food; 
                if(animal.isAlive() && this.height > animal.height) { 
                    animal.setDead();
                    this.foodLevel += animal.FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
