import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Jaguar.
 * jaguares age, move, eat prey, and die.
 *
 */
public class Jaguar extends Animal
{
    
    /**
     * Create a jaguar. A jaguar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the jaguar will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the safari.
     */
    public Jaguar(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        BREEDING_AGE = 30;
        MAX_AGE = 200;
        BREEDING_PROBABILITY = 0.1;
        MAX_LITTER_SIZE = 1;
        height = 70;
        FOOD_VALUE = 30;
        
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(120); //general food level
        }
        else {
            age = 0;
            foodLevel = 60;
        }
        
        sex = rand.nextBoolean();
    }
    
    /**
     * This is what the jaguar does most of the time: it hunts for
     * its prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newjaguares A list to return newly born jaguares.
     */
    public void act(List<Animal> newAnimals, boolean daytime)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && daytime) {
            giveBirth(newAnimals);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
                
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }    
    
    /**
     * Look for prey/animal adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            // Can move to plants and kill them but gains no foodlevel from it
            if(food instanceof Plant || food instanceof Mice || food instanceof Giraffe || food instanceof Zebra || food instanceof InfectedMice) {
                Animal animal = (Animal) food;
                if(animal.isAlive()) { 
                    animal.setDead();
                    if(!(food instanceof Plant)){
                        this.foodLevel += animal.FOOD_VALUE;
                    }
                    return where;
                }
            }
        }
        return null;
    }
}
