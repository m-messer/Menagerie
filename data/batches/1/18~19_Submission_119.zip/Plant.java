import java.util.List;
import java.util.Random;

/**
 * This is a plant class. It can breed, die and get eaten by animals.
 * 
 */
public class Plant extends Animal 
{
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        BREEDING_AGE = 1;
        MAX_AGE = 10;
        BREEDING_PROBABILITY = 0.9;
        MAX_LITTER_SIZE = 6;
        FOOD_VALUE = 8;

        if (rand.nextBoolean()){
            height = 1;
        }
        height = 25;
        
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    
    /**
     * The plants will grow, and if it is still alive, it will breed and create new plants.
     */
    public void act(List<Animal> newAnimals, boolean daytime){
        incrementAge();
        if(isAlive()) {
            giveBirth(newAnimals);
        }
    }
}
