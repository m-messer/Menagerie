import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.lang.reflect.Constructor;

/**
 * A class representing shared characteristics of animals.
 *
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    public Field field;
    // The animal's position in the field.
    public Location location;
   
    // The animals's age, height in cm, speed in km/h
    public int age;
    public int height;
    public boolean sex; //true = male, false = female
    
    // The animal's food level, which is how many steps it can move
    public int foodLevel;
    // food value of the animals, added to their consumer's food level. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    public int FOOD_VALUE;
    
    // A shared random number generator to control breeding.
    public Random rand = Randomizer.getRandom();
    
    // The age at which an animal can start to breed.
    public int BREEDING_AGE;
    // The age to which an animal can live.
    public int MAX_AGE;
    // The likelihood of an animal breeding out of 1.
    public double BREEDING_PROBABILITY;
    // The maximum number of births.
    public int MAX_LITTER_SIZE;
    // Is the animal infected?
    public boolean INFECTED;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        FOOD_VALUE = 10;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, boolean daytime);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Returns the gender of the animal.
     * true  = male, false = female
     */ 
    protected boolean getSex()
    {
        return sex;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    /**
     * Increase the age. This could result in the animal's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * An animal can breed if it has reached the breeding age, is female and has an adjacent male.
     * @return true if the animal can breed, false otherwise.
     */
    public boolean canBreed()
    {
        //Plants behave differently, dont need mate
        if (this instanceof Plant) {
            return true;
        }
        
        if(!getSex() && age >= BREEDING_AGE) {
            Field field = getField();
            List<Location> free = field.adjacentLocations(getLocation());
            for(Location var : free) {
                //Check if animal in adjacent location is of the same species
                if(this.getClass().isInstance(field.getObjectAt(var))) {
                    //Casting is safe as the object is guranteed to be an animal from above
                    Animal mate = (Animal) field.getObjectAt(var);
                    //System.out.println("TRUE");
                    return mate.getSex(); //Return true if mate is male
                }
            }
        }
        //System.out.println("FALSE");
        return false;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= this.BREEDING_PROBABILITY) {
            births = rand.nextInt(this.MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * The typical method of creating objects with new cannot be used as the class of the object being 
     * created is only known at runtime. E.g. It needs to know to give birth to lions when a lion calls on 
     * this method. This technique is called reflection.
     * @param newAnimals A list to return newly born Animals.
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        
        try {
            Class<?> c = this.getClass(); 
            //initialises a constructor of the mother which has the following parameters. In this case
            // there is only one constructor;
            Constructor<?> constructor = c.getConstructor(boolean.class, Field.class, Location.class);
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                //Creates a new object using the constructor of whatever species called giveBirth
                
                //Small chance of an infected mice being born if the species that invoked the method is a mouse        
                if (rand.nextDouble() <= 0.0001 && this instanceof Mice){
                    InfectedMice young = new InfectedMice(field, location);
                    newAnimals.add((Animal) young);
                }
                else {
                    Object young = constructor.newInstance(false, field, loc);
                    //Even though the new object is verifiably (using getClass()) a specific animal, Java 
                    //still treats it like an Object so a cast is needed here.
                    
                    newAnimals.add((Animal) young);
                }
            }
        } catch (Exception e) {
            System.out.println("GIVE BIRTH ERROR");
        }
    }
}