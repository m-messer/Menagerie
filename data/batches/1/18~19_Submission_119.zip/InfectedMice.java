import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * The infected mice can infect normal mice, can breed and age, or die. 
 * @param It stays in the given field.
 * @param It will run around the given location
 *
 */
public class InfectedMice extends Animal
{
    public InfectedMice(Field field, Location location)
    {
        super(field, location);
        
        MAX_AGE = 15;
        BREEDING_PROBABILITY = 1;
        MAX_LITTER_SIZE = 1;
        height = 10;
        FOOD_VALUE = -1;
        
        age = 0;
        foodLevel = 4;
        sex = rand.nextBoolean();
    }
    /**
     * This is what theinfected mice does most of the time - it hunts for mice 
     * . Sometimes it will breed or die of old age.
     * @param newmices A list to return newly born mices.
     */
    public void act(List<Animal> newAnimals, boolean daytime)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
                       
            // Move towards a source of food if found.
            Location newLocation = findFood(newAnimals);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation == null) {
                setDead();
            }
        }
    }
    
    /**
     * The infected mice moves around, looks for healthy mice and eats it.
     * 
     */
    private Location findFood(List<Animal> newmices)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Mice) {
                Animal animal = (Animal) food; 
                if(animal.isAlive()) { 
                    InfectedMice victim = new InfectedMice(field, location);
                    newmices.add(victim);
                    animal.setDead();
                    return where;
                }
            }
        }
        return null;
    }
}



