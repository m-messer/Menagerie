import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * liones age, move, eat rabbits, and die.
 *
 */
public class Lion extends Animal 
{
    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        BREEDING_AGE = 200;
        MAX_AGE = 1000;
        BREEDING_PROBABILITY = 0.1;
        MAX_LITTER_SIZE = 1;
        height = 120;
        FOOD_VALUE = 30;
        
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(200); //general food level
        }
        else {
            age = 0;
            foodLevel = 100;
        }
        
        sex = rand.nextBoolean();
    }
    
    /**
     * This is what the lion does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newliones A list to return newly born liones.
     */
    public void act(List<Animal> newAnimals, boolean daytime)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive() && daytime) {
            giveBirth(newAnimals);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
        }
    }    
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live and correct prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            // Can move to plants and kill them but gains no foodlevel from it
            if(food instanceof Plant || food instanceof Mice || food instanceof Giraffe || food instanceof Zebra || food instanceof InfectedMice) {
                Animal animal = (Animal) food;
                if(animal.isAlive()) { 
                    animal.setDead();
                    if(!(food instanceof Plant)){
                        this.foodLevel += animal.FOOD_VALUE;
                    }
                    return where;
                }
            }
        }
        return null;
    }
}
