import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * Wolves age, move, eat sheep mice, breed and die.
 *
 * @version 2022.03.02 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all foxes (class variables).
    
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a fox can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum food level it can intake.
    private static final int MAX_FOOD_LEVEL = 40;
    // The food value of a single rabbit
    private static final int FOOD_VALUE = 20;
    // A list of lions prey
    private static final List<Class> PREY_LIST = List.of(Sheep.class,Mouse.class);
  
    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level. A wolf is created 
     * with a random gender.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If true, the wolf's gender will be male 
     * @param isDiseased If True it means the wolf is infected and will act accordingly.
     */
    public Wolf( boolean randomAge, Field field, Location location, boolean isMale, boolean isDiseased)
    {
        super(field, location, isDiseased);

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        super.isMale = isMale;
    }
    
    /**
     * Return the wolf's breeding age
     * @return the wolf's breeding age
     */
    public int get_BREEDING_AGE(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the wolf's maximum age(lifespan)
     * @return the wolf's maximum age(lifespan)
     */
    public int get_MAX_AGE(){
        return MAX_AGE;
    }
    
    /**
     * Return the wolf's breeding probability.
     * @return the wolf's breeding probability.
     */
    public double get_BREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the wolf's maximum number of births.
     * @return the wolf's maximum number of births.
     */
    public int get_MAX_LITTER_SIZE(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the wolf's maximum food level.
     * @return the wolf's maximum food level.
     */
    public int get_MAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the food value wolf provide.
     * @return the food value wolf provide.
     */
    public int get_FOOD_VALUE(){
        return FOOD_VALUE;
    }
    
    /**
     * Return the list of prey of wolf.
     * @return the list of prey of wolf.
     */
    public List<Class> get_PREY_LIST(){
        return PREY_LIST;
    }
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born wolves.
     */
    public void giveBirth(List<Animal> newWolves)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        boolean isBirthMale =  rand.nextBoolean(); //assign a random gender
        for(int b = 0; b < births && free.size() > 0; b++) {
         
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, field, loc, isBirthMale,false);
            newWolves.add(young);
            
        }
    }
}
