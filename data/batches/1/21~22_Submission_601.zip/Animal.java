import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.03.02 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    protected Location location;
    
    public abstract int get_BREEDING_AGE();                  //get the breeding age of the animal
    public abstract int get_MAX_AGE();                       //get the max age of the animal
    public abstract double get_BREEDING_PROBABILITY();       // get the breeding probability of the animal
    public abstract int get_MAX_LITTER_SIZE();               //get the max number of children the animal can have
    public abstract int get_MAX_FOOD_LEVEL();                // get the max food that the animal can store
    public abstract int get_FOOD_VALUE();                    // get the nutritional content eating this animal with provide
    public abstract List<Class> get_PREY_LIST();             // get the list of animals that this animal can eat
    // The animal's age.
    protected int age;
    // The animal's food level.
    protected int foodLevel;
    // The animal's gender.
    protected boolean isMale;
    
    protected static final Random rand = Randomizer.getRandom();
    //The animal's disease status.
    protected Disease disease;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isDiseased whether the animal should be created with a disease or not
     */
    public Animal(Field field, Location location, boolean isDiseased)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        if (isDiseased){
            Disease temp = new Disease();
            for (Class affected : temp.getAffectedList()){
                if (this.getClass() == affected){
                    disease = temp;
                }
            }
        }
    }
    
    /**
     * This is what the animal does most of the time: it hunts for
     * food. In the process, it might breed,contract diseases, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newAnimals A list to return newly born animals.
     * @param clock the object which holds the current time.
     */
    public void act(List<Animal> newAnimals, ClockDisplay clock){
        incrementAge();
        incrementHunger();
        if (timeAffect(clock)){
            if (hasDisease()){
               disease.act(this);
               }
            Location newLocation = null;
            if(isAlive()) {           
                // Move towards a source of food if found.
                if ((double)foodLevel / get_MAX_FOOD_LEVEL() <= 0.6){   //only hunt for food if the animal is hungry by 40%
                    newLocation = findFood();
                }
                
                if ((double)foodLevel / get_MAX_FOOD_LEVEL() >= 0.6 && findMate()){   //only look for mate if animal is at least 60% full
                    giveBirth(newAnimals);
                }
                
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * Increase the age by 1. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > get_MAX_AGE()) {
            setDead();
        }
    }
    
    /**
     * Increase the age by specified amount. This could result in the animal's death.
     */
    protected void incrementAge(int num){
        age += num;
        if(age > get_MAX_AGE()){
            setDead();
        }
    }
    
     /**
     * Make this fox more hungry by 1 food level. This could result in the fox's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Make this fox more hungry by a specified amount. This could result in the fox's death.
     */
    protected void incrementHunger(int num)
    {
        foodLevel -= num;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Increase the animal's food level according to food eaten.
     */
    protected void updateFoodLevel(int amount){
        foodLevel = Math.min(get_MAX_FOOD_LEVEL(),foodLevel + amount);
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            for (Class prey : get_PREY_LIST()){                         // check whether the animal found is a prey of the animal
                if (animal != null && prey.equals(animal.getClass())){
                    Animal hunted = (Animal) animal;
                    if (hunted.isAlive()){
                        updateFoodLevel(hunted.get_FOOD_VALUE());
                        hunted.setDead();
                        return where;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Look for animals of same species and different gender to breed adjacent
     * to the current location.
     * Only the first live mate is bred with.
     * @return True if a mate was found and false if it wasnt.
     */
    protected boolean findMate(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            if(animal != null && this.getClass() == animal.getClass()) {    //check whether the animal found is of the same class as this animal
                Animal mate = (Animal) animal;
                if(mate.isAlive() && isMale != mate.getIsMale()) { 
                    return true;
                }
            }
        
        }
        return false;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= get_BREEDING_PROBABILITY()) {
            births = rand.nextInt(get_MAX_LITTER_SIZE()) + 1;
        }
        return births;
    }
    
    /**
     * Make this animal give birth
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void giveBirth(List<Animal> newAnimals);
    
    /**
     * return whether animal is affected by time
     */
    protected boolean timeAffect(ClockDisplay clock){    // override this method in child class for time properties
        return true;    
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the animal's gender.
     * @return The animal's gender.
     */
    protected boolean getIsMale(){
        return isMale;
    }
    
    /**
     * A fox can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= get_BREEDING_AGE();
    }
    
    /**
     * Return true if the animal's infected.
     * @return True if the animal's infected.
     */
    protected boolean hasDisease(){
        return disease != null;
    }
    
    
    /**
     * Return the animal's disease status.
     * @return the animal's disease status.
     */
    protected Disease getDisease(){
        return disease;
    }
    
    /**
     * Set the animal to be infected with a disease.
     */
    protected void setDisease(Disease disease){
        this.disease = disease;
    }
}
