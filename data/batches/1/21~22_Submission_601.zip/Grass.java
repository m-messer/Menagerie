import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of grass.
 * Grass ages, grows and dies
 * 
 * @version 2022.03.02 (2) 
 */
public class Grass extends Animal
{
    // Characteristics shared by all grass (class variables).

    // The age at which a grass can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a grass can live.
    private static final int MAX_AGE = 10;
    // The likelihood of a grass breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum food level it can intake.
    private static final int MAX_FOOD_LEVEL = 10;
    // The food value it provides to predators.
    private static final int FOOD_VALUE = 5;
    // A list of grass' prey.
    private static final List<Class> PREY_LIST = List.of();
    
    private Simulator view;
    /**
     * Create a grass. A grass can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the grass will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isDiseased If True it means the grass is infected and will act accordingly.
     */
    public Grass( boolean randomAge, Field field, Location location, boolean isDiseased)
    {
        super(field, location, isDiseased);

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        
      
    }
    
    /**
     * Return the grass' breeding age
     * @return the grass' breeding age
     */
    public int get_BREEDING_AGE(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the grass' maximum age(lifespan)
     * @return the grass' maximum age(lifespan)
     */
    public int get_MAX_AGE(){
        return MAX_AGE;
    }
    
    /**
     * Return the grass' breeding probability.
     * @return the grass' breeding probability.
     */
    public double get_BREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the grass' maximum number of births.
     * @return the grass' maximum number of births.
     */
    public int get_MAX_LITTER_SIZE(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the grass' maximum food level.
     * @return the grass' maximum food level.
     */
    public int get_MAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the food value grass provides.
     * @return the food value grass provides.
     */
    public int get_FOOD_VALUE(){
        return FOOD_VALUE;
    }
    
    /**
     * Return the list of prey of grass.
     * @return the list of prey of grass.
     */
    public List<Class> get_PREY_LIST(){
        return PREY_LIST;
    }
    
    /**
     * This is what the grass does most of the time: it ages and in the process 
     * it might reproduce or die of old age.
     * @param field The field currently occupied.
     * @param newAnimals A list to return newly born grass.
     */
    public void act(List<Animal> newGrass, ClockDisplay clock){
        if (clock.getHour() > 4 && clock.getHour() < 22){
            if(isAlive()) {           
            giveBirth(newGrass);
            }
        }
        incrementAge();
    }
    
    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born grass.
     */
    public void giveBirth(List<Animal> newGrass)
    {
        // New grass are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
         
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc,false);
            newGrass.add(young);
            
        }
    }
}
