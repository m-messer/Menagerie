import java.util.List;
import java.util.Random;

/**
 * A simple model of a Sheep.
 * Sheeps age, move, breed,eat grass and carrots and die.
 *
 * @version 2022.03.02 (2)
 */
public class Sheep extends Animal
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The maximum food level it can intake.
    private static final int MAX_FOOD_LEVEL = 20;
    // The food value it provides to predators.
    private static final int FOOD_VALUE = 5;
    // A list of rabbits' prey.
    private static final List<Class> PREY_LIST = List.of(Carrot.class,Grass.class);

    /**
     * Create a new sheep. A sheep may be created with age
     * zero (a new born) or with a random age. A sheep is created 
     * with a random gender.
     * 
     * @param randomAge If true, the sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If true, the sheep's gender will be male 
     * @param isDiseased If True it means the sheep is infected and will act accordingly.
     */
    public Sheep(boolean randomAge, Field field, Location location, boolean isMale, boolean isDiseased)
    {
        super(field, location, isDiseased);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        super.isMale = isMale;
    }
    
    /**
     * Return the sheep's breeding age
     * @return the sheep's breeding age
     */
    public int get_BREEDING_AGE(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the sheep's maximum age(lifespan)
     * @return the sheep's maximum age(lifespan)
     */
    public int get_MAX_AGE(){
        return MAX_AGE;
    }
    
    /**
     * Return the sheep's breeding probability.
     * @return the sheep's breeding probability.
     */
    public double get_BREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the sheep's maximum number of births.
     * @return the sheep's maximum number of births.
     */
    public int get_MAX_LITTER_SIZE(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the sheep's maximum food level.
     * @return the sheep's maximum food level.
     */
    public int get_MAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the food value sheep provide.
     * @return the food value sheep provide.
     */
    public int get_FOOD_VALUE(){
        return FOOD_VALUE;
    }
    
    /**
     * Return the list of prey of sheep.
     * @return the list of prey of sheep.
     */
    public List<Class> get_PREY_LIST(){
        return PREY_LIST;
    }
    
    /**
     * Check whether or not this sheep is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born sheep.
     */
    public void giveBirth(List<Animal> newSheep)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        boolean isBirthMale =  rand.nextBoolean(); //assign a random gender
        for(int b = 0; b < births && free.size() > 0; b++) {
         
            Location loc = free.remove(0);
            Sheep young = new Sheep(false, field, loc, isBirthMale,false);
            newSheep.add(young);
            
        }
    }
}
