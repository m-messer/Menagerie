import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a disease.
 * Diseases infect animals which can then be spread throughout the 
 * population. They cause animals to gain hunger.
 *
 * @version 2022.03.02 (2)
 */
public class Disease
{
    private static final int HUNGER_INCREASE = 2;     // the hunger affect this disease has on the animal
    
    private static final int AGE_INCREASE = 1;        // the ageing affect this disease has on the animal
    
    private static final List<Class> affectedList = List.of(Sheep.class, Mouse.class);

    /**
     * Constructor for objects of class Disease
     */
    public Disease()
    {
        // initialise instance variables
    }
    /**
     * @param animal the animal being affected
     * the act method which affects the animal that is given and spreads based on that animals location
     */
    public void act(Animal animal){
        animal.incrementHunger(HUNGER_INCREASE);
        animal.incrementAge(AGE_INCREASE);
        spread(animal);
    }
    
    /**
     * @param animal the animal being spread from
     * spreading the disease to a nearby animal
     */
    public void spread(Animal animal){
        if (animal.isAlive()){
            Field field = animal.getField();
            List<Location> adjacent = field.adjacentLocations(animal.getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object target = field.getObjectAt(where);
                for (Class prey : affectedList){
                    if (target != null){
                        Animal hunted = (Animal) target;
                        if (hunted.isAlive()&& prey.equals(target.getClass())){
                            //Disease child = new Disease();
                            hunted.setDisease(this);
                        }
                    }
                }
            }
        }
    }
    /**
     * @return the list of animals that this disease affects
     */
    public List<Class> getAffectedList(){
        return affectedList;
    }
}
