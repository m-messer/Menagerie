import java.util.List;
import java.util.Random;

/**
 * A simple model of a mouse.
 * Mice age, move, breed,eat grass and carrots and die.
 *
 * @version 2022.03.02 (2)
 */
public class Mouse extends Animal
{
    // Characteristics shared by all mice (class variables).

    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum food level it can intake.
    private static final int MAX_FOOD_LEVEL = 20;
    // The food value it provides to predators.
    private static final int FOOD_VALUE = 10;
    // A list of mice prey.
    private static final List<Class> PREY_LIST = List.of(Carrot.class,Grass.class);

    /**
     * Create a new mouse. A mouse may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the mouse will have a random age.An eagle is created 
     * with a random gender.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If true, the eagle's gender will be male 
     * @param isDiseased If True it means the mice is infected and will act accordingly.
     */
    public Mouse(boolean randomAge, Field field, Location location, boolean isMale, boolean isDiseased)
    {
        super(field, location, isDiseased);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        super.isMale = isMale;
    }
    
    /**
     * Return the mouse's breeding age
     * @return the mouse's breeding age
     */
    public int get_BREEDING_AGE(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the mouse's maximum age(lifespan)
     * @return the mouse's maximum age(lifespan)
     */
    public int get_MAX_AGE(){
        return MAX_AGE;
    }
    
    /**
     * Return the mouse's breeding probability.
     * @return the mouse's breeding probability.
     */
    public double get_BREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the mouse's maximum number of births.
     * @return the mouse's maximum number of births.
     */
    public int get_MAX_LITTER_SIZE(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the mouse's maximum food level.
     * @return the mouse's maximum food level.
     */
    public int get_MAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the food value mouse provide.
     * @return the food value mouse provide.
     */
    public int get_FOOD_VALUE(){
        return FOOD_VALUE;
    }
    
    /**
     * Return the list of prey of mouse.
     * @return the list of prey of mouse.
     */
    public List<Class> get_PREY_LIST(){
        return PREY_LIST;
    }
    
    /**
     * Return True if the animal is allowed to act at this given time.
     * @return True if the animal is allowed to act at this given time.
     */
    public boolean timeAffect(ClockDisplay clock){
        if (clock.getHour() > 21 || clock.getHour() < 6){
            return true;
        }
        return false;
    }
    
    /**
     * Check whether or not this mouse is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born mice.
     */
    public void giveBirth(List<Animal> newMice)
    {
        // New mice are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        boolean isBirthMale =  rand.nextBoolean(); //assign a random gender
        for(int b = 0; b < births && free.size() > 0; b++) {
         
            Location loc = free.remove(0);
            Mouse young = new Mouse(false, field, loc, isBirthMale, false);
            newMice.add(young);
            
        }
    }
}