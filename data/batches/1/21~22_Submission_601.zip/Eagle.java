import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an Eagle.
 * Eagles age, move, eat mice, and die. 
 * 
 * @version 2022.03.02 (2) 
 */
public class Eagle extends Animal
{
    // Characteristics shared by all eagles (class variables).

    // The age at which an eagle can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which an eagle can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a eagle breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum food level it can intake.
    private static final int MAX_FOOD_LEVEL = 50;
    // The food value it provides to predators.
    private static final int FOOD_VALUE = 20;
    // A list of eagle prey
    private static final List<Class> PREY_LIST = List.of(Mouse.class);

    /**
     * Create an eagle. An eagle can be created as a new born (age zero
     * and not hungry) or with a random age and food level. An eagle is created 
     * with a random gender.
     * 
     * @param randomAge If true, the eagle will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If true, the eagle's gender will be male 
     * @param isDiseased If True it means the eagle is infected and will act accordingly.
     */
    public Eagle(boolean randomAge, Field field, Location location, boolean isMale, boolean isDiseased)
    {
        super(field, location, isDiseased);

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        super.isMale = isMale;
        
      
    }
    
    /**
     * Return the eagle's breeding age
     * @return the eagle's breeding age
     */
    public int get_BREEDING_AGE(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the eagle's maximum age(lifespan)
     * @return the eagle's maximum age(lifespan)
     */
    public int get_MAX_AGE(){
        return MAX_AGE;
    }
    
    /**
     * Return the eagle's breeding probability.
     * @return the eagle's breeding probability.
     */
    public double get_BREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the eagle's maximum number of births.
     * @return the eagle's maximum number of births.
     */
    public int get_MAX_LITTER_SIZE(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the eagle's maximum food level.
     * @return the eagle's maximum food level.
     */
    public int get_MAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the food value eagle provide.
     * @return the food value eagle provide.
     */
    public int get_FOOD_VALUE(){
        return FOOD_VALUE;
    }
    
    /**
     * Return the list of prey of eagle.
     * @return the list of prey of eagle.
     */
    public List<Class> get_PREY_LIST(){
        return PREY_LIST;
    }
    
    /**
     * Check whether or not this eagle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newEagles A list to return newly born eagles.
     */
    public void giveBirth(List<Animal> newEagles)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        boolean isBirthMale =  rand.nextBoolean(); //assign a random gender
        for(int b = 0; b < births && free.size() > 0; b++) {
         
            Location loc = free.remove(0);
            Eagle young = new Eagle(false, field, loc, isBirthMale,false);
            newEagles.add(young);
            
        }
    }
}