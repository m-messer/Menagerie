import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a carrot.
 * Carrots age, grow and die.They only act during the day.
 *
 * @version 2022.03.02 (2) 
 */
public class Carrot extends Animal
{
    // Characteristics shared by all carrots (class variables).

    // The age at which a carrot can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a carrot can live.
    private static final int MAX_AGE = 10;
    // The likelihood of a carrot breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The maximum food level it can intake.
    private static final int MAX_FOOD_LEVEL = 10;
    // The food value it provides to predators.
    private static final int FOOD_VALUE = 10;
    // A list of carrots' prey.
    private static final List<Class> PREY_LIST = List.of();
    /**
     * Create a carrot. A carrot can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the carrot will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isDiseased If True it means the carrot is infected and will act accordingly.
     */
    public Carrot( boolean randomAge, Field field, Location location, boolean isDiseased)
    {
        super(field, location, isDiseased);

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        
      
    }
    
    /**
     * Return the carrot's breeding age
     * @return the carrot's breeding age
     */
    public int get_BREEDING_AGE(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the carrot's maximum age(lifespan)
     * @return the carrot's maximum age(lifespan)
     */
    public int get_MAX_AGE(){
        return MAX_AGE;
    }
    
    /**
     * Return the carrot's breeding probability.
     * @return the carrot's breeding probability.
     */
    public double get_BREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the carrot's maximum number of births.
     * @return the carrot's maximum number of births.
     */
    public int get_MAX_LITTER_SIZE(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the carrot's maximum food level.
     * @return the carrot's maximum food level.
     */
    public int get_MAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the food value carrots provide.
     * @return the food value carrots provide.
     */
    public int get_FOOD_VALUE(){
        return FOOD_VALUE;
    }
    
    /**
     * Return the list of prey of carrots.
     * @return the list of prey of carrots.
     */
    public List<Class> get_PREY_LIST(){
        return PREY_LIST;
    }
    
     /**
     * This is what the carrot does most of the time: it ages and in the process 
     * it might reproduce or die of old age.
     * @param field The field currently occupied.
     * @param newAnimals A list to return newly born carrots.
     * @param clock to receive time
     */
    public void act(List<Animal> newCarrots, ClockDisplay clock){
        
        if (clock.getHour() > 4 && clock.getHour() < 22){
            if(isAlive()) {           
            giveBirth(newCarrots);
            }
        }
        incrementAge();
    }
    
     
    /**
     * Check whether or not this carrot is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born carrots.
     */
    public void giveBirth(List<Animal> newCarrots)
    {
        // New carrots are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
         
            Location loc = free.remove(0);
            Carrot young = new Carrot(false, field, loc, false);
            newCarrots.add(young);
            
        }
    }
}
