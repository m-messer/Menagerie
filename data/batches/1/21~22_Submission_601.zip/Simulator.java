import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sheep, wolves, lions, eagles, mice, carrots and grass.
 *
 * @version 2022.03.02 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.005;
    // The probability that a sheep will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.04;   
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;
    // The probability that a eagle will be created in any given grid position.
    private static final double EAGLE_CREATION_PROBABILITY = 0.001;
    // The probability that a mouse will be created in any given grid position.  
    private static final double MOUSE_CREATION_PROBABILITY = 0.01;
    // The probability that a carrot will be created in any given grid position.  
    private static final double CARROT_CREATION_PROBABILITY = 0.03;
    // The probability that grass will be created in any given grid position.  
    private static final double GRASS_CREATION_PROBABILITY = 0.03;
    // The probability that a disease will be created in any given grid position. 
    private static final double DISEASE_CREATION_PROBABILITY = 0.01;

    private static final Random rand = Randomizer.getRandom();
    
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step; // each step = 1 minute.
    //The current time of the simulation.
    
    // A graphical view of the simulation.
    private SimulatorView view;
    // A graphical display of a clock
    ClockDisplay clock = new ClockDisplay();
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        clock.setTime(12,0);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        clock.setTime(12,0);
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Sheep.class, Color.LIGHT_GRAY);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Lion.class, Color.YELLOW);
        view.setColor(Eagle.class, Color.CYAN);
        view.setColor(Mouse.class, Color.DARK_GRAY);
        view.setColor(Carrot.class, Color.ORANGE);
        view.setColor(Grass.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        clock.hourTick();
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, clock);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field,clock);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        clock.setTime(12, 0);
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field,clock);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                boolean isMale = rand.nextBoolean(); // random chance of male or female

                boolean isDiseased = (rand.nextDouble() <= DISEASE_CREATION_PROBABILITY); // check whether animal should have the disease
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(false, field, location, isMale, isDiseased);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sheep sheep = new Sheep(true, field, location, isMale,isDiseased);
                    animals.add(sheep);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(false, field, location, isMale,isDiseased);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= EAGLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(false, field, location, isMale, isDiseased);
                    animals.add(eagle);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(false, field, location, isMale, isDiseased);
                    animals.add(mouse);
                }
                // else leave the location empty.
                else if(rand.nextDouble() <= CARROT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Carrot carrot = new Carrot(true, field, location,isDiseased);
                    animals.add(carrot);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location,isDiseased);
                    animals.add(grass);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
