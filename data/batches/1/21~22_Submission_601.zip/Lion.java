import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a lion.
 * Lions age, move, eat sheep and wolves, and mice and die.
 *
 * @version 2022.03.02 (2)
 */
public class Lion extends Animal
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a lion can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum food level it can intake.
    private static final int MAX_FOOD_LEVEL = 80;
    // The food value it provides to predators.
    private static final int FOOD_VALUE = 20;
    // A list of lions prey
    private static final List<Class> PREY_LIST = List.of(Sheep.class, Mouse.class, Wolf.class);

     /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level. A lion is created 
     * with a random gender.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If true, the lion's gender will be male 
     * @param isDiseased If True it means the lion is infected and will act accordingly.
     */
    public Lion( boolean randomAge, Field field, Location location,boolean isMale, boolean isDiseased)
    {
        super(field, location, isDiseased);

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_LEVEL;
        }
        super.isMale = isMale;
        
    }

    /**
     * Return the lion's breeding age
     * @return the lion's breeding age
     */
    public int get_BREEDING_AGE(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the lion's maximum age(lifespan)
     * @return the lion's maximum age(lifespan)
     */
    public int get_MAX_AGE(){
        return MAX_AGE;
    }
    
    /**
     * Return the lion's breeding probability.
     * @return the lion's breeding probability.
     */
    public double get_BREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the lion's maximum number of births.
     * @return the lion's maximum number of births.
     */
    public int get_MAX_LITTER_SIZE(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the lion's maximum food level.
     * @return the lion's maximum food level.
     */
    public int get_MAX_FOOD_LEVEL(){
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the food value lion provide.
     * @return the food value lion provide.
     */
    public int get_FOOD_VALUE(){
        return FOOD_VALUE;
    }
    
    /**
     * Return the list of prey of lion.
     * @return the list of prey of lion.
     */
    public List<Class> get_PREY_LIST(){
        return PREY_LIST;
    }
    
    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    public void giveBirth(List<Animal> newLions)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        boolean isBirthMale =  rand.nextBoolean(); //assign a random gender
        for(int b = 0; b < births && free.size() > 0; b++) {
         
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc, isBirthMale,false);
            newLions.add(young);
            
        }
    }
}