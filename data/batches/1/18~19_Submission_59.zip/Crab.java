import java.util.Random;
/**
 * A simple model of a crab.
 * Crabs age, move, breed, eat Phytoplanktons and 
 * Conifers and die.
 *
 * @version 2019.02.22 
 */
public class Crab extends Animal
{
    // instance variables - replace the example below with your own
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Constructor for objects of class Crab
     */
    public Crab(boolean randomAge, Field field, Field trapField,Location location, Environment environment, boolean infected)
    {
        super(field,trapField,location, environment,  infected);
        setMaxAge(85);
        setBreedingAge(10);
        setMaxLitterSize(12);
        setMaxBreedingAge(80);
        setBreedingProbability(0.1);
        setNocturnal(true);
        setTerrestrial(true);
        setAge(0);
        addFood(Phytoplankton.class);
        addFood(Conifer.class);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getNutritionValue(Phytoplankton.class)));
        }
        else {
            setAge(0);
            setFoodLevel(getNutritionValue(Phytoplankton.class));
        }
    }

    /**
    * Implementation of the abstract method from Organism
    *  @return A new Crab
    */
    public Animal getNewOrganism(Field field, Location location, Environment environment, boolean infected){
        return new Crab(false, field, getTrapField(), location, environment, infected);
    }
    
}
