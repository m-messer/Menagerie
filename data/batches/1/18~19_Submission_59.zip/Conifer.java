import java.util.List;
import java.util.Random;

/**
 * A simple model of a Conifer.
 * Conifers age, breed, and die.
 *
 * @version 2019.02.22 
 */
public class Conifer extends Plant
{
    private static final Random rand = Randomizer.getRandom();

    /** 
     * Create a new Conifer at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment of the field.
     * @param infected The Conifer's health. True if the animal is infected.
     */
    public Conifer(Field field, Location location, Environment environment, boolean infected)
    {
        super(field,location, environment, infected);
        setMaxAge(65);
        setBreedingAge(5);
        setMaxLitterSize(9);
        setAge(rand.nextInt(getMaxAge()) );
        setBreedingProbability(0.05);
        setTerrestrial(true);
        setMaxBreedingAge(60);
    }
    
    /**
     * Implementation of the abstract method in Organism
     * @return A new Conifer
     */ 
     public Organism getNewOrganism(Field field, Location location, Environment environment, boolean infected){
        return new Conifer( field, location,environment, infected);
    }
    
    
}
