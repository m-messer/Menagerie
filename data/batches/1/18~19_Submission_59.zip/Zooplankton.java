import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Zooplankton.
 * Zooplanktones age, move, eat Phytoplanktons, and die.
 *
 * @version 2019.02.22 
 */
public class Zooplankton extends Animal
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Zooplankton. A Zooplankton can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Zooplankton will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zooplankton(boolean randomAge,Field field,Field trapField, Location location, Environment environment, boolean infected)
    {
        super(field,trapField,location, environment,  infected);
        setMaxAge(100);
        setBreedingAge(10);
        setMaxLitterSize(12);
        setMaxBreedingAge(95);
        setBreedingProbability(0.35);
        setAge(0);
        addFood(Phytoplankton.class);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getNutritionValue(Phytoplankton.class)));
        }
        else {
            setAge(0);
            setFoodLevel(getNutritionValue(Phytoplankton.class));
        }
    }
   
   /**
     * Implementation of the abstract method in Organism
     * @return A new Zooplankton
     */
    public Animal getNewOrganism(Field field, Location location, Environment environment, boolean infected){
        return new Zooplankton(false, field, getTrapField(), location, environment, infected);
    }
    
}
