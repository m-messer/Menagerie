import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a worm.
 * Worms age, move, breed, eat Phytoplanktons and die.
 *
 * @version 2019.02.22 
 */
public class Worm extends Animal
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new worm. A worm may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the worm will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment of the field.
     * @param infected The worm's health. True if the worm is infected.
     */
    public Worm(boolean randomAge,Field field,Field trapField, Location location, Environment environment, boolean infected)
    {
        super(field, trapField,location, environment, infected);
        setMaxAge(70);
        setBreedingAge(10);
        setMaxLitterSize(7);
        setMaxBreedingAge(65);
        setBreedingProbability(0.3);
        setNocturnal(true);
        setAge(0);
        addFood(Phytoplankton.class);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getNutritionValue(Phytoplankton.class)));
        }
        else {
            setAge(0);
            setFoodLevel(getNutritionValue(Phytoplankton.class));
        }
    }
    
    
    /**
     * Implementation of the abstract method in Organism
     * @return A new Worm
     */
    public Animal getNewOrganism(Field field, Location location, Environment environment, boolean infected){
        return new Worm(false, field,  getTrapField(),location, environment, infected);
    }
    
    
}

