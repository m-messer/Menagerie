
/**
 * A simple model of a Trap. 
 *
 * @version 2019.02.22
 */
public class Trap
{
    // instance variables
    private Field field;
    private Location location;

    /**
     * Constructor for objects of class Trap
     */
    public Trap(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }

   /**
     * Place the trap at the new location in the given field.
     * @param newLocation The traps's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
     /**
     * @return The trap's field.
     */
    public Field getField(){
        return field;
    }
    
      /**
     * @return The trap's location.
     */
    public Location getLocation(){
        return location;
    }
}
