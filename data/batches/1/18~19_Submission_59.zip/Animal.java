import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.22
 */
public abstract class Animal extends Organism
{
    //The field containing traps.
    private Field trapField;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
  
    // Individual characteristics (instance fields).
    
    // The animal's foodLevel. It's the number of steps without eating before the animal dies.
    private int foodLevel;
    //The gender of the animal. True if it's a female.
    private boolean female;
    //What the animal does at night. True if it stays awake.
    private boolean nocturnal;
    //The list of animal/plant the animal can eat.
    private ArrayList<Class> food;

    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment of the field.
     * @param infected The animal's health. True if the animal is infected.
     */
    public Animal(Field field, Field trapField,Location location, Environment environment, boolean infected)
    {
        super(field,location, environment, infected);
        this.trapField = trapField;
        food = new ArrayList<>();
        setInfected(infected);
        if(rand.nextDouble()<=0.5)
        {
            female=true;
        }
        else female=false;
    }
    
     /**
     * This is what the animal does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newAnimals A list to return newly born animals .
     */
    public void act(List<Organism> newAnimals)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive() && (getEnvironment().getTime() || getNocturnal())) {
            giveBirth(newAnimals);            
            // Try to move into a free location.
            Location newLocation = findFood();
            
             if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                 if((getField().isLand(newLocation) && getTerrestrial()) 
                 ||!getField().isLand(newLocation)) setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            if(isTrap()) setDead();
        }
        
    }
    
    /**
     * Sets the food level of an animal
     * @param level the value to be set
     */
    public void setFoodLevel(int level){
        foodLevel = level;
    }
    
     /**
     * Returns the food level of an animal
     * @return current food level of an animal
     */
    public int getFoodLevel(){
        return foodLevel ;
    }
    
     /**
     * @return the list of animals and plants that an animal can eat
     */
    public ArrayList<Class> getFoods()
    {
        return food;
    }
    
     /**
     * Sets the food of an animal 
     * @param food the name of animal or plant to be set as its food
     */
    public void addFood(Class food)
    {
        this.food.add(food);
    }
    

     /**
     * Returns the gender of an animal
     * @return gender of the animal
     */
    public boolean getGender()
    {
        return female;
    }
   
     /**
     * Checks if the animal is nocturnal
     * @return true if the animal is nocturnal
     */
    public boolean getNocturnal(){
        return nocturnal;
    }
    
    /**
     * Checks if the animal is nocturnal
     * @return true if the animal is nocturnal
     */
    public void setNocturnal(boolean nocturnal){
        this.nocturnal=nocturnal;
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(getEnvironment().getWeather().equals("Cold")) foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
   
    /**
    *Looks around the animal's location to find something it can eat.
    * @return the location of the animal's food.
    **/
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if(foodLevel < 10){
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                for(Class animals:this.getFoods()){
                    
                    if(animal instanceof Organism){
                        if(animal.getClass().equals(animals)) {
                            Organism ani = (Organism) animal;
                            if(ani.isAlive()) { 
                                ani.setDead();
                                foodLevel = ani.getNutritionValue(animals);
                                return where;
                            }
                        }
                    }
                }   
            }
        }
        return null;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
     
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal ani = (Animal) animal;
                if(ani.getClass().equals(this.getClass()) && this.getGender()!=ani.getGender() 
                    && canBreed() && rand.nextDouble() <= getBreedingProbability()  ) { 
                    births = rand.nextInt(getMaxLitterSize()) + 1;
                    if(this.getInfected()) ani.setInfected(true);
                }
            }
        }
        return births;
    }

     /**
     * Checks if the current location is a trap.
     * @return true if the current location is a trap.
     */
    public boolean isTrap(){
        if(this.getLocation() != null){
            Object trap = trapField.getObjectAt(getLocation());
            if(trap!= null){
                if(trap instanceof Trap) return true;
            }
        }
        return false;
    }
    
    /**
     * returns the trap field
     * @return the trapfield
     */
    public Field getTrapField(){
         return trapField;
    }
    
}
