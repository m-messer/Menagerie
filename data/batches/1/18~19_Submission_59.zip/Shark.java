import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a shark.
 * Sharks age, move, breed, eat Seal and Fish, and die.
 *
 * @version 2019.02.22 
 */
public class Shark extends Animal
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a shark. A shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment of the field.
     * @param infected The shark's health. True if the shark is infected.
     */
    public Shark(boolean randomAge,Field field,Field trapField, Location location, Environment environment, boolean infected)
    {
        super(field,trapField,location, environment, infected);
        setMaxAge(70);
        setBreedingAge(10);
        setMaxLitterSize(6);
        setMaxBreedingAge(65);
        setBreedingProbability(0.17);
        setNocturnal(true);
        setTerrestrial(false);
        setAge(0);
        
        addFood(Seal.class);
        addFood(Fish.class);
        
        
        
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getNutritionValue(Seal.class)));
        }
        else {
            setAge(0);
           setFoodLevel(getNutritionValue(Seal.class));
        }
    }
    
    /**
     * Implementation of the abstract method in Organism
     * @return A new Shark
     */
    public Animal getNewOrganism(Field field, Location location, Environment environment, boolean infected){
        return new Shark(false, field,  getTrapField(),location, environment, infected);
    }
}
