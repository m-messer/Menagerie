import java.util.List;
import java.util.Random;
/**
 * A simple model of a Phytoplankton.
 * Phytoplanktons age, breed, and die.
 *
 * @version 2019.02.22 
 */
public class Phytoplankton extends Plant
{
    private static final Random rand = Randomizer.getRandom();

    /** 
     * Create a new Phytoplankton at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment of the field.
     * @param infected The animal's health. True if the animal is infected.
     */
    public Phytoplankton(Field field, Location location, Environment environment, boolean infected)
    {
        super(field,location, environment, infected);
        setMaxAge(65);
        setBreedingAge(5);
        setMaxLitterSize(9);
        setAge(rand.nextInt(getMaxAge()) );
        setBreedingProbability(0.08);
        setTerrestrial(false);
        setMaxBreedingAge(60);
    }
    
    /**
    * Implementation of the abstract method from Organism
    *  @return A new Phytoplankton
    */
     public Organism getNewOrganism(Field field, Location location, Environment environment, boolean infected){
        return new Phytoplankton( field, location,environment, infected);
    }
    
    
}
