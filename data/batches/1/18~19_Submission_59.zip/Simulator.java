import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing zooplanktons and seales.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a seal will be created in any given grid position in the sea.
    private static final double SEA_SEAL_CREATION_PROBABILITY = 0.03;
    // The probability that a seal will be created in any given grid position on land.
    private static final double LAND_SEAL_CREATION_PROBABILITY = 0.20;
    // The probability that a zooplankton will be created in any given grid position.
    private static final double ZOOPLANKTON_CREATION_PROBABILITY = 0.04;    
    // The probability that a fish will be created in any given grid position.
    private static final double FISH_CREATION_PROBABILITY = 0.04;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.02;      
    // The probability that a phytoplankton will be created in any given grid position.
    private static final double PHYTOPLANKTON_CREATION_PROBABILITY = 0.06;  
    // The probability that a worm will be created in any given grid position.
    private static final double WORM_CREATION_PROBABILITY = 0.02;
    // The probability that a crab will be created in any given grid position in the sea.
    private static final double SEA_CRAB_CREATION_PROBABILITY = 0.03;
    // The probability that a crab will be created in any given grid position on land.
    private static final double LAND_CRAB_CREATION_PROBABILITY = 0.26;
    // The probability that a conifer will be created in any given grid position.
    private static final double CONIFER_CREATION_PROBABILITY = 0.04;
    // The probability that a trap will be created in any given grid position.
    private static final double TRAP_CREATION_PROBABILITY = 0.004;
    
   
    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current state of the field containing traps.
    private Field trapField;
     //The current environment of the field.
    private Environment environment;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);
        trapField = new Field(depth, width);
        environment = new Environment();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zooplankton.class, new Color(255, 204, 153));
        view.setColor(Seal.class, new Color(224, 224, 224));
        view.setColor(Fish.class,new Color(255, 153, 255));
        view.setColor(Shark.class, Color.BLACK);
        view.setColor(Phytoplankton.class, new Color(153, 255,153));
        view.setColor(Worm.class, new Color(255, 153, 153));
        view.setColor(Crab.class, new Color(153, 204,255));
        view.setColor(Conifer.class, Color.YELLOW);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(50);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public void simulateOneStep()
    {
        step++;
        environment.updateTime();
        // Provide space for newborn organisms.
        
        List<Organism> newOrganisms = new ArrayList<>();        
   
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms);
            if(! organism.isAlive()) {
                it.remove();
            }
        }
        
        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganisms);
        Random rand = Randomizer.getRandom();
                 
        view.showStatus(step, environment.getTime(),environment.getWeather(), field, trapField);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        environment.resetTime();
        
        // Show the starting state in the view.
        view.showStatus(step,environment.getTime(),environment.getWeather(),  field, trapField);
    }
    
    /**
     * Randomly populate the field with seals, crabs, conifers, sharks,worms, fish and zooplanktons.
     * It also places some traps in the trapField.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
         trapField.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if( col > (int)field.getWidth()*0.8){
                    if(rand.nextDouble() <= LAND_SEAL_CREATION_PROBABILITY) {
                        Seal seal = new Seal(false, field,trapField, location, environment, false);
                        organisms.add(seal);
                    }
                    else if(rand.nextDouble() <= LAND_CRAB_CREATION_PROBABILITY) {
                        Crab crab = new Crab(true, field,trapField, location, environment, false);
                        organisms.add(crab);
                    }
                    else if(rand.nextDouble() <= CONIFER_CREATION_PROBABILITY){
                        Conifer conifer= new Conifer(field,location, environment, false);
                        organisms.add(conifer);
                    }
                }
                else{
                    if(rand.nextDouble() <= SEA_SEAL_CREATION_PROBABILITY) {
                        Seal seal = new Seal(true, field,trapField, location, environment, false);
                        organisms.add(seal);
                    
                    }
                    else if(rand.nextDouble() <= SEA_CRAB_CREATION_PROBABILITY) {
                        Crab crab = new Crab(true, field, trapField,location, environment, false);
                        organisms.add(crab);
                    }
                    else if(rand.nextDouble() <= ZOOPLANKTON_CREATION_PROBABILITY) {
                        Zooplankton zooplankton = new Zooplankton(true, field,trapField, location, environment, false);
                        organisms.add(zooplankton);
                    }
                    else if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                        Fish fish = new Fish(true, field, trapField,location, environment, false);
                        organisms.add(fish);
                    }
                    else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                        Shark shark = new Shark(true, field,trapField, location, environment, false);
                   
                        organisms.add(shark);
                    }
                    else if(rand.nextDouble() <= PHYTOPLANKTON_CREATION_PROBABILITY){
                        Phytoplankton phytoplankton= new Phytoplankton(field, location, environment, false);
                        organisms.add(phytoplankton);
                    }
                    else if(rand.nextDouble() <= WORM_CREATION_PROBABILITY){
                        Worm worm= new Worm(true, field, trapField, location, environment, false);
                        organisms.add(worm);
                    }
                    else if( rand.nextDouble() <= TRAP_CREATION_PROBABILITY) {
                        Trap trap = new Trap(trapField, location);
                   }
                }
             }
                // else leave the location empty.
        }
    }
    

    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
