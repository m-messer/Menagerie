import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of plants.
 *
 * @version 2019.02.22
 */
public abstract class Plant extends Organism
{

    private static final Random rand = Randomizer.getRandom();
    /** 
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location, Environment environment, boolean infected)
    {
        super(field,location, environment, infected);
        setMaxAge(65);
        setBreedingAge(5);
        setMaxLitterSize(9);
        setAge(rand.nextInt(getMaxAge()) );
        setMaxBreedingAge(60);
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

     /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     */
     public void act(List<Organism> newPlants){
        incrementAge();
        
        if(isAlive() && getEnvironment().getTime() ) {
            giveBirth(newPlants);            
            // Try to move into a free location.
           
        }
    }
    
     public abstract Organism getNewOrganism(Field field, Location location, Environment environment, boolean infected);
    }
    
