import java.util.List;
import java.util.HashMap;
import java.util.Random;
/**
 * A class representing shared characteristics of organisms.
 *
 * @version 2019.02.22
 */
public abstract class Organism
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Whether the organisms is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    private Environment environment;

    // The age after which an organism can breed.
    private  int BREEDING_AGE;
    // The age to which an organism can live.
    private int MAX_AGE;
    // The maximum number of births.
    private int MAX_LITTER_SIZE;
    // The maximum breeding age.
    private int MAX_BREEDING_AGE;
    // The likelihood of the organism breeding.
    private double breedingProbability;
    //The animal's ability to be on land. 
    private boolean beOnLand;
   
    private HashMap<Class, Integer> nutritionValues;
    
    // Individual characteristics (instance fields).
    
    // The organism's age.
    private int age;
    //The infection state of the organism.
    private boolean infected;
    
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment of the field.
     * @param infected True if the organism is infected. 
     */
    protected Organism(Field field, Location location, Environment environment, boolean infected)
    {
        alive = true;
        this.field = field;
        this.environment = environment;
        setLocation(location);
        nutritionValues = new HashMap<Class, Integer>();
        setNutritionValues();
    }
    
     /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganism A list to receive newly born organism.
     */
    abstract protected void act(List<Organism> newOrganism);
    
    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * @return the age of the organism.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Changes the age of the organism.
     * @param age The new age of the organism.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * @return the breeding age of the organism.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Changes the breeding age of the organism.
     * @param age The new breeding age of the organism.
     */
    protected void setBreedingAge(int age)
    {
        BREEDING_AGE = age;
    }
    
    /**
     * @return the maximum breeding age of the organism.
     */
    protected int getMaxBreedingAge()
    {
        return MAX_BREEDING_AGE;
    }
    
    /**
     * Changes the maximum breeding age of the organism.
     * @param age The new maximum breeding age of the organism.
     */
    protected void setMaxBreedingAge(int age)
    {
        MAX_BREEDING_AGE = age;
    }
    
    /**
    * Sets the likelihood of the organism breeding.
    * @param probability The new probability of breeding.
    */
    public void setBreedingProbability(double probability){
        breedingProbability = probability;
    }
    
    /**
    * @return The likelihood of the organism breeding.
    */
    public double getBreedingProbability(){
        return breedingProbability ;
    }
    
    /**
     * @return the maximum age of the organism.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Changes the maximum age of the organism.
     * @param age The new maximum age of the organism.
     */
    protected void setMaxAge(int age)
    {
        MAX_AGE = age;
    }
    
    /**
     * @return the maximum number of births.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Changes the maximum number of births.
     * @param age The new maximum number of births.
     */
    protected void setMaxLitterSize(int size)
    {
        MAX_LITTER_SIZE = size;
    }
    
    /**
     * @return true if the animal can breed.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE && age <= MAX_BREEDING_AGE;
    }
    
    /**
     * @return True if the animal is infected.
     */
    protected boolean getInfected()
    {
        return infected;
    }
    
    /**
     * Changes the value of infected.
     * @param infected the new value of infected. 
     */
    protected void setInfected(boolean infected)
    {
        this.infected = infected;
    }
    
    /**
     * Checks if the animal can be on land.
     * @return true if the animal can be on land.
     */
    public boolean getTerrestrial(){
        return beOnLand;
    }
    
     /**
     * Changes the value of beOnLand;
     */
    public void setTerrestrial(boolean beOnLand){
        this.beOnLand =  beOnLand;
    }
    
    /**
     * Increments the age of the organism, it increments twice if the organism is infected
     * and it increments 3 time if the weather is "Hurricane" and the organism is a Plant.
     */
    protected void incrementAge()
    {
        age++;
        if(getInfected()) age++;
        if(environment.getWeather().equals("Hurricane") && this.getClass().equals(Plant.class)) age += 2;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Sets the nutrition values for each class. 
     */
    private void setNutritionValues(){
        nutritionValues.put(Seal.class, 23);
        nutritionValues.put(Fish.class, 20);
        nutritionValues.put(Phytoplankton.class, 25);
        nutritionValues.put(Zooplankton.class, 18);
        nutritionValues.put(Shark.class, 15);
        nutritionValues.put(Worm.class, 19);
        nutritionValues.put(Crab.class, 20);
        nutritionValues.put(Conifer.class, 17);
    }
    
    /**
     * @return the HashMap containing the nutrion values of all of the organisms.
     */
    protected HashMap<Class, Integer> getNutritionValues(){
        return nutritionValues;
    }
    
    /**
     * @return the nutrition value of the current organism.
     */
    protected int getNutritionValue(Class key){
        return nutritionValues.get(key);
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected abstract int breed();
    
    /**
     * @param field The field that will be occupied by the new organism.
     * @param location The location that will be occupied by the new organism.
     * @param environment The environment of the field.
     * @param infected The animal's health. True if the animal is infected.
     */
    protected abstract Organism getNewOrganism(Field field, Location location, Environment environment, boolean infected);
    
    /**
     * Check whether or not this organism is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrganisms A list to return newly born organisms.
     */
    protected void giveBirth(List<Organism> newOrganisms)
    {
        // New organisms are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        Environment environment = getEnvironment();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Organism young ;
            if((getField().isLand(loc) && getTerrestrial())  ||(!getField().isLand(loc) && !this.getClass().equals(Conifer.class))) {
                if(rand.nextDouble()<=0.0001)
                {
                     young = getNewOrganism(field, loc, environment, true);
                }
                else {
                     young = getNewOrganism(field, loc, environment, infected);
                }
                newOrganisms.add(young);
                
            }
        }
    }
    
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * @return The organism's environment.
     */
    protected Environment getEnvironment()
    {
        return environment;
    }
}
