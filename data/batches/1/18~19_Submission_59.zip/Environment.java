import java.util.Random;
/**
 * Sets the time and the weather of the simulation.
 *
 * @version 2019.02.22 
 */
public class Environment
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    private double time = 0;
    private boolean day;
    private int daysCounter=0;
    private String weather = "Warm";
    
    /**
     * Constructor for objects of class Environment
     */
    public Environment()
    {
    }

    /**
     * Updates the time and day
     */
    public void updateTime(){
        time = (time +1)%24 ;
        if(time==0) daysCounter = (daysCounter+1)%25;
        if(time<21&&time>5)
        day=true;
        else day = false;
        if(daysCounter% 2 == 0)
        updateWeather();
    }
    
    /**
     * updates the weather
     */
    public void updateWeather(){
        double check = rand.nextDouble();
        if(check<=0.45)
        weather="Warm";
        else if(check <= 0.9) 
        weather="Cold";
        else 
        weather="Hurricane";
    }
    
    /**
     * @return the current weather
     */
    public String getWeather(){
        return weather;
    }
    
    /**
     * resets the time to 0
     */
    public void resetTime(){
        time =0;
        day = false;
        daysCounter=0;
        weather = "Warm";
    }
    
    /**
     * returns the current time.
     */
    public boolean getTime(){
        return day;
    }
}
