import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a fish.
 * Fishs age, move, breed, eat phytoplanktons, 
 * worms and zooplanktons, and die.
 *
 * @version 2019.02.22 
 */
public class Fish extends Animal
{
    // Characteristics shared by all fishs (class variables).

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new fish. A fish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the fish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment of the field.
     * @param infected The animal's health. True if the animal is infected.
     */
    public Fish(boolean randomAge,Field field,Field trapField, Location location, Environment environment, boolean infected)
    {
        super(field, trapField,location, environment, infected);
        setMaxAge(70);
        setBreedingAge(10);
        setMaxLitterSize(8);
        setMaxBreedingAge(65);
        setBreedingProbability(0.15);
        setNocturnal(true);
        setTerrestrial(false);
        setAge(0);
        addFood(Phytoplankton.class);
        addFood(Zooplankton.class);
        addFood(Worm.class);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getNutritionValue(Zooplankton.class)));
        }
        else {
            setAge(0);
            setFoodLevel(getNutritionValue(Zooplankton.class));
        }
    }
    
    /**
     * Implementation of the abstract method in Organism
     * @return A new Fish
     */
    public Animal getNewOrganism(Field field, Location location, Environment environment, boolean infected){
        return new Fish(false, field,  getTrapField(),location, environment, infected);
    }
}
