import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * The weather class controls the weather in the simulation
 * there are 4 different weather conditions which have different effects on the animals
 *
 * @version 1
 */
public class Weather
{
    // instance variables 
    private int x;
    private String currentWeather;
    private List<String> weathers;
    
    /**
     * Constructor for objects of class Weather
     * initialises the currentWeather list and adds the different weather conditions to it
     */
    public Weather()
    {
        currentWeather= "sunny";
        weathers = new ArrayList<>();
        weathers.add("sun");
        weathers.add("rain");
        weathers.add("wind");
        weathers.add("fog");
    }
    
    /**
     * changes the weather in the simulation
     * uses a randomiser to select the weather from the currentWeather list
     * 
     */
    public void changeWeather(){
        Random rand;
        rand= Randomizer.getRandom();
        int random = rand.nextInt(4);
        currentWeather = weathers.get(random);
    }
    
    /**
     * returns the current weather in the simulation
     * @return currentWeather returns the current weather in the simulation
     */
    public String getCurrentWeather(){
        return currentWeather;
    }

}
