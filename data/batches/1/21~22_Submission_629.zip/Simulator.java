import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 100;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a fox will be created in any given grid position.
    private static final double PREDATOR_CREATION_PROBABILITY = 0.05;
    // The probability that a rabbit will be created in any given grid position.
    private static final double PREY_CREATION_PROBABILITY = 0.5; 
    // The probability that a small plant will be created in any given grid position.
    private static final double SMALL_PLANT_CREATION_PROBABILITY = 0.001;
    // The probability that a Tree will be created in any given grid position.
    private static final double TREE_CREATION_PROBABILITY = 0.00006;
    

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field
    private List<Plant> plants;
    
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // object of time class.
    private Time time = new Time();
    //object of the weather class
    private Weather weather = new Weather();
    
    //current weather in the simulation in the form of a string 
    private String currentWeather;

    // current time in string formate.
    private String currentTime;
    //The amount of steps per day
    private int stepsPerDay = time.minutesInDay();

    // A graphical view of the simulation.
    private SimulatorView view;
    
    //colors for all the animals and plants in the simulation
    Color giants = new Color(84,70, 50);
    Color goblins = new Color(113, 150, 44);
    Color trees = new Color(67, 149, 65);
    Color dragon = new Color(117, 20, 12);
    Color pixies = new Color(237, 117, 248);
    Color elves = new Color(255, 254, 209);
    Color fairies = new Color(188, 67, 149);
    Color mushrooms = new Color(255, 0, 0);
    
    

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Pixie.class, pixies);
        view.setColor(Elf.class, elves);
        view.setColor(Dragon.class, dragon);
        view.setColor(Goblin.class, goblins);
        view.setColor(Giant.class, giants);
        view.setColor(Fairy.class, fairies);
        view.setColor(Tree.class, trees);
        view.setColor(Mushroom.class, mushrooms);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    public void simulateDay(){
        simulate(stepsPerDay);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        //increase the step and time
        step++;
        time.incrimentMinutes();
        //return the current time and assign it to a variable
        currentTime = time.getTime();
        //change the color of the background based on the time of day
        view.setBGColor(time.timeOfDay());
        
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        
        if (step%stepsPerDay == 0){
            weather.changeWeather();
            currentWeather = weather.getCurrentWeather();
        }
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(step % stepsPerDay == 0){
                animal.incrementAge();
                animal.changeWeather(weather.getCurrentWeather());
            }
            animal.act(newAnimals, time);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        //List containing all the new plants spawned
        List<Plant> newPlants = new ArrayList<>();
        
        // plants act
        for(Iterator<Plant> it = plants.iterator(); it.hasNext();){
            Plant plant = it.next();
            if(step % stepsPerDay  == 0){
                plant.incrementAge(view);
            }

            if(! plant.isAlive()) {
                it.remove();
            }
        }
        
        //spawn new plants
        spawnPlants(step);
        

        
        // Add the newly born plants and animals to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);

        //update the statistics on the screen
        view.showStatus(step, field, currentTime, currentWeather);
    }



    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        time.resetTime();
        currentTime = time.getTime();
        currentWeather = weather.getCurrentWeather();

        // Show the starting state in the view.
        view.showStatus(step, field, currentTime, currentWeather);
    }

    /**
     * spawn new plants randomly into the field
     */
    private void spawnPlants(int step){
        Random rand;
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++){
                rand  = Randomizer.getRandom();
                if(field.getObjectAt(row,col) == null){
                    double randdouble = rand.nextDouble();
                    if(randdouble < TREE_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Plant plant = new Tree(field, location);
                        plants.add(plant);
                    } 
                    if(rand.nextDouble() <= SMALL_PLANT_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Plant plant = new Mushroom(field, location);
                        plants.add(plant);
                    }
                }
            }
        }
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        Random randSex= Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SMALL_PLANT_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Plant plant = new Tree(field, location);
                        plants.add(plant);
                        view.addToColorMap(plant, mushrooms);
                } 
                else if(rand.nextDouble() <= PREDATOR_CREATION_PROBABILITY) {
                    int predator1 = rand.nextInt(3);
                    boolean predatorSex = randSex.nextBoolean();
                    if(predator1 == 0){
                        Location location = new Location(row, col);
                        Predator predator = new Giant(false, field, location, predatorSex);
                        animals.add(predator);
                    } else if(predator1 == 1){
                        Location location = new Location(row, col);

                        Predator predator = new Dragon(false, field, location, predatorSex);
                        animals.add(predator);
                    } else{
                        Location location = new Location(row, col);
                        Predator predator = new Goblin(false, field, location, predatorSex);
                        animals.add(predator);
                    }
                }
                else if(rand.nextDouble() <= TREE_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Plant plant = new Mushroom(field, location);
                        plants.add(plant);
                }
                else if(rand.nextDouble() <= PREY_CREATION_PROBABILITY) {
                    int prey1 = rand.nextInt(3);
                    boolean preySex = randSex.nextBoolean();
                    if(prey1 == 0){
                        Location location = new Location(row, col);
                        Prey prey = new Elf(false, field, location, preySex);
                        animals.add(prey);
                    } else if(prey1 == 1){
                        Location location = new Location(row, col);
                        Prey prey = new Pixie(false, field, location, preySex);
                        animals.add(prey);
                    } else{
                        Location location = new Location(row, col);
                        Prey prey = new Fairy(false, field, location, preySex);
                        animals.add(prey);
                    }
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}