import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.awt.Color;

/**
 * A simple model of a predator.
 * Predator's age, move, eat rabbits, and die.
 * A child class of animal
 *
 * @version 2016.02.29 (2)
 */ 
public abstract class Predator extends Animal
{
    // Characteristics shared by all predators (class variables).
    // The food value of a single prey. In effect, this is the
    // number of steps a predator can go before it has to eat again.
    protected int PREY_FOOD_VALUE;
    //is the predator asleep
    protected boolean isAsleep;
    // A shared random number generator to control breeding.
    protected Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The predator's age.
    protected int age;
    // The predator's food level, which is increased by eating prey.
    protected int foodLevel;

    protected Color colour; 

    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(Field field, Location location, boolean sex)
    {
        super(field, location, sex);
    }

    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newPredator A list to return newly born foxes.
     */
    public void act(List<Animal> newPredator, Time time)
    {
        toggleAsleep(time);
        if (!isAsleep){
            incrementHunger();
            if(isAlive()){
                giveBirth(newPredator);   
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    this.setDead();
                }
                Disease(rand.nextDouble());
            }
        }
    }

    abstract public void toggleAsleep(Time time);

    /**
     * Increase the age. This could result in the predator's death.
     */
    public void incrementAge()
    {
        age = age+1;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this predator more hungry. This could result in the predator's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }


    /**
     * Look for prey adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel += PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPredator A list to return newly born foxes.
     */
    public abstract void giveBirth(List<Animal> newPredator);

    
    /**
     * returns the color of the predator
     * @return color the color object of the predator
     */

    public Color getColor(){
        return colour;
    }
}