import java.awt.Color;
import java.util.List;

/**
 * A simple model fo a Giant
 * Giants can eat, move breed and die
 * They eat prey
 * A child class of Predator
 * 
 * @version 1
 */
public class Giant extends Predator
{

    /**
     * constructor for the giant class
     * @param randomAge determines if a giant is spawned with a random age or with age 0
     * @param field, the field the giant is spawned in
     * @param location, the location of giant
     * @param sex, the sex of the giant
     */
    public Giant(boolean randomAge, Field field, Location location, boolean sex){
        
        super(field, location, sex);
        
        og_BREEDING_AGE = 8;
        og_MAX_AGE = 20;
        og_BREEDING_PROBABILITY = 0.04;
        og_MAX_LITTER_SIZE = 1;
        PREY_FOOD_VALUE = 6;
        age = 0;
        isAsleep = false;
        colour = Color.orange;
        foodLevel = 60;
        Species = "Giant";
        this.setOriginal();
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        
    }

    public Color getColor(){
        return colour;
    }

    /**
     * Check whether or not this Giant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGiants A list to return newly born giants.
     */
    public void giveBirth(List<Animal> newGiants){
        // New giants are born into adjacent locations.
        // Get a list of adjacent free locations.
        //
        Field field = getField();
        Location location = getLocation();
        Object foundAnimal = null;
        boolean breedable = false;;
        
        List <Animal> foundAnimals = field.getAnimalAt(location);
        
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        for(int i = 0; i<foundAnimals.size(); i++){
            if(foundAnimals.get(i).getSpecies().equals(this.getSpecies()) && foundAnimals.get(i).getSex() != this.getSex()){
                breedable = true;
                break;
            }
        }
        if(breedable){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean sex = rand.nextBoolean();
                Predator young = new Giant(false, field, loc, sex);
                newGiants.add(young);
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            //System.out.println(MAX_LITTER_SIZE);
            births = rand.nextInt(MAX_LITTER_SIZE+ 1) +1;
        }
        return births;
    }

    /**
     * A giant can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    
    /**
     * change the giant's characteristics based on time of day
     */
    public void setNight(){
        BREEDING_PROBABILITY = 0.4;
        MAX_LITTER_SIZE = 4;
        PREY_FOOD_VALUE = 8;
    }
    
    /**
     * change the giant's characteristics based on time of day
     */
    public void setDay(){
        BREEDING_PROBABILITY = 0.3;
        MAX_LITTER_SIZE = 3;
        PREY_FOOD_VALUE = 8;
    }
    
    /** 
     * toggles the sleep state of the rabbit
     * @param time, the time of day
     */
    public void toggleAsleep(Time time){
        if (time.timeOfDay()){
            isAsleep = false;
        } else {
            isAsleep = true;
        }
    }
}