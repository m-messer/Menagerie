/**
 * Time class control the time a time of day in the simluation
 * the smallest unit incremented is minutes. 
 * the class calculates the number of steps required to complete 1 day and night cycle
 *
 * @version (a version number or a date)
 */
public class Time
{
    private int minutes;
    private int hours;
    private int days;
    private boolean isNight;
    private int minuteStep;
    
    /**
     * contructor for the time class
     * initialises minutes hours and days to 0
     * initialises inNight to true
     * intialises the minuteStep to 30
     * calls the incrimentMinutes method
     */
    public Time(){
        minutes = 0;
        hours = 0;
        days = 0;
        minuteStep= 30;
        isNight = true;
        incrimentMinutes();
    }
    
    /**
     * increments the number of days passed in the simulation
     */
    public void incrimentDays(){
        days++;
    }
    
    /**
     * increments the number of hours passed
     * calls he incrementDays() function if 24 hours pass, sets hours to 0
     */
    public void incrimentHours(){
        hours++;
        if(hours >=24){
            hours = 0;
            incrimentDays();
        }
    }
    
    /**
     * increments the number of minutes passed in the simulation
     * called the incrementhours() method if 60 minutes pass, sets minutes to 0
     */
    public void incrimentMinutes(){
        minutes+=minuteStep;
        if(minutes >= 60){
            minutes = 0;
            incrimentHours();
        }
    }
    
    /**
     * calulates the number of steps required for a day to pass
     * @return temp the number of steps required for a day to pass
     */
    public int minutesInDay(){
        int temp;
        temp = 60/minuteStep;
        temp = temp * 24;
        return temp;
    }
    
    /**
     * returns the current time in string format
     * @return Time, returns the current time in DD:HH:MM format
     */
    public String getTime(){
        String Minutes, Hours, Days;
        if(minutes < 10){
            Minutes = "0"+minutes;
        } else {
            Minutes = ""+minutes;
        }
        
        if(hours < 10){
            Hours = "0"+hours;
        } else {
            Hours = ""+hours;
        }
        if(days < 10){
            Days = "0"+days;
        } else {
            Days = ""+days;
        }
        String Time = Days + " Days " + Hours + ":" + Minutes;
        return Time;
    }
    
    /**
     * returns the current time of day
     * @return isNight returns true if current time is between 10pm and 9am
     */
    public boolean timeOfDay(){
        if(hours < 9 || hours > 22){
            isNight = true;
        } else {
            isNight = false;
        }
        return isNight;
    }
    
    /**
     * resets the minutes hours and days to 0 and sets isNight to true
     */
    public void resetTime(){
        minutes = 0;
        hours = 0;
        days = 0;
        isNight = true;
    }
}