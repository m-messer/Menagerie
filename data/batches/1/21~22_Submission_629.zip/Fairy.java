import java.awt.Color;
import java.util.List;

/**
 * A simple model of a Fairy
 * Fairies age, move, breed, and die.
 * A child class of Prey
 * They eat mushrooms
 *
 * @version 1
 */
public class Fairy extends Prey
{

    private static String species = "Fairy"; 

    /**
     * constructor for the fairy class
     * @param randomAge determines if a squirrel is spawned with a random age or with age 0
     * @param field, the field the fairy is spawned in
     * @param location, the location of squirrel
     * @param sex, the sex of the squirrel
     */
    public Fairy(boolean randomAge, Field field, Location location, boolean sex){
        super(field, location, sex);
        age = 0;
        og_BREEDING_AGE = 0;
        og_MAX_AGE = 100;
        og_BREEDING_PROBABILITY = 0.7;
        og_MAX_LITTER_SIZE = 20;
        isAsleep = false;
        colour = Color.orange;
        Species = "Fairy";
        PLANT_FOOD_VALUE = 10;
        foodLevel = 50;
        this.setOriginal();

        if(randomAge){
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * returns the species  
     */
    public String getSpecies(){
        return Species;
    }
    
    
    public Color getColor(){
        return colour;
    }

    /**
     * Check whether or not this fairy is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFairies A list to return newly born Fairies.
     */
    public void giveBirth(List<Animal> newFairies)
    {
        // New fairies are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        Location location = getLocation();
        Object foundAnimal = null;
        boolean breadable = false;

        List <Animal> foundAnimals = field.getAnimalAt(location);
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        for(int i = 0; i<foundAnimals.size(); i++){
            if(foundAnimals.get(i).getSpecies().equals(this.getSpecies()) && foundAnimals.get(i).getSex() != this.getSex()){
                breadable = true;
            }
        }
        if(breadable){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean sex = rand.nextBoolean();
                Prey young = new Fairy(false, field, loc, sex);
                newFairies.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fairy can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /** 
     * toggles the sleep state of the fairy
     * @param time, the time of day
     */
    public void toggleAsleep(Time time){
        if (time.timeOfDay()){
            isAsleep = true;
        } else {
            isAsleep = false;
        }
    }
}
