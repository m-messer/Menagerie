import java.awt.Color;
import java.util.List;

/**
 * A simple model of a Pixie
 * Pixie age, move, breed, and die.
 * A child class of Prey
 * they eat mushrooms
 *
 * @version 1
 */
public class Pixie extends Prey
{

    private static String species = "Pixie"; 
    
    public Pixie(boolean randomAge, Field field, Location location, boolean sex){
        super(field, location, sex);
        age = 0;
        og_BREEDING_AGE = 0;
        og_MAX_AGE = 100;
        og_BREEDING_PROBABILITY = 0.8;
        og_MAX_LITTER_SIZE = 20;
        isAsleep = false;
        colour = Color.orange;
        Species = "Pixie";
        PLANT_FOOD_VALUE = 10;
        foodLevel = 50;
        this.setOriginal();
        
        if(randomAge){
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * returns the species  
     */
    public String getSpecies(){
        return Species;
    }
    
    public Color getColor(){
        return colour;
    }

    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPixies A list to return newly born rabbits.
     */
    public void giveBirth(List<Animal> newPixies)
    {
        // New pixies are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        Location location = getLocation();
        Object foundAnimal = null;
        boolean breedable = false;

        List <Animal> foundAnimals = field.getAnimalAt(location);
        
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        for(int i = 0; i<foundAnimals.size(); i++){
            if(foundAnimals.get(i).getSpecies().equals(this.getSpecies()) && foundAnimals.get(i).getSex() != this.getSex()){
                breedable = true;
            }
        }
        
        if(breedable){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean sex = rand.nextBoolean();
                Prey young = new Pixie(false, field, loc, sex);
                newPixies.add(young);
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Pixie can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /** 
     * toggles the sleep state of the Pixie
     * @param time, the time of day
     */
    public void toggleAsleep(Time time){
        if (time.timeOfDay()){
            isAsleep = true;
        } else {
            isAsleep = false;
        }
    }
}