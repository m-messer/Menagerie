import java.awt.Color;

/**
 *A simple model of a Mushroom
 * Pixie age and die.
 * they are eaten by prey
 * A child class of Plant
 *
 * @version 1
 */
public class Mushroom extends Plant
{
    // attribute of the mushroom
    private int foodValue;
    private Color color;
    
    /**
     * contructor for the mushroom class
     * @param field The field of the tree
     * @param location The location of the tree
     * randomAge determines whether the tree is given a random age or the age is intialised to 0
     */
    public Mushroom(Field field, Location location){
        super(field, location);
        location.setIsPlant(true);
        randomAge = random.nextBoolean();
        if(randomAge){
           age = random.nextInt(4); 
        } else {
            age = 0;
        }
        
        
        MAX_AGE = 6;
        foodValue = 1;
        
        color = new Color(255, 0, 0);
    }
    
    /**
     * Increase the age. This could result in the mushroom's death.
     * @param view the similator vietw object that the tree is present in
     * changes the color of the small plant as it gets older
     */
    public void incrementAge(SimulatorView view){
        age++;
        
        foodValue++;
        if(age > MAX_AGE) {
            setDead();
        }
        
        this.color = color.darker();
        view.setColor(this, this.color);
    }
    
    
    /**
     * returns the food value of the mushroom
     * @return foodValue returns the food value of the plant.
     */
    public int getPlantFoodValue(){
        return foodValue;
    }
}
