import java.util.List;
import java.util.Random;
import java.awt.Color;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //determines the gender
    protected boolean isFemale;
    protected int BREEDING_AGE;
    protected int MAX_AGE;
    protected double BREEDING_PROBABILITY;
    protected int MAX_LITTER_SIZE;
    protected int og_BREEDING_AGE;
    protected int og_MAX_AGE;
    protected double og_BREEDING_PROBABILITY;
    protected int og_MAX_LITTER_SIZE;
    protected double diseaseProbability;
    protected Random rand = Randomizer.getRandom();
    protected static int counter = 0;
    
    // The rabbit's age.
    protected int age;
    
    protected Color colour;
    
    protected boolean isAsleep;
    
    protected int foodLevel;
    
    // String containing the species of the animal
    protected String Species;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender true if female, false if male
     */
    public Animal(Field field, Location location, boolean sex)
    {
        alive = true;
        isFemale = sex;
        this.field = field;
        diseaseProbability = 0.00001;
        setLocation(location);
        
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, Time time);
    
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    abstract public void incrementAge();
    

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the sex of the animal, used during breeding
     * @return The animal's sex
     */
    protected boolean getSex(){
        return isFemale;
    }
    
    /**
     * returns the species of the animal in string form
     * @return Species returns the species as a string
     */
    public String getSpecies(){
        return Species;
    }
    
    /**
     * changes the attribute of the animal based on the current weather
     * @param weather, the current weather
     */
    public void changeWeather(String weather){
        setOriginal();
        if (weather.equals("sun")){
            MAX_LITTER_SIZE= og_MAX_LITTER_SIZE *3;
        } else if (weather.equals("rain")){
            BREEDING_PROBABILITY= og_BREEDING_PROBABILITY * 2;
        } else if (weather.equals("fog")){
            BREEDING_PROBABILITY= og_BREEDING_PROBABILITY / 2;
        } else {
            MAX_LITTER_SIZE = og_MAX_LITTER_SIZE /2 ;
        }
        }
        
    /**
     * resets all the attributes of the animal to the original values
     */
    protected void setOriginal(){
        MAX_LITTER_SIZE= og_MAX_LITTER_SIZE;
        BREEDING_PROBABILITY= og_BREEDING_PROBABILITY;
        MAX_AGE= og_MAX_AGE;
        BREEDING_AGE = og_BREEDING_AGE;
    }
    
    /**
     * disease methods
     * @param disease, takes in a double to determine if the animal has a disease
     * if double disease is less than the disease probability then the animal is given a disease
     * deathProbability determines if the animal gets a fatal disease
     * if die is less than deathProbability the animal gets a fatal disease and instantly dies
     * else it is crippled
     */
    public void Disease(double disease){
        if(disease < diseaseProbability){
            double deathProbability = 0.001;
            double die = rand.nextDouble();
            counter++;
            
            if(die < deathProbability){
                this.setDead();
            } else{
                this.BREEDING_PROBABILITY = 0;
                this.MAX_AGE = MAX_AGE/2;
            }
        }
    }
    
    /**
     * Returns the color of the animal
     * @return color The color of the animal
     */
    public Color getColor(){
        return colour;
    }
}


