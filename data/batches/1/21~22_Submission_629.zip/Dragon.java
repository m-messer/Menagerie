import java.awt.Color;
import java.util.List;

/**
 * A simple model of a dragon
 * Dragons can move eat die and sleep
 * They eat prey
 * A child class of Predator
 * 
 * @version 1
 */
public class Dragon extends Predator
{
    /**
     * constructor for the hawk class
     * @param randomAge determines if a hawk is spawned with a random age or with age 0
     * @param field, the field the hawk is spawned in
     * @param location, the location of hawk
     * @param sex, the sex of the hawk
     */
    public Dragon(boolean randomAge, Field field, Location location, boolean sex){
        super(field, location, sex);
        og_BREEDING_AGE = 15;
        og_MAX_AGE = 30;
        og_BREEDING_PROBABILITY = 0.04;
        og_MAX_LITTER_SIZE = 1;
        PREY_FOOD_VALUE = 6;
        isAsleep = false;
        age = 0;
        colour = Color.green;
        foodLevel = 60;
        Species = "Dragon";
        this.setOriginal();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * Returns the species of the dragon in the form of a string
     * @return Species the String form of the species
     */
    public String getSpecies(){
        return Species;
    }
    
    /**
     * returns the color object of the species
     * @return scolor the color object of the species 
     */
    public Color getColor(){
        return colour;
    }
    
    /**
     * Check whether or not this dragon is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDragon A list to return newly born dragon.
     */
    public void giveBirth(List<Animal> newDragons){
        // New dragons are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        Location location = getLocation();
        Object foundAnimal = null;
        boolean breedable = false;

        List <Animal> foundAnimals = field.getAnimalAt(location);
        
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        for(int i = 0; i<foundAnimals.size(); i++){
            if(foundAnimals.get(i).getSpecies().equals(this.getSpecies()) && foundAnimals.get(i).getSex() != this.getSex()){
                breedable = true;
            }
        }
        if(breedable){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean sex = rand.nextBoolean();
                Predator young = new Dragon(false, field, loc, sex);
                newDragons.add(young);
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE+1) + 1;
        }
        return births;
    }
    
    /**
     * A dragon can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /** 
     * toggles the sleep state of the rabbit
     * @param time, the time of day
     */
    public void toggleAsleep(Time time){
        if (time.timeOfDay()){
            isAsleep = true;
        } else {
            isAsleep = false;
        }
    }
}