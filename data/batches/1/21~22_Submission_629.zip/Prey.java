import java.util.List;
import java.util.Random;
import java.awt.Color;
import java.util.Iterator;

/**
 * A simple model of a Prey
 * Preys age, move, breed, and die.
 * They eat plants
 * A child class of animal
 *
 * @version 2016.02.29 (2)
 */
public abstract class Prey extends Animal
{
    // Characteristics shared by all Prey (class variables).

    // A shared random number generator to control breeding.
    protected Random rand = Randomizer.getRandom();
    
    //amount of nutrition recieved by eating a plant
    protected int PLANT_FOOD_VALUE;
    

    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param sex The sex of the prey
     */
    public Prey(Field field, Location location, boolean sex)
    {
        super(field, location, sex);
    }
    
    /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will eat, breed or die of old age.
     * @param newPrey A list to return newly born prey.
     * Calls find food and disease methods
     */
    public void act(List<Animal> newPrey, Time time)
    {        
        toggleAsleep(time);
        if (!isAsleep){
            incrementHunger();
            if(isAlive()){
                giveBirth(newPrey);
                
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
                // call the disease method and pass a random double to determine whether the prey will get a disease
                Disease(rand.nextDouble());
            }
        }
    }
    
    abstract public void toggleAsleep(Time time);

    /**
     * Increase the age.
     * This could result in the prey's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this prey more hungry. This could result in the prey's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            //System.out.println("prey dead by hunger");
            setDead();
        }
    }


    /**
     * Look for prey adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
       
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Mushroom) {
                Plant mushroom = (Mushroom) plant;
                if(mushroom.isAlive()) {
                    mushroom.setDead();
                    foodLevel += PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this prey is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    abstract public void giveBirth(List<Animal> newAnimal);
    
}