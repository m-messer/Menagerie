
/**
 * A simple model of a tree
 * Trees are born and die
 * they do not move in the simulation
 * a child of the plant class
 * 
 * @version 1
 */
public class Tree extends Plant
{
    /**
     * contructor for the tree class
     * @param field The field of the tree
     * @param location The location of the tree
     * randomAge determines whether the tree is given a random age or the age is intialised to 0
     */
    public Tree(Field field, Location location){
        super(field, location);
        randomAge = random.nextBoolean();
        if(randomAge){
           age = random.nextInt(40); 
        } else {
            age = 0;
        }
        MAX_AGE = 60;
    }
    
    /**
     * Increase the age. This could result in the tree's death.
     * @param view the similator vietw objec that the tree is present in
     */
    public void incrementAge(SimulatorView view){
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    
}
