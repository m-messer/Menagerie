import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator implements ViewController
{
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;

    // List of actors in the field.
    private List<Actor> actors;
    // The weather present in the simulation.
    private Weather weather;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The milliseconds of delay per simulation step.
    private int delayTime = 0;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Hyena.class, Color.BLUE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Zebra.class, Color.CYAN);
        view.setColor(Giraffe.class, Color.ORANGE);
        view.setColor(Impala.class, Color.YELLOW);
        view.setColor(Leaves.class, new Color(0, 190, 0));
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(delayTime);
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of all actors.
     */
    public void simulateOneStep()
    {
        step++;
        // Enable night for 50 steps per 100.
        if (step % 100 == 1 || step % 100 == 51) {
            Animal.toggleNightBehaviour();
        }

        // Provide space for new actors.
        List<Actor> newActors = new ArrayList<>();
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext();) {
            Actor actor = it.next();
            actor.act(newActors);
         
            if(!actor.isAlive()) {
                it.remove();
            }
        }
               
        // Add the new actors to the main list.
        actors.addAll(newActors);

        view.showStatus(step, field, weather.getWeather());
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        weather = new Weather();
        actors.add(weather);
        PopulationGenerator.populate(field, actors);
        
        // Show the starting state in the view.
        view.showStatus(step, field, weather.getWeather());
    }

    /**
     * Adjust the delay of the simulation.
     * @param millisec The time to wait between steps.
     */
    @Override
    public void setDelay(int millisec)
    {
        delayTime = millisec;
    }

    /**
     * Refresh the view with the latest information from the simulation.
     */
    @Override
    public void refreshView() {
        view.showStatus(step, field);
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
