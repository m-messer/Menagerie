/**
 * A simple model of a lion.
 * Lions age, move, eat giraffes or impalas, and die.
 *
 * @version 2021.02.18
 */
public class Lion extends Predator
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 45;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.75;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    // The food values of a lion's prey. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int IMPALA_FOOD_VALUE = 25;
    private static final int GIRAFFE_FOOD_VALUE = 35;
    private static final int DEFAULT_FOOD_LEVEL = 30;

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Check if prey is a Giraffe or Impala and try to eat them.
     * @param prey The prey to eat.
     * @return true if the prey was eaten.
     */
    @Override
    protected boolean canHunt(Prey prey)
    {
        if (prey.isAlive()) {
            if (prey instanceof Giraffe) {
                prey.setDead();
                increaseFoodLevel(GIRAFFE_FOOD_VALUE);
                return true;
            } else if (prey instanceof Impala) {
                prey.setDead();
                increaseFoodLevel(IMPALA_FOOD_VALUE);
                return true;
            }
        }
        return false;
    }

    /**
     * Produce a new lion.
     * @param loc The location of which the lion is born in.
     * @return The lion that is born.
     */
    @Override
    protected Animal produceNewYoung(Location loc)
    {
        return new Lion(false, getField(), loc);
    }

    /**
     * Gets the food level all new born lions should have.
     * It is also used as the max food level a lion with a random age can have.
     * @return The food level for a new born.
     */
    @Override
    protected int getDefaultFoodLevel()
    {
        return DEFAULT_FOOD_LEVEL;
    }

    /**
     * Return the minimum age for breeding to occur.
     * @return The minimum breeding age.
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the chance of success when attempting to breed.
     * @return The probability of breeding success.
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the maximum number of offspring a lion can produce.
     * @return The maximum number of offspring.
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the maximum age of a lion before it will die.
     * @return The maximum age of a lion.
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
}
