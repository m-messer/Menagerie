import java.util.List;

/**
 * A class that represents shared characteristics of prey
 * in this simulation. Predators are defined as animals that
 * are eaten by any predator.
 *
 * @version 2020.02.22
 */
public abstract class Prey extends Animal
{

    /**
     * Create new prey at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
    }

    /**
     * This is what prey does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born prey.
     */
    @Override
    public void act(List<Actor> newPrey) {
        incrementAge();
        incrementHunger();
        if (isAlive()) {
            giveBirth(newPrey);

            // If the current food level is below their remaining life expectancy,
            // look for food.
            if (getFoodLevel() <= getMaxAge() - getAge()) {
                findFood();
            }
            Location newLocation = getField().freeAdjacentLocation(getLocation());

            if (newLocation != null) {
                setLocation(newLocation);
                attemptInfection();
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     */
    private void findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object plant = field.getObjectAt(where);
            if (plant instanceof Plant && ate((Plant) plant)) {
                return;
            }
        }
    }

    /**
     * Check if the plant can be eaten, and set the appropriate values.
     * @param plant The plant to be eaten.
     * @return true if eaten, false if not.
     */
    protected boolean ate(Plant plant)
    {
        if (plant.isAlive()) {
            if (plant instanceof Leaves) {
                plant.bitten();
                increaseFoodLevel(getPlantFoodValue());
                if(plant.getFoodValue()<=0){
                    plant.setDead();
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Return the amount of energy/food that is attained by eating plants.
     * @return The food value given by plants for this animal.
     */
    protected abstract int getPlantFoodValue();

}
