import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.02.21
 */
public abstract class Animal implements Actor
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The chance that an animal randomly contracts a disease.
    private static final double DISEASE_PROBABILITY = 0.00001;
    // The chance that an animal is infected by a nearby diseased animal.
    private static final double DISEASE_SPREAD_PROBABILITY = 0.035;
    // The maximum steps a diseased animal can make before dying.
    private static final int MAX_DISEASE_STEPS = 16;
    // Whether animals should exhibit night-time behaviour.
    private static boolean isNight = false;
    // Whether animals should exhibit behaviour in fog.
    private static boolean isFoggy = false;

    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's age.
    private int age;
    // The animal's food level, which is increased by eating it's food.
    private int foodLevel;
    // Whether the animal can give birth (i.e. is female).
    private boolean canGiveBirth;
    // The number of steps taken after getting a disease.
    private int diseasedSteps = 0;

    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        if (randomAge) {
            age = getRandom().nextInt(getMaxAge());
            foodLevel = getRandom().nextInt(getDefaultFoodLevel());
        } else {
            age = 0;
            foodLevel = getDefaultFoodLevel();
        }

        canGiveBirth = rand.nextBoolean();
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Gets the food level all new born animals should have.
     * It is also used as the max food level a animal with a random age can have.
     * @return The food level for a new born.
     */
    protected abstract int getDefaultFoodLevel();

    /**
     * Make this animal more hungry. This could result in its death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increase the current food level of the animal.
     * @param foodIncrease The amount to increase the animal's food level by.
     */
    protected void increaseFoodLevel(int foodIncrease)
    {
        foodLevel += foodIncrease;
    }

    /**
     * Gets the current food level of the animal.
     * It is also used as the max food level an animal with a random age can have.
     * @return The food level for a new born.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public abstract void act(List<Actor> newAnimals);

    /**
     * Return the minimum age for breeding to occur.
     * @return The minimum breeding age.
     */
    protected abstract int getBreedingAge();

    /**
     * Return the chance of success when attempting to breed.
     * @return The probability of breeding success.
     */
    protected abstract double getBreedingProbability();

    /**
     * Return the maximum number of offspring an animal can produce.
     * @return The maximum number of offspring.
     */
    protected abstract int getMaxLitterSize();

    /**
     * Check whether the animal is female (and can give birth).
     * @return true if the animal is female.
     */
    protected boolean isFemale()
    {
        return canGiveBirth;
    }

    /**
     * Check before breeding if there is a nearby animal of the same species,
     * are of the opposite gender and over the breeding age.
     * @return true if reproduction conditions are satisfied.
     */
    public boolean canReproduce()
    {
        if (isFemale() && age >= getBreedingAge()) {
            // Get all adjacent cells
            List<Location> surroundings = field.adjacentLocations(location);

            for (Location location : surroundings) {
                Object fieldObject = field.getObjectAt(location);

                // Check if the the adjacent cell has the same type of animal
                if (fieldObject != null && fieldObject.getClass() == this.getClass()) {
                    Animal animal = (Animal) fieldObject;

                    // Check if the animal is male and above min breeding age
                    if (!animal.isFemale() && animal.age >= animal.getBreedingAge()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        if (canReproduce()) {
            // New animals are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                newAnimals.add(produceNewYoung(loc));
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Produce new young from the same species of it's parent.
     * @param location The location of which the offspring is born in.
     * @return The animal that is born.
     */
    protected abstract Animal produceNewYoung(Location location);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Returns whether the animal currently has a disease or not.
     * @return true if it has a disease, false if not.
     */
    public boolean isDiseased()
    {
        return diseasedSteps != 0;
    }

    /**
     * Attempts an infection on the current animal.
     * If already infected, it attempts to infect any adjacent animals.
     */
    protected void attemptInfection()
    {
        // If exceeded maximum steps when diseased, animal dies.
        if (diseasedSteps >= MAX_DISEASE_STEPS) {
            setDead();
            return;
        }

        // If already diseased, try to infect adjacent animals.
        if (isDiseased()) {
            diseasedSteps++;
            List<Location> surroundings = field.adjacentLocations(location);
            for (Location cell : surroundings) {
                Object actor = field.getObjectAt(cell);
                if (actor instanceof Animal && rand.nextDouble() <= DISEASE_SPREAD_PROBABILITY) {
                    ((Animal) actor).diseasedSteps++;
                }
            }
        }

        // Try to randomly infect the current animal.
        // (If already infected, animal will die sooner.)
        if (rand.nextDouble() <= DISEASE_PROBABILITY) {
            diseasedSteps++;
        }
    }

    /**
     * Returns the current age of this animal.
     * @return The age of the animal.
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Returns the maximum age of this animal before it will die.
     * @return The maximum age of this animal.
     */
    protected abstract int getMaxAge();

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Sets the age of the animal.
     * @param age The new age of the animal.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Returns the random generator used to control age, breeding, etc.
     * @return The random number generator.
     */
    protected Random getRandom()
    {
        return rand;
    }

    /**
     * Adjusts the behaviour of all animals to their behaviour at night.
     * Alternate behaviour might not exist in all implementations of animals.
     */
    public static void toggleNightBehaviour()
    {
        isNight = !isNight;
    }

    /**
     * Checks whether it is currently night (and if the animal should exhibit night behaviour).
     * @return true if it is night, false if not.
     */
    protected boolean isNight()
    {
        return isNight;
    }

    /**
     * Adjusts the behaviour of all animals to their behaviour in foggy weather.
     * This behaviour might not exist in all animal implementations.
     */
    public static void setFogBehaviour(boolean isFoggy)
    {
        Animal.isFoggy = isFoggy;
    }

    /**
     * Checks whether the weather is currently foggy (and the animal should exhibit different behaviour).
     * @return true if foggy, false if not.
     */
    protected boolean isFoggy()
    {
        return isFoggy;
    }
}
