import java.util.List;

/**
 * The interface to be extended by any class wishing
 * to participate in the simulation.
 *
 * @version 2021.02.22
 */
public interface Actor
{
    /**
     * Perform the actor's regular behaviour.
     * @param newActors A list for receiving newly created actors.
     */
    void act(List<Actor> newActors);

    /**
     * Is the actor still active?
     * @return true if still active, false if not.
     */
    boolean isAlive();
}
