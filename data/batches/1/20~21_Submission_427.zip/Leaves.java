import java.util.List;
/**
 * A simple model of a leaf.
 * Leaves produce age and die.
 *
 * @version 2021.02.18
 */
public class Leaves extends Plant {

    // Characteristics shared by all leaves (class variables).

    // The age to which a leaf bush can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a leaf bush reproducing.
    private static final double POLLINATION_PROBABILITY = 0.034;
    // The maximum number of new plants that can be made on reproduction.
    private static final int MAX_OFFSPRING_SIZE = 4;

    /**
     * Create a leaf. A leaf can be created as a new born (zero age)
     * or with a random age.
     *
     * @param randomAge If true, the leaf will have random age and food value.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Leaves(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
      /**
     * This is what a predator does most of the time: it hunts for
     * foods. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newPlants A list to return newly born predators.
     */
    @Override
    public void act(List<Actor> newPlants)
    {
        incrementAge();
        if (isAlive()) {
            pollination(newPlants);
        }
    }

    /**
     * Returns the max possible food value of the plant
     * (the number of times it can be eaten before dying).
     * @return The plant's maximum food value.
     */
    @Override
    protected int getMaxFoodValue()
    {
        return 20;
    }

    /**
     * Produce a new plant.
     * @param loc The location of which the plant is made in.
     * @return The plant that is produced.
     */
    @Override
    protected Plant produceNewPlant(Location loc)
    {
    return new Leaves(false, getField(), loc);
    }

    /**
     * Return the chance of success when attempting to reproduce.
     * @return The probability of reproduction success.
     */
    @Override
    protected double getPollinationProbability()
    {
        return POLLINATION_PROBABILITY;
    }

    /**
     * Return the maximum number of offspring a plant can produce.
     * @return The maximum number of offspring.
     */
    @Override
    protected int getMaxOffspring()
    {
        return MAX_OFFSPRING_SIZE;
    }

    /**
     * Returns the maximum age of a plant before it will die.
     * @return The maximum age of a plant.
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
}
