import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import java.awt.event.ItemEvent;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2016.02.29
 */
public class SimulatorView extends JFrame
{
    // Enum to hold different types of visualisations.
    private enum Visualisation { NORMAL, DISEASE }

    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;
    // Color used for objects that are filtered out.
    private static final Color FILTERED_COLOR = Color.LIGHT_GRAY;
    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    // Constants for labels
    private final String STEP_PREFIX = "Step: ";
    private final String WEATHER_PREFIX = "Current weather: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String DELAY_PREFIX = "Delay: ";

    // Swing components for GUI
    private JMenu actorFilterMenu;
    private JLabel stepLabel, population, infoLabel, delayLabel;
    private FieldView fieldView;

    // A functional interface that implements changes in delay value
    private ViewController controller;
    // A map for storing colors for participants in the simulation
    private Map<Class<?>, Color> colors;
    // A map for storing whether the actors are filtered or not.
    private Map<Class<?>, Boolean> visibleActors;
    // A statistics object computing and storing simulation information.
    private FieldStats stats;
    // Holds the current type of visualisation.
    private Visualisation currentVisual = Visualisation.NORMAL;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     * @param controller The controller used to handle UI events.
     */
    public SimulatorView(int height, int width, ViewController controller)
    {
        this.controller = controller;

        stats = new FieldStats();
        colors = new LinkedHashMap<>();
        visibleActors = new HashMap<>();

        setTitle("Habitat Simulation");
        setLocation(100, 50);

        Container root = getContentPane();

        // Add pane to provide padding to the edges of the window.
        JPanel contents = new JPanel(new BorderLayout());
        contents.setBorder(new EmptyBorder(2, 5, 2, 5));
        root.add(contents);

        // Setup the top menu bar.
        JMenuBar menuBar = new JMenuBar();

        // Create the View menu.
        JMenu viewTypeMenu = new JMenu("View");

        // Create the view options (Normal / Disease visualisations).
        JRadioButtonMenuItem normalViewMenu = new JRadioButtonMenuItem("Normal view");
        normalViewMenu.setSelected(true);
        JRadioButtonMenuItem diseaseViewMenu = new JRadioButtonMenuItem("Disease view");
        ButtonGroup btnGroup = new ButtonGroup();
        btnGroup.add(normalViewMenu);
        btnGroup.add(diseaseViewMenu);

        // When menu item is selected, change the visualisation and update the field view.
        normalViewMenu.addActionListener(l -> {
            currentVisual = Visualisation.NORMAL;
            actorFilterMenu.setEnabled(true);
            if (controller != null) {
                controller.refreshView();
            }
        });
        diseaseViewMenu.addActionListener(l -> {
            currentVisual = Visualisation.DISEASE;
            actorFilterMenu.setEnabled(false);
            if (controller != null) {
                controller.refreshView();
            }
        });
        viewTypeMenu.add(normalViewMenu);
        viewTypeMenu.add(diseaseViewMenu);
        menuBar.add(viewTypeMenu);

        // Create the filter menu.
        actorFilterMenu = new JMenu("Filter");
        menuBar.add(actorFilterMenu);
        setJMenuBar(menuBar);

        // Setup top pane with step info.
        JPanel infoPane = new JPanel(new BorderLayout());
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel(WEATHER_PREFIX + WeatherForecast.CLEAR, JLabel.CENTER);
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(infoLabel, BorderLayout.EAST);

        contents.add(infoPane, BorderLayout.NORTH);

        // Setup field view.
        fieldView = new FieldView(height, width);
        contents.add(fieldView, BorderLayout.CENTER);

        // Setup bottom pane with population.
        JPanel statsPane = new JPanel(new GridLayout(1, 2));
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        statsPane.add(population);

        // Add a pane to hold slider + text.
        JPanel delayPane = new JPanel();
        delayPane.setLayout(new BoxLayout(delayPane, BoxLayout.Y_AXIS));

        // Setup label to hold delay period text.
        delayLabel = new JLabel(DELAY_PREFIX + "0ms", JLabel.CENTER);
        delayLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Setup slider.
        JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 200, 0);
        slider.addChangeListener(this::changeDelay);

        // Add slider + text to pane, and add that pane to the bottom pane.
        delayPane.add(delayLabel);
        delayPane.add(slider);
        statsPane.add(delayPane);

        contents.add(statsPane, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }

    /**
     * A ChangeListener that relays the value of the slider.
     * @param changeEvent The slider's change in value event.
     */
    private void changeDelay(ChangeEvent changeEvent)
    {
        // Get the slider's current value.
        JSlider slider = (JSlider) changeEvent.getSource();
        int delay = slider.getValue();

        // Update the text above the slider.
        delayLabel.setText(DELAY_PREFIX + delay + "ms");

        // Send the delay value to the controller.
        if (controller != null) {
            controller.setDelay(delay);
        }
    }

    /**
     * Define a color to be used for a given class of animal.
     * @param actorClass The actor's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class<?> actorClass, Color color)
    {
        // Add the color to the Map.
        colors.put(actorClass, color);

        // Add a checkbox menu item entry using the class name.
        JCheckBoxMenuItem checkBox = new JCheckBoxMenuItem(actorClass.getName());

        // Create the coloured square.
        BufferedImage image = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = image.createGraphics();
        graphics.setPaint(color);
        graphics.fillRect(0, 0, image.getWidth(), image.getHeight());
        ImageIcon imageIcon = new ImageIcon(image);

        // Set the coloured square with the checkbox, put tick in box.
        checkBox.setIcon(imageIcon);
        checkBox.setState(true);

        // Add an Item Listener to watch for changes, then add to Map and Menu.
        checkBox.addItemListener(this::adjustActorFilter);
        visibleActors.put(actorClass, true);
        actorFilterMenu.add(checkBox);
    }

    /**
     * Changes the actor filter when a checkbox is changed.
     * @param itemEvent The event containing the changed checkbox.
     */
    private void adjustActorFilter(ItemEvent itemEvent)
    {
        // Get the text next to the checkbox that was changed.
        String className = ((JCheckBoxMenuItem) itemEvent.getSource()).getText();

        // Find the matching class. If found, toggle visibility and refresh view.
        for (Class<?> actor : visibleActors.keySet()) {
            if (className.equals(actor.getName())) {
                visibleActors.put(actor, !visibleActors.get(actor));
                controller.refreshView();
            }
        }
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class<?> animalClass)
    {
        Color col = colors.get(animalClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     * @param forecast The current weather forecast of the field.
     */
    public void showStatus(int step, Field field, WeatherForecast forecast)
    {
        showStatus(step, field);
        infoLabel.setText(WEATHER_PREFIX + forecast);
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }
            
        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();
        
        fieldView.preparePaint();

        // Switch between Normal / Disease visualisations depending what user chose.
        switch (currentVisual) {
            case NORMAL:
                showNormalStatus(field);
                break;
            case DISEASE:
                showDiseaseStatus(field);
                break;
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Show the status of the field by distinguishing species.
     * @param field The field whose status is to be displayed.
     */
    private void showNormalStatus(Field field)
    {
        // Iterate through all cells
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object actor = field.getObjectAt(row, col);
                // Check if there is an object inside the cell.
                if (actor != null) {
                    stats.incrementCount(actor.getClass());
                    // If visible (not filtered), get the right color.
                    // Otherwise, give it the filtered out color.
                    if (visibleActors.get(actor.getClass())) {
                        fieldView.drawMark(col, row, getColor(actor.getClass()));
                    } else {
                        fieldView.drawMark(col, row, FILTERED_COLOR);
                    }
                } else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
    }

    /**
     * Show the status of the field by distinguishing diseased animals.
     * @param field The field whose status is to be displayed.
     */
    private void showDiseaseStatus(Field field)
    {
        // Iterate through all the cells
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object actor = field.getObjectAt(row, col);
                if (actor != null) {
                    stats.incrementCount(actor.getClass());

                    // Paint the cells depending if diseased or not.
                    // If cant be diseased (i.e. plant), filter them out.
                    if (actor instanceof Animal && ((Animal) actor).isDiseased()) {
                        fieldView.drawMark(col, row, Color.MAGENTA);
                    } else if (actor instanceof Plant) {
                        fieldView.drawMark(col, row, FILTERED_COLOR);
                    } else {
                        fieldView.drawMark(col, row, Color.GREEN);
                    }
                } else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 4;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                                 gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
