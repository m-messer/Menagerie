/**
 * A simple model of a giraffe.
 * Giraffes age, move, breed, and die.
 *
 * @version 2021.02.18
 */
public class Giraffe extends Prey
{
    // Characteristics shared by all giraffes (class variables).

    // The age at which a giraffe can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a giraffe can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a giraffe breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    private static final int PLANT_FOOD_VALUE = 20;
    private static final int DEFAULT_FOOD_LEVEL = 10;

    /**
     * Create a new giraffe. A giraffe may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the giraffe will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Giraffe(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Produce a new giraffe.
     * @param loc The location of which the giraffe is born in.
     * @return The giraffe that is born.
     */
    @Override
    protected Animal produceNewYoung(Location loc)
    {
        return new Giraffe(false, getField(), loc);
    }

    /**
     * Return the minimum age for breeding to occur.
     * @return The minimum breeding age.
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the chance of success when attempting to breed.
     * @return The probability of breeding success.
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the maximum number of offspring a giraffe can produce.
     * @return The maximum number of offspring.
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the maximum age of a giraffe before it will die.
     * @return The maximum age of a giraffe.
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Gets the food level all new born Giraffes should have.
     * It is also used as the max food level a giraffe with a random age can have.
     * @return The food level for a new born.
     */
    @Override
    protected int getDefaultFoodLevel()
    {
        return DEFAULT_FOOD_LEVEL;
    }

    /**
     * Return the amount of energy/food that is attained by eating plants.
     * @return The food value given by plants for giraffes.
     */
    @Override
    protected int getPlantFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }
}
