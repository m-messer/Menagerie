import java.util.List;
import java.util.Random;

/**
 * A class that represents the weather in the simulation.
 * Different types of weather can affect the simulation
 * in different ways.
 *
 * @version 2020.02.25
 */
public class Weather implements Actor
{
    // A random number generator to control weather.
    private static final Random rand = Randomizer.getRandom();

    // Constants for chance of fog per step and maximum fog duration.
    private static final double FOG_PROBABILITY = 0.001;
    private static final int FOG_MAX_TIME = 450;

    // Constants for chance of rain per step and maximum rain duration.
    private static final double RAIN_PROBABILITY = 0.004;
    private static final int RAIN_MAX_TIME = 420;

    private WeatherForecast currentWeather = WeatherForecast.CLEAR;

    // Steps left before the fog is lifted
    // (-1 = fog not active, 0 = fog will lift in this step)
    private int fogTimeLeft = -1;
    // Steps left before the rain is lifted
    private int rainTimeLeft = -1;

    /**
     * Perform the weather's regular behaviour.
     * @param newActors Unused.
     */
    @Override
    public void act(List<Actor> newActors)
    {
        updateFog();
        updateRain();
    }

    private void updateFog()
    {
        // If there is fog time remaining, reduce it by 1.
        if (fogTimeLeft > 0) {
            fogTimeLeft--;
        }
        // If fog time = 0, set animal's fog behaviour to false.
        else if (fogTimeLeft == 0) {
            Animal.setFogBehaviour(false);
            removeWeather(WeatherForecast.FOG);
            fogTimeLeft = -1;
        }

        // Attempt to make fog (If fog is already present, fog time will be extended).
        if (rand.nextDouble() <= FOG_PROBABILITY) {
            Animal.setFogBehaviour(true);
            // Set fog time to a random value between half the max time & max time.
            fogTimeLeft = (int) Math.ceil(FOG_MAX_TIME * (Double.max(0.5, rand.nextDouble())));
            addWeather(WeatherForecast.FOG);
        }
    }

    private void updateRain()
    {
        // If there is rain time remaining, reduce it by 1.
        if (rainTimeLeft > 0) {
            rainTimeLeft--;
        }
        // If rain time = 0, set plant's rain behaviour to false.
        else if (rainTimeLeft == 0) {
            Plant.setRainBehaviour(false);
            removeWeather(WeatherForecast.RAIN);
            rainTimeLeft = -1;
        }

        // Attempt to make rain (If rain is already present, rain time will be extended).
        if (rand.nextDouble() <= RAIN_PROBABILITY) {
            Plant.setRainBehaviour(true);
            // Set rain time to a random value between half the max time & max time.
            rainTimeLeft = (int) Math.ceil(RAIN_MAX_TIME * (Double.max(0.5, rand.nextDouble())));
            addWeather(WeatherForecast.RAIN);
        }
    }

    /**
     * Add the new weather to the overall weather.
     * @param weather The new weather type to add.
     */
    private void addWeather(WeatherForecast weather)
    {
        if (currentWeather == WeatherForecast.CLEAR) {
            currentWeather = weather;
        } else if (currentWeather != weather) {
            currentWeather = WeatherForecast.ALL;
        }
    }

    /**
     * Remove existing weather from the overall weather.
     * @param weather The weather type to remove.
     */
    private void removeWeather(WeatherForecast weather)
    {
        if (currentWeather == WeatherForecast.ALL) {
            if (weather == WeatherForecast.RAIN) {
                currentWeather = WeatherForecast.FOG;
            } else {
                currentWeather = WeatherForecast.RAIN;
            }
        } else if (currentWeather == weather) {
            currentWeather = WeatherForecast.CLEAR;
        }
    }

    public WeatherForecast getWeather()
    {
        return currentWeather;
    }

    /**
     * Whether the actor is still alive (always true for weather).
     * @return true.
     */
    @Override
    public boolean isAlive()
    {
        return true;
    }
}
