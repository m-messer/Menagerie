/**
 * This class is the main class used to start the
 * simulation.
 *
 * @version 2020.02.22
 */
public class Application
{

    public static void main(String[] args)
    {
        Simulator simulator = new Simulator();
        simulator.runLongSimulation();
    }

}
