/**
 * A simple model of an impala.
 * Impalas age, move, breed, and die.
 *
 * @version 2021.02.18
 */
public class Impala extends Prey
{
    // Characteristics shared by all impalas (class variables).

    // The age at which an impala can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which an impala can live.
    private static final int MAX_AGE = 40;
    // The likelihood of an impala breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;

    private static final int PLANT_FOOD_VALUE  = 10;
    private static final int DEFAULT_FOOD_LEVEL = 10;

    /**
     * Create a new impala. An impala may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the impala will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Impala(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Produce a new impala.
     * @param loc The location of which the impala is born in.
     * @return The impala that is born.
     */
    @Override
    protected Animal produceNewYoung(Location loc)
    {
        return new Impala(false, getField(), loc);
    }

    /**
     * Return the minimum age for breeding to occur.
     * @return The minimum breeding age.
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the chance of success when attempting to breed.
     * @return The probability of breeding success.
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the maximum number of offspring an impala can produce.
     * @return The maximum number of offspring.
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the maximum age of an impala before it will die.
     * @return The maximum age of an impala.
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Gets the food level all new born Impalas should have.
     * It is also used as the max food level an impala with a random age can have.
     * @return The food level for a new born.
     */
    @Override
    protected int getDefaultFoodLevel()
    {
        return DEFAULT_FOOD_LEVEL;
    }

    /**
     * Return the amount of energy/food that is attained by eating plants.
     * @return The food value given by plants for impalas.
     */
    @Override
    protected int getPlantFoodValue() {
        return PLANT_FOOD_VALUE;
    }
}
