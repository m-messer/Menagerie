import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2021.02.21
 */
public abstract class Plant implements Actor
{

    // A shared random number generator to control reproduction.
    private static final Random rand = Randomizer.getRandom();
    // Whether it is currently raining or not.
    private static boolean isRaining = false;

    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // The plant's age.
    private int age;
    // The amount of times this plant can be eaten.
    private int foodValue;

    /**
     * Create a new plant at location in field.
     *
     * @param randomAge If true, the plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        if (randomAge) {
            age = getRandom().nextInt(getMaxAge());
            foodValue = getRandom().nextInt(getMaxFoodValue());
        } else {
            age = 0;
            foodValue = getMaxFoodValue();
        }

        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Return the chance of success when attempting to reproduce.
     * @return The probability of reproduction success.
     */
    protected abstract double getPollinationProbability();

    /**
     * Return the maximum number of offspring a plant can produce.
     * @return The maximum number of offspring.
     */
    protected abstract int getMaxOffspring();

    /**
     * Check whether or not this plant is to reproduce at this step.
     * New plants will be made into free adjacent locations.
     * @param newPlants A list to return new plants.
     */
    protected void pollination(List<Actor> newPlants)
    {
        Field field = getField();
        if (isRaining) {
            growPlants(newPlants);
            isRaining = false;
        }
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = reproduce();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newPlants.add(produceNewPlant(loc));
        }
    }

    /**
     * Cause plants to grow in random locations across the field.
     * @param newPlants A list to return the new plants.
     */
    private void growPlants(List<Actor> newPlants)
    {
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= 0.001) {
                    Location location = new Location(row, col);
                    Plant plant = produceNewPlant(location);
                    newPlants.add(plant);
                }
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can reproduce.
     * @return The number of births (may be zero).
     */
    protected int reproduce()
    {
        int births = 0;
        double chance = rand.nextDouble();

        // Increase the chance of new plants if raining.
        if (isRaining) {
            chance = chance * 0.9;
        }
        if(chance <= getPollinationProbability()) {
            births = rand.nextInt(getMaxOffspring()) + 1;
        }
        return births;
    }

    /**
     * Produce a new plant.
     * @param location The location of which the plant is made in.
     * @return The plant that is produced.
     */
    protected abstract Plant produceNewPlant(Location location);

    /**
     * Adjusts the behaviour of all plants to their behaviour in rain.
     * The current behaviour is to increase reproduction probability.
     */
    public static void setRainBehaviour(boolean isRaining)
    {
        Plant.isRaining = isRaining;
    }

    /**
     * Indicates the plant has been eaten by an plant,
     * reduces the food value of the plant by 1.
     */
    public void bitten()
    {
        foodValue--;
    }

    /**
     * Returns the current food value of the plant
     * (the number of times it can be eaten before dying).
     * @return The plant's food value.
     */
    public int getFoodValue()
    {
        return foodValue;
    }

    /**
     * Returns the max possible food value of the plant
     * (the number of times it can be eaten before dying).
     * @return The plant's maximum food value.
     */
    protected abstract int getMaxFoodValue();

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    @Override
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return current age of a plant.
     * @return the current age of a plant. 
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Returns the maximum age of a plant before it will die.
     * @return The maximum age of a plant.
     */
    protected abstract int getMaxAge();
  
    /**
     * Increase the age. This could result in the plant's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Sets the age of the plant.
     * @param age The age to set the plant to.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the random number generator.
     * @return The random number generator.
     */
    protected Random getRandom()
    {
        return rand;
    }
}