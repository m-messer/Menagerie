import java.util.List;

/**
 * A class that represents shared characteristics of predators
 * in this simulation. Predators are defined as animals that
 * eat (any subset of) prey.
 *
 * @version 2020.02.22
 */
public abstract class Predator extends Animal
{

    /**
     * Create a new predator at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what a predator does most of the time: it hunts for
     * foods. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newPredators A list to return newly born predators.
     */
    @Override
    public void act(List<Actor> newPredators)
    {
        incrementAge();

        // If night, don't do anything.
        if (isNight()) return;

        incrementHunger();
        if(isAlive()) {
            giveBirth(newPredators);

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - look at nearby locations
                List<Location> potentialLocations = getField().adjacentLocations(getLocation());

                // If the location is empty, move to it.
                // If the location has a Plant, kill the plant and move to it.
                for (Location location : potentialLocations) {
                    Object actor = getField().getObjectAt(location);
                    if (actor == null) {
                        newLocation = location;
                        break;
                    } else if (actor instanceof Plant) {
                        ((Plant) actor).setDead();
                        newLocation = location;
                        break;
                    }
                }
            }

            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
                attemptInfection();
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent;
        // If foggy, check one adjacent location, else check all adjacent.
        if (isFoggy()) {
            adjacent = List.of(field.randomAdjacentLocation(getLocation()));
        } else {
            adjacent = field.adjacentLocations(getLocation());
        }

        // Check if the prey can be eaten by this animal.
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Prey && canHunt((Prey) animal)) {
                return where;
            }
        }
        return null;
    }

    /**
     * Check if a certain type of prey can be eaten by this specific predator.
     * @param prey The prey to eat.
     * @return true if the prey was eaten.
     */
    protected abstract boolean canHunt(Prey prey);
}
