import java.util.List;
import java.util.Random;

/**
 * A generator that randomly populates a filed with actors
 * based on creation probability constants.
 *
 * @version 2021.02.18
 */
public class PopulationGenerator
{

    // Constants representing configuration information for the simulation.
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.02;

    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;

    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.065;

    // The probability that a giraffe will be created in any given grid position.
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.07;

    // The probability that a impala will be created in any given grid position.
    private static final double IMPALA_CREATION_PROBABILITY = 0.1;

    // The probability that leaves will be created in any given grid position.
    private static final double LEAVES_CREATION_PROBABILITY = 0.1;

    /**
     * Randomly populate the field with different types of actors.
     * @param field The field to populate
     * @param actors The list that will be populated with actors
     */
    public static void populate(Field field, List<Actor> actors)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {

                if (rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena fox = new Hyena(true, field, location);
                    actors.add(fox);

                } else if (rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    actors.add(lion);

                } else if (rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    actors.add(zebra);

                } else if (rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Giraffe giraffe = new Giraffe(true, field, location);
                    actors.add(giraffe);

                } else if (rand.nextDouble() <= IMPALA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Impala rabbit = new Impala(true, field, location);
                    actors.add(rabbit);

                } else if (rand.nextDouble() <= LEAVES_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Leaves leaves = new Leaves(true, field, location);
                    actors.add(leaves);
                }
                // else leave the location empty.
            }
        }
    }

}
