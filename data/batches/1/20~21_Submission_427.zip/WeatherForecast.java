/**
 * Enums of the different types of weather that can
 * take place in the simulation.
 *
 * @version 2021.02.25
 */
public enum WeatherForecast
{
    CLEAR("Clear"),
    RAIN("Raining"),
    FOG("Foggy"),
    ALL("Rain & Fog");

    private String forecastString;

    /**
     * Initialise with the appropriate forecast string representation.
     * @param forecast The weather in string form.
     */
    WeatherForecast(String forecast)
    {
        forecastString = forecast;
    }

    /**
     * Return the type of weather as a string.
     * @return The weather forecast as String.
     */
    @Override
    public String toString()
    {
        return forecastString;
    }
}
