/**
 * A simple model of a hyena.
 * Hyenas age, move, eat impalas or zebras, and die.
 *
 * @version 2021.02.18
 */
public class Hyena extends Predator
{
    // Characteristics shared by all hyena (class variables).

    // The age at which a hyena can start to breed.
    private static final int BREEDING_AGE = 45;
    // The age to which a hyena can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.75;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    // The food value of a hyena's prey. In effect, this is the
    // number of steps a hyena can go before it has to eat again.
    private static final int IMPALA_FOOD_VALUE = 25;
    private static final int ZEBRA_FOOD_VALUE = 35;
    private static final int DEFAULT_FOOD_LEVEL = 30;

    /**
     * Create a hyena. A hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the hyena will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Check if prey is a Zebra or Impala and try to eat them.
     * @param prey The prey to eat.
     * @return true if the prey was eaten.
     */
    @Override
    protected boolean canHunt(Prey prey)
    {
        if (prey.isAlive()) {
            if (prey instanceof Zebra) {
                prey.setDead();
                increaseFoodLevel(ZEBRA_FOOD_VALUE);
                return true;
            } else if (prey instanceof Impala) {
                prey.setDead();
                increaseFoodLevel(IMPALA_FOOD_VALUE);
                return true;
            }
        }
        return false;
    }

    /**
     * Produce a new hyena.
     * @param loc The location of which the hyena is born in.
     * @return The hyena that is born.
     */
    @Override
    protected Animal produceNewYoung(Location loc)
    {
        return new Hyena(false, getField(), loc);
    }

    /**
     * Gets the food level all new born hyenas should have.
     * It is also used as the max food level a hyena with a random age can have.
     * @return The food level for a new born.
     */
    @Override
    protected int getDefaultFoodLevel()
    {
        return DEFAULT_FOOD_LEVEL;
    }

    /**
     * Return the minimum age for breeding to occur.
     * @return The minimum breeding age.
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the chance of success when attempting to breed.
     * @return The probability of breeding success.
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the maximum number of offspring a hyena can produce.
     * @return The maximum number of offspring.
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the maximum age of a hyena before it will die.
     * @return The maximum age of a hyena.
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
}
