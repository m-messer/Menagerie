/**
 * Interface to control the view of the simulation
 *
 * @version 2021.02.24
 */
public interface ViewController
{
    /**
     * Adjust the delay of the simulation.
     * @param delayTime The time to wait between steps (in ms).
     */
    void setDelay(int delayTime);

    /**
     * Refresh the view with the latest information from the simulation.
     */
    void refreshView();
}
