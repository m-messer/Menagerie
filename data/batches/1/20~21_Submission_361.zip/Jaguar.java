import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a jaguar.
 * Jaguars age, move, eat capybaras, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Jaguar extends Animal
{
    // Characteristics shared by all jaguars (class variables).
    
    // The age at which a jaguar can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a jaguar can live.
    private static final int MAX_AGE = 150;
    // The gender of the jaguar.
    private static final int MAX_GENDER = 2;
    // The likelihood of a jaguar breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The chance of infection, higher values = lower chance of infection/
    private static final int CHANCE_OF_INFECTION = 1000;    
    // The food value of a single capybara and rat. In effect, this is the
    // number of steps a jaguar can go before it has to eat again.
    private static final int CAPYBARA_FOOD_VALUE = 9;
    private static final int RAT_FOOD_VALUE = 8;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The jaguar's age.
    private int age;
    // The jaguar's food level, which is increased by eating capybaras/rats.
    private int foodLevel;
    // Gender of animal; 1 = male, 0 = female.
    private int gender;
    // Does animal have disease.
    private boolean disease;
    
     

    /**
     * Create a jaguar. A jaguar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the jaguar will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Jaguar(boolean randomAge, boolean randomGender, boolean randomDisease, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CAPYBARA_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = CAPYBARA_FOOD_VALUE;
        }
        
        if(randomGender) {
            gender = rand.nextInt(MAX_GENDER);
        }
        if(randomDisease) {
            disease = rand.nextBoolean();
        }
    }
    
    /**
     * This is what the jaguar does most of the time: it hunts for
     * capybaras and rats. In the process, it might breed, die of hunger,
     * or die of old age or disease.
     * @param field The field currently occupied.
     * @param newJaguars A list to return newly born jaguars.
     */
    public void act(List<Animal> newJaguars)
    {
        incrementAge();
        incrementHunger();
        checkIfDeadFromDisease();
        
        if(isAlive()) {
            giveBirth(newJaguars); 
            isInfected();
            // Move towards a source of food if found.
             
            Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
                if(newLocation != null) {
                setLocation(newLocation);
            }
                else {
                // Overcrowding.
                setDead();
            }
            
        }
        
    }

    /**
     * Increase the age. This could result in the jaguar's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
     /**
     * Check if animal has the disease.
     * @return true if it does.
     */
    protected boolean hasDisease()
    {
        return disease;
    }
    
    /**
     * Make this jaguar more hungry. This could result in the jaguar's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check if the jaguar died from the disease or not.
     * This could result in the jaguars's death.
     */
    private void checkIfDeadFromDisease()
    {
        //diseaseValue--;
        boolean diedFromDisease = Math.random() < 0.01;
        if(disease == true && diedFromDisease) {
            setDead();
            //System.out.println("Jaguar died to disease");
        }
    }    
    
    /**
     * Look for capybaras and rats adjacent to the current location.
     * Only the first live capybara or rat is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if(capybara.isAlive()) { 
                    capybara.setDead();
                    foodLevel = CAPYBARA_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.isAlive()) { 
                    rat.setDead();
                    foodLevel = RAT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
 
    /**
     * Look for any animal adjacent to the current location.
     * This can lead to the jaguar contracting the disease
     * @return Where disease was found, or null if it wasn't.
     */
    private void isInfected()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if(capybara.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance == 1)
                    {
                        disease = true;
                    } 
                
                }
            }
            if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }
            }
            else if(animal instanceof Jaguar) {
                Jaguar jaguar = (Jaguar) animal;
                if(jaguar.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }
            }
            else if(animal instanceof Owl) {
                Owl owl = (Owl) animal;
                if(owl.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }
            }
            else if(animal instanceof Anaconda) {
                Anaconda anaconda = (Anaconda) animal;
                if(anaconda.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }    
            }
        }
        
    }     
    /*
     * Check whether or not this jaguar is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newJaguars A list to return newly born jaguars.
     */
    private void giveBirth(List<Animal> newJaguars)
    {
        // New jaguars are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Jaguar young = new Jaguar(false, true, false, field, loc);
            newJaguars.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A jaguar can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
