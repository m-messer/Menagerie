
import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of an anaconda.
 * Anacondas age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Anaconda extends Animal
{
    // Characteristics shared by all anacondas (class variables).

    // The age at which a anaconda can start to breed.
    private static final int BREEDING_AGE = 50;
    // The age to which a anaconda can live.
    private static final int MAX_AGE = 400;
    // The gender of the anaconda.
    private static final int MAX_GENDER = 2;
    // The likelihood of a anaconda breeding.
    private static final double BREEDING_PROBABILITY = 0.012;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The chance of infection, higher values = lower chance of infection/
    private static final int CHANCE_OF_INFECTION = 450;     
    //number of steps an anaconda can go before it has to eat again.
    private static final int CAPYBARA_FOOD_VALUE = 9;
    private static final int JAGUAR_FOOD_VALUE = 30;
    private static final int RAT_FOOD_VALUE = 4;
    private static final int OWL_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The anaconda's age.
    private int age;
    // The anaconda's food level, which is increased by eating capybaras, jaguars or rats.
    private int foodLevel;
    // Gender of animal; 1 = male, 0 = female.
    private int gender;
    // Does animal have disease.
    private boolean disease;  
    

    /**
     * Create a new anaconda. An anaconda may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the anaconda will have a random age.
     * @param randomGender If true, the anaconda will have a random gender.
     * @param randomDisease If true, the anaconda will have a disease.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Anaconda(boolean randomAge, boolean randomGender, boolean randomDisease, Field field, Location location)
    {
        super(field, location);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(OWL_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = OWL_FOOD_VALUE;
        }

        if(randomGender) {
            gender = rand.nextInt(MAX_GENDER);
        }
        if(randomDisease) {
            disease = rand.nextBoolean();
        }        
    }
    
    /**
     * This is what the anaconda does most of the time - it runs 
     * around hunting all other animals. Sometimes it will breed or die of old age/diease or starvation.
     * @param newanacondas A list to return newly born anacondas.
     */
    public void act(List<Animal> newAnacondas)
    {
        incrementAge();
        incrementHunger();
        checkIfDeadFromDisease();
        
        if(isAlive()) {
            giveBirth(newAnacondas);
            isInfected();
            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the anaconda's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
     /**
     * Check if animal has the disease.
     * @return true if it does.
     */    
    protected boolean hasDisease()
    {
        return disease;
    }    
    
    /**
     * Make this Anaconda more hungry. This could result in the Anaconda's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check if the anaconda died from the disease or not.
     * This could result in the anaconda's death.
     */
    private void checkIfDeadFromDisease()
    {
        //diseaseValue--;
        boolean diedFromDisease = Math.random() < 0.01;
        if(disease == true && diedFromDisease) {
            setDead();
            //System.out.println("Anaconda died to disease");
        }
    }    
    
    /**
     * Look for capybaras, jaguars, owls or rats adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if(capybara.isAlive()) { 
                    capybara.setDead();
                    foodLevel = foodLevel + CAPYBARA_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Jaguar) {
                Jaguar jaguar = (Jaguar) animal;
                if(jaguar.isAlive()) { 
                    jaguar.setDead();
                    foodLevel = foodLevel + JAGUAR_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.isAlive()) { 
                    rat.setDead();
                    foodLevel = foodLevel + RAT_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Owl) {
                Owl owl = (Owl) animal;
                if(owl.isAlive()) { 
                    owl.setDead();
                    foodLevel = foodLevel + OWL_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this anaconda is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnacondas A list to return newly born anacondas.
     */
    private void giveBirth(List<Animal> newAnacondas)
    {
        // New anacondas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Anaconda young = new Anaconda(false, true, false, field, loc);
            newAnacondas.add(young);
        }
    }
    
    /**
     * Look for any animal adjacent to the current location.
     * This can lead to the anaconda contracting the disease
     * @return Where disease was found, or null if it wasn't.
     */
    private void isInfected()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if(capybara.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                        disease = true;
                    } 
                
                }
            }
            if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.hasDisease() == true) { 
                    
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                        disease = true;
                        
                    }   
                }
            }
            else if(animal instanceof Jaguar) {
                Jaguar jaguar = (Jaguar) animal;
                if(jaguar.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }
            }
            else if(animal instanceof Owl) {
                Owl owl = (Owl) animal;
                if(owl.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }
            }
            else if(animal instanceof Anaconda) {
                Anaconda anaconda = (Anaconda) animal;
                if(anaconda.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }    
            }
        }
        
        }     
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A anaconda can breed if it has reached the breeding age.
     * @return true if the anaconda can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
