import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of grass.
 * Grass ages, moves, breeds, and dies.
 *
 * @version 2016.02.29 (2)
 */
public class Grass extends Plant
{
    // Characteristics shared by all grass (class variables).


    // The age to which grass can live.
    private static final int MAX_AGE = 35;
    // The likelihood of grass spreading.
    private static final double SPREADING_PROBABILITY = 0.13;
    // The maximum number of spread.
    private static final int MAX_SPREAD_SIZE = 3;
    // A shared random number generator to control spreading.
    private static final Random rand = Randomizer.getRandom();
    
    
    // Individual characteristics (instance fields).
    
    // The grasses age.
    private int age;



    /**
     * Create a new grass. Grass may be created with age
     * zero (a new spawn) or with a random age.
     * 
     * @param randomAge If true, grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the grass does most of the time - it doesnt move 
     * around. Sometimes it will spread or die of old age.
     * @param newGrass A list to return newly spread grass.
     */
    public void act(List<Plant> newGrass)
    {
        incrementAge();
        if(isAlive()) {
        spread(newGrass);            
        }
    }

    /**
     * Increase the age.
     * This could result in the grasses death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this grass is to spread at this step.
     * New spread will be made into free adjacent locations.
     * @param newGrass A list to return newly spread grass.
     */
    private void spread(List<Plant> newGrass)
    {
        // New grasses are spread into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int newSpread = spread();
        for(int b = 0; b < newSpread && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass fresh = new Grass(false, field, loc);
            newGrass.add(fresh);
        }
    }
        
    /**
     * Generate a number representing the number of spread,
     * if it can spread.
     * @return The number of spread (may be zero).
     */
    private int spread()
    {
        int newSpread = 0;
        if(canSpread() && rand.nextDouble() <= SPREADING_PROBABILITY) {
            newSpread = rand.nextInt(MAX_SPREAD_SIZE) + 1;
        }
        return newSpread;
    }

    /**
     * A grass can spread if it hasnt reached the max age.
     * @return true if the grass can spread, false otherwise.
     */
    private boolean canSpread()
    {
        return age <= MAX_AGE;
    }
}
