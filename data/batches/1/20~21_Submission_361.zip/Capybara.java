import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a capybara.
 * Capybaras age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Capybara extends Animal
{
    // Characteristics shared by all capybaras (class variables).

    // The age at which a capybara can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a capybara can live.
    private static final int MAX_AGE = 60;
    // The gender of the capybara.
    private static final int MAX_GENDER = 2;
    // The likelihood of a capybara breeding.
    private static final double BREEDING_PROBABILITY = 0.11;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The chance of infection, higher values = lower chance of infection/
    private static final int CHANCE_OF_INFECTION = 10;     
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //number of steps a capybara can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 30;    
    // Individual characteristics (instance fields).
    
    // The capybara's age.
    private int age;
    // Gender of animal; 1 = male, 0 = female.
    private int gender;
    // The capybaras's food level, which is increased by eating grass.
    private int foodLevel;
    // Does animal have disease.
    private boolean disease;  
      
    

    /**
     * Create a new capybara. A capybara may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the capybara will have a random age.
     * @param randomGender If true, the capybara will have a random gender.
     * @param randomDisease If true, the capybara will have a disease.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Capybara(boolean randomAge,boolean randomGender, boolean randomDisease, Field field, Location location)
    {
        super(field, location);

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        } 
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }

         if(randomGender) {
            gender = rand.nextInt(MAX_GENDER);
        }
        if(randomDisease) {
            disease = rand.nextBoolean();
        }        
    }
    
    /**
     * This is what the capybara does most of the time - it runs 
     * around and eats. Sometimes it will breed or die of old age/disease or starvation.
     * @param newCapybaras A list to return newly born capybaras.
     */
    public void act(List<Animal> newCapybaras)
    {
        incrementAge();
        incrementHunger();
        checkIfDeadFromDisease();
        if(isAlive()) {
            giveBirth(newCapybaras);
            isInfected();
            // Move towards a source of food if found.
            Location newLocation = findFood();   
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the capybara's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
     /**
     * Check if animal has the disease.
     * @return true if it does.
     */
    protected boolean hasDisease()
    {
        return disease;
    }    
       
    /**
     * Make this Capybara more hungry. This could result in the Capybara's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }    
    
    /**
     * Check if the capybara died from the disease or not.
     * This could result in the capybaras's death.
     */
    private void checkIfDeadFromDisease()
    {
        //diseaseValue--;
        boolean diedFromDisease = Math.random() < 0.01;
        if(disease == true && diedFromDisease) {
            setDead();
            //System.out.println("Capybara died to disease");
        }
    }    

    /**
     * Look for grass adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
            
        }
        return null;
    }    
    
    /**
     * Check whether or not this capybara is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCapybaras A list to return newly born capybaras.
     */
    private void giveBirth(List<Animal> newCapybaras)
    {
        // New capybaras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Capybara young = new Capybara(false, true, false, field, loc);
            newCapybaras.add(young);
        }
    }
    
    /**
     * Look for any animal adjacent to the current location.
     * This can lead to the capybara contracting the disease
     * @return Where disease was found, or null if it wasn't.
     */
    private void isInfected()
    {
        Field field = getField();
        //System.out.println("Before");
        List<Location> adjacent = field.adjacentLocations(getLocation());
        //System.out.println("Middle" + adjacent);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            if(animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if(capybara.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance == 1)
                    {
                        disease = true;
                    }               
                }
            }
             if(animal instanceof Rat) {
                 Rat rat = (Rat) animal;
                 if(rat.hasDisease() == true) { 
                     int chance = rand.nextInt(CHANCE_OF_INFECTION);
                     if(chance < 1)
                     {
                         disease = true;
                     }   
                 }
            }
            else if(animal instanceof Jaguar) {
                Jaguar jaguar = (Jaguar) animal;
                if(jaguar.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }
            }
            else if(animal instanceof Owl) {
                Owl owl = (Owl) animal;
                if(owl.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }
            }
            else if(animal instanceof Anaconda) {
                Anaconda anaconda = (Anaconda) animal;
                if(anaconda.hasDisease() == true) { 
                    int chance= rand.nextInt(CHANCE_OF_INFECTION);
                    if(chance < 1)
                    {
                    disease = true;
                    }   
                }    
            }
        }
        
    }     
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A capybara can breed if it has reached the breeding age.
     * @return true if the capybara can breed, false otherwise.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if(gender == 0 && age >= BREEDING_AGE)
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if(capybara.gender == 1) { 
                  return true;
                }
            }
        }
        else if(gender == 1 && age >= BREEDING_AGE)
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if(capybara.gender == 0) { 
                  return true;
                }
            }
        
        }
        return false;
    }
}
