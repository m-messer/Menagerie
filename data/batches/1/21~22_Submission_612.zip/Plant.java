import java.util.List;
import java.util.Random;

/**
 * 13 Feb 2022
 */
public abstract class Plant {
    //Whether the plant is alive or not.
    private boolean alive;
    //The plant's field.
    private Field field;
    //The plant's location on the field.
    private Location location;
    //The age of the plant.
    private int age;
    //If the plant is diseased.
    private boolean diseased;

    private static final Random r = new Random();


    /**
     * Create a new plant at location in the field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this plant grow.
     *
     * @param newPlants A list to receive newly created plants
     * @param timeOfDay The current time of day in the simulation.
     * @param weathers A list containing all the weathers currently on the field.
     */
    abstract public void grow(List<Plant> newPlants, int timeOfDay, List<Weather> weathers);

    /**
     * Increases the age of the plant by one,
     * if the plant is older than the max age, then it dies.
     * If the plant is diseased then their max age is halved.
     *
     */
    protected void incrementAge() {
        setAge(getAge() + 1);
        if (isDiseased()) {
            if (getAge() > getMAX_AGE()/3) {
                setDead();
            }
        } else if (getAge() > getMAX_AGE()) {
            setDead();
        }
    }

    /**
     * This method is used to determine whether plants are capable of
     * breeding.
     *
     * @param plant        this is the plant itself
     * @param BREEDING_AGE the min age to reproduce
     * @param age          the current age of the plant
     * @return true if the necessary conditions for reproduction are met
     */
    protected boolean canBreed(Plant plant, int BREEDING_AGE, int age) {

        field = getField();
        for (Location loc : field.adjacentLocations(getLocation())) {
            if (field.getObjectAt(loc) != null) {
                if (plant.getClass() == field.getObjectAt(loc).getClass()) {
                    Plant neighbor = (Plant) field.getObjectAt(loc);
                    if ((age >= BREEDING_AGE) && (neighbor.getAge() >= BREEDING_AGE)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Method used to determine how many new plants will be
     * produced after successful breeding.
     *
     * @param weathers List of weathers on field.
     * @return The number of births each plant has.
     */
    protected int breed(List<Weather> weathers) {
        double newBreedingProbability = getBREEDING_PROBABILITY();
        int births = 0;

        for (Weather weath : weathers) {
            if ((weath.sameLocation(this.getLocation()) && canBreed(this, getBREEDING_AGE(), getAge()) && (weath.weatherAffects(this, null)))) {
                newBreedingProbability = getBREEDING_PROBABILITY() + weath.getPlantBirthProbability(this);
            }
        }

        if (canBreed(this, getBREEDING_AGE(), getAge()) && r.nextDouble() <= newBreedingProbability) {
            births = r.nextInt(getMAX_LITTER_SIZE()) + 1;
        }
        return births;
    }

    /**
     * If the plant is diseased, it has a certain probability of
     * spreading that disease to adjacent plants of the same type.
     * @version 2022.03.02
     */
    protected void spreadDisease() {
        if (!isDiseased()) {
            return;
        }
        for (Location loc : field.adjacentLocations(getLocation())) {
            if(field.getObjectAt(loc) != null) {
                if (this.getClass() == field.getObjectAt(loc).getClass()) {
                    setDiseased(r.nextDouble() <= getDISEASE_SPREAD_PROBABILITY());
                }
            }
        }
    }


    /**
     * @return The plant's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * @return the plant's location within the field.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Check whether the plant is alive or not.
     *
     * @return true if the plant is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * @return The age of the plant.
     */
    protected int getAge() {
        return age;
    }

    /**
     * Sets the age of the plant to the given input.
     *
     * @param age Age to be set.
     */
    protected void setAge(int age) {
        this.age = age;
    }

    /**
     * @return True if the plant is diseased, false if not.
     */
    protected boolean isDiseased() {
        return diseased;
    }

    /**
     * Sets the value of diseased.
     *
     * @param diseased True or false.
     */
    protected void setDiseased(boolean diseased) {
        this.diseased = diseased;
    }

    /**
     * @return True if the fruit is ripe, false if not.
     */
    protected abstract boolean isRipe();

    /**
     * @return the minimum age to breed for the plant.
     */
    abstract protected int getBREEDING_AGE();

    /**
     * @return the breeding probability of the plant.
     */
    abstract protected double getBREEDING_PROBABILITY();

    /**
     * @return the maximum number of births a plant can have.
     */
    abstract protected int getMAX_LITTER_SIZE();

    /**
     * @return The maximum age the plant can reach.
     */
    abstract protected int getMAX_AGE();

    /**
     * @return The probability that this plant spreads disease to another.
     */
    abstract protected double getDISEASE_SPREAD_PROBABILITY();
}
