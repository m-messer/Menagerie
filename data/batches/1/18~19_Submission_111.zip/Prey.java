import java.util.Iterator;
import java.util.List;

/**
 * A class representing shared characteristics of prey.
 *
 * @version 2019.02.21
 */

public abstract class Prey extends Animal {

    /**Constructor for the prey class, sets the variables etc and foodLevel dependent on when the prey is spawned
     * @param randomAge a boolean to check if the age should be random or not
     * @param field the current state of the field
     * @param location location of spawn
     * @param breedingAge the age at which the prey is able to breed
     * @param breedingProbability the probability that the prey will breed
     * @param maxAge the maximum age that the prey can live
     * @param maxLitterSize the maximum number of children that the prey can give birth to
     */
    public Prey(boolean randomAge, Field field, Location location, int breedingAge, double breedingProbability, int maxAge, int maxLitterSize) {
        super(field, location);
        setParameters(breedingAge, breedingProbability, maxAge, maxLitterSize);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);

        }
        foodLevel = rand.nextInt(20);

    }

    /**
     * This is what prey do most of the time - they run
     * around. Sometimes they will breed or die of old age.
     * A random number of prey at each step will become infected with disease
     * If they have had the disease for 3 or more steps, they die. Otherwise they will
     * continue to live with the disease.
     *
     * @param newPrey A list to return newly born preys.
     */
    public void act(List<Entities> newPrey, boolean doesBreeding) {
        incrementHunger();
        incrementAge();
        setRandomInfected();
        if (isAlive()) {

            if (infectedStep >= 3) {
                setDead();
                return;

            }
            if (isInfected()) {
                infectedStep++;

            }
            if (doesBreeding == true) {
                giveBirth(newPrey);
            }
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for preys adjacent to the current location.
     * Only the first live prey is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object entity = field.getObjectAt(where);
            if (entity instanceof Plant) {
                Plant plant = (Plant) entity;
                if (plant.isAlive()) {
                    plant.setDead();

                    foodLevel = plant.getFoodValue();

                    return where;

                }
            }
        }
        return null;
    }
}

