import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Predator is an abstract class that extends from Animal.
 * Predator has the base constructor to instantiate common variables and the findfood and act methods
 * @version 2019.02.21
 */
public abstract class Predator extends Animal {
    // Sets the food value of a capybara (how much the predator food level increases by if it consumes a capybara).
    private static final int CAPYBARA_FOOD_VALUE = 9;
    // Sets the food value of a macaw (how much the predator food level increases by if it consumes a macaw).
    private static final int MACAW_FOOD_VALUE = 9;
    // Sets the initial number of steps which an animal has been infected for to zero.

    private static final Random rand = Randomizer.getRandom();

    /**Constructor for the predator class, sets the variables etc and foodLevel dependent on when the predator is spawned
     * @param randomAge a boolean to check if the age should be random or not
     * @param field the current state of the field
     * @param location location of spawn
     * @param breedingAge the age at which the prey is able to breed
     * @param breedingProbability the probability that the prey will breed
     * @param maxAge the maximum age that the prey can live
     * @param maxLitterSize the maximum number of children that the prey can give birth to
     */
    public Predator(boolean randomAge, Field field, Location location, int breedingAge, double breedingProbability, int maxAge, int maxLitterSize) {
        super(field, location);
        setParameters(breedingAge, breedingProbability, maxAge, maxLitterSize);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CAPYBARA_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = CAPYBARA_FOOD_VALUE;
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if (capybara.isAlive()) {
                    capybara.setDead();
                    if (capybara.isInfected()) {
                        this.setInfected();
                    }
                    foodLevel = CAPYBARA_FOOD_VALUE;
                    return where;
                }
            } else if (animal instanceof Macaw) {
                Macaw macaw = (Macaw) animal;
                if (macaw.isAlive()) {
                    macaw.setDead();
                    if (macaw.isInfected()) {
                        this.setInfected();
                    }
                    foodLevel = MACAW_FOOD_VALUE;
                    return where;
                }

            } else if ((animal instanceof HomoSapiens) && (this instanceof Anaconda) && ((HomoSapiens) animal).getAge() < (1)) {
                HomoSapiens homoSapiens = (HomoSapiens) animal;
                if (homoSapiens.isAlive()) {
                    homoSapiens.setDead();
                    if (homoSapiens.isInfected()) {
                        this.setInfected();
                    }
                    foodLevel = ((HomoSapiens) animal).getAge();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * This is what predators do most of the time: they hunts for
     * prey. In the process, it might breed, die of hunger,
     * die of old age or die of disease.
     *
     * @param newPredator A list to return newly born predators.
     */
    public void act(List<Entities> newPredator, boolean doesBreeding) {
        incrementAge();
        incrementHunger();
        setRandomInfected();
        if (isAlive()) {
            if (infectedStep >= 3) {
                setDead();
                return;
            }
            if (isInfected()) {
                infectedStep++;
            }
            if (doesBreeding == true) {
                giveBirth(newPredator);
            }
            if (!((Simulator.getTimeInHours() > 18) || (Simulator.getTimeInHours() < 6)) && (this instanceof Jaguar)) {
                return;
            }
            if (Simulator.getCurrentWeather().equals("hot") && (this instanceof Anaconda)) {
                return;
            }
            if (Simulator.getTimeInHours() > 19 && (this instanceof HomoSapiens)) {
                return;
            }
            if (Simulator.getCurrentWeather().equals("rainy") && (this instanceof HomoSapiens)) {
                return;
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }


}
