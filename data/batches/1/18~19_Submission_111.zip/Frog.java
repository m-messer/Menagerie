/**
 * A simple model of a Frog.
 * Frogs age, move, breed, do not get eaten, change gender and can balance populations and die
 *
 * @version 2019.02.21
 */


public class Frog extends Prey
{    /**
     * Create a new frog. A frog may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the frog will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location, 1,.4,3,3);
    }

    /**
     * Changes the current sex of the current frog object
     */
    protected void sexChange(){
        male = !male;
    }
}
