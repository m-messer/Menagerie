/**
 * A simple model of a homo sapien.
 * Homo sapiens age, move, eat capybara and macaws, sleep, stop moving if it is raining,  and die.
 * Homo sapiens can also get diseased and pass it on to their offspring
 *
 * @version 2019.02.21
 */

public class HomoSapiens extends Predator {
    /**
     * Create a homo sapien. A homo sapien can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the homo sapien will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public HomoSapiens(boolean randomAge, Field field, Location location) {

        super(randomAge,field, location,8,.8,45,6);
    }
}
