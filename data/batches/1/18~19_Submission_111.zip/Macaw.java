/**
 * A simple model of a Macaw.
 * Macaw age, move, breed, and die.
 *
 * @version 2019.02.21
 */
public class Macaw extends Prey
{    /**
     * Create a new capybara. A capybara may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the capybara will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Macaw(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location, 1,0.8,7,6);
    }
}
