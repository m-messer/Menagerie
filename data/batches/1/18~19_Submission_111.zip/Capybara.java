/**
 * A simple model of a capybara.
 * Capybara age, move, breed, eat plants, and die.
 * Capybara can also get diseased and pass it on to their offspring
 *
 * @version 2019.02.21
 */

public class Capybara extends Prey {
    /**
     * Create a new capybara. A capybara may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the capybara will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Capybara(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, 2, 0.7, 7, 6);
    }
}
