/**
 * A simple model of a anaconda  .
 * Anacondas age, move, eat capybara , eat jaguars if old enough, and die.
 *
 *
 * @version 2019.02.15
 */
public class Anaconda extends Predator {
    /**
     * Create a anaconda. A anaconda can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the anaconda will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Anaconda(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location,4,.2,4,3);
    }
}
