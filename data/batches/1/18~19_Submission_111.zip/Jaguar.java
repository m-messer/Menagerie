/**
 * A simple model of a jaguar.
 * Jaguars age, move, eat capybara and macaws, and die.
 * Jaguars can also get diseased and pass it on to their offspring
 *
 * @version 2019.02.21
 */

public class Jaguar extends Predator {
    /**
     * Create a jaguar. A jaguar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the jaguar will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Jaguar(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, 1, .4, 12, 6);
    }
}