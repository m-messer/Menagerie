import java.util.*;
import java.awt.Color;
import java.util.stream.Collectors;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing containing capybaras, macaws, frogs, anacondas, jaguars, homo sapiens and plants.
 *
 * @version 2019.02.21
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a anaconda will be created in any given grid position.
    private static final double ANACONDA_CREATION_PROBABILTY = 0.1;
    // The probability that a capybara will be created in any given grid position.
    private static final double CAPYBARA_CREATION_PROBABILTY = 0.3;
    // The probability that a frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILTY = 0.2;
    // The probability that a macaw will be created in any given grid position.
    private static final double MACAW_CREATION_PROBABILTY = 0.3;
    // The probability that a homo sapiens will be created in any given grid position.
    private static final double HomoSapienS_CREATION_PROBABILTY = 0.2;
    // The probability that a jaguar will be created in any given grid position.
    private static final double JAGUAR_CREATION_PROBABILTY = 0.2;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.5;
    // The different possibilities of weather in the simulation
    private static final String[] weatherOptions = {"mild ", "sunny", "rainy", "humid", "hot  "};
    // Sets the initial weather to be the first option in the array
    private static String currentWeather = weatherOptions[0];
    // New instance of randomiser
    protected static final Random rand = Randomizer.getRandom();
    // Current time of day in hours
    public static int timeInHours;

    // List of animals in the field.
    private List<Entities> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private static int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Capybara.class, Color.BLACK);
        view.setColor(Anaconda.class, Color.BLUE);
        view.setColor(Frog.class, Color.MAGENTA);
        view.setColor(Macaw.class, Color.RED);
        view.setColor(HomoSapiens.class, Color.YELLOW);
        view.setColor(Jaguar.class, Color.CYAN);
        view.setColor(Plant.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }

    /**
     *
     * @return The current weather at that time.
     */
    public static String getCurrentWeather() {
        return currentWeather;
    }

    /**
     * Changes the weather to a random element from the array weatherOptions.
     */
    private void changeWeather() {
        currentWeather = weatherOptions[rand.nextInt(weatherOptions.length)];

    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();

            delay(300);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep() {
        step++;

        if (step % 10 == 0) {
            changeWeather();
        }
        incrementTime();
        // Provide space for newborn animals.
        List<Entities> newEntitiess = new ArrayList<>();

        // Let all animals act.
        int maleFrogPopulation = 0, frogPopulation = 0;
        for (Iterator<Entities> it = animals.iterator(); it.hasNext(); ) {
            List<Object> adjacentEntitiess = new ArrayList<>();
            Entities entity = it.next();

            List<Location> adjacentEntitiesLocation = field.adjacentLocations(entity.getLocation());

            for (int i = 0; i < adjacentEntitiesLocation.size(); i++) {
                adjacentEntitiess.add((Entities) (field.getObjectAt(adjacentEntitiesLocation.get(i))));
            }
            boolean doesBreeding = false;
            while (adjacentEntitiess.contains(null)) {
                adjacentEntitiess.remove(null);
            }
            if (entity instanceof Animal) {
                Animal animal = (Animal) entity;

                for (Iterator<Object> it2 = adjacentEntitiess.iterator(); it2.hasNext(); ) {
                    Entities temp = (Entities) it2.next();
                    if (temp instanceof Animal) {
                        Animal tempEntities = (Animal) temp;
                        if ((animal.isMale() != tempEntities.isMale()) && (tempEntities.getClass() == animal.getClass())) {
                            doesBreeding = true;
                        }
                    }
                }
                if (animal instanceof Frog) {
                    frogPopulation++;
                    if (animal.isMale()) {
                        maleFrogPopulation++;
                    }
                }
            }

            entity.act(newEntitiess, doesBreeding);

            if (!entity.isAlive()) {
                it.remove();
            }
        }

        if (frogPopulation > 0) {
            balancePopulation(maleFrogPopulation, frogPopulation);
        }
        // Add the newly born anacondaes and capybaras to the main lists.
        animals.addAll(newEntitiess);

        view.showStatus(step, field);
    }

    /**
     * Balances the ratio of male/ female frogs in the simulation.
     * @param malePopulation Current population of male frogs in the simulation.
     * @param frogPopulation Current population of all frogs in the simulation
     */
    private void balancePopulation(int malePopulation, int frogPopulation) {
        Iterator<Entities> iterator = animals.iterator();
        while (((double) malePopulation / frogPopulation) >= 0.51 && iterator.hasNext()) {
            //current frog male -> sex change
            Entities entity = iterator.next();
            if (entity instanceof Animal) {
                Animal frog = (Animal) entity;
                if (frog.isMale() && (frog instanceof Frog)) {
                    ((Frog) frog).sexChange();
                }
            }
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with the different species.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= ANACONDA_CREATION_PROBABILTY) {
                    Location location = new Location(row, col);
                    Anaconda anaconda = new Anaconda(true, field, location);
                    animals.add(anaconda);
                } else if (rand.nextDouble() <= CAPYBARA_CREATION_PROBABILTY) {
                    Location location = new Location(row, col);
                    Capybara capybara = new Capybara(true, field, location);
                    animals.add(capybara);
                } else if (rand.nextDouble() <= FROG_CREATION_PROBABILTY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    animals.add(frog);
                } else if (rand.nextDouble() <= MACAW_CREATION_PROBABILTY) {
                    Location location = new Location(row, col);
                    Macaw macaw = new Macaw(true, field, location);
                    animals.add(macaw);
                } else if (rand.nextDouble() <= HomoSapienS_CREATION_PROBABILTY) {
                    Location location = new Location(row, col);
                    HomoSapiens homoSapiens = new HomoSapiens(true, field, location);
                    animals.add(homoSapiens);
                } else if (rand.nextDouble() <= JAGUAR_CREATION_PROBABILTY) {
                    Location location = new Location(row, col);
                    Jaguar jaguar = new Jaguar(true, field, location);
                    animals.add(jaguar);
                } else if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    animals.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * @return Current time in hours
     */
    public static int getTimeInHours() {
        return timeInHours;
    }

    public static void incrementTime() {
        if (timeInHours >= 23) {
            timeInHours = 0;
        } else {
            timeInHours++;
        }
    }

    /**
     * @return Number of steps
     */
    public static int getSteps() {
        return step;
    }

    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
