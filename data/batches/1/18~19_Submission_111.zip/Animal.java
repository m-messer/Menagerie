

import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.05
 */
public abstract class Animal extends Entities {

    //the age at which the animal can breed
    protected static int BREEDING_AGE;
    // The age to which an animal can live.
    protected static int MAX_AGE;
    // The likelihood of an animal breeding.
    protected static double BREEDING_PROBABILITY;
    // The maximum number of births.
    protected static int MAX_LITTER_SIZE;
    // number of steps a fox can go before it has to eat again.
    protected boolean male;
    // age of the animal at a given time
    protected int age;
    //whether or not the animal is infected with the disease
    protected boolean infected;
    //probability of getting infected
    protected static double INFECTION_PROBABILITY = 0.1;
    //the randomizer for random generation of variables etc
    protected static final Random rand = Randomizer.getRandom();
    //the number of steps that the animal has been infected for
    protected int infectedStep = 0;


    /**
     * Sets the parameters for each species
     * @param breedingAge min age at which breeding can occur
     * @param breedingProbability probability that animal will breed
     * @param maxAge max age of the animal
     * @param maxLitterSize max number of offspring per breeding cycle
     */
    protected void setParameters(int breedingAge, double breedingProbability, int maxAge, int maxLitterSize) {
        setBreedingAge(breedingAge);
        setBreedingProbability(breedingProbability);
        setMaxAge(maxAge);
        setMaxLitterSize(maxLitterSize);
    }

    /**
     * initialises the animal and sets sex
     * @param field current state of the field
     * @param location location where the animal is initialised
     */
    protected Animal(Field field, Location location) {
        super(field,location);
        male = rand.nextBoolean();
    }

    /**
     * @return the sex of the animal
     */
    public boolean isMale() {
        return male;
    }

    /**
     * randomly infect animals
     */
    protected void setRandomInfected() {
        this.infected = rand.nextDouble() <= INFECTION_PROBABILITY;
    }

    /**
     *
     * @return whether or not the animal is infected with the disease
     */
    protected boolean isInfected() {
        return this.infected;
    }

    /**
     * Infect the current animal
     */
    protected void setInfected() {
        this.infected = true;
    }

    /**
     *
     * @param BREEDING_PROBABILITY the probability that an animal will breed
     */
    protected void setBreedingAge(int BREEDING_PROBABILITY) {
        this.BREEDING_AGE = BREEDING_AGE;
    }

    /**
     * Sets the breeding probability of the current animal
     * @param BREEDING_PROBABILITY the probability that an animal will breed
     */
    protected void setBreedingProbability(double BREEDING_PROBABILITY) {
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
    }

    /**
     * Sets the max litter size of the current animal
     * @param MAX_LITTER_SIZE the maximum number of offspring for an animal per breeding cycle
     */
    protected void setMaxLitterSize(int MAX_LITTER_SIZE) {
        this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
    }

    /**
     * Sets the max age of the current animal
     * @param MAX_AGE the max age for the animal before it dies
     */
    protected void setMaxAge(int MAX_AGE) {
        this.MAX_AGE = MAX_AGE;
    }

    /**
     * @return age of the current animal at that time
     */
    public int getAge() {
        return age;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Increments the animal's age by one.
     */
    protected void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }



    /**
     * A animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }

    /**
     * Check whether or not any of the animals are to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newAnimal A list to return newly born animals.
     */
    protected void giveBirth(List<Entities> newAnimal) {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();

        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young;
                if (this instanceof Capybara) {
                    young = new Capybara(false, field, loc);
                    if (isInfected()) {
                        young.setInfected();
                    }
                    newAnimal.add(young);
                }if (this instanceof Frog) {
                    young = new Frog(false, field, loc);
                    if (isInfected()) {
                        young.setInfected();
                    }
                    newAnimal.add(young);
                }if (this instanceof Macaw) {
                    young = new Macaw(false, field, loc);
                    if (isInfected()) {
                        young.setInfected();
                    }
                    newAnimal.add(young);
                }
                if (this instanceof Anaconda) {
                    young = new Anaconda(false, field, loc);
                    if (isInfected()) {
                        young.setInfected();
                    }
                    newAnimal.add(young);
                }if (this instanceof HomoSapiens) {
                    young = new HomoSapiens(false, field, loc);
                    if (isInfected()) {
                        young.setInfected();
                    }
                    newAnimal.add(young);
                }if (this instanceof Jaguar) {
                    young = new Jaguar(false, field, loc);
                    if (isInfected()) {
                        young.setInfected();
                    }
                    newAnimal.add(young);
                }
        }
    }
}
