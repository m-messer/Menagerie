import java.util.List;
import java.util.Random;

/**
 * An abstract class to store methods and variables used by all of the subclasses (Animal, Prey, Predator and Plant)
 *
 * @version 2019.02.21
 */
public abstract class Entities {
    // Whether the entity is alive or not.
    protected boolean alive;
    // The entities field.
    protected Field field;
    // The entities position in the field.
    protected Location location;
    // The entities food level 
    protected int foodLevel;
    // a randomiser for the entity
    protected static final Random rand = Randomizer.getRandom();

     /** Create a new entity at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Entities(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    /**
     * Make this Entitiy more hungry. This could result in the Entitiy's death.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Indicate that the entity is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /***
     * An abstract method to breed for the animal
     * @return returns the number of entitys that need to be generated
     */
    abstract protected int breed() ;

    /**
     * An abstract method for the actions of the entities below 
     * @param newEntities a List of all entities
     * @param doesBreeding boolean to check if the entity can breed 
     */
    abstract protected void act(List<Entities> newEntities, boolean doesBreeding);


    /**
     * Check whether the entity is alive or not.
     *
     * @return true if the entity is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Return the entities location.
     *
     * @return The entities location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Return the entities field.
     *
     * @return The entities field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Place the entity at the new location in the given field.
     *
     * @param newLocation The entities new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

}
