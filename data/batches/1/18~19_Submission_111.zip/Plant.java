import java.util.List;

/**
 *A simple model of a Plant.
 *Plants can be eaten, grow and reproduce
 *@version 2019.02.21
 */
public class Plant extends Entities{
    //the food value of the plant
    private int foodValue = 10;
    //the number of steps that the plant has been alive for
    private int aliveSteps;
    //the probability of the plant to breed
    private double GROWTH_PROB = 0.4;

    /**
     *
     * @param field current state of the field
     * @param location location of the entity's initialisation
     */
    public Plant(Field field, Location location) {
        super(field,location);
        aliveSteps = 0;
        alive = true;
    }

    /**
     * Set's the food value of the plant based on the number of steps it has been since the plant has been alive
     */
    private void setFoodValue() {
        if (aliveSteps > 20) {
            setDead();
        } else if (aliveSteps >= 5) {
            foodValue++;
        }
    }

    /**
     * @return the food value
     */
    protected int getFoodValue(){
        return foodValue;
    }
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born rabbits.
     */
    private void giveBirth(List<Entities> newPlants)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(field, loc);
            newPlants.add(young);
        }
    }
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (rand.nextDouble() <= GROWTH_PROB) {
            births = rand.nextInt(30) + 1;
        }
        return births;
    }

    /**
     * Method for alive plants to act by giving birth and setting the foodvalue
     * @param newPlants the list of new plants to be given birth to
     * @param canBreed  the plant can breed
     */
    protected void act(List<Entities> newPlants,boolean canBreed)
    {
        if(isAlive()) {
            giveBirth(newPlants);
            setFoodValue();
        }
    }

}
