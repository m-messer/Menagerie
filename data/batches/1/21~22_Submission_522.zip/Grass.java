import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a grass.
 * Grasses breed and die.
 * 
 * @version 2022.03.01
 * Coursework 3
 */
public class Grass extends Plant
{
    // Characteristics shared by all grass (class variables).
    
    // Probability of breeding
    private static final double BREEDING_PROBABILITY = 0.001;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new grass. A grass may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
    }

    /**
     * This is what the grass does most of the time.
     * Gives birth.
     * @param newGrasses A list to return newly born grass.
     */
    public void act(List<Plant> newGrasses)
    {
        if(isAlive()) {
            giveBirth(newGrasses);
        }
    }

    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrasses A list to return newly born grass.
     */
    private void giveBirth(List<Plant> newGrasses)
    {
        // New grass are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrasses.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * Doubles the breeding probability if the weather is currently raining.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        double CURRENT_BREEDING_PROBABILITY;
        if(weather.equals("rain")){
            CURRENT_BREEDING_PROBABILITY = BREEDING_PROBABILITY * 2;
        }
        else{
            CURRENT_BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        }
        if(rand.nextDouble() <= CURRENT_BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
