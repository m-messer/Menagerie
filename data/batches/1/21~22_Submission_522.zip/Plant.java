import java.util.List;

/**
 * A class representing shared characteristics of plants.
 * 
 * @version 2022.03.01
 * Coursework 3
 */
public abstract class Plant
{
    // Whether the plant is alive or not.
    private boolean alive;
    // The weather
    protected String weather;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param weather - current weather, defaults to clear.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        weather = "clear";
        setLocation(location);
    }
    
    /**
     * Allows the weather to be updated from the simulator to match the current weather
     * allowing the animals to act accordingly.
     * @param simWeather - sets weather to the weather from the simulator
     */   
    protected void setWeather(String simWeather){
        weather = simWeather;
    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     */
    abstract public void act(List<Plant> newPlants);

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
}
