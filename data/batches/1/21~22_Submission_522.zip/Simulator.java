import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple Savannah simulator, based on a rectangular field
 * containing Lions, Hyenas, Warthogs, Zebras, Reedbucks and Grass.
 * 
 * @version 2022.03.01 (4)
 * Coursework 3
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // Random
    private static final Random rand = Randomizer.getRandom();
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a LION will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;
    // The probability that a ZEBRA will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.015;   
    // The probability that a WARTHOG will be created in any given grid position.
    private static final double WARTHOG_CREATION_PROBABILITY = 0.015;   
    // The probability that a HYENA will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.02;   
    // The probability that a REEDBUCK will be created in any given grid position.
    private static final double REEDBUCK_CREATION_PROBABILITY = 0.02;  
    // The probability that GRASS will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.05;
    // The probability that the weather will be RAIN for a given number of steps
    private static final double RAIN_PROBABILITY = 0.1;
    // The probability that the weather will be FOG for a given number of steps
    private static final double FOG_PROBABILITY = 0.1;
    // Probability an animal will get a DISEASE each step
    private static final double DISEASE_PROBABILITY = 0.000001;
    

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Current weather (set to clear initially)
    private String weather = "clear";

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Warthog.class, Color.PINK);
        view.setColor(Hyena.class, Color.YELLOW);
        view.setColor(Reedbuck.class, Color.BLUE);
        view.setColor(Grass.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Runs a random double against the weather probabilities listed above.
     */
    private void weatherCheck(){
        if(rand.nextDouble() <= FOG_PROBABILITY) {
            weather = "fog";
        }
        else if(rand.nextDouble() <= RAIN_PROBABILITY) {
            weather = "rain";
        }
        else{
            weather = "clear";
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        //Checks if it has been ten steps, if so then run a weatherCheck probability.
        //This allows weather to stay for a minimum of 10 steps at a change.
        if(step % 10 == 0){
            weatherCheck();
        }
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.setTime(step%48);
            animal.setWeather(weather);
            //Rolls a disease probability for the animal every step, if rolled true
            //gives the animal a disease.
            if(rand.nextDouble() <= DISEASE_PROBABILITY) {
                animal.giveDisease();
            }
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        List<Plant> newPlants = new ArrayList<>();        
        // Let all plants act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.setWeather(weather);
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals and plants to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);

        view.showStatus(step, field, weather);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, weather);
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= REEDBUCK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Reedbuck reedbuck = new Reedbuck(true, field, location);
                    animals.add(reedbuck);
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(true, field, location);
                    animals.add(hyena);
                }
                else if(rand.nextDouble() <= WARTHOG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Warthog warthog = new Warthog(true, field, location);
                    animals.add(warthog);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    plants.add(grass);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
