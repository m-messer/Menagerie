import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a warthog.
 * Warthogs age, move, breed, and die.
 * 
 * @version 2022.03.01 (3)
 * Coursework 3
 */
public class Warthog extends Animal
{
    // Characteristics shared by all warthogs (class variables).

    // The age at which a warthog can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a warthog can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a warthog breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The warthog's age.
    private int age;
    // Animal sex (0 for female, 1 for male)
    private int sex;
    // Disease level ( amt of steps before they die );
    private int diseaseLevel = 10;

    /**
     * Create a new warthog. A warthog may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the warthog will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Warthog(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        setSex(rand.nextInt(2));
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * Getters and setters for sex
     * @param y - sets sex to integer y
     */
    private void setSex(int y){
        sex = y;
    }
    public int getSex(){
        return sex;
    }

    /**
     * This is what the warthog does most of the time - it runs 
     * around. Sometimes it will breed or die of old age or disease.
     * @param newWarthogs A list to return newly born warthogs.
     */
    public void act(List<Animal> newWarthogs)
    {
        incrementAge();
        if(disease){
            incrementDisease();
        }
        if(isAlive()) {
            if(findMate()){
                giveBirth(newWarthogs);
            }            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the diseaseLevel. This could result in the warthog's death.
     */
    private void incrementDisease(){
        diseaseLevel--;
        if(diseaseLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increase the age.
     * This could result in the warthog's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Look for mates in a search region adjacent to the current location.
     * If a mate is found, return true
     * @return Whether there is a Warthog of the opposite sex in the area, if true
     * return true, otherwise false.
     */
    private Boolean findMate() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocationsWBorder(getLocation(),1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Warthog) {
                Warthog warthog = (Warthog) animal;
                if(warthog.getSex() != sex) { 
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this warthog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWarthogs A list to return newly born warthogs.
     */
    private void giveBirth(List<Animal> newWarthogs)
    {
        // New warthogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Warthog young = new Warthog(false, field, loc);
            newWarthogs.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A warthog can breed if it has reached the breeding age.
     * @return true if the warthog can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
