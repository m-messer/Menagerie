import java.util.List;

/**
 * A class representing shared characteristics of animals.
 * 
 * @version 2022.03.01 (3)
 * Coursework 3
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // Time (modulus of steps)
    protected int time;
    // The current weather
    protected String weather;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // Whether the animal has a disease or not
    protected boolean disease;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param weather - current weather, defaults to clear.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        weather = "clear";
        disease = false;
        setLocation(location);
    }
    
    /**
     * Allows the weather to be updated from the simulator to match the current weather
     * allowing the animals to act accordingly.
     * @param simWeather - sets weather to the weather from the simulator
     */
    protected void setWeather(String simWeather){
        weather = simWeather;
    }
    
    /**
     * Allows the time to be updated from the simulator to match the current time
     * allowing the animals to act accordingly.
     * @param simTime - sets time to time given from simulator
     */
    protected void setTime(int simTime){
        time = simTime;
    }
    
    /**
     * Sets the disease flag in the animal to true to indicate it is diseased.
     */
    protected void giveDisease(){
        disease = true;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
