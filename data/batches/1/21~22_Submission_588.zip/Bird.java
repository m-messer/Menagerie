import java.util.List;
import java.util.Random;
import java.util.HashMap;

import java.util.Iterator;

/**
 * An Bird class containing the information and 
 * functionalities of the Animal of type Bird
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
public class Bird extends Animal 
{
    // DEFAULT MAX AGE
    private static final int DEFAULT_MAX_AGE = 100;
    // DEFAULT MATE DISTANCE
    private static final int DEFAULT_MATE_DISTANCE = 5;
    // Age at which it can start to breed
    private static final int BREEDING_AGE = 15;
    // The likelihood of a Bird breeding.
    private static final double BREEDING_PROBABILITY = 0.65;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Value of slug
    private static final int SLUG_FOOD_VALUE = 15;
    //Value of insect
    private static final int FROG_FOOD_VALUE = 15;
    // MAX STEPS
    private static final int MAX_STEPS = 5;

    // MATE DISTANCE
    private static int mate_distance = DEFAULT_MATE_DISTANCE;
    // Max age that the Bird can live till
    private static int max_age = DEFAULT_MAX_AGE;

    public Bird(Field field, Location location)
    {
        super(field, location);
        //Decided gender of new Bird
        if(rand.nextInt(2) == 0) {
            isMale = true;
        } else {
            isMale = false;
        }

        //Set Foodlevel at creation
        foodlevel = 50;
    }

    public void act(List<Organism> newBirds, boolean isDay, HashMap<String, String> params)
    {
        // validation of object
        // check to see if object has field
        if(getField() == null) {
            setDead();
        }
        //check if object has a location on the field
        else if(getField().getObjectAt(getLocation()) == null) {
            setDead();
        }
        //check if the object has not been overridden
        else if(!getField().getObjectAt(getLocation()).equals(this)) {
            setDead();
        }

        // Update stats
        //Perform the act for the current turn
        incrementAge();
        incrementHunger();

        if(this.hasDeezZeezH) {
            // Check if they die due to Deez Zeez H
            if(rand.nextDouble() <= this.DEEZ_ZEEZ_H_DEATH_RATE) {
                // DIED
                setDead();
                return;
            }
        }

        //check act status
        // Bird has gone to sleep at night
        if(isDay == false) {
            return;
        }

        // perform act
        if(isAlive()){
            // When it meets other gender then give birth
            if(canBreed() && findMate()) {
                giveBirth(newBirds);
            }

            infect(rand);

            // Move towards a source of food if found.
            move();

        }
    }

    /**
     * Move Bird
     */
    private void move() {
        for(int steps = 0; steps < MAX_STEPS; steps++) {
            Location newLocation = findFood();

            if(newLocation == null) { 
                // No food found - try to move to a free location or on top of a plant.
                List<Location> adjLoc = getField().adjacentLocations(getLocation());
                for(Location options : adjLoc) {
                    if (getField().getObjectAt(options) == null) {
                        newLocation = options;
                        break;
                    }
                    else if(getField().getObjectAt(options) instanceof Plant) {
                        getField().clear(options);
                        newLocation = options;
                        break;
                    }
                }
            } else {
                break;
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
                break;
            }
        }
    }

    /**
     * Increases the age. This could result in the Bird dieing.
     */
    private void incrementAge()
    {
        age++;
        if(age > max_age) {
            setDead();
        }
    }

    /**
     * Increase the hunger. If no food, the Bird dies.
     */
    private void incrementHunger()
    {
        foodlevel--;
        if(foodlevel == 0) {
            setDead();
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Frog || organism instanceof Slug) {
                Animal prey = (Animal) organism;
                if(prey.isAlive()) { 
                    if(prey instanceof Frog) {
                        prey.setDead();
                        foodlevel += FROG_FOOD_VALUE;
                        return where;
                    } 
                    else if(prey instanceof Slug) {
                        prey.setDead();
                        foodlevel += SLUG_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Looks for a mate
     * @return True if a mate was
     */
    private boolean findMate() 
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocationsVar(getLocation(), mate_distance);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if (organism instanceof Bird) {
                Bird potentialMate = (Bird) organism;
                if(potentialMate.isAlive() && potentialMate.canBreed()) {
                    if(potentialMate.getIsMale() != this.isMale) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this Bird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBirds A list to return newly born Birds.
     * 
     */
    private void giveBirth(List<Organism> newBirds)
    {
        // New Birdes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bird young = new Bird(field, loc);
            diseaseImplementation(young, rand);
            field.place(young, loc);
            newBirds.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Check if the Bird can breed
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && foodlevel > 45;
    }
}
