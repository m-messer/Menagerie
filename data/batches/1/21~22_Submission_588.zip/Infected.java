/**
 * Infected class used as a key to be used for the colour in Simulator to represent infected animals
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
public class Infected {
    
}
