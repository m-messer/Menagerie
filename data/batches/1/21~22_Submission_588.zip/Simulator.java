import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing plants, insects, slugs, frogs, snakes and birds with boulders and ponds.
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a insect will be created in any given grid position.
    private static final double INSECT_CREATION_PROBABILITY = 0.42;
    // The probability that a slug will be crease in any given grid position
    private static final double SLUG_CREATION_PROIBAIBLITY = 0.56;
    // The probability that a Frog will be crease in any given grid position
    private static final double FROG_CREATION_PROIBAIBLITY = 0.26;
    // The probability that a Snake will be crease in any given grid position
    private static final double SNAKE_CREATION_PROIBAIBLITY = 0.04;
    // The probability that a Bird will be crease in any given grid position
    private static final double BIRD_CREATION_PROIBAIBLITY = 0.03;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.999;
    
    // The probability that a thunderstorm will occur
    private static final double THUNDERSTROM_PROBABILITY = 0.3;

    // The probability that the day will be sunny
    private static final double SUNNY_DAY_PROBABILITY = 0.5;

    // The probility that the day/night will have rain
    private static final double RAIN_PROBABILITY = 0.5;

    // List of animals in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // State of day or night
    private boolean isDay;
    // State of sunny day
    private boolean isSunny;
    // State of rain
    private boolean isRainy;
    // Location of Thunderstorm
    private List<Location> thunderstorm = new ArrayList<>();
    // List of thunderstrikes
    private List<Thunder> thunderstrikes = new ArrayList<>();
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Insect.class, Color.BLACK);
        view.setColor(Slug.class, Color.getHSBColor(0, 0, 0.35f));
        view.setColor(Frog.class, Color.getHSBColor(0.43f, 1, 0.35f));
        view.setColor(Snake.class, Color.getHSBColor(0.1f, 0.84f, 1));
        view.setColor(Bird.class, Color.MAGENTA);
        view.setColor(Thunder.class, Color.BLUE);
        view.setColor(Infected.class, Color.RED);
        view.setColor(Rock.class, Color.getHSBColor(0.05f, 1.0f, 0.22f));
        view.setColor(Pond.class, Color.getHSBColor(0.55f, 1.0f, 1.0f));
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(10000);
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runTillExtinction()
    {
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(10000);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public void simulateOneStep()
    {
        step++;

        //Simulate Thunder
        simulateThunder();
        

        int modSteps = (step % 50); // Modulus steps of 50

        //Determine if it is day or night
        dayNightCycle(modSteps);


        //Check for rain
        checkForRain(modSteps);

        // Provide space for newborn animals.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();

            // Create params values for the organisms to act
            HashMap<String, String> params = new HashMap<String,String>();
            params.put("isSunny", String.valueOf(isSunny));
            params.put("isRainy", String.valueOf(isRainy));

            // Check what terrain the organism is in
            if(organism.getLocation() != null) {
                params.remove("terrain");
                if ((organism.getLocation().getRow() < 31) && (organism.getLocation().getCol() < 41)) {
                    params.put("terrain", "rocky");
                } 
                else if((organism.getLocation().getRow() > 49) && (organism.getLocation().getCol() > 79)) {
                    params.put("terrain", "pond");
                } 
                else {
                    params.put("terrain", "normal");
                }
            }

            // Allow the organism to act
            organism.act(newOrganisms, getIsDay(), params);

            // Remove the dead organism
            if(! organism.isAlive()) {
                organism.setDead();
                it.remove();
            }
        }
               
        // Add the newly born forganisms to the main lists.
        organisms.addAll(newOrganisms);


        view.showStatus(step, field, isSunny, isRainy);
        delay(100);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        isDay = true;
        organisms.clear();
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field, isSunny, isRainy);
    }

    private void setFieldForRocks() 
    {    
        //Creation of Rocks
        int noOfRocks = 20;
        // Array containing the rock tiles
        List<Location> rockLocations = new ArrayList<Location>();

        Random rand = Randomizer.getRandom();

        // x: 0- 40, y: 0-30 
        // blocks can be either 2 or 3 in dimenstions
        // This generates an array for all the rocks to be created
        for(int i = 0; i<noOfRocks; i++) {
            int xVal = nextIntBetween(0,30,rand);
            int yVal = nextIntBetween(0,40,rand);
            int size;
            if(xVal == 0 || xVal == 29 || yVal == 0 || yVal == 39) {
                size = 2;
            } 
            else {
                size = nextIntBetween(2,4,rand);
            }

            boolean flagOverlap = false;
            // Check if there are rocks there already
            for(int xoffset = xVal; xoffset < (xVal+size); xoffset++) {
                for(int yoffset = yVal; yoffset < (yVal+size); yoffset++) {
                    Location current = new Location(xoffset,yoffset);
                    //System.out.print(xoffset);
                    //System.out.print(yoffset);
                    if ((rockLocations.size() > 0) && rockLocations.contains(current)) {
                        // retry init
                        flagOverlap = true;
                    }
                }
            }

            if (flagOverlap) {
                //retry
                i--;
            } 
            else {
                //Add rocks to array
                for(int xoffset = xVal; xoffset < xVal+size; xoffset++) {
                    for(int yoffset = yVal; yoffset < yVal+size; yoffset++) {
                        Location current = new Location(xoffset,yoffset);
                        rockLocations.add(current);
                    }
                }
            }
        }

        // Add rocks to Field
        for(Location rockloc : rockLocations) {
            field.place(new Rock(), rockloc);
        }
    }

    private void setFieldForPond() 
    { 
        //Creation of Rocks
        int noOfPond = 20;
        // Array containing the pond tiles
        List<Location> pondLocations = new ArrayList<Location>();

        Random rander = Randomizer.getRandom();

        // x: 0- 40, y: 0-30 
        // blocks can be either 2 or 3 in dimenstions
        // This generates an array for all the rocks to be created
        for(int i = 0; i< noOfPond; i++) {
            int xVal = nextIntBetween(50, 78, rander);
            int yVal = nextIntBetween(79,119,rander);

            int size;
            if(xVal == 50 || xVal == 77 || yVal == 79 || yVal == 118) {
                size = 2;
            } 
            else {
                size = nextIntBetween(2,4,rander);
            }

            boolean flagOverlap = false;
            // Check if there are rocks there already
            for(int xoffset = xVal; xoffset < (xVal+size); xoffset++) {
                for(int yoffset = yVal; yoffset < (yVal+size); yoffset++) {
                    Location current = new Location(xoffset,yoffset);
                    if ((pondLocations.size() > 0) && pondLocations.contains(current)) {
                        // retry init
                        flagOverlap = true;
                    }
                }
            }

            if (flagOverlap) {
                //retry
                i--;
            } 
            else {
                //Add pond to array
                for(int xoffset = xVal; xoffset < xVal+size; xoffset++) {
                    for(int yoffset = yVal; yoffset < yVal+size; yoffset++) {
                        Location current = new Location(xoffset,yoffset);
                        pondLocations.add(current);
                    }
                }
            }
        }

        // Add pond to Field
        for(Location pondloc : pondLocations) {
            field.place(new Pond(), pondloc);
        }
    }
    
    /**
     * Randomly populate the field with organisms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        setFieldForRocks();
        setFieldForPond();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // if the tile does not have anything on it then summon organisms
                if(field.getObjectAt(row, col) == null) {
                    if(rand.nextDouble() <= INSECT_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Insect insect = new Insect(field, location);
                        organisms.add(insect);
                    }
                    else if((rand.nextDouble()) <= SLUG_CREATION_PROIBAIBLITY) {
                        Location location = new Location(row, col);
                        Slug slug = new Slug(field, location);
                        organisms.add(slug);
                    }
                    else if((rand.nextDouble()) <= FROG_CREATION_PROIBAIBLITY) {
                        Location location = new Location(row, col);
                        Frog frog = new Frog(field, location);
                        organisms.add(frog);
                    }
                    else if((rand.nextDouble()) <= SNAKE_CREATION_PROIBAIBLITY) {
                        Location location = new Location(row, col);
                        Snake Snake = new Snake(field, location);
                        organisms.add(Snake);
                    }
                    else if((rand.nextDouble()) <= BIRD_CREATION_PROIBAIBLITY) {
                        Location location = new Location(row, col);
                        Bird bird = new Bird(field, location);
                        organisms.add(bird);
                    }
                    else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Plant plant = new Plant(field, location);
                        organisms.add(plant);
                    }
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     *  Gets the value of isDay
     * @return True if it is day
     */
    public boolean getIsDay() 
    {
        return this.isDay;
    }

    /**
     * Creates a random number of thunderstikes for the said thunderstorm
     */
    public void generateThunderstorm() 
    {
        Random rand = new Random();
        int noOfThunder = rand.nextInt(4);

        for(int i = 0; i < noOfThunder; i++) {
            thunderstorm.add(getRandomLocation());
        }

    }

    /**
     * Generates a random location within the field
     * @return Location of a random location on the field
     */
    public Location getRandomLocation()
    {
        Random rand = new Random();
        return new Location(rand.nextInt(field.getWidth()),rand.nextInt(field.getDepth()));
    }

    /**
     * Creates a 3x3 area to striek thunder
     * @param loc the center of the thunderstrike
     */
    private void thunderstike(Location loc) 
    {
        //check width is in range
        if((loc.getCol() < field.getWidth()) && (loc.getCol() > 0)) {
            //check height is in range
            if((loc.getRow() < field.getDepth()) && (loc.getRow() > 0)) {
                // Location is valid so generate the thunder strike
                List<Location> adjacentOptions = field.adjacentLocations(loc);
                adjacentOptions.add(loc);
                for(Organism organ : organisms) {
                    for(Location sLoc : adjacentOptions) {
                        // check if the organism is in the thunder stike region
                        if (organ.getLocation() == sLoc) {
                            organ.setDead();
                        }

                        Thunder thnder = new Thunder(field, sLoc);
                        thunderstrikes.add(thnder);
                        field.place(thnder, sLoc);
                    }
                } 
            }
        }
    }


    /**
     * Simulates when to create a thunder storm and when to perform a thunder strike
     */
    private void simulateThunder() 
    {
        if(thunderstorm.size() == 0) {
            // Thunder storm not active
            Random rand = Randomizer.getRandom();
            if(rand.nextDouble() <= THUNDERSTROM_PROBABILITY) {
                generateThunderstorm();
            }
        } 
        else {
            // Thunderstorm is active
            if ((step % 5) == 0) {
                //Do thunder strike
                thunderstike(thunderstorm.get(0));
                thunderstorm.remove(0);
            }
        }

        //Thunder duration
        for(Thunder thnder : thunderstrikes) {
            thnder.turn();
        }
    }

    /**
     * Determines if it is day or night
     * Upon a change, some variables are reset
     * 
     * @param modSteps the remainder from 50
     */
    private void dayNightCycle(int modSteps) 
    {
        if(modSteps < 25) {
            // steps in 0-24 are days
            isDay = true;

            if(modSteps == 0) {
                //reset rain variable
                isRainy = false;
                // Check for sunny day
                Random rand = Randomizer.getRandom();
                if(rand.nextDouble() <= SUNNY_DAY_PROBABILITY) {
                    isSunny = true;
                } 
                else {
                    isSunny = false;
                }
            }
        } 
        else {
            // steps 25-50 are nights
            isDay = false;
            //reset rain variable
            // Reset isSunny variable at night
            if(modSteps == 25) {
                isSunny = false;
                isRainy = false;
            }
        }
    }

    /**
     * Checks if there will be rain in during the day/night
     * @param modSteps the remainder from 50
     */
    private void checkForRain(int modSteps)
    {
        if((modSteps == 0) || (modSteps == 25)) {
            if(isSunny == false || isDay == false) {
                // Thunder storm not active
                Random rand = Randomizer.getRandom();
                if(rand.nextDouble() <= RAIN_PROBABILITY) {
                    isRainy = true;
                }
            }
        }
    }

    /**
     * nextInt code from java documentation
     * Retyped here since bluej's java version does not contain the function Random.Randomizer.nextInt(int origin, int bound)
     */
    private int nextIntBetween(int origin, int bound, Random rander) {
        int n = bound - origin;
        if (n > 0) {
            return rander.nextInt(n) + origin;
        }
        else {  // range not representable as int
            int r;
            do {
                r = rander.nextInt();
            } while (r < origin || r >= bound);
            return r;
        }
    }
}
