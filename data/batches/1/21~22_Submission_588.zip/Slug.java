import java.util.List;
import java.util.Random;
import java.util.HashMap;

import java.util.Iterator;

/**
 * An Slug class containing the information and 
 * functionalities of the Animal of type Slug
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
public class Slug extends Animal 
{
    // DEFAULT MAX AGE
    private static final int DEFAULT_MAX_AGE = 100;
    // DEFAULT MATE DISTANCE
    private static final int DEFAULT_MATE_DISTANCE = 4;
    // Age at which it can start to breed
    private static final int BREEDING_AGE = 1;
    // The likelihood of a Slug breeding.
    private static final double BREEDING_PROBABILITY = 0.075;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Value of plant
    private static final int PLANT_FOOD_VALUE = 5;
    // MAX STEPS
    private static final int MAX_STEPS = 2;

    // MATE DISTANCE
    private static int mate_distance = DEFAULT_MATE_DISTANCE;
    // Max age that the Slug can live till
    private static int max_age = DEFAULT_MAX_AGE;

    public Slug(Field field, Location location)
    {
        super(field, location);
        //Decided gender of new Slug
        if(rand.nextInt(2) == 0) {
            isMale = true;
        } else {
            isMale = false;
        }

        //Set Foodlevel at creation
        foodlevel = 75;
    }

    public void act(List<Organism> newSlugs, boolean isDay, HashMap<String, String> params)
    {
        // validation of object
        // check to see if object has field
        if(getField() == null) {
            setDead();
        }
        //check if object has a location on the field
        else if(getField().getObjectAt(getLocation()) == null) {
            setDead();
        }
        //check if the object has not been overridden
        else if(!getField().getObjectAt(getLocation()).equals(this)) {
            setDead();
        }

        //Update stats
        // If in rock terrain then max age increase
        if (params.containsKey("terrain")) {
            // perform actions depending on terrain
            switch(params.get("terrain")) {
                case "pond":
                    max_age = DEFAULT_MAX_AGE + 35;
                    break;
                default :
                    max_age = DEFAULT_MAX_AGE;
                    break;
            }

            if(age > max_age) {
                setDead();
            }
        }

        //Perform the act for the current turn
        incrementAge();
        incrementHunger();

        if(this.hasDeezZeezH) {
            // Check if they die due to Deez Zeez H
            if(rand.nextDouble() <= this.DEEZ_ZEEZ_H_DEATH_RATE) {
                // DIED
                setDead();
                return;
            }
        }

        // Check act status
        // Slug has gone to sleep at day
        if(isDay == true) {
            return;
        }

        // Perform act
        if(isAlive()){
            // When it meets other gender then give birth
            if(canBreed() && findMate()) {
                giveBirth(newSlugs);
            }

            infect(rand);
            
            // Check for action occured
            boolean actionOccured = false;

            // check for rain
            if ((actionOccured == false) && params.containsKey("isRainy")) {
                actionOccured = rainAction(Boolean.parseBoolean(params.get("isRainy")));
            }
            
            // If no action occured due to weather
            if(!actionOccured) {
                mate_distance = DEFAULT_MATE_DISTANCE;
            }

            // Move towards a source of food if found.
            move();

        }
    }

    /**
     * Move Slug
     */
    private void move() {
        for(int steps = 0; steps < MAX_STEPS; steps++) {
            Location newLocation = findFood();

            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
                break;
            }
        }
    }

    /**
     * Increases the age. This could result in the Slug dieing.
     */
    private void incrementAge()
    {
        age++;
        if(age > max_age) {
            setDead();
        }
    }

    /**
     * Increase the hunger. If no food, the Slug dies.
     */
    private void incrementHunger()
    {
        foodlevel--;
        if(foodlevel == 0) {
            setDead();
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Plant) {
                Plant plant = (Plant) organism;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodlevel += PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Looks for a mate
     * @return True if a mate was
     */
    private boolean findMate() 
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocationsVar(getLocation(), mate_distance);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if (organism instanceof Slug) {
                Slug potentialMate = (Slug) organism;
                if(potentialMate.isAlive() && potentialMate.canBreed()) {
                    if(potentialMate.getIsMale() != this.isMale) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this Slug is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSlugs A list to return newly born Slugs.
     * 
     */
    private void giveBirth(List<Organism> newSlugs)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Slug young = new Slug(field, loc);
            diseaseImplementation(young, rand);
            field.place(young, loc);
            newSlugs.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Check if the Slug can breed
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && foodlevel > 70;
    }

    /**
     * Rain perform
     */
    private boolean rainAction(Boolean isRainy) {
        if(isRainy) {
            mate_distance = DEFAULT_MATE_DISTANCE + 1;
            return true; // Action performed
        }
        return false; // Action not performed
    }
}