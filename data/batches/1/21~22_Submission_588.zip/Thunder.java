/**
 * Thunder class consins the information about thunder and stores the duration
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
public class Thunder {
    private int duration = 10;

    private Field field;
    private Location location;

    public Thunder(Field field, Location loc) {
        this.field = field;
        this.location = loc;
    }

    public void turn(){
        duration--;
        if (duration == 0) {
            field.clear(location);
        }
    }
}