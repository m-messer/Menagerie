import java.util.List;
import java.util.Random;

import java.util.HashMap;

/**
 * A Plant class containing the information and 
 * functionalities of the Organism of type Plant
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
public class Plant extends Organism{

    //Max age of plant
    private static final int MAX_AGE = 60;
    //Age when it can produce seeds
    private static final int MAX_LITTER_SIZE = 4;
    //Plant breeding age
    private static final int BREEDING_AGE = 1;
    //DEFUALT FERTILISATION PROBABILITY
    private static final double DEFAULT_FERTILISATION_PROBABILITY = 0.5;
    // plant fertilisation probability
    private static double fertilisation_probability = DEFAULT_FERTILISATION_PROBABILITY;
    // A shared random number generator to control fertilisation.
    private static final Random rand = Randomizer.getRandom();


    public Plant(Field field, Location location)
    {
        super(field, location);
    }

    public void act(List<Organism> newPlants, boolean isDay, HashMap<String, String> params)
    {
        // validation of object
        // check to see if object has field
        if(getField() == null) {
            setDead();
        }
        //check if object has a location on the field
        else if(getField().getObjectAt(getLocation()) == null) {
            setDead();
        }
        //check if the object has not been overridden
        else if(!getField().getObjectAt(getLocation()).equals(this)) {
            setDead();
        }

        incrementAge();

        // boolean to check if actions occured
        boolean actionOccured = false;

        // isSunny action
        if((actionOccured == false) && params.containsKey("isSunny")) {
            actionOccured = sunnyAction(Boolean.parseBoolean(params.get("isSunny")));
        }

        // isRainy action
        if((actionOccured == false) && params.containsKey("isRainy")) {
            actionOccured = rainyAction(Boolean.parseBoolean(params.get("isRainy")));
        }

        //action checker
        if(actionOccured == false) {
            fertilisation_probability = DEFAULT_FERTILISATION_PROBABILITY;
        }

        // if it is night time, DO NOT BREED
        if(isDay != true) {
            return;
        }

        if(isAlive()) {
            giveBirth(newPlants, isDay);
        } else {
            setDead();
        }
    }

    /**
     * Increase the age.
     * This could result in the plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     * @param isDay True if it is day
     */
    private void giveBirth(List<Organism> newPlants, boolean isDay)
    {
        // if it is night time, DO NOT BREED
        if(isDay != true) {
            return;
        }

        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.

        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(field, loc);
            field.place(young, loc);
            newPlants.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= fertilisation_probability) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A plant can breed if it has reached the breeding age.
     * @return true if the plant can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Action to perform if it is sunny
     * @param isSunny True if it is sunny
     * @return True if the action was performed
     */
    private boolean sunnyAction(boolean isSunny) {
        if(isSunny) {
            fertilisation_probability = DEFAULT_FERTILISATION_PROBABILITY + 0.4;
            return true;
        }
        return false;
    }

    /**
     * Action to perform if it is rainy
     * @param isRainy True it is rainy
     * @return True if the action was performed
     */
    private boolean rainyAction(boolean isRainy) {
        if(isRainy) {
            fertilisation_probability = DEFAULT_FERTILISATION_PROBABILITY + 0.4;
            return true;
        }
        return false;
    }

}
