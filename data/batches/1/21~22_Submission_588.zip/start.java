/**
 * A basic start function for the simulator
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
 
public class start {
    public static void main(String[] args) {
        Simulator sim = new Simulator();
        sim.simulate(10000);
    }
}
