import java.util.List;
import java.util.HashMap;

/**
 * A Class representing shared characteristics of living organisms in the field
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */

public abstract class Organism 
{
    // Is the organism alive?
    private boolean alive;
    // The organism's field
    private Field field;
    // The organism's position in the field
    private Location location;

    // The organisms age
    protected int age;

    public Organism(Field field, Location location) 
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.age = 0;
    }

    /**
     * Make the organism do an act for the turn
     * @param newOrganisms Alist for new born organisms (jide doesnt understand this yet)
     * @param isDay boolean value for is day or not
     * @param params HashMap<String,String> contains surplus paramaters for: "isSunny", "isRainy", "terrain"
     */
    abstract public void act(List<Organism> newOrganisms, boolean isDay, HashMap<String,String> params);

    /**
     * Check if the organism is alive
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism has died
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the Organism's field
     */
    protected Field getField()
    {
        return field;
    }
}
