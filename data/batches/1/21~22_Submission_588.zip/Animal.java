import java.util.List;
import java.util.Random;

import java.util.Iterator;

/**
 * Class to replace the old animal class.
 * It inherits from the Organism class
 *
 * @version 2022.02.27 (yyyy.mm.dd)
 */
public abstract class Animal extends Organism
{
    // Characteristics for all animal classes

    // Sex of animal
    protected boolean isMale;
    // food level
    protected int foodlevel;

    // probability of diseaseX
    protected final double DEEZ_ZEEZ_H_INFECTION_RATE = 0.01;
    protected final double DEEZ_ZEEZ_H_INHERIT = 0.02;
    protected final double DEEZ_ZEEZ_H_DEATH_RATE = 0.001;

    protected boolean hasDeezZeezH;

    public Animal(Field field, Location location) 
    {
        super(field, location);
    }

    public boolean getIsMale() 
    {
        return isMale;
    }

    public void giveDisease() {
        this.hasDeezZeezH = true;
    }

    /**
     * Check if the new born get Deez Zeez H
     * @param newBorn
     */
    protected void diseaseImplementation(Animal newBorn, Random rand) {
        if(this.hasDeezZeezH) {
            // Check if the new born will get the disease
            if(rand.nextDouble() <= this.DEEZ_ZEEZ_H_INHERIT) {
                // pass on the infection to young
                newBorn.giveDisease();
            }
        }
    }

    /**
     * Look for adjacent animals and then chance to spread the diesease to them
     */
    protected void infect(Random rand)
    {
        //Get adjacent animals
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // Traverse through nearby animals
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Animal) {
                Animal ani = (Animal) organism;
                //Chance to get infected by disease
                if(rand.nextDouble() <= this.DEEZ_ZEEZ_H_INFECTION_RATE) {
                    // Spread the disease onto the animal
                    ani.giveDisease();
                }
            }
        }
    }
}
