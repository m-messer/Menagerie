

/**
 * A class representing shared characteristics of organisms.
 *
 * @version 2019.2.21
 */
public class Organism {
    // Whether the Organism is alive or not.
    private boolean alive;
    // The Organism's field.
    private Field field;
    // The Organism's position in the field.
    private Location location;
    private int foodValue;

    /**
     * create a new organism at location in field.
     *
     * @param field  The field currently occupied.
     * @param location  The location within the field.
     */
    public Organism(Field field, Location location,int foodValue) {
        alive = true;
        this.field = field;
        this.location = location;
        this.foodValue = foodValue;
        changeLocation(location);
    }


    /**
     * Check whether the organism is alive or not.
     *
     * @return true if the organism is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field but no corpse created.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {

            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field, and create a corpse.
     */
    protected void setGrayed() {
         alive = false;
        if (location != null) {
            Death death =new Death(field,location,System.currentTimeMillis(),this.getFoodValue());
            field.place(death,location);
        }
    }



    /**
     * Return the organism's location.
     *
     * @return The organism's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Return the organism's field.
     *
     * @return The organism's field.
     */
    protected Field getField() {
        return field;
    }


    /**
     * Place the Organism at the new location in the given field.
     *
     * @param newLocation The Organism's new location.
     */
    protected void changeLocation(Location newLocation) {
        if (null!=getLocation())
        {
            getField().clear(getLocation());
        }

        this.location = newLocation;
        getField().place(this, newLocation);
    }

    /**
     * @return the food value
     */
    protected int getFoodValue(){
        return foodValue;
    }
}




