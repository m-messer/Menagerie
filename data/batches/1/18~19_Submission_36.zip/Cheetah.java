import java.util.List;
import java.util.Random;

/**
 * A simple model of a Cheetah.
 * Cheetah's age, move, breed, hunt and die.
 *
 * @version 2019/2/16
 */
public class Cheetah extends Animal {
    // The age at which a Cheetah can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Cheetah can live.
    private static final int MAX_AGE = 150;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The likelihood of a Cheetah breeding
    private static final double ORIGIN_BREEDING_PROBABILITY = 0.135;
    private static double ADJUSTED_BREEDING_PROBABILITY;
    // The likelihood of a Cheetah hunts a zebra when meet one.
    private static final double ORIGIN_ZEBRA_HUNT_PROBABILITY = 0.8;
    private static double ADJUSTED_ZEBRA_HUNT_PROBABILITY;
    // The likelihood of a Cheetah hunts a deer when meet one.
    private static final double ORIGIN_DEER_HUNT_PROBABILITY = 0.65;
    private static double ADJUSTED_DEER_HUNT_PROBABILITY;
    // The likelihood of a Cheetah hunts a hyena when meet one.
    private static final double ORIGIN_HYENA_HUNT_PROBABILITY = 0.3;
    private static double ADJUSTED_HYENA_HUNT_PROBABILITY;
    // The number of steps before Cheetah has to eat again.
    private static final int ORIGIN_FOOD_VALUE = 12;
    private static int ADJUSTED_FOOD_VALUE;
    // The probability that Cheetah will die suddenly (e.g. cold, disease, thirst).
    private static final double ORIGIN_DEATH_RATE = 0;
    private static double ADJUSTED_DEATH_RATE;
    
    private static int FOOD_VALUE = 150;
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new Cheetah. A Cheetah may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Cheetah will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param gender    The gender of the Cheetah.
     * @param isDisease If the Cheetah carries some disease.
     */
    public Cheetah(boolean randomAge, Field field, Location location, Gender gender,boolean isDisease) {

        super(randomAge, field, location, gender, isDisease, FOOD_VALUE);

    }

    /**
     * This is what Cheetahs do each step, find mate and find food
     * However still chances of contagion and sudden death
     * 
     * @param newCheetahs A list to return newly born Cheetahs
     * @param isDay     whether it is day or night
     * @param weather   The string representation of the weather that step
     */
    public void act(List<Animal> newCheetah, boolean isDay, String weather)
    {
        // adjusted the characteristics according to the weather.
        weatherImpact(weather);
        incrementAge(MAX_AGE);
        if (isSleep (isDay)){
            return;
        }
        if (isRest(weather)){
            return;
        }
        contagion();
        findEnemy();
        incrementHunger();
        illness();
        suddenDeath(ADJUSTED_DEATH_RATE);
        if(isAlive()){
            if(findMate()){
                giveBirth(newCheetah);
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null){
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // see if its possible to move.
            if(newLocation != null){
                changeLocation(newLocation);
            }
            else{
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     *  Determine whether the target object is Cheetah's food.
     *  @param object The target object.
     *  @return whether the target object is its food.   
     */
    public boolean isFood(Object object) {

        if (object instanceof Zebra && rand.nextDouble()<= ADJUSTED_ZEBRA_HUNT_PROBABILITY)  {
            return true;
            
        }
        else if(object instanceof Deer && rand.nextDouble()<= ADJUSTED_DEER_HUNT_PROBABILITY){
            return true;
        }
        else if(object instanceof Hyena && rand.nextDouble()<= ADJUSTED_HYENA_HUNT_PROBABILITY){
            return true;
        }
        return false;

    }


    /**
     * Check whether or not this cheetah is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newCheetah A list to return newly born cheetah.
     */
    public void giveBirth(List<Animal> newCheetah) {
        // New cheetah are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            // Generate random gender.
            Gender gender= Randomizer.getGender();
            // Generate if the disease old Cheetah carries will infect the new born Cheetah.
            boolean   isDisease =false;
            if (this.isDisease()){
                isDisease = Randomizer.getRandomIsDisease();
            }

            Cheetah young = new Cheetah(false, field, loc, gender,isDisease);
            newCheetah.add(young);
        }
    }

    /**
     * Determine whether the target object is Cheetah's mate.
     * Which means same species and opposite gender.
     *
     * @param object The target object.
     * @return result Whether the target object is its mate
     */
    public boolean isMate(Object object) {
        boolean result = false;

        if (object instanceof Cheetah) {
            Cheetah cheetah = (Cheetah) object;
            if (cheetah.isAlive() && cheetah.canBreed(BREEDING_AGE) && !(cheetah.getGender().getName().equals(this.getGender().getName()))) {
                result = true;
            }
        }

        return result;
    }

    /**
     * Adjust the values according to the weather.
     *
     * @param weather The String representation of the weather that step.
     */
    public void weatherImpact (String weather){
        double factor = 1 ;
        if (weather.equals("Sunny")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY;
            ADJUSTED_HYENA_HUNT_PROBABILITY = ORIGIN_HYENA_HUNT_PROBABILITY;
            ADJUSTED_DEER_HUNT_PROBABILITY = ORIGIN_DEER_HUNT_PROBABILITY;
            ADJUSTED_ZEBRA_HUNT_PROBABILITY = ORIGIN_ZEBRA_HUNT_PROBABILITY;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE;
        }
        else if (weather.equals("Drought")){
            factor = 0.7;
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * factor;
            ADJUSTED_HYENA_HUNT_PROBABILITY = ORIGIN_HYENA_HUNT_PROBABILITY * factor;
            ADJUSTED_DEER_HUNT_PROBABILITY = ORIGIN_DEER_HUNT_PROBABILITY * factor;
            ADJUSTED_ZEBRA_HUNT_PROBABILITY = ORIGIN_ZEBRA_HUNT_PROBABILITY * factor;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE + 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.01;
        }
        else if (weather.equals("Rain")){
            factor = 0.6;
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * factor;
            ADJUSTED_HYENA_HUNT_PROBABILITY = ORIGIN_HYENA_HUNT_PROBABILITY * factor;
            ADJUSTED_DEER_HUNT_PROBABILITY = ORIGIN_DEER_HUNT_PROBABILITY * factor;
            ADJUSTED_ZEBRA_HUNT_PROBABILITY = ORIGIN_ZEBRA_HUNT_PROBABILITY * factor;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE + 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.03;
        }     
        else if (weather.equals("Snow")){
            factor = 0.5;
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * factor;
            ADJUSTED_HYENA_HUNT_PROBABILITY = ORIGIN_HYENA_HUNT_PROBABILITY * factor;
            ADJUSTED_DEER_HUNT_PROBABILITY = ORIGIN_DEER_HUNT_PROBABILITY * factor;
            ADJUSTED_ZEBRA_HUNT_PROBABILITY = ORIGIN_ZEBRA_HUNT_PROBABILITY * factor;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE - 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.01;
        
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed() {
        int births = 0;
        if (canBreed(BREEDING_AGE) && rand.nextDouble() <= ADJUSTED_BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     *  Determine whether the target object is Cheetah's enemy.
     *  @param object The target object.
     *  @return whether the target object is its enemy.  
     */
    public  boolean isEnemy(Object object){
        if(this.getGender()==Gender.MALE){
         if(object instanceof Cheetah){
             Cheetah Cheetah = (Cheetah)object;
             if(Cheetah.getGender()==Gender.MALE){
                 return true;
                }
            }
        }
        return false;
    
    }
    
    /**
     * To determine whether cheetahs will have a rest in Rain.
     * 
     * @param weather To return thr weather.
     */
    @Override
    public boolean isRest(String weather){
        boolean result = false;
        if (weather.equals("Sunny")){
        }
        else if (weather.equals("Drought")){
        }
        else if (weather.equals("Rain")){
            if (Randomizer.getRandom().nextInt(10)>3){
                result = true;
            }
        }
        else if (weather.equals("Snow")){
        }
        return result;
    }
    
    /**
     * Adjust the death rate according to the disease status.
     */
    public void illness()
    {
        if(isDisease()){
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.05;
        }
    }
}


 