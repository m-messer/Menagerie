import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of plants
 *
 * @version 2019.02.11
 */
public class Plants extends Organism {

    // The likelihood of a plant breeding.
    private static final double ORIGIN_BREEDING_PROBABILITY = 0.08;
	private static double ADJUSTED_BREEDING_PROBABILITY;
	
	private static final int FOOD_VALUE = 30;
	// Maximum number of births
	private static final int MAX_LITTER_SIZE = 3;
	// The age of the plant
	private int age;
	// The maximum age of the plant
	private static final int MAX_AGE = 3;


    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new Plant. A plant will be created with age zero.
	 *
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
     */
    public Plants(Field field, Location location) {
        // initialise instance variables
		super(field, location,FOOD_VALUE);
        //age = 0;
    }
	
	/**
	 * This is what Plants do each step, increment age and give birth.
	 * 
	 * @param newPlants A list to return newly born Plants
	 * @param weather   The string representation of the weather that step
	 */
	public void act(List<Plants> newPlants, String weather)
    {
       incrementAge();
        if(isAlive()) {
            giveBirth(newPlants);
            weatherImpact(weather);
        }
    }
    
	/**
	 * increment the age of the plant each step
	 * Plants will be dead when reach max age. 
	 */
    private void incrementAge(){
        age++;
        if(age>MAX_AGE){
            setDead();
        }
    }
    
    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newPlants A list to return newly born plants.
     */
    public void giveBirth(List<Plants> newPlants) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = null;
        int births = breed();
        if (null != field) {
            free = field.getFreeAdjacentLocations(getLocation());
        }


        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plants plants = new Plants(field, loc);
            newPlants.add(plants);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    public int breed() {
        int births = 0;
        if (rand.nextDouble() <= ADJUSTED_BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

	/**
	 * Adjust the values according to the weather.
	 *
	 * @param weather The String representation of the weather that step.
	 */
	public void weatherImpact (String weather){
		if (weather.equals("Sunny")){
			ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY;
		}
		if (weather.equals("Drought")){
			ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.3;
		}
		if (weather.equals("Rain")){
			ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 1.1;
		}
		if (weather.equals("Snow")){
			ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.3;
		}
	}
}