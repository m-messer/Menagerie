import java.util.List;
import java.util.Random;

/**
 * A simple model of a zebra.
 * zebras age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Zebra extends Animal {
    // The age at which a Zebra can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 75;
    // The likelihood of a zebra breeding.
    private static final double ORIGIN_BREEDING_PROBABILITY = 0.27;
    private static double ADJUSTED_BREEDING_PROBABILITY;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The probability that Zebra will die suddenly (e.g. cold, disease, thirst).
    private static final double ORIGIN_DEATH_RATE = 0;
    private static double ADJUSTED_DEATH_RATE;
	// The number of steps before Zebra has to eat again.
    private static final int ORIGIN_FOOD_VALUE = 12;
    private static int ADJUSTED_FOOD_VALUE;
    
    private static int FOOD_VALUE = 100;
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the zebra will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
	 * @param gender    The gender of the Zebra.
	 * @param isDisease If the Zebra carries some disease.
     */
    public Zebra(boolean randomAge, Field field, Location location,Gender gender,boolean isDisease) {

        super(randomAge, field, location, gender,isDisease, FOOD_VALUE);
        
    }

	/**
	 * This is what Zebras do each step, find mate and find food
	 * However still chances of contagion and sudden death
	 * 
	 * @param newZebras A list to return newly born Zebras
	 * @param isDay     whether it is day or night
	 * @param weather   The string representation of the weather that step
	 */
    public void act(List<Animal> newZebras, boolean isDay, String weather)
    {
       // adjusted the characteristics according to the weather.
        weatherImpact(weather);
        incrementAge(MAX_AGE);
        
        contagion();
        if (isSleep (isDay)){
            return;
        }
        if (isRest(weather)){
            return;
        }
        incrementHunger();
        illness();
        suddenDeath(ADJUSTED_DEATH_RATE);
        if(isAlive()){
            if(findMate()){
                giveBirth(newZebras);
            }
			// Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null){
				// No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null){
                changeLocation(newLocation);
            }
            else{
				// Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Check whether or not this zebra is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newZebras A list to return newly born zebras.
     */
    public void giveBirth(List<Animal> newZebras) {
        // New zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);

            Gender gender = Randomizer.getGender();
            
            boolean   isDisease =false;
            if (this.isDisease()){
                isDisease = Randomizer.getRandomIsDisease();
            }
            Zebra young = new Zebra(false, field, loc, gender,isDisease);
            newZebras.add(young);
        }
    }

	/**
	 *	Determine whether the target object is Zebra's food.
	 *  @param object The target object.
	 *  @return whether the target object is its food. 	 
	 */
    public boolean isFood(Object object) {

        if (object instanceof Plants) {
			return true;
        }

        return false;
    }

	/**
	 * Determine whether the target object is Zebra's mate.
	 * Which means same species and opposite gender.
	 *
	 * @param object The target object.
	 * @return result Whether the target object is its mate
	 */
    public boolean isMate(Object object) {
        boolean result = false;

        if (object instanceof Zebra) {
            Zebra zebra = (Zebra) object;
            if (zebra.isAlive() && zebra.canBreed(BREEDING_AGE) && !(zebra.getGender().getName().equals(this.getGender().getName()))) {
                result = true;
            }

        }
        return result;
    }
    
	/**
	 * Adjust the values according to the weather.
	 *
	 * @param weather The String representation of the weather that step.
	 */
    public void weatherImpact (String weather){
        
        if (weather.equals("Sunny")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE;
        }
        else if (weather.equals("Drought")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.7;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE + 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.01;
        }
        else if (weather.equals("Rain")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.6;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE + 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.03;
        }     
        else if (weather.equals("Snow")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.5;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE - 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.01;
        }
    }

	/**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed() {
        int births = 0;
        if (canBreed(BREEDING_AGE) && rand.nextDouble() <= ADJUSTED_BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
	/**
	 * Adjust the death rate according to the disease status.
	 */
    public void illness()
    {
        if(isDisease()){
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.05;
        }
    }
}
