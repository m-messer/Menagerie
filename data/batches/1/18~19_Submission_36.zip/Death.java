/**
 * A simple model of corpses and death.
 *
 * @version 2018.2.21
 */
public class Death  extends Organism {

    private  long deathTime;
    /**
     * Create a new corpse.
     *
     * @param field      The field currently occupied.
     * @param location   The location within the field
     * @param deathTime  The time since the death
     */
    public Death(Field field, Location location,long deathTime,int foodValue) {
        super(field, location,foodValue);
        this.deathTime = deathTime;
    }


	/**
	 * @return deathTime
	 */
    public long getDeathTime() {
        return  this.deathTime;
    }
}
