
/**
 * Enumeration class Sex - shows the gender of species, male or female.
 *
 * @version 2019.2.21
 */
public enum Gender {

    MALE("male"), FEMALE("female");

    private String name;

    /**
     * Create gender of the animal.
     *
     * @param name The string name of the animal.
     */
    private Gender(String name) {
        this.name = name;
    }

    /**
     * @return the name of the animal.
     */
    public String getName() {
        return this.name;
    }

}
