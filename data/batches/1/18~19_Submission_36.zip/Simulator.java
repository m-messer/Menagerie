


import java.util.*;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing five differenr species.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that organisms will be created in any given grid position.
    private static final double PLANTS_CREATION_PROBABILITY = 0.07;
    private static final double ZEBRA_CREATION_PROBABILITY = 0.06;
    private static final double DEER_CREATION_PROBABILITY = 0.06;
    private static final double HYENA_CREATION_PROBABILITY = 0.07;
    private static final double CHEETAH_CREATION_PROBABILITY = 0.055;
    private static final double LION_CREATION_PROBABILITY = 0.055;
    // The probability that organisms will be created in any free grid position per step.
    private static final double PLANTS_CREATION_PROBABILITY_PER_TURN = 0.04;

    // List of animals in the field.
    private List<Organism> organismList;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current weather of the simulation.
    private Weather weather;
    // The string representation of the weather.
    private String todayWeather;

    private boolean isDay = true;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organismList = new ArrayList<>();
        weather = new Weather();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.putColor(Zebra.class.getSimpleName(),false,new Color(255,140,0));
        view.putColor(Lion.class.getSimpleName(), false, new Color(255,182,193));
        view.putColor(Hyena.class.getSimpleName(), false,new Color(151,96,207));
        view.putColor(Deer.class.getSimpleName(),false, new Color(3,103,213));
        view.putColor(Cheetah.class.getSimpleName(),false, new Color(152,55,65));
        view.putColor(Plants.class.getSimpleName(), true, Color.GREEN);
        view.putColor(Plants.class.getSimpleName(), false, Color.GREEN);
        view.putColor(Death.class.getSimpleName(),true,Color.GRAY);
        view.putColor(Death.class.getSimpleName(),false,Color.GRAY);

        todayWeather = "Sunny";
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {

            simulateOneStep();
            //delay(600);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animals
     */
    public void simulateOneStep() {
        // determine whether is the step to change status of time or weather.
        if (step % 10 == 6){
            isDay = false;
        }
        if (step % 10 == 0){
            todayWeather = weather.getWeather();
            isDay = true;
        }

        step++;

        // Provide space for newborn animals.
        List<Animal> newOrganismList = new ArrayList<>();
        List<Plants> newPlantsList = new ArrayList<>();
        // Let all animals act.
        for (Iterator<Organism> it = organismList.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            Animal animal = null;

            if (organism instanceof Animal) {
                animal = (Animal) organism;

                if (!animal.isAlive()) {
                    it.remove();

                } 
                else {
                    animal.act(newOrganismList, isDay, todayWeather);
                }

            }
            if (organism instanceof Plants) {
                Plants plants = (Plants) organism;
                if (!plants.isAlive()) {
                    it.remove();
                    
                } 
                else {
                    plants.act(newPlantsList, todayWeather);
                }
            }
        }
        // generate new plant each step.
        populatePlant();

        organismList.addAll(newOrganismList);
        organismList.addAll(newPlantsList);

        view.showStatus(step, field, todayWeather, isDay);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        organismList.clear();
        populate();
        String  environment= "now is"+ (isDay?" day":" night")+"   "+"weather:" +weather;
        // Show the starting state in the view.
        view.showStatus(step , field, todayWeather, isDay);
    }

    /**
     * Randomly populate the field with organisms.
     */

    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {

                Location location = new Location(row, col);

                Organism organism = null;

                if (rand.nextDouble() <= PLANTS_CREATION_PROBABILITY) {

                    organism = new Plants(field, location);

                } else if (rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {

                    organism = new Zebra(true, field, location, Randomizer.getGender(),Randomizer.getRandomIsDisease());

                
                    } else if (rand.nextDouble() <= DEER_CREATION_PROBABILITY) {

                    organism = new Deer(true, field, location, Randomizer.getGender(),Randomizer.getRandomIsDisease());

                } else if (rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {

                    organism = new Hyena(true, field, location, Randomizer.getGender(),Randomizer.getRandomIsDisease());

                } else if (rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {

                   organism = new Cheetah(true, field, location, Randomizer.getGender(),Randomizer.getRandomIsDisease());

                } 
                else if (rand.nextDouble() <= LION_CREATION_PROBABILITY) {

                    organism = new Lion(true, field, location, Randomizer.getGender(),Randomizer.getRandomIsDisease());

                }

                if (null != organism) {
                    organismList.add(organism);
                }

                // else leave the location empty.
            }
        }
    }
    
    /**
     * Randomly populate plants in the free locations.
     */
    private void populatePlant() {
        Random rand = Randomizer.getRandom();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {

                Location location = new Location(row, col);

                Organism organism = null;


                if (rand.nextDouble() <= PLANTS_CREATION_PROBABILITY_PER_TURN) {

                    organism = new Plants(field, location);
                    organismList.add(organism);
                } 
            }
        }
    }
    
    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
