import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Organism {
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    private boolean  isDisease;
    private Gender gender;
    private int age;
    private int foodLevel;

    /**
     * Create a new animal at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param gender    The gender of the animal.
     * @param isDisease If the animal carries some disease.
     * @param randomAge If true, the animal will have a random age.
     *
     */
    public Animal(boolean randomAge, Field field, Location location, Gender gender,
                  boolean isDisease,int foodValue) {
        super(field, location,foodValue);
        this.gender = gender;
        this.isDisease = isDisease;
        if (randomAge) {
            age = rand.nextInt(10);
            foodLevel = rand.nextInt(20);
        } else {
            age = 0;
            foodLevel = 10;
        }
    }

    /**
     * reset the food level of the animal.
     */
    public void setFoodLevel(int foodLevel) {
        this.foodLevel = foodLevel;
    }
    
    /**
     *  Determine whether the target object is Animal's food.
     *  @param object The target object.
     *  @return whether the target object is its food.   
     */
    abstract public boolean isFood(Object object);
    
    /**
     * Determine whether the target object is Animal's mate.
     * Which means same species and opposite gender.
     *
     * @param object The target object.
     * @return result Whether the target object is its mate
     */
    abstract public boolean isMate(Object animal);

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param A list to return newly born animals.
     */
    abstract public void giveBirth(List<Animal> animalList);

    /**
     * @return return false if the animal has no enemy(no isEnemy method in the subclass)
     */
    public boolean isEnemy(Object object) {

        return false;
    }

    /**
     * @return return false if no isRest method in the subclass
     */
    public boolean isRest(String weather) {

        return false;
    }

    /**
     * increment the age of the animal by one
     * set grayed if reaches max age
     * 
     * @param maxAge   maximun age of the animal.
     */
    protected void incrementAge(int maxAge) {
        age++;
        if (age > maxAge) {
          setGrayed();
        }
    }
    
    /**
     * reduce the food level by one.
     * set grayed if food level reaches zero.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setGrayed();
        }
    }
    
    /**
     * set grayed if get the probability of sudden death.
     *
     * @param deathRate  the probability of sudden death.
     */
    protected void suddenDeath(double deathRate)
    {
        if(rand.nextDouble() <= deathRate){
            setGrayed();
        }
    }
    
    /**
     * check if the age of the animal is larger than the breeding age.
     *
     * @param breedingAge  the breeding age of the animal
     * @return whether the animal can breeding.
     */
    protected boolean canBreed(int breedingAge) {
        return age >= breedingAge;
    }
    
    /**
     * @return the gender of the animal
     */
    protected Gender getGender(){
        return gender;
    }
    
    /**
     * Look for mate adjacent to the current location.
     * Only the first live foods is eaten.
     *
     * @return true mate was found, or false if it wasn't.
     */
    protected boolean findMate() {
        boolean result = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (isMate(animal)) {
                result = true;
                break;
            }
        }
        return result;
    }
    
    /**
     * Print the details of the animals
     */
    @Override
    public String toString() {
        return "Animal{" +
                "isDisease=" + isDisease +
                ", gender=" + gender +
                '}';
    }

    /**
     * Look for foods adjacent to the current location.
     * Only the first live foods is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if (isFood(object)) {
                Organism organism = (Organism) object;
                if (organism.isAlive()) {
                    this.setFoodLevel(organism.getFoodValue());
                    organism.setDead();
                    return where;
                    
                }
            }

        }
        
        return null;
    }

    /**
     * This is what the animals do most of the time: it hunts for
     * other animals. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param animalList    A list to return newly born animals.
     * @param isDay         To determine whether it is day or night
     * @param weather       Return the weather.
     */
    abstract public void act(List<Animal> animalList, boolean isDay, String wheater);
    
    /**
     * Animals will spread the disease randomly if they meet other animals.
     */
    protected void contagion() {

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while (it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);

            if (object instanceof  Animal)
            {
                Animal animal = (Animal) object;

                if(this.isDisease()){
                    animal.setDisease(Randomizer.getRandomIsDisease());
                } else if (animal.isDisease()){
                    this.setDisease(Randomizer.getRandomIsDisease());
                }

            }
        }
    }

   
    /**
     * Most animal sleeps at night, except hyena which has its own method isSleep under the subclass.
     *
     * @param isDay  a boolean represent of day or night.
     * @return a boolean represent whether the animal will sleep.
     */
    protected boolean isSleep(boolean isDay) {

        return !isDay;
    }

    /**
     * Look for enemy adjacent to the current location.
     * Only the first enemy find will fight.
     */
    protected void findEnemy() {

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while (it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);

            if (isEnemy(object)) {
                Animal animal = (Animal) object;
                int randomInt = new Random().nextInt(10);

                if (randomInt <= 3) {
                    this.setGrayed() ;
                } 
                else if(randomInt <= 6){
                    animal.setGrayed();
                }

                break;
            }
        }

    }
    
    /**
     * @return if the animal carries disease.
     */
    public boolean isDisease() {
        return isDisease;
    }

    /**
     * Set the disease status of the animal.
     *
     * @param disease  if the animal has diaease
     */
    public void setDisease(boolean disease) {
        isDisease = disease;
    }
}
