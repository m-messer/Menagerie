 import java.util.List;
 import java.util.Random;

 /**
 * A simple model of a Deer.
 * Deer's age, move, breed and die.
 *
 * @version 2019.2.20
 */
public class Deer extends Animal {
    // The age at which a Deer can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a Deer can live.
    private static final int MAX_AGE = 80;
    // The number of steps before Deer has to eat again.
    private static final int ORIGIN_FOOD_VALUE = 12;
    private static int ADJUSTED_FOOD_VALUE; 
    // The likelihood of a deer breeding.
    private static final double ORIGIN_BREEDING_PROBABILITY = 0.29;
    private static double ADJUSTED_BREEDING_PROBABILITY; 
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The probability that Deer will die suddenly (e.g. cold, disease, thirst).
    private static final double ORIGIN_DEATH_RATE = 0;
    private static double ADJUSTED_DEATH_RATE;
    
    private static final Random rand = Randomizer.getRandom();
    private static int FOOD_VALUE = 150;
    
    /**
     * Create a new Deer. A Deer may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Deer will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param gender    The gender of the Deer.
     * @param isDisease If the Deer carries some disease.
     */
    public Deer(boolean randomAge, Field field, Location location, Gender gender,boolean isDisease) {

        super(randomAge, field, location, gender,isDisease,FOOD_VALUE);

    }
    
    /**
     * This is what deers do each step, find mate and find food
     * However still chances of contagion and sudden death
     * 
     * @param newDeers  A list to return newly born deers
     * @param isDay     whether it is day or night
       * @param weather   The string representation of the weather that step
     */
    public void act(List<Animal> newDeers, boolean isDay, String weather)
    {
        // adjusted the characteristics according to the weather.
        weatherImpact(weather);
        incrementAge(MAX_AGE);
        
        contagion();
        if (isSleep (isDay)){
            return;
        }
        if (isRest(weather)){
            return;
        }
        incrementHunger();
        illness();
        suddenDeath(ADJUSTED_DEATH_RATE);
        if(isAlive()){
            if(findMate()){
                giveBirth(newDeers);
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null){
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null){
                changeLocation(newLocation);
            }
            else{
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     *  Determine whether the target object is Deer's food.
     *  @param object The target object.
     *  @return whether the target object is its food.   
     */
    public boolean isFood(Object object) {

        if (object instanceof Plants) {
            return true;
            
        }

        return false;

    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed() {
        int births = 0;
        if (canBreed(BREEDING_AGE) && rand.nextDouble() <= ADJUSTED_BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newDeers A list to return newly born deers.
     */
    public void giveBirth(List<Animal> newDeers) {
        // New deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);

            Gender gender = Randomizer.getGender();

            boolean   isDisease =false;
            if (this.isDisease()){
                isDisease = Randomizer.getRandomIsDisease();
            }
            Deer young = new Deer(false, field, loc, gender,isDisease);
            newDeers.add(young);
        }
    }

    /**
     * Determine whether the target object is Deer's mate.
     * Which means same species and opposite gender.
     *
     * @param object The target object.
     * @return result Whether the target object is its mate
     */
    public boolean isMate(Object object) {
        boolean result = false;

        if (object instanceof Deer) {
            Deer deer = (Deer) object;
            if (deer.isAlive() && deer.canBreed(BREEDING_AGE) && !(deer.getGender().getName().equals(this.getGender().getName()))) {
            //    System.out.println("deer mate success");
                result = true;
            }
        }
        return result;
    }
    
    /**
     * Adjust the values according to the weather.
     *
     * @param weather The String representation of the weather that step.
     */
    public void weatherImpact (String weather){
        if (weather.equals("Sunny")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE;
        }
        else if (weather.equals("Drought")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.7;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE + 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.01;
        }
        else if (weather.equals("Rain")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.6;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE + 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.03;
        }     
        else if (weather.equals("Snow")){
            ADJUSTED_BREEDING_PROBABILITY = ORIGIN_BREEDING_PROBABILITY * 0.5;
            ADJUSTED_FOOD_VALUE = ORIGIN_FOOD_VALUE - 5;
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.01;
        }
    }
    
    /**
     * Adjust the death rate according to the disease status.
     */
    public void illness()
    {
        if(isDisease()){
            ADJUSTED_DEATH_RATE = ORIGIN_DEATH_RATE + 0.05;
        }
    }
}
