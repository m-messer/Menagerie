import java.util.Random;
import java.util.ArrayList;
/**
 * This class stores different types if weathers and generate random weather when need.
 *
 * @version 2019.2.21
 */
public class Weather
{
    private ArrayList<String> weathers;  //a list to stores different weather
    
    private String weather;
    
    private Random rand;
    /**
     * Initialise the variables and store the weathers
     */
    public Weather()
    {
        weathers = new ArrayList<>();
        weathers.add("Sunny");
        weathers.add("Drought");
        weathers.add("Rain");
        weathers.add("Snow");
        
        rand = Randomizer.getRandom();
        
        weather = "Sunny";
    }

    /**
	 * @return generate random weather from the list.
	 */
    public String getWeather()
    {
        weather = weathers.get(rand.nextInt(weathers.size() - 1));
        return weather;
    }
}