import java.util.Random;

/**
 * Keeps track of the simulation environment (Such as the time of the day
 * and weather).
 *
 * @version 2020.02.21
 */
public class Environment 
{
    // Whether it is day or night.
    private boolean day;
    // To generate a random number.
    private static final Random rand = Randomizer.getRandom();
    
    enum Weather
    {
        RAIN, WARM, SNOW; // The different weather types
    };
    
    // The current weather
    Weather weather; 
    // The number of items defined in an enum.
    private int weatherLen = Weather.values().length;

    /**
     * Construct an Environment object.
     * (The simulation starts as day time and rainy weather).
     */
    public Environment()
    {
        day = true; 
        weather = Weather.RAIN;
    }
    
    /**
     * Updates the time and weather according to the current simulation step
     * @param step The current step of the simulation.
     */
    public void timeChanger(int step){
        // Every 20 steps the day changes
        int time = step/20;
        if (time % 2 == 0) {
            day = true; // Morning
        }
        else {
            day = false; // Night
        }
        
        // Every 30 steps the weather changes
        if(step % 30 == 0) {
            weather = Weather.values()[rand.nextInt(weatherLen)];
        }
    }
    
    /**
     * Return the time of the day.
     * @return true if its day time, false otherwise.
     */
    public boolean getTime(){
        return day;
    }
    
    /**
     * Returns the current weather.
     * @return The current weather.
     */
    public Weather getWeather(){
        return weather;
    }
}