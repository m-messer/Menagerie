import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.21
 */
public abstract class Animal extends Species
{
    // The possible genders an animal could have. 
    char[] genders = new char[]{'m', 'f'};
    //Random number generator for assigning genders
    private Random rnd = new Random();
    // Whether the animal is infected by the disease or not. 
    private boolean isInfected;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The animal's gender.
    private char gender;
    
    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the animal is in.
     */
    public Animal(Field field, Location location, Environment environment)
    {
        super(field, location, environment);
    }
    
    /**
     * Checks whether the adjacent species is edible by the animal. 
     * @param species The adjacent species. 
     * @return true if it was eaten, false otherwise.
     */
    abstract protected Boolean foodChecker(Object species);
    
    /**
     * Look for a prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if (foodChecker(species)){
                return where;
            }
        }
        return null;
    }
    
    /**
     * Randomly assigns genders to existing and newly born animals.
     * @return The assigned gender.
     */
    protected char assignGender()
    {
        return genders[rnd.nextInt(2)];
    }
    
    /**
     * Sets the animal's gender.
     * @param gender The animal's gender.
     */
    protected void setGender(char gender)
    {
        this.gender = gender;
    }
    
    /**
     * Return the animal's gender.
     * @return the animal's gender.
     */
    protected char getGender()
    {
        return this.gender;
    }
    
    /**
     * Look for a partner adjacent to the current location.
     * @return true if a partner is of the same kind and is with an opposite
     * genders was found, false otherwise.
     */
    protected Boolean findPartner()
    {
        Field field= getField();
        List<Location> adjacent= field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof Animal) 
            {
                Animal animal = (Animal) species; 
                if(animal.getClass().equals(this.getClass()))
                {
                    if(!(animal.getGender() == this.getGender()))
                    {
                        return true; 
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Animals can breed if it has reached the breeding age and found a partner.
     * @param age The animal's age. 
     * @param breedingAge The animal's breeding age. 
     * @return true if the animal can breed, false otherwise.
     */
    @Override
    protected boolean canBreed(int age, int breedingAge)
    {
        return findPartner() && (age >= breedingAge);
    }
    
    /**
     * Set the animal's disease infection.
     * @param isInfected whether the animal is infected by the disease or not.
     */
    protected void setInfection(boolean isInfected) 
    {
        this.isInfected = isInfected; 
    }
    
    /**
     * Returns the health status of the animal.
     * @return true if the animal is infected by a disease, false otherwise.
     */
    protected boolean getIsInfected() 
    {
        return this.isInfected; 
    }
    
    /**
     * Checks if all disease conditions are met that is the weather is snowy and 
     * the probability is less than or equals to the disease infection probability. 
     * @param infection_prob the probability of getting infected
     * @return true if the conditions are suitable for getting infected by the disease.
     */
    protected boolean diseaseCondition(double infection_prob)
    {
        return (getEnvironment().weather.SNOW == getEnvironment().getWeather())
                && (rand.nextDouble() <= infection_prob);
    }
    
    /**
     * Spreads the disease to all adjacent animals of same type.
     * @param newMaxAge The animal's new maximum age after infection. 
     */
    protected void spreadDisease(int newMaxAge)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof Animal) 
            {
                if(species.getClass().equals(this.getClass()))
                {
                    Animal adjacentAnimal = (Animal) species; 
                    adjacentAnimal.setInfection(true);
                    adjacentAnimal.setMaxAge(newMaxAge);
                }
            }
        }
    }
}
