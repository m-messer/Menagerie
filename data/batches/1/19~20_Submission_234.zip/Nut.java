import java.util.List;
import java.util.Random;

/**
 * A simple model of a nut.
 * Nuts age, grow, and die.
 *
 * @version 2020.02.21
 */
public class Nut extends Plant
{
    // The age at which a nut can start to breed.
    private static final int BREEDING_AGE = 8;
    // The likelihood of nut growing.
    private static final double GROWTH_RATE = 0.02;
    // The maximum number of reproductions.
    private static final int MAX_LITTER_SIZE = 1;
    // A shared random number generator to control growth.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The nut's age.
    private int age;
    // Variable to store the incremented age.
    private int newAge; 

    /**
     * Constructor for objects of class Nut
     * @param randomAge If true, the nut will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the nut is in.
     */
    public Nut(boolean randomAge, Field field, Location location, Environment environment)
    {
        super(field, location, environment);
        setMaxAge(40);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
        }
    }

    /**
     * This is what the nut does most of the time: it might breed
     * or die of old age. (Does not move)
     * @param newNuts A list to return newly produced nuts.
     */
    @Override
    public void act(List<Species> newNuts)
    {
        newAge = incrementAge(age, getMaxAge());
        if (newAge != -1) {
            age = newAge; }
            
        if(isAlive()) {
             reproduce(newNuts); 
        }
    }

    /**
     * Generate a number representing the number of reproductions,
     * if it can breed.
     * @return The number of reproductions (may be zero).
     */
    @Override
    protected int breed()
    {
        int births = 0;
        if(canBreed(age, BREEDING_AGE) && rand.nextDouble() <= GROWTH_RATE) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Create a new nut.
     * @param field The nut's field.
     * @param loc A free location.
     * @param environment The nut's environment.
     * @return New nut.
     */
    @Override
    protected Nut createYoung(Field field, Location loc, Environment environment) {
        Nut young = new Nut(false, field, loc, environment);
        return young;
    }
}
