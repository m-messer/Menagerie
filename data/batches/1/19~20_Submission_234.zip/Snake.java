import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Snake.
 * Snakes age, move, eat squirrels, and die.
 *
 * @version 2020.02.21
 */
public class Snake extends Animal
{
    // Characteristics shared by all snakes (class variables).
    
    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.11;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The food value of a single squirrel. In effect, this is the
    // number of steps a snake can go before it has to eat again.
    private static final int SQUIRREL_FOOD_VALUE = 11;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The snake's age.
    private int age;
    // Variable to store the incremented age.
    private int newAge;
    // The snake's food level, which is increased by eating.
    private int foodLevel;

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the snake is in.
     */
    public Snake(boolean randomAge, Field field, Location location, Environment environment)
    {
        super(field, location, environment);
        setMaxAge(75);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(SQUIRREL_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SQUIRREL_FOOD_VALUE;
        }
        setGender(assignGender());
    }

    /**
     * This is what the snake does most of the time: it hunts for
     * squirrels. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newSnakes A list to return newly born snakes.
     */
    @Override
    public void act(List<Species> newSnakes)
    {
        newAge = incrementAge(age, getMaxAge());
        if (newAge != -1) {
            age = newAge; }
        incrementHunger();
        if(isAlive()) {
            reproduce(newSnakes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Make this snake more hungry. This could result in the snake's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Checks whether the adjacent species is an alive squirrel.  
     * @param species the adjacent species. 
     * @return true if it was eaten, false otherwise.
     */
    @Override
    protected Boolean foodChecker(Object species){
        if(species instanceof Squirrel) {
            Squirrel squirrel = (Squirrel) species;
            if(squirrel.isAlive()) { 
                squirrel.setDead();
                foodLevel = SQUIRREL_FOOD_VALUE;
                return true;
            }
        }
        return false;
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    @Override
    protected int breed()
    {
        int births = 0;
        if(canBreed(age, BREEDING_AGE) && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Create a new born snake (age zero and not hungry).
     * @param field The snake's field.
     * @param loc A free location.
     * @param environment The snake's environment.
     * @return A new born snake.
     */
    @Override
    protected Snake createYoung(Field field, Location loc, Environment environment) {
        Snake young = new Snake(false, field, loc, environment);
        return young;
    }
}
