import java.util.List;
import java.util.Random;

/**
 * A simple model of a grass.
 * Grass age, grow, and die.
 *
 * @version 2020.02.21
 */
public class Grass extends Plant 
{
    // The age at which a grass can start to breed.
    private static final int BREEDING_AGE = 8;
    // The maximum number of reproductions.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control growth.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The grass's age.
    private int age;
    // Variable to store the incremented age.
    private int newAge;
    // The likelihood of grass growing.
    private double growth_rate;
    
    /**
     * Constructor for objects of class Grass
     * @param randomAge If true, the grass will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the grass is in.
     */
    public Grass(boolean randomAge, Field field, Location location, Environment environment)
    {
        super(field, location, environment);
        setMaxAge(10);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
        }
    }
    
    /**
     * This is what the grass does most of the time: it might breed
     * or die of old age. (Does not move)
     * @param newGrass A list to return newly produced grass.
     */
    @Override
    public void act(List<Species> newGrass)
    {
        growth_rate = 0.2;
        newAge = incrementAge(age,  getMaxAge());
        if (newAge != -1) {
            age = newAge; }
            
        if (getEnvironment().weather.RAIN == getEnvironment().getWeather()) {
            growth_rate *= 5;
        }
        
        if(isAlive()) {
             reproduce(newGrass); 
        }
    }

    /**
     * Generate a number representing the number of reproductions,
     * if it can breed.
     * @return The number of reproductions (may be zero).
     */
    @Override
    protected int breed()
    {
        int births = 0;
        if(canBreed(age, BREEDING_AGE) && rand.nextDouble() <= growth_rate) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Create a new grass.
     * @param field The grass's field.
     * @param loc A free location.
     * @param environment The nut's environment.
     * @return New grass.
     */
    @Override
    protected Grass createYoung(Field field, Location loc, Environment environment) {
        Grass young = new Grass(false, field, loc, environment);
        return young;
    }
}
