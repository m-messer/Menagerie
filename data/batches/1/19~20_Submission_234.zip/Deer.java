import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a deer.
 * Deers age, move, eat grass, and die.
 *
 * @version 2020.02.21 
 */
public class Deer extends Animal
{
    // Characteristics shared by all deers (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 8;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.24;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The food value of a single grass. In effect, this is the
    // number of steps a deer can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The deer's age.
    private int age;
    // Variable to store the incremented age.
    private int newAge; 
    // The deer's food level, which is increased by eating.
    private int foodLevel;
    
    /**
     * Create a deer. A deer can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the deer will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the deer is in.
     */
    public Deer(boolean randomAge, Field field, Location location, Environment environment)
    {
        super(field, location, environment);
        setMaxAge(62);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
        setGender(assignGender());
    }
    
    /**
     * This is what the deer does most of the time: it looks for
     * grass. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newDeers A list to return newly born deers.
     */
    @Override
    public void act(List<Species> newDeers)
    {
        newAge = incrementAge(age, getMaxAge());
        if (newAge != -1) {
            age = newAge; }
        incrementHunger();
        if(isAlive()) {
            reproduce(newDeers);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Make this deer more hungry. This could result in the deer's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Checks whether the adjacent species is an alive grass.  
     * @param species the adjacent species. 
     * @return true if it was eaten, false otherwise.
     */
    @Override
    protected Boolean foodChecker(Object species){
        if(species instanceof Grass) {
            Grass grass = (Grass) species;
            if(grass.isAlive()) { 
                grass.setDead();
                foodLevel = GRASS_FOOD_VALUE;
                return true;
            }
        }
        return false;
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    @Override
    protected int breed()
    {
        int births = 0;
        if(canBreed(age, BREEDING_AGE) && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Create a new born deer (age zero and not hungry).
     * @param field The deer's field.
     * @param loc A free location.
     * @param environment The deer's environment.
     * @return A new born deer.
     */
    @Override
    protected Deer createYoung(Field field, Location loc, Environment environment) {
        Deer young = new Deer(false, field, loc, environment);
        return young;
    }
}
