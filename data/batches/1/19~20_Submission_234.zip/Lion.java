import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat deers, and die.
 *
 * @version 2020.02.21
 */
public class Lion extends Animal
{
    // Characteristics shared by all lions (class variables).
    
    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 4;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single deer. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 16;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The lion's infection probability 
    private static final double INFECTION_PROBABILITY = 0.5;
    
    // Individual characteristics (instance fields).
    // The lion's age.
    private int age;
    // Variable to store the incremented age.
    private int newAge;
    // The lion's food level, which is increased by eating.
    private int foodLevel;
    
    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the lion is in.
     */
    public Lion(boolean randomAge, Field field, Location location, Environment environment)
    {
        super(field, location, environment);
        setMaxAge(62);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(DEER_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = DEER_FOOD_VALUE;
        }
        setGender(assignGender());
        setInfection(false);
    }
    
    /**
     * This is what the lion does most of the time: it hunts for
     * deers. In the process, it might breed, die of hunger,
     * or die of old age.
     * if it's snowing, it might get sick
     * @param newLions A list to return newly born lions.
     */
    @Override
    public void act(List<Species> newLions)
    {
        newAge = incrementAge(age, getMaxAge());
        if (newAge != -1) {
            age = newAge; }
        incrementHunger();
        if(isAlive()) {
            reproduce(newLions);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation); 
                // check if the lion is not diseased, it's nowing and if it's going to get diagnosed
                if(!getIsInfected() && diseaseCondition(INFECTION_PROBABILITY))
                {
                    setInfection(true);
                    setMaxAge(8);
                    spreadDisease(8);
                }
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
     
    /**
     * Checks whether the adjacent species is an alive deer.  
     * @param species the adjacent species. 
     * @return true if it was eaten, false otherwise.
     */
    @Override
    protected Boolean foodChecker(Object species){
        if(species instanceof Deer) {
            Deer deer = (Deer) species;
            if(deer.isAlive()) { 
                deer.setDead();
                foodLevel = DEER_FOOD_VALUE;
                return true;
            }
        }
        return false;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    @Override
    protected int breed()
    {
        int births = 0;
        if(canBreed(age, BREEDING_AGE) && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Create a new born lion (age zero and not hungry).
     * @param field The lion's field.
     * @param loc A free location.
     * @param environment The lion's environment.
     * @return A new born lion.
     */
    @Override
    protected Lion createYoung(Field field, Location loc, Environment environment) {
        Lion young = new Lion(false, field, loc, environment);
        return young;
    }
}
