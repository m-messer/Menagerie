import java.util.List;

/**
 * A class representing shared characteristics of species.
 *
 * @version 2020.02.21
 */
public abstract class Species
{
    // Whether the species is alive or not.
    private boolean alive;
    // The species' field.
    private Field field;
    // The species' position in the field.
    private Location location; 
    // The environment that the species is in (time and weather).
    private Environment environment;
    // The age to which a species can live.
    private int max_age;
    
    /**
     * Create a new species at location in field. 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the species is in.
     */
    public Species(Field field, Location location, Environment environment)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.environment = environment;
    }
    
    /**
     * Make this species act - that is: make it do
     * whatever it wants/needs to do.
     * @param newSpecies A list to receive newly produced species.
     */
    abstract public void act(List<Species> newSpecies);

    /**
     * Check whether the species is alive or not.
     * @return true if the species is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the species is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the species' location.
     * @return The species' location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the species at the new location in the given field.
     * @param newLocation The species's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the species' field.
     * @return The species' field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the species' environment.
     * @return the species' environment.
     */
    protected Environment getEnvironment() 
    {
        return environment;
    }

    /**
     * Increase the age. This could result in the species' death.
     * @param age The species' current age.
     * @param maxAge The species' maximum age.
     * @return The species' new age or -1 if was set dead.
     */ 
    protected int incrementAge(int age, int maxAge)
    {
        age++;
        if(age > maxAge) {
            setDead();
            return -1;
        }
        return age;
    }
    
    /**
     * Species can breed if it has reached the breeding age.
     * @param age The species' age. 
     * @param breedingAge The species' breeding age. 
     * @return true if the species can breed, false otherwise.
     */
    abstract protected boolean canBreed(int age, int breedingAge);
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    abstract protected int breed();
    
    /**
     * Check whether or not this species is to reproduce at this step.
     * Newly produced species will be made into free adjacent locations.
     * @param newSpecies A list to return newly produced species.
     */
    protected void reproduce(List<Species> newSpecies)
    {
        // New animals/plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Species young = createYoung(field, loc, environment);
            newSpecies.add(young);
        }
    }
    
    /**
     * Create a new species. 
     * @param field The species' field.
     * @param loc A free location.
     * @param environment The species' environment.
     * @return A newly produced species.
     */
    abstract protected Species createYoung(Field field, Location loc, Environment environment) ;
   
    /**
     * Sets the species' maximum age to the given value.
     * @param max_age The species' maximum age. 
     */
    protected void setMaxAge(int max_age)
    {
        this.max_age = max_age;
    }
    
    /**
     * Get the maximum age of a species.
     * @return The maximum age of a species.
     */
    protected int getMaxAge(){
        return this.max_age;
    }
}