/**
 * A class representing shared characteristics of plants.
 *
 * @version 2020.02.16
 */
public abstract class Plant extends Species
{
    /**
     * Create a new plant at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment that the plant is in.
     */
    public Plant(Field field, Location location, Environment environment)
    {
        super(field, location, environment);
    }
    
    /**
     * Plants can breed if it has reached the breeding age.
     * @param age The plant's age. 
     * @param breedingAge The plant's breeding age. 
     * @return true if the plant can breed, false otherwise.
     */
    @Override
    protected boolean canBreed(int age, int breedingAge)
    {
        return age >= breedingAge ;
    }
}
