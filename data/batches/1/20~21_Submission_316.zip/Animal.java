import java.util.ArrayList;
import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * Animals have a food level which must be satisfied through eating. They
 * also mate when the same species of the opposite sex is besides them.
 *
 * Animals have diseases which can be passed on to their young or spread to other
 * nearby animals of the same species. Diseases may also spread when a diseased animal
 * is eaten by it.
 *
 * Animals sleep can also be controlled, while sleeping they do not move nor need food.
 * They can however still die of disease while asleep.
 *
 * @version 2021.02.24 (3)
 */
public abstract class Animal extends Entity
{
    // Basic characteristics of all animals
    private int age;
    private boolean isFemale;
    private int foodLevel;
    private boolean isSleeping;

    // An ArrayList holding the prey (animals that this animal eats)
    private final ArrayList<Class> prey;
    
    /**
     * Create a new animal and initialise its variables
     */
    public Animal(Field f, Location l) {
        super(f, l);
        prey = new ArrayList<>();

        foodLevel = rand.nextInt((int) (getMaxFoodLevel() * 0.25 + 1));
        setRandomSex();
        isSleeping = rand.nextBoolean();

        setPrey();
    }

    /**
     * The main act method which is called in every step of the simulation.
     * This drives the animal and makes it do whatever that animal does (move, eat,
     * breed, etc)
     * @param newEntities A list to receive newborn animals
     */
    public void act(List<Entity> newEntities) {
        incrementAge();
        incrementHunger();
        checkInfection();

        // Animal may be dead at this point, so double-check
        if (isAlive()) {
            checkNeighbouringDiseasedEntities();
            toggleSleep();

            // If the animal is sleeping, we don't want it to move or give birth.
            if (isSleeping) {
                return;
            }

            giveBirth(newEntities);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation(), getMoveRadius());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else if (getMoveRadius() != 0){
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increment the age of the animal, and kill it if it exceeds
     * its maximum age.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Change whether this animal is sleeping or is awake
     * @param sleep Whether this animal should sleep, true = the animal is sleeping, false = the animal is awake
     */
    public void setSleep(boolean sleep) {
        this.isSleeping = sleep;
    }

    /**
     * Make the animal hungry, this could lead to it dying.
     */
    public void incrementHunger() {
        if (!isSleeping) {
            foodLevel--;
            if (foodLevel <= 0) {
                // Starved to death
                setDead();
            }
        }
    }

    /**
     * Check whether this animal can breed or not, this depends on various factors such as its
     * age, gender, food level and whether there is a mate nearby.
     * @return True if the animal can breed, false if it can not.
     */
    public boolean canBreed() {
        return age >= getBreedingAge() && isFemale && maleNearby() && foodLevel > getMaxFoodLevel() * 0.15;
    }

    /**
     * Set a random gender for this animal.
     */
    public void setRandomSex() {
        isFemale = rand.nextDouble() <= 0.5;
    }

    /**
     * Generate a number of animals this animal can breed, if it is possible
     * @return The number of births (can be zero if the animal can't breed).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && getRand().nextDouble() <= getBreedingProbability()) {
            births = getRand().nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Check whether there is a male animal of the same species in any
     * adjacent location to the current animal
     * @return True if there is a male nearby, false otherwise
     */
    public boolean maleNearby() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), 1);

        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);

            // Check if the animal is of the same species and male
            if (animal != null && animal.getClass() == this.getClass()) {
                Animal neighbour = (Animal) animal;
                if (!neighbour.isFemale) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Look for any prey nearby that this animal can eat. Only the first seen
     * prey is eaten.
     * This animal may become infected if it eats a diseased animal.
     *
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), getMoveRadius());
        for (Location where : adjacent) {
            Object prey = field.getObjectAt(where);
            if (prey != null && isFood(prey.getClass())) {
                Entity preyEntity = (Entity) prey;
                if (preyEntity.isAlive()) {
                    eat(preyEntity);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * This method is used to eat another entity and spread any diseases if applicable
     * @param entity The entity to eat
     */
    public void eat(Entity entity) {
        if (foodLevel >= 0.9 * getMaxFoodLevel()) {
            // If 90% full, don't eat
            return;
        }

        // Animal is hungry
        incrementFoodLevel(entity.getFoodValue());
        if (entity.isDiseased() && rand.nextDouble() <= entity.getDisease().getSpreadProbability()) {
            infect(new Disease(entity.getDisease()));
        }

        // Kill off prey
        entity.setDead();
    }

    /**
     * Increment the food level of the current entity by a given amount, or the maximum if it exceeds
     * maximum food level
     * @param foodValue The amount to increase food level by
     */
    public void incrementFoodLevel(int foodValue) {
        foodLevel = Integer.min(getMaxFoodLevel(), foodLevel + foodValue);
    }

    /**
     * Check if a given animal class is considered as prey by the current animal
     * @param potentialPrey The class of the animal to check
     * @return True if the given animal class is considered prey to this animal, false if it is not
     */
    protected boolean isFood(Class potentialPrey) {
        return prey.contains(potentialPrey);
    }

    /**
     * Add an animal class to the prey of this animal. This will make the current animal
     * eat it whenever it is nearby
     * @param prey The class of the animal that is considered prey.
     */
    protected void addPrey(Class prey) {
        this.prey.add(prey);
    }

    /**
     * Make this animal sleep or wake up based on certain conditions
     */
    protected abstract void toggleSleep();

    /**
     * @return The maximum food level of this animal.
     */
    protected abstract int getMaxFoodLevel();

    /**
     * @return The maximum age of this animal
     */
    protected abstract int getMaxAge();

    /**
     * @return The age at which this animal can breed
     */
    protected abstract int getBreedingAge();

    /**
     * Set the prey of the current animal
     */
    protected abstract void setPrey();
}
