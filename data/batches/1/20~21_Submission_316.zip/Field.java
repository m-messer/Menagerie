import java.util.*;

/**
 * Represents a field in the simulation. The field is a rectangular grid
 * of field positions, each of which can hold a single entity.
 *
 * The field also has an environment to simulate environmental factors
 * such as rain, fog, light and the time of day.
 *
 * @version 2021.02.24
 */
public class Field
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();
    
    // The depth and width of the field.
    private final int depth;
    private final int width;

    // Storage for the entities.
    private final Object[][] field;

    // The environment of the field
    private final Environment environment;

    /**
     * Represent a field of the given dimensions.
     * @param depth The depth of the field.
     * @param width The width of the field.
     * @param environment The environment of the current field
     */
    public Field(int depth, int width, Environment environment)
    {
        this.depth = depth;
        this.width = width;
        field = new Object[depth][width];
        this.environment = environment;
    }
    
    /**
     * Empty the field.
     */
    public void clear()
    {
        for(int row = 0; row < depth; row++) {
            for(int col = 0; col < width; col++) {
                field[row][col] = null;
            }
        }
    }

    /**
     * Get a string value that represents the name of the current season
     * @return The name of the current season
     */
    public String getSeasonName() {
        return environment.getSeason().toString();
    }

    /**
     * Check if its night time
     * @return True if it is night time, false if it is not
     */
    public boolean isNight() {
        return environment.isNight();
    }

    /**
     * Check if it is day time
     * @return True if it is day time, false if it is not
     */
    public boolean isDay() {
        return environment.isDay();
    }

    /**
     * Get the current light level
     * @return The current light level, between 0 and 1, 1 = Very bright, 0 = Very dark
     */
    public double getLightLevel() {
        return environment.getLightLevel();
    }

    /**
     * Get the current temperature of the environment
     * @return The current temperature, between 0 and 1, 1 = Very hot, 0 = Very cold
     */
    public double getTemperature() {
        return environment.getTemperature();
    }

    /**
     * Get the fog level of the current environment
     * @return The fog level, between 0 and 1, 1 = Very foggy, 0 = No fog
     */
    public double getFogLevel() {
        return environment.getFogLevel();
    }

    /**
     * Get the rain level of the current environment
     * @return The rain level, between 0 and 1, 1 = Very rainy, 0 = Not raining
     */
    public double getRainLevel() {
        return environment.getRainLevel();
    }

    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    public void clear(Location location)
    {
        field[location.getRow()][location.getCol()] = null;
    }
    
    /**
     * Place an entity at the given location.
     * If there is already an entity at the location it will
     * be lost.
     * @param entity The entity to be placed.
     * @param location Where to place the animal.
     */
    public void place(Object entity, Location location)
    {
        field[location.getRow()][location.getCol()] = entity;
    }
    
    /**
     * Return the entity at the given location, if any.
     * @param location Where in the field.
     * @return The entity at the given location, or null if there is none.
     */
    public Object getObjectAt(Location location)
    {
        return getObjectAt(location.getRow(), location.getCol());
    }
    
    /**
     * Return the entity at the given location, if any.
     * @param row The desired row.
     * @param col The desired column.
     * @return The entity at the given location, or null if there is none.
     */
    public Object getObjectAt(int row, int col)
    {
        return field[row][col];
    }

    /**
     * Get a shuffled list of the free adjacent locations.
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */
    public List<Location> getFreeAdjacentLocations(Location location, int radius)
    {
        List<Location> free = new LinkedList<>();
        List<Location> adjacent = adjacentLocations(location, radius);
        for(Location next : adjacent) {
            if(getObjectAt(next) == null) {
                free.add(next);
            }
        }
        return free;
    }
    
    /**
     * Try to find a free location that is adjacent to the
     * given location. If there is none, return null.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location freeAdjacentLocation(Location location, int radius)
    {
        // The available free ones.
        List<Location> free = getFreeAdjacentLocations(location, radius);
        if(free.size() > 0) {
            return free.get(0);
        }
        else {
            return null;
        }
    }

    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    public List<Location> adjacentLocations(Location location, int radius)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        int row = location.getRow();
        int col = location.getCol();
        for(int roffset = -1 * radius; roffset <= radius; roffset++) {
            int nextRow = row + roffset;
            if(nextRow >= 0 && nextRow < depth) {
                for(int coffset = -1 * radius; coffset <= radius; coffset++) {
                    int nextCol = col + coffset;
                    // Exclude invalid locations and the original location.
                    if(nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
                        locations.add(new Location(nextRow, nextCol));
                    }
                }
            }
        }
        Collections.shuffle(locations, rand);
        return locations;
    }

    /**
     * Return the depth of the field.
     * @return The depth of the field.
     */
    public int getDepth()
    {
        return depth;
    }
    
    /**
     * Return the width of the field.
     * @return The width of the field.
     */
    public int getWidth()
    {
        return width;
    }
}
