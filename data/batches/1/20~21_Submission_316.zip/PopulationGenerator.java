import java.awt.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

/**
 * This class is a generator for the population of the simulator.
 * It creates all the entities with hard-coded creation probabilities and
 * is used to populate a given field with all the entities that have
 * been specified.
 *
 * @version 2021.03.03
 */

public class PopulationGenerator {
    // List of entities in the field.
    private final List<Entity> entities;
    // LinkedHashMap of entity classes with their associated creation probabilities
    private final LinkedHashMap<Class, Double> entityClasses;
    // The simulator entities
    private final SimulatorEntities simulatorEntities;

    /**
     * Create a population generator for the given view
     * @param view The view to generate the population for
     */
    public PopulationGenerator(SimulatorView view) {
        entities = new ArrayList<>();
        entityClasses = new LinkedHashMap<>();
        simulatorEntities = new SimulatorEntities(view, entityClasses);
        createEntities();
    }

    /**
     * This method loads all the entity classes with their associated probabilities,
     * and display colour
     */
    private void createEntities() {
        // Add entities and their creation probabilities to LinkedHashMap
        // Set entity colours
        simulatorEntities.addEntity(Lizard.class, 0.13061053097248077, Color.CYAN);
        simulatorEntities.addEntity(Plant.class, 0.3933432579040528, Color.GREEN);
        simulatorEntities.addEntity(Lion.class, 0.04044768631458285, Color.BLUE);
        simulatorEntities.addEntity(Hawk.class, 0.029595976471900938, Color.MAGENTA);
        simulatorEntities.addEntity(Scorpion.class, 0.1289423781633377, Color.BLACK);
        simulatorEntities.addEntity(Insect.class, 0.1212902843952179, Color.RED);
    }

    /**
     * Generate and put the population of all entities into the given field
     * @param field The field to populate with entities
     */
    public void populate(Field field) {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                for (Class entityClass : entityClasses.keySet()) {
                    try {
                        // Dynamically create entities from their class references
                        Double creationProbability = entityClasses.get(entityClass);

                        if (rand.nextDouble() < creationProbability) {
                            // Randomly infect ~10% of the initial population
                            Constructor constructor = entityClass.getConstructor(Field.class, Location.class);
                            Location location = new Location(row, col);
                            Entity entity = (Entity) constructor.newInstance(field, location);

                            if (rand.nextDouble() < 0.01) {
                                entity.infect(new Disease());
                            }

                            entities.add(entity);
                            break;
                        }
                    } catch (InstantiationException | NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                        System.out.println(e);
                    }
                }
            }
        }
    }

    /**
     * Clear all entities that are currently in the field
     */
    public void clearEntities() {
        entities.clear();
    }

    /**
     * Get the list of all entities currently in the field
     * @return A list containing all entities in the field
     */
    public List<Entity> getEntities() {
        return entities;
    }
}
