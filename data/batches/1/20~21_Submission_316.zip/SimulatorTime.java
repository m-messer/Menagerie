/**
 * This class keeps track of the time the simulation has run.
 * It has a set length of steps for each time unit (day, hour, year).
 *
 * The class can also perform checks such as if its day or night, and
 * the current season.
 *
 * @version 2021.02.24
 */
public class SimulatorTime {
    private int day;
    private int hour;

    private final int hoursPerDay;
    private final int daysPerYear;
    private final int hoursPerStep;

    /**
     * Create a DayTime object and initialise its values
     */
    public SimulatorTime() {
        day = 1;
        hour = 0;

        hoursPerDay = 10;
        daysPerYear = 20;
        hoursPerStep = 1;
    }

    /**
     * Increment a step in the simulation, this modifies the
     * internal time based on the parameters set
     */
    public void incrementStep() {
        incrementHour();
    }

    /**
     * Increase the current hour. This resets the day and year if applicable
     */
    private void incrementHour() {
        hour += hoursPerStep;

        // Increase the day and hour if applicable
        if (hour % hoursPerDay == 0) {
            day++;
            hour = 0;
        }

        // Reset the day if needed
        if (day > daysPerYear) {
            day = 1;
        }
    }

    /**
     * Check if it is currently daytime
     * @return True if it is day time, false if it is not
     */
    public boolean isDay() {
        return hour >= 3 && hour <= 7;
    }

    /**
     * Check if it is currently night time
     * @return True if it is night time, false if it is not
     */
    public boolean isNight() {
        return !isDay();
    }

    /**
     * Get the current season, this is based on the current day of the year
     * @return A Season object for the current time of year
     */
    public Season getSeason() {
        if (isSpring()) {
            return Season.SPRING;
        } else if (isSummer()) {
            return Season.SUMMER;
        } else if (isAutumn()) {
            return Season.AUTUMN;
        } else {
            return Season.WINTER;
        }
    }

    /**
     * Check if the season is currently Spring
     * @return True if it is Spring, false if it is not
     */
    private boolean isSpring() {
        return day <= daysPerYear * 0.25;
    }

    /**
     * Check if the season is currently Summer
     * @return True if it is Summer, false if it is not
     */
    private boolean isSummer() {
        return day <= daysPerYear * 0.5 && day > daysPerYear * 0.25;
    }

    /**
     * Check if the season is currently Autumn
     * @return True if it is Autumn, false if it is not
     */
    private boolean isAutumn() {
        return day <= daysPerYear * 0.75 && day > daysPerYear * 0.5;
    }
}
