/**
 * A simple model of a lion.
 * lions age, move, eat lizards and scorpions, breed, and die.
 *
 * @version 2021.02.24 (3)
 */
public class Lion extends Animal {
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a lion can live.
    private static final int MAX_AGE = 53;
    // The likelihood of a lion breeding.
    private static final double DAY_BREEDING_PROBABILITY = 0.07996352314949036;
    private static final double NIGHT_BREEDING_PROBABILITY = 0.2579066038131714;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The maximum food level a lion can have
    private static final int MAX_FOOD_LEVEL = 37;
    // The food level of the lion. If a predator eats the lion then its food value goes up by this amount
    private static final int foodValue = 2;
    // The radius about which the lion can move in a single step
    private static final int MOVE_RADIUS = 1;

    /**
     * Create a lion at a given field and position
     * @param field The field to create the lion in
     * @param loc The location to create the lion in
     */
    public Lion(Field field, Location loc) {
        super(field, loc);
    }

    /**
     * Sets prey of the lion
     */
    public void setPrey() {
        addPrey(Lizard.class);
        addPrey(Scorpion.class);
    }

    /**
     * @return return breeding probability during the night
     */
    public double getNightBreedingProbability() {
        return NIGHT_BREEDING_PROBABILITY;
    }

    /**
     * @return return breeding probability during the day
     */
    public double getDayBreedingProbability() {
        return DAY_BREEDING_PROBABILITY;
    }

    /**
     * @return returns the breeding age of the lion
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return return move radius if it's daytime, otherwise return 0
     */
    public int getMoveRadius() {
        return getField().isDay() ? MOVE_RADIUS : 0;
    }

    /**
     * @return returns the max age of the lion
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * @return returns the max litter size of the lion
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Sets the lion to sleep if it's night, otherwise wakes it
     */
    public void toggleSleep() {
        setSleep(getField().isNight());
    }

    /**
     * @return returns the food value of the lion
     */
    public int getFoodValue() {
        return foodValue;
    }

    /**
     * @return returns the max food level of the lion
     */
    public int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }
}