import java.util.List;

/**
 * A simple model of a plant
 * Plants don't move, but they do breed.
 *
 * @version 2021.02.24
 */
public class Plant extends Entity {
    // Characteristics shared by all Plants (class variables).

    // Max water saturation level. Beyond this is death.
    private static final int maxSaturation = 100;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The minimum saturation level. Below this is death.
    private static final int minimumSaturation = 0;
    // The food level of the plant. If an animal eats the plant then its food value goes up by this amount
    private static final int foodValue = 3;
    // The likelihood of a plant breeding.
    private static final double DAY_BREEDING_PROBABILITY = 0.4027390331029892;
    private static final double NIGHT_BREEDING_PROBABILITY = 0.37729258537292476;

    // Current water saturation level
    private int waterSaturation;

    /**
     * Create a plant at a given field and location.
     * Plants are created with an initial water saturation of 50. They have no age and cannot move.
     * @param field The field to create the plant in
     * @param loc The location to create the plant in
     */
    public Plant(Field field, Location loc) {
        super(field, loc);
        waterSaturation = 50;
    }

    /**
     * All plant functions on every step, check if it is dead from disease or water saturation, and if not then
     * give birth to new plants
     * @param babyPlants newborns will be added to this list
     */
    public void act(List<Entity> babyPlants) {
        checkInfection();
        checkWaterSaturation();
        if (isAlive()) {
            waterSaturation += getField().getRainLevel() * 15;
            waterSaturation -= ((getField().getLightLevel() * 5 + 2) + (getField().getTemperature() * 7));
            checkNeighbouringDiseasedEntities();
            giveBirth(babyPlants);
        }
    }

    /**
     * Check if the water saturation has exceeded the min and max bounds. Kill the plant if it has.
     */
    public void checkWaterSaturation() {
        if (waterSaturation <= minimumSaturation || waterSaturation > maxSaturation) {
            setDead();
        }
    }

    /**
     * @return return breeding probability during the night
     */
    public double getNightBreedingProbability() {
        return NIGHT_BREEDING_PROBABILITY;
    }

    /**
     * @return return breeding probability during the day
     */
    public double getDayBreedingProbability() {
        return DAY_BREEDING_PROBABILITY;
    }

    /**
     * @return returns the breeding probability of the plant
     */
    public double getBreedingProbability() {
        double probability = getField().isDay() ? DAY_BREEDING_PROBABILITY : NIGHT_BREEDING_PROBABILITY;
        probability += 0.1 * getField().getLightLevel();

        return Double.min(1.0, probability);
    }

    /**
     * Gets the number of births possible
     * @return return number of births
     */
    public int breed() {
        int births = 0;
        if(getRand().nextDouble() <= getBreedingProbability()) {
            births = getRand().nextInt(getMaxLitterSize()) + 1;
        }

        return births;
    }

    /**
     * Gets the move radius of the plant (it doesn't move so returns 0)
     * @return returns 0
     */
    public int getMoveRadius() {
        return 0;
    }

    /**
     * @return returns the max litter size of the plant
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return returns the food value of the plant
     */
    public int getFoodValue() {
        return foodValue;
    }
}
