/**
 * This class simulates a disease in the simulation.
 *
 * Diseases affect animals and each have a spread probability, death probability
 * and healing time, which represents the number of steps it takes to recover
 * from this disease (and thus remove it)
 *
 * Diseases have an age, once the age exceeds the healing time
 * the disease dies off.
 *
 * @version 2021.02.24
 */
public class Disease {
    // The probability this disease kills, between 0 and 1
    private final double deathProbability;

    // The probability this disease spreads, between 0 and 1
    private final double spreadProbability;

    // The number of steps it takes to recover from this disease
    private final int healingTime;

    // The current age of this disease
    private int diseaseAge;

    /**
     * Create a new disease object with random parameters
     */
    public Disease() {
        this(Randomizer.getRandom().nextDouble() * 0.5,
                Randomizer.getRandom().nextDouble() * 0.1,
                Randomizer.getRandom().nextInt(10));
    }

    /**
     * Create a new disease with the given parameters
     * @param deathProbability The probability this disease kills, between 0 and 1
     * @param spreadProbability The probability this disease spreads, between 0 and 1
     * @param healingTime The number of steps it takes to recover from this disease
     */
    public Disease(double deathProbability, double spreadProbability, int healingTime) {
        this.deathProbability = deathProbability;
        this.spreadProbability = spreadProbability;
        this.healingTime = healingTime;

        diseaseAge = 0;
    }

    /**
     * Constructor to create a copy of a given disease. This creates a new copy of the disease
     * which has an age of 0.
     * @param disease The disease to copy
     */
    public Disease(Disease disease) {
        this(disease.deathProbability, disease.spreadProbability, disease.healingTime);
    }

    /**
     * Get the probability that this disease kills
     * @return The probability that this disease kills, between 0 and 1
     */
    public double getDeathProbability() {
        return deathProbability;
    }

    /**
     * Get the probability that this disease spreads
     * @return The probability that this disease spreads, between 0 and 1
     */
    public double getSpreadProbability() {
        return spreadProbability;
    }

    /**
     * Increment the age of this disease
     */
    public void incrementAge() {
        diseaseAge++;
    }

    /**
     * Check if this disease is still alive based on its age
     * @return True if the disease is alive, false if it is not
     */
    public boolean isAlive() {
        return diseaseAge < healingTime;
    }
}
