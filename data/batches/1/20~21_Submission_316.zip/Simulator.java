import java.util.*;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing lizards and lions.
 *
 * @version 2021.02.24 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.

    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;

    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;

    // The generator for the population
    private final PopulationGenerator populationGenerator;

    // The current state of the field.
    private final Field field;

    // The current step of the simulation.
    private int step;

    // A graphical view of the simulation.
    private final SimulatorView view;

    // Provides access to light, rain, fog and temperature levels
    private final Environment simEnvironment;


    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        // Create a new simulation environment
        simEnvironment = new Environment();

        // Create a field with a given environment
        field = new Field(depth, width, simEnvironment);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);

        // Create a population generator for the view
        populationGenerator = new PopulationGenerator(view);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Get the field of this simulator
     * @return The field of this simulator
     */
    public Field getField() {
        return field;
    }

    /**
     * The main method to start the application, creates a Simulator object
     */
    public static void main(String[] args) {
        new Simulator();
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * lion and lizard.
     */
    public void simulateOneStep()
    {
        step++;

        simEnvironment.incrementStep();

        // Change the weather every 10 steps
        if (step % 10 == 0) {
            simEnvironment.changeWeather();
        }

        // Provide space for newborn animals.
        List<Entity> newEntities = new ArrayList<>();
        // Let all entities act.
        List<Entity> allEntities = populationGenerator.getEntities();
        for(Iterator<Entity> it = allEntities.iterator(); it.hasNext(); ) {
            Entity entity = it.next();
            entity.act(newEntities);

            if (!entity.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born lions and lizards to the main lists.
        allEntities.addAll(newEntities);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        // Stop the simulation

        step = 0;

        // Regenerate the population
        populationGenerator.clearEntities();
        populationGenerator.populate(field);

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

}
