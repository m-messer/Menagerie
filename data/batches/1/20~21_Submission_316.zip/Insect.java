/**
 * A simple representation of an insect.
 * lions age, move, eat lizards, and die.
 *
 * Insects never sleep and are always active. They only
 * eat plants but can be eaten by many other animals.
 *
 * @version 2021.02.24
 */
public class Insect extends Animal {
    // Characteristics shared by all insects (class variables).

    // The age at which an insect can start to breed.
    private static final int BREEDING_AGE = 0;

    // The age to which an insect can live.
    private static final int MAX_AGE = 19;

    // The likelihood of an insect breeding during the day.
    private static final double DAY_BREEDING_PROBABILITY = 0.33957353234291077;

    // The likelihood of an insect breeding during the night.
    private static final double NIGHT_BREEDING_PROBABILITY = 0.3785300433635712;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;

    // The maximum food level of an insect
    private static final int MAX_FOOD_LEVEL = 26;

    // The food value of an insect when it is eaten
    private static final int foodValue = 7;

    // The move radius of an insect, the radius of the steps it can move
    private static final int MOVE_RADIUS = 1;

    /**
     * Create an insect at a given field and position
     * @param field The field to create the insect in
     * @param loc The location to create the insect in
     */
    public Insect(Field field, Location loc) {
        super(field, loc);
    }

    /**
     * Set the prey of the insect
     */
    protected void setPrey() {
        addPrey(Plant.class);
    }

    /**
     * Toggle the sleep of the insect. Insects never sleep
     */
    public void toggleSleep() {
        setSleep(false);
    }

    /**
     * @return The move radius of the insect
     */
    public int getMoveRadius() {
        return MOVE_RADIUS;
    }

    /**
     * @return The breeding probability of an insect during the day
     */
    public double getDayBreedingProbability() {
        return DAY_BREEDING_PROBABILITY;
    }

    /**
     * @return The breeding probability of an insect during the night
     */
    public double getNightBreedingProbability() {
        return NIGHT_BREEDING_PROBABILITY;
    }

    /**
     * @return The maximum age an insect can live up to.
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * @return The age at which an insect can breed
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return The maximum number of insects a female insect can birth at a time
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return The food value of this insect when eaten
     */
    public int getFoodValue() {
        return foodValue;
    }

    /**
     * @return The maximum food level of this insect
     */
    public int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }
}