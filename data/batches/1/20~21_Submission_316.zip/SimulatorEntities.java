import java.awt.*;
import java.util.LinkedHashMap;

/**
 * This class represents a entities for the simulator. It can hold different entities
 * and adds them to the view of the simulation.
 *
 * Each entity provided must be given with a creation probability as well as a colour
 * for the GUI.
 *
 * @version 2021.02.24
 */
public class SimulatorEntities {

    // Graphical view of simulation
    private final SimulatorView view;

    // LinkedHashMap of animal classes with their associated creation probabilities
    private final LinkedHashMap<Class, Double> entities;

    /**
     * Instantiate SimulatorEntities instance attributes
     * @param view Graphical view of simulation
     * @param entities LinkedHashMap of animal classes with their associated creation probabilities
     */
    public SimulatorEntities(SimulatorView view, LinkedHashMap<Class, Double> entities) {
        this.view = view;
        this.entities = entities;
    }

    /**
     * Add entity and creation probability to LinkedHashMap.
     * Set entity colours
     * @param className Class reference of entity
     * @param creationProbability Creation probability of entity
     * @param colour Colour of entity
     */
    public void addEntity(Class className, double creationProbability, Color colour) {
        entities.put(className, creationProbability);
        view.setColor(className, colour);
    }
}
