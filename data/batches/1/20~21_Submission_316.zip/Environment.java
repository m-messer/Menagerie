/**
 * This class represents the environment of the simulation.
 * It stores the time of the simulation, the weather and its different factors
 * (rain, fog, light, temperature etc).
 *
 * @version 2021.02.24
 */
public class Environment {
    // Non-derived environment factors
    private double rainLevel;
    private double fogLevel;

    // The simulation time
    private final SimulatorTime time;

    /**
     * Create a new environment and set a starting weather
     */
    public Environment() {
        time = new SimulatorTime();
        changeWeather();
    }

    /**
     * Change the weather based on the current season, this is based
     * on the current day/time of the simulation
     */
    public void changeWeather() {
        rainLevel = time.getSeason().getRainProbability();

        // Change fog based on temperature and whether its day or night
        double fog = (isNight()) ? 0.3 : 0;
        fog += (1 - getTemperature()) * 0.6;

        fogLevel = fog;
    }

    /**
     * Get the season enum which represents the current season
     * @return The current season
     */
    public Season getSeason() {
        return time.getSeason();
    }

    /**
     * Increment a step in the environment
     */
    public void incrementStep() {
        time.incrementStep();
    }

    /**
     * Get the current fog level
     * @return The fog level, between 0 and 1
     */
    public double getFogLevel() {
        return fogLevel;
    }

    /**
     * Get the current light level (based on the time of day)
     * @return The current light level, between 0 and 1. 1 = Maximum light level (bright), 0 = Minimum light level (dark)
     */
    public double getLightLevel() {
        if (isNight()) {
            return 0;
        }

        return time.getSeason().getLightProbability();
    }

    /**
     * Get the current temperature based on the season
     * @return The current temperature, between 0 and 1. 1 = Very hot, 0 = Very cold
     */
    public double getTemperature() {
        return time.getSeason().getTemperature();
    }

    /**
     * Get the current rain level
     * @return The rain level, between 0 and 1, 1 = Very rainy, 0 = Not raining at all
     */
    public double getRainLevel() {
        return rainLevel;
    }

    /**
     * Check if it is day time in the simulation
     * @return True if it is day time, false if it is not
     */
    public boolean isDay() {
        return time.isDay();
    }

    /**
     * Whether it is night time
     * @return True if it is currently night time, false if it is not
     */
    public boolean isNight() {
        return time.isNight();
    }
}
