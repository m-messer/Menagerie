/**
 * A simple model of a lizard.
 * Lizards age, move, eat plants, breed, and die.
 *
 * @version 2021.02.24 (3)
 */
public class Lizard extends Animal
{
    // Characteristics shared by all lizards (class variables).

    // The age at which a lizard can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a lizard can live.
    private static final int MAX_AGE = 33;
    // The likelihood of a lizard breeding.
    private static final double DAY_BREEDING_PROBABILITY = 0.38907132148742685;
    private static final double NIGHT_BREEDING_PROBABILITY = 0.2106873989105225;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum food level a lizard can have
    private static final int MAX_FOOD_LEVEL = 46;
    // The food level of the lizard. If a predator eats the lizard then its food value goes up by this amount
    private static final int foodValue = 4;
    // The radius about which the lizard can move in a single step
    private static final int MOVE_RADIUS = 1;

    /**
     * Create a lizard at a given field and position
     * @param field The field to create the lizard in
     * @param loc The location to create the lizard in
     */
    public Lizard(Field field, Location loc) {
        super(field, loc);
    }

    /**
     * Set prey of the lizard
     */
    public void setPrey() {
        addPrey(Plant.class);
    }

    /**
     * @return return breeding probability during the night
     */
    public double getNightBreedingProbability() {
        return NIGHT_BREEDING_PROBABILITY;
    }

    /**
     * @return return breeding probability during the day
     */
    public double getDayBreedingProbability() {
        return DAY_BREEDING_PROBABILITY;
    }

    /**
     * @return returns the breeding age of the lizard
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return return move radius if it's daytime, otherwise return 0
     */
    public int getMoveRadius() {
        return getField().isDay() ? MOVE_RADIUS : 0;
    }

    /**
     * @return returns the max age of the lizard
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * @return returns the max litter size of the lizard
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Sets the lizard to sleep if it's night, otherwise wakes it
     */
    public void toggleSleep() {
        setSleep(getField().isNight());
    }

    /**
     * @return returns the food value of the lizard
     */
    public int getFoodValue() {
        return foodValue;
    }

    /**
     * @return returns the max food level of the lizard
     */
    public int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }
}
