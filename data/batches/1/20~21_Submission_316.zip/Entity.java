import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Random;

/**
 * This abstract class represents an Entity in the simulation. These entities
 * are typically shown in the field and are representatives of living beings, animals
 * and plants.
 *
 * Entities have a location in the field, can be alive, can breed and even
 * become infected with disease
 *
 * @version 2021.02.24
 */
public abstract class Entity {
    // A random shared object
    protected static final Random rand = Randomizer.getRandom();

    // A disease, if this entity has one
    private Disease disease;

    // Whether the entity is alive or dead
    private boolean alive;

    // The field the entity is in
    private final Field field;

    // The location within the field where this entity is
    private Location location;

    /**
     * Create a new entity within a given field and location
     * @param field The field where this entity is
     * @param loc   The location within the field
     */
    public Entity(Field field, Location loc) {
        alive = true;
        this.field = field;
        setLocation(loc);
    }

    /**
     * A shared random number generator used for probability checking
     * @return A shared Random object.
     */
    protected Random getRand() {
        return rand;
    }

    /**
     * Get the breeding probability of this entity, based on the time of day
     * @return A probability between 0 and 1 which represents the breeding probability of this entity
     */
    protected double getBreedingProbability() {
        if (getField().isDay()) {
            return getDayBreedingProbability();
        }
        return getNightBreedingProbability();
    }

    /**
     * Check if this entity is diseased or has recovered.
     */
    protected void checkInfection() {
        if (disease != null) {
            disease.incrementAge();
            if (disease.isAlive() && rand.nextDouble() <= disease.getDeathProbability()) {
                // If disease is still alive, check probability of death
                setDead();
            } else if (!disease.isAlive()) {
                // The disease is no longer active
                disease = null;
            }
        }
    }

    /**
     * Check if any of this entities neighbours are diseased, if they are then infect
     * the current entity based on the spreading probability of the diseases they have
     */
    protected void checkNeighbouringDiseasedEntities() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), 1);

        for (Location where : adjacent){
            Object entity = field.getObjectAt(where);

            if (entity != null && entity.getClass() == this.getClass()) {
                // Same species neighbour
                Entity neighbour = (Entity) entity;
                if (neighbour.isDiseased() && rand.nextDouble() <= neighbour.getDisease().getSpreadProbability() && !isDiseased()) {
                    // Create a copy of the disease with age = 0
                    Disease copy = new Disease(neighbour.getDisease());
                    infect(copy);
                }
            }
        }
    }

    /**
     * Check if this entity is diseased
     * @return True if the entity has an active infection, false if they do not.
     */
    public boolean isDiseased() {
        return disease != null && disease.isAlive();
    }

    /**
     * Get the disease of the current entity
     * @return The disease infecting this entity, or null if it does not have one
     */
    public Disease getDisease() {
        return disease;
    }

    /**
     * Infect the current entity with a disease if it is not already infected
     * @param disease The disease to infect this entity with.
     */
    public void infect(Disease disease) {
        if (!isDiseased()) {
            this.disease = disease;
        }
    }

    /**
     * Set the current entity to be dead, this clears their spot from the field
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
        }
    }

    /**
     * Check if this entity is still alive or not
     * @return True if it is alive, false if it is not
     */
    public boolean isAlive() {
        return alive;
    }

    /**
     * Get the current location of this entity
     * @return A Location object representing the location of this entity in its field
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Place the entity at a new location in the field.
     * @param newLocation The entity's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Check whether or not this entity is to give birth at this step.
     * New births will be placed into free adjacent locations.
     *
     * @param newEntities A list to return newly born entities of the same species.
     */
    public void giveBirth(List<Entity> newEntities) {
        // New entities are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), 1);

        // Get the number of births
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            try {
                // Create a new entity of this species

                Constructor constructor = this.getClass().getConstructor(Field.class, Location.class);
                Entity young = (Entity) constructor.newInstance(field, loc);

                // If the current entity is diseased, potentially pass it
                // onto its newborns
                if (isDiseased()) {
                    if (rand.nextDouble() <= getDisease().getSpreadProbability()) {
                        young.infect(new Disease(getDisease()));
                    }
                } else if (rand.nextDouble() < 0.01) {
                    // If it is not diseased, potentially infect it with a random
                    // infection
                    young.infect(new Disease());
                }

                newEntities.add(young);
            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | InstantiationException e){
                System.out.println(e);
            }
        }
    }

    /**
     * Return the entity's field
     * @return The entity's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * The number of potential young this entity can birth
     * @return The number of entities this entity can potentially give birth to
     */
    protected abstract int breed();

    /**
     * @return The maximum number of entities this entity can give birth to
     */
    protected abstract int getMaxLitterSize();

    /**
     * The main act method of the entity, called in every simulation step.
     * @param newEntities A reference to store any newborns this entity gives birth to
     */
    protected abstract void act(List<Entity> newEntities);

    /**
     * @return The breeding probability of this entity during the day
     */
    protected abstract double getDayBreedingProbability();

    /**
     * @return The breeding probability of this entity during the night
     */
    protected abstract double getNightBreedingProbability();

    /**
     * The food value of this entity
     * @return A number indicating how many "food points" this entity is worth
     */
    protected abstract int getFoodValue();

    /**
     * The move radius of this entity, how far it can move in any given step
     * @return The move radius of this entity
     */
    protected abstract int getMoveRadius();
}
