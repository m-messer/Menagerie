/**
 * A simple model of a scorpion.
 * Scorpions age, move, eat insects, and die.
 *
 * @version 2021.02.24
 */
public class Scorpion extends Animal {
    // Characteristics shared by all scorpions (class variables).

    // The age at which a scorpion can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a scorpion can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a scorpion breeding.
    private static final double DAY_BREEDING_PROBABILITY = 0.3366015563011172;
    private static final double NIGHT_BREEDING_PROBABILITY = 0.2068133592605591;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum food level a scorpion can have
    private static final int MAX_FOOD_LEVEL = 42;
    // The food level of the scorpion. If an animal eats the scorpion then its food value goes up by this amount
    private static final int foodValue = 4;
    // The radius about which the lizard can move in a single step
    private static final int MOVE_RADIUS = 1;

    /**
     * Create a scorpion at a given field and position
     * @param field The field to create the scorpion in
     * @param loc The location to create the scorpion in
     */
    public Scorpion(Field field, Location loc) {
        super(field, loc);
    }

    /**
     * Set prey of the scorpion
     */
    public void setPrey() {
        addPrey(Insect.class);
        addPrey(Plant.class);
    }

    /**
     * @return return breeding probability during the night
     */
    public double getNightBreedingProbability() {
        return NIGHT_BREEDING_PROBABILITY;
    }

    /**
     * @return return breeding probability during the day
     */
    public double getDayBreedingProbability() {
        return DAY_BREEDING_PROBABILITY;
    }

    /**
     * @return returns the breeding age of the scorpion
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return return move radius if it's daytime, otherwise return 0
     */
    public int getMoveRadius() {
        return getField().isDay() ? MOVE_RADIUS : 0;
    }

    /**
     * @return returns the max age of the scorpion
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * @return returns the max litter size of the scorpion
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Sets the scorpion to sleep if it's night, otherwise wakes it
     */
    public void toggleSleep() {
        setSleep(getField().isNight());
    }

    /**
     * @return returns the food value of the scorpion
     */
    public int getFoodValue() {
        return foodValue;
    }

    /**
     * @return returns the max food level of the scorpion
     */
    public int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }
}