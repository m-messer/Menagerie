/**
 * A simple representation of a hawk.
 *
 * A hawk is always active and never sleeps, though it has
 * a reduced movement radius during the day and during
 * foggy weather.
 *
 * It also breeds less during the day compared to the night.
 *
 * @version 2021.02.24
 */
public class Hawk extends Animal {
    // Characteristics shared by all hawks (class variables).

    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 8;

    // The age to which a hawk can live.
    private static final int MAX_AGE = 38;

    // The likelihood of a hawk breeding during the day
    private static final double DAY_BREEDING_PROBABILITY = 0.1562483787536621;

    // The likelihood of a hawk breeding during the night
    private static final double NIGHT_BREEDING_PROBABILITY = 0.20598045289516448;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    // The maximum food level of a hawk
    private static final int MAX_FOOD_LEVEL = 17;

    // The food value of a hawk when eaten
    private static final int foodValue = 12;

    // The hawks normal move radius
    private static final int normalMoveRadius = 2;

    // A reduced move radius for the hawk when it is less active
    private static final int reducedMoveRadius = 1;

    /**
     * Create a hawk at a given field and position
     * @param field The field to create the hawk in
     * @param loc The location to create the hawk in
     */
    public Hawk(Field field, Location loc) {
        super(field, loc);
    }

    /**
     * Toggle the sleep of the hawk. The hawk never sleeps.
     */
    public void toggleSleep() {
        setSleep(false);
    }

    /**
     * Get the move radius of the hawk, the hawk has reduced move radius during the day
     * and during foggy weather
     * @return The move radius of the hawk
     */
    public int getMoveRadius() {
        if (getField().getFogLevel() >= 0.5 || getField().isDay()) {
            return reducedMoveRadius;
        } else {
            return normalMoveRadius;
        }
    }

    /**
     * @return The breeding probability during the day
     */
    public double getDayBreedingProbability() {
        return DAY_BREEDING_PROBABILITY;
    }

    /**
     * @return The breeding probability during the night
     */
    public double getNightBreedingProbability() {
        return NIGHT_BREEDING_PROBABILITY;
    }

    /**
     * Add the hawks prey
     */
    public void setPrey() {
        addPrey(Lizard.class);
        addPrey(Scorpion.class);
    }

    /**
     * @return The maximum age of the hawk
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * @return The age at which the hawk can breed
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return The maximum number of hawks a female hawk can birth at a time
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return The food value of the hawk when eaten
     */
    public int getFoodValue() {
        return foodValue;
    }

    /**
     * @return The maximum food level of the hawk
     */
    public int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }
}