import java.util.Random;

/**
 *
 * This class is an enumeration of objects which represent the different
 * seasons that the simulator environment can have.
 *
 * Each season is created with minimum and maximum bounds for the rain and light level, these
 * together influence the various other factors, such as temperature and fog level. This allows
 * the weather patterns for each season to be more finely tuned to allow a higher probability
 * of, for example, rain.
 *
 * @version 2021.02.24
 */
public enum Season {
    // The 4 seasons
    SPRING(0.3, 0.7, 0.3, 0.8),
    SUMMER(0.3, 0.6, 0.4, 0.9),
    AUTUMN(0.5, 0.8, 0.2, 0.4),
    WINTER(0.5, 0.9, 0.1, 0.3);

    private final double minRainProbability;
    private final double maxRainProbability;
    private final double minLightProbability;
    private final double maxLightProbability;

    // Current rain and light levels
    private double rainLevel;
    private double lightLevel;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Instantiate season
     * @param minRain minimum rain probability
     * @param maxRain maximum rain probability
     * @param minLight minimum light probability
     * @param maxLight maximum light probability
     */
    Season(double minRain, double maxRain, double minLight, double maxLight) {
        minLightProbability = minLight;
        maxLightProbability = maxLight;
        minRainProbability = minRain;
        maxRainProbability = maxRain;

    }

    /**
     * Get the temperature at the current step
     * Influenced by rain and light levels
     * @return temperature (range 0 -> 1)
     */
    public double getTemperature() {
        double temperature = 0.5;
        temperature += 0.7 * lightLevel;
        temperature -= 0.5 * rainLevel;

        if (temperature < 0) {
            return 0;
        }
        if (temperature > 1) {
            return 1;
        }
        return temperature;
    }

    /**
     * @return return rain probability
     */
    public double getRainProbability() {
        rainLevel = rand.nextDouble() * (maxRainProbability - minRainProbability) + minRainProbability;
        return rainLevel;
    }

    /**
     * @return return light probability
     */
    public double getLightProbability() {
        lightLevel = rand.nextDouble() * (maxLightProbability - minLightProbability) + minLightProbability;
        return lightLevel;
    }
}
