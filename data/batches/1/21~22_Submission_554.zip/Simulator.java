import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 *  
 * 
 * A simple predator-prey simulator, based on a rectangular field
 * with the setting being a Sahara Desert. This simulation has been 
 * enhances to mock a typical food chain with eagles, hawks and snakes
 * being the predators, lizards and mice being the prey that eat plants.
 * The simulation involves various real-life actions in a habitat, such
 * as moving round, hunting, mating, breeding, growth, death and so on.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default dimensions for the grid.
    private static final int DEFAULT_WIDTH = 400;
    private static final int DEFAULT_DEPTH = 200;

    //Predator creation probabilities
    // The probability that a predator will be created in any given grid position.
    private static final double EAGLE_CREATION_PROBABILITY = 0.05;
    private static final double HAWK_CREATION_PROBABILITY = 0.06; 
    private static final double SNAKE_CREATION_PROBABILITY = 0.04; 

    //Prey creation probabilities
    // The probability that a prey will be created in any given grid position.
    private static final double LIZARD_CREATION_PROBABILITY = 0.30;    
    private static final double MOUSE_CREATION_PROBABILITY = 0.30; 

    //Plant creation probabilities
    // The probability that a plant will be created in any given grid position.    
    private static final double PLANT_CREATION_PROBABILITY = 0.06; 

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current step of the simulation.
    private int step;
    //whether it is day time or not
    private boolean isDay = true;
    //string representing the time of the day
    private String timeString;

    //Main methods to run the simulation
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Eagle.class, Color.ORANGE);
        view.setColor(Hawk.class, Color.RED);
        view.setColor(Snake.class, Color.BLACK);

        view.setColor(Lizard.class, Color.PINK);
        view.setColor(Mouse.class, Color.BLUE);

        view.setColor(Plant.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period.
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    //Tier 1: Sub methods used in the main simulation methods.
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * Switches simulation to nigttime every 24 steps. This way, animals 
     * could have different actions depending on time of the day.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            //switch the settings to nighttime every 24 steps.
            if(step %24 == 0){
                isDay = false;
                timeString = "Nighttime";
            }
            else{
                timeString = "Daytime";
            }
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Returns true if daytime and false if nighttime.
     */
    public boolean isDay(){
        return isDay;
    }

    /**
     * Returns a string to represent the time of the day.
     * String is in the form "Daytime"/ "Nighttime."
     */
    public String timeString(){
        return timeString;
    }

    //Tier 2: Sub methods used in the tier 1 methods.
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random random = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(random.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    plants.add(plant);
                }
                else if(random.nextDouble() <= EAGLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(true, field, location);
                    animals.add(eagle);
                }
                else if(random.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(true, field, location);
                    animals.add(hawk);
                    // else leave the location empty.
                }
                else if(random.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);

                }
                else if(random.nextDouble() <= LIZARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lizard lizard = new Lizard(true, field, location);
                    animals.add(lizard);
                }
                else if(random.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }
            }
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all new animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add all the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds   
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
