import java.util.Iterator;
import java.util.List;
import java.util.Random;
/** 
 * 
 * A simple model of a fox.
 * Foxes age, move, eat prey, breed and die.
 *
 * @version 2016.02.29 (2)
 */
public class Eagle extends Predator
{
    // Characteristics shared by all eagles (class fields).

    //class types
    // A random number generator.
    private static final Random random = Randomizer.getRandom();
    private Prey prey;

    //primitive types
    // The age at which an eagle can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which an eagle can live.
    private static final int MAX_AGE = 150;
    // The likelihood of an eagle breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births at a time.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single prey; the number of steps an eagle 
    //can go before it has to eat again.
    private static final int PREY_FOOD_VALUE = 10;

    // Individual characteristics (instance fields).
    // The eagles's age.
    private int age;
    // The eagles's food level, which is increased by eating prey.
    private int foodLevel;
    /**
     * Create an eagle. An eagle can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the eagle will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Eagle(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = random.nextInt(MAX_AGE);
            foodLevel = random.nextInt(PREY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PREY_FOOD_VALUE;
        }
    }

    //Main methods to simulate eagle's actions.
    /**
     * This is what the eagle does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newEagels A list to return newly born eagles.
     */
    public void act(List<Animal> newEagles)
    {
        //pauseAct();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            meet(newEagles);           
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    //Tier 1: Sub methods used in the main act methods.
    /**
     * Increase the age. This could result in the eagle's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this eagle more hungry. This could result in the eagle's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Allows the eagle mate with other eagles when in contact, only if one is female 
     * and the other is male.
     */
    private void meet(List<Animal> newEagles){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        Object animal1 = field.getObjectAt(getLocation());
        while(it.hasNext()){
            Location occupied = it.next();
            Object animal2 = field.getObjectAt(occupied);
            if (animal1 instanceof Eagle && animal2 instanceof Eagle){
                Eagle breeder = (Eagle) animal1;
                Eagle breedingMate = (Eagle) animal2;
                if((breeder.isFemale() && !breedingMate.isFemale()) 
                || (!breeder.isFemale() && breedingMate.isFemale()))
                {
                    giveBirth(newEagles); 
                }
            }
        }
    }  

    /**
     * Check whether or not this eagle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born eagles.
     */
    private void giveBirth(List<Animal> newEagles)
    {
        // New eagles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Eagle young = new Eagle(false, field, loc);
            newEagles.add(young);
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    //Tier 2: Sub methods used in the tier 1 methods.
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && random.nextDouble() <= BREEDING_PROBABILITY) {
            births = random.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An eagle can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
} 
