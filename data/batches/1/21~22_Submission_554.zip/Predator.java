import java.util.List;
import java.util.Random;
/**
 *  
 * A class representing shared characteristics of predators.
 *
 * @version 2022.02.27 (1)
 */
public abstract class Predator extends Animal 
{
    //class types
    //a random number generator.
    private static final Random random = Randomizer.getRandom();
    private Simulator simulator;
    /**
     * Create a new predator of a random age, at location in field.
     * @param randomAge The age of the predator, randomly selected.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Make this predator act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPredator A list to receive newly born predators.
     */
    abstract public void act(List<Animal> newPredator);

    /**
     * Makes the predator sleep, on the condition that it is nighttime.
     */
    protected void pauseAct(){
        if(simulator.isDay() != true){
            sleep();
        }
    }

    /**
     * Makes the animal sleep, by doing nothing.
     */
    public void sleep(){
        ;
    }
}  
