import java.util.Random;
/**
 *  
 * 
 * A simple model of a plant.
 *
 * @version 2022.02.27 (1)
 */
public class Plant
{
    // Characteristics shared by all plants (class field).

    //class types
    private Field field;//
    private Location location;//
    //a random number generator.
    private static final Random random = Randomizer.getRandom();

    //primitive types
    // The age at which a rabbit can start to breed.
    private static final double GROWTH_PROBABILITY = 0.5;
    private boolean alive; //whether the plant is alive or not
    private boolean toxic; // wheter the plant if toxic or not

    // Individual characteristics (instance fields).
    // The plant's nutrient level, which is increased depending on growth.
    private int nutrients;
    
    //Main methods to simulate plant's life
    /**
     * Creates a plant that will be placed in a random location within the grid
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        toxic = random.nextBoolean(); //randomly assign toxicity to plants
        grow();
    }

    /**
     * 
     * gives the plant location coordinates   
     * 
     */
    public void setLocation(Location newloc)
    {
        if(location != null){
            field.clear(location);
        }
        location = newloc;
        field.place(this, newloc);
    }

    /**
     * @return true if plant is toxic and false if not
     */
    public boolean plantIsToxic(){
        return toxic;
    }
    
    //Tier 1: Sub methods used in the main simulation methods.
    /**
     * Allows the plants to grow, improving its nutrient level, which
     * is of benefit to the prey.
     */
    private void grow()
    {
        int nutrients = 0;
        if( random.nextDouble() <= GROWTH_PROBABILITY) {
            nutrients = random.nextInt(2) + 1;
        }
    }

    /**
     * Track the plant's nutrient level.
     * @return The nutrient level.
     */
    public int trackNutrients()
    {
        return nutrients;
    }
    
    //Tier 2: Sub methods used in the tier 1 methods.
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void killPlant(){
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
        nutrients = 0;
    }
}
