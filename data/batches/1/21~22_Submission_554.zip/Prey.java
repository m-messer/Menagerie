import java.util.List;
import java.util.Random;
/**
 *  
 * 
 * A class representing shared characteristics of prey.
 *
 * @version 2022.02.27 (1)
 */
public abstract class Prey extends Animal 
{
    //class types
    //a random number generator.
    private static final Random random = Randomizer.getRandom();
    /**
     * Create a new prey of a random age, at location in field.
     * @param randomAge The age of the prey, randomly selected.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this prey act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPrey A list to receive newly born prey.
     */
    abstract public void act(List<Animal> newPrey);
}  
