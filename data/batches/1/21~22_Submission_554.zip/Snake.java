import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 *  
 * 
 * A simple model of a snake.
 * Snakes age, move, eat prey, breed and die.
 *
 * @version 2016.02.29 (2)
 */
public class Snake extends Predator
{
    // Characteristics shared by all snakes (class fields).

    //class types
    // A random number generator.
    private static final Random random = Randomizer.getRandom();
    private Prey prey;
    
    //primitive types
    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a snake can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.27;
    // The maximum number of births at a time.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single prey; the number of steps a snake 
    //can go before it has to eat again.
    private static final int PREY_FOOD_VALUE = 8;

    // Individual characteristics (instance fields).
    // The snake's age.
    private int age;
    // The snake's food level, which is increased by eating prey.
    private int foodLevel;
    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = random.nextInt(MAX_AGE);
            foodLevel = random.nextInt(PREY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PREY_FOOD_VALUE;
        }
    }

    //Main methods to simulate snake's actions.
    /**
     * This is what the snake does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSnakes A list to return newly born snakes.
     */
    public void act(List<Animal> newSnakes)
    {
        //pauseAct();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            meet(newSnakes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    //Tier 1: Sub methods used in the main act methods.
    /**
     * Increase the age. This could result in the snake's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this snake more hungry. This could result in the snake's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Allows the snake mate with other snake when in contact, only if one is female 
     * and the other is male.
     */
    private void meet(List<Animal> newSnakes){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        Object animal1 = field.getObjectAt(getLocation());
        while(it.hasNext()){
            Location occupied = it.next();
            Object animal2 = field.getObjectAt(occupied);
            if (animal1 instanceof Snake && animal2 instanceof Snake){
                Snake breeder = (Snake) animal1;
                Snake breedingMate = (Snake) animal2;
                if((breeder.isFemale() && !breedingMate.isFemale()) 
                || (!breeder.isFemale() && breedingMate.isFemale())){
                    giveBirth(newSnakes);
                }
            }
        }
    }  

    /**
     * Check whether or not this snake is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSnakes A list to return newly born snakes.
     */
    private void giveBirth(List<Animal> newSnakes)
    {
        // New snakes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Snake young = new Snake(false, field, loc);
            newSnakes.add(young);
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    //Tier 2: Sub methods used in the tier 1 methods.
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && random.nextDouble() <= BREEDING_PROBABILITY) {
            births = random.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A snake can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
} 
