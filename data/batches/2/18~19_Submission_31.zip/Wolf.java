import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a wolf.
 * Wolves age, move, eat gazelles, and die.
 *
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).
    
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;

    // The food value of a single gazelle. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int GAZELLE_FOOD_VALUE = 9;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // boolean value showing if the wolf has the disease
    private boolean hasDisease;

    // The step number when this wolf is due to die (due to disease)
    private int deathSentence;
   
    
    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location, false);
        foodSource = Gazelle.class;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GAZELLE_FOOD_VALUE);

        }
        else {
            age = 0;
            foodLevel = GAZELLE_FOOD_VALUE;
        }

        // Wolves are capable of catching a disease
        Random rng = new Random();

        if (rng.nextInt(300) == 1) {
            infect();
        }
    }
    
    /**
     * This is what the wolf does most of the time: it hunts for
     * gazelles. In the process, it might breed, die of hunger,
     * or die of old age.
     * The wolf is nocturnal - so it only acts during the night
     * @param field The field currently occupied.
     * @param newWolves A list to return newly born wolves.
     */
    public void act(List<Organism> newWolves, boolean isNight)
    {
        incrementAge();
        incrementHunger();
        incrementStep();

        // if the wolf has the disease and is due to die
        // then set to dead
        if (hasDisease && stepCounter == deathSentence) {
            setDead();
        }
        
        if(isNight)
        {
            // It is nighttime - these wolves are nocturnal so they act only during the night.
        
            if(isAlive()) {
                giveBirth(newWolves);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), false);
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * Increase the age. This could result in the wolf's death.
     */
    @Override()
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Get the food value that this wolf recieves when it eats a Gazelle
     * @return the food value of the Gazelle
     */
    protected int getPreyFoodValue()
    {
        return GAZELLE_FOOD_VALUE;
    }
    
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolves.
     */
    private void giveBirth(List<Organism> newWolves)
    {
        if(maleNearby() && isFemale()){
            // New wolves are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), false);
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Wolf young = new Wolf(false, field, loc);

                // If this wolf has the disease, there is a 1% chance that
                // the offspring will catch the disease
                if (hasDisease && rand.nextInt(100) == 1) {
                    young.infect();
                }
                
                newWolves.add(young);
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A wolf can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

     /**
     * Accessor method for the food source
     * @return foodSource Class object
     */
    public Class getFoodSource()
    {
        return foodSource;
    }


    /**
     * Infects the wolf with the disease by setting the boolean value to true
     * and setting the deathSentence property to 5 steps from now
     * This is when they are due to die.
     */
    private void infect() {
        hasDisease = true;
        deathSentence = stepCounter + 5;
    }
}
