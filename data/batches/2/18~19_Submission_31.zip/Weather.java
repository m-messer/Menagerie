import java.util.Random;
/**
 * Write a description of class Weather here.
 *
 * @version (a version number or a date)
 */
public class Weather
{
    // Properties
    private int rain;
    private int sunlight;
    
    public Weather()
    {
        // Set default values for rain and sunlight
        rain = 1;
        sunlight = 1;
    }
    
    /**
     * Generate new random values for the rainfall and sunlight values
     */
    public void nextStep()
    {
        Random rng = new Random();
        
        // Rain Probabilities
        // Complete Drought: 0.5%;
        // No Rain = 15%;
        // Little Rain = 77%
        // Lot of Rain = 8%
        if (rng.nextDouble() < 0.005) {
            // complete drought
            rain = -1;
        }
        else if (rng.nextDouble() < 0.08) {
            // Lots of rain
            rain = 2 + rng.nextInt(3); // random number between 2 and 4
        } else if (rng.nextDouble() < 0.78) {
            // Little bit of rain
            rain = 1;
        } else {
            // No rain
            rain = 0;
        }
        
        
        // Sunlight Probabilities
        // No Sunlight = 4.5%;
        // Little Sunlight = 45%
        // Lot of Sunlight = 50%
        if (rng.nextDouble() < 0.05) {
            // No sunlight
            sunlight = 0;
        } else if (rng.nextDouble() < 0.5) {
            // Little bit of sunlight
            sunlight = 1;
        } else {
            // Lots of sunglight
            sunlight = 2 + rng.nextInt(3); // random number between 2 and 4
        }
    }

    /**
     * Accessor method for the rain property
     * @return an integer representing the current amount of rainfall
     */
    public int getRain()
    {
        return rain;
    }
    
    /**
     * Accessor method for the sunlight property
     * @return an integer representing the current sunlight levels
     */
    public int getSunlight()
    {
        return sunlight;
    }

}
