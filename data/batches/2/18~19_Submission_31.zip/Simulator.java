import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Gazelles and wolves.
 *
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.1;
    // The probability that a gazelle will be created in any given grid position.
    private static final double GAZELLE_CREATION_PROBABILITY = 0.2;  
    // The probability that a camel will be created in any given grid position.
    private static final double CAMEL_CREATION_PROBABILITY = 0.2;  
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.08;  
    // The probability that grass will grow in any given grid position.
    private static final double GRASS_GROW_PROBABILITY = 0.5;  

    // List of animals in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Gazelle.class, Color.YELLOW);
        view.setColor(Camel.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Lion.class, Color.BLACK);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(120);
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public void simulateOneStep()
    {
        step++;
        
        // Provide space for newly created organisms.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all Gazelles act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms, isNight());
            field.getWeather().nextStep();
            if(!organism.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }
    
    private boolean isNight() {
        // 50% of the time it is night (every other step)
        if (step % 2 == 0) {
            return true;
        }

        // else
        return false;
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with organisms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, false);
                    Wolf wolf = new Wolf(true, field, location);
                    organisms.add(wolf);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, false);
                    Lion lion = new Lion(true, field, location);
                    organisms.add(lion);
                }
                else if(rand.nextDouble() <= GAZELLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, false);
                    Gazelle gazelle = new Gazelle(true, field, location);
                    organisms.add(gazelle);
                }
                else if(rand.nextDouble() <= CAMEL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, false);
                    Camel camel = new Camel(true, field, location);
                    organisms.add(camel);
                }
                
                
                // For plants
                if(rand.nextDouble() <= GRASS_GROW_PROBABILITY) {
                    Location location = new Location(row, col, true);
                    Grass grass = new Grass(field, location);
                    organisms.add(grass);
                }
                
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
