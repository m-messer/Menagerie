import java.util.List;

/**
 * Abstract class Organism - write a description of the class here
 *
 */
public abstract class Organism
{

    // The organism's position on the field.
    private Location location;

    // The organism's field.
    public Field field;

    // Whether the organism is alive or not.
    private boolean alive;
    
    // The organism's food level, which is increased by eating a food source (or by photosynthesis).
    protected int foodLevel;
    
    // The organism's age
    protected int age;

    public Organism(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);   
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    
    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly created organisms.
     */
    abstract public void act(List<Organism> newOrganisms, boolean isNight);
    
    /**
     * Increment the organism's age
     */
    protected void incrementAge(){
        age++;
    }
    
}
