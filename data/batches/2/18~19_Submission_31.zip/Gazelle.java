import java.util.List;
import java.util.Random;

/**
 * A simple model of a Gazelle.
 * Gazelles age, move, breed, and die.
 *
 */
public class Gazelle extends Animal
{
    // Characteristics shared by all Gazelles (class variables).
 
    // The age at which a Gazelle can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Gazelle can live.
    private static final int MAX_AGE = 2;
    // The likelihood of a Gazelle breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // food value that the Gazelle recieves when it eats grass
    private static final int GRASS_FOOD_VALUE = 3;


    /**
     * Create a new Gazelle. A Gazelle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Gazelle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gazelle(boolean randomAge, Field field, Location location)
    {
        super(field, location, true);

        foodSource = Grass.class;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * This is what the Gazelle does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGazelles A list to return newly born Gazelles.
     */
    public void act(List<Organism> newGazelles, boolean isNight)
    {
        incrementAge();
        incrementStep();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newGazelles);            
            // Move towards a source of food if found.

            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation(), false);
            }
            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }

        }
    }


    /**
     * Get the food value that this Gazelle recieves when it eats grass
     * @return the food value of the grass
     */
    protected int getPreyFoodValue()
    {
        return GRASS_FOOD_VALUE;
    }

    /**
     * Accessor method for the food source
     * @return foodSource Class object
     */
    public Class getFoodSource()
    {
        return foodSource;
    }


    /**
     * Increase the age.
     * This could result in the Gazelle's death.
     */
    @Override()
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this Gazelle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGazelles A list to return newly born Gazelles.
     */
    private void giveBirth(List<Organism> newGazelles)
    {
        if(maleNearby() && isFemale()){
            // New Gazelles are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), false);
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Gazelle young = new Gazelle(false, field, loc);
                newGazelles.add(young);
            }

        }

    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Gazelle can breed if it has reached the breeding age.
     * @return true if the Gazelle can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
