import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a lion.
 * Lions age, move, eat camels, and die.
 *
 */
public class Lion extends Animal
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.001;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single camel. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int CAMEL_FOOD_VALUE = 9;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location, false);
        foodSource = Camel.class;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CAMEL_FOOD_VALUE);

        }
        else {
            age = 0;
            foodLevel = CAMEL_FOOD_VALUE;
        }
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * camels. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLions A list to return newly born lions.
     */
    public void act(List<Organism> newLions, boolean isNight)
    {
        incrementAge();
        incrementHunger();
        incrementStep();

        // Check if it is daytime - Lions only act during the day
        if(!isNight)
        {
            // It is daytime.

            if(isAlive()) {
                giveBirth(newLions);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), false);
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the lion's death.
     */
    @Override()
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Get the food value that this lion recieves when it eats a Camel
     * @return the food value of the Camel
     */
    protected int getPreyFoodValue()
    {
        return CAMEL_FOOD_VALUE;
    }

    /**
     * Accessor method for the food source
     * @return foodSource Class object
     */
    public Class getFoodSource()
    {
        return foodSource;
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    private void giveBirth(List<Organism> newLions)
    {
        if(maleNearby() && isFemale()){
            // New lions are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), false);
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Lion young = new Lion(false, field, loc);
                newLions.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A lion can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

}
