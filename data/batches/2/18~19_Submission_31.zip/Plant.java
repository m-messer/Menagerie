import java.util.Random;
import java.util.Iterator;
import java.util.List;

/**
 * Abstract class Plants - write a description of the class here
 *
 */
public abstract class Plant extends Organism
{

    // Whether the plant is alive or not.
    protected boolean alive;
    // The plant's field.
    protected Field field;
    // The plant's position on the field.
    private Location location;

    // the plant's age
    protected int age;

    // The plant's food level, which is increased by getting combination of sunlight + water
    protected int foodLevel;

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location) 
    {
        super(field, location);
    }

    
    /**
     * Feed the plant via photosynthesis (absorbtion of water and sunlight)
     * This method gets rain and sunlight data from the Weather object on the field
     * and then uses it to increment the foodLevel appropriately
     * The more water and sunlight there is, the more the food level increases
     */
    protected void photosynthesis() {
        // "eat" (get sunlight + water(rain) levels from "Weather" object and then increase foodLevels

        Weather weather = getField().getWeather();
        double rain = weather.getRain();
        double sunlight = weather.getSunlight();

        foodLevel += rain*sunlight;
    }


    /**
     * Reproductive method for plants
     * @param newPlants A list to return the newly grown plants
     */
    protected void disperseSeeds(List<Organism> newPlants) {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), true);
        int seeds = createSeeds();
        for(int b = 0; b < seeds && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass grassSeed = new Grass(field, loc);
            newPlants.add(grassSeed);
        }
    }
    
    // Method that returns a random number of seeds
    abstract protected int createSeeds();
}
