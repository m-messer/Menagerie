import java.util.List;
import java.util.Random;

/**
 * Write a description of class Grass here.
 *
 */
public class Grass extends Plant
{
    // The age at which grass grows its seed heads
    private static final int SEEDING_AGE = 3;
    // The likelihood of grass seed being generated
    private static final double SEEDING_PROBABILITY = 0.85;
    // The maximum number of seeds a grass plant can create
    private static final int MAX_SEEDS = 3;
    // A shared random number generator to control breeding/seeding
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Grass
     */
    public Grass(Field field, Location location)
    {
        super(field, location);

        // Set the food level of the grass
        Random rng = new Random(); 
        // set foodLevel to random integer between 0 and 50
        foodLevel = rng.nextInt(50);
    }

    /**
     * This is what the Grass does most of the time
     * @param newGrass A list to return newly grown grass
     * @param isNight boolean value stating if it is nightime
     */
    public void act(List<Organism> newGrass, boolean isNight)
    {
        // increment age
        age++;

        if (isAlive()) {
            disperseSeeds(newGrass);
            
            // Only carry out photosynthesis during daytime
            if (!isNight) {
                photosynthesis();
            }
        }

        decreaseFoodLevel();
    }

    /**
     * Checks whether the plant is old enough to produce seeds
     */
    private boolean canSeed() {
        return age > SEEDING_AGE;
    }

    /**
     * Generate a number for the amount of seeds that this grass plant produces
     */
    protected int createSeeds() {
        if (canSeed() && rand.nextDouble() > SEEDING_PROBABILITY) {
            return rand.nextInt(MAX_SEEDS);
        }
        return 0;
    }

    /**
     * Decrease the foodLevel 
     */
    private void decreaseFoodLevel() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }
}
