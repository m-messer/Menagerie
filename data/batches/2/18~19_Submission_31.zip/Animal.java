import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A class representing shared characteristics of animals.
 *
 */
public abstract class Animal extends Organism
{

    // states if animal if female (i.e. can give birth)
    private boolean female;

    // The animal's age
    protected int age;

    // The animal's step counter
    protected int stepCounter;

    // states whether this animal is a herbivore (i.e. eats plants)
    protected boolean herbivore;

    // The Class object that holds the food source (the prey or plant)
    protected Class foodSource;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, boolean herbivore) 
    {
        super(field, location);
        this.herbivore = herbivore;

        // Randomly set the gender of this animal
        Random rng = new Random();
        if(rng.nextInt(2) == 1){
            female = true;
        }
        else{
            female = false;
        }
    }

    // Abstract method that returns the food value gained by eating foodSource
    protected abstract int getPreyFoodValue();

    protected void incrementStep(){
        stepCounter++;
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }    

    /**
     * Accessor method for the female property
     * @return true if the animal is female
     */
    protected boolean isFemale(){
        return female;
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first food source is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), herbivore);

        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object tile = field.getOrganismsAt(where, herbivore);

            // if the object is an instance of class organism
            if(tile instanceof Organism) {
                Organism foodSource = (Organism) tile; // cast to organism
                if(getFoodSource().isInstance(foodSource)) // if the organism is a food source for 
                {                                              // this animal
                    if(foodSource.isAlive()) { // eat the organism 
                        foodSource.setDead();
                        foodLevel = getPreyFoodValue();
                        where.setToAnimalSlot();
                        return where;
                    }
                }

            }
        }
        return null;
    }

    /**
     * Search nearby area for a male
     * If there is a male, then breed.
     */
    protected boolean maleNearby()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), false);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getOrganismsAt(where);

            // if the animal is an instance of the calling object
            if(this.getClass().isInstance(animal)) {
                // if fox is male
                // we have to cast to animal before accessing isFemale method
                if(!((Animal)animal).isFemale()) {
                    return true;
                }
            }
        }
        // return false if a male couldn't be found in close proximity
        return false;
    }

    abstract protected Class getFoodSource();

}
