/**
 * Represent a location in a rectangular grid.
 *
 * @version 2016.02.29
 */
public class Location
{
    // Row and column positions.
    private int row;
    private int col;
    
    // boolean that shows if a plant is at this location
    private boolean isPlant;

    /**
     * Represent a row and column.
     * @param row The row.
     * @param col The column.
     */
    public Location(int row, int col, boolean isPlant)
    {
        this.row = row;
        this.col = col;
        this.isPlant = isPlant;
    }
    
    /**
     * Implement content equality.
     */
    public boolean equals(Object obj)
    {
        if(obj instanceof Location) {
            Location other = (Location) obj;
            return row == other.getRow() && col == other.getCol() && getSlotIndex() == other.getSlotIndex();
        }
        else {
            return false;
        }
    }
    
    /**
     * Return a string of the form row,column
     * @return A string representation of the location.
     */
    public String toString()
    {
        return row + "," + col;
    }
    
    /**
     * Use the top 16 bits for the row value and the bottom for
     * the column. Except for very big grids, this should give a
     * unique hash code for each (row, col) pair.
     * @return A hashcode for the location.
     */
    public int hashCode()
    {
        return (row << 16) + col;
    }
    
    /**
     * Get the index of the array at the current location
     * @return A hashcode for the location.
     */
    public int getSlotIndex() {
        return getSlotIndex(isPlant);
    }
    
    // test method
    
    /*public void setSlotIndex(int index) {
        isAnimal = false;
    }*/
    
    public void setToAnimalSlot() {
        this.isPlant = false;
    }
    
    /**
     * Get the index of the array at the current location
     * @return A hashcode for the location.
     */
    public int getSlotIndex(boolean isPlant) {
        if (isPlant) {
            return 0;
        } else {
            return 1;
        }
    }
    
    /**
     * @return The row.
     */
    public int getRow()
    {
        return row;
    }
    
    /**
     * @return The column.
     */
    public int getCol()
    {
        return col;
    }
}
