import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of hunters.
 *
 * @version 2021.02.28
 */
public class Hunter
{
    // maximum kills
    private static final int MAX_KILLS = 3;
    // The hunter's field.
    private Field field;
    // The hunter's position in the field.
    private Location location; 
    // The probability that the species will be created in any given grid position.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new hunter at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hunter(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this hunter act - that is: make it do
     * whatever it wants/needs to do.
     * @param newHunters A list to receive newly born hunters.
     */
    public void act(List<Hunter> newHunters){
        if(isAlive()) {          
            // Move towards a source of food if found.
            Location newLocation = hunt();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
        }
    }
    
    /**
     * Look for species adjacent to the current location.
     * Only the first live specie is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location hunt(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        int kills = 0;
        while(it.hasNext() && kills < MAX_KILLS) {
            Location where = it.next();
            Object hunter = field.getObjectAt(where);
            if(hunter instanceof Animal) {
                Animal firedAnimal = (Animal) hunter;
                if(firedAnimal.isAlive()) { 
                    firedAnimal.setDead();
                    kills++;
                }
            }
            
            else if(hunter instanceof Plant){
                Plant firedPlant = (Plant) hunter;
                if(firedPlant.isAlive()) { 
                    firedPlant.setDead();
                    kills++;
                }
            }
        }
        return null;
    }

    /**
     * Return the hunter's location.
     * @return The hunter's location.
     */
    private Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the hunter at the new location in the given field.
     * @param newLocation The hunter's new location.
     */
    private void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the hunter's field.
     * @return The hunter's field.
     */
    private Field getField()
    {
        return field;
    }
    
    /**
     * Check whether the hunter is alive or not.
     * @return true if the hunter is still alive.
     */
    public boolean isAlive(){
        return true;
    }
}
