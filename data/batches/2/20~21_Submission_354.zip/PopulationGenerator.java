import java.awt.Color;
import java.util.List;
import java.util.Random;

/**
 * The class is to gengerate all the species
 *
 * @version 2021.02.28
 */
public class PopulationGenerator
{
    private static final double WOLF_CREATION_PROBABILITY = 0.08;
    // The probability that a wolf will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.10;    
    // The probability that a sheep will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.16;
    // The probability that a deer will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.08;
    // The probability that a tiger will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.15;
    // The probability that the grass will be created in any given grid position.
    private static final double HUNTER_CREATION_PROBABILITY = 0.01;
    // The probability that a hunter will be created in any given grid position.
    
    /**
     * Populator Generator Constructor
     * @param view
     */
    public PopulationGenerator(SimulatorView view)
    {
        //set up the color of species
        view.setColor(Tiger.class, Color.BLACK);
        view.setColor(Sheep.class, Color.PINK);
        view.setColor(Deer.class, Color.ORANGE);
        view.setColor(Hunter.class,Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Wolf.class, Color.BLUE);
    }

    /**
     * Randomly populate the field with species.
     * @param field The field to be populated.
     * @param animals A list of all the animals generated.
     * @param plants A list of all the plants generated.
     * @param hunters A list of all the hunters generated.
     */
    public void populate(Field field, List<Animal>animals, List<Plant>plants, List<Hunter> newHunters)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(rand.nextBoolean(), true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sheep sheep = new Sheep(rand.nextBoolean(), true, field, location);
                    animals.add(sheep);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(rand.nextBoolean(), true, field, location);
                    animals.add(deer);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(rand.nextBoolean(), true,false, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    plants.add(grass);
                }
                else if(rand.nextDouble() <= HUNTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hunter hunter = new Hunter(field, location);
                    newHunters.add(hunter);
                }
                }
        }
        
    }
}