import java.util.ArrayList;
import java.util.Random;
/**
 * A class representing shared characteristics of weather.
 *
 * @version 2021.02.28
 */
public class Weather
{
    private  ArrayList<String> weatherList;
    private  Random rand;
    private  String curWeather;
    /**
     * create a weather list.
     * add weather into the weatherlist
     */
    public Weather()
    {
         weatherList= new ArrayList<>();
         rand= new Random();
         weatherList.add("sunny");
         weatherList.add("fog");
         weatherList.add("rainy");
    }
    
    /**
     * randomly generate a weather
     */
    public void randWeather(){
        curWeather = weatherList.get(rand.nextInt(weatherList.size()));
    }
    
    /**
     * check current Weather
     */
    public String getWeather(){
        return curWeather;
    }
}