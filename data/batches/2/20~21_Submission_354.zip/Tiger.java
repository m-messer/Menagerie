import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a tiger.
 * Tigers age, move, eat sheep and deer, breed and die.
 *
 * @version 2021.02.28
 */
public class Tiger extends Animal
{
    // Characteristics shared by all tigers (class variables).
    
    // The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a tiger can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single sheep or deer. In effect, this is the
    // number of steps a tiger can go before it has to eat again.
    private static final int TOTAL_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The rate of infection by virus.
    private static final double infectionRate=0.08;
    // The disease value
    private static int diseaseValue=10;
    // True if the tiger is infected
    private boolean infected;
    // The diseaseLevel
    private int diseaseLevel;
    
    // The tiger's age.
    private int age;
    // The tiger's food level, which is increased by eating sheep or deers.
    private int foodLevel;
    
    /**
     * Create a new tiger. A tiger may be created with age
     * zero (a new born) or with a random age.
     * A tiger is created with gender and food level.
     * 
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender Distinguish between male and female.
     * @param infected If true, the tiger is infected.
     */
    public Tiger(boolean gender, boolean randomAge,boolean infected, Field field, Location location)
    {
        super(gender, field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(TOTAL_FOOD_VALUE);
            infected=rand.nextBoolean();
            if(infected){
                diseaseLevel=rand.nextInt(diseaseValue);
            }
        }
        else {
            age = 0;
            foodLevel = TOTAL_FOOD_VALUE;
            infected=false;
            diseaseLevel=0;
        }
    }
    
    /**
     * This is what the tiger does most of the time: it hunts for
     * sheep or deers. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * A tiger may also be infected.
     * 
     * @param newTigers A list to return newly born tigers.
     */
    public void act(List<Animal> newTigers)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newTigers);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
            if(infected){
                infection();
            }
        }
    }

    /**
     * Increase the age. This could result in the tiger's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this tiger more hungry. This could result in the tiger's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    } 
    
    /**
     * Increase disease level. This could result in the tiger's death.
     */
    private void increaseDisease(){
        diseaseLevel++;
        if(diseaseLevel>diseaseValue){
            setDead();
        }
    }
    
    /**
     * Look for sheep or deers adjacent to the current location.
     * Only the first live sheep or deer is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Sheep) {
                Sheep sheep = (Sheep) animal;
                if(sheep.isAlive()) { 
                    sheep.setDead();
                    foodLevel = TOTAL_FOOD_VALUE;
                    return where;
                }
            }
            
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel = TOTAL_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * New births will be made into random age and gender.
     * @param newTigers A list to return newly born tigers.
     */
    protected void giveBirth(List<Animal> newTigers)
    {
        // New tigers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tiger young = new Tiger(rand.nextBoolean(), false,false, field, loc);
            newTigers.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A tiger can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Look for mates adjacent to the current location.
     * Breed only if the two tigers are opposite genders.
     * @return Where the mate was found, or null if it wasn't.
     */
    private Location findMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Tiger) {
                Tiger tiger = (Tiger) animal;
                if(!gender()) { 
                    tiger.breed();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Spread disease to the around Tiger. 
     * If the probability is under the infection rate, then the around animals get disease.
     * 
     */
    private void infection(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        double i;
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if((i=rand.nextDouble())<=infectionRate){
                if(animal instanceof Tiger) {
                    Tiger tiger = (Tiger) animal;
                    if(!infected){
                       infected=true;
                    }
                }
            }
        }
    }
}