import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A simple model of a seal.
 * seals age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Seal extends Animal
{
    // Characteristics shared by all seals (class variables).

    // The age at which a seal can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a seal can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a seal breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The seal's age.
    private int age;
    // The time of day.
    private String time;

    /**
     * Create a new seal. A seal may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the seal will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * 
     */
    public Seal(boolean randomAge, Field field, Location location, String time)
    {
        super(field, location);
        this.time=time;
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the seal does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newseals A list to return newly born seals.
     */
    public void act(List<Animal> newSeals)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newSeals);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the seal's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this seal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newseals A list to return newly born seals.
     */
    private void giveBirth(List<Animal> newSeals)
    {
        // New seals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seal young = new Seal(false, field, loc, time);
            newSeals.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && canMeet()&& rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A Seal can distinguish bewtween male and female individuals within
     * a specific distance.
     */
    public Boolean canMeet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            if(animal instanceof Seal) {
                Seal seal = (Seal) animal;
                return meet(seal);

            }
        }
        return false;
        
    }
    
    /**
     * @return true if the two seals are from different genders,
     * and false otherwise.
     */
    public Boolean meet(Seal seal)
    {
        if(!(getGender().equals(seal.getGender())))
        {
            return true;
        }
         return false;
                
    }

    /**
     * A seal can breed if it has reached the breeding age.
     * @return true if the seal can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * @return true if the time is night, false otherwise.
     */
    private boolean NightBreed()
    {
        //sim = new Simulator();
        if(time.equals("Day"))
        {
            return true;
        }
        return false;
    }
}