import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A simple model of a seagrass.
 * seagrasss age, grow and die.
 *
 * @version 2016.02.29 (2)
 */
public class Seagrass extends Plants
{
    // Characteristics shared by all seagrasss (class variables).

    // The age at which a seagrass can start to reproduce.
    private static final int GROWING_AGE = 2;
    // The age to which a seagrass can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a seagrass reproducing.
    private static final double BREEDING_PROBABILITY = 0.35;
  
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The Seagrass's age.
    private int age;
    

    /**
     * Create a new seagrass. A seagrass may be created with age
     * zero (a new seagrass) or with a random age.
     * 
     * @param randomAge If true, the seagrass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seagrass(Field field, Location location)
    {
        super(field, location);
        age = 0;
    }
    
     public void act(List<Plants> newSeagrass)
    {
        
        if(isAlive()) {
            giveBirth(newSeagrass);            

                }
        }
    
    /**
     * Increase the age.
     * This could result in the seagrass's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
     /**
     // * Check whether or not this seagrass is to reproduce at this step.
     // * New seagrass will be made into free adjacent locations.
     // * @param newSeagrasss A list to return newly grown seagrasss.
      */
    private void giveBirth(List<Plants> newSeagrass)
    {
        // New seagrasss are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seagrass young = new Seagrass(field, loc);
            newSeagrass.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of seagrasses,
     * if it can reproduce.
     * @return The number of seagrasses (may be zero).
     */
    
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(25) + 1;
        }
        return births;
    }

    /**
     * A seagrass can reproduce if it has reached the reproducing age.
     * @return true if the seagrass can reproduce, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= GROWING_AGE;
    }
    
}
