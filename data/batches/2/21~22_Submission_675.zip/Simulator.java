import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sharks, whales, stinggrays and penguins as predators 
 * and goldfish,seal and octopuses as preys.
 * 
 *
 * 
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Stingray will be created in any given grid position.
    private static final double STINGRAY_CREATION_PROBABILITY = 0.07;
    // The probability that a Goldfish will be created in any given grid position.
    private static final double GOLDFISH_CREATION_PROBABILITY = 0.03; 
    // The probability that a Penguin will be created in any given grid position.
    private static final double PENGUIN_CREATION_PROBABILITY = 0.07;
    // The probability that a Seal will be created in any given grid position.
    private static final double SEAL_CREATION_PROBABILITY = 0.03;  
    // The probability that a Shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.07;
    // The probability that a Whale will be created in any given grid position
    private static final double WHALE_CREATION_PROBABILITY = 0.07;
    // The probability that a Octopus will be created in any given grid position.
    private static final double OCTOPUS_CREATION_PROBABILITY = 0.03; 
    // The probability that a SeaGrass will be created in any given grid position.
    private static final double SEAGRASS_CREATION_PROBABILITY = 0.03;
    
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plants> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Number of steps entered
    private int stepEntered;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Goldfish.class, Color.lightGray);
        view.setColor(Stingray.class, Color.PINK);
        view.setColor(Shark.class, Color.orange);
        view.setColor(Seal.class, Color.RED);
        view.setColor(Penguin.class, Color.YELLOW);
        view.setColor(Octopus.class, Color.DARK_GRAY);
        view.setColor(Whale.class, Color.CYAN);
        view.setColor(Seagrass.class, Color.GREEN);
    
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) 
        {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
            for(int i=0;i<=numSteps;i++)
            {
                stepEntered= i;
            }
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all the animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        List<Plants> newPlants = new ArrayList<>();        
        // Let all the plants act.
        for(Iterator<Plants> it1 = plants.iterator(); it1.hasNext(); ) {
            Plants plants = it1.next();
            plants.act(newPlants);
            if(! plants.isAlive()) {
                it1.remove();
            }
        }
        // Add the newly born animals  to the main animal list.
        animals.addAll(newAnimals);
        // Add the new grown plants  to the main plant list.
        plants.addAll(newPlants);
        view.showStatus(step, field);
    }
    /**
     * Return the time of day based on the stepEntered.
     */
    public String dayNight()
    {
        int number=stepEntered/100;
        String time="Day";
    
        for ( int i=0; i<= number; i++)
        {
            if(i % 2 != 0){
                time="Day";
            }
            else{
                time="Night";
        }
        }
        return time;
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= STINGRAY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Stingray stingray = new Stingray(true, field, location);
                    animals.add(stingray);
                }
               else if(rand.nextDouble() <= GOLDFISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Goldfish goldfish = new Goldfish(true, field, location);
                    animals.add(goldfish);
                }
                else if(rand.nextDouble() <= PENGUIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Penguin penguin = new Penguin(true, field, location);
                    animals.add(penguin);
                }
                else if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location,dayNight());
                    animals.add(seal);
                }
                else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location,dayNight());
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    animals.add(whale);
                }
                else if(rand.nextDouble() <= SEAGRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seagrass sgrass = new Seagrass(field, location);
                    plants.add(sgrass);
                }
                else if(rand.nextDouble() <= OCTOPUS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Octopus octopus = new Octopus(true, field, location, dayNight());
                    animals.add(octopus);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    /**
     * return stepEntered
     */
    public int getStepEntered()
    {
        return stepEntered;
    }
}
