import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a Penguin.
 * penguins age, move, eat seals, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Penguin extends Animal
{
    // Characteristics shared by all penguines (class variables).
    
    // The age at which a penguin can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a penguin can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a penguin breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single seal. In effect, this is the
    // number of steps a penguin can go before it has to eat again.
    private static final int SEAL_FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The penguin's age.
    private int age;
    // The penguin's food level, which is increased by eating seals.
    private int foodLevel;

    /**
     * Create a penguin. A penguin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the penguin will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Penguin(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SEAL_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SEAL_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the penguin does most of the time: it hunts for
     * seals. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newPenguin A list to return newly born penguins.
     */
    public void act(List<Animal> newPenguin)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPenguin);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the penguin's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this penguin more hungry. This could result in the penguin's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for seals adjacent to the current location.
     * Only the first live seal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Seal) {
                Seal seal = (Seal) animal;
                if(seal.isAlive()) { 
                    seal.setDead();
                    foodLevel = SEAL_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this penguin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newpenguines A list to return newly born penguines.
     */
    private void giveBirth(List<Animal> newPenguin)
    {
        // New penguines are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Penguin young = new Penguin(false, field, loc);
            newPenguin.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed()&& rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A penguin can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * A Penguin can distinguish bewtween male and female individuals within
     * a specific distance.
     */    
     public Boolean canMeet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocationsMeet(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);

            if(animal instanceof Penguin) {
                Penguin penguin = (Penguin) animal;
                return meet(penguin);

            }
        }

        return false;
        
    }
    
    /**
     * @return true if the two penguins are from different genders,
     * and false otherwise.
     */
    public Boolean meet(Penguin penguin){
        if(!(getGender().equals(penguin.getGender()))){
                return true;
            }
         return(false);
                
    }
   
}
