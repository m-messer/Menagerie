import java.util.Random;
/**
 * A simple model of a Lion.
 * Lions age, move, eat preys, and die.
 *
 * @version 20.02.2020
 */
public class Lion extends Predator
{
    /**
     * Create a Lion. A Lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // The age at which a Lion can start to breed.
        reproduceAge = 8;
        // The age to which a Lion can live.
        maxAge = 70;
        // The likelihood of a Lion breeding.
        reproduceProbability = 0.54;
        // The maximum number of births.
        maxDescendants = 4;
        // The food value of a single prey. In effect, this is the
        // number of steps a Lion can go before it has to eat again.
        foodValue = 10;
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(foodValue);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }
}

