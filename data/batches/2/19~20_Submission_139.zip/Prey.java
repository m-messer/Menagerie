import java.util.List;
import java.util.Iterator;

/**
 * A class representing preys.
 *
 * @version 20.02.2020
 */
public abstract class  Prey extends Animal
{
    /**
     * Constructor for objects of class Prey
     */
    public Prey(Field field, Location location)
    {
        super(field,location);
    }
}
