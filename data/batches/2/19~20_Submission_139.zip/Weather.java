import java.util.ArrayList;
import java.util.Random;
/**
 * This class defines the characteristics of a weather.
 * Weather stats: 0 - sunny; 
 *                1 - rainy; 
 *                2 - stormy;
 * @version 20.02.2020
 */
public class Weather
{
    private int currentWeather;
    // A random number generator.
    private  Random random = Randomizer.getRandom();

    /**
     * Initialises the current weather to sunny.
     */
    public Weather()
    {
        //Make the default weather sunny.
        currentWeather = 0;
    }
    
    /**
     * Changes the current weather to a random one.
     */
    public void changeWeather()
    {
        currentWeather = random.nextInt(3);
    }
    
    /**
     * @return The current weather as a string.
     */
    public String getWeatherString()
    {
        if(currentWeather == 0){
            return "Sunny";
        }
        else if(currentWeather == 1){
            return "Rainy";
        }
        else
        {
            return "Storm";
        }
    }
    
    /**
     * @return The weather specific number.
     */
    public int getWeather()
    {
        return currentWeather;
    }
}
