import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of actors.
 * An actor is any living creature present on the field.
 *
 * @version 20.02.2020
 */
public abstract class Actor
{
    // Determines whether the actor is alive or not.
    protected boolean alive;
    // The actor's field.
    protected Field field;
    //The actor's position in the field.
    protected Location location; 
    // The actor's age.
    protected int age;
    // The age at which the actor can reproduce.
    protected int reproduceAge;
    // The age to which an actor can live.
    protected int maxAge;
    // The likelihood of an actor reproduce with others.
    protected double reproduceProbability;
    // A shared random number generator.
    protected  Random rand = Randomizer.getRandom();
    // Maximum number of descendants.
    protected int maxDescendants;
    /**
     * A class representing shared characteristics of actors.
     * An actor is any living creature present on the field.
     */
    public Actor(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Generate a number representing the number of descendants,
     * if it can reproduce or grow.
     * @return The number of births (may be zero).
     */
    protected int descendantsNumber()
    {
        int descendants = 0;
        if(canReproduce() && rand.nextDouble() <= reproduceProbability) {
            descendants = rand.nextInt(maxDescendants) + 1;
        }
        return descendants;
    }

    /**
     * An actor can reproduce if it has reached the minimum reproducing age.
     * @return true if the actor can reproduce, false otherwise.
     */
    protected boolean canReproduce()
    {
        return age >= reproduceAge;
    }

    /**
     * @return true if the actor is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Increase the age.
     * This could result in the actor's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }
   
}
