import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing preys, predators and plants.
 *
 * @version 20.02.2020
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH =120;
    // The probability that a predator will be created in any given grid position.
    private static final double PREDATORS_CREATION_PROBABILITY = 0.03;
    // The probability that a prey will be created in any given grid position.
    private static final double PREYS_CREATION_PROBABILITY = 0.3;    
    // The probability that a plant will be created in any given grid position.
    private static final double PLANTS_CREATION_PROBABILITY = 0.09;  
    // The probability that a plant spawns when it is raining.
    private static final double PLANTS_SPAWN_PROBABILITY = 0.009;
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    //List of infected animals in the field.
    private List<Animal> infectedAnimals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The ClockDisplay (taken from the BlueJ projects) of the simulator.
    private ClockDisplay clock;
    // The current weather for the simulation.
    private Weather currentWeather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        currentWeather = new Weather();
        animals = new ArrayList<>();
        infectedAnimals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        clock = new ClockDisplay();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Cheetah.class, Color.GRAY);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Giraffe.class, Color.YELLOW);
        view.setColor(Antelope.class, Color.PINK);
        view.setColor(Plant.class, Color.GREEN);
        view.showTime(clock.getTime());
        view.showWeather(currentWeather.getWeatherString());
        view.showAnimalDisease(infectedAnimals);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();

            //delay(30);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * predator, prey and plant.
     */
    public void simulateOneStep()
    {
        // increase step number of the simulation
        step++;  
        // Provide space for newborn animals.
        Random random = new Random();
        // Predators, preys and plants act based on weather.
        // 0 - sunny, 1 -  rainy, 2 - storm.
        if(currentWeather.getWeather() == 0){
            // Let all animals act.
            animalAct();
            // Let all plants act.
            plantAct();
        }
        else if(currentWeather.getWeather() == 1){
            // Let all animals act.
            animalAct();
            // If the weather is rainy, randomly spawn plants on the map;
            for(int row = 0; row < field.getDepth(); row++) {
                for(int col = 0; col < field.getWidth(); col++) {
                    Random rand = Randomizer.getRandom();
                    if(rand.nextDouble() <= PLANTS_SPAWN_PROBABILITY){
                        Location location = new Location(row, col);                    
                        Plant plant = new Plant(true, field, location);
                        plants.add(plant);                
                    }
                    // else leave the location empty.
                }
            }
            // Let all plants act.
            plantAct();
        }
        // if it's storm, everything acts 2 times slower.
        else if(currentWeather.getWeather() == 2){
            if(step % 2 == 0){
                // Let all animals act.
                animalAct();
                // Let all plants act.
                plantAct();
            }
        }        
        
        clock.incrementTime(20);
        view.showTime(clock.getTime());
        // Generate a random number between 10 and 20, to determine the duration of each weather.
        int randomNumber = random.nextInt(10)+10;
        // Change the weather each 10 - 20 steps (based on the number generated).
        if(step %  randomNumber == 0){
            currentWeather.changeWeather();
        }
        view.showAnimalDisease(infectedAnimals);
        view.showWeather(currentWeather.getWeatherString());
        view.showStatus(step, field);
    }

    /**
     * Calls the animal's act method and updates the lists of animals.
     */
    private void animalAct()
    {
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>(); 
        int simulatorTime = clock.getTimeInSeconds();
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.disease(infectedAnimals);

            // If is it daytime, let animals act. During nightime, all animals sleep.
            // Daytime: 06:00 - 22:00
            if (simulatorTime>=21600 && simulatorTime <=79200)
            {
                animal.act(newAnimals);
            }
            if(!animal.isAlive()) {
                it.remove();
                infectedAnimals.remove(animal);
            }
        }
        animals.addAll(newAnimals);        
    }
    
    /**
     * Calls the plant's act method and updates the list of plants.
     */
    private void plantAct()
    {
        // Provide space for new plants.
        List<Plant> newPlants = new ArrayList<>();              
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }    
        plants.addAll(newPlants);        
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        clock.resetTime();
        view.showTime(clock.getTime());
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with predators, preys and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Random random = new Random();
                Location location = new Location(row, col);
                if(rand.nextDouble() <= PREDATORS_CREATION_PROBABILITY) {
                    int randomNumber = random.nextInt(2 );
                    // Creates a random number between 0 and 1
                    // If 0 : Spawn a lion / If 1 : Spawn a cheetah

                    if (randomNumber == 0)
                    {                    
                        Predator predator = new  Lion(true, field, location);
                        animals.add(predator);
                    }
                    if (randomNumber == 1)
                    {
                        Predator predator = new  Cheetah(true, field, location);
                        animals.add(predator); 
                    }
                }

                else if(rand.nextDouble() <= PREYS_CREATION_PROBABILITY) {
                    int randomNumber = random.nextInt(3);
                    // Creates a random number between 0 and 2
                    // If 0 : Spawn a Zebra / If 1 : Spawn a Giraffe / If 2 : Spawn a Antelope
                    if (randomNumber == 0)
                    {
                        Prey prey = new Zebra(true, field, location);
                        animals.add(prey);

                    }
                    if (randomNumber == 1)
                    {
                        Prey prey = new Giraffe(true, field, location);
                        animals.add(prey);
                    }
                    if (randomNumber == 2)
                    {
                        Prey prey = new Antelope(true, field, location);
                        animals.add(prey);
                    }

                }
                else if(rand.nextDouble() <= PLANTS_CREATION_PROBABILITY){
                    // Spawn a plant.
                    Plant plant = new Plant(true, field, location);
                    plants.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}