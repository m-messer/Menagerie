import java.util.List;
import java.util.Iterator;

/**
 * A class representing predators.
 *
 * @version 20.02.2020
 */
public abstract class Predator extends Animal
{
    /**
     * Constructor for objects of class Predators
     */
    public Predator(Field field, Location location)
    {
        super(field,location);
    }    
}
