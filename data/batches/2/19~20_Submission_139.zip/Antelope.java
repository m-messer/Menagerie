import java.util.Random;
/**
 * A simple model of a Antelope.
 * Antelopes age, move, eat plants, and die.
 *
 * @version 20.02.2020
 */
public class Antelope extends Prey
{
    /**
     * Create a new Antelope. A Antelope may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Antelope(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        reproduceAge = 8;
        // The age to which a Antelope can live.
        maxAge = 45;
        // The likelihood of a Antelope breeding.
        reproduceProbability = 0.55;
        // The maximum number of births.
        maxDescendants = 4;
        // The food value of a plant. In effect, this is the
        // number of steps a Antelope can go before it has to eat again.
        foodValue = 18;       
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(foodValue);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }
}
