import java.util.Random;
/**
 * A simple model of a Zebra.
 * Zebras age, move, eat plants, and die.
 *
 * @version 20.02.2020
 */
public class Zebra extends Prey
{
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new Zebra. A Zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        reproduceAge = 8;
        // The age to which a Zebra can live.
        maxAge = 50;
        // The likelihood of a Zebra breeding.
        reproduceProbability = 0.55;
        // The maximum number of births.
        maxDescendants = 4;
        // The food value of a plant. In effect, this is the
        // number of steps a Zebra can go before it has to eat again.
        foodValue = 18;     
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(foodValue);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }
}
