import java.util.Random;
/**
 * A simple model of a Giraffe.
 * Giraffes age, move, eat plants, and die.
 *
 * @version 20.02.2020
 */
public class Giraffe extends Prey
{
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new Giraffe. A Giraffe may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Giraffe will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Giraffe(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        reproduceAge = 8;
        // The age to which a Giraffe can live.
        maxAge = 60;
        // The likelihood of a Giraffe breeding.
        reproduceProbability = 0.55;
        // The maximum number of births.
        maxDescendants = 4;
        // The food value of a plant. In effect, this is the
        // number of steps a Giraffe can go before it has to eat again.
        foodValue = 18;        
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(foodValue);
        }
        else {
            age = 0;
            foodLevel = foodValue;
        }
    }
}
