import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 20.02.2020
 */
public  abstract class Animal extends Actor
{
    protected boolean isFemale;   
    // The probability of any animal to be a female.
    protected static final double FEMALE_PROBABILITY = 0.5;
    // The number of steps an animal can do without eating.
    protected int foodValue;
    // The level of hunger. Smaller number means the animal is more hungry.
    protected int foodLevel;
    // The probability of an animal catching a disease.
    private static final double DISEASE_PROBABILITY = 0.02;
    // The probability of an animal dying from a disease.
    private static final double DISEASE_DYING_PROBABILITY = 0.02;
    // The probability of an animal to be cured of a disease.
    private static final double DISEASE_CURE_PROBABILITY=0.05;
    // The disease's duration on an animal.
    private int diseaseAge;
    // Checks whether or not the animal is infected.
    private boolean isInfected;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        isInfected = false;
        //Determines if the animal is a female or not.
        if(rand.nextDouble() <= FEMALE_PROBABILITY) {
            isFemale = true;
        }
    }

    /**
     * Let the animal act. 
     * An animal, each step, increments age and gets more hungry.
     * If the animal is alive and a female, it can give birth to a new animal of its type.
     * Each animal searches for food or tries to move to a new place.
     */
    public void act(List<Animal> newAnimal)
    {
        // Each step animals get older and more hungry.
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(isFemale() == true){
                giveBirth(newAnimal);  
            }            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first (living) food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            // This is the prey case. Preys eat plants.
            if(this instanceof Prey){
                if(food instanceof Plant) {
                    Plant plant = (Plant) food;
                    if(plant.isAlive()) { 
                        plant.setDead();
                        foodLevel = foodValue;
                        return where;
                    }
                }
            }
            // This is the predator case. Predators eat preys.
            else if(this instanceof Predator){
                if(food instanceof Prey) {
                    Prey prey = (Prey) food;
                    if(prey.isAlive()) { 
                        prey.setDead();
                        foodLevel = foodValue;
                        return where;
                    }
                }            
            }           
        }
        return null;
    }

    /**
     * Check whether or not this animal is able to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        // Cannot breed multiples times per stage, for exemple when a female animal has more than one male near her.
        boolean givenBirth = false;
        Field field = getField();
        // Get a list of adjacent free locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if (object instanceof Animal)
            {
                Animal animal = (Animal) object;
                //Check if the animal near the female is a living male of the same type and if it's the female's first birth in that stage.
                if(animal.isAlive() && !animal.isFemale() && givenBirth == false) { 
                    givenBirth = true;
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int descendants = descendantsNumber();
                    // Each animal gives birth to its animal type.
                    for(int i = 0; i < descendants && free.size() > 0; i++) {
                        Location loc = free.remove(0);
                        if (animal instanceof Zebra && this instanceof Zebra)
                        {
                            Zebra young = new Zebra(false, field, loc);
                            newAnimals.add(young);
                        }
                        if (animal instanceof Antelope && this instanceof Antelope)
                        {
                            Antelope young = new Antelope(false, field, loc);
                            newAnimals.add(young);
                        }
                        if (animal instanceof Giraffe && this instanceof Giraffe)
                        {
                            Giraffe young = new Giraffe(false, field, loc);
                            newAnimals.add(young);
                        }
                        if (animal instanceof Lion && this instanceof Lion)
                        {
                            Lion young = new Lion(false, field, loc);
                            newAnimals.add(young);
                        }
                        if (animal instanceof Cheetah && this instanceof Cheetah)
                        {
                            Cheetah young = new Cheetah(false, field, loc);
                            newAnimals.add(young);
                        }
                    }
                }
            }
        }
    }

    /**
     * Increments the hunger of an animal.
     * If the hunger reached it's maximum level, the animal dies.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Chech whether the animal is a male or female.
     * @return true if the animal is a female.
     */
    protected boolean isFemale(){
        return isFemale;
    }   

    /**
     * If an animal is infected, it is added to an infected animals list.
     * If it gets infected, it can either die or be cured.
     */
    protected void disease(List<Animal> infectedAnimals)
    {
        // animal is added to the list.
        if(!isInfected)
        {
            if (rand.nextDouble() <= DISEASE_PROBABILITY)
            {
                isInfected = true;
                infectedAnimals.add(this);
            }
        }
        // check if the animals dies this step.
        if(infectedAnimals.contains(this) && rand.nextDouble()<=DISEASE_DYING_PROBABILITY)
        {
            isInfected = false;
            infectedAnimals.remove(this);
            setDead();      
        }
        // check if the animal is cured this step.
        if(infectedAnimals.contains(this) && rand.nextDouble()<=DISEASE_CURE_PROBABILITY)
        {
            isInfected = false;
            infectedAnimals.remove(this);
        }
    }
    
    /**
     * @return true if the animal is infected.
     */
    protected boolean isInfected()
    {
        return isInfected;
    }
}