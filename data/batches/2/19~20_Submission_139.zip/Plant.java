import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing a basic plant.
 *
 * @version 20.02.2020
 */
public class Plant extends Actor
{
    // Individual characteristics (instance fields).
    // The plant's age.

    /**
     * Constructor for objects of class Plant
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        reproduceAge = 5;
        // The age to which a plant can live.
        maxAge = 20;
        // The likelihood of a plant breeding.
        reproduceProbability = 0.05;
        // The maximum number of births.
        maxDescendants = 3;
        if(randomAge) {
            age = rand.nextInt(maxAge);
        }
        else {
            age = 0;
        }
    }

    /**
     * The behaviour of the plant. Each step it's age increments.
     * If the plant is alive, reproduce (grow).
     */
    public void act(List<Plant> newPlants)
    {
        incrementAge();
        if(isAlive()) {            
            reproduce(newPlants);     
        }
    }

    /**
     * Check whether or not this plant can reproduce (grow) at this step.
     * New descendants will be placed into free adjacent locations.
     * @param newPlants A list to return newly grown plants.
     */
    protected void reproduce(List<Plant> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        int descendants = descendantsNumber();
        for(int i = 0; i < descendants && free.size() > 0; i++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc);
            newPlants.add(young);
        }
    }
}

