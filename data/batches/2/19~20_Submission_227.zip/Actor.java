import java.util.List;
/**
 * The Actor Interface links together the Animal Class, Plant Class and
 * Le_Gourmand Class and stores their common methods.
 * 
 * @date 23.02.2020
 */
public interface Actor
{   
    void act(List<Actor> newActors, String season, boolean isDay); 

    boolean isAlive();

    void setDead();

    Field getField();

    Location getLocation();
}
