 import java.util.List;
 import java.util.Iterator;
 import java.util.Random;

/**
 * A class representing shared characteristics of different species of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal implements Actor 
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //The animal is initialized as a male
    private boolean gender; 
    // A shared random number generator
    private static final Random rand = Randomizer.getRandom();
    //The animal's age.
    private int age;
   
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @age The age that an animal has when it is born.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        setGender();
        age = 0;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @season A string that shows the season the animals are in.
     * @isDay A boolean that helps the animals know how to act
     * during the day or during the night.
     */
    abstract public void act(List<Actor> newAnimals, String season, boolean isDay);
    
    /**
     * The age at which an animal can breed.
     */
    abstract protected int getBreedingAge();
    
    /**
     * The age up until an animal can live.
     */
    abstract protected int getMaxAge();
    
    /**
     * The probability of an animal to breed itself.
     */
    abstract protected double getBreedingProbability();
    
    /**
     * The value of the litter size an animal has.
     */
    abstract protected int getLitterSize();
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the animals's age.
     * @age The age value of an animal
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * The random age an animal can have when it is displayed.
     */
    protected void setAge()
    {
        age = rand.nextInt(getMaxAge());
    }
    
    /**
      * Sets the animal's age to 0.
      */
    protected void setAgeTo0()
    {
        age = 0;
    }
    
    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    public Field getField()
    {
        return field;
    }
    
    /**
     * Return the gender of an animal.
     * @gender Whether the animal is a female or male.
     */
    protected boolean getGender()
    {
        return gender;
    }
   
    /**
     * If there is an adjacent location near animal, the animal.
     * will verify if the animal of the same species is of an opposite
     * gender.
     * @return true if the animal is of an opposite gender.
     * @return false if they have the same gender.
     */
    protected boolean findPartner()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal animal1 = (Animal) animal;
                if(animal1.getGender() != this.getGender() && animal1.getClass() == this.getClass()) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Sets the animal's gender in a random way.
     * @param gender Receives a random boolean.
     */
    protected void setGender()
    {
        gender = rand.nextBoolean();
    }
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    protected boolean canBreed()
    {   
        return age >= getBreedingAge() && findPartner();
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getLitterSize()) + 1;
        }
        return births;
    }
}
