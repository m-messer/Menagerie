import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing different species.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.0155;
    //The probability that a coyotee will be created in any given grid position.
    private static final double COYOTEE_CREATION_PROBABILITY = 0.017;
    //The probability that a coyotee will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.117;
    //The probability that an antelope will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.0417;   
    //The probability that a mouse will be created in any given grid position.
    private static final double MICE_CREATION_PROBABILITY = 0.04998;

    // List of actors in the field.
    private List<Actor> actors;
    //List of infected animals in the field.
    //private List<Actor> infected = new ArrayList<>();
    // List of le_gourmands
    private List<Actor> gourmands = new ArrayList<>();

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A counter for the number of infected animals.
    private int infected_No = 2;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A variable that verifies the time of the day
    private boolean isDay = true;
    //A string used to set the season.
    private String season = "";
    //The current stats of the field.
    private FieldStats stats;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>(); //array to store the actors
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Antelope.class, Color.YELLOW);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Le_Gourmand.class, Color.RED);
        view.setColor(Coyotee.class, Color.BLUE);
        view.setColor(Mouse.class, Color.GRAY);

        // Setup a valid starting point.
        reset();

    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();

            delay(150);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * actor.
     * Also, it is updating the time of the day,seasons,
     * which makes the animals behave differently.
     * It helps the disease to spread from the coyotees to other animals of
     * the same kind. 
     * It helps le_Gourmand to manifest itself and to extend. 
     * 
     */
    public void simulateOneStep()
    {
        step++;
        if (step % 1000 == 0) //re-enacts every 1000 steps
        {
            addLeGourmand(); 
        }

        //alternate day and night 
        if (step % 5 == 0 && (step / 5) % 2 == 0) 

        {
            view.setDay();
            isDay = true;
        }
        else if(step % 5 == 0 &&(step / 5) %2 == 1)
        {
            view.setNight();
            isDay = false;
        }

        if (step % 100 == 0 && (step / 100) % 2 == 0 )
        {   
            season = "Wet season";
        }
        else 
        if (step % 100 == 0 && (step/100) % 2 == 1)
        {
            season = "Dry season";
        }

        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>(); 
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors, season, isDay);

            if(actor instanceof Le_Gourmand)
            {    
                gourmands.add(actor); //store the gourmands in an ArrayList
            }

            if (actor instanceof Coyotee) 
            {
                Coyotee coyotee = (Coyotee) actor;
                if (coyotee.isSick() == true && coyotee.isAlive() == true)
                {  
                    infected_No++; //increment the number of infected 
                    coyotee.getSicker(); //increment the level of sickness
                    coyotee.kill(); //if the coyotee has been infected for a selected number of steps it dies
                }
            }

            if (actor instanceof Mouse) 
            {
                Mouse mouse = (Mouse) actor;
                if (mouse.isSick() == true && mouse.isAlive() == true)
                {  
                    infected_No++; //increment the number of infected 
                    mouse.getSicker(); //increment the level of sickness
                    mouse.kill(); //if the mouse has been infected for a selected number of steps it dies
                }
            }

            if(! actor.isAlive()) {
                it.remove();    //if the actor is dead, remove it from the array
            }

        }

        actors.addAll(newActors); //add the newly born actors

        if (gourmands.size() >= 400) //if the gourmand gets too big, kill it and remove it from the actors list
        { 
            for(Iterator<Actor> it1 = actors.iterator(); it1.hasNext(); )
            { 
                Actor actor1 = it1.next();
                if (actor1 instanceof Le_Gourmand)
                {   actor1.setDead();
                    it1.remove();
                }
            }
        }
        
        //clear the array at each step so it doesn't add into the array an actor that is already there.
        gourmands.clear(); 
        view.showStatus(step, field, season, infected_No);
        //reset the number of infected coyotees at each step so it doesn't count the same one multiple times.
        infected_No = 0; 
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        season = "Wet season"; //the simulatio/ starts in the wet season.
        isDay = true;//the simulation starts in daytime.
        view.setDay();//set the color of the screen to white
        populate();//add the actors
        infected_No = 2;//when the game starts you have only one infected coyotee

        // Show the starting state in the view.
        view.showStatus(step, field, season, infected_No);
    }

    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        /*
        boolean used to check that we don't add more than
        one infected coyotee at the beginning of  the simulation
         */
        boolean c_sick = false; 
        /*
        boolean used to check that we don't add more than
        one infected mouse at the beginning of  the simulation
         */
        boolean m_sick = false;
        addLeGourmand(); //calls the Le_Gourmand creation method

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(field.getObjectAt(row, col) == null){
                    if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY ) {
                        Location location = new Location(row, col);
                        Antelope antelope = new Antelope(true, field, location);
                        actors.add(antelope);
                    }
                    else 
                    if(rand.nextDouble() <=  LION_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Lion lion = new Lion(true, field, location);
                        actors.add(lion);
                    }
                    else
                    if(rand.nextDouble() <= COYOTEE_CREATION_PROBABILITY)
                    {
                        Location location = new Location(row, col);
                        Coyotee coyotee = new Coyotee(true, field, location, false);
                        actors.add(coyotee);
                    }
                    else 
                    if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY)
                    {
                        Location location = new Location(row, col);
                        Plant plant = new Plant(true, field, location);
                        actors.add(plant);
                    }
                    else 
                    if(rand.nextDouble() <= COYOTEE_CREATION_PROBABILITY)
                    {
                        if (c_sick == false)   
                        {   c_sick = true; //set to true when the first infected coyotee is added.
                            Location location1 = new Location(row, col);
                            Coyotee coyoteeI = new Coyotee(true, field, location1, true);
                            actors.add(coyoteeI);
                        }
                    }
                    else
                    if(rand.nextDouble() <= MICE_CREATION_PROBABILITY ) {
                        Location location = new Location(row, col);
                        Mouse mouse = new Mouse(true, field, location, false);
                        actors.add(mouse);
                    }
                    else
                    if(rand.nextDouble() <= MICE_CREATION_PROBABILITY)
                    {
                        if (m_sick == false)   
                        {   m_sick = true; //set to true when the first infected coyotee is added.
                            Location location2 = new Location(row, col);
                            Mouse mouseI = new Mouse(true, field, location2, true);
                            actors.add(mouseI);
                        }
                    }

                    // else leave the location empty.
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Add the Le_Gourmand to the game.
     * This animal is made up from other little actors of the same kind.
     * We will treat it as one big animal that changes its size when it eats coyotees.
     */
    private void addLeGourmand()
    {   
        //boolean used to check if we have already added the gourmands or not
        boolean test = false; 

        for(int row = field.getDepth()/2; row < field.getDepth(); row++) {
            for(int col = (field.getWidth()-1)/2; col < field.getWidth()-1; col++) {
                if (test == false && field.getObjectAt(row, col) == null && field.getObjectAt(row, col+1) == null)
                {   
                    test = true; //set to true when the gourmands are added
                    Location location = new Location(row, col);
                    Le_Gourmand gourmand = new Le_Gourmand(field, location);

                    Location location1 = new Location(row, col+1);
                    Le_Gourmand gourmand1 = new Le_Gourmand(field, location1);

                    // add the gourmands to the list of actors
                    actors.add(gourmand); 
                    actors.add(gourmand1);

                    //add the gourmands to the list of gourmands
                    gourmands.add(gourmand);
                    gourmands.add(gourmand1);
                }
            }
        }
    }
}
