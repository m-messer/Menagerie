import java.util.List;
import java.util.Iterator;
/**
 * Write a description of class Le_Gourmand here.
 *
 * @version (a version number or a date)
 */
public class Le_Gourmand implements Actor
{
    // The gourmand's position in the field.
    private Location location;
    // The animal's field.
    private Field field;
    // Whether the animal is alive or not.
    private boolean alive;
    
    /**
     * Constructor for objects of class Le_Gourmand
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Le_Gourmand(Field field, Location newlocation)
    {
        // initialise instance variables
        alive = true;
        this.field = field;
        setLocation(newlocation);
    }

    /**
     * Return the gourmand's location.
     * @return The gourmand's location.
     */
    public Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the gourmand at the new location in the given field.
     * @param newLocation The gourmand's new location.
     */
    private void setLocation(Location newLocation)
    {
        if(location != null) {
           field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**This is what the gourmand does: it hunts for
     * coyotees. 
     * The gourmand doesn't age, nor it gets hungry. It just gets too greedy for its own health.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     * */
    public void act(List<Actor> newGourmands, String season, boolean isDay)
    { 
        Location newLocation = findFood(); 
        if(newLocation == null){
        }
        else if (newLocation != null) 
        {
            Le_Gourmand gour = new Le_Gourmand(field, newLocation);
            newGourmands.add(gour);
        }
    }
    
    /**
     * Look for coyotees adjacent to the current location, but not positioned diagonally.
     * Only the first live coyotee or mouse is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        List<Location> adjacent = field.adjacentLocations1(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Coyotee) {
                Coyotee coyotee= (Coyotee) animal;
                if(coyotee.isAlive()) { 
                    coyotee.setDead();
                    return where;
                }
            }
            else 
            if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) { 
                    mouse.setDead();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Indicate that the gourmand is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Check whether the gourmand is alive or not.
     * @return true if the gourmand is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Return the gourmand's field.
     * @return The gourmand's field.
     */
    public Field getField()
    {
        return field;
    }
}
