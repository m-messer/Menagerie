import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a whale.
 * Whales age, move, eat prey, and die.
 *
 * @version 02/02/2022 (2)
 */
public class Whale extends Animal
{
    // Characteristics shared by all whales (class variables).
    
    // The age at which a whale can start to breed.
    private static final int BREEDING_AGE = 17520;
    // The age to which a whale can live.
    private static final int MAX_AGE = 26280;
    // The likelihood of a whale breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births a whale can have at a time
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single prey. In effect, this is the
    // number of steps a whale can go before it has to eat again.
    private static final int PREY_FOOD_VALUE = 300;
    
    // The probability that the disease will spread 
    private static final double DISEASE_SPREAD_PROBABILITY = 0.8;
    // The probability that the disease will result in death
    private static final double DISEASE_FATALITY_PROBABILITY = 0.3;
    //The number of days the whale will be infected with the disease
    private int daysWithDisease = 0;
    // Determines if the whale is infected or not
    private boolean isInfected;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The whale's age in hours.
    private int age;
    // The whale's food level, which is increased by eating rabbits.
    private int foodLevel;
    
    /**
     * Create a whale. A whale can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge if true, the whale will have random age and hunger level.
     * @param field the field currently occupied.
     * @param location the location within the field.
     */
    public Whale(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        isInfected = false;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PREY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PREY_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the whale does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWhales A list to return newly born whales.
     */
    public void act(List<Animal> newWhales)
    {
        age++;
        foodLevel--;
        checkDisease();
        
        if (age > MAX_AGE || foodLevel <= 0) {
            setDead();
        }

        if(isAlive()) {
            giveBirth(newWhales);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Checks if the whale has been infected with disease if they are in close proximity to another whale they may spread 
     * the disease  
     * @param field The field currently occupied.
     * @param newWhales A list to return newly born whales.
     */
    
    public void checkDisease() 
    {
        if (isInfected) {
            daysWithDisease++;
    
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Whale) {
                    Whale newWhale = (Whale) animal;
                    if (rand.nextDouble() <= DISEASE_SPREAD_PROBABILITY) {
                        newWhale.setInfected();
                        System.out.println("Disease has been spread");
                    }
                }
            }
        }
        
        if (daysWithDisease > 200) {
            isInfected = false;
            daysWithDisease = 0;
            if (rand.nextDouble() <= DISEASE_FATALITY_PROBABILITY) {
                setDead();
                System.out.println("Died of disease");
            } else {
                System.out.println("Recovered from disease");
            }
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shark) {
                Shark food = (Shark) animal; //one of their prey is Shark
                if(food.isAlive()) { 
                    food.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                } 
            } else if (animal instanceof Squid) { //one of their prey is Squid
                Squid food = (Squid) animal;
                if(food.isAlive()) { 
                    food.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            } else if (animal instanceof Trout) {  //one of their prey is Trout
                Trout food = (Trout) animal;
                if(food.isAlive()) { 
                    food.setDead();
                    foodLevel = PREY_FOOD_VALUE; 
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this whale is to give birth at this step.
     * new births will be made into free adjacent locations.
     * @param newWhales A list to return newly born whales.
     */
    private void giveBirth(List<Animal> newWhales)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation()); 
        List<Location> free = field.getFreeAdjacentLocations(getLocation()); 
        Iterator<Location> it = adjacent.iterator(); 
        int births = breed(); 
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Whale) {
                Whale adjacentWhale = (Whale) animal;
                if (adjacentWhale.getIsMale() != getIsMale()) {  // male and female is in close proximity they can have children
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Whale young = new Whale(false, field, loc); 
                        newWhales.add(young);
                    }
                }
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    
    /**
     * A whale can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    
    /**
     * Set a whale as infected
     */
    public void setInfected() 
    {
        isInfected = true;
        System.out.println("New whale infected");
    }
    
    
    /**
     * returns the whales that are infected 
     * @return all the animals that are infected
     */
    public boolean getInfected() 
    {
        return isInfected;
    }
}
