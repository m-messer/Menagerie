
/**
 * A class representing shared characteristics of plants.
 *
 * @version 02/02/2022 (2)
 */
public class Plant
{
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // The maximum level of steps a plant can live
    private static final int MAX_AGE = 10;
    // Age of the plant in hours
    private int age = 1;
    // Determine if the plant is alive or dead
    private boolean alive;
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location); // clear the location once the animal is dead
            location = null;
            field = null;
        }
    }

    /**
     * Mehtod to check if a plant is alive
     * @return true (alive) if the animal is alive
     */

    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Increments the age of the plant by every step and if it has reached its max age set the plant to dead
     */

    public void age() 
    {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }
}
