import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field based upon 
 * an underwater simulation actors of Plants, Whale, Sharks, Trout, Squid and Cod.
 *
 *
 * @version 02/02/2022 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.

    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a plant will grow in any given grid position.
    private static final double PLANT_GROWTH_PROBABILITY = 0.03;
    // After how many steps should plants grow
    private static final int PLANT_GROWTH_STEP_COUNT = 20;
    // After how many steps the weather needs to be checked
    private static final int WEATHER_STEP_CHECK = 500;
    // The multiplier for the growth rate of plants when the weather is sunny
    private static final double SUNNY_PLANT_MULTIPLIER = 1.25;
    // The probability that the weather will be overcast
    private static final double OVERCAST_PROBABILITY = 0.7;
    // The probability that the weather will be sunny
    private static final double SUNNY_PROBABILITY = 0.3;
    //The probability that a whale will spawn with the disease
    private static final double DISEASE_SPAWN_PROBABILITY = 0.4;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.004;
    // The probability that a cod will be created in any given grid position.
    private static final double COD_CREATION_PROBABILITY = 0.02;
    // The probability that a squid will be created in any given grid position.
    private static final double SQUID_CREATION_PROBABILITY = 0.005;
    // The probability that a trout will be created in any given grid position.
    private static final double TROUT_CREATION_PROBABILITY = 0.04;
    // The probability that a whale will be created in any given grid position.
    private static final double WHALE_CREATION_PROBABILITY = 0.0015;

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A timer object to keep track of the time in the simulation   
    private Timer timer;
    // A weather tracking object to keep track of the current weather in the simulation
    private WeatherTracker weather;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) { 
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        timer = new Timer(0);
        weather = new WeatherTracker(0);

        // Create a view of the state of each location in the field along with the time and weather trackers.
        // each actor is represented on the simulator with a unique colour 
        view = new SimulatorView(depth, width, timer, weather);
        view.setColor(Cod.class, Color.ORANGE); 
        view.setColor(Shark.class, Color.BLUE);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Trout.class, Color.YELLOW);
        view.setColor(Squid.class, Color.PINK);
        view.setColor(Whale.class, Color.RED);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep(false);
        }
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * This method doesn't show all the steps, it runs the amount specifies and then displays the end result.
     * @param numSteps The number of steps to run for.
     */

    private void simulateInvisible(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep(true);
        }
        view.showStatus(step, field);
    }

    /**
     * Simulates days, one day is counted every 24 hours.
     * @param numDays The number of days to run for.
     */

    public void simulateDays(int numDays)
    {
        for(int step = 1; step <= numDays && view.isViable(field); step++) {
            simulateInvisible(24); // every 24 hours
        }
        view.showStatus(step, field); // shows days
    }

    /**
     * Simulates years, one year is counted every 8760 hours.
     * @param numYears The number of years to run for.
     */

    public void simulateYears(int numYears) 
    {
        for(int step = 1; step <= numYears && view.isViable(field); step++) {
            simulateInvisible(8760);
        }
        view.showStatus(step, field); //shows hours
    }

    /**
     * Simulates what happens every one step.
     * Animals act during the day, plants are created and the weather can be changed
     * @param isInvisible Indicates whether the step should be displayed on the simulator view.
     */

    private void simulateOneStep(boolean isInvisible) 
    {
        step++;
        timer.incrementTime();
        simulatePlants();
        boolean isNight = timer.checkIfNight();
        Random rand = Randomizer.getRandom();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();

        if (!isNight) {        
            // Let all animals act.
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                animal.act(newAnimals);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
        } 
        // let all the plants age      
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.age(); 
            if(! plant.isAlive()) {
                it.remove();
            }
        }

        if (step % WEATHER_STEP_CHECK == 0) {
            if (rand.nextDouble() <= SUNNY_PROBABILITY) {  //determining if it will be a sunny day or ovecast
                weather.setCurrentWeather(1);
            } else if(rand.nextDouble() <= OVERCAST_PROBABILITY) {
                weather.setCurrentWeather(0);
            }
        }

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        if (!isInvisible) {
            view.showStatus(step, field);
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with animals and diseased whales.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();

        ArrayList<Whale> spawnedWhales= new ArrayList<>();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    animals.add(whale);
                    spawnedWhales.add(whale);
                } else if(rand.nextDouble() <= SQUID_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squid squid = new Squid(true, field, location);
                    animals.add(squid);
                } else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                } else if(rand.nextDouble() <= PLANT_GROWTH_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant algae = new Plant(field, location);
                    plants.add(algae);
                } else if(rand.nextDouble() <= COD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cod cod = new Cod(true, field, location);
                    animals.add(cod);
                } else if(rand.nextDouble() <= TROUT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Trout trout = new Trout(true, field, location);
                    animals.add(trout);
                }

                // else leave the location empty.
            }
        }

        for (Whale whale : spawnedWhales) {
            if(rand.nextDouble() <= DISEASE_SPAWN_PROBABILITY) {
                whale.setInfected();
            }
        }
    }

    /**
     * Simulate plants onto the simulator
     */

    private void simulatePlants() 
    {
        Random rand = Randomizer.getRandom();

        if (step % PLANT_GROWTH_STEP_COUNT == 0 && weather.getCurrentWeather() == 0) { 
            for(int row = 0; row < field.getDepth(); row++) {
                for(int col = 0; col < field.getWidth(); col++) {
                    if(rand.nextDouble() <= PLANT_GROWTH_PROBABILITY) {
                        Location location = new Location(row, col);
                        Plant plant = new Plant(field, location);
                        plants.add(plant);
                    }
                }
            }
        } else if (step % PLANT_GROWTH_STEP_COUNT == 0 && weather.getCurrentWeather() == 1) {
            for(int row = 0; row < field.getDepth(); row++) {
                for(int col = 0; col < field.getWidth(); col++) {
                    if(rand.nextDouble() <= PLANT_GROWTH_PROBABILITY * SUNNY_PLANT_MULTIPLIER) {
                        // growth of plant is increased if it is a sunny day
                        Location location = new Location(row, col);
                        Plant plant = new Plant(field, location);
                        plants.add(plant);
                    }
                }
            }
        }
    }
}
