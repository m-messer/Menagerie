import java.awt.Color;

/**
 * A class to track the current weather in the simulation. The weather is stored in integer form, with the default (0) being
 * overcast and (1) being sunny.
 *
 * @version (02/02/2022)
 */
public class WeatherTracker
{
    private int currentWeather;

    /**
     * Constructor for objects of class WeatherTracker
     */
    public WeatherTracker(int initialWeather)
    {
        currentWeather = initialWeather;
    }

    /**
     * Sets the weather chosen as the current weather
     * @param weather chosen to be changed
     */   
    public void setCurrentWeather(int weather)
    {
        currentWeather = weather;
    }

    /**
     * retrieve the current weather 
     * @return currentWeather displayed
     */
    public int getCurrentWeather() {
        return currentWeather;
    }

    /**
     * Generates the sentence used to display the weather on the simulator
     */

    public String currentWeatherSentence() {
        if (currentWeather == 0) {
            return "-- It is currently: Overcast";
        } else {
            return "-- It is currently: Sunny";
        }
    }
}
