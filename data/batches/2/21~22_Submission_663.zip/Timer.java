import java.awt.Color;

/**
 * Keeps track of the current time in the simulator and calculates the current
 * day and year
 *
 * @version (02/02/2022)
 */
public class Timer
{
    //Keeps track of the current time in hours
    private int currentTime;
    //Keeps track of the current day
    private int currentDay = 1;
    //Keeps track of the current year
    private int currentYear = 1;

    /**
     * Constructor for objects of class Timer
     * @param initialTime sets the current time as the starting time 
     */
    public Timer(int initialTime)
    {
        currentTime = initialTime;
    }

    /**
     * Displays the date and time on the simulator  
     */

    public String currentTimeSentence() 
    {
        return " -- It is: " + currentTime % 24 + ":00 -- Year " + currentYear + ", Day " + currentDay % 365;
    }

    /**
     * Every 8760 hours increment the years and every 24 hours increment the days
     */

    private void incrementDaysAndYears() 
    {
        if (currentTime % 8760 == 0) {
            currentYear++;
        }

        if (currentTime % 24 == 0) {
            currentDay++;
        }
    }

    /**
     *  This method checks if it is night. if the hours of the day is inbetween 6pm and 6am it is night.
     *  @return true if it is night
     *  @return false if it is morning/afternoon
     */

    public Boolean checkIfNight()
    {
        if (currentTime % 24 < 6 || currentTime % 24 > 18) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Sets the current time to time 
     * @param time of the day
     */
    public void setCurrentTime(int time)
    {
        currentTime = time;
    }

    /**
     * Increment the time and check if the the days and years need to be incremented 
     */

    public void incrementTime()
    {
        currentTime++;
        incrementDaysAndYears();
    }

}
