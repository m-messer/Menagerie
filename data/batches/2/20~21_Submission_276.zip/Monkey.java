import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a monkey.
 * Monkeys age, move, breed and die.
 *
 * @version (04/03/21)
 */
public class Monkey extends NonLethal
{
    /**
     * Create a new monkey. A monkey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the monkey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Monkey(boolean randomAge, Field field, Location location)
    {
        super(field, location, 10, 150, 0.6, 18, 20);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }        
    }

    /**
     * This is what the monkey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMonkeys A list to return newly born monkeys.
     */
    public void actDay(List<Actor> newMonkeys)
    {
        Act(newMonkeys);
    }
    
    /**
     * Monkeys don't behave differently at night.
     * @param newBirds A list to return newly born birds.
     */
    public void actNight(List<Actor> newMonkeys)
    {
        
        Act(newMonkeys);
    }
    
    /**
     * Overrides the act method in the NonLethal superclass.
     * @param newMonkeys A list to return newly born monkeys.
     */
    public void Act(List<Actor> newMonkeys) {
        incrementAge();
        if(isAlive()) {
            giveBirth(newMonkeys); 
            // Doesn't eat, just tries to find a free adjacent location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
          
    /**
     * Check whether or not this monkey is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMonkeys A list to return newly born monkeys.
     */
    private void giveBirth(List<Actor> newMonkeys)
    {
        // New monkeys are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Monkey young = new Monkey(false, field, loc);
            newMonkeys.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A monkey can breed if it has reached the breeding age and there is an adjacent monkey of the opposite sex.
     */
    protected boolean canBreed()
    {
        if(age < BREEDING_AGE){
            return false;
        }
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            Actor actor = (Actor) object;
            // If the adjacent object is a monkey and of opposite gender then they can breed.
            if(object instanceof Monkey && actor.getGender() != gender){
                return true;
            }
        }
        return false;
    }
}
