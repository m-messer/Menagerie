import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * This is a JavaFX GUI class that allows the simulator to be run from a GUI without having to 
 * create simulator objects manually from BlueJ.
 *
 * @version (04/03/21)
 */
public class GUIsimulator extends Application
{
    // Uses the gridpane
    private GridPane pane;
    private Scene scene;
    
    // We keep track of the count, and label displaying the count:
    private boolean started;
    private Label startLabel = new Label("Start the Simulator at default size");
    private Label resetLabel = new Label("Reset the simulator");
    private Label complexLabel = new Label("Start the simulator with custom size (depth|width)");
    private Label simulateNumberLabel = new Label("Simulate for a set number of steps");
    private Label setDayLengthLabel = new Label("Set the length of each day");
    private Label delayLabel = new Label("Set the delay for each step");
    private Label infoLabel = new Label("Welcome to Predator/Prey simulator! \n Remember to click either of the Start simulator buttons \n before running any other function");
    
    // These are all the fields where the user can input data.
    private TextField stepsInput;
    private TextField depthInput;
    private TextField widthInput;
    private TextField dayLengthInput;
    private TextField delayInput;
    
    // These are all the labelled buttons that the user can interact with
    private Button runLongSimButton = new Button("Run Long");
    private Label runLongSimLabel = new Label("Run Long simulation");
    private Button runShortSimButton = new Button("Run short");
    private Label runShortSimLabel = new Label("Run Long simulation");
    private Button runForOneStepButton = new Button("Step");
    private Label runOneStepLabel = new Label("Run simulation for one step");
    
    // This is the simulator object that is controlled by this GUI
    private Simulator simulator;

    /**
     * The start method starts the GUI and gets it ready for user interaction.
     * @param  stage The primary stage for this application.
     */
    @Override
    public void start(Stage stage)
    {
        started = false;
        // Create a Button or any control item
        Button startButton = new Button("Start");
        Button startComplexButton = new Button("StartComplex");
        Button resetButton = new Button("Reset");
        Button simulateNoStepsButton = new Button("Simulate Number");
        Button setDayLengthButton = new Button("Set Day Length");
        Button setDelayButton = new Button("Set Delay");
        
        stepsInput = new TextField();
        depthInput = new TextField();
        widthInput = new TextField();
        dayLengthInput = new TextField();
        delayInput = new TextField();
        
        // Create a new grid pane
        pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.setMinSize(300, 300);
        pane.setVgap(10);
        pane.setHgap(10);
        
        //set an action on the button using method reference
        startButton.setOnAction(this::startSimulator);
        resetButton.setOnAction(this::resetButtonClick);
        runLongSimButton.setOnAction(this::runLongSimulationClick);
        runShortSimButton.setOnAction(this::runShortSimulationClick);
        startComplexButton.setOnAction(this::startComplex);
        simulateNoStepsButton.setOnAction(this::runSimulationForNoSteps);
        setDayLengthButton.setOnAction(this::setDayLength);
        setDelayButton.setOnAction(this::setDelay);
        runForOneStepButton.setOnAction(this::runForOneStep);

        // Add the button and label into the pane
        pane.add(startLabel, 1, 1);
        pane.add(startButton, 0, 1);
        pane.add(complexLabel,3,2);
        pane.add(startComplexButton, 0,2);
        pane.add(depthInput, 1,2);
        pane.add(widthInput,2,2);
        pane.add(simulateNumberLabel, 2,3);
        pane.add(simulateNoStepsButton, 0,3);
        pane.add(stepsInput,1,3);
        pane.add(resetLabel,1,4);
        pane.add(resetButton,0, 4);
        pane.add(runLongSimLabel, 1,5);
        pane.add(runLongSimButton, 0 ,5);
        pane.add(runOneStepLabel, 1,6);
        pane.add(runForOneStepButton, 0 ,6);
        pane.add(runShortSimLabel,1,7);
        pane.add(runShortSimButton,0,7);
        pane.add(setDayLengthLabel,2,8);
        pane.add(dayLengthInput,1,8);
        pane.add(setDayLengthButton,0, 8);
        pane.add(delayLabel,2,9);
        pane.add(setDelayButton, 0,9);
        pane.add(delayInput, 1,9);
        pane.add(infoLabel,0,0);
        
        stage.setHeight(450);
        stage.setWidth(1000);
        
        // JavaFX must have a Scene (window content) inside a Stage (window)
        scene = new Scene(pane, 900,300);
        stage.setTitle("Predator/Prey Simulator");
        stage.setScene(scene);

        // Show the Stage (window)
        stage.show();
    }

    /**
     * This will be executed when the start button is clicked
     * It starts up the simulator
     * @param event This is the event
     */
    private void startSimulator(ActionEvent event)
    {
        // Counts number of button clicks and shows the result on a label
        simulator = new Simulator();
        startLabel.setText("Simulator Started");
    }
    
    /**
     * This method allows the simulator to be create with custom values for depth and width.
     * @param event This is the event
     */
    private void startComplex(ActionEvent event) 
    {
        String depthString = depthInput.getText();
        int depth = Integer.valueOf(depthString);
        
        String widthString = widthInput.getText();
        int width = Integer.valueOf(widthString);
        
        simulator = new Simulator(depth, width);
    }
    
    /**
     * This resets the simulator
     * @param event This is the event
     */
    private void resetButtonClick(ActionEvent event) 
    {
        simulator.reset();
        runLongSimLabel.setText("Run Long Simulation");
    }
    
    /**
     * This runs the simulator the number of steps that the user inputs.
     * @param event This is the event
     */
    private void runSimulationForNoSteps(ActionEvent event) 
    {
        int steps = Integer.valueOf(stepsInput.getText());
        simulator.simulate(steps);
    }
    
    /**
     * This runs the simulator for 'long' number of steps.
     * @param event This is the event
     */
    private void runLongSimulationClick(ActionEvent event) 
    {
        simulator.runLongSimulation();
        while (simulator.getFinished() == false) {
            
            runLongSimLabel.setText("Simulator is running");
            
        }
        runLongSimLabel.setText("Simulation Finished");
    }
    
    /**
     * This runs the simulator for one step.
     * @param event This is the event
     */
    private void runForOneStep(ActionEvent event) 
    {
        simulator.simulateOneStep();
    }
    
    /**
     * This runs the simulator for a 'short' number of steps.
     * @param event This is the event
     */
    private void runShortSimulationClick(ActionEvent event) 
    {
        simulator.runShortSimulation();
        while (simulator.getFinished() == false) {
            
            runLongSimLabel.setText("Simulator is running");
            
        }
        runLongSimLabel.setText("Simulation Finished");
    }
    
    /**
     * This sets the day length to whatever the user inputs.
     * @param event This is the event
     */
    private void setDayLength(ActionEvent event) 
    {
        simulator.setDayLength(Integer.valueOf(dayLengthInput.getText()));
    }
    
    /**
     * This sets the delay to whatever the user inputs.
     * @param event This is the event
     */
    private void setDelay(ActionEvent event) 
    {
        int delay = Integer.valueOf(delayInput.getText());
        simulator.setDelay(delay);
    }
}
