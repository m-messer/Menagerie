import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;

/**
 * A complex predator-prey simulator, based on a rectangular field
 * containing predators (from the movie), tigers, birds, monkeys, anteaters and plants.
 *
 * @version (04/03/21)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 300; 
    
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 300; 
    
    // Provides a way to increase or decrease the initial number of animals  while maintaining the same proportion of animals between different species.
    private static double probabilityFactor = 8;
    
    // The probability that the animal will occupy a cell when the field is initially populated, all are constants.
    private static final double PREDATOR_CREATION_PROBABILITY = 0.26 / probabilityFactor; 
    private static final double TIGER_CREATION_PROBABILITY = 0.28 / probabilityFactor; 
    private static final double MONKEY_CREATION_PROBABILITY = 0.70 / probabilityFactor; 
    private static final double BIRD_CREATION_PROBABILITY = 0.40 / probabilityFactor; 
    private static final double ANTEATER_CREATION_PROBABILITY = 0.55 / probabilityFactor;
    
    // The initial probability that a plant will grow into a cell after each step. This is a variable not a constant.
    private double plantGrowthRate = 0.3 / probabilityFactor;

    // List of actors in the field.
    private List<Actor> actors;
    
    // The current state of the field.
    private Field field;
    
    // The current step of the simulation.
    private int step;
    
    //The length of a day in steps
    private int dayLength;
    
    // A graphical view of the simulation.
    private SimulatorView view;
    
    // The delay between each step shown in the GUI.
    private int delay;
    
    //whether or not the simulator is finished
    private boolean finished;
    
    // A map between the weather as a string, and the integer from which the variable plantGrowthRate is derived.
    private HashMap<Integer, String> weather = new HashMap();
    
    // A list of the integer keys from the weather HashMap above.
    private List<Integer> weatherKeys;
    
    // The current weather as a string which is initialised to an empty string.
    private String currentWeather = "" ;
    
    Random generator = new Random();
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    
    /**
     * Fills in the weather HashMap with strings of weather types and their respective integers from which the variable plantGrowthRate is derived (by dividing by 10).
     * Note that the integers put into weather must be between 0 and 10 inclusive.
     */
    private void fillWeatherInfo() {
        
        weather.put(8, "Sunny");
        weather.put(6, "Partly Cloudy");
        weather.put(4, "Cloudy");
        weather.put(2, "Storm");
        weatherKeys = new ArrayList<Integer>(weather.keySet());
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // Initially there is no delay but we can change this with the setDelay method.
        delay = 0;
        //Initially the day length is set to 48 steps 
        dayLength = 48;
        
        
        fillWeatherInfo();
        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        // Set the colour of each animal/plant
        view.setColor(Tiger.class, Color.RED.brighter());
        view.setColor(Predator.class, Color.BLUE);
        view.setColor(Monkey.class, Color.YELLOW);
        view.setColor(Bird.class, Color.CYAN);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Anteater.class, Color.MAGENTA);
        
        // Setup a valid starting point.
        reset();
        
    }
    
    /**
     * @return Finished variable
     */
    public boolean getFinished() {
        return finished;
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for a reasonably short period,
     * (400 steps).
     */
    public void runShortSimulation() {
        simulate(400);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay();   // uncomment this to run more slowly
        }
        finished = true;
    }
    
    /**
     * Set the delay variable to an integer of your choice
     * @param newDelay The number of milliseconds you want the simulator to pause between each step.
     */
    public void setDelay(int newDelay) {
        delay = newDelay;
    }
    
    /**
     * Set the dayLength variable to an integer of your choice
     * @param newDayLength The number of milliseconds you want the simulator to pause between each step.
     */
    public void setDayLength(int newDayLength) {
        dayLength = newDayLength;
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        Random rand = Randomizer.getRandom();
        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();

        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            
            // A full 24 hour day is equivalent to 48 steps in this simulation. For the first 24 steps in a day the actDay method is called 
            // on all actors, and for the next 25 the actNight method is called enabling actors
            // to exhibit different behaviours during day and night.
            if (step % dayLength <= 23) {
                actor.actDay(newActors);
            } 
            else {
                actor.actNight(newActors);
            }
            
            // At the beginning of each day the weather is randomly picked, affecting the behaviour of the plants.
            if (step % dayLength == 0) {
                // This assigns a random key from the weather HashMap to the randomKey variable.
                double randomKey = weatherKeys.get(generator.nextInt(weatherKeys.size()));

                // The plantGrowthRate is derived from the randomKey here.
                plantGrowthRate =  randomKey / 100;
                
                // Sets the currentWeather string to the weather associated with the randomKey.
                currentWeather = weather.get((int) randomKey);
            }
            
            if(!actor.isAlive()) {
                it.remove();
            }
        }
               
        // For each free location there is a plantGrowthRate chance that a new plant will spawn there. Plants don't need to meet to 'give birth'.
        for(Location location : field.freeLocations()){
                if(rand.nextDouble() <= plantGrowthRate){
                    Plant babyPlant = new Plant(field, location);
                    newActors.add(babyPlant);
                }
        }
        
        actors.addAll(newActors);
        
        view.showStatus(step, dayLength, field, currentWeather);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        finished = false;
        step = 0;
        actors.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, dayLength, field, currentWeather);
    }
    
    /**
     * Randomly populate the field with all species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= MONKEY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Monkey monkey = new Monkey(true, field, location);
                    actors.add(monkey);
                }
                else if(rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bird bird = new Bird(true, field, location);
                    actors.add(bird);
                }
                
                else if(rand.nextDouble() <= PREDATOR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Predator predator = new Predator(true, field, location);
                    actors.add(predator);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    actors.add(tiger);
                } else if (rand.nextDouble() <= plantGrowthRate) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    actors.add(plant);
                    
                } else if (rand.nextDouble() <= ANTEATER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Anteater anteater = new Anteater(true, field, location);
                    actors.add(anteater);
                    
                }
                
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay() // used to be (int millisec)
    {
        try {
            Thread.sleep(delay);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
