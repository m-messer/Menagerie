import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * A type of actor that can kill other animal actors.
 *
 * @version (04/03/21)
 */
public abstract class Lethal extends Actor
{
    // The age at which a lethal can start to breed.
    protected static int BREEDING_AGE;
    // The likelihood of a lethal breeding.
    protected static double BREEDING_PROBABILITY;
    // The maximum number of births.
    protected static int MAX_LITTER_SIZE;
    // The food value of a single nonlethal. In effect, this is the
    // number of steps a lethal can go before it has to eat again.
    protected static int NONLETHAL_FOOD_VALUE;
    // The lethal's food level, which is increased by eating nonlethals.
    protected int foodLevel;
    // Whether or not the lethal is infected with disease
    protected boolean diseased;

    protected static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Lethal
     */
    public Lethal(Field field, Location location, int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, int NONLETHAL_FOOD_VALUE)
    {
        super(field, location);
        this.BREEDING_AGE = BREEDING_AGE;
        this.MAX_AGE = MAX_AGE;
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
        this.NONLETHAL_FOOD_VALUE = NONLETHAL_FOOD_VALUE;
        Random rand = Randomizer.getRandom();
        // There is a 10% chance that a new Lethal will be born with disease.
        if(rand.nextDouble() <= 0.1){
            diseased = true;
        }
        else {
            diseased = false;
        }
    }

    /**
     * Returns diseased variable.
     * @return True if animal is diseased otherwise return false.
     */
    public boolean getIsDiseased() {
        return diseased;
    }

    /** 
     * This is what the lethal does most of the time: it hunts for
     * nonlethals. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLethals A list to return newly born lethals.
     */
    public void actDay(List<Actor> newLethals)
    {
        incrementAge();        
        Act(newLethals);
    }

    /** 
     * This method will be overridden by the Act methods in the subclasses.
     */
    abstract protected void Act(List<Actor> newLethals); 

    /**
     * Lethals sleep at night, they don't get more hungry they just age.
     */
    public void actNight(List<Actor> newLethals)
    {
        incrementAge();
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /** 
     * This method will be overridden by the canBreed methods in the subclasses.
     */
    abstract protected boolean canBreed();

    /**
     * Look for nonlethals adjacent to the current location.
     * Only the first live nonlethal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof NonLethal) {
                Actor nonlethal = (Actor) actor;
                if(nonlethal.isAlive()) { 
                    nonlethal.setDead();
                    foodLevel = NONLETHAL_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Increase the age. This could result in the fox's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Lethal more hungry. This could result in the Lethal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check if the lethal will get infected based on the surrounding lethals and their states.
     * @return Whether or not the lethal will be infected.
     */
    protected boolean getInfected()
    {
        // If the lethal already has disease it can't be infected again.
        if(diseased){
            return false;
        }

        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // Iterate over all the lethal's adjacent locations.
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            // Since only lethals can have disease, if the adjacent object isn't a lethal then continue.
            if(!(object instanceof Lethal)){
                continue;
            }
            Lethal lethal = (Lethal) object;
            // There is a 20% chance the lethal gets infected for each adjacent lethal with disease.
            if(lethal.getIsDiseased() == true && rand.nextDouble() <= 0.2){
                return true;
            }
        }
        return false;
    }
}
