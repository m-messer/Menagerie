import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * A NonLethal is an animal that can be killed and eaten by a Lethal, and it can't kill any animals it can only eat plants.
 *
 * @version (04/03/21)
 */
public abstract class NonLethal extends Actor
{
    // The age at which a nonlethal can start to breed.
    protected static int BREEDING_AGE;

    // The likelihood of a nonlethal breeding.
    protected static double BREEDING_PROBABILITY;
    // The maximum number of births.
    protected static int MAX_LITTER_SIZE;

    protected static int PLANT_FOOD_VALUE;

    // The lethal's food level, which is increased by eating plants.
    protected int foodLevel;

    protected static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class NonLethal
     */
    public NonLethal(Field field, Location location, int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, int PLANT_FOOD_VALUE)
    {
        super(field, location);
        this.BREEDING_AGE = BREEDING_AGE;
        this.MAX_AGE = MAX_AGE;
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
        this.PLANT_FOOD_VALUE = PLANT_FOOD_VALUE;
    }

    /**
     * This is what the nonlethal does most of the time - it flies
     * around eating plants. Sometimes it will breed or die of old age.
     * @param newNonLethals A list to return newly born nonlethals.
     */
    public void actDay(List<Actor> newNonLethals)
    {
        incrementAge();
        Act(newNonLethals);
    }

    /**
     * NonLethals don't behave differently at night.
     * @param newNonLethals A list to return newly born nonlethals.
     */
    public void actNight(List<Actor> newNonLethals)
    {
        incrementAge();      
        Act(newNonLethals);
    }

    /** 
     * This method will be overridden by the Act methods in the subclasses.
     */
    abstract public void Act(List<Actor> newNonLethals);

    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Plant) {
                Actor plant = (Actor) actor;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = 10 * PLANT_FOOD_VALUE;                   
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Increase the age.
     * This could result in the nonlethal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
}
