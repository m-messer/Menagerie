import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a bird.
 * Birds age, move, breed, eat and die.
 *
 * @version (04/03/21)
 */
public class Bird extends NonLethal
{
    /**
     * Create a new bird. A bird may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the bird will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bird(boolean randomAge, Field field, Location location) 
    {
        super(field, location, 8, 120, 0.7, 15, 15);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
        foodLevel = 10 * PLANT_FOOD_VALUE;
    }
    
    /**
     * Overrides the act method in the NonLethal superclass.
     * @param newBirds A list to return newly born birds.
     */
    public void Act(List<Actor> newBirds) {
        incrementHunger();
        if(isAlive()) {
            giveBirth(newBirds);
            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if (newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead(); 
            }
        }
    }
    
    /**
     * Make this bird more hungry. This could result in the bird's death.
     */
    public void incrementHunger() 
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
            System.out.println("Bird died of Hunger");
        }
    }
       
    /**
     * Check whether or not this bird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBirds A list to return newly born birds.
     */
    private void giveBirth(List<Actor> newBirds)
    {
        // New birds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bird young = new Bird(false, field, loc);
            newBirds.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A bird can breed if it has reached the breeding age and there is an adjacent bird of the opposite sex.
     */
    protected boolean canBreed()
    {
        if(age < BREEDING_AGE){
            return false;
        }
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            Actor actor = (Actor) object;
            // If the adjacent object is a bird and of opposite gender then they can breed.
            if(object instanceof Bird && actor.getGender() != gender){
                return true;
            }
        }
        return false;
    }
}
