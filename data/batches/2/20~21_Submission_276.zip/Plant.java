import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a plant.
 * Plants age and die.
 *
 * @version (04/03/21)
 */
public class Plant extends Actor
{
    private Field field;
    private Location location;
    private int MAX_AGE;
    private int age;

    /**
     * Create a new monkey. A monkey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If, the monkey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field inputField, Location inputLocation)
    {
        super(inputField, inputLocation);
        MAX_AGE = 2;
        age = 0;
    }
    
    /**
     * Plant only ages
     */
    public void actDay(List<Actor> newPlants)
    {
        incrementAge();
    }   
    
    /**
     * Plant only ages
     */
    public void actNight(List<Actor> newPlants) {
        incrementAge();
    }
    
    /**
     * Increase the age.
     * This could result in the plant's death.
     */
    private void incrementAge(){
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
}
