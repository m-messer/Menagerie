import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a predator.
 * Predators age, move, eat nonlethals and die.
 *
 * @version (04/03/21)
 */
public class Predator extends Lethal
{
    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(field, location, 10, 55, 0.20, 5, 12);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(NONLETHAL_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = NONLETHAL_FOOD_VALUE;
        }
        
        // Half the lifespan when the predator is diseased.
        if(diseased) {
            MAX_AGE = MAX_AGE / 2;
        }
    }
    
    protected void Act(List<Actor> newPredators) {
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPredators);
            
            // If the predator has been infected in its travels, set the diseased parameter to reflec this and half the lifespan.
            if(getInfected()){
                MAX_AGE = MAX_AGE / 2;
                diseased = true;
                
            }
            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Check whether or not this predator is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPredators A list to return newly born predators.
     */
    private void giveBirth(List<Actor> newPredators)
    {
        // New predators are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Predator young = new Predator(false, field, loc);
            newPredators.add(young);
        }
    }

    /**
     * A predator can breed if it has reached the breeding age and there is an adjacent predator of the opposite sex.
     */
    protected boolean canBreed()
    {
        if(age < BREEDING_AGE){
            return false;
        }
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            Actor actor = (Actor) object;
            // If the adjacent object is a predator and of opposite gender then they can breed.
            if(object instanceof Predator && actor.getGender() != gender){
                return true;
            }
        }
        return false;
    }
}


