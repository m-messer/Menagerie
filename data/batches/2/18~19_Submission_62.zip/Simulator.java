import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    //The probability each species of actor will be created. 
    private static final double TIGER_CREATION_PROBABILITY = 0.02;
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.03;
    private static final double SNAKE_CREATION_PROBABILITY = 0.037;
    private static final double TURTLE_CREATION_PROBABILITY = 0.04;
    private static final double FOX_CREATION_PROBABILITY = 0.044;
    private static final double RABBIT_CREATION_PROBABILITY = 0.052;
    private static final double TREE_CREATION_PROBABILITY = 0.06;
    private static final double GRASS_CREATION_PROBABILITY = 0.065;
    
    Random rand = Randomizer.getRandom();
    // List of actors in the field.
    private List<Actor> actors;
    //List of weathers in the simulation.
    private List<Weather> Weathers=new ArrayList<>();
    private Weather currentWeather=Weather.NORMAL;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Snake.class,Color.PINK);
        view.setColor(Turtle.class,Color.CYAN);
        view.setColor(Tiger.class,Color.RED);
        view.setColor(Giraffe.class,Color.GRAY);
        view.setColor(Tree.class,Color.BLACK);
        view.setColor(Grass.class,Color.GREEN);
        
        Weathers.add(Weather.NORMAL);
        Weathers.add(Weather.HEATWAVE);
        Weathers.add(Weather.FOG);
        Weathers.add(Weather.RAIN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly 60
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();
        //Chance the weather changes every 6 steps;
        if (step%6==0){
            currentWeather=Weathers.get(rand.nextInt(Weathers.size()));
        }
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            //The timeOfDay is found by taking the modulo of 24 of the step variable. This value will
            //be used to determine the behaviour of different actors at different times.
            actor.act(newActors,step%24,currentWeather);
            if(! actor.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly created actors to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        
        actors.clear();
        
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                
                 if (rand.nextDouble() <= TIGER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location,rand.nextBoolean());
                    actors.add(tiger);
                }
                else if(rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Giraffe giraffe = new Giraffe(true, field, location,rand.nextBoolean());
                    actors.add(giraffe);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location, rand.nextBoolean());
                    actors.add(snake);
                }
                else if(rand.nextDouble() <= TURTLE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Turtle turtle= new Turtle(true, field, location, rand.nextBoolean());
                    actors.add(turtle);
                }
                else if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location,rand.nextBoolean());
                    actors.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location, rand.nextBoolean());
                    actors.add(rabbit);
                }
                else if(rand.nextDouble() <= TREE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Tree tree = new Tree(true,field, location,true);
                    actors.add(tree);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true,field, location,true);
                    actors.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
