import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * The class for giraffes. It eats plants
 *
 * @version (a version number or a date)
 */
public class Giraffe extends Animal
{
    // Characteristics shared by all giraffe (class variables).

    // The age at which a giraffe can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a giraffe can live.
    private static final int MAX_AGE = 150;
    
    //The resistance of giraffes to disease
    private static final double IMMUNITY = 0.92;
    // The likelihood of a giraffe breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    //The number of steps a giraffe can go before it has to eat again.
    private static final int TREE_FOOD_VALUE = 40;
    

    /**
     * Create a new giraffe. A giraffe may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the giraffe will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If the animal is a male.
     */
    public Giraffe(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(randomAge, field, location, isMale, MAX_AGE);
        setFoodLevel(randomAge,TREE_FOOD_VALUE);
    }
    
    /**
     * This is what the giraffe does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGiraffes A list to return newly born giraffes.
     * @param timeOfDay The time of day in the simulation.
     * @param weather The weather in the simulation.
     */
    public void act(List<Actor> newGiraffes,int timeOfDay,Weather weather)
    {
        increaseAge();
        incrementHunger();
        if (getDiseases().contains(Disease.CANKER)){
            //Canker makes animals hungry faster. Can lead to starvation.
            for (int i=0;i<3;i++)
            {
                incrementHunger();
            }
        }
        
        if ((timeOfDay>10 && timeOfDay<18)|| getFoodLevel()<10){
            if(isAlive()) {
                //Chance to infect nearby giraffes.
                infect();
                giveBirth(newGiraffes);
                
                // Try to move into a free location while looking for food.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move. If it was not the animal stays where it is.
                if(newLocation != null) {
                    setLocation(newLocation);
                }else{
                    // Overcrowding.
                    setDead();
                }
    
            }
        }
    }
    
    /**
     * The giraffe will look for plants to eat. Returns the location of the plant
     * if it has been completely eaten so that the animal will move to that location
     * @return The location of a completely eaten plant. 
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            
            if (actor instanceof Tree){
                Tree tree=(Tree) actor;
                if (tree.isAlive()){
                    tree.consume();
                    setFoodLevel(false,TREE_FOOD_VALUE);
                    getDiseases().addAll(tree.getDiseases());
                    //Will only go to the plants location if it has been fully consumed.
                    if (!(tree.isAlive())){
                        return where;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this giraffe is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGiraffes A list to return newly born giraffes.
     */
    private void giveBirth(List<Actor> newGiraffes)
    {
        // New giraffes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Giraffe young = new Giraffe(false, field, loc, rand.nextBoolean());
            newGiraffes.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Two giraffe can breed if they have reached the breeding age and are of opposite gender.
     * @return true if the giraffe can breed, false otherwise.
     */
    private boolean canBreed()
    {
        //2 animals of the same species and different gender are next to each other.
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
              Location where = it.next();
              Object animal = field.getObjectAt(where);
              if (where!=null){
                if (animal instanceof Giraffe){
                    Giraffe giraffe = (Giraffe) animal;
                    if ((!(giraffe.getIsMale()) && (getIsMale()))||
                    ((giraffe.getIsMale()) && !(getIsMale()))){
                        if ((giraffe.getAge()>= BREEDING_AGE) && (getAge()>=BREEDING_AGE)){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
              }
        }
        return false;
    }
    
    /**
     * Infect nearby animals of the same species.
     */
    private void infect(){
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if (where!=null){
                if (actor instanceof Giraffe){
                    Giraffe giraffe = (Giraffe) actor;
                    //Chance to infect nearby giraffes.
                    if (rand.nextDouble()>IMMUNITY){
                        giraffe.getDiseases().addAll(getDiseases());
                    }
                }
            }
        }
    }
}
