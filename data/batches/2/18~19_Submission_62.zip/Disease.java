
/**
 * Enumeration class Disease - Different diseases have different magnitudes of effects on different animals.
 * Some animals can be carriers of a disease(carry the disease but are not affected by it). Some are directly
 * affected by it. Snakes,Tigers, and foxes are affected by lupus.Foxes are affected by rabies.
 * Rabbits and foxes are carriers of rabies.
 * Turtles are carriers of lupus. Plants and giraffes are affected by Canker. Turtles,Rabbits and Plants 
 * can introduce the disease to the system through breeding (Lupus,Rabies and Canker respectively).
 * @version (version number or date here)
 */
public enum Disease
{
    LUPUS,RABIES,CANKER
}
