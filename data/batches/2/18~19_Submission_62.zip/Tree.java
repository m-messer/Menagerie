import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Write a description of class Tree here.
 *
 * @version (a version number or a date)
 */
public class Tree extends Plant
{
    //The maximum growth of the plant.
    private static final int MAX_GROWTH_VALUE=10;
    //The most saplings a tree can reproduce.
    private static final int MAX_SPREAD_SIZE=2;
    //Probability the tree will reproduce
    private static final double SPREAD_PROBABILITY=0.02;
    //The resistance of a tree to disease.
    private static final double IMMUNITY=0.7;
    
    //The minimum growth value of the plant for it to spread new plants.
    private static final int SPREAD_GROWTH=7;
    //The maximum age a tree can live upto.
    private static final int MAX_AGE=100;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Tree
     * @param randomAge Whether the age of a tree should be generated randomly.
     * @param field The field of the tree in the simulation.
     * @param location The location of the created tree object in the simulation.
     * @param randomGrowth Whether the growth value of the tree should be set randomly or not.
     */
    public Tree(boolean randomAge,Field field, Location location, boolean randomGrowth)
    {
        super(randomAge,field,location,randomGrowth,MAX_AGE,MAX_GROWTH_VALUE);
    }

    /**
     * Trees will stay in one position, age, and maybe affected by or infect other trees with the disease.
     * @param newPlants An empty list of new plants to be created in the system.
     * @param timeOfDay The time of day within the simulation.
     */
    public void act(List<Actor> newPlants, int timeOfDay,Weather weather)
    {
        increaseAge();
        if (getDiseases().contains(Disease.LUPUS)){
            //Canker causes trees to have a shorter lifespan.
            changeMaxAgeTo(MAX_AGE-20);
        }
        
        if ((timeOfDay>9 && timeOfDay<17)){
            if(isAlive()) {
                //Can infect nearby trees.
                infect();
                //Reproduce new plants nearby.
                spreadNewPlants(newPlants);
                
                if(weather.equals(Weather.HEATWAVE)){
                    //If there is a heatwave, the growth value of the plant will decrease.
                    changeGrowth(-1);
                }
                else if (weather.equals(Weather.RAIN)){
                    //Rain causes trees to grow at an accelerated rate.
                    changeGrowth(5);
                }
                else
                {
                    //Trees will normally grow at this rate.
                    changeGrowth(2);
                }
                
            }
        }
    }
    
    /**
    * Create new plants at adjacent locations.
    * @param newPlants An empty list of plants of which new plant objects will be entered to.
    */
    private void spreadNewPlants(List<Actor> newPlants)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int saplings = spread();
        for(int b = 0; b < saplings && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tree young = new Tree(false,field,loc,false);
            //Chance that young trees will get infected.
            if (rand.nextDouble()>IMMUNITY){
                young.getDiseases().add(Disease.CANKER);
            }
            newPlants.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of saplings that can be created if it can spread saplings.
     * @return The number of saplings (may be zero).
     */
    private int spread()
    {
        int plants = 0;
        if(canSpread() && rand.nextDouble() <= SPREAD_PROBABILITY) {
            plants = rand.nextInt(MAX_SPREAD_SIZE) + 1;
        }
        return plants;
    }
    
    /**
     * Determines if new plants can be created.
     */
    private boolean canSpread()
    {
        return getGrowthValue()>=SPREAD_GROWTH;
    }
    
    /**
     * Infect nearby actors of the same species.
     */
    private void infect(){
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if (where!=null){
                if (actor instanceof Tree){
                    Tree tree = (Tree) actor;
                    //Nearby trees will have an immunity against the disease.
                    if (rand.nextDouble()>IMMUNITY){
                        tree.getDiseases().addAll(getDiseases());
                    }
                }
            }
        }
    }
}
