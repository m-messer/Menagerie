
/**
 * Enumeration class Weather - Normal weather has no effect on the system. A heatwave causes the growthValue
 * of plants to decrease. Fog causes animals that prey on other animals to stop hunting(as they cannot see well)
 * Rain causes the growth of plants to accelerate.
 *
 * @version (version number or date here)
 */
public enum Weather
{
    NORMAL,HEATWAVE,FOG,RAIN
}
