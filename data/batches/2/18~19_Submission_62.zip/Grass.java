import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * Write a description of class Grass here.
 *
 * @version (a version number or a date)
 */
public class Grass extends Plant
{
    //The maximum growth of grass.
    private static final int MAX_GROWTH_VALUE=14;
    //The maximum number of saplings of the plant created when reproducing.
    private static final int MAX_SPREAD_SIZE=2;
    //The probability the plant will reproduce.
    private static final double SPREAD_PROBABILITY=0.05;
    //How resistant the plant is to disease.
    private static final double IMMUNITY=0.94;
    //The minimum growth of a plant for it to spread.
    private static final int SPREAD_GROWTH=5;
    //The maximum age the grass can live upto.
    private static final int MAX_AGE=100;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Grass
     */
    public Grass(boolean randomAge,Field field, Location location, boolean randomGrowth)
    {
        super(randomAge,field,location,randomGrowth,MAX_AGE,MAX_GROWTH_VALUE);
    }

    /**
     * @param newPlants An empty list of new plants to be created in the system.
     * @param timeOfDay The time of day within the simulation.
     */
    public void act(List<Actor> newPlants, int timeOfDay,Weather weather)
    {
        increaseAge();
        if (getDiseases().contains(Disease.LUPUS)){
            //Canker causes grass to have a shorter lifespan.
            changeMaxAgeTo(MAX_AGE-10);
        }
        
        if ((timeOfDay>9 && timeOfDay<17)){
            if(isAlive()) {
                //Infect nearby trees.
                infect();
                //New plants maybe spawned in nearby locations.
                spreadNewPlants(newPlants);
                if(weather.equals(Weather.HEATWAVE)){
                    changeGrowth(-1);
                }
                else if (weather.equals(Weather.RAIN)){
                    changeGrowth(4);
                }
                else
                {
                    changeGrowth(2);
                }
                
            }
        }
    }
    
    /**
    * Create new plants at adjacent locations.
    * @param newPlants An empty list of plants of which new plant objects will be entered to.
    */
    private void spreadNewPlants(List<Actor> newPlants)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int saplings = spread();
        for(int b = 0; b < saplings && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false,field,loc,false);
            
            //Chance a spawned plant can have a disease.
            if (rand.nextDouble()>IMMUNITY){
                young.getDiseases().add(Disease.CANKER);
            }
            newPlants.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of saplings that can be created if it can spread saplings.
     * @return The number of saplings (may be zero).
     */
    private int spread()
    {
        int plants = 0;
        if(canSpread() && rand.nextDouble() <= SPREAD_PROBABILITY) {
            plants = rand.nextInt(MAX_SPREAD_SIZE) + 1;
        }
        return plants;
    }
    
    /**
     * Determines if new plants can be created if it has a growth value larger than the minimum growth needed
     * to spread plants.
     */
    private boolean canSpread()
    {
        return getGrowthValue()>=SPREAD_GROWTH;
    }
    
    /**
     * Infect nearby actors of the same species.
     */
    private void infect(){
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if (where!=null){
                if (actor instanceof Grass){
                    Grass grass = (Grass) actor;
                    //Chance nearby grass does not get infected if the random value is less than immunity.
                    if (rand.nextDouble()>IMMUNITY){
                        grass.getDiseases().addAll(getDiseases());
                    }
                }
            }
        }
    }
}
