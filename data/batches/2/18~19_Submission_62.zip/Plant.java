import java.util.Random;
import java.util.List;
/**
 * Plants will serve as a food source for some animals that exist within the simulation.
 *
 * @version (a version number or a date)
 */
public abstract class Plant extends Actor
{
    
    private int maxGrowthValue;
    private int growthValue;
    
    private static final Random rand = Randomizer.getRandom();
    /**
     * Constructor for objects of class Plants
     * @param randomAge Whether the age of the plant should be randomly generated.
     * @param field The field of the simulation.
     * @param location The location of the plant in the field.
     * @param randomGrowth Whether the growth of the plant should be set randomly.
     * @param maxAge The maximum age of the plant.
     * @param maxGrowthValue The maximum amount a plant can grow upto.
     */
    public Plant(boolean randomAge,Field field, Location location, boolean randomGrowth, int maxAge,int maxGrowthValue)
    {
        super(randomAge,field,location,maxAge);
        growthValue=2;
        this.maxGrowthValue=maxGrowthValue;
        //Set the growth value of the plant.
        setGrowthValue(randomGrowth,maxGrowthValue);
    }
    
    /**
     * @param randomGrowth If true the growthValue will be set randomly to a value upto growthValue.
     * @param growthValue The the growth value to be set.
     */
    protected void setGrowthValue(boolean randomGrowth, int growthValue)
    {
        if (randomGrowth){
            Random rand= new Random();
            growthValue= rand.nextInt(growthValue);
        }else{
            this.growthValue=growthValue;
        }
    }
    
    /**
     * @return The growth value of the plant.
     */
    protected int getGrowthValue(){
        return growthValue;
    }
    
    /**
     * @param newPlants An empty list of new plants to be created in the system.
     * @param timeOfDay The time of day within the simulation.
     * @param weather The weather within the simulation.
     */
    public abstract void act(List<Actor> newPlants, int timeOfDay,Weather weather);
    
    /**
     * change the growth of the plant by a given rate.
     * @param rate The value by which the growth of the plant should be changed by.
     */
    protected void changeGrowth(int rate){
        growthValue=growthValue+rate;
        if (growthValue>maxGrowthValue){
            growthValue=maxGrowthValue;
        }else if (growthValue<0){
            setDead();
        }
        
    }
    
    /**
     * Decreases the growth of the plant if an animal eats it. 
     * If the growth of the plant is 0 or less, the plant dies.
     */
    public void consume(){
        growthValue=growthValue-1;
        if (growthValue<=0){
            setDead();
        }
    }
}
