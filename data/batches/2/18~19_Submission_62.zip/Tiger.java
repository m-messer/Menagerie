import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * The class for Tigers. It eats foxes, giraffes, turtles and rabbits.
 *
 * @version (a version number or a date)
 */
public class Tiger extends Animal
{
    
    private static final Random rand = Randomizer.getRandom();

    // The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a tiger can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    
    private static final double IMMUNITY = 0.98;
    // The food value of a single rabbit, fox or snake. In effect, this is the
    // number of steps a tiger can go before it has to eat again.
    private static final int FOX_FOOD_VALUE = 19;
    private static final int GIRAFFE_FOOD_VALUE = 24;
    private static final int TURTLE_FOOD_VALUE= 20;
    private static final int RABBIT_FOOD_VALUE= 18;
    /**
     * Constructor for objects of class Tiger
     */
    public Tiger(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(randomAge,field, location, isMale, MAX_AGE);
        //age = 0;
        //age is set randomly.
        setAge(randomAge,MAX_AGE);
        setFoodLevel(randomAge,TURTLE_FOOD_VALUE);
    }

    /**
     * This is what the tiger does most of the time: it hunts and moves.
     * In the process, it might breed, die of hunger,die of disease
     * or die of old age.
     * @param newTigers A list to return newly born tigers.
     */
    public void act(List<Actor> newTigers, int timeOfDay,Weather weather)
    {
        increaseAge();
        incrementHunger();
        if (getDiseases().contains(Disease.RABIES)){
            //Rabies makes animals hungry faster. Can lead to starvation.
            incrementHunger();
        }
        
        if (getDiseases().contains(Disease.LUPUS)){
            //Lupus causes animals to have a shorter lifespan.
            changeMaxAgeTo(MAX_AGE-5);
        }
        
        if ((timeOfDay>7 && timeOfDay<21) || getFoodLevel()<10){
            if(isAlive()) {
                //Infect nearby animals of the same species.
                infect();
                
                giveBirth(newTigers);            
                // Move towards a source of food if found.
                Location newLocation=null;
                //Cannot hunt in the fog.
                if (!weather.equals(Weather.FOG)){
                    newLocation = findFood();
                }
                
                // See if it was possible to move. If it was not the animal stays where it is.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
            }
        }
    }
    
    /**
     * Check whether or not this tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTigers A list to return newly born tigers.
     */
    private void giveBirth(List<Actor> newTigers)
    {
        // New tigers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tiger young = new Tiger(false, field, loc, rand.nextBoolean());
            newTigers.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Two tigers can breed if they have reached the breeding age and are of opposite gender.
     * @return true if the tiger can breed, false otherwise.
     */
    private boolean canBreed()
    {
        //2 animals of the same species and different gender are next to each other.
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
              Location where = it.next();
              Object animal = field.getObjectAt(where);
              if (where!=null){
                if (animal instanceof Tiger){
                    Tiger tiger = (Tiger) animal;
                    if ((!(tiger.getIsMale()) && (getIsMale()))||
                    ((tiger.getIsMale()) && !(getIsMale()))){
                        if ((tiger.getAge()>= BREEDING_AGE) && (getAge()>=BREEDING_AGE)){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
              }
        }
        return false;
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            //The tiger will eat animals in this order of precedence if available
            if(actor instanceof Giraffe) {
                Giraffe giraffe = (Giraffe) actor;
                if(giraffe.isAlive()) { 
                    giraffe.setDead();
                    getDiseases().addAll(giraffe.getDiseases());
                    setFoodLevel(false,GIRAFFE_FOOD_VALUE);
                    return where;
                }
            }else if (actor instanceof Turtle){
                Turtle turtle= (Turtle) actor;
                if(turtle.isAlive()){
                    turtle.setDead();
                    getDiseases().addAll(turtle.getDiseases());
                    setFoodLevel(false,TURTLE_FOOD_VALUE);
                    return where;
                }
            }else if (actor instanceof Fox){
                Fox fox= (Fox) actor;
                if(fox.isAlive()){
                    fox.setDead();
                    getDiseases().addAll(fox.getDiseases());
                    setFoodLevel(false,FOX_FOOD_VALUE);
                    return where;
                }
            }else if (actor instanceof Rabbit){
                Rabbit rabbit = (Rabbit) actor;
                if (rabbit.isAlive()){
                    rabbit.setDead();
                    getDiseases().addAll(rabbit.getDiseases());
                    setFoodLevel(false,RABBIT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Infect nearby animals of the same species.
     */
    private void infect(){
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if (where!=null){
                if (actor instanceof Tiger){
                    Tiger tiger = (Tiger) actor;
                    if (rand.nextDouble()>IMMUNITY){
                        tiger.getDiseases().addAll(getDiseases());
                    }
                }
            }
        }
    }
}
