import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{
    
    private boolean isMale;
    private int foodLevel;
    private Random rand = Randomizer.getRandom();
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Whether the animal is a male.
     * @param maxAge The maximum age of the animal.
     */
    public Animal(boolean randomAge,Field field, Location location, boolean isMale, int maxAge)
    {
        super(randomAge, field, location,maxAge);
        foodLevel=0;
        this.isMale=isMale;
    }
    
    /**
     * Abstract method for Animals to act.
     * @param newAnimals an empty list for new Animals that are created.
     * @param timeOfDay The time of day in the simulation.
     */
    public abstract void act(List<Actor> newAnimals, int timeOfDay,Weather weather);
    
    /**
     * Set the food level for the animal.
     * @param randomHunger The foodLevel of the animal will be set randomly to a value upto hungerValue.
     * @param hungerValue The value that the foodLevel of the animal will be set to.
     */
    protected void setFoodLevel(boolean randomHunger,int hungerValue){
        if (randomHunger){
            foodLevel=rand.nextInt(hungerValue);
        }else{
            foodLevel = hungerValue;
        }
    }
    
    /**
     * returns the foodLevel of the animal.
     * @return The foodLevel of the animal.
     */
    protected int getFoodLevel(){
        return foodLevel;
    }
    
    /**
     * reduce the foodLevel of the animal by 1. If the value becomes less than or equal to 0 set it to Dead.
     */
    protected void incrementHunger(){
        foodLevel=foodLevel-1;
        if (foodLevel<=0){
            setDead();
        }
    }
    
    /**
     * Return the animal's gender.
     * @return The animal's gender
     */
    protected boolean getIsMale(){
        return isMale;
    }
    
}
