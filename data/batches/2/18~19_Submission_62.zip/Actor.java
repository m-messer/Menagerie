import java.util.List;
import java.util.Random;
import java.util.HashSet;
import java.util.Iterator;
/**
 * A class that holds the properties that all organisms in the system should have.
 *
 * @version (version number or date here)
 */
public abstract class Actor
{
    //The field of the simulation.
    private Field field;
    //The location of the actor in the simulation
    private Location location;
    //Whether the actor is alive or not.
    private boolean alive;
    //The maximum age the actor can live upto.
    private int maxAge;
    //The current age of the actor.
    private int age;
    //A set of all diseases the actor has contracted.
    private HashSet<Disease> diseases=new HashSet<>();
    
    private Random rand = Randomizer.getRandom();

    /**
     * Constructor of an actor.
     * @param randomAge whether the age of the organism should be random.
     * @param field The field the organism shall live in.
     * @param location The location within the field.
     * @param maxAge The maximum possible age of an organism before it dies.
     */
    public Actor( boolean randomAge, Field field, Location location, int maxAge)
    {
        this.field=field;
        setLocation(location);
        alive=true;
        age=0;
        this.maxAge=maxAge;
        setAge(randomAge,maxAge);
    }
    
    /**
     * returns the set of diseases.
     * @return The set of diseases an animal has.
     */
    protected HashSet<Disease> getDiseases(){
        return diseases;
    }
    
    /**
     * Change the maxAge of the animal to a certian amount
     * @param change The value the maxAge is to be changed to.
     */
    protected void changeMaxAgeTo(int change){
        maxAge=change;
        //If the actor is older than the new maxAge, it dies.
        if (age>maxAge){
            setDead();
        }
    }
    
    
    /**
     * Increments the age of the organism. If this exceeds the maxAge the actor dies.
     */
    public void increaseAge(){
        age=age+1;
        //If the age exceeds the maxAge, the actor dies.
        if(age > maxAge) {
            setDead();
        }
    }
    
    /**
     * Sets the age of an organism. 
     * @param randomAge If true the age will be a random value upto the ageLimit. Otherwise it will be 0.
     * @param ageLimit The limit to the bounds of the age.
     */
    protected void setAge(boolean randomAge,int ageLimit){
        if (randomAge){
            Random rand= new Random();
            age= rand.nextInt(ageLimit);
        }
    }
    
    /**
     * @return Retrieves the age of the organism
     */
    protected int getAge(){
        return age;
    }
    
    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Abstract method for Actors to act.
     * @param newActors an empty list for new Actors that are created.
     * @param timeOfDay The time of day in the simulation.
     * @param weather The weather within the simulation.
     */
    public abstract void act(List<Actor> newActors, int timeOfDay,Weather weather);

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
}
