import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * The class for the animal snake. It eats rabbits and turtles.
 *
 * @version (a version number or a date)
 */
public class Snake extends Animal
{
    
    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 16;
    // The age to which a snake can live upto.
    private static final int MAX_AGE = 150;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    //How resistant the species is to disease.
    private static final double IMMUNITY = 0.99;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single rabbit/turtle. In effect, this is the
    // number of steps a snake can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 25;
    private static final int TURTLE_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Whether the snake is a male.
     */
    public Snake(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(randomAge,field, location, isMale, MAX_AGE);
        setAge(randomAge,MAX_AGE);
        setFoodLevel(randomAge,RABBIT_FOOD_VALUE);
    }
    
    /**
     * This is what the snake does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSnakes A list to return newly born snakes.
     * @param timeOfDay The time of day in the simulation.
     */
    public void act(List<Actor> newSnakes, int timeOfDay,Weather weather)
    {
        increaseAge();
        incrementHunger();
        if (getDiseases().contains(Disease.RABIES)){
            //Rabies makes animals hungry faster. Can lead to starvation
            incrementHunger();
        }
        
        if (getDiseases().contains(Disease.LUPUS)){
            //Lupus causes animals to have a shorter lifespan.
            changeMaxAgeTo(MAX_AGE-10);
        }
        
        if ((timeOfDay<10 || timeOfDay>22) || (getFoodLevel()<10)){
            if(isAlive()) {
                infect();
                giveBirth(newSnakes);            
                // Move towards a source of food if found.
                Location newLocation=null;
                //Cannot hunt in the fog
                if (!weather.equals(Weather.FOG)){
                    newLocation = findFood();
                }
                
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                
                // See if it was possible to move. Otherwise stay in the same spot.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
            }
        }
    }
    
    
    /**
     * Look for rabbits and turtles adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            //Snakes will eat animals. Animals that are eaten which have a disease will pass the disease
            //onto the predator. Immunity does not prevent this.
            if (actor instanceof Turtle){
                Turtle turtle= (Turtle) actor;
                if(turtle.isAlive()){
                    turtle.setDead();
                    getDiseases().addAll(turtle.getDiseases());
                    setFoodLevel(false,TURTLE_FOOD_VALUE);
                    return where;
                }
            }
            else if (actor instanceof Rabbit){
                Rabbit rabbit = (Rabbit) actor;
                if (rabbit.isAlive()){
                    rabbit.setDead();
                    getDiseases().addAll(rabbit.getDiseases());
                    setFoodLevel(false,RABBIT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this snake is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSnakes A list to return newly born Snakes.
     */
    private void giveBirth(List<Actor> newSnakes)
    {
        // New snakes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Snake young = new Snake(false, field, loc, rand.nextBoolean());
            newSnakes.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Two snakes can breed if they have reached the breeding age and are of opposite gender.
     * @return true if the snake can breed, false otherwise.
     */
    private boolean canBreed()
    {
        //2 animals of the same species and different gender are next to each other.
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
              Location where = it.next();
              Object animal = field.getObjectAt(where);
              if (where!=null){
                  if (animal instanceof Snake){
                    Snake snake = (Snake) animal;
                    if ((!(snake.getIsMale()) && (getIsMale()))||
                    ((snake.getIsMale()) && !(getIsMale()))){
                        if ((snake.getAge()>= BREEDING_AGE) && (getAge()>=BREEDING_AGE)){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
              }
        }
        return false;
    }
    
    /**
     * Infect nearby animals of the same species.
     */
    private void infect(){
        Field field = getField();
        List<Location> adjacentLocations=field.adjacentLocations(getLocation());
        Iterator<Location> it= adjacentLocations.iterator();
        while (it.hasNext()){
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if (where!=null){
                if (actor instanceof Snake){
                    Snake snake = (Snake) actor;
                    if (rand.nextDouble()>IMMUNITY){
                        snake.getDiseases().addAll(getDiseases());
                    }
                }
            }
        }
    }
}