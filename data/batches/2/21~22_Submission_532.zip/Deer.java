import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Deer.
 * Deers age, move, breed, and die.
 *
 * @version 2022.02.28 
 */
public class Deer extends Prey
{
    // Characteristics shared by all Deers (class variables).

    // The "age" at which a Deer can start to breed.
    private static final int BREEDING_AGE = 5;
    // The "age" to which a Deer can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a Deer breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Food value of a deer
    private static final int FOOD_VALUE = 9;
    // Max value of food level for a deer.
    private static final int MAX_FOOD_LEVEL = 10;
    
    // Individual characteristics (instance fields).
    
    // The Deer's "age".
    private int age;
    // The Deer's food level.
    private int foodLevel;

    /**
     * Create a new Deer. A Deer may be created with "age"
     * zero (a new born) or with a random "age".
     * 
     * @param randomAge If true, the Deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time Time of the field.
     */
    public Deer(boolean randomAge, Field field, Location location, TimeOfDay time)
    {
        super(field, location, time);
   
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(Plant.getFoodValue());
        }
        else {
            age = 0;
            foodLevel = Plant.getFoodValue();
        }
    }

    
    /**
     * Increase the "age" (every step increases the "age" by one hence the quotation marks).
     * This could result in the Deer's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Deer more hungry. This could result in the Deer's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for Plants adjacent to the current location.
     * Only the first live Plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        
        // Check if there are any nearby Plants, move towards them (by returning their location)
        // and eat them if there are any, return null if there are none.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant Plant = (Plant) animal;
                if(Plant.isAlive()) // Set the eaten Plant dead and add it's food value to Deer's food level.
                { 
                    Plant.setDead();
                    foodLevel = foodLevel + Plant.getFoodValue();
                    if (foodLevel > MAX_FOOD_LEVEL) {
                        foodLevel = MAX_FOOD_LEVEL;
                    }
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeers A list to return newly born Deers.
     */
    protected void giveBirth(List<Entity> newDeers)
    {
        // New Deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        TimeOfDay time = getTime();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc, time);
            newDeers.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Deer can breed if it has reached the breeding age and if there are any other Deers of the opposite genders nearby.
     * @return true if the Lion can breed
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if(age >= BREEDING_AGE)
        {
            while(it.hasNext()) 
            {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Deer && this.isOppositeGender((Deer)animal)) // Check if there are any Deers of the opposite gender nearby.
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Return the food value of a Deer.
     * @return the food value of a Deer.
     */
    public static int getFoodValue()
    {
        return FOOD_VALUE;
    }
}
