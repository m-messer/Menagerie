import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Plant.
 * Plants age, move, breed, and die.
 *
 * @version 2016.02.29
 */
public class Plant extends Entity
{
    // Characteristics shared by all Plants (class variables).

    // The age at which a Plant can start to breed.
    private static final int GROWING_AGE = 3;
    // The age to which a Plant can live.
    private static final int PERISH_AGE = 7;
    // The likelihood of a Plant breeding.
    private static final double GROWTH_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_SPREAD = 4;
    // How much food it provides to other animals
    private static final int FOOD_VALUE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Plant's age.
    private int age;

    /**
     * Create a new Plant. A Plant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time  Time of the field.
     */
    public Plant(boolean randomAge, Field field, Location location, TimeOfDay time)
    {
        super(field, location, time);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(PERISH_AGE);
        }
    }
    
    /**
     * This is what the Plant does most of the time.
     * Sometimes it breeds or dies of old age.
     * @param newPlants A list to return newly born Plants.
     */
    public void act(List<Entity> newPlants)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newPlants);            
        }
    }

    /**
     * Increase the age if it rains.
     * This could result in the Plants's death.
     */
    protected void incrementAge()
    {
        if (getWeather().hasStatus("rain") == true && getWeather().hasStatus("drought") == false) {
            age++;
        }
        
        if(age > PERISH_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born Plants.
     */
    protected void giveBirth(List<Entity> newPlants)
    {
        // New Plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        TimeOfDay time = getTime();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc,time);
            newPlants.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= GROWTH_PROBABILITY) {
            births = rand.nextInt(MAX_SPREAD) + 1;
        }
        return births;
    }

    /**
     * A Plant can breed if it has reached the breeding age and if there is rain.
     * @return true if the Plant can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= GROWING_AGE && getWeather().hasStatus("rain") == true && getWeather().hasStatus("drought") == false);
    }
    
    /**
     * A Plant's food value. How much food it gives to other
     * animals.
     * @return Int with plant's food value
     */
    public static int getFoodValue()
    {
        return FOOD_VALUE;
    }
}
