
/**
 * A class representing shared characteristics of Prey animals.
 * Currently no such behaviour is implemented but it is still there in case someone wants to implement
 * in the future.
 *
 * @version 2022.02.28 
 */
public abstract class Prey extends Animal
{
    /**
     * Create a new prey at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time  Time of the field.
     */
    public Prey(Field field, Location location, TimeOfDay time)
    {
        super(field,location,time);
    }
    
}
