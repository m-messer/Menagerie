import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Deers, Leopards, Fish, Crocodiles, Lions and Plants.
 *
 * @version 2022.02.28 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Leopard will be created in any given grid position.
    private static final double LEOPARD_CREATION_PROBABILITY = 0.04;
    // The probability that a Lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.04;
    // The probability that a Crocodile will be created in any given grid position.
    private static final double CROCODILE_CREATION_PROBABILITY = 0.04;
    // The probability that a Deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.13;    
    // The probability that a Fish will be created in any given grid position.
    private static final double FISH_CREATION_PROBABILITY = 0.12;  
    // The probability that a Plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.2;  
    
    // List of entities in the field.
    private List<Entity> entities;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    // Keep track of time of day and weather
    private TimeOfDay currentTime;
    private Weather currentWeather;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        entities = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Deer.class, Color.ORANGE);
        view.setColor(Leopard.class, Color.BLUE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Crocodile.class, Color.GREEN);
        view.setColor(Fish.class, Color.PINK);
        view.setColor(Plant.class, new Color(0, 120, 50));
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Refresh the time and weather objects into new objects
     * for the reset method.
     * Re-hook the time-weather methods.
     */
    public void resetTimeWeather()
    {
        currentTime = new TimeOfDay();
        currentWeather = new Weather();
        
        // hooking time function to weather function
        currentTime.onDayChange(
            () -> {
                int currentDay = currentTime.getDayInt();
                currentWeather.dayChanged(currentDay);
            }
        );
        
        currentTime.onHourChange(
            () -> {
                int currentHour = currentTime.currentTimeInt();
                currentWeather.hourChanged(currentHour);
            }
        );
        
        field.setWeather(currentWeather);
    }
    
    /**
     * Update the overall simulation data (step, time data, weather data)
     */
    public void updateStatus()
    {
        view.showStatus(step, field, currentTime.getCurrentData() + currentWeather.getWeatherData());
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(120);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each Entity.
     */
    public void simulateOneStep()
    {
        step++;
        currentTime.increment();

        // Provide space for newborn entities.
        List<Entity> newEntities = new ArrayList<>();        
        // Let all Entity act.
        for(Iterator<Entity> it = entities.iterator(); it.hasNext(); ) {
            Entity entity = it.next();
            entity.act(newEntities);
            if(!entity.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born Entities to the main lists.
        entities.addAll(newEntities);
        updateStatus();
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        resetTimeWeather();
        entities.clear();
        populate();
        
        // Show the starting state in the view.
        updateStatus();
    }
    
    /**
     * Randomly populate the field with Entities.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LEOPARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Leopard Leopard = new Leopard(true, field, location,currentTime);
                    entities.add(Leopard);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion Lion = new Lion(true, field, location,currentTime);
                    entities.add(Lion);
                }
                else if(rand.nextDouble() <= CROCODILE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Crocodile Crocodile = new Crocodile(true, field, location,currentTime);
                    entities.add(Crocodile);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer Deer = new Deer(true, field, location,currentTime);
                    entities.add(Deer);
                }
                else if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fish Fish = new Fish(true, field, location,currentTime);
                    entities.add(Fish);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant Plant = new Plant(false, field, location,currentTime);
                    entities.add(Plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
