import java.util.HashMap;

/**
 * Class stimulates time throughout the day.
 * Class further provides terms used to define 
 * certain times of day (Morning, Afternoon, etc).
 * Flexible in terms of being able to add lambda runnables to certain hooks.
 * Hooks: run per hour (onHourChange), run per day (onDayChange)
 *
 * @version 2022.02.28 
 */
public class TimeOfDay
{
    // counters that keep track of the time in int form
    private int dayCount;
    private int hourCount;
    
    // HashMap that holds terms at certain points of the day
    private HashMap<String, String> timesOfDay;
    
    // (currently empty) functions that can be hooked to class functions
    // ran when class functions are run
    private Runnable hourFunction;
    private Runnable dayFunction;
    
    /**
     * Creates a new time of day in order to simulate time.
     * Initialises terms defining certain times of day.
     */
    public TimeOfDay()
    {
        // initialise basic time fields
        dayCount = 1;
        hourCount = 0;
        // initialise terms for time of day (fills HashMap above)
        timesOfDay = new HashMap<String, String>(){{
                put("0", "Midnight");
                put("1", "Late Night");
                put("3", "Early Morning");
                put("6", "Morning");
                put("12", "Noon");
                put("13", "Afternoon");
                put("18", "Evening");
                put("20", "Night");
            }};
    }
    
    /**
     * Increment timer by default time (1 step).
     */
    public void increment()
    {
        incrementHour();
    }
    
    /**
     * Increment timer based on given amount.
     * @param int Amount to increment by. Must be greater than 0.
     */
    public void increment(int amount)
    {
        for (int i = 0; i < amount; i++) {
            incrementHour();
        }
    }
    
    /**
     * Increments the hour counter field by 1.
     * Runs the hourFunction method if one exists.
     * If hour counter reaches 24 hrs then resets to midnight (0).
     */
    public void incrementHour()
    {
        hourCount++;
        if (hourFunction != null) {
            hourFunction.run();
        }
        if (hourCount > 23) {
            hourCount = 0;
            incrementDay();
        }
    }
    
    /**
     * Increments day counter field by 1.
     * Used to determine that 24 hrs have passed.
     * Runs dayFunction method if one exists.
     */
    public void incrementDay()
    {
        dayCount++;
        if (dayFunction != null) {
            dayFunction.run();
        }
    }
    
    /**
     * Hooks custom lambda fucntion to run on hour counter changing.
     * (incrementHour method)
     * @param Runnable the lambda to be run
     */
    public void onHourChange(Runnable function)
    {
        hourFunction = function;
    }
    
    /**
     * Hooks custom lambda fucntion to run on day counter changing.
     * (incrementDay method)
     * @param Runnable the lambda to be run
     */
    public void onDayChange(Runnable function)
    {
        dayFunction = function;
    }
    
    /**
     * Gets the current value of the hour counter field.
     * @return int value of hour counter
     */
    public int currentTimeInt()
    {
        return hourCount;
    }

    /**
     * Gets the current value of the day counter field.
     * @return int value of day counter
     */
    public int getDayInt()
    {
        return dayCount;
    }
    
    /**
     * Iterates through the terms of times of days to determine current time.
     * @return String Current term of the time of day.
     */
    public String getTimeOfDay()
    {
        String currentTimes = "";
        int currentHighest = 0;
        
        // iterate through HashMap, if the current value is bigger than
        // previous value then set the currentTime (term) to the key;
        // fundamentally determines which time is most recent.
        for (HashMap.Entry<String, String> entry : timesOfDay.entrySet()) {
            String k = entry.getKey();
            String v = entry.getValue();
            int toInt = Integer.parseInt(k);
            if ((hourCount >= toInt) && (toInt >= currentHighest)) {
                currentTimes = v;
                currentHighest = toInt;
            }
        }
        return currentTimes;
    }
    
    /**
     * Compiles all relevant time of day data together to provide a concise status.
     * Includes: current time, current term, current day.
     * @return String Compiled time of day data in string format.
     */
    public String getCurrentData()
    {
        String postfix = "";
        int deduction = 0;
        
        // determine postfix of time
        if (hourCount < 12) {
            postfix = "AM";
        } else if (hourCount >= 12) {
            postfix = "PM";
            deduction = 12;
        }
        
        // determine if it is either midnight or noon
        int newHour = (hourCount - deduction);
        if (newHour == 0) {
            newHour = 12;
        }
        
        // compile all data together
        String returnedData = String.format("[Time: %s (%s)] [Day: %s]", newHour, 
            getTimeOfDay(), dayCount);
        
        return returnedData;
    }
    
    /**
     * Determines if it is night time or not.
     * @return boolean True if night, false if any other time of day.
     */
    public boolean isNight()
    {
        return (hourCount >= 20 || hourCount < 6);
    }
}
