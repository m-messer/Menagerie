
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of entities.
 *
 * @version 2022.02.28 
 */
public abstract class Entity
{
    // Whether the entity is alive or not.
    private boolean alive;
    // The entity's field.
    private Field field;
    // The entity's position in the field.
    private Location location;
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    // A field for entity to store the Field's time.
    private TimeOfDay time;
    
    // Stores whether the entity is infected of not.
    protected boolean infected;
    // Values for the infection.
    // Chance of an animal being infected on birth.
    protected static final double infectionSpawnRate = 0.01;
    // The likelihood of an infected animal dying per step.
    protected static final double infectionDeathRate = 0.5;
    // The likelihood of an infected animal 
    // infecting animals in neighbouring locations.
    protected static final double infectionRate = 0.5;
    // A field for entity to store the Field's Weather.
    private Weather weather;
    
    /**
     * Create a new entity at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time Field's time
     */
    public Entity(Field field, Location location, TimeOfDay time)
    {
        alive = true;
        infected = false;
        this.field = field;
        this.time = time;
        setLocation(location);
        weather = getField().getWeather();
    }
    
    /**
     * Make this entity act - that is: make it do
     * whatever it wants/needs to do.
     * @param newEntities A list to receive newly born entities.
     */
    abstract public void act(List<Entity> newEntities);

    /**
     * Check whether the entity is alive or not.
     * @return true if the entity is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Returns the weather of the field.
     * @return the weather belonging to the field.
     */
    protected Weather getWeather()
    {
        return weather;
    }
    
    /**
     * Returns true if the entity is infected
     * @return whether entity is infected or not
     */
    public boolean isInfected()
    {
        return infected;
    }
    
    /**
     * Changes the infection status of an entity
     * @param  newInfected  a parameter to set true if we want to infect an entity and to false if we wish to cure it.
     */
    protected void setInfected(boolean newInfected)
    {
        infected = newInfected;
    }
    
    /**
     * Indicate that the entity is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the entity's location.
     * @return The entity's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the entity's time.
     * @return The entity's time.
     */
    protected TimeOfDay getTime()
    {
        return time;
    }
    
    /**
     * Place the entity at the new location in the given field.
     * @param newLocation The entity's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the entity's field.
     * @return The entity's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Every entity gives birth to their own species hence this method is abstract
     * @param  newEntities  the list of new entities this entity will give birth to.
     */
    abstract protected void giveBirth(List<Entity> newEntities);
}