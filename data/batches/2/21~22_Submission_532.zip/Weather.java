import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/**
 * This class stimulates weather and provides weather data to other classes.
 * Other capabilities include: rotating through the 4 seasons and providing
 * weather status effects throughout the days.
 * Mainly used alongside TimeOfDay class for increments.
 *
 * @version 2022.02.28 
 */
public class Weather
{
    // array of all four seasons, simply used as identifiers
    private static final String[] seasons = {"Winter", "Autumn", "Summer", "Spring"};
    // String version of the currentSeason
    private String currentSeason;
    // int version of the currentSeason, counter to keep track
    private int seasonCounter = 0;
    // ArrayList to hold current weather status
    ArrayList<String> weatherStatus;
    // HashMap to hold initial weather data status percentages for each season
    private HashMap<String, HashMap> weatherData;
    // A shared random number generator to provide randomised status.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Creates a new weather object in order to simulate day-to-day
     * weather and the four seasons.
     * Initialises seasons and their chances for certain status.
     */
    public Weather()
    {
        // initialise instance variables
        seasonCounter = 0;
        currentSeason = getSeasonAt(seasonCounter);
        weatherStatus = new ArrayList<String>();
        
        // initialise chances of certain weather status per season
        weatherData = new HashMap<String, HashMap>(){{
            put("Winter", new HashMap<String, String>(){{
                put("rain", "0.2");
                put("foggy", "0.6");
                put("harsh", "0.1");
            }});
            put("Autumn", new HashMap<String, String>(){{
                put("rain", "0.2");
                put("drought", "0.5");
            }});
            put("Summer", new HashMap<String, String>(){{
                put("rain", "0.3");
                put("drought", "0.4");
            }});
            put("Spring", new HashMap<String, String>(){{
                put("rain", "0.5");
                put("foggy", "0.4");
            }});
        }};
    }
    
    /**
     * Retrieves the current season.
     * @return String weather's current season
     */
    public String getCurrentSeason()
    {
        return currentSeason;
    }
    
    /**
     * Checks if it is currently the season inputted.
     * @param String season to check with.
     * @return true if seasons are the same, otherwise false
     */
    public boolean isSeason(String season)
    {
        return (currentSeason.equals(season));
    }
    
    /**
     * Checks if a certain status is currently on-going.
     * @return true if the status exists inside ArrayList, otherwise false
     */
    public boolean hasStatus(String status)
    {
        return weatherStatus.contains(status);
    }
    
    /**
     * Compiles all current weather status together into a string.
     * @return String consisting of all current status.
     */
    private String getStatusAsString()
    {
        String newString = "";
        for (String status : weatherStatus) {
            newString += status+", ";
        }
        
        if (newString.equals("") == false)
        {
            newString = newString.substring(0, newString.length() - 2);
        }
        else
        {
            newString = "None";
        }
        
        return newString;
    }
    
    /**
     * Flushes all current weather status.
     */
    private void clearStatus()
    {
        weatherStatus = new ArrayList<String>();
    }
    
    /**
     * Retrieves the season at the index specified.
     * @return String of the season at specified index.
     */
    private String getSeasonAt(int index)
    {
        return seasons[index];
    }
    
    /**
     * Rotates to the next season in the season array.
     * If the season counter surpasses the max length of the season
     * then it rotates back to the first season.
     */
    private void rotateSeason()
    {
        int nextSeason = (seasonCounter + 1);
        if (nextSeason >= seasons.length) {
            nextSeason = 0;
        }
        
        seasonCounter = nextSeason;
        currentSeason = getSeasonAt(seasonCounter);
    }
    
    /**
     * Selects random status effects to affect the day, 
     * based on chances provided by the current season.
     * Chances are based on the weather data HashMap.
     */
    private void selectRandomDayStatus()
    {
        clearStatus();
        HashMap<String, String> currentWeatherData = weatherData.get(currentSeason);
        
        for (HashMap.Entry<String, String> entry : currentWeatherData.entrySet()) {
            String statusName = entry.getKey();
            String statusChance = entry.getValue();
            double chanceDouble = Double.parseDouble(statusChance);
            
            if (rand.nextDouble() <= chanceDouble) {
                weatherStatus.add(statusName);
            }
        }
    }
    
    /**
     * This is the method hooked to the TimeOfDay class,
     * in which the body is ran every simulation hour.
     * Currently the code selects random weather status
     * every 5 hours.
     * 
     * @param newHour current hour.
     */
    public void hourChanged(int newHour)
    {
        if (newHour % 5 == 0) {
            selectRandomDayStatus();
        }
    }
    
    /**
     * This is the method hooked to the TimeOfDay class,
     * in which the body is ran every simulation day change.
     * Currently the code selects rotates between seasons
     * every 5 days.
     * 
     * @param newDay current day.
     */
    public void dayChanged(int newDay)
    {
        if (newDay % 5 == 0) {
            rotateSeason();
        }
    }
    
    /**
     * Compiles all relevant weather data together into
     * a concise string.
     * @return String consisting of season and status weather data.
     */
    public String getWeatherData()
    {
        return String.format(" [Season: %s] [Status: %s]", getCurrentSeason(), getStatusAsString());
    }
}
