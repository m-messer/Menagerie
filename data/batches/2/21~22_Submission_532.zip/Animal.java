import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.02.28 
 */
public abstract class Animal extends Entity
{
    // An enum field for the gender of an animal.
    private Gender gender;
    
    // Randomizer.
    private static final Random rand = Randomizer.getRandom();

    // An enum with 2 gender values.
    protected enum Gender
    {
        MALE,
        FEMALE
    };

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time Field's time
     */
    public Animal(Field field, Location location, TimeOfDay time)
    {
        super(field,location,time);
        gender = Animal.getRandomGender(); // Pick a random gender for each animal.
        
        // Decide whether the animal will be spawned as infected or not.
        if (rand.nextDouble() <= infectionSpawnRate) {
            infected = true;
        }
    }

    /**
     * Return the animal's gender.
     * @return The animal's gender.
     */
    protected Gender getGender()
    {
        return gender;
    }

    /**
     * Return a random gender.
     * @return random gender
     */
    protected static Gender getRandomGender()
    {
        if(rand.nextBoolean()) return Gender.FEMALE;
        else return Gender.MALE;
    }

    /**
     * Check whether the given animal has the same gender compared to this animal.
     * @param  animal  the animal we want to compare our animal with.
     * @return true if they are the opposite gender, false if they are not.
     */
    protected Boolean isOppositeGender(Animal animal)
    {
        if(animal.getGender() != this.getGender()) return true;
        else return false;
    }

    /**
     * Night time behaviour of an animal, the default behaviour is sleeping (aka doing nothing) but subclasses can override it.
     */
    protected void nightTimeBehaviour()
    {
        if(getTime().isNight()) // Check if it is night.
        { 
            // if night then do nothing
        }
    }

    /**
     * If an animal is infected, decide whether they will also infect animals beside them or not.
     * @param  newLocation  adjacent locations to check for animals
     */
    protected void spreadInfection(Location newLocation)
    {
        if (infected == true) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(newLocation);
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Animal) {
                    Animal currentAnimal = (Animal) animal;
                    if (rand.nextDouble() <= infectionRate) {
                        currentAnimal.setInfected(true);
                    }
                }
            }

            if (rand.nextDouble() <= infectionDeathRate) {
                setDead();
            }
        }
    }

    /**
     * An animal's default morning behaviour (give birth, search for food, move and try to infect other animals
     * if you are infected)
     * 
     * @param  newAnimals  the list to contain all the newly born animals.
     */
    protected void morningBehaviour(List<Entity> newAnimals)
    {
        if(!(getTime().isNight())) // Check if it is morning.
        {
            if(isAlive()) {
                if (infected == false) {
                    giveBirth(newAnimals); 
                } 
                // Try to move into a free location.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                
                if(newLocation != null) {
                    setLocation(newLocation);
                    spreadInfection(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                    return;
                }
            } 
        }
    }
    
    /**
     * All of the actions an animal will take regardless of time + their night/morning behaviours.
     * This is the method that gets called for making animals act.
     * 
     * @param  newAnimals  the list to contain all the newly born animals.
     */
    public void act(List<Entity> newAnimals)
    {
        incrementAge();
        nightTimeBehaviour();
        morningBehaviour(newAnimals);
        
        // if it is harsh weather then there is a chance of death
        if (getWeather().hasStatus("harsh")) {
            double deathRate = 0.05;
            if (rand.nextDouble() <= deathRate) {
                setDead();
            }
        }
    }
    
    /**
     * Increment the animal's age.
     */
    abstract protected void incrementAge();
    
    /**
     * Increment the animal's hunger level.
     */
    abstract protected void incrementHunger();
    
    /**
     * Method for finding food.
     * 
     * @return the location where food is found or null if it isn't found.
     */
    abstract protected Location findFood();
}
