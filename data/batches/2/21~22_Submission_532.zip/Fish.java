import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Fish.
 * Fish age, move, breed, and die.
 *
 * @version 2022.02.28 
 */
public class Fish extends Prey
{
    // Characteristics shared by all Fish (class variables).

    // The "age" at which a Fish can start to breed.
    private static final int BREEDING_AGE = 5;
    // The "age" to which a Fish can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a Fish breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Food value of a fish
    private static final int FOOD_VALUE = 9;
    // Max value of food level for a fish.
    private static final int MAX_FOOD_LEVEL = 10;
    
    // Individual characteristics (instance fields).
    
    // The Fish's "age".
    private int age;
    // The Fish's food level.
    private int foodLevel;

    /**
     * Create a new Fish. A Fish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Fish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time The time of the field.
     */
    public Fish(boolean randomAge, Field field, Location location, TimeOfDay time)
    {
        super(field, location, time);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(Plant.getFoodValue());
        }
        else {
            age = 0;
            foodLevel = Plant.getFoodValue();
        }
    }

    /**
     * Increase the "age" (every step increases the "age" by one hence the quotation marks).
     * This could result in the Fish's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Fish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFish A list to return newly born Fish.
     */
    protected void giveBirth(List<Entity> newFish)
    {
        // New Fishs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        TimeOfDay time = getTime();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fish young = new Fish(false, field, loc, time);
            newFish.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Fish can breed if it has reached the breeding age and if there are any other Fish of the opposite genders nearby.
     * @return true if the Fish can breed      
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        if(age >= BREEDING_AGE)
        {
            while(it.hasNext()) 
            {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Fish && this.isOppositeGender((Fish)animal)) // Check if there are any opposite gendered fish around
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Look for Plants adjacent to the current location.
     * Only the first live Plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        
        // Check if there are any nearby Plants, move towards them (by returning their location)
        // and eat them if there are any, return null if there are none.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant Plant = (Plant) animal;
                if(Plant.isAlive())
                { 
                    Plant.setDead(); // Set the eaten Plant dead and add it's food value to Fish's food level.
                    foodLevel = foodLevel + Plant.getFoodValue();
                    if (foodLevel > MAX_FOOD_LEVEL) 
                    {
                        foodLevel = MAX_FOOD_LEVEL;
                    }
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Make this Fish more hungry. This could result in the Fish's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Return the food value of a Fish.
     * @return the food value of a Fish.
     */
    public static int getFoodValue()
    {
        return FOOD_VALUE;
    }
}
