import java.util.List;

/**
 * A simple model of a Hippo.
 * Rabbits age, move, breed, and die.
 *
 * @version 2021.02.16 (3)
 */
public class Hippo extends Prey
{
    // Characteristics shared by all Hippos (class variables).
    
    private static final int BREEDING_AGE = 6;                 // The age at which a hippo can start to breed.

    private static final int MAX_AGE = 12;                     // The age to which a hippo can live.
    
    private static final double BREEDING_PROBABILITY = 0.6;    // The likelihood of a hippo breeding.
    
    private static final int MAX_LITTER_SIZE = 3;              // The maximum number of births.
    
    private static final int startSleep = 23;                  // The time at which a hippo starts sleeping.
    
    private static final int endSleep = 2;                     // The time at which a hippo stops sleeping.
    
    private int age;                                           // The age of the hippo.

    /**
     * Create a new hippo. A hippo may be created with age
     * zero (a new born) or with a random age. Hippo's gender is
     * always random. There is also a chance for the hippo to have disease. 
     * New born hippos will not have disease.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the deer.
     * @param hasDisease Whether the hippo has a disease.
     */
    public Hippo(boolean randomAge, Field field, Location location, String gender, boolean hasDisease)
    {
        super(field, location, gender, hasDisease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * Increase the age.
     * This could result in the hippo's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this hippo is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHippos A list to return newly born hippos.
     */
    protected void giveBirth(List<Species> newHippos)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hippo young = new Hippo(false, field, loc, randomizer.randomGender(), false);
            newHippos.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && randomizer.checkProbability(BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A female hippo can breed if it has reached the breeding age, 
     * and there is at least one male hippo near by.
     * @return Return true if the above conditions is satisifed, false otherwise.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Animal> animals = field.getAdjecentAnimals(getLocation());
        
        if (age >= BREEDING_AGE && getGender().equals("female")) {
            for (Animal next: animals) {
                if (next.getGender().equals("male") && next instanceof Hippo) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Checks whether the hippo is sleeping or not.
     * @return Return true if current time is between hippo's sleeping time, 
     * false otherwise.
     */
    protected boolean isSleeping()
    {
        return getTime().checkTimeIsBetween(startSleep, endSleep);
    }
}