import java.util.List;

/**
 * A simple model of a tiger.
 * Tigers age, move, eat rabbits or elephants, and die.
 *
 * @version 2021.02.16 (3)
 */
public class Tiger extends Predator
{
    // Characteristics shared by all tigers (class variables).
    
    private static final int BREEDING_AGE = 5;               // The age at which a tiger can start to breed.

    private static final int MAX_AGE = 14;                   // The age to which a tiger can live.
    
    private static final double BREEDING_PROBABILITY = 0.65;   // The likelihood of a tiger breeding.
    
    private static final int MAX_LITTER_SIZE = 2;             // The maximum number of births.

    private static final int startSleep = 17;                // The time when the tigers start to sleep.

    private static final int endSleep = 20;                    // The time when the tigers stops sleeping.
    
    private int age;
    
    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level. Tiger's gender is
     * always random. There is also a chance for the tiger to have disease. 
     * New born tigers will not have disease.
     * 
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the tiger, can be either male or female.
     * @param hasDisease Whether the tiger has a disease.
     */
    public Tiger(boolean randomAge, Field field, Location location, String gender, boolean hasDisease)
    {
        super(field, location, gender, hasDisease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * Increase the age. This could result in the tiger's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
   
    /**
     * Check whether or not this tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTigers A list to return newly born tigers.
     */
    protected void giveBirth(List<Species> newTigers)
    {
        // Get a list of adjacent free locations.
        // New tigers are born into adjacent locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());   
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);                                     
            Tiger young = new Tiger(false, field, loc, randomizer.randomGender(), false);
            newTigers.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && randomizer.checkProbability(BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A female tiger can breed if it has reached the breeding age, 
     * and there is at least one male tiger near by.
     * @return Return true if the above conditions is satisifed, false otherwise.
     * 
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Animal> animals = field.getAdjecentAnimals(getLocation());
        
        if (age >= BREEDING_AGE && getGender().equals("female")) {
            for (Animal next: animals) {
                if (next.getGender().equals("male") && next instanceof Tiger) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Checks whether the tiger is sleeping or not.
     * @return Return true if current time is between tiger's sleeping time, 
     * false otherwise.
     */
    protected boolean isSleeping()
    {
        return getTime().checkTimeIsBetween(startSleep, endSleep);
    }
}
