import java.util.List;
import java.util.Iterator;

/**
 * An abstract predator class that extends from Animal class.
 * Predators are able to hunt other animals like deers and elephants.
 *
 * @version 2021.02.16 (3)
 */
public abstract class Predator extends Animal
{

    private static final int DEER_FOOD_VALUE = 10;                // The food value of a deer.

    private static final int ELEPHANT_FOOD_VALUE = 15;            // The food value of a elephant.

    private static final double FOG_FIND_FOOD_PROBABILITY = 0.9; // The probability of finding food when the weather is fog.

    private double STANDARD_FIND_FOOD_PROBABILITY = 0.98;                           // The probability of predators finding food.

    /** 
     * Create a new predator at a location in a field with gender and disease values.
     * Predators are less likely to find food when
     * the weather is fog.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the tiger, can be either male or female.
     * @param hasDisease Whether the tiger has a disease.
     */
    public Predator(Field field, Location location, String gender, boolean hasDisease)
    {
        super(field, location, gender, hasDisease);
    }

    /**
     * Checks if the weather is fog. If yes, find food probability will be changed.
     */
    private double checkWeather()
    {
        double probability = 0;
        
        if (getWeather().getCurrentWeather().equals("fog")) {
            return probability = FOG_FIND_FOOD_PROBABILITY;
        }else {
            return probability = STANDARD_FIND_FOOD_PROBABILITY;
        }
    }

    /**
     * Preators eat the animals, if they are either deer or elephant.
     * @return Return the locaions of the animals being eaten.
     * @param animal The animal to be eaten.
     * @param location The location of the animal to be eaten.
     */
    private Location eatFood(Object animal, Location where)
    {
        if(animal instanceof Deer) {
            Deer deer = (Deer) animal;
            if(deer.isAlive()) { 
                deer.setDead();
                setFoodLevel(DEER_FOOD_VALUE);
                return where;
            }
        }
        else if(animal instanceof Elephant) {
            Elephant elephant = (Elephant) animal;
            if(elephant.isAlive()) { 
                elephant.setDead();
                setFoodLevel(ELEPHANT_FOOD_VALUE);
                return where;
            }
        }
        return null;
    }
    
    /**
     * Look for deers adjacent to the current location.
     * Only the first live deer or elephant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        if (randomizer.checkProbability(checkWeather())) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                return eatFood(animal, where);
            }
        }
        return null;
    }
}
