import java.util.List;
import java.util.ArrayList;

/**
 * A simple model of a plant.
 * Plants can grow, reproduce, but can not move. 
 * Plants can be eaten by animals like deer, elephants, and hippo.
 *
 * @version 2021.02.16 (3)
 */
public class Plant extends Species
{
    // Characteristics shared by all plants (class variables).
    
    private static final int BREEDING_AGE = 5;                          // The age at which a plant can start to reproduce.

    private static final int MAX_AGE = 10;                              // The age to which a plant can live.

    private static final double BREEDING_PROBABILITY = 0.25;            // The likelihood of a plant reproducing.

    private static final double NIGHT_BREEDING_PROBABILITY = 0.15;       // The likelihood of a plant reproducing at night.
 
    private static final double RAIN_BREEDING_PROBABILITY_FACTOR = 1.1; // The likelihood of a plant reproducing when the weather is rain.

    private static final int MAX_LITTER_SIZE = 4;                       // The maximum number of births.
    
    private double probability;                                         // A variable stroing probability which varies according to the current conditions.
    
    private int age;                                                    // The age of the deer.

    /**
     * Create a new plant. A plant is created with a location, and a field.
     * Plant's are created with age at 0. Plants have differet growth rates
     * accodring to the environment.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field,location);
        age = 0;
        probability = growthRate();
    }

    /**
     * This is what the Plant does most of the time: reproduction.
     * In the process, it might die of old age, or get eaten by other
     * animals.
     * @param newPlants A list to return newly reproduced plantss.
     */
    public void act(List<Species> newPlants)
    {
        incrementAge();
        if (isAlive()) {  
            probability = growthRate();
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Plant young = new Plant(field, loc);
                newPlants.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(randomizer.checkProbability(probability)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Increase the age.
     * This could result in the plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Checks the current time and weather. Breeding probability will change
     * if it is at night or raining.
     * @return Return the changed breeding probability in accordance to the current environment. 
     */
    private double growthRate()
    {
        if (getTime().checkTimeIsBetween(3, 10)) {
            probability = BREEDING_PROBABILITY;
        }
        else {
            probability = NIGHT_BREEDING_PROBABILITY;
        }

        if (getWeather().getCurrentWeather().equals("rain")) {
            probability = probability * RAIN_BREEDING_PROBABILITY_FACTOR;
        }

        return probability;
    }
}
