import java.util.HashMap;
import java.util.Random;
import java.util.Map;

/**
 * Model the weather. There are in total 5 different 
 * weathers: fog, rain, clear, overcast, snow.
 * Occurrence of all weathers have the same probability.
 *
 * @version 2021.02.16 (3)
 */
public class Weather
{
    
    private HashMap<String,Integer> weather;    // Stores the weathers and also a value for the probability.
    
    private String currentWeather;              // Stores the current weather.

    /**
     * Create a weather. Has in total 5 different weathers.
     * Occurrence of each weather has the same probability.
     */
    Weather()
    {
        weather = new HashMap<>();
        currentWeather = "";
        weather.put("Fog",0);
        weather.put("Rain",1);
        weather.put("Clear",2);
        weather.put("Overcast",3);
        weather.put("Snow",4);
    }

    /**
     * @return Return a random weather as a string.
     */
    public String getRandomWeather()
    {
        Random rand = new Random();
        int random = rand.nextInt(4);
        String randomWeather = "";
        
        for (Map.Entry<String, Integer> prob : weather.entrySet()) { 
            if (prob.getValue() == random) {
                randomWeather = prob.getKey();
            }
        }
        
        currentWeather = randomWeather;
        
        return randomWeather;
    }
    
    /**
     * @return Return the current weather.
     */
    public String getCurrentWeather()
    {
        return currentWeather;
    }
}
