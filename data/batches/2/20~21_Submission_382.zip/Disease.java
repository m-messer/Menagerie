import java.util.List;
import java.util.Random;

/**
 * A class representing disease. Disease may spread among animals.
 * Aniamls with the disease die earlier.
 *
 * @version 2021.02.16 (3)
 */
public class Disease
{

    private static final double diseaseSpreadProbability = 0.02; // The likelihood of getting the disease from other animals.
    
    private static final int diseaseIncreaseAge = 2; // The disease increases the age. Therefore animals die earlier.

    public Disease()
    {  
    }

    /**
     * This controls how the disease acts. 
     * Surrounding animals are checked to see whether they have the disease.
     * There is then a random chance that an animal gets the disease.
     */
    public void spreadDisease(Species species)
    {
        Randomizer randomizer = new Randomizer();
        if (species.isAlive() && species instanceof Animal){
            Animal animal = (Animal) species;
            Field field = animal.getField();
            List<Animal> animals = field.getAdjecentAnimals(animal.getLocation());
            if (!animal.getDisease()) {
                for (Animal next: animals) {
                    if (next.getDisease() && randomizer.checkProbability(diseaseSpreadProbability)) {
                        animal.setDisease(true);
                        influenceAge(animal);       // Age gets increased when animal gets the disease.
                        return;
                    }
                }
            }
        }
    }

    /**
     * Increase the animal's age by the diseaseIncreaseAge value.
     */
    private void influenceAge(Animal animal)
    {
        for (int i = 0; i < diseaseIncreaseAge; i++) {
            animal.incrementAge();
        }
    }
}
