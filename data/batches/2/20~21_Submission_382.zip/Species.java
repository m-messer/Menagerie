import java.util.Random;
import java.util.List;

/**
 * A class representing shared characteristics of all species.
 *
 * @version 2021.02.16 (3)
 */
public abstract class Species
{
    
    private boolean alive;       // Indicates whether the species is still alive.

    private Field field;         // The field that the species lives on.
    
    private Location location;   // The locaiton of the species.

    private TimeOfDay time;    // The current time, species exhibit different behaviour at some time of the day.

    private Weather weather;   // The current weather, species exhibit different behaviour during different weather.

    protected static final Random rand = Randomizer.getRandom();   // The radnomizer generates random values for gender and weather.
    
    protected static final Randomizer randomizer = new Randomizer(); // A random number generator.
    
    /** 
     * Create a new species at a location in a field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Species(Field field, Location location)
    {
        this.field = field;
        this.location = location;
        this.field = field;
        alive = true;
        setLocation(location);
        time = field.getTime();
        weather = field.getWeather();
    }
    
    /**
     * Check whether the species is alive or not.
     * @return true if the species is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the species is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * @return The species's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the species at the new location in the given field.
     * @param newLocation The species's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * @return The species's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * @return The time of day.
     */
    protected TimeOfDay getTime()
    {
        return time;
    }

    /**
     * @return The weather.
     */
    protected Weather getWeather()
    {
        return weather;
    }
    
    /**
     * Make this species act - that is: make it do
     * whatever it wants/needs to do.
     * @param newSpeciess A list to receive newly born species.
     */
    abstract public void act(List<Species> newSpecies);
}
