import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing lions, tigers, deers, hippos, and elephants.
 *
 * @version 2021.02.16 (3)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.

    private static final int DEFAULT_WIDTH = 120;                           // The default width for the grid.

    private static final int DEFAULT_DEPTH = 80;                           // The default depth of the grid.

    private static final double LION_CREATION_PROBABILITY = 0.09;           // The probability that a lion will be created in any given grid position.

    private static final double DEER_CREATION_PROBABILITY = 0.155;           // The probability that a deer will be created in any given grid position.

    private static final double HIPPO_CREATION_PROBABILITY = 0.115;         // The probability that a hippo will be created in any given grid position.

    private static final double ELEPHANT_CREATION_PROBABILITY = 0.13;      // The probability that a elephant will be created in any given grid position.

    private static final double TIGER_CREATION_PROBABILITY = 0.11;         // The probability that a tiger will be created in any given grid position.

    private static final double PLANT_CREATION_PROBABILITY = 0.5;           // The probability that a plant will be created in any given grid position.

    private static final double DISEASE_CREATION_PROBABILITY = 0.01;        // The probability that an animal with disease will be created in give field.

    private List<Species> species;   // List of animals in the field.

    private Field field;             // The current state of the field.

    private int step;                // The current step of the simulation.

    private SimulatorView view;      // A graphical view of the simulation.

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        species = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        // Set color to represent each animals.
        view.setColor(Deer.class, Color.ORANGE);
        view.setColor(Lion.class, Color.BLUE);
        view.setColor(Elephant.class, Color.PINK);
        view.setColor(Hippo.class, Color.BLACK);
        view.setColor(Tiger.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(30);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animals.
     */
    public void simulateOneStep()
    {
        field.getTime().incrementHalfAnHour();    // One step equals to 30 minutes.
        changeWeather();                          // Randomly changes the weather.

        step++;

        List<Species> newSpecies = new ArrayList<>();     // Provide space for newborn animals.       
        // Let all animals act.
        for(Iterator<Species> it = species.iterator(); it.hasNext(); ) {
            Species species = it.next();
            species.act(newSpecies);
            field.getDisease().spreadDisease(species);
            if(!species.isAlive()) {
                it.remove();
            }
        }

        species.addAll(newSpecies);     // Add the newly born foxes and rabbits to the main lists.

        view.showStatus(step, field);
    }

    /**
     * Every 60 steps the weather is randomly changed.
     */
    private void changeWeather()
    {
        if (step % 60 == 0) {
            field.getWeather().getRandomWeather();
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        species.clear();
        populate();
        field.getTime().reset();
        view.showStatus(step, field);     // Show the starting state in the view.
    }

    /**
     * Randomly populate the field with different animals.
     */
    private void populate()
    {
        Randomizer rand = new Randomizer();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {     
                String gender = rand.randomGender();
                boolean hasDisease = rand.checkProbability(DISEASE_CREATION_PROBABILITY);

                Location location = new Location(row, col);

                if(rand.checkProbability(LION_CREATION_PROBABILITY)) {
                    Lion lion = new Lion(true, field, location, gender, hasDisease);
                    species.add(lion);
                }
                else if(rand.checkProbability(TIGER_CREATION_PROBABILITY)) {  
                    Tiger tiger = new Tiger(true, field, location, gender, hasDisease);
                    species.add(tiger);
                }
                else if(rand.checkProbability(HIPPO_CREATION_PROBABILITY)) {
                    Hippo hippo = new Hippo(true, field, location, gender, hasDisease);
                    species.add(hippo);
                }
                else if(rand.checkProbability(ELEPHANT_CREATION_PROBABILITY)) {
                    Elephant elephant = new Elephant(true, field, location, gender, hasDisease);
                    species.add(elephant);
                }
                else if(rand.checkProbability(DEER_CREATION_PROBABILITY)) {
                    Deer deer = new Deer(true, field, location, gender, hasDisease);
                    species.add(deer);
                }
                else if(rand.checkProbability(PLANT_CREATION_PROBABILITY)) {
                    Plant plant = new Plant(field, location);
                    species.add(plant);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
