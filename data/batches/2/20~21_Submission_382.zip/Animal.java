import java.util.List;
import java.util.Random;
import java.util.LinkedList;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.02.16 (3)
 */
public abstract class Animal extends Species
{

    private String gender; // The gender of the animal (male or female).

    private boolean isSleeping; // Whether the animal is sleeping or not.

    private int foodLevel; // The animal's food level, which is increased by eating.

    private boolean hasDisease; // Whether the animal has a disease.

    /**
     * Create a new animal at location in field with gender and disease values.
     * An animal is assigned a random food level.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the animal.
     * @param hasDisease Whether the animal has a disease.
     */
    public Animal(Field field, Location location, String gender, boolean hasDisease) 
    {
        super(field, location);
        this.gender = gender;
        this.hasDisease = hasDisease;  
        isSleeping = false; 
        foodLevel = randomizer.randomFoodLevel();
    }

    /**
     * This is what the animal does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newSpecies A list to return newly born species.
     */
    public void act(List<Species> newSpecies)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive() && !isSleeping()) {
            giveBirth(newSpecies);            
            Location newLocation = findFood();     // Move towards a source of food if found.
            if(newLocation == null) { 
                newLocation = getField().freeAdjacentLocation(getLocation());     // No food found - try to move to a free location.
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else if (getField().checkAdjecentPlants(getLocation())){
                overtakePlantLocation();   // Overtake plants location if surrounded by plants.
            } 
            else{
                setDead();     // Overcrowding.
            }
        }
    }
    
    /**
     * Animal overtakes plants' location.  
     */
    private void overtakePlantLocation()
    {
        List<Plant> adjecentPlants = new LinkedList<>();
        adjecentPlants = getField().getAdjecentPlants(getLocation());
        
        getField().clear(adjecentPlants.get(0).getLocation()); 
        setLocation(adjecentPlants.get(0).getLocation());
    }
    
    /** 
     * This returns the gender of the animal.
     * @return the gender of the animal.
     */
    protected String getGender()
    { 
        return gender;
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * This returns whether the animal has a disease or not.
     * @return whether the animal has a disease.
     */
    public boolean getDisease()
    {
        return hasDisease;   
    }

    /**
     * Set the disease to the given parameter.
     */
    public void setDisease(boolean disease)
    {
        hasDisease = disease;
    }

    /**
     * Set the food level to the given parameter.
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }
    
    /**
     * This will increase the age of the animal.
     * Could result in an animal's death.
     */
    abstract protected void incrementAge();

    /**
     * This will return whether the animal is sleeping or not.
     * @return whether the animal is sleeoing or not.
     */
    abstract protected boolean isSleeping();

    /**
     * This will check whether an animal can give birth.
     * It will then create a new animal if the conditions are met.
     * @param species A list to return newly born species.
     */
    abstract protected void giveBirth(List<Species> Species);

    /**
     * This allows animals to find and eat food.
     * It checks for the animal's required food and then allows for it to be eaten.
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood();
}