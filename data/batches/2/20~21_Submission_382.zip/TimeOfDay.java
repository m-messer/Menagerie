
/**
 * The TimeOfDay class implements a digital clock display for a
 * 24 hour clock. 
 * 
 * The time is incremented simply by incrementing a minute.
 *
 * @version 2021.02.16
 */
public class TimeOfDay
{
    private int hours; // The hour of the day.
    private int minutes; // The minute of the hour.
    private int days; // The days passed.

    /**
     * When TimeOfDay is created it is set to 00:00
     */
    public TimeOfDay()
    {
        hours = 0;
        minutes = 0;
        days = 0;
    }

    /**
     * Increments the hour by 1.
     * Resets the hours back to 0 once hours has reached 24.
     */
    private void incrementHour() 
    {
        hours++;
        if (hours == 24) {
            hours = 0;
            incrementDay();
        }
    }

    /**
     * Increments the minute by 1.
     * Resets the minutes back to 0 once minutes has reached 60.
     * Increments hour by one when the minutes reach 60.
     */
    private void incrementMinute() 
    {
        minutes++;
        if (minutes == 60) {
            minutes = 0;
            incrementHour();
        }
    }

    /**
     * Increments the day by 1.
     */
    private void incrementDay()
    {
        days++;
    }

    /**
     * Increments the minute by 30 minutes.
     */
    public void incrementHalfAnHour()
    {
        for (int i = 0; i < 30;i++) {
            incrementMinute();
        }
    }

    /**
     * This allows for a specific time to be set.
     */
    public void setTime(int hour, int minute)
    {
        hours = hour;
        minutes = minute;
    }

    /**
     * Returns the hours.
     * @return hour of the day.
     */
    private int returnHour() 
    {
        return hours;
    }

    /**
     * Returns the minutes.
     * @return the minutes of the hour.
     */
    private int returnMinute() 
    {
        return minutes;
    }

    /**
     * This checks to see if the current time is between two given hours.
     * @param start The beginning of the range of time to check from.
     * @param end The end of the range of time to check until.
     * @return true if the time is between the range, false otherwise.
     */
    public boolean checkTimeIsBetween(int start, int end)
    {
        if (start < end) {
            if (start <= returnHour() && end > returnHour()){
                return true;
            }
        }else if (end < start) {
            if (start <= returnHour() || end > returnHour()) {
                return true;
            }
        }
        return false;
    }

    /**
     * This returns the current time as a string is 24 hour format.
     * @return a string of the current time.
     */
    public String getCurrentTime()
    {
        String time = "";

        if(hours < 10) {
            time = "0" + hours;
        }
        else {
            time = "" + hours;
        } 

        time = time + ":";

        if(minutes < 10) {
            time = time + "0" + minutes;
        }
        else {
            time = time + minutes;
        } 
        
        time = time + "   Days: " + days;

        return time;
    }

    /**
     * This resets the clock back to 00:00.
     */
    public void reset()
    {
        hours = 0;
        minutes = 0;
    }
}
