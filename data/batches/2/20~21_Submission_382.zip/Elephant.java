import java.util.List;

/**
 * A simple model of a Elephant.
 * Elephants age, move, breed, eat plants and die.
 *
 * @version 2021.02.16 (3)
 */
public class Elephant extends Prey
{
    // Characteristics shared by all elephants (class variables).
    
    private static final int BREEDING_AGE = 4; // The age at which an elephant can start to breed.

    private static final int MAX_AGE = 16;   // The age to which an elephant can live.

    private static final double BREEDING_PROBABILITY = 0.75; // The likelihood of an elephant breeding.

    private static final int MAX_LITTER_SIZE = 3; // The maximum number of births.

    private static final int startSleep = 23;  // The time at which an elephant starts to sleep.
    
    private static final int endSleep = 1;  // The time at which an elephant stops sleeping.
    
    private int age;   // The age of the elephant.

    /**
     * Create a new elephant. An elephant can be created as a new born (age zero
     * and not hungry) or with a random age. Elephant's gender is
     * always random. There is also a chance for the elephant to have disease. 
     * New born elephants will not have disease.
     * 
     * @param randomAge If true, the elephant will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the elephant, can be either male or female.
     * @param hasDisease Whether the elephant has a disease.
     */
    public Elephant(boolean randomAge, Field field, Location location, String gender, boolean hasDisease)
    {
        super(field, location, gender, hasDisease);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * Increase the age.
     * This could result in the elephant's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this elephant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newElephants A list to return newly born elephants.
     */
    protected void giveBirth(List<Species> newElephants)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Elephant young = new Elephant(false, field, loc, randomizer.randomGender(), false);
            newElephants.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && randomizer.checkProbability(BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An elephant can breed if it has reached the breeding age and can only occur if a female meets a male.
     * @return true if the elephant can breed, false otherwise.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Animal> animals = field.getAdjecentAnimals(getLocation());
        
        if (age >= BREEDING_AGE && getGender().equals("female")) {
            for (Animal next: animals) {
                if (next.getGender().equals("male") && next instanceof Elephant) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /** 
     * Checks to see if the elephant is sleeping.
     * @return true if the elephant is sleeping, false otherwise.
     */
    protected boolean isSleeping()
    {
        return getTime().checkTimeIsBetween(startSleep, endSleep);
    }
}

