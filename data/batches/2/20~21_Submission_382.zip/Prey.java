import java.util.List;
import java.util.Iterator;

/** 
 * An abstract prey class that extends from the Animal class.
 * Prey are animals that are hunted, like deers and hippos. 
 * All prey eat plants.
 *
 * @version 2021.02.16 (3)
 */

public abstract class Prey extends Animal
{
    private static final int PLANT_FOOD_VALUE = 20;         // The food value of a single plant. 
    
    /**
     * Create a new prey at a location in a field with gender and disease values.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the prey.
     * @param hasDisease Whether the prey has a disease.
     */
    public Prey(Field field, Location location, String gender, boolean hasDisease)
    {
        super(field, location, gender, hasDisease);
    }
    
    /**
     * Look only for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant) {
                Plant plant1 = (Plant) plant;
                if(plant1.isAlive()) { 
                    plant1.setDead();
                    setFoodLevel(PLANT_FOOD_VALUE);
                    return where;
                } 
            }
        }
        return null;
    }
}
    



