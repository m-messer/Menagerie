import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * An abstract class representing shared characteristics of prey.
 * Prey age, move, eat plants, breed, and die.
 *
 * @version 2019.02.21
 */
public abstract class Prey extends Animal
{ 
    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = getRandom().nextInt(getMaxAge());
            foodLevel = getRandom().nextInt(9);
        }
        else {
            age = 0;
            foodLevel = 5;
        }
    }
    
    /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born prey.
     */
    @Override
    public void act(List<Animal> newPrey)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            super.giveBirth(newPrey);
            // Try to move into a free location.
            Location newLocation = findPlants();    // Move towards a source of plant if found
            if(newLocation == null) {   // No plants found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {   // See if it was possible to move.
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age. This could result in the prey's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Make this prey more hungry. This could result in the prey's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * It will eat the first plant it finds and move to its location.
     * @return Where plant was found or null if it wasn't.
     */
    public Location findPlants()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Plant) {
                Plant plant = (Plant) obj;
                if(plant.isAlive()) {   // If a plant was found, eat it.
                    plant.setDead();
                    foodLevel = 9;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Return the maximum possible age of the prey.
     * @return the maximum possible age of the prey.
     */
    abstract public int getMaxAge();
    
    /**
     * Returns the randomizer.
     * @return randomizer.
     */
    abstract public Random getRandom();
    
    /**
     * Return the probability that the species breeds.
     * @return the probability that the species breeds.
     */
    abstract public double getBreedProb();
    
    /**
     * Return the maximum number of possible births for that species.
     * @return the maximum number of possible births for that species.
     */
    abstract public int getMaxLitterSize();
    
    /**
     * Return the age of the animal.
     * @return the age of the animal.
     */
    abstract public int getAge();
    
    /**
     * Return the minimum breeding age for the species.
     * @return the minimum breeding age for the species.
     */
    abstract public int getBreedAge();
    
    /**
     * Return the time that the animal acts.
     * @return true if the species is a day animmal.
     */
    abstract public boolean dayAnimal();
    
    /**
     * Return the gender of the animal.
     * @return true if the animal is female.
     */
    abstract public boolean getIsFemale();
    
    /**
     * Return the food value of this prey species.
     * @return the food value of this prey species.
     */
    abstract public int getFoodValue();
}
