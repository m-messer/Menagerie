import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * An abstract class representing shared characteristics of predators.
 * Prey age, hunt, move, breed, and die.
 *
 * @version 2019.02.21
 */
public abstract class Predator extends Animal
{
    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
        {
        super(field, location);
        if(randomAge) {
            age = getRandom().nextInt(getMaxAge());
            foodLevel = getRandom().nextInt(50);
        }
        else {
            age = 0;
            foodLevel = 20;
        }
     }
     
    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newPredators A list to return newly born predators.
     */
    @Override
    public void act(List<Animal> newPredators)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            super.giveBirth(newPredators);
            
            Location newLocation = findFood();  // Move towards a source of food if found.
            if(newLocation == null) {   // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {   // See if it was possible to move.
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age. This could result in the predator's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Make this predator more hungry. This could result in the predator's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for prey/plants adjacent to the current location.
     * If it finds a prey it will eat it and if it is 
     * a plant it will trample it.
     * @return Where food or plant was found or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(isPrey(obj)) {
                Animal prey = (Animal) obj;
                if(prey.isAlive()) {    // If prey is found, eat it.
                    prey.setDead();
                    foodLevel = prey.getFoodValue();
                    return where;
                }
            }
            else if (obj instanceof Plant) {    // If a plant was found, trample it.
                Plant plant = (Plant) obj;
                plant.setDead();
                return where;
            }
        }
        return null;
    }
    
    /**
     * Return the maximum possible age of the species.
     * @return the maximum possible age of the species.
     */
    abstract public int getMaxAge();
    
    /**
     * Checks if an animal is the predators prey.
     * @param animal The animal to be checked.
     */
    abstract public boolean isPrey(Object animal);
    
    /**
     * Returns the randomizer.
     * @return randomizer.
     */
    abstract public Random getRandom();
    
    /**
     * Return the probability that the species breeds.
     * @return the probability that the species breeds.
     */
    abstract public double getBreedProb();
    
    /**
     * Return the maximum number of possible births for that species.
     * @return the maximum number of possible births for that species.
     */
    abstract public int getMaxLitterSize();
    
    /**
     * Return the age of the animal.
     * @return the age of the animal.
     */
    abstract public int getAge();
    
    /**
     * Return the minimum breeding age for the species.
     * @return the minimum breeding age for the species.
     */
    abstract public int getBreedAge();
    
    /**
     * Return the time that the animal acts.
     * @return true if the species is a day animmal.
     */
    abstract public boolean dayAnimal();
    
    /**
     * Return the gender of the animal.
     * @return true if the animal is female.
     */
    abstract public boolean getIsFemale();
}
