import java.util.List;
import java.util.Random;

/**
 * A model of a mouse.
 * Mice age, move, breed, and die.
 *
 * @version 2019.02.21
 */
public class Mouse extends Prey
{
    // The food value that the mouse is worth.
    private static final int FOOD_VALUE = 8;
    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 25;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.33;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The gender of the mouse
    private boolean isFemale;

    /**
     * Create a new mouse with a random gender.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        
        isFemale = rand.nextBoolean();
    }
    
    /**
     * Returns the randomizer.
     * @return randomizer.
     */
    @Override
    public Random getRandom()
    {
        return rand;
    }
    
    /**
     * Return the probability that the mouse breeds.
     * @return the probability that the mouse breeds.
     */
    @Override
    public double getBreedProb()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum number of possible births.
     * @return the maximum number of possible births.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the age of the mouse.
     * @return the age of the mouse.
     */
    @Override
    public int getAge()
    {
        return age;
    }
    
    /**
     * Return the minimum breeding.
     * @return the minimum breeding.
     */
    @Override
    public int getBreedAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Return the maximum possible age.
     * @return the maximum possible age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Return mouse as a nocturnal animal.
     * @return false.
     */
    @Override
    public boolean dayAnimal()
    {
        return false;
    }
    
    /**
     * Return the food value
     * @return the food value
     */
    @Override
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * Return the gender
     * @return true if the mouse is female.
     */
    @Override
    public boolean getIsFemale()
    {
        return isFemale;
    }
}
