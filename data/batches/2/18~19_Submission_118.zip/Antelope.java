import java.util.List;
import java.util.Random;

/**
 * A simple model of an antelope.
 * Antelope age, move, breed, and die.
 *
 * @version 2019.02.21
 */
public class Antelope extends Prey
{
    // Characteristics shared by all antelope (class variables).
    private static final int FOOD_VALUE = 28;
    // The age at which an antelope can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which an antelope can live.
    private static final int MAX_AGE = 60;
    // The likelihood of an antelope breeding.
    private static final double BREEDING_PROBABILITY = 0.43;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Shows if the antelope is infected.
    private boolean isInfected;
    // The antelope's gender.
    private boolean isFemale;
    
    /**
     * Create a new antelope with a random gender.
     * The antelope can be infected.
     * 
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param infected Is the antelope infected.
     */
    public Antelope(boolean randomAge, Field field, Location location, boolean infected)
    {
        super(randomAge, field, location);
        isFemale = rand.nextBoolean();
        isInfected = false;
        if (infected) {
            infectedAntelope();
        }
    }
    
    /**
     * Infect an antelope.
     * As a result, make it live 5 years less.
     */
    private void infectedAntelope()
    {
        age += 5;
        isInfected = true;
    }
    
    /**
     * Infect any neighbouring antelopes.
     */
    protected void infectAntelopes()
    {
        List<Location> adjLocations = getField().adjacentLocations(getLocation());
        List<Location> freeLocations = getField().getFreeAdjacentLocations(getLocation());
        adjLocations.removeAll(freeLocations);
        for (Location location : adjLocations) {
            Object obj = getField().getObjectAt(location);
            if (!(obj instanceof Plant)) {
                Animal animal = (Animal) obj;
                if ((animal instanceof Antelope)) {
                    infectedAntelope();
                }
            }
        }
    }
    
    /**
     * Is the antelope infected.
     * @return true if the antelope is infected.
     */
    public boolean getInfected()
    {
        return isInfected;
    }
    
    /**
     * This is what the Antelope does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born prey.
     */
    @Override
    public void act(List<Animal> newPrey)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPrey);
            infectAntelopes();
            Location newLocation = findPlants();    // Try to move into a free location.
            if(newLocation == null) {   // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            if(newLocation != null) {   // See if it was possible to move.
                setLocation(newLocation);
            }
            else{
                setDead();
            }
        }
    }
    
    /**
     * Returns the randomizer.
     * @return randomizer.
     */
    @Override
    public Random getRandom()
    {
        return rand;
    }
    
    /**
     * Return the probability that the antelope breeds.
     * @return the probability that the antelope breeds.
     */
    @Override
    public double getBreedProb()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum number of possible births.
     * @return the maximum number of possible births.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the age of the antelope.
     * @return the age of the antelope.
     */
    @Override
    public int getAge()
    {
        return age;
    }
    
    /**
     * Return the minimum breeding.
     * @return the minimum breeding.
     */
    @Override
    public int getBreedAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Return the maximum possible age.
     * @return the maximum possible age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Return antelope as a day animal.
     * @return true.
     */
    @Override
    public boolean dayAnimal()
    {
        return true;
    }
    
    /**
     * Return the food value
     * @return the food value
     */
    @Override
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * Return the gender
     * @return true if the antelope is female.
     */
    @Override
    public boolean getIsFemale()
    {
        return isFemale;
    }
}
