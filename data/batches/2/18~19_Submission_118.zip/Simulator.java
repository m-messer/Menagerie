import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A predator-prey simulator, based on a rectangular field
 * containing Antelopes, Leopards, Lions, Mice, Plants, Snakes and Zebras.
 *
 * @version 2019.02.21
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.034;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.09;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.09;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.055;
    // The probability that a leopard will be created in any given grid position.
    private static final double LEOPARD_CREATION_PROBABILITY = 0.036;
    // The probability that a antelope will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.19;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.18;
    // The probability that an antelope is infected at the start.
    private static final double INFECTION_PROBABILITY = 0.05;
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current time in the field (day = true, night = false).
    private boolean time;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        // Give an error message and use the default size if negative values given.
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        time = false;   // Start the simulation at night.
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Lion.class, Color.YELLOW);
        view.setColor(Snake.class, Color.MAGENTA);
        view.setColor(Mouse.class, Color.GRAY);
        view.setColor(Antelope.class, Color.RED);
        view.setColor(Leopard.class, Color.BLUE);
        view.setColor(Plant.class, Color.GREEN);
        
        reset();    // Setup a valid starting point.
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            // Every 20 steps, change the time and weather.
            if (step % 20 == 0) {
                changeTime();
                field.generateWeather();
            }
            simulateOneStep();
            //delay(60);   // Uncomment this to run more slowly.
        }
    }
  
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant
     */
    public void simulateOneStep()
    {
        step++;
        
        List<Animal> newAnimals = new ArrayList<>();    // Provide space for newborn animals.
        // Let animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if (animal.dayAnimal() && time) {   // Let day animals act if its day.
                animal.act(newAnimals);
            }
            else if (!animal.dayAnimal() && !time) {    // Let nocturnal animals act if its night.
                animal.act(newAnimals);
            }
            if(! animal.isAlive()) {    // Remove dead animals from the field.
                it.remove();
            }
        }
        animals.addAll(newAnimals); // Add the newly born animals to the main animals list.
        
        List<Plant> newPlants = new ArrayList<>();  // Provide space for new plants.
        // Let plants breed.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.makeNewPlants(newPlants);
            if(! plant.isAlive()) { // Remove dead plants from the field.
                it.remove();
            }
        }
        
        
        plants.addAll(newPlants);   // Add the new plants to the main plants list
        view.showStatus(step, time, field); // Show the updated simulation
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        view.showStatus(step, time, field); // Show the starting state in the view.
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // for each species, use their creation probability to populate the field.
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope = new Antelope(true, field, location, isInfected());
                    animals.add(antelope);
                }
                else if(rand.nextDouble() <= LEOPARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Leopard leopard = new Leopard(true, field, location);
                    animals.add(leopard);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    plants.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds.
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up.
        }
    }
    
    /**
     * Change the time between day (true) and night (false).
     */
    private void changeTime()
    {
        time = !time;
    }
    
    /**
     * Infect a percentage of the antelopes at the start.
     * @return true if infected.
     */
    private boolean isInfected()
    {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= INFECTION_PROBABILITY) {
            return true;
        }
        return false;
    }
}
