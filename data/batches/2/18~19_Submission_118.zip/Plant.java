import java.util.Random;
import java.util.List;

/**
 * Plants are only able to breed.
 *
 * @version 2019.02.21
 */
public class Plant
{
    private static final double BREEDING_PROBABILITY = 0.21;
    private static final int MAX_CHILDREN = 3;
    private static final int RAINY_MAX_CHILDREN = 4;
    private static final Random rand = Randomizer.getRandom();
    private Field field;
    private Location location;
    private boolean alive;
    
    
    /**
     * Create a new plant.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Creates new plants in free locations.
     */ 
    
    public void makeNewPlants(List<Plant> newPlants)
    {
        if(alive) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                newPlants.add(new Plant(field, loc));
            }
        }
    }
    
    /**
     * Plants are breeding.
     * If the weather is rainy they have a higher value for the number of children they can have.
     */ 
    
    private int breed()
    {
        int maxChildren;
        if (getField().isRainy()) {
            maxChildren = RAINY_MAX_CHILDREN;
        }
        else {
            maxChildren = MAX_CHILDREN;
        }
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(maxChildren) + 1;
        }
        return births;
    }
    
    
    /**
     * When plants are eaten or trampled on this method runs.
     * It clears the location field where it used to be.
     */ 
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    
    /**
     * Returns the location for the plant.
     */ 
    protected Location getLocation()
    {
        return location;
    }
    
    
    /**
     * Sets the location for the plant.
     */ 
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Returns the field for the plant.
     */ 
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Sets the alive boolean field to true.
     */
    public boolean isAlive()
    {
        return alive;
    }
}
