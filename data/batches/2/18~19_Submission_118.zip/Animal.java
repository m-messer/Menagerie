import java.util.List;
import java.util.Random;

/**
 * An abstract class representing shared characteristics of animals.
 *
 * @version 2019.02.21
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The predator's age;
    protected int age;
    // The predator's food level, which is increased by eating its prey.
    protected int foodLevel;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Infect an animal
     * @param animal The animal to be infected
     */
    private void infect(Animal animal)
    {
        animal.infect(animal);
    }
   
    /**
     * Check that there is a neighbouring animal of the same species and opposite gender
     * so that they can breed.
     * @return true if a neighbouring animal is able to breed with this animal.
     */
    protected boolean canGiveBirth()
    {
        List<Location> adjLocations = field.adjacentLocations(getLocation());
        List<Location> freeLocations = field.getFreeAdjacentLocations(getLocation());
        adjLocations.removeAll(freeLocations);  // Get a list of occupying  neighbouring locations.
        // Look for an animal of the same species and opposite gender.
        for (Location location : adjLocations) {
            Object obj = field.getObjectAt(location);
            if (obj instanceof Plant) {
                return false;
            }
            Animal animal = (Animal) obj;
            if (oppositeGender(animal) && sameClass(animal)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Check if an animal has the opposite gender.
     * @param animal The animal to compare with.
     * @return true if animal has the opposite gender.
     */
    protected boolean oppositeGender(Animal animal)
    {
        return animal.getIsFemale() == !this.getIsFemale();
    }
    
    /**
     * Check if an animal is of the same species.
     * @param animal The animal to compare with.
     * @return true if animal is of the same class type (species).
     */
    private boolean sameClass(Animal animal)
    {
        return this.getClass().equals(animal.getClass());
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        if (!canGiveBirth()) {
            return;
        }
        // New animals are born into adjacent locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();   // Gets the number of new animals to be born
        // Add new instances of the species to the list of newly born animals.
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (this instanceof Zebra) {
                newAnimals.add(new Zebra(false, field, loc));
            }
            else if (this instanceof Snake) {
                newAnimals.add(new Snake(false, field, loc));
            }
            else if (this instanceof Lion) {
                newAnimals.add(new Lion(false, field, loc));
            }
            else if (this instanceof Mouse) {
                newAnimals.add(new Mouse(false, field, loc));
            }
            else if (this instanceof Antelope) {
                newAnimals.add(new Antelope(false, field, loc, false));
            }
            else if (this instanceof Leopard) {
                newAnimals.add(new Leopard(false, field, loc));
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && this.getRandom().nextDouble() <= this.getBreedProb()) {
            births = this.getRandom().nextInt(this.getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return this.getAge() >= this.getBreedAge();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Returns the randomizer.
     * @return randomizer.
     */
    abstract public Random getRandom();
    
    /**
     * Return the probability that the species breeds.
     * @return the probability that the species breeds.
     */
    abstract public double getBreedProb();
    
    /**
     * Return the maximum number of possible births for that species.
     * @return the maximum number of possible births for that species.
     */
    abstract public int getMaxLitterSize();
    
    /**
     * Return the age of the animal.
     * @return the age of the animal.
     */
    abstract public int getAge();
    
    /**
     * Return the minimum breeding age for the species.
     * @return the minimum breeding age for the species.
     */
    abstract public int getBreedAge();
    
    /**
     * Return the time that the animal acts.
     * @return true if the species is a day animmal.
     */
    abstract public boolean dayAnimal();
    
    /**
     * Return the food value of the species.
     * @return the food value of the species.
     */
    abstract public int getFoodValue();
    
    /**
     * Return the gender of the animal.
     * @return true if the animal is female.
     */
    abstract public boolean getIsFemale();
}
