import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat antelopes and zebras, and die.
 *
 * @version 2019.02.21
 */
public class Lion extends Predator
{
    // The food value that the snake is worth.
    private static final int FOOD_VALUE = 20;
    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 16;
    // The age to which a lion can live.
    private static final int MAX_AGE = 145;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.17;
    // The likelihood of a snake breeding if its foggy.
    private static final double FOGGY_BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The gender of the lion.
    private boolean isFemale;
    
    /**
     * Create a new lion with a random gender.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        isFemale = rand.nextBoolean();
    }
    
    /**
     * Returns the randomizer.
     * @return randomizer.
     */
    @Override
    public Random getRandom()
    {
        return rand;
    }
    
    /**
     * Return the probability that the lion breeds.
     * Foggy weather will decrease this probability.
     * @return the probability that the lion breeds.
     */
    @Override
    public double getBreedProb()
    {
        if(getField().isFoggy()){
            return FOGGY_BREEDING_PROBABILITY;
        }
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum number of possible births.
     * @return the maximum number of possible births.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the age of the lion.
     * @return the age of the lion.
     */
    @Override
    public int getAge()
    {
        return age;
    }
    
    /**
     * Return the minimum breeding.
     * @return the minimum breeding.
     */
    @Override
    public int getBreedAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Return the maximum possible age.
     * @return the maximum possible age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Checks if an animal is a the lion's prey (antelope and zebra).
     * @param animal The animal to be checked.
     */
    @Override
    public boolean isPrey(Object animal)
    {
        return (animal instanceof Antelope) || (animal instanceof Zebra);
    }
    
    /**
     * Return lion as a day animal.
     * @return true.
     */
    @Override
    public boolean dayAnimal()
    {
        return true;
    }
    
    /**
     * Return the food value
     * @return the food value
     */
    @Override
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * Return the gender
     * @return true if the lion is female.
     */
    @Override
    public boolean getIsFemale()
    {
        return isFemale;
    }
}