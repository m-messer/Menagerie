import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Write a description of class Insect here.
 *
 * @version (a version number or a date)
 */
public class Insect extends Animal
{
    // The age at which a Insect can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a Insect can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a Insect breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single patch of plants. In effect, this is the
    // number of steps an Insect can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 15;
    
    // Individual characteristics (instance fields).
    // The Insect
    private int age;
    // The Monkey's food level, which is increased by eating plants.
    private int foodLevel;
    /**
     * Constructor for objects of class Insect
     */
    public Insect(boolean randomAge, Field field, Location location)
    {
          super(field, location);
          age = 0;
          if(randomAge) {
                age = rand.nextInt(MAX_AGE);
                foodLevel = PLANT_FOOD_VALUE;
            }
            else {
                age = 0;
                foodLevel = 15;
            }
    }
    
    /**
     * This is what the Insect does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newInsects A list to return newly born Insects.
     */
    public void act(List<Animal> newInsects)
    {
        incrementAge();
        if(isAlive() && SimulatorView.dayTime()) {
            // Try to move into a free location.
            Location newLocation = eat();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        else if(isAlive() && !SimulatorView.dayTime()) {
            isBreedable(newInsects);
        }
    }
    private Location eat(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant.isAlive()) { 
                    plant.setDead();
                    return where;
                }
            }
        }
        return null;
    }
    /**
     * Increase the age.
     * This could result in the Insect's death.
     */
    private void incrementAge()
    {
        age++;
        Insect insect = this;
        if(insect.getDisease(insect) == "disease")
        {
            int MAX_AGE = 5;
        }
        if(age > MAX_AGE) {
            setDead();
        }
    }
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    /**
     * Check whether or not this Insect is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newInsects A list to return newly born Insects.
     */
    private void giveBirth(List<Animal> newInsects)
    {
        // New Insects are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Insect young = new Insect(false, field, loc);
            newInsects.add(young);
            young.setGender(young);
            young.setDisease(young);
        }
    }
    private void isBreedable(List<Animal> newInsects)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Insect) {
                Insect ana = (Insect) animal;
                Insect insect = this;
                // Check if they are opposite genders.
                    if(insect.getGender(insect) != ana.getGender(ana) ){
                    giveBirth(newInsects);
                }
            }
        }
    }    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed()) {
            if(SimulatorView.rain() && rand.nextDouble() <= BREEDING_PROBABILITY){
               births = rand.nextInt(1) + 1;
            }
            else{
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            }
        }
        return births;
    }

    /**
     * A Insect can breed if it has reached the breeding age.
     * @return true if the Insect can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && foodLevel >= 10;
    }
}
