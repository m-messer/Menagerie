import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // A hashmap linking the animal to a sex.
    protected HashMap<Animal, String> sex;
    // An arraylist containing the two genders.
    protected ArrayList<String> gender;
    // A hashmap linking the animal to a disease.
    protected HashMap<Animal, String> illness;
    // An arraylist containing the disease.
    protected ArrayList<String> disease;
    Location newLocation;
    /**
     * Create a new animal at location in field, HashMaps 
     * and ArrayLists.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        gender = new ArrayList<>();
        sex = new HashMap<>();  
        illness = new HashMap<>();
        disease = new ArrayList<>();
        
        gender.add("male");
        gender.add("female");
        disease.add("zombie");
        disease.add("disease");
        disease.add("healthy");
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * When called it will give a disease to the animal
     * with a 50% chance.
     */
    protected void setDisease(Animal animal)
    {
        Random rand = new Random();
        int number;
        number = rand.nextInt(3);
        illness.put(animal,disease.get(number));
    }
    
    /**
     * returns if the animal is diseased or not.
     */
    protected String getDisease(Animal animal)
    {
        return illness.get(animal);
    }
    
    /**
     * When called it will assign a gender at an
     * even 50/50 chance.
     */
    protected void setGender(Animal animal)
    {
        Random rand = new Random();
        int number;
        number = rand.nextInt(2);
        sex.put(animal,gender.get(number));
    }
    
    /**
     * returns the gender of the animal.
     */
    protected String getGender(Animal animal)
    {
        return sex.get(animal);
    }
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}