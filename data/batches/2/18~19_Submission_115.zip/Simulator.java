import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;
    // The probability that the animals and plants will be created in any 
    // given grid position.
    private static final double JAGUAR_CREATION_PROBABILITY = 0.03;
    
    private static final double ANACONDA_CREATION_PROBABILITY = 0.02;
    
    private static final double OWL_CREATION_PROBABILITY = 0.02;
    
    private static final double MONKEY_CREATION_PROBABILITY = 0.10;
    
    private static final double INSECT_CREATION_PROBABILITY = 0.08;
    
    private static final double MOUSE_CREATION_PROBABILITY = 0.10;   
    
    private static double PLANT_CREATION_PROBABILITY = 0.07;
    

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private List<Plant> plants;
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Mouse.class, Color.BLUE);
        view.setColor(Anaconda.class, Color.YELLOW);
        view.setColor(Jaguar.class, Color.BLACK);
        view.setColor(Monkey.class, Color.RED);
        view.setColor(Owl.class, Color.PINK);
        view.setColor(Insect.class, Color.GRAY);
        view.setColor(Plant.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (2500 steps).
     */
    public void runLongSimulation()
    {
        simulate(2500);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // uncomment this to run more slowly
            delay(60);
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        // Every step of the simulation plants are created.
        // The plants can only be created when it is raining.
        Random rand = Randomizer.getRandom();
        if(SimulatorView.rain())
        {
            PLANT_CREATION_PROBABILITY = 0.02;
        }
        else
        {
            PLANT_CREATION_PROBABILITY = 0;
        }
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    animals.add(plant);
                }
            }
        }
        
        // Add the newly born animals and the newly created plants
        // to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= JAGUAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Jaguar jaguar = new Jaguar(true, field, location);
                    animals.add(jaguar);
                    jaguar.setGender(jaguar);
                }
                else if(rand.nextDouble() <= ANACONDA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Anaconda anaconda = new Anaconda(true, field, location);
                    animals.add(anaconda);
                    anaconda.setGender(anaconda);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                    mouse.setGender(mouse);
                }
                else if(rand.nextDouble() <= MONKEY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Monkey monkey = new Monkey(true, field, location);
                    animals.add(monkey);
                    monkey.setGender(monkey);
                }
                else if(rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    animals.add(owl);
                    owl.setGender(owl);
                }
                else if(rand.nextDouble() <= INSECT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Insect insect = new Insect(true, field, location);
                    animals.add(insect);
                    insect.setGender(insect);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    animals.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
