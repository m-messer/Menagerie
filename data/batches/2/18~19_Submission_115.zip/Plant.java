import java.util.List;
import java.util.Random;
/**
 * Write a description of class Plants here.
 *
 * @version (a version number or a date)
 */
public class Plant extends Animal
{
    // The Plant's age.
    private int age;
    // The age to which a Plant can live.
    private int MAX_AGE =  20;
    
    /**
     * Constructor for objects of class Plants
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
        age = 0;
    }
    
    /**
     * This is what the Plant does most of the time - it's just
     * a food source in reality.
     * @param newMonkeys A list to return new Plants.
     */
    public void act(List<Animal> newPlants)
    {
        incrementAge();
    }
    
    /**
     * Increase the age.
     * This could result in the Plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
   
}