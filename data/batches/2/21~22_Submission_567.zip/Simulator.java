import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals that live in the.
 *
 * @version 3
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    // The probability that a tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.04;

    // The probability that a hyhena will be created in any given grid position.
    private static final double HYHENA_CREATION_PROBABILITY = 0.05;
 
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.1;

    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.1;
   
    // The probability that a elephant will be created in any given grid position.
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.05;
    
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.5;
    
    // The current step of the simulation.
    public static int step;

    // List of animals in the field.
    private List<Animal> animals;
    
    // The current state of the field.
    private Field field;

    // The current time of the silmulation.
    private Time time;
    
    // The current weather of the silmulation.
    private Weather weather;

    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);
        time = new Time();
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        // Colors for each animal in simulation
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Tiger.class, Color.ORANGE);
        view.setColor(Elephant.class, Color.LIGHT_GRAY); 
        view.setColor(Hyhena.class, Color.YELLOW);
        view.setColor(Deer.class, Color.PINK);
        view.setColor(Grass.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
      public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    { 
        // reset button values
        SimulatorView.pause = false;
        SimulatorView.speed = 0;
        
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            if (SimulatorView.pause == false){
                simulateOneStep(); 
                delay(SimulatorView.speed);
            }
            else{
                //pauses the program until user plays
                while (SimulatorView.pause == true){  
                    delay(10);
                }
                runLongSimulation();
            }
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * entity.
     */
    public void simulateOneStep()
    {
       
        step++;
        
        //update time and weather for every step that we take
        time.updateTime();
        weather.updateWeather();
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>(); 
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with all the animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    animals.add(tiger);
                }

                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }

                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    animals.add(deer);
                }

                else if(rand.nextDouble() <= ELEPHANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Elephant elephant = new Elephant(true, field, location);
                    animals.add(elephant);
                }

                else if(rand.nextDouble() <= HYHENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyhena hyhena = new Hyhena(true, field, location);
                    animals.add(hyhena);
                }

                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    animals.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
