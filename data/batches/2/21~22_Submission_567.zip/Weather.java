import java.util.Random;
import java.util.ArrayList;

/**
 * Weather is a class that has a static variable that stores the current weather,and 
 * the weather can be changed randomly as the simulation runs.
 *
 * @3
 */
public class Weather
{
    // stores the current weather
    public static String cur_weather = "Clear";
    
    //List of weathers
    private ArrayList<String> Weathers;
    private double WEATHER_CHANGE_PROBABILITY = 0.01;
    
    /**
     * Constructor for objects of class Time
     */
    public Weather()
    {  
        Random rand = new Random();
        Weathers = new ArrayList<>();
        Weathers.add("Clear");
        Weathers.add("Rain");
        Weathers.add("Thunderstorm");
    }
    
    /**
     * When this method is called, there is a small chance that the weather can change
     */
    public void updateWeather(){
        Random rand = Randomizer.getRandom();
        if(rand.nextDouble() <= WEATHER_CHANGE_PROBABILITY) {
            cur_weather = Weathers.get(rand.nextInt(Weathers.size()));
        }
    }
}
