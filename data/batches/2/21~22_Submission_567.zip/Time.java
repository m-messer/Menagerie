import java.util.ArrayList;

/**
 * Time class stores a universal time of day value (Morning,Afternoon,Evening,Night), 
 * which is accessed and updated by the silmulator class.
 * @3
 */
public class Time
{
    // Stores the current time 
    public static String cur_time = "Morning";
    
    //List of times of day.
    private ArrayList<String> TimeOfDay;
    private int i; 
    
    /**
     * Constructor for objects of class Time
     */
    public Time()
    {  
        TimeOfDay = new ArrayList<>();
        TimeOfDay.add("Morning");
        TimeOfDay.add("Afternoon");
        TimeOfDay.add("Evening");
        TimeOfDay.add("Night");
    }
    
    /**
     * Updates the time of day, based on the current number of steps the program has performed
     * (cycles every 10 steps).
     */
    public void updateTime()
    
    {
        if (Simulator.step >= 0 && Simulator.step < 100){
            cur_time =  TimeOfDay.get(i);
        }
        
        if (Simulator.step % 10 == 0){
            if (i+1 > TimeOfDay.size()-1){
                i = 0;
            }
            else{
                i = i+1;
                cur_time =  TimeOfDay.get(i);
            }
        }
        
        cur_time = TimeOfDay.get(i);
    }
}
