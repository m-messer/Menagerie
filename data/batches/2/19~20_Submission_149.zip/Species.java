import java.util.*;
/**
 * A class representing shared characteristics of species.
 * and some of the methods that their classes invoke.
 *
 * @version 2020.02.20
 */
public  class Species
{
    // Whether the species is alive or not
    private boolean alive;
    // The specie's field.
    private Field field;
    // The specie's position in the field.
    //private Location location;
    private Location location;
    //The name of the specie.
    private static String name;
    //The health value, when the specie gets eaten.
    private int healthValue;
    //a boolean variable, showing if the specie is infected.
    private boolean Infected;

    /**
     * Constructor for objects of class Species
     */
    public Species(Field field, Location location, String name, int healthValue, boolean Infected)
    {
        this.healthValue = healthValue;
        this.name = name;
        alive = true;
        this.field = field;
        this.Infected = Infected;
        setLocation(location);
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the specie is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the specie's location.
     * @return The specie's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the specie at the new location in the given field.
     * @param newLocation The specie's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the specie's field.
     * @return The specie's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * returns the specie's name.
     * @return: String.
     */
    protected String getName()
    {
        return name;
    }
    
    /**
     * returns the specie's health value.
     * @return: int.
     */
    public int getHealthValue()
    {
        return healthValue;
    }
    
    /**
     * gets the specie infected.
     */
    protected void getInfected()
    {
        Infected = true;
    }
    
    /**
     * returns the specie's infection boolean variable.
     * @return: boolean.
     */
    protected boolean isInfected()
    {
        return Infected;
    }
}
