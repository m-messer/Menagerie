import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * This is a class representing the lion in the simulatior.
 * It has no methods as all of the methods that the Lion class' objects invoke are in the Animal ans Species classes.
 * the lion object is made through the constructor that passes through the characteristics, of the lion through the Animal super constructor.
 *
 * @version 2020.02.20
 */
public class Lion extends Animal
{
    
    // A shared random number generator to control age.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location, "Lion", 100, 0, 150, 15, 0.65, 2, false);
        addFoodType("Fox");
        addFoodType("Rabbit");
        addFoodType("Deer");
        addFoodType("Tiger");
        editFoodLevel(rand.nextInt(60));
        if(randomAge)
        {
            editAge(rand.nextInt(150));
        }
        else
            editAge(0);
    }

}
