import java.util.List;
import java.util.*;
/**
 * A class representing some characteristics of animals.
 * and some of the methods that their classes invoke.
 * the constructor passes through the Species super constructor some fields, which other types of species also have.
 *
 * @version 2020.02.20
 */
public class Animal extends Species
{

    // Animal's Sex
    private boolean isMale;
    // A hash set that includes all the types of animals that the specific animal can eat.
    private static HashSet<String> foodType;
    // The food level that the animal has, the less it is the hungrier the animals are.
    private int foodLevel;
    // The animal's age.
    private int age;
    // The animal's  max age.
    private int MAX_AGE;
    // The animal's  max number of breeding each time.
    private int MAX_LITTER_SIZE;
    // The animal's breeding probability.
    private double BREEDING_PROBABILITY;
    // The animal's minimum  age for breeding.
    private int BREEDING_AGE;
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param: Field The field currently occupied.
     * @param: Location The location within the field.
     * @param: String The name of the animal.
     * @param: int The health value of the animal.
     * @param: int The age of the animal.
     * @param: int The maximum age of the animal.
     * @param: int The breeding age of the animal.
     * @param: double The breeding probability of the animal.
     * @param: int The maximum litter size of the animal.
     * @param: boolean The infection state of the animal.
     */
    public Animal(Field field, Location location, String name, int healthValue, int age, int MAX_AGE, 
    int BREEDING_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, boolean Infected)
    {
        super(field, location, name, healthValue, Infected);
        this.age = age;
        this.MAX_AGE = MAX_AGE;
        this.BREEDING_AGE = BREEDING_AGE;
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
        isMale = animalSex();
        setLocation(location);
        foodType = new HashSet<>();
    }
    
    /**
     * Adds the animal name to the food type Hash set.
     */
    public void addFoodType(String animal)
    {
        foodType.add(animal);
    }
    
    /**
     * returns the food type hash set.
     * @return: hash set.
     */
    public HashSet getFoodType()
    {
        return foodType;
    }
    
    /**
     * Sets the animal sex, with a same probability for either sex.
     * @returns: boolean.
     */
    public boolean animalSex()
    {
        if(rand.nextInt(2) == 1)
            return true;
        else
            return false;
    }
    
    /**
     * Look for animals that are in the food type has set adjacent to the current location, of the animal.
     * Only the first live animal is eaten.
     * Also, if the food is infected the animal that eats it get infected.
     * @return Where food was found, or null if it wasn't.
     */
    
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object species1 = field.getObjectAt(where);
            Species species = (Species) species1;
            if( species != null && this.getFoodType().contains(species.getName())) {
                if(species.isAlive()) {
                    
                    species.setDead();
                    foodLevel += species.getHealthValue();
                    if(species.isInfected())
                    {
                        this.getInfected();
                        FieldStats.incrementInfectionNumber();
                    }
                    return where;
                }
            }
            
        }
        return null;
    }
    
     /**
     * Make the animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newAnimals)
    {
            if(this.isAlive()) {
                giveBirth(newAnimals);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                    
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
        }
    }
    
    /**
     * increments the hunger of the animal, by reducing the food level, by 1 if it is not incfected, or by 3 if it is.
     * and checks if it is below or equal to zero, to check if it is dead.
     */
    public void incrementHunger()
    {
        editFoodLevel(-1);
        if(this.isInfected())
            editFoodLevel(-2);
            
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
    
    /**
     * increments the age of the animal by 1.
     * and checks if it is above the maximum age.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * returns the food level of the animal.
     * @return: int.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * edits the food level of the animal, by adding the passed parameter.
     * @param: int.
     */
    protected void editFoodLevel(int num)
    {
        foodLevel += num;
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    private void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        HashSet<Species> adjacentSpecies = new HashSet<Species>();
        // Adds adjacent species to the animal in a hash set.
        while(it.hasNext()) 
        {
            Location where = it.next();
            Object species1 = field.getObjectAt(where);
            Species specie = (Species) species1;
            adjacentSpecies.add(specie);
        }
        
        //checks if the adjacent specie is of the same type and different sex, and if so gives birth.
        for(Species sp: adjacentSpecies)
        {
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                if (sp instanceof Animal)
                {
                    Animal animal = (Animal) sp;
                    if(this instanceof Lion && sp instanceof Lion)
                    {
                        if(animal.getSex() != this.getSex())
                        {
                            Animal young = new Lion(false, field, loc);
                            newAnimals.add(young);
                        }
                    }
                    else if(this instanceof Tiger && sp instanceof Tiger)
                    {
                        if(animal.getSex() != this.getSex())
                        {
                            Animal young = new Tiger(false, field, loc);
                            newAnimals.add(young);
                        }
                    }
                    else if(this instanceof Fox && sp instanceof Fox)
                    {
                        if(animal.getSex() != this.getSex())
                        {
                            Animal young = new Fox(false, field, loc);
                            newAnimals.add(young);
                        }
                    }
                    else if(this instanceof Deer && sp instanceof Deer)
                    {
                        if(animal.getSex() != this.getSex())
                        {
                            Animal young = new Deer(false, field, loc);
                            newAnimals.add(young);
                        }
                    }
                    else if(this instanceof Rabbit && sp instanceof Rabbit)
                    {
                        if(animal.getSex() != this.getSex())
                        {
                            Animal young = new Rabbit(false, field, loc);
                            newAnimals.add(young);
                        }
                    }
                }
            }
        }
        
    }
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed()
    {
            return getAge() >= BREEDING_AGE;
    }
    
    /**
     * returns the animal's age.
     * @return: int.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * returns the animal's sex.
     * @return: boolean.
     */
    public boolean getSex()
    {
        return isMale;
    }
    
    /**
     * sets the animal's age, by making age equal to the passed parameter.
     * @param: int.
     */
    protected void editAge(int num)
    {
        age = num;
    }
    
    /**
     * returns the animal's maximum age.
     * @return: int.
     */
    protected int getMAX_AGE()
    {
        return MAX_AGE;
    }
}
