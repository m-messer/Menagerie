import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * This is a class representing the tiger in the simulatior.
 * It has no methods as all of the methods that the Tiger class' objects invoke are in the Animal and Species classes.
 * the tiger object is made through the constructor that passes through the characteristics, of the tiger through the Animal super constructor.
 *
 * @version 2020.02.20
 */
public class Tiger extends Animal
{

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the tiger will have random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(field, location, "Tiger", 90, 0, 150, 15, 0.65, 2, false);
        addFoodType("Fox");
        addFoodType("Rabbit");
        addFoodType("Deer");
        editFoodLevel(rand.nextInt(60));
        if(randomAge)
        {
            editAge(rand.nextInt(150));
        }
        else
            editAge(0);
    }
    
}
