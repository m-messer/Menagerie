import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * This is a class representing the fox in the simulatior.
 * It has no methods as all of the methods that the Fox class' objects invoke are in the Animal and Species classes.
 * the fox object is made through the constructor that passes through the characteristics, of the fox through the Animal super constructor.
 *
 * @version 2020.02.20
 */
public class Fox extends Animal
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location)
    {
        super(field, location, "Fox", 70, 0, 100, 10, 0.5, 2, false);
        addFoodType("Rabbit");
        addFoodType("Deer");
        editFoodLevel(rand.nextInt(35));
        if(randomAge)
        {
            editAge(rand.nextInt(100));
        }
        else
            editAge(0);
    }
    
}
