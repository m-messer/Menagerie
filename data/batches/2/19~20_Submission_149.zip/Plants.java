import java.util.*;
/**
 * This is a class representing the plant in the simulatior.
 * This class has only one method, which increments the age, but has other methods from the class higher in the class hierarchy, Species.
 * Also, the constructor passes through the Species super constructor some fields, which other types of species also have.
 *
 * @version 2020.02.20
 */
public class Plants extends Species
{
    private static final int MAX_AGE = 15;
    private int age;
    private static final Random rand = Randomizer.getRandom();
    /**
     * creates a new plant with a random age.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(Field field, Location location)
    {
        super(field, location, "Plants", 30, false);
        age = rand.nextInt(MAX_AGE);
    }
    
    /**
     * increments the plant's age by 1 if it is not infecte, or by 3 if it is.
     * and if it reaches the maxiumum age it sets it dead.
     * 
     * Incrementing the age means making the plan die faster, so if it is infected it will die faster.
     */
    public void incrementAge()
    {
        age += 1;
        if(this.isInfected())
            age+= 2;
            
        if (age > MAX_AGE)
            setDead();
    }
    
    
}
