import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing plants, rabbits, deers, foxes, tigers, and lions.
 *
 * @version 2020.02.20
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.07;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.11;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.045;
    // The probability that a tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.05;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.09;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANTS_CREATION_PROBABILITY = 0.13;
    
    // A Randomizer object.
    private static final Random rand = Randomizer.getRandom();

    // List of animals in the field.
    private List<Species> species;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // the current time.
    private int time = 0;
    // Day and night boolean variable.
    private boolean isDay = true;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The weather in the simulation.
    private boolean isClear;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        species = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Lion.class, Color.YELLOW);
        view.setColor(Tiger.class, Color.PINK);
        view.setColor(Deer.class, Color.RED);
        view.setColor(Plants.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * makes a time string, showing the time, and if it is day or night.
     * @return: String.
     */
    private String timeString()
    {
        if (isDay)
            return time + ":00, " + "Day";
        else
            return time + ":00, " + "Night";
    }
    
    /**
     * updates the clock time, and if it is day or night.
     */
    private void dayOrNight()
    {
        if(time == 24)
            time -= 24;
            
        if (time < 12)
        {
            isDay = true;
        }
        else if (time >= 12 && time < 24)
        {
            isDay = false;
        }
        time+=6;
    }
    
    /**
     * @return: the boolean variable isDay.
     */
    public boolean getDayOrNight()
    {
        return isDay;
    }
    
    /**
     * sets the weather randomly, to either rainny, or clear.
     */
    private void setWeather()
    {
        int randomWeather = rand.nextInt(2);
        if(randomWeather == 0)
            isClear = true;
        else if(randomWeather == 1)
            isClear = false;   
    }
    
    /**
     * makes a weather string, which is either clear, or rainy.
     * @return: String.
     */
    private String weatherString()
    {
        if (isClear)
            return "Clear";
        else
            return "Rainy";
    }
    
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        //sets the weather every 2 steps.
        if(step % 2 == 0)
            setWeather();
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        
        //changes the time with each step.
        dayOrNight();
        
        // Let all rabbits act.
        for(Iterator<Species> it = species.iterator(); it.hasNext(); ) {
            Species specie = it.next();
            if(specie instanceof Plants)
            {
                Plants plant = (Plants) specie;
                plant.incrementAge();
            }
            else if(specie instanceof Animal)
            {
                Animal animal = (Animal) specie;
                animal.incrementAge(); 
                animal.incrementHunger();
                // Animals' behaviour varies from animal type, weather, and time.
                if((animal instanceof Lion || animal instanceof Tiger) && isDay && isClear)
                {
                    animal.act(newAnimals);
                }
                else if(animal instanceof Fox && !isDay)
                {
                    animal.act(newAnimals);
                }
                else if((animal instanceof Rabbit || animal instanceof Deer) && rand.nextInt(2) == 1 && isClear)
                {
                    animal.act(newAnimals);
                }
                
                if(! animal.isAlive()) 
                    it.remove();
            }
        }
      
               
        // Add the newly born foxes and rabbits to the main lists.
        species.addAll(newAnimals);
        if(!isClear)
            species.addAll(makePlants());
            
        //updates the simulator view labels
        view.updateWeather(weatherString());
        view.updateTime(timeString());
        view.updateInfectedSpecies(FieldStats.getInfectionNumber());
        view.showStatus(step, field);
    }

    /**
     * makes plants randomly in free spaces, with a 1/3 chance of the plant having
     * a disease.
     * and adds them to a new ArrayList.
     * @return: ArrayList, which contains the new plants.
     */
    public List<Plants> makePlants()
    {
        ArrayList<Plants> newPlants = new ArrayList<Plants>();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                int randomNumber = rand.nextInt(30);
                if (location != null && randomNumber == 5)
                {
                    Plants plant = new Plants(field, location);
                    if(rand.nextInt(3) == 1)
                        plant.getInfected();
                    newPlants.add(plant);
                    
                }
            }
        }
        return newPlants;
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        species.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    species.add(lion);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    species.add(tiger);
                }
                else if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    species.add(fox);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    species.add(deer);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    species.add(rabbit);
                }
                else if(rand.nextDouble() <= PLANTS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plants plant = new Plants(field, location);
                    if(rand.nextInt(2) == 1)
                        plant.getInfected();
                    species.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
}
