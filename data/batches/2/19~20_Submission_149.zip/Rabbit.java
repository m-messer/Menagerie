import java.util.List;
import java.util.Random;

/**
 * This is a class representing the rabbit in the simulatior.
 * It has no methods as all of the methods that the Rabbit class' objects invoke are in the Animal and Species classes.
 * the rabbit object is made through the constructor that passes through the characteristics, of the rabbit through the Animal super constructor.
 *
 * @version 2020.02.20
 */
public class Rabbit extends Animal
{

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a rabbit. A rabbit can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the rabbit will have a random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location)
    {
        super(field, location, "Rabbit", 35, 0, 70, 2, 0.9, 4, false);
        addFoodType("Plants");
        editFoodLevel(rand.nextInt(35));
        if(randomAge)
        {
            editAge(rand.nextInt(70));
        }
        else
            editAge(0);
    }
}
