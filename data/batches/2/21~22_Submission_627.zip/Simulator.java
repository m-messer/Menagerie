import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Seaweed, Salmon, Cod, Shark, Whale, and also the elmement of disease and weather
 *
 * @version 2022/03/02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // The probability that a fox will be created in any given grid position.
    private static final double SALMON_CREATION_PROBABILITY = 0.08;
    // The probability that a rabbit will be created in any given grid position.
    private static final double COD_CREATION_PROBABILITY = 0.08;  
    // The probability that a seaweed will be created in any given grid position.
    private static final double SEAWEED_CREATION_PROBABILITY = 0.03;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.04;
    // The probability that a whale will be created in any given grid position.
    private static final double WHALE_CREATION_PROBABILITY = 0.03;

    // The probability that a storm may occur.
    private static final double STORM_HAPPEN_PROBABILITY = 0.14; 
    // The probability that the disease may occur.
    private static final double DISEASE_PROBABILITY = 0.1;


    // List of creatures in the field.
    private List<Creature> creatures;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    private Disease disease;
    private Weather weather;

    
    // The inital level of dissolved oxygen in the water. 
    private double oxygenLevel; 

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        creatures = new ArrayList<>();

        field = new Field(depth, width);
        weather = new Weather(field);
        disease = new Disease();

        oxygenLevel = 1;


        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        view.setColor(Cod.class, Color.ORANGE);
        view.setColor(Salmon.class, Color.YELLOW);
        view.setColor(Seaweed.class, Color.RED);
        view.setColor(Shark.class, Color.BLACK);
        view.setColor(Whale.class, Color.PINK);
        view.setColor(Weather.class,Color.BLUE);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * 
     * Iterate over the whole field updating the state of each
     * creaturesÃ¯Â¼Ârecord the total amount of oxygen that is consumed or produced 
     * by specific species in each step, Storms have a certain probability of occurring , 
     * update the oxygen level, and identify if the disease is stops.
     */
    public void simulateOneStep()
    {
        step++;

        double totalOxygenInvolved= 0; //oxygen that is generated or consumed in total for this step

        disease.creationSourceOfInfection(creatures, step);

        // Provide space for newborn animals.
        List<Creature> newCreatures = new ArrayList<>();        
        // Let all creatures act.
        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
            Creature creature = it.next();
            totalOxygenInvolved += creature.act(newCreatures, timeOfDay(), oxygenLevel, disease, step);
            if(!creature.isAlive()) {
                it.remove();
            }
        }

        if(Randomizer.getRandom().nextDouble() <= STORM_HAPPEN_PROBABILITY) {
            weather.underwaterStorm(3); //  generate the storm at a random location.
            weather.setStormStart(true);
        } else {
            weather.setStormStart(false);
        }        

        // calculate the oxygen left
        oxygenLevel += totalOxygenInvolved;

        // identify if disease stops
        if(disease.getIsSpread()){
            disease.setIsSpread(identifyIfDiseaseStops());
        }

        // Add the newly born creatures to the main lists.
        creatures.addAll(newCreatures);
        view.showStatus(step, field, timeOfDay(), weather, oxygenLevel);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        creatures.clear();
        populate();
        oxygenLevel = 1;
        Animal.populationDieOfDisease = 0;

        // Show the starting state in the view.
        view.showStatus(step, field, timeOfDay(), weather, oxygenLevel);
    }

    /**
     * Randomly populate the field with Salmon, Seaweed, Shark and Whale.
     * notice if and else if is based on the creation probability of a creature in an ascending order
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SALMON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Salmon salmon = new Salmon(true, field, location);
                    creatures.add(salmon);
                }
                else if(rand.nextDouble() <= COD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cod cod = new Cod(true, field, location);
                    creatures.add(cod);
                }
                else if(rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY){
                    Location location = new Location (row, col);
                    Seaweed seaweed = new Seaweed(true, field, location);
                    creatures.add(seaweed);
                }else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    creatures.add(shark);
                }else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    creatures.add(whale);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     *  Pause for a given time.
     *  @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * 5 steps is considered as a day time followed by 5 steps considered as a night.
     * 
     * @return true If currently step is day time false if it is night time.
     */
    public boolean timeOfDay(){
        return (step % 10) < 5;
    }

    /**
     *  If all animals infected die or all animals get immunity, the disease stops.
     *  Only animal can be infected.
     */
    public boolean identifyIfDiseaseStops(){

        List<Creature> newCreatures = new ArrayList<>();   

        boolean existDisease = true;

        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
            Creature creature = it.next();
            if(creature instanceof Animal){
                Animal ani = (Animal)creature;
                // if the animal is not infected or is immuned
                if(!ani.getIsInfected() || ani.getIsImmuned()){  
                    existDisease = false;
                }
                else{
                    existDisease = true;
                }
            }
        }

        return existDisease;
    }
}
