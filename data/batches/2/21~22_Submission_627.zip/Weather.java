import java.util.Iterator;
import java.util.List;
/**
 * A simple model of weather.
 * 
 * A underwater storm is contained in the class of weather. It will happen or subsides intermittently.
 *
 * @version 2022/03/02
 */
public class Weather
{
    // The current state of the field.
    private Field field;
    // a random location where the storm center is.
    private Location randomLocation;
    // the scope of the storm.
    private int stormScope;
    // true if the storm start.
    private boolean stormStart;

    /**
     * Create a weather.
     * @param field The field currently occupied.
     */
    public Weather(Field field)
    {
        this.field = field;

    }

    /**
     * generate a underwater storm and kill all creatures under the storm scope.
     * Get a random location as the center of storm, and use stormScope to determine the length and width,
     * set all creatures within the storm scope to death.
     * 
     * @param stormScope the scope of the storm. The length and width of a storm 
     * are its stormscope * 2 + 1 
     */
    public void underwaterStorm(int stormScope)
    {
        setStormScope(stormScope);
        randomLocation = field.generateRandomLocation(); // get a random location as storm center.
        
        //get all creatures in the storm scope.
        List<Object> adjacentObjectList = field.getAllObjectAt(randomLocation, stormScope);
        //set them to death.
        Iterator<Object> it = adjacentObjectList.iterator();
        while( it.hasNext() ) {
            Object adjacentObject = it.next();
            if(adjacentObject instanceof Creature){
                Creature creature = (Creature) adjacentObject;
                if( creature.isAlive()) { 
                    creature.setDead();
                }
            }
        }
    }
    /**
     * Set the underwater storm scope.
     * @param stormScope int storm scope.
     */
    private void setStormScope(int stormScope) {
        this.stormScope = stormScope;
    }
    /**
     * get a random location as the center of storm.
     * @return return a Location type randomLocation.
     */
    public Location getRandomLocation() {
        return randomLocation;
    }
    /**
     * get the underwater storm scope.
     * @return int stormScope .
     */
    public int getStormScope() {
        return stormScope;
    }
    /**
     * If the storm begins, set the stormStart to true.
     * @param stormStart whether the storm begins.
     */
    public void setStormStart(boolean stormStart) {
        this.stormStart = stormStart;
    }
    /**
     * get whether the storm begins.
     * @return true if the storm begins, false otherwise.
     */
    public boolean getStormStart() {
        return stormStart;
    }
}