import java.util.Arrays;
import java.util.HashSet;

/**
 * The implementation of a the disease class:
 * Pinkeye is fast to spread but has a minimal effect on the health of the animal
 *
 * Code utilised in lines 22-23 are attributed to "Gennadiy" from the StackOverflow below:
 * https://stackoverflow.com/questions/2041778/how-to-initialize-hashset-values-by-construction
 *
 * @version 02/03/2020
 */
public class PinkEye extends Disease{
    // Constants for this disease
    private static final double RECOVERY_CHANCE = 0.1;
    private static final double INFECTION_CHANCE = 0.1;
    private static final int PENALTY_VALUE = 1;
    // Keep track of the number of animals infected
    private static int infectedAnimals = 0;
    // Assign animals that this disease applies to
    public static final Class[] SET_VALUES = new Class[]{Leopard.class, Gazelle.class, Zebra.class, Cheetah.class};
    public static final HashSet<Class> proneAnimals = new HashSet<Class>(Arrays.asList(SET_VALUES));


    @Override
    protected double getRecoveryChance() {
        return RECOVERY_CHANCE;
    }

    @Override
    protected double getInfectionChance() {
        return INFECTION_CHANCE;
    }

    @Override
    protected int getPenaltyValue() {
        return PENALTY_VALUE;
    }

    @Override
    protected int getInfectedCount() {
        return infectedAnimals;
    }

    @Override
    protected void incrementInfectedCount() {
        infectedAnimals++;
    }

    @Override
    protected void decrementInfectedCount() {
        infectedAnimals--;
    }

    @Override
    protected boolean isInfectable(Class animalClass){
        return proneAnimals.contains(animalClass);
    }
}
