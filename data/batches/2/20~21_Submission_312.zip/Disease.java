import java.util.HashSet;

/**
 * An abstract class representing the diseases an animal can
 * have. Methods of this class are related to how the disease
 * affects the infected animal
 *
 * @version 02/03/2020
 */
public abstract class Disease {
    HashSet<Class> proneAnimals;

    /**
     * @return the recovery chance of the disease
     */
    protected abstract double getRecoveryChance();

    /**
     * @return the infection chance of the disease
     */
    protected abstract double getInfectionChance();

    /**
     * @return the penalty value of the disease
     */
    protected abstract int getPenaltyValue();

    /**
     * @return the number of animals infected with this disease
     */
    protected abstract int getInfectedCount();

    /**
     * Increases the counter tracking cases of the disease
     */
    protected abstract void incrementInfectedCount();

    /**
     * Decreases the counter tracking cases of the disease
     */
    protected abstract void decrementInfectedCount();

    /**
     * Checks to see whether an animal is susceptible to a disease
     * @param animalClass The Class of the animal we want to check
     * @return true if that animal class can be infected, else false
     */
    protected abstract boolean isInfectable(Class animalClass);

}
