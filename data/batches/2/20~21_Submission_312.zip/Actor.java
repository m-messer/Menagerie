/**
 * A generic actor class which is stored in a tile on the board,
 * must be implemented by subclasses
 *
 * @version 02/03/2020
 */
public abstract class Actor {
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;
    // Whether the actor is in play or not.
    protected boolean alive;
    // Time for the actor
    protected static int hour;
    protected static int day = 0;
    protected static int month = 0;

    public Actor(Field field, Location location){
        this.field = field;
        setLocation(location);
        alive = true;
    }
    
    /**
     * Updates the current hour, day and month every step.
     * 
     * @param step  the current step of the simulation.
     */
    public void updateTime(int step)
    {
        hour = step % 24;//24 hours from 0 - 23
        if(hour == 0){day++; }//whenever the time reaches midnight (0hrs), a new day begins
        if(day == 28){month++; }//whenever the 28th day is reached, a month has passed
    }
    
    /**
     * Returns the location of the actor
     *
     * @return The actor's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     *
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Returns the field the actor inhabits
     *
     * @return The actor's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Indicate that the actor is no longer in play.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Check whether the animal is still in play in the simulation
     *
     * @return true if the animal is still in play, else false
     */
    protected boolean isAlive() {
        return alive;
    }

    /* ABSTRACT METHODS TO BE OVERRIDDEN IN SUBCLASSES */

    /**
     * Return a random double
     *
     * @return Random double between 0 and 1 inclusive
     */
    protected abstract double getRandomDouble();

    /**
     * Return a random integer between 0 and maxValue-1 inclusive
     *
     * @param maxValue The maximum value which can be returned
     * @return A random integer between 0 and maxValue-1 inclusive
     */
    protected abstract int getRandomInt(int maxValue);

    /**
     * Generate random boolean value
     *
     * @return Random boolean value
     */
    protected abstract boolean getRandomBoolean();

}
