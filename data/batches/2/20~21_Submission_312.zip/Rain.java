/**
 * An implementation of the weather class, rain is a
 * fundamental part to the growth of plant life
 *
 * @version 02/03/2020
 */
public class Rain extends Weather
{
    /**
     * Create a rain object in a field
     *
     * @param field The field to add rain to
     */
    public Rain(Field field)
    {
        // initialise instance variables
        super(field);
        duration = getRandomInt(21);
        
        depth = field.getDepth();
        width = field.getWidth();
        
        weatherMap = new boolean[depth][width];
    }
    
    /**
     * While it is raining, every tile that is true allows plants to grow
     */
    protected void effect()
    {
        if(isActive() == true){
            if(duration > 0){
                for(int i = 0; i < (depth*width/20); i++){
                        int rand_X = getRandomInt(depth);
                        int rand_Y = getRandomInt(width);
                        weatherMap[rand_X][rand_Y] = true;
                }
                //printMap();
                duration--;
            }
            else{clear();
                 active = false;
            }
        }
    }
    
    /**
     * Restarts the rain and picks a new duration
     */
    public void activateWeather()
    {
        duration = getRandomInt(21);
        active = true;
        effect();
    }
    
    /**
     * Resets every tile back to false
     */
    private void clear()
    {
        for(int i = 0; i < depth; i++){
            for(int j = 0; j < width; j++){
                weatherMap[i][j] = false;
            }
        }
    }    
    
    /**
     * Returns how long it will rain
     */
    protected int returnDuration()
    {
        return duration;
    }
    
    /**
     * Prints out the map,
     * showing which tiles are currently "wet" - used primarily for testing
     * . = dry, x = wet
     */
    private void printMap()
    {
        for(int i = 0; i < depth; i++){
            for(int j = 0; j < width; j++){
                if(j == (width - 1)){
                    System.out.print("\n");
                }
                if(weatherMap[i][j] == false){
                    System.out.print(".");
                }
                else if(weatherMap[i][j] == true){
                    System.out.print("x");
                }
            }
        }
        System.out.println();
    }
}
