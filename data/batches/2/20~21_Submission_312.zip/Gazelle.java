import java.util.*;

/**
 * A simple model of a gazelle.
 * gazelles age, move, breed, and die.
 *
 * @version 02/03/2020
 */
public class Gazelle extends Animal
{
    // Characteristics shared by all gazelles (class variables).

    // The age at which a gazelle can start to breed.
    private static final int BREEDING_AGE = 25;
    // The age to which a gazelle can live.
    private static final int MAX_AGE = 1600;
    // The likelihood of a gazelle breeding.
    private static final double BREEDING_PROBABILITY = 0.55; //0.01
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Defining a gazelle's diet:
    // Adapted from: https://www.baeldung.com/java-initialize-hashmap
    protected static Map<Class, Integer> animalEats;
    static {
        animalEats = new HashMap<>();
        animalEats.put(Plant.class, 12);
    }

    // The food value a gazelle starts off with
    private static final int DEFAULT_FOOD_VALUE = 12;

    /**
     * Create a new gazelle. A gazelle may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the gazelle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gazelle(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the gazelle does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     *
     * @param newGazelles A list to return newly born gazelles.
     */
    public void act(List<Animal> newGazelles)
    {
        incrementAge();
        if(isAlive()) {
            passInfection();
            attemptRecovery();
            if(!((hour >= 21) && ( hour <= 8))){//from 21:00 to 06:00 gazelles are asleep
                if((hour >= 10) && (hour <= 14)){
                    //between 10:00 and 14:00 gazelles will breed
                    meet(newGazelles);
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }

                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }

                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether or not this gazelle is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newGazelles A list to return newly born gazelles.
     */
    protected void giveBirth(List<Animal> newGazelles)
    {
        // New gazelles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Gazelle young = new Gazelle(false, field, loc);
            newGazelles.add(young);
        }
    }

    /* OVERRIDING ABSTRACT METHODS FROM ANIMAL CLASS */

    /**
     * @param actorClass The class of the actor we want to check
     * @return True if the animal eats that object, else false
     */
    protected boolean eats(Class actorClass){
        if (actorClass == null){
            return false;
        }
        return animalEats.containsKey(actorClass);
    }

    /**
     * @param actorClass The class of the actor we want the food value of
     * @return An int food value
     */
    protected int getFoodValue(Class actorClass){
        return animalEats.get(actorClass);
    }

    /**
     * @return Constant for the classes MAX_AGE
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * @return Constant for the classes BREEDING_AGE
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * @return Constant for the classes BREEDING_PROBABILITY
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return Constant for the classes MAX_LITTER_SIZE
     */
    protected int getLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * @return Random value between 0 and 1 inclusive
     */
    protected double getRandomDouble(){
        return rand.nextDouble();
    }

    /**
     * @param maxValue The maximum value which can be returned
     * @return A random integer between 0 and maxValue inclusive
     */
    protected int getRandomInt(int maxValue){
        return rand.nextInt(maxValue);
    }

    /**
     * @return Random boolean value
     */
    protected boolean getRandomBoolean(){
        return rand.nextBoolean();
    }
}
