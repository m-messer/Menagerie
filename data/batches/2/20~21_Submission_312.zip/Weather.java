import java.util.Random;
/**
 * An abstract weather class, the weather concrete
 * classes can be created at a position in a field
 * and will last for a certain duration
 *
 * @version 02/03/2020
 */
public abstract class Weather
{  
    //The tiles the weather interacts with
    Field field;
    
    protected int duration;//how long the weather lasts
    
    protected boolean[][] weatherMap;//Stores the coordinates of tiles affected by the weather
    protected int depth, width;// depth and width of weatherMap
    protected boolean active;

    /**
     * Constructor for subclasses
     *
     * @param field The field to add the object to
     */
    protected Weather(Field field)
    {
        this.field = field;
        active = true;
    }
    
    /**
     * Every weather event will invoke an effect
     */
    protected abstract void effect();
    
    /**
     * Returns how many steps the weather event will last
     */
    protected abstract int returnDuration();
    
    /**
     * Returns an array of all the coordinates of tiles affected by the weather.
     */
    public boolean[][] returnWeatherMap()
    {
        return weatherMap;
    }
    
    /**
     * Starts/restarts the weather
     */
    public void activateWeather()
    {
        active = true;
        effect();
    }
    
    /**
     * Picks a random number up to the maximum value given
     * 
     * @param maxValue  The highest number that can can be picked
     */
    protected int getRandomInt(int maxValue)
    {
        Random rand = new Random();
        int randValue = rand.nextInt(maxValue);
        
        return randValue;
    }
    
    /**
     * Checks if the weather event is active
     */
    protected boolean isActive()
    {
        return active;
    }
}
