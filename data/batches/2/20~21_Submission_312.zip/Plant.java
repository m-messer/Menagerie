import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * An implementation of the Actor class, plants are inanimate and instead
 * of moving around, they instead grow outwards. This is dependent on the
 * weather conditions
 *
 * @version 02/03/2020
 */
public class Plant extends Actor{
    // A shared random number generator to control randomness
    private static final Random rand = Randomizer.getRandom();

    // The chance that a plant grows
    private static final Double GROWTH_CHANCE = 0.9;

    public Plant(Field field, Location location) {
        super(field, location);
    }

    /**
     * Complete the plant's actions for each step
     * @param newPlants a list of new plants to output to
     */
    public void act(List<Plant> newPlants, boolean[][] weatherMap){
        if (isAlive()){
            if(canGrow(weatherMap)){
                // 50% chance that plant grows
                if (getRandomDouble() <= GROWTH_CHANCE) {
                    grow(newPlants);
                }
            }
        }
    }

    /**
     * The plant equivalent of breeding, plants will attempt to grow to
     * adjacent squares
     * @param newPlants a list of new plants to output to
     */
    public void grow(List<Plant> newPlants){
        // Plant grows into adjacent locations
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // If there is a free location to move to
        if (free != null) {
            for (Location loc : free) {
                Plant plant = new Plant(field, loc);
                newPlants.add(plant);
            }
        }
    }

    /**
     * Determines whether the weather conditions allow the
     * plant to grow
     *
     * @param weatherMap A map of the weather conditions
     * @return true if plant can grow, else false
     */
    public boolean canGrow(boolean[][] weatherMap)
    {
        int row = getLocation().getRow();
        int column = getLocation().getCol();
        if(weatherMap[row][column] == true){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * @return Random double between 0 and 1 inclusive
     */
    protected double getRandomDouble(){
        return rand.nextDouble();
    }

    /**
     * Return a random integer
     *
     * @param maxValue The maximum value which can be returned
     * @return A random integer between 0 and maxValue inclusive
     */
    protected int getRandomInt(int maxValue){
        return rand.nextInt(maxValue);
    }

    /**
     * @return Random boolean value
     */
    protected boolean getRandomBoolean(){
        return rand.nextBoolean();
    }
}
