import java.util.*;

/**
 * A simple model of an elephant.
 * Elephants age, move, breed, and die.
 *
 * @version 02/03/2020
 */
public class Elephant extends Animal
{
    // Characteristics shared by all elephants (class variables).

    // The age at which an elephant can start to breed.
    private static final int BREEDING_AGE = 200;
    // The age to which an elephant can live.
    private static final int MAX_AGE = 3000;
    // The likelihood of an elephant breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Defining an elephant's diet:
    // Adapted from: https://www.baeldung.com/java-initialize-hashmap
    protected static Map<Class, Integer> animalEats;
    static {
        animalEats = new HashMap<>();
        animalEats.put(Plant.class, 400);
    }

    // The food value an elephant starts off with
    private static final int DEFAULT_FOOD_VALUE = 400;

    /**
     * Create a new elephant. A elephant may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the elephant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Elephant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the elephant does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     *
     * @param newElephants A list to return newly born elephants.
     */
    public void act(List<Animal> newElephants)
    {
        incrementAge();
        if(isAlive()) {
            passInfection();
            attemptRecovery();
            if(!(hour >= 4) && (hour <= 6)){//elephants sleep between 04:00 and 06:00
                if((hour >= 17) && (hour <= 20)){
                    //elephants breed between 17:00 and 20:00
                    meet(newElephants);
                }

                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }

                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }

                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether or not this elephant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newElephants A list to return newly born elephants.
     */
    protected void giveBirth(List<Animal> newElephants)
    {
        // New elephants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Elephant young = new Elephant(false, field, loc);
            newElephants.add(young);
        }
    }

    /* OVERRIDING ABSTRACT METHODS FROM ANIMAL CLASS */

    /**
     * @param actorClass The class of the actor we want to check
     * @return True if the animal eats that object, else false
     */
    protected boolean eats(Class actorClass){
        if (actorClass == null){
            return false;
        }
        return animalEats.containsKey(actorClass);
    }

    /**
     * @param actorClass The class of the actor we want the food value of
     * @return An int food value
     */
    protected int getFoodValue(Class actorClass){
        return animalEats.get(actorClass);
    }

    /**
     * @return Constant for the classes MAX_AGE
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * @return Constant for the classes BREEDING_AGE
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * @return Constant for the classes BREEDING_PROBABILITY
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return Constant for the classes MAX_LITTER_SIZE
     */
    protected int getLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * @return Random value between 0 and 1 inclusive
     */
    protected double getRandomDouble(){
        return rand.nextDouble();
    }

    /**
     * @param maxValue The maximum value which can be returned
     * @return A random integer between 0 and maxValue inclusive
     */
    protected int getRandomInt(int maxValue){
        return rand.nextInt(maxValue);
    }

    /**
     * @return Random boolean value
     */
    protected boolean getRandomBoolean(){
        return rand.nextBoolean();
    }
}
