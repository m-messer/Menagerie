import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 02/03/2020
 */
public abstract class Animal extends Actor{
    // The animal's age.
    protected int age;
    // The disease an animal may be carrying (null if healthy)
    protected Disease disease;
    // The animal's food level, which is increased by eating it's food source
    protected int foodLevel;
    //The animal's gender, it can only breed with the opposite gender
    protected boolean gender = getRandomBoolean();
    // A HashMap of all the classes an animal eats, whether other animals, or grass
    protected static Map<Class, Integer> animalEats; // Links an animal to the food value it provides


    /**
     * Create a new animal at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        super(field, location);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Checks the surrounding tiles to find a gazelle of the opposite gender.
     * If there is, then there is a chance the two will breed.
     *
     * @param newAnimals The list of animals to write to
     */
    protected void meet(List<Animal> newAnimals)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor != null && actor.getClass() == this.getClass()) {
                Animal animal = (Animal) actor;
                if(animal.getGender() != this.gender) {
                    giveBirth(newAnimals);
                }
            }
        }
    }

    /**
     * Returns the animal's gender
     *
     * @return
     */
    protected boolean getGender(){return gender;}


    /**
     * Increase the animal's age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        // If diseased, decrease lifespan accordingly
        if (disease != null){
            age += disease.getPenaltyValue();
        }
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Increases the animal's hunger level
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * The animal will attempt to find something it eats in the
     * squares adjacent to it, based on the Map animalEats
     *
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            // Check for adjacent object and if the animal eats it
            if((object != null) && (eats(object.getClass()))) {
                Actor actor = (Actor) object;
                if(actor.isAlive()) {
                    actor.setDead();
                    // Get the food value from the hashmap
                    foodLevel += getFoodValue(actor.getClass());
                    return where;
                }
            }

        }
        return null;
    }


    /**
     * Generate a number representing the number of births, provided
     * it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && getRandomDouble() <= getBreedingProbability()) {
            births = getRandomInt(getLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     *
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * A method which attempts infection of the animal according to the infection chance of the disease
     *
     * @param disease The disease the animal is to be infected with
     */
    protected void attemptInfection(Disease disease){
        // First check if this animal can be infected
        if (disease.isInfectable(this.getClass()) && getRandomDouble() <= disease.getInfectionChance()){
            if (this.disease != null && this.disease != disease){
                // Animal dies from having two diseases
                this.setDead();
            } else{
                // Animal catches the disease
                this.disease = disease;
            }
        }
    }

    /**
     * An infected animal will attempt to pass on the disease it is carrying
     */
    protected void passInfection(){
        // If the animal has a disease
        if (disease != null) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while (it.hasNext()) {
                Location where = it.next();
                Object square = field.getObjectAt(where);
                // If the location has an animal, attempt infection
                if (square instanceof Animal){
                    // Cast to animal
                    Animal animal = (Animal) square;
                    animal.attemptInfection(disease);
                }
            }
        }
    }

    /**
     * @return true if animal has a disease, else false
     */
    protected boolean hasInfection(){
        return (disease != null);
    }

    /**
     * The animal will attempt to recover from it's disease
     */
    protected void attemptRecovery(){
        if (disease != null){
            // Check if recovery made
            if (getRandomDouble() <= disease.getRecoveryChance()){
                disease = null;
            }
        }
    }

    /* ABSTRACT METHODS TO BE OVERRIDDEN IN SUBCLASSES */

    /**
     * Check whether or not this animal can give birth
     *
     * @param newAnimals A list to return newly born animals
     */
    protected abstract void giveBirth(List<Animal> newAnimals);

    /**
     * A method to check if an animal eats an object
     *
     * @param actorClass The class of the actor we want to check
     * @return true if eats, else false
     */
    protected abstract boolean eats(Class actorClass);

    /**
     * A method to obtain the food value of something an animal eats
     *
     * @param actorClass The class of the actor we want the food value of
     * @return true if eats, else false
     */
    protected abstract int getFoodValue(Class actorClass);

    /**
     * @return Constant for the classes MAX_AGE
     */
    protected abstract int getMaxAge();

    /**
     * @return Constant for the classes BREEDING_AGE
     */
    protected abstract int getBreedingAge();

    /**
     * @return Constant for the classes BREEDING_PROBABILITY
     */
    protected abstract double getBreedingProbability();

    /**
     * @return Constant for the classes MAX_LITTER_SIZE
     */
    protected abstract int getLitterSize();

}