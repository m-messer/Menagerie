import java.util.ArrayList;

/**
 * Animals that can be eaten by a wolf
 *
 * @version 2022.02.28
 */
public interface EatenByWolves
{
}
