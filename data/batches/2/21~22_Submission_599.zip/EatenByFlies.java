
/**
 * Plants that can be eaten by a fly.
 *
 * @version 2022.02.28
 */
public interface EatenByFlies
{
}
