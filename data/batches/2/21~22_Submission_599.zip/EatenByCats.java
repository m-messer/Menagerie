
/**
 * Animals that can be eaten by a cat.
 *
 * @version 2022.02.28
 */
public interface EatenByCats
{
}
