
/**
 * Animals that can be eaten by a bird.
 *
 * @version 2022.02.28
 */
public interface EatenByBirds
{
}
