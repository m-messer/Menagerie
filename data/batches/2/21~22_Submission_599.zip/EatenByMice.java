
/**
 * Plants that can be eaten by a mouse.
 *
 * @version 2022.02.28
 */
public interface EatenByMice
{
}
