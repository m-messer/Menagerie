import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing worms and mice.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.1;
    // The probability that a worm will be created in any given grid position.
    private static final double WORM_CREATION_PROBABILITY = 0.2; 
    // The probability that a bird will be created in any given grid position.
    private static final double BIRD_CREATION_PROBABILITY = 0.1; 
    // The probability that a cat will be created in any given grid position.
    private static final double CAT_CREATION_PROBABILITY = 0.1; 
    // The probability that a unicorn will be created in any given grid position.
    private static final double UNICORN_CREATION_PROBABILITY = 0.05; 
    // The probability that a patch of grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.15;
    //The boolean variable representing whether it is daytime or nightime in the field.
    private boolean isDay;
    //The integer that decides which whether is which
    private int weatherVal;
    //Counter to display the number of diseased animals within the simulator.
    private int diseaseCounter;
    private static final Random rand = Randomizer.getRandom();

    // List of animals in the field.
    private List<Animal> animals;
    //List of grass in the field.
    private List<Grass> grasses;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        isDay = true;

        animals = new ArrayList<>();
        grasses = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Worm.class, Color.PINK);
        view.setColor(Mouse.class, Color.GRAY);
        view.setColor(Unicorn.class, Color.MAGENTA);
        view.setColor(Cat.class, Color.BLACK);
        view.setColor(Bird.class, Color.BLUE);
        view.setColor(Grass.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * @return the amount of animals diseased within the simulator
     */
    public int getDiseaseCounter(){
        return diseaseCounter;
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //One cycle (day and night) is 8 steps, therefore day/night lasts for 4 steps
            if (step % 4 == 0){
                isDay = !(isDay());
            }
            //Every six steps there is a change in weather
            if (step % 6 == 0) {
                forecast();
            }
            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Generates a random number to display whether it will rain or not.
     * 0 is sunny - that is the default weather.
     * 1 is rainy - grass grows quicker then.
     * 2 is cold - all animals have a chance of getting a disease then.
     */
    private void forecast() {
        weatherVal = rand.nextInt(3);
    }

    /**
     * @return the randomly generated value that represents the weather.
     */
    private int getWeatherVal() {
        return weatherVal;
    }

    /**
     * @returns whether the isDay boolean variable
     */
    private boolean isDay(){
        return isDay;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and grass.
     */
    public void simulateOneStep() {
        step++;
        diseaseCounter = 0;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();    
        //Provide space for newborn grass.
        List<Grass> newGrass = new ArrayList<>();
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, isDay());
            if (getWeatherVal() == 2 && rand.nextDouble() >= 0.8) {
                animal.setDiseased();
            }
            if(! animal.isAlive()) {
                it.remove();
            }
            if (animal.isDiseased()) {
                diseaseCounter++;
            }
        }
        //Let all grass act.
        for(Iterator<Grass> it = grasses.iterator(); it.hasNext(); ) {
            Grass grass = it.next();
            grass.act(newGrass);
            //If it is raining then grass grows more quickly
            if (getWeatherVal() == 1) {
                grass.setBreedingProbability(0.1);
            } else {
                grass.setBreedingProbability(0.05);
            }
            if(! grass.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animal and grass to the main lists.
        animals.addAll(newAnimals);
        grasses.addAll(newGrass);

        view.showStatus(step, field, isDay(), getWeatherVal(), getDiseaseCounter());
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, isDay(), getWeatherVal(), getDiseaseCounter());
    }

    /**
     * Randomly populate the field with all animals and grass.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    grasses.add(grass);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location, rand.nextBoolean());
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= WORM_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Worm worm = new Worm(true, field, location, rand.nextBoolean());
                    animals.add(worm);
                }
                else if (rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bird bird = new Bird(true, field, location, rand.nextBoolean());
                    animals.add(bird);
                }
                else if (rand.nextDouble() <= CAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cat cat = new Cat(true, field, location, rand.nextBoolean());
                    animals.add(cat);
                }
                else if (rand.nextDouble() <= UNICORN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Unicorn unicorn = new Unicorn(true, field, location, rand.nextBoolean());
                    animals.add(unicorn);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
