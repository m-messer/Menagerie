import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Bird.
 * Birds age, move, eat mice, and die.
 *
 */
public class Bird extends Animal
{
    // Characteristics shared by all Birds (class variables).

    // The age at which a Bird can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a Bird can live.
    private static final int MAX_AGE = 500;
    // The likelihood of a Bird breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single worm. In effect, this is the
    // number of steps a Bird can go before it has to eat again.
    private static final int MOUSE_FOOD_VALUE = 90;
    private static final int WORM_FOOD_VALUE = 20;
    //Probability of spreading disease
    private static final double DISEASE_PROBABILITY = 0.5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Bird's age.
    private int age;
    // The Bird's food level, which is increased by eating mice.
    private int foodLevel;
    //whether or not the animal is diseased. No animal is born diseased. If an animal is
    //diseased, then it loses hunger twice as fast, and will be less likely to breed
    private boolean diseased;
    //gives animal modifier that multiplies/divides with attributes relevant to its and its
    //species' survival
    private int diseaseModifier;
    /**
     * Create a Bird. A Bird can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Bird will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Whether the Bird is male or not.
     */
    public Bird(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        //All birds start off with no disease
        diseased = false;
        diseaseModifier = 1;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MOUSE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(MOUSE_FOOD_VALUE);
        }
    }

    /**
     * Set diseaseModifier to 2. As diseases cannot be cured within this simulation,
     * only setting the diseaseModifier to 2 is needed.
     */
    private void diseaseCheck(){
        if (isDiseased()){
            diseaseModifier = 2;
        }
    }

    /**
     * The diseased individual spreads its disease to adjacent animals
     * Success of spreading disease only happens sometimes:
     * based on if the adjacent is the same species and DISEASE_PROBABILITY
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bird && rand.nextDouble() <= DISEASE_PROBABILITY) {
                Bird bird = (Bird) animal;
                bird.setDiseased();
            }
        }
    }

    /**
     * This is what the Bird does most of the time: it hunts for
     * mice. In the process, it might breed, die of hunger, spread disease if it is ill,
     * or die of old age.
     * @param isDay Boolean to return whether it is day
     * @param newBirds A list to return newly born Birds.
     */
    public void act(List<Animal> newBirds, boolean isDay)
    {
        incrementAge();
        diseaseCheck();
        incrementHunger();
        if (diseased){
            spreadDisease();
        }
        if(isAlive()) {
            //Bird has different behavior depending on time of day.
            if (isDay) {
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            } else {
                giveBirth(newBirds);  
            }
        }
    }

    /**
     * Increase the age. This could result in the Bird's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Bird more hungry. This could result in the Bird's death.
     * If the bird is diseased, then it will get hungry faster, therefore die faster.
     */
    private void incrementHunger()
    {
        foodLevel-= diseaseModifier;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for mice adjacent to the current location.
     * Only the first live mouse is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Mouse) {
                Mouse mouse = (Mouse) food;
                if(mouse.isAlive()) { 
                    mouse.setDead();
                    foodLevel = MOUSE_FOOD_VALUE;
                    return where;
                }
            }
            else if(food instanceof Worm) {
                Worm worm = (Worm) food;
                if(worm.isAlive()) { 
                    worm.setDead();
                    foodLevel = WORM_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Bird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBirds A list to return newly born Birds.
     */
    private void giveBirth(List<Animal> newBirds)
    {
        // New Birds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bird young = new Bird(false, field, loc, isMale());
            newBirds.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0; 
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bird) {
                Bird bird = (Bird) animal;
                if(isOpposingSex(bird) && canBreed() && 
                rand.nextDouble()<= BREEDING_PROBABILITY/diseaseModifier) { 
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                }
                return births;
            }
        }
        return 0;
    }

    /**
     * A Bird can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
