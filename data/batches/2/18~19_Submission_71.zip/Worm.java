import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a worm.
 * Worms age, eat grass, move, breed, and die.
 *
 */
public class Worm extends Animal {
    // Characteristics shared by all worms (class variables).

    // The age at which a worm can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a worm can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a worm breeding.
    private static final double BREEDING_PROBABILITY = .2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of a single blade of grass. 
    private static final int GRASS_FOOD_VALUE = 30;
    //Probability of spreading disease
    private static final double DISEASE_PROBABILITY = 0.5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The worm's age.
    private int age;
    //whether or not the animal is diseased. No animal is born diseased. If an animal is
    //diseased, then it loses hunger twice as fast, and will be less likely to breed
    private boolean diseased;
    //gives animal modifier that multiplies/divides with attributes relevant to its and its
    //species' survival
    private int diseaseModifier;
    //// The worm's food level, which is increased by eating grass.
    private int foodLevel;

    /**
     * Create a new worm. A worm may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the worm will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Whether the Worm is male or not.
     */
    public Worm(boolean randomAge, Field field, Location location, boolean isMale) {
        super(field, location, isMale);
        //All worms start off with no disease
        diseased = false;
        diseaseModifier = 1;
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
    }

    /**
     * Set diseaseModifier to 2. As diseases cannot be cured within this simulation,
     * only setting the diseaseModifier to 2 is needed.
     */
    private void diseaseCheck(){
        if (isDiseased()){
            diseaseModifier = 2;
        }
    }

    /**
     * The diseased individual spreads its disease to adjacent animals
     * Success of spreading disease only happens sometimes:
     * based on if the adjacent is the same species and DISEASE_PROBABILITY
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Worm && rand.nextDouble() <= DISEASE_PROBABILITY) {
                Worm worm = (Worm) animal;
                worm.setDiseased();
            }
        }
    }
    
    /**
     * Make this Worm more hungry. This could result in the Worm's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * This is what the worm does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newWorms A list to return newly born worms.
     * @param isDay Boolean to return whether it is day
     */
    public void act(List<Animal> newWorms, boolean isDay) {
        incrementAge();
        diseaseCheck();
        incrementHunger();
        if (diseased){
            spreadDisease();
        }
        if(isAlive()) {
            giveBirth(newWorms);            
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the worm's death.
     */
    private void incrementAge() {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Grass) {
                Grass grass = (Grass) food;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this worm is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWorms A list to return newly born worms.
     */
    private void giveBirth(List<Animal> newWorms) {
        // New worms are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Worm young = new Worm(false, field, loc, isMale());
            newWorms.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0; 
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Worm) {
                Worm worm = (Worm) animal;
                if(isOpposingSex(worm) && canBreed() && 
                rand.nextDouble()<= BREEDING_PROBABILITY/diseaseModifier) { 
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                }
                return births;
            }
        }
        return 0;
    }

    /**
     * A worm can breed if it has reached the breeding age.
     * @return true if the worm can breed, false otherwise.
     */
    private boolean canBreed() {
        return (age >= BREEDING_AGE);
    }
}
