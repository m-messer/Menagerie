import java.util.Iterator;
import java.util.Random;
import java.util.List;

/**
 * A simple model of a Cat.
 * Cats age, move, eat mice, and die.
 *
 */
public class Cat extends Animal
{
    // Characteristics shared by all Cats (class variables).

    // The age at which a Cat can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a Cat can live.
    private static final int MAX_AGE = 1000;
    // The likelihood of a Cat breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single mouse. In effect, this is the
    // number of steps a Cat can go before it has to eat again.
    private static final int MOUSE_FOOD_VALUE = 50;
    private static final int BIRD_FOOD_VALUE = 100;
    //Probability of spreading disease
    private static final double DISEASE_PROBABILITY = 0.5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Cat's age.
    private int age;
    // The Cat's food level, which is increased by eating mice.
    private int foodLevel;
    //Whether or not the animal is diseased. No animal is born diseased.
    //If an animal is diseased, then it loses hunger twice as fast, and will be less likely to breed
    private boolean diseased;
    //Gives animal modifier that multiplies/divides with attributes relevant to its and its
    //species' survival
    private int diseaseModifier;
    /**
     * Create a Cat. A Cat can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Cat will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale Whether the Cat is male or not.
     */
    public Cat(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        //All Cats start off with no disease
        diseased = false;
        diseaseModifier = 1;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(BIRD_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(BIRD_FOOD_VALUE);
        }
    }

    /**
     * Set diseaseModifier to 2. As diseases cannot be cured within this simulation,
     * only setting the diseaseModifier to 2 is needed.
     */
    private void diseaseCheck(){
        if (isDiseased()){
            diseaseModifier = 2;
        }
    }

    /**
     * The diseased individual spreads its disease to adjacent animals
     * Success of spreading disease only happens sometimes:
     * based on if the adjacent is the same species and DISEASE_PROBABILITY
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cat && rand.nextDouble() <= DISEASE_PROBABILITY) {
                Cat cat = (Cat) animal;
                cat.setDiseased();
            }
        }
    }

    /**
     * This is what the Cat does most of the time: it hunts for
     * mice. In the process, it might breed, die of hunger, spread disease if it is ill,
     * or die of old age.
     * @param newCats A list to return newly born Cats.
     * @param isDay Boolean to return whether it is day.
     */
    public void act(List<Animal> newCats, boolean isDay)
    {
        incrementAge();
        diseaseCheck();
        incrementHunger();
        if (diseased){
            spreadDisease();
        }
        if(isAlive()) {
            //Cat has different behavior depending on time of day.
            if (isDay) {
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            } else {
                giveBirth(newCats); 
            }
        }
    }

    /**
     * Increase the age. This could result in the Cat's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Cat more hungry. This could result in the Cat's death.
     * If the cat is diseased, then it will get hungry faster, therefore die faster.
     */
    private void incrementHunger()
    {
        foodLevel-= diseaseModifier;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for mice adjacent to the current location.
     * Only the first live mouse or bird is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Mouse) {
                Mouse mouse = (Mouse) food;
                if(mouse.isAlive()) { 
                    mouse.setDead();
                    foodLevel = MOUSE_FOOD_VALUE;
                    return where;
                }
            }
            else if(food instanceof Bird) {
                Bird bird = (Bird) food;
                if(bird.isAlive()) { 
                    bird.setDead();
                    foodLevel = BIRD_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Cat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCats A list to return newly born Cats.
     */
    private void giveBirth(List<Animal> newCats)
    {
        // New Cats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cat young = new Cat(false, field, loc, isMale());
            newCats.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0; 
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cat) {
                Cat cat = (Cat) animal;
                if(isOpposingSex(cat) && canBreed() && 
                rand.nextDouble()<= BREEDING_PROBABILITY/diseaseModifier) { 
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                }
                return births;
            }
        }
        return 0;
    }

    /**
     * A Cat can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
