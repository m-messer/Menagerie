/**
 * stimulate a dry day, grass grow very slow
 *
 * @version 2021/02/18
 */
public class Dry extends Weather
{
    /**
     * Construct the grass state in Dry weather.
     */
    public Dry()
    {
        super("Dry", 8, 500);
    }
}
