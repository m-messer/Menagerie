/**
 * Stimulate a normal day
 *
 * @version 2021/02/17
 */
public class Sunny extends Weather
{
    /**
     * Construct the grass state in Raining weather.
     */
    public Sunny()
    {
        super("Sunny",4, 1000);
    }
}
