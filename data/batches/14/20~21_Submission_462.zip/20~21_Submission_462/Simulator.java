import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Wormss and foxes.
 *
 * @version 2021.02.16
 */
public class Simulator
{
    // The current step of the simulation.
    private int step;
    
    private FieldSetter fieldSetter;
   
    // The current weather name.
    //private String weatherName;
    
    // The current time.
    private String dayOrNight;
    
    private Grass grass;
    
    private int infectedNumber;

    private int time;
    
    private WeatherStimulator weatherStimulator;
    
    public Simulator()
    {
        initialize();
        fieldSetter = new FieldSetter();
        //runLongSimulation();
    }
    
    public Simulator(int depth, int height)
    {
        initialize();
        fieldSetter = new FieldSetter(depth, height);
    }

    /**
     * initialize some fields
     */
    private void initialize()
    {
        dayOrNight = "day";
        grass = new Grass();
        weatherStimulator = new WeatherStimulator();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && fieldSetter.isViable(); step++) {
            simulateOneStep();
            //delay(1000);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Snakeand Worms.
     */
    public void simulateOneStep()
    {
        step++;
        time++;
        if(time == 1) {
            weatherStimulator.setWeather(grass);
        }
        grass.growth();
        if(time >= 3) {
            dayOrNight = "Night";
        }
        if(time >= 6) {
            time = 0; 
            dayOrNight = "Day";
        }
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animal act.
        for(Iterator<Animal> it = fieldSetter.getAnimalList().iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.getIsSick()) 
            {
                infectedNumber++;
            }
            
            if(animal instanceof GrassAnimal) {
                GrassAnimal grassAnimal = (GrassAnimal) animal;
                grassAnimal.act(newAnimals, time, grass);
            }
            else if(animal instanceof MeatAnimal){
                MeatAnimal meatAnimal = (MeatAnimal) animal;
                meatAnimal.act(newAnimals, time);
            }
            
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        fieldSetter.introNewAnimals();
        // Add the newly born foxes and Wormss to the main lists.
        fieldSetter.getAnimalList().addAll(newAnimals);
        fieldSetter.setInformation(step,dayOrNight, weatherStimulator.getCurrentWeather().getWeatherName(),
        grass.getAmount(), infectedNumber);
        infectedNumber = 0;
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        time = 0;
        fieldSetter.reset();
        dayOrNight = "day";
        grass.setMaxAmount(1000);
        grass.growth();
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}