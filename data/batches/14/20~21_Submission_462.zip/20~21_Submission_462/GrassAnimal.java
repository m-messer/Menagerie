import java.util.List;
/**
 * A class representing shared characteristics of animals wich eat grass.
 *
 * @version 2021.02.16
 */
public abstract class GrassAnimal extends Animal
{
    /**
     * Create a new grass animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public GrassAnimal(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this grass animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, int time, Grass grass);
}
