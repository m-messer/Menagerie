import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Snake.
 * Snakees age, move, eat Birds, Frogs and Rabbits and die.
 *
 * @version 2021/02/09
 */
public class Snake extends MeatAnimal
{
    // Characteristics shared by all Snakees (class variables).

    // The age at which a Snake can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Snake can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a Snake breeding.
    private static final double BREEDING_PROBABILITY = 0.14;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single Bird.
    private static final int BIRDS_FOOD_VALUE = 20;
    // The food value of a single Frog.
    private static final int FROGS_FOOD_VALUE = 15;
    // The food value of a single Rabbit.
    private static final int RABBITS_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The possibility of snakes getting sick
    private static final double SICK_PROBABILITY = 0.00003;
    //The possibility of snakes getting infect
    private static final double INFECT_PROBABILITY = 0.001;
    
    private static final int SNAKE_SICK_AGE = 50;
    private static final int SNAKE_INFECT_SCOPE = 5;

    /**
     * Create a Snake. A Snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setMaxAge(MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(BIRDS_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(BIRDS_FOOD_VALUE);
        }
    }

    /**
     * This is what the Snake does most of the time: it hunts for
     * Birds,Frogs and Rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param time Current time.
     * @param newSnakees A list to return newly born Snakees.
     */
    public void act(List<Animal> newSnakes, int time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect();
            if(isAlive()) {
                if(time <= 3){
                    giveBirth(newSnakes);
                    // Move towards a source of food if found.
                    Location newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Look for Birds, Frogs and Rabbits adjacent to the current location.
     * Only the first live Bird or frog or Rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            int num = rand.nextInt(3);
            if(num % 3 == 0){
                if(animal instanceof Rabbit) {
                    eatRabbit(where, animal);
                }
                else if(animal instanceof Bird) {
                    eatBird(where, animal);
                }
                else if(animal instanceof Frog) {
                    eatFrog(where, animal);
                }
            }
        }
        return null;
    }

    /**
     * The snake eat the frog. The frog is dead.
     * And the snake's food value will increase.
     * @param where the frog's location
     * @param the animal in the location
     * @return the frog's location
     */
    private Location eatFrog(Location where, Object animal)
    {
        Frog frog = (Frog) animal;
        if(frog.isAlive()) { 
            frog.setDead();
            setFoodLevel(FROGS_FOOD_VALUE);
            return where;
        }
        return null;
    }

    /**
     * The snake eat the bird. The bird is dead.
     * And the snake's food value will increase.
     * @param where the bird's location
     * @param the animal in the location
     * @return the bird's location
     */
    private Location eatBird(Location where, Object animal)
    {
        Bird bird = (Bird) animal;
        if(bird.isAlive()) { 
            bird.setDead();
            setFoodLevel(BIRDS_FOOD_VALUE);
            return where;
        }
        return null;
    }

    /**
     * The snake eat the rabbit. The rabbit is dead.
     * And the snake's food value will increase.
     * @param where the frog's location
     * @param the animal in the location
     * @return the rabbit's location
     */
    private Location eatRabbit(Location where, Object animal)
    {
        Rabbit rabbit = (Rabbit) animal;
        if(rabbit.isAlive()) { 
            rabbit.setDead();
            setFoodLevel(RABBITS_FOOD_VALUE);
            return where;
        }
        return null;
    }

    /**
     * Check whether or not this Snake is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSnakees A list to return newly born Snakees.
     */
    private void giveBirth(List<Animal> newSnakees)
    {
        // New Snakes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Snake young = new Snake(false, field, loc);
            newSnakees.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Snake can breed if it has reached the breeding age.
     * @return Whether the animal can breed.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),4);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if(snake.isAlive() && !(this.isMale() && snake.isMale())&& this.getAge() >= BREEDING_AGE && snake.getAge() >= BREEDING_AGE) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * A getter for the sick age of snake
     */
    public int getSickAge()
    {
        return SNAKE_SICK_AGE;
    }
    
    /**
     * A getter for the scope infected by the snake
     */
    public int getInfectScope()
    {
        return SNAKE_INFECT_SCOPE;
    }
    
    /**
     * A getter for the sick probability
     */
    public double getSickProbability()
    {
        return SICK_PROBABILITY;
    }
    
    /**
     * A getter for the infect probability
     */
    public double getInfectProbability()
    {
        return INFECT_PROBABILITY;
        }
}