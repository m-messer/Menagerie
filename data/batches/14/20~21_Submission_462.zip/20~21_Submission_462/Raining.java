
/**
 * Grass will grow faster at a raining dday
 *
 * @version 2021/02/11
 */
public class Raining extends Weather
{
    /**
     * Construct the grass state in Raining weather.
     */
    public Raining()
    {
        super("Raining",2, 2000);
    }
}
