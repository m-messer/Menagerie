
/**
 * This class is the super class of all weather.
 * Weather effect the growth rate and max amount of plants
 * @version 2021/02/11
 */
public class Weather
{
    private String weatherName;
    private int growthRate;
    private int amount;
    
    /**
     * Create a new weather with weather name.
     * The growthRate and amount of grass.
     * 
     * @param weatherName The weather name of the weather
     * @param growthRate The growth rate of grass in the weather.
     * @param amount The amount of grass in the weather.
     */
    public Weather(String weatherName, int growthRate, int amount)
    {
        this.weatherName = weatherName;
        this.growthRate = growthRate;
        this.amount = amount;
    }
    
    /**
     * Return the weather name.
     */
    public String getWeatherName()
    {
        return weatherName;
    }
    
    /**
     *  Return the growth rate of grass.
     */
    public int getGrowthRate()
    {
        return growthRate;
    }
    
    /**
     * Return the amount of grass.
     */
    public int getAmount()
    {
        return amount;
    }
}
