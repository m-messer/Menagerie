import java.util.*;
import java.awt.Color;
import java.util.Iterator;
/**
 * This class initialize the field of animals
 *
 * @2021/02/18
 */
public class FieldSetter
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;
    // The probability that a Owl will be created in any given grid position.
    private static final double OWL_CREATION_PROBABILITY = 0.012;
    // The probability that a Rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.12;    
    // The probability that a Frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.114;
    // The probability that a Snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.08;
    // The probability that a Worm will be created in any given grid position.
    private static final double WORM_CREATION_PROBABILITY = 0.20;            
    // The probability that a Bird will be created in any given grid position.
    private static final double BIRD_CREATION_PROBABILITY = 0.1514;    
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public FieldSetter()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public FieldSetter(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Worm.class, Color.PINK);
        view.setColor(Snake.class, Color.CYAN);
        view.setColor(Owl.class, Color.BLACK);
        view.setColor(Rabbit.class, Color.RED);
        view.setColor(Bird.class, Color.YELLOW);
        view.setColor(Frog.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
        //runLongSimulation();
    }
    
    /**
     * Clear existing animals and re-randomly populate animals. 
     * Reset weather and time.
     */
    public void reset()
    {
        animals.clear();
        populate();
        view.showStatus(0, field,"Day", "Sunny", 1000, 0);
    }
    
    /**
     * Randomly populate the field with Owls, Rabbits, Frogs, Birdï¼Snakes and Worms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl= new Owl(true, field, location);
                    animals.add(owl);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    animals.add(frog);
                }
                else if(rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bird bird = new Bird(true, field, location);
                    animals.add(bird);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= WORM_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Worm worm = new Worm(true, field, location);
                    animals.add(worm);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * There is a chance to randomly spawn new animals 
     * when there is a space in the field.
     */
    public void introNewAnimals()
    {
        Random rand = Randomizer.getRandom();
        for(Location location : field.findEmptyLocationAtEdge()) {
            if(rand.nextDouble() <= 0.00012) {
                Owl owl= new Owl(true, field, location);
                animals.add(owl);
            }
            else if(rand.nextDouble() <= 0.0012) {
                Rabbit rabbit = new Rabbit(true, field, location);
                animals.add(rabbit);
            }
            else if(rand.nextDouble() <= 0.00114) {
                Frog frog = new Frog(true, field, location);
                animals.add(frog);
            }
            else if(rand.nextDouble() <= 0.001514) {
                Bird bird = new Bird(true, field, location);
                animals.add(bird);
            }
            else if(rand.nextDouble() <= 0.0008) {
                Snake snake = new Snake(true, field, location);
                animals.add(snake);
            }
            else if(rand.nextDouble() <= 0.002) {
                Worm worm = new Worm(true, field, location);
                animals.add(worm);
            }
        }
    }
    
    /**
     * Returns a list of all animals
     */
    public List getAnimalList()
    {
        return animals;
    }
    
    /**
     * Display step, field,dayOrNight, weather, grassAmount,
     * infectedNumber on the GUI
     */
    public void setInformation(int step, String dayOrNight, String weather
    , int grassAmount, int infectedNumber)
    {
        view.showStatus(step, field,dayOrNight, weather, grassAmount,
        infectedNumber);
    }
    
    /**
     * Return whether or not it is visible.
     */
    public boolean isViable()
    {
        return view.isViable(field);
    }
    
    /**
     * Returns the field of the animal.
     */
    public Field getField()
    {
        return field;
    }
}
