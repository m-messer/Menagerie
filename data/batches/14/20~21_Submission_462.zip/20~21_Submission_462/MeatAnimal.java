import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of meat animals.
 *
 * @version 2021.02.16
 */
public abstract class MeatAnimal extends Animal
{
    
    /**
     * Create a new meat animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public MeatAnimal(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this meat animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param time Current time.
     */
    abstract public void act(List<Animal> newAnimals, int time);
}
