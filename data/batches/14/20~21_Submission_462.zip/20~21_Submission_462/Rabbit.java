import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2021.02.16
 */
public class Rabbit extends GrassAnimal
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    private static final int GRASS_FOOD_VALUE = 4;
    // Individual characteristics (instance fields).

    //The possibility of rabbits getting sick
    private static final double SICK_PROBABILITY = 0.004;
    //The possibility of rabbits getting infect
    private static final double INFECT_PROBABILITY = 0.015;
    
    private static final int RABBIT_SICK_AGE = 5;
    private static final int RABBIT_INFECT_SCOPE = 1;

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setMaxAge(MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(GRASS_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(GRASS_FOOD_VALUE);
        }
    }

    /**
     * This is what the rabbit does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param time Current time.
     * @param newRabbits A list to return newly born rabbits.
     * @param grass Grass can be eaten.
     */
    public void act(List<Animal> newRabbits, int time, Grass grass)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect();
            if(isAlive()) {
                if(time <= 3) {
                    giveBirth(newRabbits);   
                    findFood(grass);
                    // Try to move into a free location.
                    Location newLocation = getField().freeAdjacentLocation(getLocation());
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }}
            }
        }
    }

    /**
     * Look for Grass.
     * @param grass Grass that exist.
     */
    public void findFood(Grass grass)
    {
        if(grass.canBeEaten()) {
            grass.getEat();
            setFoodLevel(GRASS_FOOD_VALUE);
        }
    }

    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    private void giveBirth(List<Animal> newRabbits)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rabbit young = new Rabbit(false, field, loc);
            newRabbits.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),3);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive() && !(this.isMale() && rabbit.isMale())&& this.getAge() >= BREEDING_AGE && rabbit.getAge() >= BREEDING_AGE) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * A getter for the sick age of rabbit
     */
    public int getSickAge()
    {
        return RABBIT_SICK_AGE;
    }
    
    /**
     * A getter for the scope infected by the rabbit
     */
    public int getInfectScope()
    {
        return RABBIT_INFECT_SCOPE;
    }
    
    /**
     * A getter for the sick probability
     */
    public double getSickProbability()
    {
        return SICK_PROBABILITY;
    }
    
    /**
     * A getter for the infect probability
     */
    public double getInfectProbability()
    {
        return INFECT_PROBABILITY;
    }
}
