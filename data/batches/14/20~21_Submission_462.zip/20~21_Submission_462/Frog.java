import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a frog.
 * Frog age, move, eat worns, and die.
 *
 * @version 2021.2.9
 */
public class Frog extends MeatAnimal
{
    // Characteristics shared by all frogs (class variables).

    // The age at which a frog can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a frog can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a frog breeding.
    private static final double BREEDING_PROBABILITY = 0.44;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single worn. In effect, this is the
    // number of steps a frog can go before it has to eat again.
    private static final int WORM_FOOD_VALUE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The possibility of frogs getting sick
    private static final double SICK_PROBABILITY = 0.004;
    //The possibility of frogs getting infect
    private static final double INFECT_PROBABILITY = 0.015;

    private static final int FROG_SICK_AGE = 5;
    private static final int FROG_INFECT_SCOPE = 1;

    /**
     * Create a frog. A frog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the frog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setMaxAge(MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(WORM_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(WORM_FOOD_VALUE);
        }
    }

    /**
     * This is what the frog does most of the time: it hunts for
     * worms. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param time Current time.
     * @param newFroges A list to return newly born frogs.
     */
    public void act(List<Animal> newFrogs, int time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect();
            if(isAlive()) {
                if(time <= 3) {
                    giveBirth(newFrogs);
                    // Move towards a source of food if found.
                    Location newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Look for worms adjacent to the current location.
     * Only the first live worm is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Worm) {
                Worm worm = (Worm) animal;
                if(worm.isAlive()) { 
                    worm.setDead();
                    setFoodLevel(WORM_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this frog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFrogs A list to return newly born frog.
     */
    private void giveBirth(List<Animal> newFrogs)
    {
        // New frogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Frog young = new Frog(false, field, loc);
            newFrogs.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A frog can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),3);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isAlive() && !(this.isMale() && frog.isMale())&& this.getAge() >= BREEDING_AGE && frog.getAge() >= BREEDING_AGE) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * A getter for the sick age of frog
     */
    public int getSickAge()
    {
        return FROG_SICK_AGE;
    }
    
    /**
     * A getter for the scope infected by the frog
     */
    public int getInfectScope()
    {
        return FROG_INFECT_SCOPE;
    }
    
    /**
     * A getter for the sick probability
     */
    public double getSickProbability()
    {
        return SICK_PROBABILITY;
    }
    
    /**
     * A getter for the infect probability
     */
    public double getInfectProbability()
    {
        return INFECT_PROBABILITY;
    }
}
