import java.util.Random;
import java.util.ArrayList;
/**
 * This class stimulate the weather, weather is going to 
 * affect the amount and growth of grass
 *
 * @version 2021/2/17
 */
public class WeatherStimulator
{
    // The current state of the weather.
    private Weather weather;
    private ArrayList<Weather> weathers;
    
    public WeatherStimulator()
    {
        weathers = new ArrayList<>();
        Weather raining = new Raining();
        Weather dry = new Dry();
        Weather sunny = new Sunny();
        weathers.add(raining);
        weathers.add(dry);
        weathers.add(sunny);
    }
    
    /**
     * Select a weather at random and return.
     * @return A weather object.
     */
    private Weather randWeather()
    {
        Random rand = new Random();
        int num = rand.nextInt(weathers.size());
        return weathers.get(num);
    }
    
    /**
     * Set the current weather to the random weather
     * @param grass, the current grass field
     */
    public void setWeather(Grass grass)
    {
        weather = randWeather();
        grass.setGrowthRate(weather.getGrowthRate());
        grass.setMaxAmount(weather.getAmount());
    }

    /**
     * return the current weather
     */
    public Weather getCurrentWeather()
    {
        return weather;
    }
}
