import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a bird.
 * Bird age, move, eat worns, and die.
 *
 * @version 2021.2.9
 */
public class Bird extends MeatAnimal
{
    // Characteristics shared by all birds (class variables).

    // The age at which a bird can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a bird can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a bird breeding.
    private static final double BREEDING_PROBABILITY = 0.44;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single worn. In effect, this is the
    // number of steps a bird can go before it has to eat again.
    private static final int WORM_FOOD_VALUE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The possibility of birds getting sick
    private static final double SICK_PROBABILITY = 0.004;
    //The possibility of birds getting infect
    private static final double INFECT_PROBABILITY = 0.0015;

    private static final int BIRD_SICK_AGE = 5;
    private static final int BIRD_INFECT_SCOPE = 1;
    
    // Individual characteristics (instance fields).

    /**
     * Create a bird. A bird can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the bird will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bird(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setMaxAge(MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(WORM_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(WORM_FOOD_VALUE);
        }
    }

    /**
     * This is what the bird does most of the time: it hunts for
     * worms. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param time Current time.
     * @param newBirds A list to return newly born Birds.
     */
    public void act(List<Animal> newBirds, int time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect();
            if(isAlive()) {
                if(time <= 3) {
                    giveBirth(newBirds);  
                    // Move towards a source of food if found.
                    Location newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Look for worms adjacent to the current location.
     * Only the first live worm is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Worm) {
                Worm worm = (Worm) animal;
                if(worm.isAlive()) { 
                    worm.setDead();
                    setFoodLevel(WORM_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this bird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born bird.
     */
    private void giveBirth(List<Animal> newBirds)
    {
        // New birds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bird young = new Bird(false, field, loc);
            newBirds.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A bird can breed if it has reached the breeding age.
     * @return Whether the bird can breed.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),3);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bird) {
                Bird bird = (Bird) animal;
                if(bird.isAlive() && !(this.isMale() && bird.isMale())&& this.getAge() >= BREEDING_AGE && bird.getAge() >= BREEDING_AGE) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * A getter for the sick age of bird
     */
    public int getSickAge()
    {
        return BIRD_SICK_AGE;
    }
    
    /**
     * A getter for the scope infected by the bird
     */
    public int getInfectScope()
    {
        return BIRD_INFECT_SCOPE;
    }
    
    /**
     * A getter for the sick probability
     */
    public double getSickProbability()
    {
        return SICK_PROBABILITY;
    }
    
    /**
     * A getter for the infect probability
     */
    public double getInfectProbability()
    {
        return INFECT_PROBABILITY;
    }
}
