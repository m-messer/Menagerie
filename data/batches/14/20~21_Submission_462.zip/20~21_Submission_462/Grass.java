
/**
 * Rabbit eat grass, they will die if they don't eat grass for a certain time.
 * grass has a growth rate which depends on the weather
 * the maxAmount of grass also depends on the weather
 * growth rate indicate how long it takes grass to become eatable by rabbits.
 *
 * @version 2021/02/11
 */
public class Grass
{
    private int growthRate;
    private int growth;
    private int maxAmount;
    private int amount;
    /**
     * Construct grass.
     */
    public Grass()
    {
        amount = 1000;
        maxAmount = 1000;
        growth = 0;
        growthRate = 4;
    }
    
    /**
     * Set growth rate for grass.
     */
    public void setGrowthRate(int growthRate)
    {
        this.growthRate = growthRate;
    }
    
    /**
     * The grass can be eaten by the rabbit,
     * the amount of grass will decrease each time the rabbit ate
     * When the last grass is eaten, the growth is set to zero
     */
    public void getEat()
    {
        amount --;
        if(amount == 0) growth = 0;
        return;
    }
    
    /**
     * If the growth of grass is lower than growth rate.
     * It increase the growth.
     * If the growth of grass is higher than or equal to growth rate.
     * The grass amount will equal to max amount.
     */
    public void growth()
    {
        growth++;
        if(growth >= growthRate) {
            amount = maxAmount;        
        }
    }
    
    /**
     * If there exist grass,grass can be eaten
     * @return Whether there has grass can be eaten.
     */
    public boolean canBeEaten()
    {
        return amount > 0;
    }
    
    /**
     * @return the amount of grass.
     */
    public int getAmount()
    {
        return amount;
    }
    
    /**
     * Set the max amount of grass.
     */
    public void setMaxAmount(int amount) 
    {
        maxAmount = amount;
    }
}
