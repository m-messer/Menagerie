import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.02.16
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //The animal's sex
    private boolean isMale;
    // Whether the animal is sick.
    private boolean isInfected;
    // Each animal's age.
    private int age;
    // Whether the animal can act.
    private boolean canAct;
    // The animal's food level, which is increased by eating worms.
    private int foodLevel;
    // The max age of the animal.
    private int max_age;
    
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        Random random = new Random();
        isMale = random.nextBoolean();
        isInfected = false;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * An accessor for animal's sex
     * @return  whether it is a male
     */
    protected boolean isMale()
    {
        // put your code here
        return isMale;
    }

    /**
     * An accessor for animal's age
     * @return  animal's age
     */
    protected int getAge()
    {
        return age;
    }
    
    protected void caughtDiease()
    {
        isInfected = true;
    }
    
    /**
     * An accessor for whether animal is sick
     * @return  whether it is sick
     */
    protected boolean getIsSick()
    {
        return isInfected;
    }
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > max_age) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * A setter for max age
     */
    protected void setMaxAge(int age)
    {
        max_age = age;
    }
    
    /**
     * A setter for age
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * A setter for foodLevel
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }
    
    /**
     * If meat animal are over sick_age years old, 
     * there is a certain chance they will get sick. 
     * @param sick_age The age at which animals can get sick
     * @param sick_probability The possibility of disease in the animal.
     */
    protected void getSick(int sick_age, double sick_probability)
    {
        if(this.getAge() > sick_age && rand.nextDouble() <= sick_probability) {
            caughtDiease();
        }
    }
    
    /**
     * If meat animal are over sick_age years old, 
     * and there is a sick animal around, 
     * there is a chance that it will become infected.
     * @param sick_age The age at which animals can get sick
     * @param infect_probability The possibility of infect in the animal.
     * @param scope Search the area of nearby animals.
     */
    protected void getInfected(int sick_age, int scope, double infect_probability)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),scope);
        Iterator<Location> it = adjacent.iterator();
        int sickAnimal = 0;
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal realAnimal = (Animal)animal;
                if(realAnimal.getIsSick()){
                    sickAnimal ++;
                }
            }
        }
        if(getAge() > sick_age && rand.nextDouble() <= infect_probability * sickAnimal) {
            caughtDiease();
        }
    }
    
    /**
     * A getter for the sick age of animal
     */
    protected abstract int getSickAge();
    
    /**
     * A getter for the scope that the diease will spread
     */
    protected abstract int getInfectScope();
    
    /**
     * A getter for the infect probability
     */
    protected abstract double getInfectProbability();
    
    /**
     * A getter for the sick probability
     */
    protected abstract double getSickProbability();
    
    /**
     * When an animal is not sick, there is a chance it will get sick 
     * or be infected by other sick animals around it.
     * If an animal is sick, there is a good chance it will die.
     */
    protected void infect()
    {
        if (!getIsSick()){
            getSick(getSickAge(), getSickProbability());
        }
        if (!getIsSick()){
            getInfected(getSickAge(), getInfectScope(), getInfectProbability());
        }
        if(getIsSick()){
            if(rand.nextDouble() > 0.8) {
                setDead();
            }
        }
        return;
    }
}
