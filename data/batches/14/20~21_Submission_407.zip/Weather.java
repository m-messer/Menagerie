import java.util.Random;


/**
 * This is an enum class representing weather
 */
public enum Weather {
    RAIN("Rain"), SUNNY("Sunny");
    //The probability of raining
    private static double RAIN_PROBABILITY = 0.5;
    private String name;
    //Generate random number
    protected static final Random rand = Randomizer.getRandom();

    Weather (String name){
        this.name =name;
    }

    /**
     * Change the weather using rain probability
     */
    public static Weather changeWeather()
    {
        if(rand.nextDouble() < RAIN_PROBABILITY)
        {
            return RAIN;
        }
        else {
            return SUNNY;
        }
    }
}
