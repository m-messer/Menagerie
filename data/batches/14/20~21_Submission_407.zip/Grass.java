import java.util.List;
/**
 * A simple model of Grass.
 * Grass age, breed, grow and die.
 *
 * @version 2021.03.01
 */
public class Grass extends Plant
{
    //The maximum grow size a plant can have
    private static final int MAX_GROW_SIZE = 2;

    //The probability that a plant can grow
    private static final double GROWING_PROBABILITY = 0.049;

    //
    //private static final int BREEDING_WATER_LEVEL = 2;

    /**
     * The constructor of Grass class
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
    }


    @Override
    /**
     * This is plant behaviour and what they do most of the time
     * @param newGrass A list to return all the new born grass
     */
    public void act(List<Actor> newGrass,Weather weather)
    {
        switch (weather){
            case RAIN:
                increaseWaterLevel(getWaterLevel());
            case SUNNY:
                decreaseWaterLevel(getWaterLevel());
                break;
            default:
                break;
        }
        if(isActive()){
            growPlant(newGrass);
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }

        }


    /**
     * Grows a new plant when this method is called
     * @param newGrass A list to return all the new born grass
     */
    protected void growPlant(List<Actor> newGrass)
    {
        Field field = getField();
        int birth = grow();
        int count = 0;
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        for(int b = 0; b < birth && free.size() > 0; b ++) {
            Location loc = free.remove(0);
            Plant young = new Grass(field, loc);
            newGrass.add(young);
            count+=1;
        }
    }

    /**
     * Getter method
     * Returns the growing probability
     */
    protected double getGrowingProbability()
    {
        return GROWING_PROBABILITY;
    }
    /**
     * Getter method
     * Returns the Max growing size
     */
    protected int getMaxGrowSize()
    {
        return MAX_GROW_SIZE;
    }
}
