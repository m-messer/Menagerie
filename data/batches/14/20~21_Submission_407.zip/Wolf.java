import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a wolf.
 * Wolfs age, move, eat rabbits, and die.
 *
 * @version 2021.03.01
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolfs (class variables).
    
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 15;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.278;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 17;
    // The fax distinguishes male and female.
    private static final double GENDER_PROBABILITY = 0.5;
    
    // Individual characteristics (instance fields).
    // The wolf's age.
    private int age;
    // The wolf's food level, which is increased by eating rabbits.
    private int foodLevel;
    // The death probability of animals when gets affected with disease;
    private double LETHALITY_RATE = 0.65;
    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        generateRandomGender();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the wolf does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newWolfs A list to return newly born wolfes.
     */
    public void act(List<Actor> newWolfs, Weather weather)
    {
        incrementAge();
        incrementHunger();
        infectOthers();
        deathByInfection();
        heal();
        if(isActive()) {
            giveBirth(newWolfs);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Make this wolf more hungry. This could result in the wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for deer adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = getAdjacentLocation();
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isActive()) {
                    deer.setDead();
                    foodLevel += 6;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolfs A list to return newly born wolf
     */
    private void giveBirth(List<Actor> newWolfs)
    {
        // New wolfs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Boolean isMeet = false;
        Field field = getField();
        List<Location> adjacent = getAdjacentLocation();
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            if(where != null)
            {
                Object surroundingAnimal = field.getObjectAt(where);
                if(surroundingAnimal != null && surroundingAnimal instanceof Wolf) {
                    Wolf mate = (Wolf) surroundingAnimal;
                    if(this.getGender() != mate.getGender()) {
                        int birth = breed();
                        for(int b = 0; b < birth && freeLocationList().size() > 0; b ++) {
                            if(freeLocationList().size() == 0) {
                                break;
                            }
                            Location loc = freeLocationList().remove(0);
                            Wolf young = new Wolf(false, field, loc);
                            generateRandomGender();
                            newWolfs.add(young);
                        }
                    }
                }
            }
        }
    }

    /**
     * @return Food level of an animal
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * Getter method
     * @return the age the animal can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Getter method
     * @return Maximun age a animal can be
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Getter method
     * @return breeding probability
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Getter method
     * @return MaxLitterSize
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Getter method
     * @return the propability to be in a gender
     */
    protected double getGenderProbability()
    {
        return GENDER_PROBABILITY;
    }

    /**
     * Get the adjacent location
     * @return the location
     */
    protected List<Location> getAdjacentLocation()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        return adjacent;
    }
    
    /**
     * Get the death probability of disease
     * @return the double lethality rate
     */
    protected double getLethalityRate()
    {
        return LETHALITY_RATE;
    }
}
