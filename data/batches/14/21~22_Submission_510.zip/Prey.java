import java.util.List;
import java.util.Iterator;
/**
 * A class representing the shared characteristics of
 * prey.
 *
 * @version (1.01)  
 */

public abstract class Prey extends Animal 
{
    /**
     * Constructor for objects of class Prey
     */
    public Prey (boolean randomAge, Field field, Location location, double randomGender)
    {
        super(randomAge, field, location, randomGender);
    }

    /**
     * Look for food (plants) adjacent to the current location.
     * Only the first live animal of the right type is eaten.
     * @return Where food was found, or null if it wasn't.
     */    
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plants) {
                Plants plant = (Plants) animal;
                if(plant.isAlive()) { 
                    foodLevel = plant.getFoodValue(); //get the food value of the plant being eaten 
                    plant.setDead();
                    return where; 
                }
            }
        }
        return null;
    }
    
    /**
     * Just like i used it for Plants class. 
     * This is future implementation where i would have made weather affect how the prey can find its food
     */
    protected void getWeather(String currentWeather)
    {
        
    }

}