import java.util.Random;
/**
 * A class concerned with determining the current weather. 
 *
 * @version (1.01)
 */
public class Weather
{
    //probability of it raining
    private static final double CHANCE_OF_RAIN = 0.15;
    //probability of it being cloudy
    private static final double CHANCE_OF_CLOUDY = 0.60;
    //probability of it being sunny
    private static final double CHANCE_OF_SUN = 0.25;
    
    //random number generator to control weather   
    private static final Random rand = Randomizer.getRandom();
    //the current weather in the simulation 
    private String currentWeather;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        // initialise instance variables
        currentWeather = "";
    }

    /**
     * using random generator we determine the weather by checking against our probabilities
     */
    public void determineWeather()
    {
        double probability = rand.nextDouble();

        if (probability <= CHANCE_OF_RAIN)
        {
            currentWeather = "Rainy";
        }
        else if (probability <= CHANCE_OF_SUN)
        {
            currentWeather = "Sunny";
        }
        else if (probability <= CHANCE_OF_CLOUDY)
        {
            currentWeather = "Cloudy";
        }
    }

    /**
     * @return the current weather
     */
    public String getWeather()
    {
        return currentWeather;
    }
    
    /**
     * returns empty weather variable
     */
    public String clearWeather()
    {
        currentWeather = "";
        return currentWeather;
    }

}