import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Write a description of class Plants here.
 *
 * @version (a version number or a date)
 */
public class Plants extends Animal
{
    // instance variables - replace the example below with your own
    private int age;
    private static final int MAX_AGE = 100;
    private static final int BREEDING_AGE = 3;
    private static final double BREEDING_PROBABILITY = 0.20;
    private static final int MAX_LITTER_SIZE = 4;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Plants
     */
    public Plants(boolean randomAge, Field field, Location location)
    {
        // initialise instance variables
        super(field,location);
        age = 0 ;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    public void act(List<Animal> newPlants)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newPlants);            
            // Try to move into a free location.
            // Location newLocation = getField().freeAdjacentLocation(getLocation());
            // if(newLocation != null) {
                // setLocation(newLocation);
            // }
            // else {
                // // Overcrowding.
                // setDead();
            // }
        }  
    }
    
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE){
            setDead();
        }
    }
    
    private void giveBirth(List<Animal> newPlants)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plants offspring = new Plants(false, field, loc);
            newPlants.add(offspring);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}



