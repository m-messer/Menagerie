import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A model of a bear. This class represents a bear's actions,
 * and also returns important information associated with each
 * bear object.
 * Bears age, move, breed, eat moose and rabbits, and die.
 *
 * @version (1.01)
 */
public class Bear extends Predator
{
    // Characteristics shared by all bears (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a fox can live.
    private static final int MAX_AGE = 45;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.175; 
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;

    // A shared random number generator to control breeding.
    //private static final Random rand = Randomizer.getRandom();

    /**
     * Create a bear. A bear can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the bear will have random age 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of bear

     */
    public Bear(boolean randomAge, Field field, Location location, double randomGender)
    {
        super(randomAge, field, location, randomGender);
    }

    /**
     * This is what the bears does most of the time: it hunts for
     * rabbits and moose. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied and the time in the simulation
     * @param newBears A list to return newly born bear.
     * @param clock the current time in the simulation 

     */
    public void act(List<Animal> newBears, ClockDisplay clock)
    {
        if (clock.checkIfMorning(clock.getHour())) //in the morning bears will act, else they will stay still and sleep, they do not get hungry or age whilst sleeping
        {
            incrementAge();
            incrementHunger();
            if(isAlive()) {
                giveBirth(newBears);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Creates new bear, used to create bear offspring in breeding 
     * @param randomAge if true we give fix random age, else we make age 0
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of bear 
     * @return Animal - return the newly created bear
     */    
    protected Animal createNewAnimal(boolean randomAge, Field field, Location location, double randomGender)
    {
        Animal young = new Bear(false, field, location, randomGender);
        return young;
    }    

    /**
     * @return the max age of the bear (age it can live up to )
     */ 
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return the breeding age of the bear
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return the maximum size of offspring the bear can reproduce
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the breeding probability of the bear
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

}