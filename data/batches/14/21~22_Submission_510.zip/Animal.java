import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //if animal is infected
    private boolean isAnimalInfected;
    //creates infection link
    private Infection newInfection;
    //the sex of animal
    protected String gender;
    //the hunger level of animal
    protected int foodLevel;
    //age of animal 
    protected int age;

    // A shared random number generator to control breeding, infections, gender and other probabiilties
    protected static final Random rand = Randomizer.getRandom();
    //the probability of getting either gender for an animal
    private static final double GENDER_PROBABILITY = 0.50;
    //initial food value that all animals start with 
    private static final int INITIAL_FOOD_VALUE = 5;

    /**
     * Create a new animal at location in field.
     * @param randomAge if true we give animal random age, else we make age 0
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of animal 
     */
    public Animal(boolean randomAge, Field field, Location location, double randomGender)
    {
        //initialisations
        alive = true;
        this.field = field;
        setLocation(location);
        newInfection = new Infection();
        isAnimalInfected = false;
        setGender(randomGender);
        foodLevel = INITIAL_FOOD_VALUE;
        if(randomAge) {
            age = rand.nextInt(getMaxAge()); //random number between the max age of the animal
        }
        else {
            age = 0;
        }
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, ClockDisplay clock);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animals's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        // New mooses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = 0;
        if (checkForOppositeGender()){ //if there are opposite genders in adjacent locations
            births = breed(); //we are able to breed
        }

        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = createNewAnimal(false, field, loc, rand.nextDouble()); //creates animal of its own species
            newAnimals.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * A animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * changes the animal infected status 
     * @param is whether the animal is infected
     */
    protected void changeInfectionofAnimal(boolean infectedCheck)
    {
        isAnimalInfected = infectedCheck;
    }

    /**
     * cheks to see if infection is on/off and checks to see if animal is infected
     * if it is then we check if it has reached the probability to die off or if tehy have survived the infection
     */
    protected void infection(boolean infectionState)
    {
        if((infectionState) && (newInfection.checkIfInfected()))
        {
            isAnimalInfected = true;
            if(newInfection.checkIfDead())
            {
                setDead();
            }
            else if(newInfection.checkIfInfectionGone())
            {
                isAnimalInfected = false;
            }
        }
    }

    /**
     * sets the gender of the animal 
     * @param a random double value that is used to choose 
     * between male and female
     */
    protected void setGender(double randomGender)
    {
        if (randomGender <= GENDER_PROBABILITY)
        {
            gender = "male";
        }
        else 
        {
            gender = "female";
        }
    }

    /**
     * Check for the opposite gender
     * @return true if there is a opposite gender in an adjacent location 
     */
    protected boolean checkForOppositeGender()
    {
        if (this.getClass().getName().equals("Plants")) //as plants do not need partners to reproduce
        {
            return true; //we make this true instantly 
        }
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) 
            {
                Animal adjacentAnimal = (Animal) animal;
                if ((adjacentAnimal.getClass().equals(this.getClass()))) { //if the aniaml in the adjacent location is the same species as the one being compared
                    if (adjacentAnimal.getGender().equals(this.getGender())) //if they are the same gender
                    {
                        return false;// then we return false as they need to be opposite genders
                    }
                    else{
                        return true; //if they are not the same we return true

                    }
                }
            }
        }
        return false;
    }

    /**
     * @return gender of animal 
     */
    protected String getGender()
    {
        return gender;
    }

    abstract protected int getMaxAge();

    abstract protected int getBreedingAge();
    
    abstract protected int getMaxLitterSize();

    abstract protected double getBreedingProbability();
    
    /**
     * Creates new animal, used to create animal offspring in breeding 
     * @param randomAge if true we give animal random age, else we make age 0
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of animal 
     * @return Animal - return the newly created animal 
     */
    abstract protected Animal createNewAnimal(boolean randomAge, Field field, Location location, double randomGender);
    
    /**
     * get current Weather of simulation if it is turned on 
     */
    abstract protected void getWeather(String currentWeather);
  
}