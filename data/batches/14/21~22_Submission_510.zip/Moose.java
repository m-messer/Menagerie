import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A model of a moose. This class represents a moose's actions,
 * and also returns important information associated with each
 * moose object.
 * Moose age, move, breed, eat plants, and die.
 *
 * @version (1.01)
 */
public class Moose extends Prey
{
    // Characteristics shared by all mooses (class variables).

    // The age at which a moose can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a moose can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a moose breeding.
    private static final double BREEDING_PROBABILITY = 0.50;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    //private static final Random rand = Randomizer.getRandom();


    /**
     * Create a new Moose. A Moose may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of moose
     */
    public Moose(boolean randomAge, Field field, Location location, double randomGender)
    {
        super(randomAge, field, location, randomGender);

    }

    /**
     * This is what the moose does most of the time - it runs 
     * around. Sometimes it will breed or die of old age. Looks to eat plants.
     * @param newMoose A list to return newly born moose and the time in the simulation.
     * @param clock the current time in the simulation 
     */
    public void act(List<Animal> newMoose, ClockDisplay clock)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newMoose);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Creates new animal, used to create animal offspring in breeding 
     * @param randomAge if true we give animal random age, else we make age 0
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of animal 
     * @return Animal - return the newly created animal 
     */
    protected Animal createNewAnimal(boolean randomAge, Field field, Location location, double randomGender)
    {
        Animal young = new Moose(false, field, location, randomGender);
        return young;
    }

    /**
     * @return the max age of the moose (age it can live up to )
     */        
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return the breeding age of the moose
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return the maximum size of offspring the moose can reproduce
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the breeding probability of the moose
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

}