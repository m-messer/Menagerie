import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A predator-prey simulator, based on a rectangular field
 * containing plants, rabbits, moose, foxes and bears.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 160;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.04;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.06;  
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.50;
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.04;
    // The probability that a moose will be created in any given grid position.
    private static final double MOOSE_CREATION_PROBABILITY = 0.05;
    //random number generator 
    private static final Random rand = Randomizer.getRandom();
    //whether infections are on or off
    private boolean infectionState = false;
    //whether wather is on or off
    private boolean weatherState = false;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //simulation time
    private ClockDisplay clock;
    ///weather for simulation
    private Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        
        animals = new ArrayList<>();
        field = new Field(depth, width);
        clock = new ClockDisplay();
        
        weather = new Weather();
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Plants.class, Color.GREEN);
        view.setColor(Bear.class, Color.YELLOW);
        view.setColor(Moose.class, Color.PINK);

        //Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1440 steps).
     */
    public void runLongSimulation()
    {
        simulate(1440);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 0; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(10);   // uncomment this to run more slowly
        }
    }

    /** 
     * Linked to tick boxes of GUI.
     * States whether the user once to run infection in the simulation or not
     */
    public void toggleInfection()
    {
        infectionState = !infectionState;
    }

    /** 
     * Linked to tick boxes of GUI.
     * States whether the user once to run weather in the simulation or not
     */
    public void toggleWeather()
    {
        weatherState = !weatherState;
        weather.clearWeather();
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        clock.timeTick(); //adds a minute to the time
        checkIfDark();  //checks if night time
        checkWeather();  //checks if user has turned on weather functionality
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, clock);
            if (infectionState) //if infection is on 
            {
                animal.infection(infectionState); //call infection  method in animal
            }
            if (weatherState)
            {
                animal.getWeather(weather.getWeather());
            }

            if(!animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field, clock.getTime(), weather.getWeather());
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        clock.resetTime();
        weather.clearWeather();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, clock.getTime(), weather.getWeather());
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true,field, location, rand.nextDouble());
                    animals.add(fox);

                }
                if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location, rand.nextDouble());
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plants plant = new Plants(true, field, location, rand.nextDouble());
                    animals.add(plant);
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true,field, location, rand.nextDouble());
                    animals.add(bear);
                }
                else if(rand.nextDouble() <= MOOSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Moose moose = new Moose(true, field, location, rand.nextDouble());
                    animals.add(moose);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Check if simulation has hit the time for when it goes dark
     * if it has, GUI empty spaces goes black
     * if not (signalling morning) empty spaces go to white
     */
    private void checkIfDark()
    {
        if (clock.checkIfMorning(clock.getHour()))
        {
            view.changeToWhite();
        }
        else
        {
            view.changeToBlack();
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Check if weather has been toggled on by the user.
     * If it has we start changing the weather through probability
     */
    private void checkWeather()
    {
        if(weatherState)
        {
            weather.determineWeather();

        }
    }
    
}
