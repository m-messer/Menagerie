import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A model of a fox. This class represents a fox's actions,
 * and also returns important information associated with each
 * fox object.
 * Foxes age, move, breed, eat rabbits, and die.
 *
 * @version (1.01)
 * @version 2016.02.29 (2)
 */
public class Fox extends Predator
{
    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a fox can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.85;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of plant 
     */
    public Fox(boolean randomAge, Field field, Location location, double randomGender)
    {
        super(randomAge, field, location, randomGender);
    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes and the time in the simulation
     * @param clock the current time in the simulation 

     */
    public void act(List<Animal> newFoxes, ClockDisplay clock)
    {
        if (!(clock.checkIfMorning(clock.getHour()))){
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            Location newLocation = checkIfFoxCanHunt(clock);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }

        }
        }
    }   

    /**
     * Creates new Fox, used to create animal offspring in breeding 
     * @param randomAge if true we give fix random age, else we make age 0
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of fox 
     * @return Animal - return the newly created fox
     */
    protected Animal createNewAnimal(boolean randomAge, Field field, Location location, double randomGender)
    {
        Animal young = new Fox(false, field, location, randomGender);
        return young;
    }

    /**
     * checks to see if it is the correct time of day for the fox to be able to hunt 
     * its prey
     * @return location of its prey or null if its not the correct time 
     */

    private Location checkIfFoxCanHunt(ClockDisplay clock)
    {
        Location newLocation = null;
        if (!(clock.checkIfMorning(clock.getHour()))){//checks to see if it is night as foxs can only hunt during the nihgt
            //System.out.println("fox moves to new lcoation");
            newLocation = findFood();
        }
        else{
            newLocation = null;
        }
        return newLocation ;
    }

    /**
     * @return the max age of the fox (age it can live up to )
     */  
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return the breeding age of the fox
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return the maximum size of offspring the fox can reproduce
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the breeding probability of the fox
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
}