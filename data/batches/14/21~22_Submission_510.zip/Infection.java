import java.util.List;
import java.util.Random;
/**
 * A class concerned with the status of an organism's health
 * in terms of infection. 
 *
 * @version (1.01)
 */
public class Infection
{
    //probability of animal becoming infected
    private static final double CHANCE_OF_INFECTION = 0.20;
    //probabily of animal's death once infected
    private static final double CHANCE_OF_DEATH = 0.20;
    //probability of an infected animal spreading the infection to another animal of the same type 
    private static final double CHANCE_OF_CONTRACTION = 0.25;
    //how long infection lasts for
    private static final int LENGTH_OF_INFECTION = 3;
    //counts how long animal has been infected for
    private int daysOfInfection;

    //random number generator to control infection rates and deaths
    public static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Infection
     */
    public Infection()
    {
        // initialise instance variables
        daysOfInfection = 0;
    }

    /**
     * checks if the animal is animal will die from infection
     * @return true, if the infection will kill the animal
     * if not then we increase counter by one
     */
    public boolean checkIfDead()
    {
        if(rand.nextDouble() <= CHANCE_OF_DEATH)
        {
            return true;
        }
        else
        {
            daysOfInfection++;
            return false;
        }
    }

    /**
     * checks if animal will be infected from the infection
     * @return true, if animal will be infected
     * if not then we leave them be 
     */
    public boolean checkIfInfected()
    {
        if(rand.nextDouble() <= CHANCE_OF_INFECTION)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * if the animal has not died from the infection then we check if the infection has left the animal
     * we check the daysOfInfection against the length of infecition 
     * @return true if infection has left animal
     */
    public boolean checkIfInfectionGone()
    {
        if(daysOfInfection  == LENGTH_OF_INFECTION)
        {
            //System.out.println("infection gone");
            return true;
        }
        else
        {
            //System.out.println("infection not gone, animal has had infection for: " + (counter) + " days");
            return false;
        }
    }

    /**
     * @return the chance of spreading the disease
     */
    public double getChanceOfContraction()
    {
        return CHANCE_OF_CONTRACTION;
    }

}