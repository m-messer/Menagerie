import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A model of a plant. This class represents a plant's actions,
 * and also returns important information associated with each
 * plant object.
 * Plants age, breed, and die.
 *
 * @version (1.01)
 */
public class Plants extends Animal
{
    //Characteristics shared by all plants (class variables)
    
    // The age to which a plant can live.
    private static final int MAX_AGE = 80;
    // The age at which a plant can start to breed.
    private static final int BREEDING_AGE = 1;
    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.90;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    //probability of pants dying if there is no light
    private static final double CHANCE_OF_DEATH_DUE_TO_LACK_LIGHT = 0.25;
    //if weather is sunny this is the bonus added to the plants food value
    private int sunBonus;

    /**
     * Create a plant. A plant can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the plant will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of plant
     */
    public Plants(boolean randomAge, Field field, Location location, double randomGender)
    {
        super(randomAge, field,location, randomGender);
        sunBonus = 0; 
    }

    /**
     * This is what the plant does most of the time: looks to reproduce,
     * stays in same place and feeds other animals
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes and the time in the simulation
     * @param clock the current time in the simulation 
     */
    public void act(List<Animal> newPlants, ClockDisplay clock )
    {
        incrementAge();
        lackOfSunlight(clock);
        if(isAlive()) {
            giveBirth(newPlants);            

        }  
    }

    /**
     * Creates new plant, used to create plant offspring in breeding 
     * @param randomAge if true we give fix random age, else we make age 0
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @randomGender a random double value used to find gender of plant 
     * @return Animal - return the newly created plant
     */    
    protected Animal createNewAnimal(boolean randomAge, Field field, Location location, double randomGender)
    {
        Animal young = new Plants(false, field, location, randomGender);
        return young;
    }

    /**
     * checks if it is dark, if it is there is a random chance of
     * plants being killed off.
     */
    private void lackOfSunlight(ClockDisplay clock)
    {
        if (!(clock.checkIfMorning(clock.getHour())))
        {
            if(rand.nextDouble() <= CHANCE_OF_DEATH_DUE_TO_LACK_LIGHT )
            {
                setDead();
            }
        }
    }

    /**
     * simulates growth of plant. As it ages, its food value increases, helping its predators.
     * @return the value of eating a plant 
     */
    public int getFoodValue()
    {
        int plantFoodValue = 0; 
        if (age >= 0 && age <= (MAX_AGE * 0.25))
        {
            plantFoodValue = 3;

        }
        else if (age > (MAX_AGE * 0.25) && age <= (MAX_AGE * 0.50))
        {
            plantFoodValue = 7;
        }
        else
        {
            plantFoodValue = 5;
        }
        plantFoodValue = plantFoodValue + sunBonus; //if it weather is on and is sunny we add a bonus to food value (more growth)
        return plantFoodValue; 
    }
    
    /**
     * @return the max age of the plant (age it can live up to )
     */ 
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return the breeding age of the plant
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return the maximum size of offspring the plant can reproduce
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the breeding probability of the plant
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * works out whether it is sunny, if it is then we make sunBonus equal to 3
     * else we maek it to 0 
     */
    protected void getWeather(String currentWeather)
    {
        if (currentWeather.equals("Sunny"))
        {
            sunBonus = 3;
        }
        else
        {
            sunBonus = 0;
        }
    }
    
}