import java.util.List;
import java.util.Iterator;
/**
 * A class representing the shared characteristics of
 * predators.
 *
 * @version (1.01)
 */
public abstract class Predator extends Animal 
{
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox/bear can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 4;
    // The food value of a single moose. In effect, this is the
    // number of steps a fox/bear can go before it has to eat again.
    private static final int MOOSE_FOOD_VALUE = 7;
    /**
     * Constructor for objects of class Predator
     */
    public Predator(boolean randomAge, Field field, Location location, double randomGender)
    {
        // initialise instance variables
        super(randomAge, field, location, randomGender);

    }

    /**
     * Look for food (rabbit/moose) adjacent to the current location.
     * Only the first live animal of the right type is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    rabbit.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
            else if (this.getClass().getName().equals("Bear") && animal instanceof Moose){
                Moose moose = (Moose) animal;
                if(moose.isAlive()) { 
                    moose.setDead();
                    foodLevel = MOOSE_FOOD_VALUE;
                    return where;
                }
            }
            else if(this.getClass().getName().equals("Bear") && animal instanceof Plants)
            {
                Plants plant = (Plants) animal;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = plant.getFoodValue();
                    return where;
                }
            }
        }

        return null;
    }
    
    /**
     * Just like i used it for Plants class. 
     * This is future implementation where i would have made weather affect how the predator can find its food
     */
    protected void getWeather(String currentWeather)
    {
        
    }
    
}