import java.util.List;
import java.util.Iterator;
/**
 * This class describes the shared characteristics of prey-type animals. 
 * These are animals which, are herbivores, and are thus hunted by predators. 
 * This class is an extension of the Animal class,which describes the shared 
 * characteristics of all animals.
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public abstract class Prey extends Animal
{
    // The food value that an animal gets from eating a plant.
    private static final int PLANT_FOOD_VALUE = 3;
    /**
     * Constructor for objects of class Prey. This constructor makes a call to 
     * the superclass Animal.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location)
    {
        // Method call to the constructor of the superclass (Animal).
        super(field,location);
    }

    /**
     * An abstract method which allows prey-animals to give birth to new animals.
     * @param newPrey A list to return newly born prey.
     */    
    protected abstract void giveBirth(List<Animal> newPrey);

    /**
     * A method that returns the plant food value.
     * @return PLANT_FOOD_VALUE
     */
    protected int getPlantFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where the plant was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Plant) {
                Plant plant = (Plant) obj;
                if(plant.isAlive()) { 
                    plant.setDead();
                    setFoodLevel(getPlantFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
}
