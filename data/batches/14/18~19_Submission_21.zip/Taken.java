import java.util.List;
/**
 * A simple model of a taken (fox in the original simulation).
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class Taken extends Predator
{
    /**
     * Create a taken. A taken can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the taken will have random age and random 
     * hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Taken(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setBreedingAge(30);
        setMaxAge(150);
        setBreedingProbability(0.1);
        setMaxLitterSize(1);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getFallenFoodValue() + 1));
        }
        else {
            setFoodLevel(getFallenFoodValue() + 1);
        }
    }
    
    /**
     * Check whether or not this taken is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTaken A list to return newly born taken.
     */
    protected void giveBirth(List<Animal> newTaken)
    {
        // New taken are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Taken young = new Taken(false, field, loc);
            newTaken.add(young);
        }
    }
}
