import java.util.List;
/**
 * A simple model of a cabal (deer in the original simulation).
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class Cabal extends Prey
{
    /**
     * Create a new cabal. A cabal may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the cabal will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cabal(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setBreedingAge(10);
        setMaxAge(150);
        setBreedingProbability(1);
        setMaxLitterSize(1);
        setAge(0);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getPlantFoodValue() + 1));
        }
        else {
         setFoodLevel(getPlantFoodValue() + 1);
        }
    }
    
    /**
     * Check whether or not this cabal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCabals A list to return newly born cabals.
     */
    protected void giveBirth(List<Animal> newCabals)
    {
        // New cabals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cabal young = new Cabal(false, field, loc);
            newCabals.add(young);
        }
    }
}
