import java.util.List;
import java.util.Random;
import java.awt.Color;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 * 
 * @version 2020.02.22 (3)
 */
public abstract class Animal
{
    // Characteristics shared by all leopards (class variables).
    
    // the color show in the view of an get disease's animal.
    private static final Color DiseaseColor = Color.BLACK;
    // the posibility of disease to infect an nother animal, 
    private static final double INFECT_PROBABILITY = 0.07;
    // the posibility for disease can make an animal die.
    private static final double DESEASE_DIE_RATE = 0.09;
    // steps takes of this disease cure itself.
    private static final int DESEASE_CURE_TIME = 5;
    // A shared random number generator to control desease.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The gender of this animal.
    private boolean isMale;
    // The animal's active time period.
    private boolean activeAtDaytime;
    // Whether The animal get disease now.
    private boolean isDisease;
    // how many steps left until the disease cure it self.
    private int deaseaseDate;
    // To show this animal die caused by disease.
    private boolean diseaseDie;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param activeAtDaytime the active time period of this animal.
     * @param isDisease comfirm wehther this animal get disease.
     */
    public Animal(Field field, Location location, boolean activeAtDaytime,boolean isDisease)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        isMale = rand.nextBoolean();// random gender
        this.activeAtDaytime = activeAtDaytime;
        this.isDisease = isDisease;
        if (isDisease == true){
            deaseaseDate = DESEASE_CURE_TIME;
        }
        diseaseDie = false;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    protected void beInfected()
    {
        if(rand.nextDouble() <= INFECT_PROBABILITY){
            isDisease = true;
            deaseaseDate = DESEASE_CURE_TIME;
        }
    }
  
    /**
     *check whether thr animal is get disease or not.
     *if get disease, infect the other animal
     *if this animal is lucky enough, the disease will be cure itself.
     */
    protected void infectAction()
    {
        if(this.isDisease()) {
            this.deaseaseDate--;
            if(this.deaseaseDate == 0) {
                this.isDisease = false; // the disease become sound.
            }
            
            else if(rand.nextDouble() <= DESEASE_DIE_RATE) {
                diseaseDie = true;// this animal may be die because of disease.
            }
            
            else{
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                   Location where = it.next();
                   Object object = field.getObjectAt(where);
                   // find objects in infect range.
                   if(object instanceof Animal) {
                       Animal surroundingAnimal = (Animal) object; 
                       if(surroundingAnimal.isDisease() == false) {
                            surroundingAnimal.beInfected();// infect a nother animal
                       }
                   }
                }    
            } 
        }
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * @return whether this animal is get disease.
     */
    protected boolean isDisease()
    {
        return isDisease;
    }
    
    /**
     * @return the color need to show when get disease
     */
    public Color getDiseaseColor()
    {
        return DiseaseColor;
    }
    
    protected boolean Disease_Cause_Die()
    {
        return diseaseDie;
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
   
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * @return the animal's gender.
     */
    public boolean isMale()
    {
        return isMale;
    }
    
    /**
    * @return the animal's active time period.
    */
    public boolean getActiveAtDaytime()
    {
        return activeAtDaytime;
    }
}
