import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sheeps and wolves.
 * 
 * @version 2020.02.22 (3)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.002;
    // The probability that a sheep will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.04;  
    
    private static final double SHEEP_CREATION_PROBABILITY = 0.04;
    
    private static final double COW_CREATION_PROBABILITY = 0.04;
    
    private static final double LEOPARD_CREATION_PROBABILITY = 0.004;
    
    private static final double GRASS_CREATION_PROBABILITY = 0.15;
    
    private static final double Disease_Rate = 0.01;
    
    private static final double SEASON_CHANGE_RATE = 0.005;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // List of animals in the field.
    private List<Plant> plants;
    //set now is day time or night time.(two steps per day)
    private boolean isDaytime;
    //set now is drought or rain season.
    private boolean isDrought;
    //An random for public use;
    private Random rand = Randomizer.getRandom();
   
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
            Random rand = Randomizer.getRandom();
            isDaytime = true;
            isDrought = false;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);
        plants = new ArrayList<>(); 
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Sheep.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Cow.class, Color.PINK);
        view.setColor(Deer.class, Color.CYAN);
        view.setColor(Leopard.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            if(rand.nextDouble() <= SEASON_CHANGE_RATE) {
                isDrought = !isDrought;
                Grass.changeSeason(isDrought);
            }
            //delay(560);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * wolf and sheep.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        //to make sure all the animals are in the field
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.isAlive()){field.place(animal,animal.getLocation());}
        }
         // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if (animal.getActiveAtDaytime() == isDaytime && animal.isAlive())
                animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        } 
        animals.addAll(newAnimals);// Provide space for newborn plants.
        List<Plant> newPlants = new ArrayList<>();        
        //to make sure all the animals are in the field
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            if(plant.isAlive()){field.place(plant,plant.getLocation());}
        }
        // Let all plants act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            if ( plant.isAlive())
                plant.act(newPlants);
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        plants.addAll(newPlants);
        view.showStatus(step, field, animals,plants,ShowSeason());
        isDaytime = !isDaytime;//switch day and night.
    }
    
    /**
     * If now season is drought, return true, else, return false.
     */
    private String ShowSeason()
    { 
        if(isDrought == true) { return "drought";
        }
        else {return"rain";
        }
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();   
        // Show the starting state in the view.
        view.showStatus(step, field ,animals ,plants,ShowSeason());
    }
    
    /**
     * Randomly populate the field with wolves and sheeps.
     */
    private void populate()
    {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {

                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    plants.add(grass);
                }
                
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf;
                    if(rand.nextDouble() <= Disease_Rate) {wolf = new Wolf(true, field, location,true);}
                    else {wolf = new Wolf(true, field, location,false);
                    }
                    animals.add(wolf);
               }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Boolean getDisease = false;
                    if(rand.nextDouble() <= Disease_Rate) {
                        getDisease = true;
                    }
                    Sheep sheep = new Sheep(true, field, location,getDisease);
                    animals.add(sheep);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Boolean getDisease = false;
                    if(rand.nextDouble() <= Disease_Rate) {
                        getDisease = true;
                    }
                    Deer deer = new Deer(true, field, location,getDisease);
                    animals.add(deer);
                }
                else if(rand.nextDouble() <= COW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Boolean getDisease = false;
                    if(rand.nextDouble() <= Disease_Rate) {
                        getDisease = true;
                    }
                    Cow cow = new Cow(true, field, location,getDisease);
                    animals.add(cow);
                    
                }
                 else if(rand.nextDouble() <= LEOPARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                     Boolean getDisease = false;
                    if(rand.nextDouble() <= Disease_Rate) {
                        getDisease = true;
                    }
                    Leopard leopard = new Leopard(true, field, location,getDisease);
                    animals.add(leopard);
                    
               }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
