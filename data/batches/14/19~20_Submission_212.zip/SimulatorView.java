import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @second modifier Haolun Shan and Maike Zhang
 * @version 2020.02.22(2)
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String DAY_PREFIX = "Day: ";
    private final String POPULATION_PREFIX = "Population: ";
    private JLabel stepLabel, population, infoLabel, seasonLabel;
    private FieldView fieldView;
    
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;
    
    // four 
    private HashMap <Location,Animal> onlyAnimals;
    private HashMap <Location,Plant> plantsBelowAnimal;
    private HashMap <Location,Animal> animalsAbovePlant;
    private HashMap <Location,Plant> onlyPlants;
    
   

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Fox and Rabbit Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        seasonLabel = new JLabel();
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        
        setLocation(100, 50);
        
        fieldView = new FieldView(height, width);

        Container contents = getContentPane();
        
        JPanel infoPane = new JPanel(new BorderLayout());
            infoPane.add(stepLabel, BorderLayout.WEST);
            infoPane.add(seasonLabel, BorderLayout.EAST);
            infoPane.add(infoLabel, BorderLayout.CENTER);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);
        pack();
        setVisible(true);
        onlyAnimals = new HashMap<>();
         plantsBelowAnimal = new HashMap<>();
         animalsAbovePlant = new HashMap<>();
         onlyPlants = new HashMap<>();
    }
    
    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass)
    {
        Color col = colors.get(animalClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * to show darker color when one plant and one animal in one posiotion.
     * show black to repersent animal who get disease.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     * @param animals the List with all the animals.
     * @param plants the List with all plants.
     */
    public void showStatus(int step, Field field, List<Animal> animals,List plants , String season)
    {
        if(!isVisible()) {
             setVisible(true);
        }
       
        if(step%2 == 0 ){
            int day = step /2;
            stepLabel.setText(STEP_PREFIX + step + "  "+DAY_PREFIX +  day + " morning");
            seasonLabel.setText("season:"+ season);
        }
        else{
            int day = (step-1) /2;
            stepLabel.setText(STEP_PREFIX + step + "  "+DAY_PREFIX +  day + " evening");
            seasonLabel.setText("season:"+ season);
        }
        stats.reset();      
        fieldView.preparePaint();
        onlyAnimals.clear();
        plantsBelowAnimal.clear();
        animalsAbovePlant .clear();
        onlyPlants.clear();
        for(Iterator<Animal> it =animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.isAlive()){
            onlyAnimals.put(animal.getLocation(),animal);}
        }
        
        for(Iterator<Plant> it =plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            Location plantLocation = plant.getLocation();
            Animal animal = onlyAnimals.get(plantLocation);
            if (animal!= null&&plant.isAlive()){
                plantsBelowAnimal.put(plantLocation,plant);
                animalsAbovePlant.put(plantLocation,animal);
                onlyAnimals.remove(plantLocation);
            }
            
            else if (plant.isAlive()){
                onlyPlants.put(plantLocation,plant);
            }
        }
        
        for(Iterator it = onlyAnimals.keySet().iterator(); it.hasNext(); ) {
          Location key = (Location)it.next();
          Animal animal = onlyAnimals.get(key);
          Color color;
          stats.incrementCount(animal.getClass());
          int col = key.getCol();          
          int row = key.getRow(); 
          if(animal.isDisease() == true){
              fieldView.drawMark(col, row, animal.getDiseaseColor());
          } 
          else{fieldView.drawMark(col, row, getColor(animal.getClass()));
          }
        }
       
        for(Iterator it = onlyPlants.keySet().iterator(); it.hasNext(); ) {
          Location key = (Location)it.next();
          Plant plant = onlyPlants.get(key);
          stats.incrementCount(plant.getClass());
          int col = key.getCol();
          int row = key.getRow();   
          fieldView.drawMark(col, row, getColor(plant .getClass()));
        }
        
        for(Iterator it = plantsBelowAnimal.keySet().iterator(); it.hasNext(); ) {
          Location key = (Location)it.next();
          Plant plantBelowAnimal = plantsBelowAnimal.get(key);
          stats.incrementCount( plantBelowAnimal.getClass());
        }
        
        for(Iterator it = animalsAbovePlant.keySet().iterator(); it.hasNext(); ) {
          Location key = (Location)it.next();
          Animal animalAbovePlant = animalsAbovePlant.get(key);
          stats.incrementCount( animalAbovePlant.getClass());
          int col = key.getCol();          
          int row = key.getRow(); 
          if(animalAbovePlant.isDisease() == true){
              fieldView.drawMark(col, row,animalAbovePlant.getDiseaseColor());
          } 
          else{fieldView.drawMark(col, row, getColor(animalAbovePlant.getClass()).darker());
          }
        }
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
               Location location = new Location(row,col);
                Object animal1 = onlyAnimals.get(location);
               Object animal2 = plantsBelowAnimal.get(location);
               Object animal3 = animalsAbovePlant .get(location);
               Object animal4 = onlyPlants.get(location);
               if(animal1 == null&&animal2 == null&& animal3 == null&&animal4 == null) {
                   fieldView.drawMark(col, row, EMPTY_COLOR);
               }
            }
        }
        stats.countFinished();
        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;
        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;
        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
