
/**
 * THIS CLASS REPRESENT A SUNNY WEATHER.
 * CURRETNLY ONLY REPRESENT A TYPE BUT HAVE NO METHOD
 *
 * @version 2021/3/2
 */
public class Sun extends Weather
{
    /**
     * Constructor for objects of class Sun
     * nothing here currently...
     */
    public Sun()
    {

    } 
}
