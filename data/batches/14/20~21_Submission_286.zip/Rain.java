/**
 * THIS CLASS REPRESENT A RAINY WEATHER.
 * CURRETNLY ONLY REPRESENT A TYPE BUT HAVE NO METHOD
 *
 * @version 2021/3/2
 */
public class Rain extends Weather
{  
    /**
     * Constructor for objects of class Rain
     */
    public Rain()
    {
        
    }

}
