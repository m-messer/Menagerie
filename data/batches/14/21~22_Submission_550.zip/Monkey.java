import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Monkey.
 * Monkeys age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Monkey extends Animal
{
    // Characteristics shared by all Monkeys (class variables).

    // The age at which a Monkey can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Monkey can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a Monkey breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The food value of various plants. In effect, this is the
    // number of steps a monkey can go before it has to eat again.
    private static final int VEGETABLE_FOOD_VALUE = 10;
    
    // Animal's move during the day and breed during the night
    private Time time;
    
    // Individual characteristics (instance fields).
    // The Monkey's age.
    private int age;
    
    // The Monkey's food level, which is increased by eating various plants.
    private int foodLevel;
    /**
     * Create a new Monkey. A Monkey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Monkey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Monkey(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(VEGETABLE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = VEGETABLE_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Monkey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMonkeys A list to return newly born Monkeys.
     */
    public void act(List<Animal> newMonkeys, Time time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (!time.isDay())
            {
                giveBirth(newMonkeys);
            }
            else{
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Monkey's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Monkey more hungry. This could result in the Monkey's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        return findVegetable(foodLevel, VEGETABLE_FOOD_VALUE);
    }
    
    /**
     * Check whether or not this Monkey is to give birth at this step.
     * New births will be made into free adjacent locations if two monkeys of
     * different gender meet.
     * @param newMonkeys A list to return newly born Monkeys.
     */
    private void giveBirth(List<Animal> newMonkeys)
    {
        // Get a list of adjacent and 'free adjacent' locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int genderOfCurrentMonkey = getGender();
        for (Location next : adjacentLocations){
            Object animal = field.getObjectAt(next);
            if(animal != null && animal instanceof Monkey ) {
                Monkey matingPairMonkey = (Monkey) animal;
                // Mating only happens if both genders are different
                if(matingPairMonkey.isAlive() || matingPairMonkey.getGender() != genderOfCurrentMonkey) { 
                     int births = breed();
                     for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Monkey young = new Monkey(false, field, loc);
                        newMonkeys.add(young);
                        }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Monkey can breed if it has reached the breeding age.
     * @return true if the Monkey can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
