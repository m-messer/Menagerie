
/**
 * Time class to keep track of time
 *
 * @version (a version number or a date)
 */
public class Time
{
    private Integer hour;
    private Integer minute;

    /**
     * Constructor for objects of class Time
     */
    public Time(Integer hour, Integer minute)
    {
        // initialise instance variables
        this.hour = hour % 24;
        this.minute = minute % 60;
    }

    /**
     *  setter for hour
     * @param  hour An Integer to set the hour 
     */
    private void setHour(Integer hr)
    {
        hour = hr;
    }
    
    /**
     *  setter for minutes
     * @param  minutes An Integer to set the minutes 
     */
    private void setMinute(Integer mins)
    {
        minute = mins;
    }
        
    /**
     *  getter for hour
     * @return  hour An Integer for hour between 0 and 23
     */
    public Integer getHour()
    {
        return hour;
    }
    
    /**
     *  getter for minutes
     * @return  minutes An Integer for minutes between 0 and 60
     */
    public Integer getMinute()
    {
        return minute;
    }
    
    /**
     * A getter for time
     *
     * @return   the current time in format  hh::mm
     */
    public String getTime()
    {
        return getHour().toString() + ":" + getMinute().toString();
    }
    
    /**
     * A method to increment hour 
     * 
     */
    public void incrementHour()
    {
        setHour( (getHour() + 1 ) % 24);
    }
    
    /**
     * A method to increment minute 
     * 
     */
    public void incrementMinute()
    {
        setMinute( (getMinute() + 1 ) % 60);
    }
    
    /**
     * A method to change from day to night and vice versa
     * 
     */
    public void incrementTime()
    {
        Integer currentHour = getHour();
        setHour(currentHour + 12);
    }    
    
    /**
     *  A method to tell whether it is day or night
     */
    public boolean isDay()
    {
        return 6 < getHour().intValue()  && getHour().intValue()< 18 ? true : false;
    }
    
    /**
     * A method to reset time of day to 00:00 (midnight)
     * 
     */
    public void reset()
    {
        setHour(0);
        setMinute(0);
    }
}
