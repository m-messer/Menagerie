import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Tiger.
 * Tigers age, move, eat goats/monkeys/lions, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Tiger extends Animal
{
    private static final int BREEDING_AGE = 10;
    
    private static final int MAX_AGE = 150;
    
    private static final double BREEDING_PROBABILITY = 0.12;
    
    private static final int MAX_LITTER_SIZE = 2;
    
    private static final int LION_FOOD_VALUE = 19;
    private static final int GOAT_FOOD_VALUE = 19;
    private static final int MONKEY_FOOD_VALUE = 19;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private Time time;
    private int age;
    private int foodLevel;
    
    /**
     * Create a Tiger. A Tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GOAT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GOAT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Tiger does most of the time: it hunts for
     * lions/monkey/goats. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newTigers A list to return newly born Tigers.
     */
    public void act(List<Animal> newTigers, Time time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (!time.isDay())
            {
                giveBirth(newTigers);
            }
            else{
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the Tiger's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Tiger more hungry. This could result in the Tiger's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for lions/monkeys/goats adjacent to the current location.
     * Only the first such animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Goat){
                Goat goat = (Goat) animal;
                if(goat.isAlive()){
                    goat.setDead();
                    foodLevel = GOAT_FOOD_VALUE;
                    return where;
                    }
            }
        }      
        return null;
    }
    
    /**
     * Check whether or not this Tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTigers A list to return newly born Tigers.
     */
    private void giveBirth(List<Animal> newTigers)
    {
        // New Tigers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int genderOfCurrentTiger = getGender();
        for (Location next : adjacentLocations){
            Object animal = field.getObjectAt(next);
            if(animal != null && animal instanceof Tiger ) {
                Tiger matingPairTiger = (Tiger) animal;
                if(matingPairTiger.isAlive() || matingPairTiger.getGender() != genderOfCurrentTiger) { 
                     int births = breed();
                     for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Tiger young = new Tiger(false, field, loc);
                        newTigers.add(young);
                        }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Tiger can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
