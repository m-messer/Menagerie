import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Pelican.
 * Pelicans age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Pelican extends Animal
{
    private static final int BREEDING_AGE = 5;
    
    private static final int MAX_AGE = 40;
    
    private static final double BREEDING_PROBABILITY = 0.12;
    
    private static final int MAX_LITTER_SIZE = 4;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private static final int VEGETABLE_FOOD_VALUE = 10;
    
    private Time time;
    private int age;
    private int foodLevel;
    
    /**
     * Create a new Pelican. A Pelican may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Pelican will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Pelican(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(VEGETABLE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = VEGETABLE_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Pelican does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPelicans A list to return newly born Pelicans.
     */
    public void act(List<Animal> newPelicans, Time time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (!time.isDay())
            {
                giveBirth(newPelicans);
            }
            else{
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Pelican's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Pelican more hungry. This could result in the Pelican's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        return findVegetable(foodLevel, VEGETABLE_FOOD_VALUE);
    }
    
    /**
     * Check whether or not this Pelican is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPelicans A list to return newly born Pelicans.
     */
    private void giveBirth(List<Animal> newPelicans)
    {
        // New Pelicans are born into adjacent locations if a Male and a Female and pelican meet.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int genderOfCurrentPelican = getGender();
        for (Location next : adjacentLocations){
            Object animal = field.getObjectAt(next);
            if(animal != null && animal instanceof Pelican ) {
                Pelican matingPairPelican = (Pelican) animal;
                if(matingPairPelican.isAlive() || matingPairPelican.getGender() != genderOfCurrentPelican) { 
                     int births = breed();
                     for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Pelican young = new Pelican(false, field, loc);
                        newPelicans.add(young);
                        }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Pelican can breed if it has reached the breeding age.
     * @return true if the Pelican can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
