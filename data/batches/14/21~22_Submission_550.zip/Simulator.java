import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that animals will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;
    private static final double TIGER_CREATION_PROBABILITY = 0.02;
    private static final double BEAR_CREATION_PROBABILITY = 0.02;
    private static final double MONKEY_CREATION_PROBABILITY = 0.08;
    private static final double GOAT_CREATION_PROBABILITY = 0.08;
    private static final double PELICAN_CREATION_PROBABILITY = 0.08;
    
    // The probability that a plant will be created in any given grid position.
    private static final double VEGETABLE_CREATION_PROBABILITY = 0.08;
    
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // Time keeping
    private Time time;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        time = new Time(0,0); // Time starts at midnight

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Lion.class, Color.MAGENTA);
        view.setColor(Tiger.class, Color.BLUE);
        view.setColor(Bear.class, Color.GRAY);
        view.setColor(Monkey.class, Color.BLACK);
        view.setColor(Goat.class, Color.ORANGE);
        view.setColor(Pelican.class, Color.PINK);
        view.setColor(Vegetable.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Getter for time object.
     */
    public Time getTime()
    {
        return this.time;
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        // Move half a day forward - if it's day it becomes night, and if it's night it becomes day
        time.incrementTime();
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        
        // Provide space for newly created plants.
        List<Plant> newPlants = new ArrayList<>();
        
        // Make all animals and plants act
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, time);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals and plants
        animals.addAll(newAnimals);
        plants.addAll(newPlants);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        time.reset();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with animals and plants
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(false, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(false, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(false, field, location);
                    animals.add(bear);
                }
                else if(rand.nextDouble() <= MONKEY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Monkey monkey = new Monkey(false, field, location);
                    animals.add(monkey);
                }
                else if(rand.nextDouble() <= GOAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Goat goat = new Goat(false, field, location);
                    animals.add(goat);
                }
                else if(rand.nextDouble() <= PELICAN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Pelican pelican = new Pelican(false, field, location);
                    animals.add(pelican);
                }
                else if(rand.nextDouble() <= VEGETABLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Vegetable vegetable = new Vegetable(false, field, location);
                    plants.add(vegetable);
                }
                

                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
