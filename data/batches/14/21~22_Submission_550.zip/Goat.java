import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Goat.
 * Goats age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Goat extends Animal
{
    private static final int BREEDING_AGE = 5;
    
    private static final int MAX_AGE = 40;
    
    private static final double BREEDING_PROBABILITY = 0.12;
    
    private static final int MAX_LITTER_SIZE = 4;
    
    private static final Random rand = Randomizer.getRandom();
    
    private static final int VEGETABLE_FOOD_VALUE = 10;
    
    
    private Time time;
    private int age;
    private int foodLevel;
    /**
     * Create a new Goat. A Goat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Goat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Goat(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(VEGETABLE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = VEGETABLE_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Goat does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGoats A list to return newly born Goats.
     */
    public void act(List<Animal> newGoats, Time time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (!time.isDay())
            {
                giveBirth(newGoats);
            }
            else{
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Goat's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Goat more hungry. This could result in the Goat's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for vegetable adjacent to the current location.
     * Only the first live vegetable is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        return findVegetable(foodLevel, VEGETABLE_FOOD_VALUE);
    }
    
    /**
     * Check whether or not this Goat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGoats A list to return newly born Goats.
     */
    private void giveBirth(List<Animal> newGoats)
    {
        // New Goats are born into adjacent locations if a Male and a Female and goat meet.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        int genderOfCurrentGoat = getGender();
        for (Location next : adjacentLocations){
            Object animal = field.getObjectAt(next);
            if(animal != null && animal instanceof Goat ) {
                Goat matingPairGoat = (Goat) animal;
                if(matingPairGoat.isAlive() || matingPairGoat.getGender() != genderOfCurrentGoat) { 
                     int births = breed();
                     for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Goat young = new Goat(false, field, loc);
                        newGoats.add(young);
                        }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Goat can breed if it has reached the breeding age.
     * @return true if the Goat can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
