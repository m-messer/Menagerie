import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simulation of several species with unpredictable weather.
 *
 * @version 2020.02.22 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.02;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.02;
    // The probability that a cow will be created in any given grid position.
    private static final double COW_CREATION_PROBABILITY = 0.08;
    // The probability that a goat will be created in any given grid position.
    private static final double GOAT_CREATION_PROBABILITY = 0.08;   
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.08;   
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.18;  

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //An instance of class Time to track the time.
    private Time time = new Time();
    //An instance of class weather to generate weather.
    private Weather weather = new Weather();

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        view.setColor(Cow.class, Color.ORANGE);
        view.setColor(Snake.class, Color.BLUE);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Goat.class, Color.YELLOW);
        view.setColor(Mouse.class, Color.PINK);
        view.setColor(Grass.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * updateColor method is to update colors every time change / weather change
     */
    private void updateColor()
    {
        if(time.isMorning == true)
        {
            view.setEmpty(Color.WHITE); //set background as white during morning
        }else if(time.isMorning == false)
        {
            view.setEmpty(Color.BLACK); //set background as black during night
        }

        if(weather.weatherInt == 1)
        {
            view.setColor(Cow.class, Color.ORANGE);
            view.setColor(Snake.class, Color.BLUE);
            view.setColor(Wolf.class, Color.RED);
            view.setColor(Goat.class, Color.YELLOW);
            view.setColor(Mouse.class, Color.PINK);
            view.setColor(Grass.class, Color.GREEN);
        }else if(weather.weatherInt == 2)
        {
            view.setColor(Cow.class, Color.ORANGE);
            view.setColor(Snake.class, Color.BLUE);
            view.setColor(Wolf.class, Color.RED);
            view.setColor(Goat.class, Color.YELLOW);
            view.setColor(Mouse.class, Color.PINK);
            view.setColor(Grass.class, Color.GRAY.brighter()); //grass is gray during cold times
        }else if(weather.weatherInt == 3)
        {
            view.setColor(Cow.class, Color.ORANGE);
            view.setColor(Snake.class, Color.BLUE);
            view.setColor(Wolf.class, Color.RED);
            view.setColor(Goat.class, Color.YELLOW);
            view.setColor(Mouse.class, Color.PINK);
            view.setColor(Grass.class, Color.GREEN.darker()); //grass is darker during hot times
        }
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(30);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * snake and rabbit.
     */
    public void simulateOneStep()
    {
        step++;

        if(step >= 2 && step % 10 == 1){
            time.changeTime(); //change the time
            updateColor(); //change the color scheme based on situation
            weather.weatherGen(); //generate weather based on random probability
        }

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if (time.isMorning == true){
                if(weather.weatherInt == 1){
                    animal.act(newAnimals);
                }else if(weather.weatherInt == 2){
                    animal.coldAct(newAnimals);
                }else if(weather.weatherInt == 3){
                    animal.hotAct(newAnimals);
                }
            }else if(time.isMorning == false){
                animal.nightAct(newAnimals);
            }
            if(! animal.isAlive()) {
                it.remove();
            }

        }

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        time.isMorning = true; //reset the time
        populate();
        updateColor(); //this is needed to match the color with surrounding when reset

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with the living things.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= COW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cow cow = new Cow(true, field, location);
                    animals.add(cow);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= GOAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Goat goat = new Goat(true, field, location);
                    animals.add(goat);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    animals.add(grass);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
