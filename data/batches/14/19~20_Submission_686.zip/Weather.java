import java.util.Random;
/**
 * Keeps track and generates weather.
 * 
 * @version 2020.02.22 
 */
public class Weather
{
    //each int represents a weather condition
    // 1 is normal, 2 is cold weather, 3 is dry and hot weather
    public int weatherInt;
    Random rand = Randomizer.getRandom();

    public Weather()
    {
        weatherGen(); //initialising
    }

    //weatherGen will generate weather using the concept of generating gender (randomizer)
    public void weatherGen()
    {
        double weatherChance = rand.nextDouble();
        if(weatherChance <= 0.8)
        {
            weatherInt = 1; //normal weather
        }
        else if(weatherChance > 0.8 && weatherChance <= 0.9)
        {
            weatherInt = 2; //cold weather
        }
        else if(weatherChance > 0.9)
        {
            weatherInt = 3; //hot and dry weather
        }
    }
}
