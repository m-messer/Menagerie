import java.util.Random;

/**
 * Generates and keeps track of animal genders.
 * 
 * @version 2020.02.22 
 */
public class Gender
{   
    // A shared random number generator to control number of males and females.
    private static final Random rand = Randomizer.getRandom();
    // The gender.
    public boolean isMale;
    
    /**
     * Constructor for objects of class Gender
     */
    public Gender()
    {
        setGender();
    }
    
    /**
     * Sets whether an animal is male or female.
     */
    public void setGender()
    {
        double genderChance = rand.nextDouble();
        if(genderChance <= 0.5)
        {
            isMale = true;
        }
        else
        {
            isMale = false;
        }
    }
    
    /**
     * Returns gender.
     */
    public boolean getGender()
    {
        return isMale;
    }
}
