/**
 * Keeps track of time.
 * 
 * @version 2020.02.22 
 */
public class Time
{
    // instance variables - replace the example below with your own
    public static boolean isMorning;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        // initialise instance variables
        isMorning = true;
    }

    /**
     * method to toggle boolean isMorning state
     */
    public void changeTime()
    {
        isMorning = !isMorning;
    }
}
