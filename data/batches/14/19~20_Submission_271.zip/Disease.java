/**
 * Provides disease for the simulation.
 * This includes an identifying boolean that indicates if there is
 * high probability of disease on this day.
 *
 * @version 2020.02.13
 */
public class Disease
{
    //boolean field indicating if the day has high chance of disease
    private boolean diseaseDay;
    //The interval of days of high disease probability
    private int diseaseInterval = 10;
    
    /**
     * Initialises the private fields
     */
    public Disease()
    {
        diseaseDay = false;
    }
    
    /**
     * Initialises the diseaseInterval field to optimum value (i.e. 10)
     */
    public void initDiseaseInterval() {
        diseaseInterval = 10;
    }

    /**
     * Sets the day to either having a high chance of disease or not
     * @param the current day count
     */
    public void setDiseaseDay(int day) {
        if(day % diseaseInterval == 0) {
         diseaseDay = true;
        } else {
         diseaseDay = false;
        }
    }
    
    /**
     * Returns the boolean value diseaseDay 
     * @return diseaseDay True if the day presents high probability
     * of infectious disease, False otherhwise
     */
    public boolean isDiseaseDay() {
        return diseaseDay;
    }
    
    /**
     * Sets the disease interval (day)
     */
    public void setDiseaseInterval(int n) {
        diseaseInterval = n;
    }
    
    /**
     * Gets the disease interval (day)
     * @returns diseaseInterval
     */
    public int getDiseaseInterval() {
        return diseaseInterval;
    }
    
    /**
     * Decrements the interval of disease (in days)
     * Interval cannot be less than 1
     */
    public void decDiseaseInterval() {
        if(diseaseInterval > 1) {
            diseaseInterval--;
        }
    }
    
    /**
     * Increments the interval of disease (in days)
     */
    public void incDiseaseInterval() {
            diseaseInterval++;
    }
    
}
