/**
 * Provide a time period for the simulation.
 * This includes an identifying string of the time period and a count of how
 * many days has elapsed from the start of the simulation
 *  
 * @version 2020.02.13
 */
public class TimeCounter
{
    //Total number of steps that is considered as a day
    private int stepsPerDay;
    //The time period of a day (i.e. morning, evening, etc)
    private String timeOfDay;
    //The weather object that determines the weather
    private Weather weather;
    //The disease object that determines the likelihood of infectious disease
    private Disease disease;
    //The day count
    private int day;

    /**
     * Initialises the private fields
     */
    public TimeCounter() 
    {
        stepsPerDay = 50;
        timeOfDay = "Morning";
        day = 0;
        weather = new Weather();
        disease = new Disease();
    }

    /**
     * Decrements the interval between each day in decrements of 10 steps
     * Step in a day cannot be less than 10 
     */
    public void decStepsPerDay() {
        if(stepsPerDay > 10) {
            stepsPerDay -= 10;
        }
    }
    
    /**
     * Increments the interval between each day in increments of 10 steps
     */
    public void incStepsPerDay() {
            stepsPerDay += 10;
    }

    /**
     * Gets the number of steps that is considered to be one day
     * @returns stepsPerDay
     */
    public int getStepsPerDay() {
        return stepsPerDay;
    }

    /**
     * Sets the number of steps that constitutes a day
     * @param n The number of steps in a day
     */
    public void setStepsPerDay(int n) {
        stepsPerDay = n;
    }
    
    /**
     * Resets the day to 0
     */
    public void initialiseTime() { 
        day = 0;
    }

    /**
     * Changes the time of day
     * @param currentStep The current step number
     */
    public void advanceTime(int currentStep) {
        timeOfDay = timeOfDay(currentStep);
        incrementDay(currentStep);
    }

    /**
     * Increments the number of days elapsed
     * @param step The current step
     */
    private void incrementDay(int step) {
        if(step % stepsPerDay == 0) {
            day++;
            weather.setWeather(day);
            disease.setDiseaseDay(day);
        }
    }

    /**
     * Auxiliary method to return the step as a value within the specified range
     * 0(inclusive) to maximum value(exclusive)
     * @param step The step value passed in by the calling method
     */
    private int stepWithinDay(int step) {
        return step % stepsPerDay;
    }

    /**
     * Returns a String representing the time of day as either
     * Morning, Afternoon, Evening, Night
     * @return The current time of day
     */
    private String timeOfDay(int step) {
        int stepInDay = stepWithinDay(step);
        if(stepInDay >= 0 && stepInDay < (stepsPerDay/4)) {
            return "Morning";
        } else if(stepInDay >= (stepsPerDay/4) && stepInDay < (stepsPerDay/2)) {
            return "Afternoon";
        } else if(stepInDay >= (stepsPerDay/2) && stepInDay < ((3*stepsPerDay)/4)) {
            return "Evening";
        } else {
            return "Night";
        } 
    }

    /**
     * Returns true if the current time of day is Morning
     */
    public boolean isMorning() {
        return timeOfDay.equals("Morning");
    }

    /**
     * Returns true if the current time of day is Afternoon
     */
    public boolean isAfternoon() {
        return timeOfDay.equals("Afternoon");
    }

    /**
     * Returns true if the current time of day is Evening
     */
    public boolean isEvening() {
        return timeOfDay.equals("Evening");
    }

    /**
     * Returns true if the current time of day is Night
     */
    public boolean isNight() {
        return timeOfDay.equals("Night");
    }

    /**
     * Returns the current time period of day
     * @return timeOfDay
     */
    public String getPeriod() {
        return timeOfDay;
    }

    /**
     * Returns the current day count
     * @return day
     */
    public int getDay() {
        return day;
    }

    /**
     * Returns the weather object
     * @return weather
     */
    public Weather getWeatherObject() {
        return weather;
    }

    /**
     * Returns the disease object
     * @return disease
     */
    public Disease getDiseaseObject() {
        return disease;
    }

}
