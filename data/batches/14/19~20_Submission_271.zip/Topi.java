import java.util.List;
import java.util.Random;
/**
 * A simple model of a topi.
 * Topis age, move, eat plants, breed, and die. 
 *
 * @version 2020.02.13
 */
public class Topi extends Prey
{

    // Characteristics shared by all topis (class variables).

    // The age at which a topi can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a topi can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a topi breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random RAND = Randomizer.getRandom();

    /**
     * Create a new topi. A topi may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the topi will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Topi(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE, MAX_LITTER_SIZE, BREEDING_AGE, BREEDING_PROBABILITY, RAND);
        setAge(0);

        if(randomAge) {
            setAge(getRand().nextInt(getMaxAge()));
            setFoodLevel(getRand().nextInt(getGrassFoodValue()));
        }
        else {
            setAge(0);  
            setFoodLevel(getGrassFoodValue());
        }
    }
}
