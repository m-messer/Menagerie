import java.util.List;
import java.util.Random;

/**
 * A simple model of grass.
 * Grass can breed (i.e. grow) when it rains and be eaten by animals. 
 *
 * @version 2020.02.13
 */
public class Grass extends Plant
{

    // Characteristics shared by all grass (class variables).

    // The likelihood of a grass breeding (i.e. growing)
    private static final double BREEDING_PROBABILITY = 0.005;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random RAND = Randomizer.getRandom();
    // The number of times a grass can be eaten before it is considered completely eaten
    private int lifeline = 700;

    /**
     * Create  new grass.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        super(field, location, MAX_LITTER_SIZE, BREEDING_PROBABILITY, RAND);
        setLifeline(lifeline);
    }

    /**
     * This is what the grass does most of the time - it grows 
     * Grass don't move
     * @param newGrasses A list to return newly born grass.
     */
    @Override
    public void act(List<Organism> newGrasses, TimeCounter time)
    {
        if(time.getWeatherObject().isRaining()) {
            super.act(newGrasses, time);
        }

    }

}
