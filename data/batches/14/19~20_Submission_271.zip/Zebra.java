import java.util.List;
import java.util.Random;

/**
 * A simple model of a zebra.
 * Zebras age, move, eat plants, breed, and die. 
 *
 * @version 2020.02.13
 */
public class Zebra extends Prey
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random RAND = Randomizer.getRandom();


    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE, MAX_LITTER_SIZE, BREEDING_AGE, BREEDING_PROBABILITY, RAND);
        setAge(0);
              
        if(randomAge) {
            setAge(getRand().nextInt(getMaxAge()));
            setFoodLevel(getRand().nextInt(getGrassFoodValue()));
        }
        else {
            setAge(0);  
            setFoodLevel(getGrassFoodValue());
        }
    }

    /**
     * This is what the zebra does most of the time - it runs 
     * around. Sometimes it will breed, feed, die of disease, die of hunger or die of old age.
     * Zebras do not move, feed or breed at night
     * @param newZebras A list to return newly born zebras.
     */
    
    public void act(List<Organism> newZebras, TimeCounter time) {
        if(time.isNight()) {
            incrementAge();
        } else {
            super.act(newZebras,time);
        }
    }
}
