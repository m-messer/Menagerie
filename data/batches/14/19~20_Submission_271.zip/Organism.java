import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Abstract class Organism - Superclass for all living objects in the simulation.
 *
 * @version 2029.02.22
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // The likelihood of a zebra breeding.
    private final double BREEDING_PROBABILITY;
    // The maximum number of births.
    private final int MAX_LITTER_SIZE;
    // A shared random number generator to control breeding.
    private final Random RAND;
    // The food value of a single zebra. In effect, this is the
    // number of steps a organism that eats zebras can go before it has to eat again.
    private static final int ZEBRA_FOOD_VALUE = 12;
    private static final int TOPI_FOOD_VALUE = 9;
    private static final int RAT_FOOD_VALUE = 5;
    private static final int GRASS_FOOD_VALUE = 7;

    /**
     * Every box in the grid can be occupied by an organism at any given time.
     * 
     */
    public Organism (Field field, Location location, int maxLitterSize, double breedingProb, Random rand) {
        alive = true;
        this.field = field;
        MAX_LITTER_SIZE = maxLitterSize;
        BREEDING_PROBABILITY = breedingProb;
        RAND = rand;
        setLocation(location);
    }

    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param neworganisms A list to receive newly born organisms.
     */
    abstract public void act(List<Organism> newOrganisms, TimeCounter time);

    /**
     * Returns the random object of the organism
     */
    protected Random getRand()  {
        return RAND;
    }

    /**
     * Returns the breeding probability of the organism
     */
    protected double getBreedingProbability()  {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the maximum litter size of the organism
     */
    protected int getMaxLitterSize()  {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the food value a zebra provides
     * @return ZEBRA_FOOD_VALUE
     */
    protected int getZebraFoodValue() {
        return ZEBRA_FOOD_VALUE;
    }

    /**
     * Returns the food value a topi provides
     * @return TOPI_FOOD_VALUE
     */

    protected int getTopiFoodValue() {
        return TOPI_FOOD_VALUE;
    }

    /**
     * Returns the food value a rat provides
     * @return RAT_FOOD_VALUE
     */
    protected int getRatFoodValue() {
        return RAT_FOOD_VALUE;
    }

    /**
     * Returns the food value grass provides
     * @return GRASS_FOOD_VALUE
     */
    protected int getGrassFoodValue() {
        return GRASS_FOOD_VALUE;
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }


}
