import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move,breed,eat zebras, eat topis, and die.
 *
 * @version 2020.02.13
 */

public class Lion extends Predator
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 50;
    // The age to which a lion can live.
    private static final int MAX_AGE = 370;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.424;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random RAND = Randomizer.getRandom();

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE, MAX_LITTER_SIZE, BREEDING_AGE, BREEDING_PROBABILITY, RAND);
        if(randomAge) {
            setAge(getRand().nextInt(getMaxAge()));
            setFoodLevel(getRand().nextInt(getZebraFoodValue()));
        }
        else {
            setAge(0);  
            setFoodLevel(getZebraFoodValue());
        }
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * zebras, topis. In the process, it might breed, die of hunger,
     * die of disease or die of old age.
     * Lions are twice as active in the night
     * @param field The field currently occupied.
     * @param newLions A list to return newly born lions.
     */
    @Override
    public void act(List<Organism> newLions, TimeCounter time) {
        if(time.isNight()) {
            super.act(newLions, time);
            super.act(newLions, time);
        } else {
            super.act(newLions,time);
        }
    }

}
