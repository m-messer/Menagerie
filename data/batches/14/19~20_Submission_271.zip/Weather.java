/**
 * Provide weather for the simulation.
 * This includes an identifying string of the current weather 
 *
 * @version 2020.02.13
 */
public class Weather
{
    //The current weather
    private String currentWeather;
    //The interval of rain (in days)
    private int rainInterval = 3;

    /**
     * Initialises the private fields
     */
    public Weather()
    {
        currentWeather = "Rain";
    }

    /**
     * Sets the weather based on the day
     * @param the current day count
     */
    public void setWeather(int day) {
        if(day % rainInterval == 0) {
            currentWeather = "Rain";
        } else {
            currentWeather = "No rain";
        }
    }

    /**
     * Initialises the rainInterval field to optimum value (i.e. 3)
     */
    public void initRainInterval() {
        rainInterval = 3;
    }
    
    /**
     * Returns true if it is raining, false otherwise
     * @return boolean
     */
    public boolean isRaining() {
        return currentWeather.equals("Rain");
    }

    /**
     * Returns the current weather string
     * @return currentWeather
     */
    public String getCurrentWeather() {
        return currentWeather;
    }
    
    /**
     * Sets the rain interval (day)
     */
    public void setRainInterval(int n) {
        rainInterval = n;
    }
    
    /**
     * Gets the rain interval (day)
     * @returns rainInterval
     */
    public int getRainInterval() {
        return rainInterval;
    }
    
    /**
     * Decrements the interval of rain (in days)
     * Interval cannot be less than 1
     */
    public void decRainInterval() {
        if(rainInterval > 1) {
            rainInterval--;
        }
    }
    
    /**
     * Increments the interval of rain (in days)
     */
    public void incRainInterval() {
            rainInterval++;
    }
}
