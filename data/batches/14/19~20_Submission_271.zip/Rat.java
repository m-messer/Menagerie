import java.util.List;
import java.util.Random;

/**
 * A simple model of a cane rat.
 * Cane rats age, move, eat plants, breed, and die. 
 *
 * @version 2020.02.13
 */
public class Rat extends Prey
{
    // Characteristics shared by all cane rats (class variables).

    // The age at which a rat can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a rat can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a rat breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // A shared random number generator to control breeding.
    private static final Random RAND = Randomizer.getRandom();

    /**
     * Create a new rat. A rat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rat(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE, MAX_LITTER_SIZE, BREEDING_AGE, BREEDING_PROBABILITY, RAND);
        setAge(0);
       
        if(randomAge) {
            setAge(getRand().nextInt(getMaxAge()));
            setFoodLevel(getRand().nextInt(getGrassFoodValue()));
        }
        else {
            setAge(0);  
            setFoodLevel(getGrassFoodValue());
        }
    }

}
