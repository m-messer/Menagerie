import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of predators.
 *
 * @version 2020.02.13
 */

public abstract class Predator extends Animal
{
    public Predator(Field field, Location location, int maxAge, int maxLitterSize, int breedingAge, double breedingProb, Random rand) {
        super(field, location, maxAge, maxLitterSize, breedingAge, breedingProb, rand);

    }

    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * die of old age, or die of disease
     * @param field The field currently occupied.
     * @param newPredators A list to return newly born predators.
     */

    public void act(List<Organism> newPredators, TimeCounter time)
    {
        super.act(newPredators, time);
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPredators);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Returns the adjacent location where there is a prey; returns null if there aren't any.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if(zebra.isAlive()) { 
                    zebra.setDead();
                    setFoodLevel(getFoodLevel() + getZebraFoodValue());
                    return where;
                }
            } else if(animal instanceof Topi) {
                if(this instanceof Lion) {
                    Topi topi = (Topi) animal;
                    if(topi.isAlive()) { 
                        topi.setDead();
                        setFoodLevel(getFoodLevel() + getTopiFoodValue());
                        return where;
                    }
                }
            } else if(animal instanceof Rat) {
                if(this instanceof Cheetah) {
                    Rat rat = (Rat) animal;
                    if(rat.isAlive()) { 
                        rat.setDead();
                        setFoodLevel(getFoodLevel() + getRatFoodValue());
                        return where;
                    }
                }
            }
        }
        return null;
    }
    
    }
