import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of preys.
 *
 * @version 2020.02.13
 */

public abstract class Prey extends Animal
{
    public Prey(Field field, Location location, int maxAge, int maxLitterSize, int breedingAge, double breedingProb, Random rand) {
        super(field, location, maxAge, maxLitterSize, breedingAge, breedingProb, rand);

    }

    /**
     * This is what the prey does most of the time: it feeds on
     * plants. In the process, it might breed, die of hunger,
     * die of old age, or die of disease.
     * @param field The field currently occupied.
     * @param newPredators A list to return newly born prey.
     */
    public void act(List<Organism> newPreys, TimeCounter time)
    {
        super.act(newPreys, time);
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPreys);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Returns the adjacent location where there is grass; returns null if there aren't any.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Grass) {
                Grass grass = (Grass) organism;
                if(grass.isAlive()) { 
                    grass.decrementLifeline();
                    setFoodLevel(getGrassFoodValue());
                    if(!grass.isAlive()) {
                        return where;
                    } else {
                        return null;
                    }
                                
                }

            }
        }
        return null;
    }
}
