import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2029.02.22
 */
public abstract class Animal extends Organism
{

    // The animal's age.
    private int age;
    // The animal's maximum age
    private final int MAX_AGE;
    // The age at which a fox can start to breed.
    private final int BREEDING_AGE;
    // The animal's food level
    private int foodLevel;
    // The gender of the animal
    private boolean isFemale;
    // Indicates whether an animal is diseased or not
    private boolean isDiseased;
    // The duration (steps) for which an animal can remain alive after getting disease
    private int diseaseLifespan;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, int maxAge, int maxLitterSize, int breedingAge, double breedingProb, Random rand)
    {
        super(field, location, maxLitterSize, breedingProb, rand);
        MAX_AGE = maxAge;
        BREEDING_AGE = breedingAge;
        isFemale = rand.nextBoolean();
        isDiseased = false;
        diseaseLifespan = 3;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    @Override
    public void act(List<Organism> newOrganisms, TimeCounter time) {
        if(time.getDiseaseObject().isDiseaseDay()) {
            if(!this.isDiseased()) {
                isDiseased = (getRand().nextInt(50000) == 0);
            }
        }

        if(this.isDiseased()) {
            decrementLifespan();
        }
    }

    /**
     * Returns the gender of the animal
     * @return isFemale (If True, then animal is female;
     * animal is male otherwise)
     */
    protected boolean isFemale() {
        return isFemale;
    }

    /**
     * Returns whether the animal is diseased or not
     * @return isFemale (If True, then animal is diseased;
     * not diseased otherwise)
     */
    protected boolean isDiseased() {
        return isDiseased;
    }

    /**
     * Sets the animal's isDiseased field to True
     */
    protected void setDiseased() {
        isDiseased = true;
    }

    /**
     * Returns the maximum age of the animal
     * @return MAX_AGE
     */
    protected int getMaxAge()  {
        return MAX_AGE;
    }

    /**
     * Returns the breeding age of the animal
     */
    protected int getBreedingAge()  {
        return BREEDING_AGE;
    }

    /**
     * Returns the age of the animal
     * @return age
     */
    protected int getAge() {
        return age;
    }

    /**
     * Sets the age of the animal
     * @param newAge
     */
    protected void setAge(int newAge) {
        age = newAge;
    }

    /**
     * Returns the food level of the animal
     * @return foodLevel
     */
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Sets the food level of the animal
     * @param newFoodLevel
     */
    protected void setFoodLevel(int newFoodLevel) {
        foodLevel = newFoodLevel;
    }

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Decrease the number of steps left for an animal before it dies
     */
    protected void decrementLifespan() {
        diseaseLifespan--;
        if(diseaseLifespan <= 0) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * An animal can breed if it has reached the breeding age and there is
     * another animal of the same species but opposite gender in adjacent cells. 
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        boolean hasPartner = false;
        int partnerAge = 0;
        while(it.hasNext()) {
            Location where = it.next();
            Object neighbour = field.getObjectAt(where);
            if(neighbour != null && neighbour.getClass() == this.getClass()) {
                Animal animal = (Animal) neighbour;
                if((this.isFemale() && !animal.isFemale()) 
                || !this.isFemale() && animal.isFemale()) {
                    hasPartner = true;
                    partnerAge = animal.getAge();
                    if(this.isDiseased()) {
                        animal.setDiseased();
                    }
                    break;
                }
            }
        }

        return hasPartner && age >= BREEDING_AGE && partnerAge >= BREEDING_AGE;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(Random rand)
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    protected void giveBirth(List<Organism> newOrganisms)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(getRand());
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if(this instanceof Lion) {
                Lion young = new Lion(false, field, loc);
                newOrganisms.add(young);
            } else if(this instanceof Cheetah) {
                Cheetah young = new Cheetah(false, field, loc);
                newOrganisms.add(young);
            }else if(this instanceof Zebra) {
                Zebra young = new Zebra(false, field, loc);
                newOrganisms.add(young);
            } else if(this instanceof Topi) {
                Topi young = new Topi(false, field, loc);
                newOrganisms.add(young);
            } else if(this instanceof Rat) {
                Rat young = new Rat(false, field, loc);
                newOrganisms.add(young);
            }

        }
    }
}
