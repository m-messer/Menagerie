import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple simulator, based on a rectangular field
 * containing animals and plants in the savannah.
 *
 * @version 2029.02.22
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.00628;
    // The probability that a cheetah will be created in any given grid position.
    private static final double CHEETAH_CREATION_PROBABILITY = 0.0061;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.115;  
    // The probability that a topi will be created in any given grid position.
    private static final double TOPI_CREATION_PROBABILITY = 0.10; 
    // The probability that a rat will be created in any given grid position.
    private static final double RAT_CREATION_PROBABILITY = 0.13;  
    // The probability that a patch of grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.044;  

    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The time of day
    private TimeCounter time;
    // Determines if simulator is currently running
    private boolean isRunning;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        isRunning = false;
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Initialise the time counter
        time = new TimeCounter();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Cheetah.class, Color.RED);
        view.setColor(Topi.class, Color.PINK);
        view.setColor(Zebra.class, Color.LIGHT_GRAY);
        view.setColor(Rat.class, Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);

        // Setup a valid starting point.
        reset();

    }

    /**
     * Returns the time object
     * @return time
     */
    public TimeCounter getTimeObject() {
        return time;
    }

    /**
     * Returns the boolean isRunning
     */
    public boolean isRunning() {
        return isRunning;
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        isRunning = true;
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
        isRunning = false;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public void simulateOneStep()
    {
        //step++;
        time.advanceTime(++step);

        // Provide space for newborn organisms.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all zebras act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms, time);
            if(! organism.isAlive()) {
                it.remove();
            }
        }

        // Add the newly created organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field, time);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {

        step = 0;
        time.initialiseTime();
        time.getWeatherObject().initRainInterval();
        time.getDiseaseObject().initDiseaseInterval();
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, time);
    }

    /**
     * Randomly populate the field with lions and zebras.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    organisms.add(lion);
                } else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah = new Cheetah(true, field, location);
                    organisms.add(cheetah);
                } else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    organisms.add(zebra);
                } else if(rand.nextDouble() <= TOPI_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Topi topi = new Topi(true, field, location);
                    organisms.add(topi);
                } else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(true, field, location);
                    organisms.add(rat);
                } else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(field, location);
                    organisms.add(grass);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
