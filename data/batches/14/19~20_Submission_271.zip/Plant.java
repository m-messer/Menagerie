import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing characteristics of plants in this simulation.
 *
 * @version 2029.02.22
 */
public abstract class Plant extends Organism
{
    // The number of times a plant can be eaten before it is considered completely eaten
    private int lifeline;

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location, int maxLitterSize,double breedingProb, Random rand) {
        super(field, location, maxLitterSize, breedingProb, rand);
        this.lifeline = lifeline;
    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     */
    @Override
    public void act(List<Organism> newPlants, TimeCounter time)
    {
        if(isAlive()) {
            giveBirth(newPlants);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @param Randomiser
     * @return The number of births (may be zero).
     */
    protected int breed(Random rand)
    {
        int births = 0;
        if(rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Check whether or not this plant is to breed at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly bred plants.
     */
    protected void giveBirth(List<Organism> newOrganisms)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(getRand());
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if(this instanceof Grass) {
                Grass young = new Grass(field, loc);
                newOrganisms.add(young);
            }
        }
    }

    /**
     * Updates the lifeline value
     * @param lifelineVal 
     */
    protected void setLifeline(int lifelineVal) {
        lifeline = lifelineVal;
    }

    /**
     * Returns the current lifeline value
     * @return lifeline
     */
    protected int getLifeline() {
        return lifeline;
    }

    /**
     * Decrements the lifeline value
     * Can remove the plant from location
     */
    protected void decrementLifeline() {
        lifeline--;
        if(lifeline <= 0) {
            setDead();
        }
    }

}
