import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a cheetah.
 * Cheetahs age, breed, move, eat zebras, eat rats, and die.
 *
 * @version 2020.02.13
 */
public class Cheetah extends Predator
{
    // Characteristics shared by all cheetahs (class variables).

    // The age at which a cheetah can start to breed.
    private static final int BREEDING_AGE = 50;
    // The age to which a cheetah can live.
    private static final int MAX_AGE = 400;
    // The likelihood of a cheetah breeding.
    private static final double BREEDING_PROBABILITY = 0.453;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random RAND = Randomizer.getRandom();

    /**
     * Create a cheetah. A cheetah can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cheetah will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cheetah(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE, MAX_LITTER_SIZE, BREEDING_AGE, BREEDING_PROBABILITY, RAND);
        if(randomAge) {
            setAge(getRand().nextInt(getMaxAge()));
            setFoodLevel(getRand().nextInt(getZebraFoodValue()));
        }
        else {
            setAge(0);  
            setFoodLevel(getZebraFoodValue());
        }
    }
}
