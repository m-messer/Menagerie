import java.util.HashMap;
/**
 * Write a description of class weather here.
 *
 * @version (a version number or a date)
 */
public class weather {
    private static final String CLEAR = "clear";
    private static final String RAINY = "rainy";
    private static final String SUNNY = "sunny";
    private static final String SNOWY = "snowy";
    
    private String currentType;
    private HashMap<String, String[]> pattern;
    
    public weather () {
        pattern = new HashMap<String, String[]>();
        pattern.put(CLEAR, new String[] {RAINY, SUNNY, SNOWY});
        pattern.put(RAINY, new String[] {CLEAR, SUNNY, SNOWY});
        pattern.put(SUNNY, new String[] {CLEAR, RAINY});
        pattern.put(SNOWY, new String[] {CLEAR, RAINY});
        
        currentType = "clear";
    }
    
    public void changeWeather () {
        String[] options = pattern.get(currentType);
        currentType = options[Randomizer.getRandom().nextInt(options.length)];
    }
    
    public String getCurrent () {
        return currentType;
    }
}
