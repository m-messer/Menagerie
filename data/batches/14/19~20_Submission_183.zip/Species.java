import java.util.*;
/**
 * A class representing shared characteristics of species.
 *
 * @version 2020.02.21 
 */
public abstract class Species {
    
    private Simulator simulator;
    private Field field;
    private Location location;
    private int germs;
    private boolean alive;
    protected static Random RNG = Randomizer.getRandom();

    public Species (Field field, Location location, int germs, Simulator sim) {
        this.field = field;
        this.germs = germs;
        alive=true;
        simulator = sim;
        setLocation(location);
    }

    protected Simulator getSim(){
        return simulator;
    }

    protected Field getField(){
        return field;
    }

    protected Location getLocation(){
        return location;
    }

    protected void addChild (Species specimen) {
        simulator.addSpecimen(specimen);
    }

    protected int getGerms(){
        return germs;
    }

    protected void setGerms (int germs) {
        this.germs = germs;
    }

    protected void setLocation(Location loc){
        if(location != null) {
            field.clear(location);
        }
        location = loc;
        field.place(this, loc);
    }

    protected void incrementGerms(int n){
        germs+=n;
        if (germs < 0) {
            germs = 0;
        }
    }

    protected void setDead () {
        alive = false;
    }

    public boolean isAlive () {
        return alive;
    }

    public abstract void act ();

    protected abstract int getNutrients();

}
