import java.util.*;
/**
 * A class representing shared characteristics of plants.
 * Plant can spread, have germs, and dies.
 *
 * @version 2020.02.21 
 */
public abstract class Plant extends Species {    

    /**
     * The base constructor for a plant. It only passes this data onto the superclass, species.
     * @param field The field for the plant to exist in.
     * @param location The location of the plant in the field.
     * @param simulator The simulator that the plant exists in.
     */
    public Plant (Field field, Location location, int germs, Simulator simulator) {
        super (field, location, germs, simulator);
    }

    /**
     * @return The germs an animal will pickup from eating this plant.
     */
    public abstract int getGermModifier ();

    /**
     * Creates a new plant with the same type as the caller in an adjacent space in the field.
     */
    public void spread () {
        Location loc = getLocation();
        Field field = getField();
        List<Location> locations = field.adjacentLocations(loc);
        for (Location location : locations) {
            if (field.getPlantAt(location) == null) {
                addChild(getChild(location));
            }
        }
    }

    /**
     * Individual plants will add additional behaviour, this method is the base behaviour of responding to germs.
     */
    public void act () {
        if (getGerms() > 200) {
            setDead();
        }
    }

    /**
     * Sets the plant as being dead and removes it from the field.
     */
    protected void setDead () {
        super.setDead();
        Location location = getLocation();
        Field field = getField();
        if(location != null) {
            field.clearPlants(location);
            location = null;
            field = null;
        }
    }

    /**
     * @return A new plant with the same type as the caller.
     */
    protected abstract Plant getChild (Location location);

}
