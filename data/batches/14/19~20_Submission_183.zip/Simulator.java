import java.util.*;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Orthorus,Cat,Mouse,Dragon,Megaworm,Cattle,two type of plants: Grass, Sage 
 *
 * @version 2020.02.21 
 */
public class Simulator{
    
    private static final int DEFAULT_WIDTH = 200;
    private static final int DEFAULT_DEPTH = 100;
    
    private static final double CATTLE_CREATION_PROBABLITY = 0.065;
    private static final double MOUSE_CREATION_PROBABILITY = 0.075;
    
    private static final double CAT_CREATION_PROBABILITY = 0.045; 
    private static final double MEGAWORM_CREATION_PROBABILITY = 0.025;
    private static final double ORTHORUS_CREATION_PROBABILITY = 0.0395;
    private static final double DRAGON_LIMIT = 2;
    
    private static final double GRASS_CREATION_PROBABILITY = 0.6;
    private static final double SAGE_CREATION_PROBABILITY = 1;
    
    private List<Species> species;
    private List<Species> newSpecies;
    private Field field;
    private int step;
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        species = new ArrayList<>();
        newSpecies = new ArrayList<>();
        field = new Field(depth, width);

        view = new SimulatorView(depth, width);
        view.setColor(Mouse.class, Color.ORANGE);
        view.setColor(Cat.class, Color.BLUE);
        view.setColor(Dragon.class,Color.RED);
        view.setColor(Megaworm.class,Color.PINK);
        view.setColor(Orthorus.class,Color.BLACK);
        view.setColor(Cattle.class,Color.YELLOW);

        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Sage.class, new Color(40, 155, 40));

        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (5000 steps).
     */
    public void runLongSimulation()
    {
        simulate(5000);
    }

    /**
     * Run the simulation with given delay
     * @param delayTime the delay for each step
     */
    public void runLongSimulation (int delayTime) {
        simulate(5000, delayTime);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
        }
    }

    /**
     * Run the simulation with given number of steps and delay
     * @param Numsteps number of steps to run the simulation for
     * @param delayTime the delay of each step
     */
    public void simulate(int numSteps, int delayTime)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(delayTime);
        }
    }

    public void startSimulation () {
        simulateOneStep();
        runLongSimulation();
    }

    public void startSimulation (int delayTime) {
        simulateOneStep();
        runLongSimulation(delayTime);
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        field.timePasses();
        for(Iterator<Species> it = species.iterator(); it.hasNext(); ) {
            Species specimen = it.next();

            specimen.act();
            if(!specimen.isAlive()) {
                it.remove();
            }
        }

        if (newSpecies.size() > 0) {
            species.addAll(newSpecies);
            newSpecies.clear();
        }
        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        species.clear();
        populate();
        field.resetTime();
        view.showStatus(step, field);
    }

    /**
     * 
     */
    public void addSpecimen (Species specimen) {
        newSpecies.add(specimen);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        Location topLeft = new Location(0, 0);
        Location bottomRight = new Location(field.getDepth() - 1, field.getWidth() - 1);
        species.add(new Dragon("female", field, topLeft, this));
        species.add(new Dragon("male",field, bottomRight, this));
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if ((row == 0 && col == 0) || (row == field.getDepth() - 1 && col == field.getWidth() - 1)) {
                    continue;
                }

                if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location, this);
                    species.add(mouse);
                }
                else if (rand.nextDouble() <= CATTLE_CREATION_PROBABLITY){
                    Location location = new Location (row,col);
                    Cattle cow = new Cattle(true, field, location, this);
                    species.add(cow);
                }
                else if(rand.nextDouble() <= CAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cat cat = new Cat(true, field, location, this);
                    species.add(cat);
                }
                else if (rand.nextDouble() <= MEGAWORM_CREATION_PROBABILITY) {
                    Location location = new Location (row, col);
                    Megaworm megaworm = new Megaworm(true, field, location, this);
                    species.add(megaworm);
                }
                else if (rand.nextDouble() <= ORTHORUS_CREATION_PROBABILITY) {
                    Location location = new Location (row, col);
                    Orthorus orthorus = new Orthorus(true, field, location, this);
                    species.add(orthorus);
                }

                if (rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(field, location, this);
                    species.add(grass);
                }
                else if (rand.nextDouble() <= SAGE_CREATION_PROBABILITY) {
                    Location location = new Location (row, col);
                    Sage sage = new Sage(field, location, this);
                    species.add(sage);
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
        }
    }
}
