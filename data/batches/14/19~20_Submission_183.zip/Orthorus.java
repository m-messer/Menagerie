import java.util.*;
/**
 * A simple model of a Orthorus (nocturnal predator).
 * Orthorus ages, move, eat cat,and get germs as they eat and die.
 *
 * @version 2020.02.21 
 */
public class Orthorus extends Carnivore{

    private static final int BREEDING_AGE = 350;
    private static final int MAX_AGE = 960;
    private static final double BREEDING_PROBABILITY = 0.5;
    private static final int MAX_LITTER_SIZE = 3;
    private static final int ORTHORUS_FOOD_VALUE = 250;
    private static final int NUTRIENTS = 70;

    /**
     * Create a Orthorus. A Orthorus can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Orthorus will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param sim the Simulator that cat within
     */
    public Orthorus(boolean randomAge, Field field, Location location, Simulator sim)
    {
        super(randomAge,field, location, 0,MAX_AGE,ORTHORUS_FOOD_VALUE, sim);
    }

    /**
     * an animal has immunity againsts germs
     * @return lowered germs depending on the immune system 
     */
    protected int getImmunityModifier(){
        return (int)(getGerms() * -0.4); 
    }

    /**
     * @return the breeding age of the animal
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * @return the breeding probablity of the animal
     */
    protected double getBreedingProbablity(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the max live birth off spring
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE; 
    }

    /**
     * @param location the location of the new child
     * @return a child of the current anima
     * 
     */
    protected Animal getChild (Location location) {
        return new Orthorus(false, getField(), location, getSim());
    }

    /**
     * @param mate the mate of the animal 
     * @return true if the mate is the same animal and male, false otherwise
     */
    protected boolean isMate (Animal mate) {
        if (mate == null) {
            return false;
        }
        else if (mate instanceof Orthorus) {
            if (((Orthorus)mate).getGender().equals("male")) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return true if the animal is active during the current time, false otherwise 
     */
    protected boolean isActive () {
        return getField().isNight();
    }

    /**
     * @return the nutrients that this animal gives
     */
    protected int getNutrients () {
        return NUTRIENTS;
    }

    /**
     * @param specimen the specimen that might be eaten
     * @return true if the specimen is a prey/food of this animal, false otherwise
     */
    protected boolean isFoodType(Species specimen){
        if(specimen  instanceof Cat){
            return true;
        }
        return false; 
    }
}
