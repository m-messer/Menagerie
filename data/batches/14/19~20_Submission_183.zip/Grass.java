
/**
 * Provides behaviour to simulate a simple representation of grass.
 *
 * @version 2020.2.21
 */
public class Grass extends Plant {
    
    private final static int GERMS = 20;
    private final static int MAX_LIFE = 350;
    private final static int LIFE_VARY = 100;
    private final static int NUTRIENTS = 35;
    private int life;

    /**
     * Constructs a new grass object.
     * @param field The field for the grass to exist in.
     * @param location The location of the grass in the field.
     * @param simulator The simulator that the grass exists in.
     */
    public Grass (Field field, Location location, Simulator simulator) {
        super(field, location, GERMS, simulator);
        life = Randomizer.getRandom().nextInt(LIFE_VARY) + MAX_LIFE;
    }

    /**
     * @return The germ value of the grass. (20);
     */
    public int getGermModifier () {
        return GERMS;
    }

    /**
     * The behaviour of grass on each step.
     * Grass heals during sun and spreads during rain.
     * It is damaged in snow.
     */
    public void act () {
        String weather = getField().getWeather();
        switch(weather){
            case "rainy":
                spread();
                break;
            case "snowy":
                life -= RNG.nextInt(2);
                break;
            case "sunny":
                life++;
                break;
            case "clear":
                break;
        }     
        if (life <= 0) {
            setDead();
        }
        else if (life > MAX_LIFE) {
            life = MAX_LIFE;
        }
    }

    protected Plant getChild(Location loc){
        return new Grass(getField(),loc,getSim());
    }

    protected int getNutrients () {
        return NUTRIENTS;
    }
}
