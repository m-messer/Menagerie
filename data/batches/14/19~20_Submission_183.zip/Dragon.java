import java.util.*;
/**
 * A simple model of a Dragon (predator).
 * Dragon ages, move, eat any animal except for itself,and get germs as they eat and die.
 *
 * @version 2020.02.21
 */
public class Dragon extends Carnivore{
    
    private static final int BREEDING_AGE = 700;
    private static final int MAX_AGE = 9999999;
    private static final double BREEDING_PROBABILITY = 1;
    private static final int MAX_LITTER_SIZE = 2;
    private static final int DRAGON_FOOD_VALUE = 1500;
    private static final int NUTRIENTS = 999999;

    public Dragon(String gender, Field field, Location location, Simulator sim)
    {
        super(gender, false, field, location, 0,MAX_AGE,DRAGON_FOOD_VALUE, sim);
    }

    public Dragon (Field field, Location location, Simulator sim) {
        super(false, field, location, 0, MAX_AGE, DRAGON_FOOD_VALUE, sim);
    }

    /**
     * an animal has immunity againsts germs
     * @return lowered germs depending on the immune system 
     */
    protected int getImmunityModifier(){
        return (int)(getGerms() *-0.3); 
    }

    /**
     * @return the breeding age of the animal
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * @return the breeding probablity of the animal
     */
    protected double getBreedingProbablity(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the max live birth off spring
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE; 
    }

    /**
     * @return a child of the current animal 
     */
    protected Animal getChild (Location location) {
        return new Dragon(getField(), location, getSim());
    }

    /**
     * @param mate the mate of the animal 
     * @return true if the mate is the same animal and male, false otherwise
     */
    protected boolean isMate (Animal mate) {
        if (mate == null) {
            return false;
        }
        else if (mate instanceof Dragon) {
            if (((Dragon)mate).getGender().equals("male")) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return true if the animal is active during the current time, false otherwise 
     */
    protected boolean isActive () {
        return true;
    }

    /**
     * @return the nutrients that this animal gives
     */
    protected int getNutrients () {
        return NUTRIENTS;
    }

    /**
     * @param specimen the specimen that might be eaten
     * @return true if the specimen is a prey/food of this animal, false otherwise
     */
    protected boolean isFoodType(Species specimen ){
        if(specimen  instanceof Animal){
            return true;
        }
        return false; 
    }
}
