
/**
 * A basic representation of sage, a plant that aids the immune system of animals that eat it.
 *
 * @version 2020.2.21
 */
public class Sage extends Plant {
    private final static int GERMS = 20;
    private final static int MAX_LIFE = 350;
    private final static int LIFE_VARY = 100;
    private final static int NUTRIENTS= 40;
    private int life;

    /**
     * Constructs a sage object. Sage is a plant that will reduce the germ level of whomever eats it.
     * @param field The field for the sage to exist in.
     * @param location The location of the sage in the field.
     * @param simulator The simulator that the plant exists in.
     */
    public Sage (Field field, Location location, Simulator simulator) {
        super(field, location, GERMS, simulator);
        life = Randomizer.getRandom().nextInt(LIFE_VARY) + MAX_LIFE;
    }

    public int getGermModifier () {
        return -50;
    }

    public void act () {
        String weather = getField().getWeather();
        switch (weather) {
            case "rainy":
                life++;
                break;
            case "snowy":
                life -= RNG.nextInt(2);
                break;
            case "sunny":
                spread();
                break;
            case "clear":
                break;
        }     
        if (life <= 0) {
            setDead();
        }
        else if (life > MAX_LIFE) {
            life = MAX_LIFE;
        }
    }

    protected Plant getChild(Location loc){
        return new Sage(getField(),loc,getSim());
    }

    protected int getNutrients () {
        return NUTRIENTS;
    }
}
