import java.util.*;
/**
 * An abstract class that allows overrides for herbivore specific behaviour.
 *
 * @version 2020.02.22
 */
public abstract class Herbivore extends Animal {
    public Herbivore (boolean randomAge, Field field, Location location, int germs, int age, int maxFoodLevel, Simulator sim) {
        super(randomAge, field, location, germs, age, maxFoodLevel, sim);
    }
    
    /**
     * Constructor overload, it allows for an animal to be created with a predetermined gender.
     * @param gender The gender of the animal.
     */
    public Herbivore (String gender, boolean randomAge, Field field, Location location, int germs,int age,int maxFoodLevel, Simulator sim) {
        super(gender, randomAge, field, location, germs, age, maxFoodLevel, sim);
    }
    
    /**
     * Locates and returns the position of an adjacent food species.
     * @return The location of an adjacent food species.
     */
    protected Location findFood () {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        adjacent.add(getLocation()); // Might be standing on food already.
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Plant specimen = field.getPlantAt(where);
            if(isFoodType(specimen) && specimen.isAlive() && (field.getObjectAt(where) == null || field.getObjectAt(where) == this)) {
                incrementGerms(specimen.getGerms());
                eatFood(specimen.getNutrients());
                specimen.setDead();
                return where;
            }
        }
        return null;
    }
}
