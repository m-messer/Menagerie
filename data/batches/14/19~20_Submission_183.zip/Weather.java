import java.util.HashMap;
/**
 * Controls the current weather and how it changes.
 *
 * @version 2020.2.21
 */
public class Weather {
    
    private static final String CLEAR = "clear";
    private static final String RAINY = "rainy";
    private static final String SUNNY = "sunny";
    private static final String SNOWY = "snowy";
    private String currentType;
    private HashMap<String, String[]> pattern;
    
    /**
     * Creates a weather object and initialises it to neutral weather.
     */
    public Weather () {
        pattern = new HashMap<String, String[]>();
        pattern.put(CLEAR, new String[] {RAINY, SUNNY, SNOWY});
        pattern.put(RAINY, new String[] {CLEAR, RAINY, SUNNY, SNOWY});
        pattern.put(SUNNY, new String[] {CLEAR, RAINY, SUNNY});
        pattern.put(SNOWY, new String[] {CLEAR, RAINY});
        
        currentType = "clear";
    }
    
    /**
     * Using the weather pattern to randomly select a new weather type.
     */
    public void changeWeather () {
        String[] options = pattern.get(currentType);
        currentType = options[Randomizer.getRandom().nextInt(options.length)];
    }
    
    /**
     * @return A string representing the current weather type.
     */
    public String getCurrent () {
        return currentType;
    }
}
