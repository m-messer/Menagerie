import java.util.*;

/**
 * A class representing shared characteristics of animals.
 * An animal has gender,age,foodlevel(current), maxFoodLevel,nocturnality indicator 
 *
 * @version 2020.02.21 (2)
 */
public abstract class Animal extends Species
{
    private String gender;
    private int age;
    private int foodLevel;
    private int maxFoodLevel;
    protected static Random RNG = Randomizer.getRandom();
    private boolean nocturnal;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param germs the germs counter 
     * @param age the age of the animal
     * @param maxFoodLevel the limit of food for the animal
     * @param sim the simulator that the animal in
     */
    public Animal (boolean randomAge, Field field, Location location, int germs, int age, int maxFoodLevel, Simulator sim) {
        super(field, location, germs, sim);
        this.age = 0;
        if (randomAge) {
            this.age = RNG.nextInt((int)((age - getBreedingAge()) * 0.6)) + getBreedingAge();
        }
        foodLevel = maxFoodLevel;
        this.maxFoodLevel = maxFoodLevel;
        int genderInt = RNG.nextInt(2);
        if (genderInt == 0) {
            gender = "female";
        }
        else {
            gender = "male";
        }
    }

    /**
     * Constructor overload, it allows for an animal to be created with a predetermined gender.
     * @param gender The gender of the animal.
     */
    public Animal (String gender, boolean randomAge, Field field, Location location, int germs,int age,int maxFoodLevel, Simulator sim) {
        this(randomAge, field, location, germs, age, maxFoodLevel, sim);
        this.gender = gender.toLowerCase();
    }

    /**
     * @return gender
     */
    public String getGender(){
        return gender;
    }

    /**
     * @return age
     */
    public int getAge(){
        return age;
    }

    /**
     * increament age by one
     */
    public void incrementAge(){
        age++;

    }

    /**
     * decreases foodLevel 
     * when foodLevel<=0 the animal dies
     */
    public void incrementHunger(){
        foodLevel--;
        if(foodLevel<=0){
            setDead();
        }
    }

    /**
     * @return foodLevel
     */
    public int getFoodLevel(){
        return foodLevel;
    }

    /**
     * setter method for foodLevel
     * @param foodLevel 
     */
    public void setFoodLevel(int foodLevel){
        this.foodLevel = foodLevel; 
    }

    /**
     * Creates a new animal of the same type as long as conditions are met.
     * This animal must have a sufficent amount of food and the partner must be valid.
     * The mate with the higher bacteria level will spread its germs to its partner.
     */
    protected void giveBirth () {
        Field field = getField();
        List<Location> mates = field.adjacentLocations(getLocation());
        List<Location> free = new ArrayList<Location>();
        boolean willBreed = false;
        Iterator<Location> it = mates.iterator();
        while (it.hasNext()) {
            Location loc = it.next();
            Animal animal = (Animal)field.getObjectAt(loc);
            if (animal == null) {
                free.add(loc);
            }
            else if (isMate(animal) && canBreed() && animal.canBreed()) {
                if (getGerms() > animal.getGerms()) {
                    animal.setGerms(getGerms());
                }
                else {
                    setGerms(animal.getGerms());
                }
                willBreed = true;
            }
        }
        int births = breed();
        for(int b = 0; willBreed && b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = getChild(loc);
            addChild(young);
        }
    }

    /**
     * to kill the animal and remove it off the grid
     */
    protected void setDead () {
        super.setDead();
        Location location = getLocation();
        Field field = getField();
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * check if it can breed and within the probablity of breeding
     * @return births number of new borns
     */
    protected int breed (){
        int births = 0;
        if(canBreed() && RNG.nextDouble() <= getBreedingProbablity()) {
            births = RNG.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * check if it can breed
     * @return true if it reached breeding age
     */
    public boolean canBreed () {
        return (getAge() >= getBreedingAge() && foodLevel >= 0.33 * maxFoodLevel);
    }

    /**
     * 
     */
    protected void eatFood (int nutrientValue) {
        foodLevel += nutrientValue;
        if (foodLevel > maxFoodLevel) {
            foodLevel = maxFoodLevel;
        }
    }

    public void act () {
        incrementHunger();
        incrementAge();
        incrementGerms(getImmunityModifier());
        if(isAlive() && isActive()) {
            if(getGender().equals("female")){
                giveBirth();
            }
            if(foodLevel < maxFoodLevel){
                Location newLocation = findFood();
                if(newLocation == null) { 
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                if(newLocation != null) {
                    setLocation(newLocation);
                }
            }
            else if(foodLevel<=0) {
                setDead();
            }
            else {
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if (newLocation != null) {
                    setLocation(newLocation);
                }
            }
            if (getGerms() >= 420) {
                setDead();
            }
        }
    }

    /**
     * check if food nearby and if the animal can eat that type and 
     * @return the location of prey to move to it
     */
    protected Location findFood (){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Species specimen = field.getObjectAt(where);
            if(isFoodType(specimen) && specimen.isAlive()) {
                incrementGerms(specimen.getGerms());
                eatFood(specimen.getNutrients());
                specimen.setDead();
                return where;
            }
        }
        return null;
    }

    /**
     * @param specimen A species object to query if it is food for this animal.
     * @return Boolean indicating if the object is food for this animal.
     */
    protected abstract boolean isFoodType(Species specimen);

    /**
     * @return Returns the maximum number of births an animal may do.
     */
    protected abstract int getMaxLitterSize();

    /**
     * @return The probability of the animal breeding, should it get the chance.
     */
    protected abstract double getBreedingProbablity();

    /**
     * @return The age at which the animal may begin breeding.
     */
    protected abstract int getBreedingAge();

    /**
     * This method is intended to be called by female animals.
     * All overrides of this method will check for a male partner of the same class.
     * @param mate An animal which may be a potential mate.
     * @return A boolean indicating if the animal is a potential mate.
     */
    protected abstract boolean isMate (Animal mate);

    /**
     * All overrides of this method will return a new animal object of that override's type.
     * @return An animal object that is the same species as the caller.
     */
    protected abstract Animal getChild (Location location);

    /**
     * @return An integer describing how to reduce the current germ level of an animal.
     */
    protected abstract int getImmunityModifier();

    /**
     * Some animals are only active at night, and some only during the day.
     * This method returns if the animal is currently active for the time.
     * @return Whether or not the animal is active.
     */
    protected abstract boolean isActive();

    /**
     * @return The amount of nutrients gained from eating the animal.
     */
    protected abstract int getNutrients();
}
