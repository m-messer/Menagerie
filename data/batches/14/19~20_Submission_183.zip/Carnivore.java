import java.util.*;
/**
 * An abstract class that allows overrides for carnivore specific behaviour.
 *
 * @version 2020.02.22
 */
public abstract class Carnivore extends Animal {
    public Carnivore (boolean randomAge, Field field, Location location, int germs, int age, int maxFoodLevel, Simulator sim) {
        super(randomAge, field, location, germs, age, maxFoodLevel, sim);
    }
    
    /**
     * Constructor overload, it allows for an animal to be created with a predetermined gender.
     * @param gender The gender of the animal.
     */
    public Carnivore (String gender, boolean randomAge, Field field, Location location, int germs,int age,int maxFoodLevel, Simulator sim) {
        super(gender, randomAge, field, location, germs, age, maxFoodLevel, sim);
    }
    
    /**
     * Locates and returns the position of an adjacent food species.
     * @return The location of an adjacent food species.
     */
    protected Location findFood () {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Animal specimen = field.getObjectAt(where);
            if(isFoodType(specimen) && specimen.isAlive()) {
                incrementGerms(specimen.getGerms());
                eatFood(specimen.getNutrients());
                specimen.setDead();
                return where;
            }
        }
        return null;
    }
}