
/**
 * An enumeration class represent the probabilities of
 * different weather events in the simulation. Currently,
 * only rainning is simulated
 *
 * @version 22/02/21
 */
public enum WeatherProbability
{
    RAIN(0.6);
    
    private double weatherProbability;
    
    /**
     * Constructore of WeatherProbability, assign a probability to
     * a weather event
     * 
     * @param weatherProbability The probability that a weather event
     * will happen in any given grid position.
     */
    private WeatherProbability(double weatherProbability) {
        this.weatherProbability = weatherProbability;
    }
    
    /**
     * Return the weather probability of a weather event.
     * 
     * @return weatherProbability The probability that a weather
     * event will happen in any given grid position.
     */
    protected double getWeatherProbability() {
        return weatherProbability;
    }
}
