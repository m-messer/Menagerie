
/**
 * An oversimplified simulation of the time in a day. Time is
 * simulated according to the step of the simulation, each step
 * is equivalent to an hour.
 *
 * @version 24/02/21
 */
public class Time
{
    private int hour;
    private TimeOfDay timeOfDay;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        hour = 0;
        setTimeOfDay();
    }

    /**
     * Increse the hour of the day.
     */
    protected void increaseHour()
    {
        if(hour < 23) {
            hour++;
        } else {
            hour = 0;
        }
        setTimeOfDay();
    }

    /**
     * @return The string representaion of the curent hour
     * of the day in the simulation.
     */
    protected String getTime()
    {
        if(hour < 10) {
            return "0" + hour + ":" + "00";
        }
        return hour + ":00";
    }

    /**
     * Reset the hour of the day.
     */
    protected void reset()
    {
        hour = 0;
    }

    /**
     * @return The time of the day, can either be night or day.
     */
    protected TimeOfDay getTimeOfDay()
    {
        return timeOfDay;
    }

    /**
     * Set the time of the day. time of the day reflect whether
     * the sun is still visible or the sky is fully dark.
     */
    private void setTimeOfDay()
    {
        if(hour >= 6 && hour < 20) {
            this.timeOfDay = TimeOfDay.DAY;
        } else {
            this.timeOfDay = TimeOfDay.NIGHT;
        }
    }
}
