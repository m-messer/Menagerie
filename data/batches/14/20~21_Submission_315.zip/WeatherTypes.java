
/**
 * Enumeration class WeatherTypes - Specify different types of weather.
 *
 * @version 24/02/21
 */
public enum WeatherTypes
{
    RAIN("Rainning"), CLEAR("Clear");
    
    private String status;
    
    /**
     * Constructore of WeatherTypes, assign a status to
     * a weather event
     * @param weatherStatus The status of a weather event
     */
    private WeatherTypes(String weatherStatus) {
        status = weatherStatus;
    }
    
    /**
     * Return the weather status. When there is a rain,
     * the status is rainning, when the sky is clear, the status is clear.
     * @return status The weather status
     */
    protected String getWeatherStatus() {
        return status;
    }
}
