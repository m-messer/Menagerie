import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.HashSet;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 22/02/21
 */
public abstract class Animal
{
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    //The probability that an animal when created would be male or female
    private static final double GENDER_PROBABILITY = 0.5;
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's hunger level
    private int hunger;
    // The animal's age
    private int age;
    // The animal's gender
    private final Gender gender;
    // When the animal sleep, some animal sleep at irregular period through the day
    private HashSet<TimeOfDay> sleepTime;
    
    private boolean illness;

    /**
     * Create a new animal at location in field.An canimal can be created
     * as a new born (age zero) or with a random age.
     * 
     * @param randomAge If true, the animal will have random age
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The maximum age an animal can live
     * @param foodValue The number of steps the animal can take before dying of hunger
     * @param maxConsumption The maximum food consumption of an animal
     */
    public Animal(boolean randomAge, Field field, Location location, int maxAge, int foodValue, int maxConsumption)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        sleepTime = new HashSet<>();
        // By default all animal sleep at night
        sleepTime.add(TimeOfDay.NIGHT);

        if (rand.nextDouble() <= GENDER_PROBABILITY) {
            gender = Gender.Male;
        } else {
            gender = Gender.Female;
        }

        if(randomAge) {
            age = rand.nextInt(maxAge);
        }
        else {
            age = 0;
        }

        setHunger(foodValue, maxConsumption);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, TimeOfDay timeOfDay);

    /**
     * Make this animal find food
     */
    abstract public Location findFood();

    /**
     * Make this animal give birth
     */
    abstract public void giveBirth(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clearAnimal(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * 
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * 
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clearAnimal(location);
        }
        location = newLocation;
        field.placeAnimal(this, newLocation);
    }

    /**
     * Return the animal's field.
     * 
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the animal's age.
     * 
     * @return The animal's age.
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Set the animal's age.
     * 
     * @param age The animal's age.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Return the animal's hunger level
     * 
     * @Return hunger The animal's hunger level
     */
    protected int getHunger() {
        return hunger;
    }

    /**
     * Set the animal's hunger level
     * @param hunger The animal's hunger level.
     * @param maxConsumption The maximum food consumption of an animal.
     */
    protected void setHunger(int hunger, int maxConsumption) {
        if(hunger > 0 && hunger <= maxConsumption) {
            this.hunger = hunger;
        } else {
            this.hunger = maxConsumption;
        }
    }

    /**
     * Increase the age. This could result in the animal's death.
     * 
     * @param maxAge The maximum age an animal can live
     */
    protected void incrementAge(int maxAge)
    {
        if(age < maxAge) {
            age++;
        } else {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        if(hunger > 0) {
            hunger--;
        } else {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births,
     * if the animal can breed.
     * @param breedingProbability The chance that the animal will breed in this step
     * @param maxChild The maximum number of birth an animal can have
     * @param breadingAge The breeding age of the animal
     * @return The number of births (may be zero).
     */
    protected int breed(double breedingProbability, int maxChild, int breadingAge)
    {
        int births = 0;
        if(canBreed(breadingAge) && rand.nextDouble() <= breedingProbability) {
            births = rand.nextInt(maxChild) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @param breedingAge The breeding age of the animal
     * @return True of the animal has reached the breeding age.
     */
    protected boolean canBreed(int breedingAge)
    {
        return age >= breedingAge;
    }

    /**
     * @return Return the animal's gender
     */
    protected Gender getGender()
    {
        return gender;
    }

    /**
     * Check whether the animal is going to sleep.
     * 
     * @param timeOfDay The current time of the day (i.e. day or night)
     * @param sleepTime The set of sleep time of the animal (i.e. day, or night or both)
     * @param sleepProbability The chance that the animal will go to sleep during this time.
     * @return True if the animal is going to sleep.
     */
    protected boolean sleep(TimeOfDay timeOfDay, HashSet<TimeOfDay> sleepTime, double sleepProbability)
    {
        for(TimeOfDay time: sleepTime) {
            if(timeOfDay == time && rand.nextDouble() <= sleepProbability) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return The sleep time of the animal.
     */
    protected HashSet getSleepTime()
    {
        return sleepTime;
    }

    /**
     * Set when the animal tend to sleep
     * @param sleepTime The time of the day that the animal tend
     * to go to sleep.
     */
    protected void setSleepTime(TimeOfDay sleepTime)
    {
        this.sleepTime.clear();
        this.sleepTime.add(sleepTime);
    }

    /**
     * Set when the animal tend to sleep
     * @param day The time of the day that the animal tend
     * to go to sleep.
     * @param night The time of the day that the animal tend
     * to go to sleep.
     */
    protected void setSleepTime(TimeOfDay day, TimeOfDay night)
    {
        sleepTime.clear();
        if(day != night) {
            this.sleepTime.add(day);
            this.sleepTime.add(night);
        } else {
            this.sleepTime.add(TimeOfDay.NIGHT);
        }
    }
    /**
     * Set the disease for animal
     */
    protected void setIllness(){
        this.illness = true;
    }
    /**
     * return the disease status of animal 
     */
    protected boolean getIllnessStatus() {
        return this.illness;
    }
}
