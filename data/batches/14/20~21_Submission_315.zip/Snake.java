import java.util.Iterator;
import java.util.List;

/**
 * A simple model of a snake. Snakes age, gender move, breed, and die.
 *
 * @version 24/02/21
 */
public class Snake extends Animal
{
    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a snake can live.
    private static final int MAX_AGE = 79;
    // The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The likelihood a snake would go to sleep
    private static final double SLEEP_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_CHILD = 10;
    // Number of steps a snake can go before it has to eat again.
    private static final int MICE_FOOD_VALUE = 9;
    // The death rate of disease
    private static final double ILLNESS_DEATH_PROBABILITY = 0.01;
    // The maximum food consumption mesured based on food value
    // which in turn is measured based on the number of steps
    // an animal can take
    private static final int MAX_FOOD_CONSUMPTION = 10;

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, MICE_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
        setSleepTime(TimeOfDay.DAY, TimeOfDay.NIGHT);
    }

    /**
     * This is what the snake does most of the time: it hunts for
     * mices. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param newSnakes A list to return newly born snake's.
     * @param timeOfDay The current time of the day (i.e. day or night)
     */
    public void act(List<Animal> newSnakes, TimeOfDay timeOfDay)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if (this.getIllnessStatus() && rand.nextDouble() <= ILLNESS_DEATH_PROBABILITY){
            setDead();
        }

        if(isAlive()) {
            if(!sleep(timeOfDay, getSleepTime(), SLEEP_PROBABILITY)) {
                giveBirth(newSnakes);
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAnimalAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for mice adjacent to the current location.
     * Only the first live mice is eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        // Only look for food if hungry, the animal just roam around when full
        if(getHunger() / MAX_FOOD_CONSUMPTION * 100 <= 60) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getAnimalAt(where);
                if (animal instanceof Mice) {
                    Mice mice = (Mice) animal;
                    if(mice.isAlive()) {   
                    //The illness mice was eaten
                    if (mice.getIllnessStatus()) {
                        this.setIllness();
                    }
                        mice.setDead();
                        setHunger(getHunger() + MICE_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this snake is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newSnakes A list to return newly born snakes.
     */
    public void giveBirth(List<Animal> newSnakes)
    {
        // New snakes are born into adjacent locations.
        Field field = getField();
        // Get a list of free adjacent locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            if (animal instanceof Snake) {
                Snake snake = (Snake) animal;
                // When male and female meet breeding
                if (snake.isAlive() && this.getGender() != snake.getGender()) {
                    int births = breed(BREEDING_PROBABILITY, MAX_CHILD, BREEDING_AGE);
                    // newly born snakes will be put into free adjacent locations
                    List<Location> free = field.getFreeAnimalAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Snake young = new Snake(false, field, loc);
                        newSnakes.add(young);
                    }
                }
            }
        }
    }
}
