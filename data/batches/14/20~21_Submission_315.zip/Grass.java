import java.util.List;

/**
 * A class representing the grass.
 *
 * @version 24/02/21
 */
public class Grass extends Plant
{
    // The growth rate of the grass
    private static final int GROWTH_RATE = 2;
    // The max grow rate of the grass
    private static final int MAX_GROWTH = 12;
    // The propagate probability of the grass
    private static final double PROPAGATE_PROBABILITY = 0.08;
    // The maximum number of new grass unit that can grow each time.
    private static final int MAX_NEW_PLANT = 1;
    // The water value of rain water
    private static final int WATER_VALUE = 12;
    // The min grow rate of the grass before it can be eaten
    private static final int MIN_GROWTH = 2;

    /**
     * Create an unit of grass at a location in field.
     *
     * @param randomGrowth Weather of not the current growth level of the grass
     * should be randomised
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomGrowth, Field field, Location location)
    {
        super(randomGrowth, field, location, MAX_GROWTH);
    }

    /**
     * The grass can grow and die. It can only by death because of dehydration
     * 
     * @param newPlants A list to return newly grown grass
     * @param weather Whether the weather is currently rainning
     */
    public void act(List<Plant> newPlants, WeatherTypes weather)
    {
        incrementGrowth(MAX_GROWTH);
        incrementDehydration();
        if(isAlive()) {
            newGrow(newPlants);
            setWaterLevel(WATER_VALUE, weather);
        }
    }

    /**
     * Check whether or not the plant is to grow into new location at this step.
     * New plant will be grown into free adjacent locations.
     * 
     * @param newPlants A list to return newly grown plants.
     */
    public void newGrow(List<Plant> newPlants)
    {
        int newGrowths = propagate(PROPAGATE_PROBABILITY, MAX_NEW_PLANT);
        Field field = getField();
        List<Location> free = field.getFreePlantAdjacentLocations(getLocation());
        for(int p = 0; p < newGrowths && free.size() > 0; p++) {
            Location loc = free.remove(0);
            Grass newGrass = new Grass(false, field, loc);
            newPlants.add(newGrass);
        }
    }
    
    /**
     * Reset the growth level of a plant that is when the plant is eaten.
     * @return True if the plant is eaten
     */
    protected boolean resetGrowthLevel()
    {
        return resetGrowth(MIN_GROWTH);
    }
}
