/**
 * An enumeration class represent the creation probabilities of
 * plants in the simulation. The probability is calculated
 * by giving each plant an integer range. An integer random generator
 * is then used to generate a random integer between 0 and the sum of 
 * all the range of different types of plants.
 *
 * @version 22/02/21
 */
public enum PlantCreationProbability
{
    GRASS(40), MUSHROOM(25);

    private int lowerBound;
    private int upperBound;
    private static int currentTotal = 0;
    private static final int TOTAL = 100;

    /**
     * Constructore of PlantCreationProbability, assign an integer range to
     * an plant.
     * 
     * @param creationProbability The chance that a
     * plant will be created in any given grid position.
     */
    private PlantCreationProbability(int creationProbability) {
        lowerBound = getCurrentTotal();
        increaseTotal(creationProbability);
        this.upperBound = getCurrentTotal();
    }

    /**
     * Return the upper bound of a plant.
     * 
     * @return upperBound The upper bound of a plant
     */
    protected int getUpperBound() {
        return upperBound;
    }

    /**
     * Return the lower bound of a plant.
     * 
     * @return lowerBound The lower bound of a plant
     */
    protected int getLowerBound() {
        return lowerBound;
    }

    /**
     * Increase the current total probability of all the plants
     * 
     * @param newCreationProbability The newly added creation probability
     */
    protected void increaseTotal(int newCreationProbability) {
        if (currentTotal <= TOTAL) {
            currentTotal += newCreationProbability;
        }
    }

    /**
     * Return the current total of the creation probability of all the plants.
     * 
     * @return currentTotal The current total probability of all the plants.
     */
    protected int getCurrentTotal() {
        return currentTotal;
    }

    /**
     * Return the total of the creation probability of all the plants.
     */
    protected static int getTotal() {
        return TOTAL;
    }
}
