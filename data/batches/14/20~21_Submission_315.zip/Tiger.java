import java.util.Iterator;
import java.util.List;

/**
 * A simple model of a tiger. Tigers age, gender move, breed, and die.
 *
 * @version 24/02/21
 */
public class Tiger extends Animal
{
    //The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 40;
    //The age to which a tiger can live.
    private static final int MAX_AGE = 131;
    //The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    //The likelihood a tiger would go to sleep
    private static final double SLEEP_PROBABILITY = 0.9;
    //The maximum number of births.
    private static final int MAX_CHILD = 2;
    //Number of steps a tiger can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 30;
    private static final int SHEEP_FOOD_VALUE = 15;
    private static final int WOLF_FOOD_VALUE = 10;
    private static final int MICE_FOOD_VALUE = 5;
    // The maximum food consumption mesured based on food value
    // which in turn is measured based on the number of steps
    // an animal can take
    private static final int MAX_FOOD_CONSUMPTION = 40;

    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, SHEEP_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
    }

    /**
     * This is what the tiger does most of the time: it hunts for
     * deers or sheep. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param newTigers A list to return newly born tiger's.
     * @param timeOfDay The current time of the day (i.e. day or night)
     */
    public void act(List<Animal> newTigers, TimeOfDay timeOfDay)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            if(!sleep(timeOfDay, getSleepTime(), SLEEP_PROBABILITY)) {
                giveBirth(newTigers);
                //Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    //No food found - try to move to a free location.
                    newLocation = getField().freeAnimalAdjacentLocation(getLocation());
                }
                //See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    //Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for wolf, deer and sheep adjacent to the current location.
     * Only the first live wolf, deer or sheep found is eaten.
     * 
     * @return Where the food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        // Only look for food if hungry, the animal just roam around when full
        if(getHunger() / MAX_FOOD_CONSUMPTION * 100 <= 65) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getAnimalAt(where);
                if (animal instanceof Sheep) {
                    Sheep sheep = (Sheep) animal;
                    if(sheep.isAlive()) {
                        sheep.setDead();
                        setHunger(getHunger() + SHEEP_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                } else if (animal instanceof Deer) {
                    Deer deer = (Deer) animal;
                    if(deer.isAlive()) {
                        deer.setDead();
                        setHunger(getHunger() + DEER_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
                else if (animal instanceof Wolf) {
                    Wolf wolf = (Wolf) animal;
                    if(wolf.isAlive()) {
                        wolf.setDead();
                        setHunger(getHunger() + WOLF_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
                else if (animal instanceof Mice) {
                    Mice mice = (Mice) animal;
                    if(mice.isAlive()) {
                        mice.setDead();
                        setHunger(getHunger() + MICE_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newTigers A list to return newly born tigers.
     */
    public void giveBirth(List<Animal> newTigers)
    {
        //New tigers are born into adjacent locations.
        Field field = getField();
        //Get a list of free adjacent locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            if (animal instanceof Tiger) {
                Tiger tiger = (Tiger) animal;
                //When male and female meet breeding
                if (tiger.isAlive() && this.getGender() != tiger.getGender()) {
                    int births = breed(BREEDING_PROBABILITY, MAX_CHILD, BREEDING_AGE);
                    //newly born tigers will be put into free adjacent locations
                    List<Location> free = field.getFreeAnimalAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Tiger young = new Tiger(false, field, loc);
                        newTigers.add(young);
                    }
                }
            }
        }
    }
}