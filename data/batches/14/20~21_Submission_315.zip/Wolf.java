import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a wolf. Wolfs age, gender move, breed, and die.
 *
 * @version 24/02/21
 */
public class Wolf extends Animal
{
    //The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 30;
    //The age to which a wolf can live.
    private static final int MAX_AGE = 123;
    //The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    //The likelihood a wolf would go to sleep
    private static final double SLEEP_PROBABILITY = 0.9;
    //The maximum number of births.
    private static final int MAX_CHILD = 2;
    //Number of steps a wolf can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 20;
    private static final int SHEEP_FOOD_VALUE = 15;
    private static final int SNAKE_FOOD_VALUE = 15;
    private static final int MICE_FOOD_VALUE = 5;
    // The maximum food consumption mesured based on food value
    // which in turn is measured based on the number of steps
    // an animal can take
    private static final int MAX_FOOD_CONSUMPTION = 20;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, SHEEP_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
    }

    /**
     * This is what the wolf does most of the time: it hunts for
     * deers or sheeps. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param newWolfs A list to return newly born wolf's.
     * @param timeOfDay The current time of the day (i.e. day or night)
     */
    public void act(List<Animal> newWolfs, TimeOfDay timeOfDay)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            if(!sleep(timeOfDay, getSleepTime(), SLEEP_PROBABILITY)) {
                giveBirth(newWolfs);
                //Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    //No food found - try to move to a free location.
                    newLocation = getField().freeAnimalAdjacentLocation(getLocation());
                }
                //See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    //Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for deer or sheep adjacent to the current location.
     * Only the first live deer or sheep is eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        // Only look for food if hungry, the animal just roam around when full
        if(getHunger() / MAX_FOOD_CONSUMPTION * 100 <= 70) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getAnimalAt(where);
                if (animal instanceof Sheep) {
                    Sheep sheep = (Sheep) animal;
                    if(sheep.isAlive()) {
                        sheep.setDead();
                        setHunger(getHunger() + SHEEP_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
                else if(animal instanceof Deer) {
                    Deer deer = (Deer) animal;
                    if(deer.isAlive()) {
                        deer.setDead();
                        setHunger(getHunger() + DEER_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
                else if (animal instanceof Mice) {
                    Mice mice = (Mice) animal;
                    if(mice.isAlive()) {
                        mice.setDead();
                        setHunger(getHunger() + MICE_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
                else if (animal instanceof Mice) {
                    Snake snake = (Snake) animal;
                    if(snake.isAlive()) {
                        snake.setDead();
                        setHunger(getHunger() + SNAKE_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newWolfs A list to return newly born wolfs.
     */
    public void giveBirth(List<Animal> newWolfs)
    {
        //New wolfs are born into adjacent locations.
        Field field = getField();
        //Get a list of free adjacent locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            if (animal instanceof Wolf) {
                Wolf wolf = (Wolf) animal;
                //When male and female meet breeding
                if (wolf.isAlive() && this.getGender() != wolf.getGender()) {
                    int births = breed(BREEDING_PROBABILITY, MAX_CHILD, BREEDING_AGE);
                    //newly born wolfs will be put into free adjacent locations
                    List<Location> free = field.getFreeAnimalAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Wolf young = new Wolf(false, field, loc);
                        newWolfs.add(young);
                    }
                }
            }
        }
    }
}
