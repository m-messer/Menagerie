import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of all plants. All plant can grow and die
 * if it is not fed enough. All plants are fed by water.
 *
 * @version 22/02/21
 */
public abstract class Plant {
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // The growth level of a plant
    private int growthLevel;
    // The water level of the plant
    private int waterLevel;

    /**
     * Create a new plant at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomGrowth, Field field, Location location, int maxGrowth)
    {
        if(randomGrowth) {
            growthLevel = rand.nextInt(maxGrowth);
        } else {
            growthLevel = 10;
        }
        alive = true;
        this.field = field;
        setLocation(location);
        waterLevel = 168;
    }

    /**
     * Return the plant's location.
     * 
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * 
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clearPlant(location);
        }
        location = newLocation;
        field.placePlant(this, newLocation);
    }

    /**
     * Return the plant's field.
     * 
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the growth level of a plant.
     * 
     * @return The growth level of a plant.
     */
    protected int getGrowthLevel()
    {
        return growthLevel;
    }

    /**
     * Reset the growth level of a plant, that is when the plant is eaten.
     * @param minGrowth The minimum growth level a plant must reach before
     * it can be eaten
     * @return True if the plant is eaten
     */
    protected boolean resetGrowth(int minGrowth)
    {
        // The plant can only be eaten when it reach its minimum growth
        if(growthLevel >= minGrowth) {
            this.growthLevel = 0;
            return true;
        }
        return false;
    }

    /**
     * Return true if the plant is alive.
     * 
     * @return Whether the plant is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Make this plant expand that is to grow into new location.
     */
    abstract public void act(List<Plant> newPlants, WeatherTypes weather);
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clearPlant(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Make this plant more dehyderated. This could result in the plant's death.
     */
    protected void incrementDehydration()
    {
        if(waterLevel > 0) {
            waterLevel--;
        } else {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of new plants,
     * if the plant can propagate.
     * 
     * @return The number of newPlants (may be zero).
     */
    protected int propagate(double propagateProbability, int maxNewPlant)
    {
        int newGrowths = 0;
        if(rand.nextDouble() <= propagateProbability) {
            newGrowths = rand.nextInt(maxNewPlant) + 1;
        }
        return newGrowths;
    }
    
    /**
     * Increase the growth level. Once the maximum growth level is reached,
     * the plant cannot grow any further.
     * 
     * @param maxGrowth The maximum growth level a plant can have.
     */
    protected void incrementGrowth(int maxGrowth)
    {
        if(growthLevel < maxGrowth) {
            growthLevel++;
        } else {
            growthLevel = maxGrowth;
        }
    }
    
    /**
     * set the water level of the plant.
     */
    protected void setWaterLevel(int waterLevel, WeatherTypes weather)
    {
        if(weather == WeatherTypes.RAIN) {
            this.waterLevel = waterLevel;
        }
    }
}
