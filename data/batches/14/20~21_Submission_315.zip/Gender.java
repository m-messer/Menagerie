/**
 * An enumeration class represent the animal gender.
 *
 * @version 22/02/21
 */
public enum Gender {
    Male, Female
}
