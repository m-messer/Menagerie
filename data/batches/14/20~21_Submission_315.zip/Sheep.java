import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a sheep. Sheeps age, gender move, breed, and die.
 *
 * @version 24/02/21
 */
public class Sheep extends Animal
{
    // The age at which a sheep can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a sheep can live.
    private static final int MAX_AGE = 105;
    // The likelihood of a sheep breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_CHILD = 4;
    // The likelihood of a sheep sleeping
    protected static final double SLEEP_PROBABILITY = 0.2;
    // number of steps a sheep can go before it has to eat again.
    protected static final int GRASS_FOOD_VALUE = 6;
    protected static final int MUSHROOM_FOOD_VALUE = 4;
    // The maximum food consumption mesured based on food value
    // which in turn is measured based on the number of steps
    // an animal can take
    private static final int MAX_FOOD_CONSUMPTION = 8;

    /**
     * Create a new sheep. A sheep may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sheep(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, MUSHROOM_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
        // This reflect the sleeping habbit of a sheep as deer only take
        // naps at irregular time throughout the day
        setSleepTime(TimeOfDay.DAY, TimeOfDay.NIGHT);
    }

    /**
     * This is what the sheep does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * 
     * @param newSheeps A list to return newly born sheeps.
     * @param timeOfDay The current time of the day (i.e. day or night)
     */
    public void act(List<Animal> newSheeps, TimeOfDay timeOfDay)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            if(!sleep(timeOfDay, getSleepTime(), SLEEP_PROBABILITY)) {
                giveBirth(newSheeps);
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAnimalAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for grass and mushroom adjacent to the current location.
     * Only the first plant found is eaten.
     * 
     * @return Where the food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        // Only look for food if hungry, the animal just roam around when full
        if(getHunger() / MAX_FOOD_CONSUMPTION * 100 <= 70) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object plant = field.getPlantAt(where);
                if(plant instanceof Grass) {
                    Grass grass = (Grass) plant;
                    if(grass.isAlive() && grass.resetGrowthLevel()) {
                        setHunger(getHunger() + GRASS_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                } else if(plant instanceof Mushroom) {
                    Mushroom mushroom = (Mushroom) plant;
                    if(mushroom.isAlive() && mushroom.resetGrowthLevel()) {
                        setHunger(getHunger() + MUSHROOM_FOOD_VALUE, MAX_FOOD_CONSUMPTION);
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this sheep is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newSheeps A list to return newly born sheeps.
     */
    public void giveBirth(List<Animal> newSheeps)
    {
        // New sheeps are born into adjacent locations.
        Field field = getField();
        // Get a list of free adjacent locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            if (animal instanceof Sheep) {
                Sheep sheep = (Sheep) animal;
                // When male and female meet breeding
                if (sheep.isAlive() && this.getGender() != sheep.getGender()) {
                    int births = breed(BREEDING_PROBABILITY, MAX_CHILD, BREEDING_AGE);
                    // newly born sheeps will be put into free adjacent locations
                    List<Location> free = field.getFreeAnimalAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Sheep young = new Sheep(false, field, loc);
                        newSheeps.add(young);
                    }
                }
            }
        }
    }
}
