
/**
 * Time of the day in the simulation.
 * Can either be day or night. This only simulate
 * the light environment of the simulation. Day means
 * the sun is still visible and night mean the sky is 
 * fully dark.
 *
 * @version 24/02/21
 */
public enum TimeOfDay
{
    DAY("Day"), NIGHT("Night");
    
    private String status;
    
    /**
     * Set the the status for each time of the day.
     */
    TimeOfDay(String status)
    {
        this.status = status;
    }
    
    /**
     * @return The status of the current time of the day
     */
    protected String getStatus()
    {
        return status;
    }
}
