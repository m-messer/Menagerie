/**
 * An enumeration class represent the creation probabilities of
 * animals in the simulation. The probability is calculated
 * by giving each animal an integer range. An integer random generator
 * is then used to generate a random integer between 0 and the sum of 
 * all the range of diefferent animal species.
 *
 * @version 22/02/21
 */
public enum AnimalCreationProbability
{
    TIGER(2), WOLF(3), SNAKE(6), DEER(10), SHEEP(10), MICE(10);

    private int lowerBound;
    private int upperBound;
    private static int currentTotal = 0;
    private static final int TOTAL = 100;

    /**
     * Constructore of AnimalCreationProbability, assign an integer range to
     * an animal.
     * 
     * @param creationProbability The chance that an animal
     * will be created in any given grid position.
     */
    private AnimalCreationProbability(int creationProbability) {
        lowerBound = getCurrentTotal();
        increaseTotal(creationProbability);
        this.upperBound = getCurrentTotal();
    }

    /**
     * Return the upper bound of an animal.
     * 
     * @return upperBound The upper bound of an animal
     */
    protected int getUpperBound() {
        return upperBound;
    }

    /**
     * Return the lower bound of an animal.
     * 
     * @return lowerBound The lower bound of an animal
     */
    protected int getLowerBound() {
        return lowerBound;
    }

    /**
     * Increase the current total probability of all the
     * animals and plants
     * 
     * @param newCreationProbability The newly added creation probability
     */
    protected void increaseTotal(int newCreationProbability) {
        if (currentTotal <= TOTAL) {
            currentTotal += newCreationProbability;
        }
    }

    /**
     * Return the current total of the creation probability of all the animal
     * and plants.
     * 
     * @return currentTotal The current total probability of all the animals
     * and plants.
     */
    protected int getCurrentTotal() {
        return currentTotal;
    }

    /**
     * Return the total of the creation probability of all the animal
     * and plants.
     */
    protected static int getTotal() {
        return TOTAL;
    }
}
