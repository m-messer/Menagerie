import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing
 * Predators: Wolf and Lynx
 * Preys: Deer, Elk, Moose, Beaver and Rabbit
 * Plants: Tree and Grass
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    private static final double WOLF_CREATION_PROBABILITY = 0.02;
    private static final double LYNX_CREATION_PROBABILITY = 0.01;
    private static final double DEER_CREATION_PROBABILITY = 0.07;
    private static final double ELK_CREATION_PROBABILITY = 0.07;
    private static final double MOOSE_CREATION_PROBABILITY = 0.07;
    private static final double BEAVER_CREATION_PROBABILITY = 0.07;
    private static final double RABBIT_CREATION_PROBABILITY = 0.10;
    private static final double TREE_CREATION_PROBABILITY = 0.03;  
    private static final double GRASS_CREATION_PROBABILITY = 0.66;    

    private static final double SUN_PROBABILITY = 0.42;// 42%
    private static final double RAIN_PROBABILITY = 0.33;// roughly 20% chance
    private static final double OVERCAST_PROBABILITY = 0.45;// roughly 18% chance
    private static final double SNOW_PROBABILITY = 0.40; // roughly 9% chance as they are not independent events
    // List of livingThings in the field.
    private List<LivingThings> livingThings;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    private int time;
    private String dayNight;
    private boolean isDay;
    
    private String weather;
    private int weatherCounter;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * Set colours of each category of living things.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        livingThings = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Lynx.class, Color.MAGENTA);
        
        //view.setColor(Prey.class, Color.BLUE);
        view.setColor(Deer.class, new Color(102,178,255));
        view.setColor(Elk.class, new Color(51,0,102));
        view.setColor(Moose.class, new Color(0,0,255));
        view.setColor(Beaver.class, new Color(204,102,0));
        view.setColor(Rabbit.class, new Color(255,255,153));
        
        view.setColor(Tree.class, new Color(0,102,0));
        view.setColor(Grass.class, Color.GREEN);
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1200);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     * Set the change in Day/Night cycle and weather cycle.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
             //delay(6000);   // uncomment this to run more slowly
             System.out.println(field.getWeather());
             if(dayNight == "Day" && time < 11){
                 
                 time++;
                 field.setDayNight(true);
                 System.out.println("its Day");
             }
             else if(dayNight == "Day" && time == 11){
                 dayNight = "Night";
                 
                 time = 0;
                 field.setDayNight(false);
                 System.out.println("Turning to Night");
             }
             else if(dayNight == "Night" && time < 11){
                 
                 time++;
                 field.setDayNight(false);
                 System.out.println("its night");
             }
             else if(dayNight == "Night" && time == 11){
                 
                 dayNight = "Day";
                 time = 0;
                 field.setDayNight(true);
                 System.out.println("Turning to Day");
             }
             Random rand = new Random();
             if(rand.nextInt(100) < 10)
             {
                 
                 if(rand.nextDouble() < SUN_PROBABILITY)
                 {
                     field.setWeather("Sun");
                     System.out.println("The weather is now sunny");
                 }
                 else if(rand.nextDouble() < RAIN_PROBABILITY)
                 {
                     field.setWeather("Rain");
                     System.out.println("The weather is now raining");
                 }
                 else if(rand.nextDouble() < OVERCAST_PROBABILITY)
                 {
                     field.setWeather("Overcast");
                     System.out.println("The weather is now overcast");
                 }
                 else if(rand.nextDouble() < SNOW_PROBABILITY)
                 {
                     field.setWeather("Snow");
                     System.out.println("The weather is now snowing");
                 }
             }
        }
        
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each living thing.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn livingThings.
        List<LivingThings> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<LivingThings> it = livingThings.iterator(); it.hasNext(); ) {
            LivingThings livingThings = it.next();
            livingThings.act(newAnimals);
            if(! livingThings.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        livingThings.addAll(newAnimals);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
    	field.setWeather("Sun");
        weatherCounter = 0;
        time = 0;
        dayNight = "Day";
        step = 0;
        livingThings.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with livingThings based on probability
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    livingThings.add(wolf);
                }
                else if(rand.nextDouble() <= LYNX_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Lynx lynx = new Lynx(true, field, location);
                    livingThings.add(lynx);
                }
                else if(rand.nextDouble() <= TREE_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Tree tree = new Tree(true, field, location);
                    livingThings.add(tree);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    livingThings.add(grass);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    livingThings.add(deer);
                }
                else if(rand.nextDouble() <= ELK_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Elk elk = new Elk(true, field, location);
                    livingThings.add(elk);
                }
                else if(rand.nextDouble() <= MOOSE_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Moose moose = new Moose(true, field, location);
                    livingThings.add(moose);
                }
                else if(rand.nextDouble() <= BEAVER_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Beaver beaver = new Beaver(true, field, location);
                    livingThings.add(beaver);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    livingThings.add(rabbit);
                }
                
                
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try 
        {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) 
        {
            // wake up
        }
    }
}
