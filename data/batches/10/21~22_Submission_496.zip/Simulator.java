package src;

import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2022.02.28
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;


    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Our population generator.
    private PopulationGenerator populationGenerator;
    // A time tracker (to determine time of day and season).
    private TimeTracker timeTracker;
    // A weather simulator (to determine whether it is raining).
    private WeatherSimulator weatherSimulator;


    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        populationGenerator = new PopulationGenerator(field, animals, plants);
        timeTracker = new TimeTracker();
        weatherSimulator = new WeatherSimulator();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        // Set colors for each species and gender.
        view.setColor(Rabbit.class + "male", Color.ORANGE);
        view.setColor(Rabbit.class + "female", Color.YELLOW);
        view.setColor(Fox.class + "male", Color.BLUE);
        view.setColor(Fox.class + "female", Color.CYAN);
        view.setColor(Bear.class + "male", Color.PINK);
        view.setColor(Bear.class + "female", Color.MAGENTA);
        view.setColor(Eagle.class + "male", new Color(34, 66, 2)); // dark green
        view.setColor(Eagle.class + "female", new Color(39, 115, 31)); // medium green
        view.setColor(Rat.class + "male", new Color(76, 0, 153)); // dark purple
        view.setColor(Rat.class + "female", new Color(151, 77, 193)); // light purple

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(50);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep() {
        step++;

        // boolean variables to determine time of day, season and raining status
        boolean isDay = timeTracker.getTime(step).equals("day");
        boolean isRaining = weatherSimulator.isRaining(step, timeTracker);
        String season = timeTracker.getSeason(step);


        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Provide space for new plants.
        List<Plant> newPlants = new ArrayList<>();

        // Let all animals act.
        for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();

            animal.act(newAnimals, isDay, isRaining);


            if (!animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals to the main list.
        animals.addAll(newAnimals);

        // Let plants grow.
        for (Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant1 = it.next();
            plant1.act(newPlants, isRaining);
            if (!plant1.isAlive()) {
                it.remove();
            }
        }

        // Add the new plants to the main list.
        plants.addAll(newPlants);


        view.showStatus(step, field, isDay, isRaining, season);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        String season = timeTracker.getSeason(step);
        animals.clear();
        plants.clear();
        populationGenerator.populate();
        populationGenerator.populatePlants();

        // Show the starting state in the view.
        view.showStatus(step, field, true, false, season);
    }


    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Main function to run the simulatio
     *
     * @param args
     */
    public static void main(String[] args) {
        Simulator sim = new Simulator(150, 225);
        sim.runLongSimulation();
    }
}
