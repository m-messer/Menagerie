package src;

import java.util.*;
import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.02.28
 */
public abstract class Animal {
    private static final double CHANCE_TO_SPREAD_INFECTION = 0.2;
    private static final int MAX_TIME_OF_INFECTION = 20; // steps

    private static final int PLANT_FOOD_VALUE = 10;


    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    private boolean gender; //0 = male, 1 = female

    private int infected = 0;

    private int age;

    private int foodLevel;

    private int MAX_AGE;

    private int BREEDING_AGE;

    private Map<Object, Integer> preferredDiet;

    private double CHANCE_TO_CURE_INFECTION = 0.7;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
        gender = rand.nextDouble() <= 0.5;
        infected = rand.nextDouble() <= CHANCE_TO_SPREAD_INFECTION ? rand.nextInt(MAX_TIME_OF_INFECTION) : 0;
        preferredDiet = new HashMap<>();
    }

    public Animal() {

    }

    /**
     * Looks for an animal of the same species,
     * but opposite gender in the adjacent locations to the animal.
     *
     * @return Whether a suitable partner has been found.
     */
    protected boolean foundPartner() {
        for (Location nearbyAnimalLocation : field.getFilledAdjacentLocations(location)) {
            Animal selectedAnimal = (Animal) field.getObjectAt(nearbyAnimalLocation);
            if (selectedAnimal.getClass().equals(this.getClass()))
                if (this.getGender() != selectedAnimal.getGender())
                    return true;
        }
        return false;
    }

    /**
     * Return the animal's gender.
     *
     * @return The animal's gender.
     */
    protected boolean getGender() {
        return gender;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do according to time of day/current weather condition.
     *
     * @param newAnimals A list to receive newly born animals.
     * @param isDay      Whether it is day or night.
     * @param isRaining  Whether it is raining or not.
     */
    abstract public void act(List<Animal> newAnimals, boolean isDay, boolean isRaining);

    /**
     * Check whether the animal is alive or not.
     *
     * @return true if the animal is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Make this animal older.
     * If it has reached its max age, kill the animal.
     */
    protected void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Return the max age of the animal.
     *
     * @return The max age of the animal.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Set the max age of the animal to a certain value.
     *
     * @param age The value to set the max age to.
     */
    protected void setMaxAge(int age) {
        MAX_AGE = age;
    }

    /**
     * Return the current age of the animal.
     *
     * @return The animal's age.
     */
    protected int getAge() {
        return age;
    }

    /**
     * Set the animal's age to a certain value.
     *
     * @param val The value to set the animal's age to.
     */
    protected void setAge(int val) {
        age = val;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }


    /**
     * Return the animal's location.
     *
     * @return The animal's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     *
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     *
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Looks for animals adjacent to the infected animal and
     * spreads the infection to those animals based on
     * how infectious the disease is (determined by CHANCE_TO_SPREAD_INFECTION in giveVirus() method).
     * This disease ages the animal three times faster.
     */
    protected void spreadInfection() {
        if (infected > 0) {
            // make the animal age 3 times faster
            incrementAge();
            incrementAge();
            incrementAge();

            if (isAlive()) {
                List<Location> nearbyAnimalsLocations = field.getFilledAdjacentLocations(location);
                List<Animal> nearbyAnimals = new ArrayList<>();
                // Construct the nearbyAnimals list by extracting the animals at the locations in the locations list.
                nearbyAnimalsLocations.forEach(loc -> nearbyAnimals.add((Animal) field.getObjectAt(loc)));

                nearbyAnimals.forEach(Animal::giveVirus);

                // Lower time of infection.
                infected--;
            }
        }
    }

    /**
     * Extension of the method above.
     * Determines whether the disease spreads and if true,
     * allocates a random amount of steps until the disease is cured.
     */
    protected void giveVirus() {
        if (rand.nextDouble() <= CHANCE_TO_SPREAD_INFECTION)
            infected = rand.nextInt(MAX_TIME_OF_INFECTION);
    }

    /**
     * Determine whether the animal is infected.
     *
     * @return true if the animal is infected.
     */
    public boolean isInfected() {
        return infected > 0;
    }

    /**
     * Animal looks for food in the adjacent locations based on their diet,
     * and increases its food level when the desired aliment is found (aliment can be an animal or a plant)
     *
     * @param diet The animal's preferred diet.
     * @return The location of the food if found, null if not.
     */
    protected Location findFood(Map<Object, Integer> diet) {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            Object plant = field.getPlantAt(where);

            for (var dietAliment : diet.keySet()) {
                if (animal != null && animal.getClass().equals(dietAliment.getClass())) {
                    Animal animal1 = (Animal) animal;
                    if (animal1.isAlive()) {
                        animal1.setDead();
                        foodLevel += diet.get(dietAliment);
                        return where;
                    }
                } else if (plant != null && plant.getClass().equals(dietAliment.getClass())) {
                    Plant plant1 = (Plant) plant;
                    if (plant1.isAlive()) {
                        plant1.setDead();
                        foodLevel += PLANT_FOOD_VALUE;
                        return where;
                    }
                }
            }


        }
        return null;
    }

    /**
     * Randomly cure the infection with a set chance.
     */
    public void clearInfection() {
        if (rand.nextDouble() <= CHANCE_TO_CURE_INFECTION)
            infected = 0;
    }

    /**
     * Make this animal hungrier.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Set this animal's food level.
     *
     * @param value The value to set the food level to.
     */
    protected void setFoodLevel(int value) {
        foodLevel = value;
    }

    /**
     * Set this animal's required breeding age.
     *
     * @param value The value to set the breeding age to.
     */
    protected void setBreedingAge(int value) {
        BREEDING_AGE = value;
    }

    /**
     * Sets the diet of the animal in terms of what animals/plants it can eat.
     * Add to this animal's diet a certain aliment, along with its food value.
     * @param aliment The aliment to be added.
     * @param foodValue The aliment's food value.
     */
    protected void addToPreferredDiet(Object aliment, int foodValue) {

        preferredDiet.put(aliment, foodValue);
    }

    /**
     * Return the animal's diet.
     * @return The animal's diet.
     */
    protected Map<Object, Integer> getPreferredDiet() {
        return preferredDiet;
    }


    /**
     * An animal can breed if it has reached the breeding age.
     *
     * @return true if the animal can breed
     */
    protected boolean canBreed() {
        return getAge() >= BREEDING_AGE;
    }

}
