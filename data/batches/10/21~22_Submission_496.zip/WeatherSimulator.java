package src;

import java.util.Random;

/**
 * A simple weather tracker.
 * Currently only tracks rain. Rain can occur randomly with different probabilities according to the current season.
 *
 * @version 2022.02.28 (2)
 */

public class WeatherSimulator {
    // chances of rain in different seasons
    private static final double SNOW_CHANCE_WINTER = 0.07; // "rain" is considered snow during winter
    private static final double RAIN_CHANCE_SPRING = 0.04;
    private static final double RAIN_CHANCE_SUMMER = 0.02;
    private static final double RAIN_CHANCE_AUTUMN = 0.06;

    // duration of rain in number of steps
    private static final int DURATION_OF_RAIN = 10;

    private static final Random rand = Randomizer.getRandom();

    // 0 = NOT RAINING
    // ANYTHING GREATER THAN 0 = RAINING (for that number of steps)
    private int raining;

    /**
     * Construct a weather simulator and set raining status to not raining.
     */
    public WeatherSimulator() {
        raining = 0;
    }

    /**
     * Method to determine whether it is raining at the moment.
     * @param step The current step.
     * @param timeTracker A TimeTracker object to determine the season.
     * @return (boolean) Whether it is currently raining.
     */
    public boolean isRaining(int step, TimeTracker timeTracker) {
        // reduce raining steps
        raining--;

        if (raining > 0)
            return true;

        // this is the raining cooldown, once it rained it cannot start raining again for 20 steps.
        if (raining > -20)
            return false;

        String season = timeTracker.getSeason(step);
        switch (season) {
            case "winter":
                if (rand.nextDouble() <= SNOW_CHANCE_WINTER) {
                    // make it rain for 10 steps
                    raining = DURATION_OF_RAIN;
                    return true;
                }
            case "spring":
                if (rand.nextDouble() <= RAIN_CHANCE_SPRING) {
                    raining = DURATION_OF_RAIN;
                    return true;
                }
            case "summer":
                if (rand.nextDouble() <= RAIN_CHANCE_SUMMER) {
                    raining = DURATION_OF_RAIN;
                    return true;
                }
            case "autumn":
                if (rand.nextDouble() <= RAIN_CHANCE_AUTUMN) {
                    raining = DURATION_OF_RAIN;
                    return true;
                }
        }

        return false;
    }
}
