package src;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * A simple population generator for the main simulator class.
 * Populates the grid and adds the animals to the animals list.
 *
 * @version 2022.02.28 (2)
 */

public class PopulationGenerator {
    private List<Class> possibleAnimals = Arrays.asList(Fox.class, Rabbit.class);
    private Field field;
    private List<Animal> animals;
    private List<Plant> plants;

    // creation probabilities of all species
    private static final double RAT_CREATION_PROBABILITY = 0.25;
    private static final double RABBIT_CREATION_PROBABILITY = 0.25;
    private static final double FOX_CREATION_PROBABILITY = 0.08;
    private static final double BEAR_CREATION_PROBABILITY = 0.04;
    private static final double EAGLE_CREATION_PROBABILITY = 0.03;
    private static final double PLANT_CREATION_PROBABILITY = 0.95;

    /**
     * Construct a population generator and call the populate() method.
     *
     * @param field   The field to place the animals.
     * @param animals The list of animals to add to.
     * @param plants
     */
    public PopulationGenerator(Field field, List<Animal> animals, List<Plant> plants) {
        this.field = field;
        this.animals = animals;
        this.plants = plants;

        populate();
        populatePlants();
    }

    /**
     * Randomly populate the field with animals.
     */
    public void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= EAGLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(true, field, location);
                    animals.add(eagle);
                } else if (rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, field, location);
                    animals.add(bear);

                } else if (rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    animals.add(fox);
                } else if (rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                } else if (rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(true, field, location);
                    animals.add(rat);
                }
            }
        }
    }

    /**
     * Randomly populate the field with plants.
     */
    public void populatePlants() {
        Random rand = Randomizer.getRandom();
        field.clearPlants();

        for (int row = 0; row < field.getDepth(); row++)
            for (int col = 0; col < field.getWidth(); col++)
                if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    plants.add(plant);
                }
    }

    // TODO: attempt to generalise populate method
    /* public void popul() {
        for (Class currentClass : possibleAnimals) {
            Location location = new Location(row, col);
            //TODO: Animal instance = (Animal) currentClass.getDeclaredConstructor(boolean.class, Field.class, Location.class).newInstance(true, field, location);

            if (rand.nextDouble() <= instance.getCreationProbability()) {
                animals.add(instance);
            }
        }
    }*/

}



