package src;

import java.util.List;
import java.util.Random;

public class Rat extends Animal {
    // Characteristics shared by all rats (class variables).

    // The age at which a rat can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a rat can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a rat breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a plant.
    private static final int PLANT_FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Create a rat. A rat can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the rat will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Rat(boolean randomAge, Field field, Location location) {
        super(field, location);
        // set the rat's max age and breeding age
        setMaxAge(MAX_AGE);
        setBreedingAge(BREEDING_AGE);
        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        } else {
            setAge(0);
        }

        // set the food level to half the rat's max age.
        setFoodLevel(getMaxAge() / 2);

        // add plants to the rat's diet
        addToPreferredDiet(new Plant(), PLANT_FOOD_VALUE);
    }

    public Rat() {}

    /**
     * This is what the rat does most of the time: it runs around
     * and eats plants. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newRats A list to return newly born rats.
     * @param isDay      Whether it is currently day or night.
     * @param isRaining  Whether it is raining.
     */
    public void act(List<Animal> newRats, boolean isDay, boolean isRaining) {
        incrementAge();
        incrementHunger();

        if (isAlive())
            spreadInfection();


        if (!isDay) // rats act only during the night
            if (isAlive()) {
                giveBirth(newRats);

                // Try to move into a free location.
                Location newLocation = findFood(getPreferredDiet());

                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }

                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }

        // randomly cure infection to prevent population dying too early
        clearInfection();
    }

    /**
     * Check whether this rat is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newRats A list to return newly born rats.
     */
    private void giveBirth(List<Animal> newRats) {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = 0;
        if (foundPartner()) {
            births = breed();
        }
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rat young = new Rat(false, field, loc);
            newRats.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

}

