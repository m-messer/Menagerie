package src;

import java.util.List;
import java.util.Random;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2022.02.28
 */
public class Fox extends Animal {
    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 11;
    // The age to which a fox can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.16;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit and rat. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 12;
    private static final int RAT_FOOD_VALUE = 8;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Create a fox. A fox can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location) {
        super(field, location);
        // set the fox's max age and breeding age
        setMaxAge(MAX_AGE);
        setBreedingAge(BREEDING_AGE);
        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        } else {
            setAge(0);
        }

        // set the food level of the fox to half its max age
        setFoodLevel(getMaxAge() / 2);

        // create the fox's diet
        addToPreferredDiet(new Rabbit(), RABBIT_FOOD_VALUE);
        addToPreferredDiet(new Rat(), RAT_FOOD_VALUE);
    }

    public Fox() {

    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newFoxes  A list to return newly born foxes.
     * @param isDay     Whether it is currently day or night.
     * @param isRaining Whether it is raining.
     */
    public void act(List<Animal> newFoxes, boolean isDay, boolean isRaining) {
        incrementAge();
        incrementHunger();

        if (isAlive())
            spreadInfection();

        if (!isDay) // foxes can only act during the night, they sleep during the day.
            if (isAlive()) {
                giveBirth(newFoxes);
                // Move towards a source of food if found.
                Location newLocation = findFood(getPreferredDiet());
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }

        // randomly cure infection to prevent population dying too early
        clearInfection();
    }


    /**
     * Check whether this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Animal> newFoxes) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        int births = 0;
        if (foundPartner()) {
            births = breed();
        }

        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fox young = new Fox(false, field, loc);
            newFoxes.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

}
