package src;

import java.util.*;

/**
 * A simple model of a bear.
 * Foxes age, move, eat rabbits, foxes, and rats, and die.
 *
 * @version 2022.02.28
 */
public class Bear extends Animal {
    // Characteristics shared by all bears (class variables).

    // The age at which a bear can start to breed.
    private static final int BREEDING_AGE = 25;
    // The age to which a bear can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a bear breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit, fox, or rat. In effect, this is the
    // number of steps a bear can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 12;
    private static final int FOX_FOOD_VALUE = 30;
    private static final int RAT_FOOD_VALUE = 5;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.02;


    /**
     * Create a bear. A bear can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the bear will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Bear(boolean randomAge, Field field, Location location) {
        super(field, location);
        // set the bear's max age and breeding age.
        setMaxAge(MAX_AGE);
        setBreedingAge(BREEDING_AGE);

        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        } else {
            setAge(0);
        }
        // set initial food level as half the bear's age.
        setFoodLevel(getMaxAge() / 2);

        // create the bear's diet.
        addToPreferredDiet(new Rabbit(), RABBIT_FOOD_VALUE);
        addToPreferredDiet(new Fox(), FOX_FOOD_VALUE);
        addToPreferredDiet(new Rat(), RAT_FOOD_VALUE);
    }


    /**
     * This is what the bear does most of the time: it hunts for
     * rabbits, rats, or foxes. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newBears  A list to return newly born bears.
     * @param isDay     Whether it is currently day or night.
     * @param isRaining Whether it is raining.
     */
    public void act(List<Animal> newBears, boolean isDay, boolean isRaining) {
        incrementAge();
        incrementHunger();
        if (isAlive())
            spreadInfection();

        if (isDay) // the bear acts only during the day.
            if (isAlive()) {
                giveBirth(newBears);
                // Move towards a source of food if found, and it's not raining;
                Location newLocation = isRaining ? null : findFood(getPreferredDiet());

                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }

        // randomly cure infection to prevent population dying too early
        clearInfection();
    }

    /**
     * Check whether this bear is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newBears A list to return newly born bears.
     */
    private void giveBirth(List<Animal> newBears) {
        // New bears are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        int births = 0;
        if (foundPartner()) {
            births = breed();
        }

        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bear young = new Bear(false, field, loc);
            newBears.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
