package src;

/**
 * A simple time tracker.
 * Able to determine the time of day, as well as the current season.
 *
 * @version 2022.02.28 (2)
 */

public class TimeTracker {
    // length of one day in number of steps (equal to length of night)
    private static final int LENGTH_OF_DAY = 10;
    // length of one season in number of steps
    private static final int LENGTH_OF_SEASON = 100;

    // no constructor needed

    /**
     * Determines whether it is day or night according to the current step.
     * @param step The current step.
     * @return A string: "day" or "night".
     */
    public String getTime(int step) {
        int indexOfCurrentDay = step / LENGTH_OF_DAY;

        if (indexOfCurrentDay % 2 == 0)
            return "day";
        else return "night";
    }

    /**
     * Determine the current season according to the step.
     * @param step The current step.
     * @return A string containing the current season. (winter, spring, summer or autumn)
     */
    public String getSeason(int step) {
        int indexOfCurrentSeason = step / LENGTH_OF_SEASON;
        switch (indexOfCurrentSeason % 4) {
            case 0:
                return "winter";
            case 1:
                return "spring";
            case 2:
                return "summer";
            case 3:
                return "autumn";
        }
        return null;
    }
}
