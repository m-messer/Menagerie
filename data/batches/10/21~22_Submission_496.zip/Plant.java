package src;

import java.util.List;
import java.util.Random;

/**
 * A class representing the characteristics of a plant.
 *
 * @version 2022.02.28
 */
public class Plant {

    // The age of the plant.
    private int age = 0;
    // Whether this plant is alive.
    private boolean alive = false;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;

    /**
     * Constructor for objects of class plant.
     */
    public Plant(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    public Plant() {
    }

    /**
     * Check whether the plant is alive or not.
     *
     * @return true if the plant is still alive.
     */
    public boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead() {
        alive = false;
        if (location != null) {
            field.clearPlant(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plant's location.
     *
     * @return The plant's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     *
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clearPlant(location);
        }
        location = newLocation;
        field.placePlant(this, newLocation);
    }

    /**
     * Make this plant act - that is:
     * determine whether the plant is old enough to reproduce/spread to neighbouring locations.
     * This behaviour is based on the weather, therefore the required age to spread is lower when it is raining.
     * Age is reset every time the plant grows a new plant.
     *
     * @param newPlants A list to receive new plants.
     * @param isRaining Current weather status.
     */
    public void act(List<Plant> newPlants, boolean isRaining) {
        // Reproduce more when it's raining. (every 2 steps)
        if (isRaining) {
            age++;
            if (age > 2) {
                age = 0;
                grow(newPlants);
            }
            // Reproduce every 30 steps when it's not raining.
        } else {
            age++;
            if (age > 30) {
                age = 0;
                grow(newPlants);
            }
        }
    }

    /**
     * Checks the adjacent locations to the plant and spreads its offspring
     * to the tiles that do not contain a plant.
     *
     * @param newPlants A list to receive new plants.
     */
    public void grow(List<Plant> newPlants) {
        if (getLocation() != null) {
            List<Location> adjacent = field.adjacentLocations(getLocation());
            for (Location loc : adjacent) {
                if (field.getPlantAt(loc) == null) {
                    Plant plant = new Plant(field, loc);
                    newPlants.add(plant);
                }
            }
        }
    }

}
