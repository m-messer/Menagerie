import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;
import java.util.LinkedList;
/**
 * The FieldLayer class represents one layer of a simulation which occurs in a Field
 * It is responsible for holding objects in a 3D grid, with dimensions specified by the Field, and managing how the layer changes at each simulation step
 * 
 * @version 0
 */
public abstract class FieldLayer
{
    private Field field;
    private LayerObject[][][] contents;
    protected List<LayerObject> managedObjects;
    protected Random rand = Randomizer.getRandom();
    private int length, width, height;
    
    /**
     * Create a new FieldLayer
     * @param field The field to which the FieldLayer's dimensions should conform to
     */
    public FieldLayer(Field field)
    {
        this.field = field;
        managedObjects = new ArrayList<>();
        
        length = field.getLength();
        height = field.getHeight();
        width = field.getWidth();
        
        contents = new LayerObject[length][height][width];
    }
    
    /**
     * Set the intial contents of the field
     */
    public abstract void populateRandomly();
    
    /**
     * Make changes to the field to simulate one step of the simulation
     */
    public abstract void simulateOneStep();
    
    /**
     * Determine whether the field is viable (whether it should stop the simulation)
     * By default, the field is always viable
     */
    public boolean isViable() {
        return true;
    }
    
    /**
     * Reset the layer. Clears all contents and repopulates it randomly.
     */
    public void reset() {
        clear();
        populateRandomly();
    }
    
    /**
     * Get the managed objects of the list
     * @return A list of the managed objects of the list
     */
    public List<LayerObject> getManagedObjects() {
        return managedObjects;
    }
    
    /**
     * Get the object which resides at a location in the field
     * @param x The x-coordinate of the location
     * @param y The y-coordinate of the location
     * @param z The z-coordinate of the location
     * @return The layer object at that location, or null if none exists or the location is invalid
     */
    protected LayerObject getObjectAt(int x, int y, int z) {
        return getObjectAt(new Location(x, y, z));
    }
    
    /**
     * Get the object which resides at a location in the field
     * @param location The location to check
     * @return The layer object at that location, or null if none exists or the location is invalid
     */
    protected LayerObject getObjectAt(Location location) {
        if (!(location.isOutsideBounds(length, height, width))) {
            return contents[location.getX()][location.getY()][location.getZ()];
        } else {
            return null;
        }
    }
    
    /**
     * Place a LayerObject at a location within the field. It does nothing if the location is invalid
     * Note: This method does not add the object to this layers's managed objects list
     * @param object The object to place
     * @param x The x-coordinate of the location
     * @param y The y-coordinate of the location
     * @param z The z-coordinate of the location
     */
    protected void place(LayerObject object, int x, int y, int z) {
        place(object, new Location(x, y, z));
    }
    
    /**
     * Place a LayerObject at a location within the field. It does nothing if the location is invalid
     * Note: This method does not add the object to this layers's managed objects list
     * @param object The object to place
     * @param location The location to place the object at
     */
    protected void place(LayerObject object, Location location) {
        if (!(location.isOutsideBounds(length, height, width))) {
            contents[location.getX()][location.getY()][location.getZ()] = object;
        }
    }
    
    /**
     * Clear a location in this layer's contents (sets the value to null)
     * Note: This method does not remove any object which may be at the location from this layers's managed objects list
     * @param location The location to clear
     */
    protected void clear(Location location) {
        if (!(location.isOutsideBounds(length, height, width))) {
            contents[location.getX()][location.getY()][location.getZ()] = null;
        }
    }
    
    /**
     * Clear the field
     */
    public void clear() {
        contents = new LayerObject[length][height][width];
        managedObjects.clear();
    }
    
    /**
     * Generate a random location that is adjacent to the
     * given location, or is the same location.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    protected Location randomAdjacentLocation(Location location, int yChange, int xzChange)
    {
        List<Location> adjacent = adjacentLocations(location, yChange, xzChange);
        return adjacent.get(0);
    }
    
    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    protected List<Location> adjacentLocations(Location location, int yChange, int zxChange)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        int x = location.getX();
        int y = location.getY();
        int z = location.getZ();
        
        for (int xOffset = -zxChange; xOffset <= zxChange; xOffset++) {
            int nextX = x + xOffset;
            for (int yOffset = -yChange; yOffset <=yChange; yOffset++) {
                int nextY = y + yOffset;
                for (int zOffset = -zxChange; zOffset <= zxChange; zOffset++) {
                    int nextZ = z + zOffset;
                    Location loc = new Location(nextX, nextY, nextZ);
                    if (!loc.isOutsideBounds(length, height, width) && !(xOffset == 0 && yOffset == 0 && zOffset == 0)) {
                        locations.add(loc);
                    }
                }
            }
        }
        
        
        // Shuffle the list. Several other methods rely on the list
        // being in a random order.
        Collections.shuffle(locations, rand);
        return locations;
    }
    
    /**
     * Get a list of the objects stored in this layer at the list of locations
     * @param locations The locations to check
     * @return The list of objects
     */
    protected List<LayerObject> objectsInLocations(List<Location> locations) {
        List<LayerObject> objects = new ArrayList<LayerObject>();
        for (Location loc : locations) {
            LayerObject obj = getObjectAt(loc);
            if (obj != null) {
                objects.add(obj);
            }
        }
        return objects;
    }
    
    /**
     * Get the field that this layer resides in
     * @return The field
     */
    public Field getField() {
        return field;
    }
}
