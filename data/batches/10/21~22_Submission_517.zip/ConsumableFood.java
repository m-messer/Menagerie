/**
 * An interface to define food which is consumable, i.e., a change occurs to the object which has implemented ConsumableFood after an animal eats it.
 * 
 * @version 0
 */
public interface ConsumableFood
{
    /**
     * Called when an implementing class is attempted to be eaten
     * @param amount The amount (between 0 and 1) of the animal that is attempted to be eaten
     * @return the amount actually eaten, e.g. 0 if the animal escapes being eaten, or a number < amount if there is not enough 'amount' left.
     */
    public double eat(double amount);
}
