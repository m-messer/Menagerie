import java.util.List;
import java.util.Random;

/**
 * Represents 'Water' as a terrain material
 * 
 * @version 0
 */
public class Water extends Terrain
{
    private Random rand = Randomizer.getRandom();
    
    private boolean isFrozen;
    private boolean isFloodWater;
    
    /**
     * Create a new Water object at a location within a layer
     * @param layer The terrain layer in which the water resides
     * @param location The location in the layer in which the water resides
     * @param isFrozen Whether this water should be frozen or not.
     */
    public Water(TerrainLayer layer, Location location, boolean isFrozen) {
        super(layer, location);
        this.isFrozen = isFrozen;
    }
    
    /**
     * At every simulation step, this method is called. It manages freezing this water object if neccecary, or causing / subsiding flooding where neccecary
     * @param newTerrain A list to accept any new Terrain objects
     */
    public void act(List<Terrain> newTerrain) {
        if (getLayer().shouldFreezeRiver()) {
            if (rand.nextDouble() > 0.5) {
                freezeIfAtSurface();
            }
        } else if (isFrozen) {
            if (rand.nextDouble() > 0.5) {
                isFrozen = false;
            }
        }
        
        if (getLayer().shouldFloodRiver()) {
            flood(newTerrain);
        } else if (isFloodWater && getLayer().shouldUnfloodRiver()) {
             unFloodSlowly();
        }
    }
    
    /**
     * Unflood the river slowly, by removing all water which has been marked as floodwater and has no other water above it
     */
    private void unFloodSlowly() {
        if (!isFloodWater) {
            return;
        }
        Location locationAbove = new Location(location.getX(), location.getY() + 1, location.getZ());
        if (layer.getObjectAt(locationAbove) == null && rand.nextBoolean()) {
            layer.clear(location);
            location = null;
            layer = null;
        }
        
    }
    
    /**
     * Set this water as floodwater
     */
    private void setFloodWater() {
        isFloodWater = true;
    }
    
    /**
     * Allow this Water object to flood by creating new Water objects in adjacent locations
     * @param newTerrain The list to accept new Terrain objects, which is floodwater
     * NOTE: The Water will not flood if it is frozen.
     */
    private void flood(List<Terrain> newTerrain) {
        if (isFrozen) {
            return;
        }
        List<Location> adjacentLocations = layer.adjacentLocations(location, 1, 2);
        for (Location loc : adjacentLocations) {
            if (layer.getObjectAt(loc) == null && rand.nextDouble() > 0.7) {
                Water floodWater = new Water(getLayer(), loc, false);
                floodWater.setFloodWater();
                newTerrain.add(floodWater);
            }
        }
    }
    
    /**
     * If this water is at the surface of the river, it will freeze.
     */
    private void freezeIfAtSurface() {
        if (!isFrozen) {
            Location locationAbove = new Location(location.getX(), location.getY() + 1, location.getZ());
            if (layer.getObjectAt(locationAbove) == null) {
                isFrozen = true;
            }
        }
    }
    
    /**
     * Check whether this water is frozen
     * @return true if this water is frozen.
     */
    public boolean isFrozen() {
        return isFrozen;
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return "Water, " + (isFrozen ? "frozen, " : "not frozen, ") + (isFloodWater ? "is flood water" : "notFloodWater");
    }
}
