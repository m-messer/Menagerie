import java.util.Random;
import java.util.List;

/**
 * A representation of Berries, a plant which can grow and be eaten.
 * 
 * @version 0
 */
public class BerryBush extends Plant implements ConsumableFood
{   
    protected static Random rand = Randomizer.getRandom();
    //Growth
    private static final int MAX_GROWTH = 4;
    private static final double GROWTH_PROBABILITY = 0.02;
    private int growthStage;
    
    /**
     * Create a new BerryBush at a location within a layer
     * @param layer The layer in which to create the bush
     * @param location The location in which to place the bush
     * @param hasRandomGrowth Define whether the berries should have growth 0 or random
     */
    public BerryBush(PlantLayer layer, Location location, boolean hasRandomGrowth) {
        super(layer, location);
        growthStage = hasRandomGrowth ? rand.nextInt(MAX_GROWTH + 1) : 0;
    }
    
    /**
     * Try to grow the berries. Success is based on the growth probability and whether the field is dark
     */
    public void act(List<Plant> newPlants) {
         if (rand.nextDouble() < GROWTH_PROBABILITY && !field.isDark() && growthStage < MAX_GROWTH) {
            growthStage++;
        }
    }
    
    /**
     * Try to eat the berries by a certain amount (value between 0 and 1)
     * @param amount The amount to try and eat
     * @return The amount actually eaten. E.g. returns 0 if the berry bush was empty.
     */
    public double eat(double amount) {
        int stagesToRemove = (int) amount * MAX_GROWTH;
        if (growthStage > stagesToRemove) {
            growthStage -= stagesToRemove;
            return amount;
        } else {
            double currentAmount = (double) growthStage / (double) MAX_GROWTH;
            growthStage = 0;
            return currentAmount;
        }
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return "Berry Bush, growth " + growthStage + " out of " + MAX_GROWTH;
    }
}
