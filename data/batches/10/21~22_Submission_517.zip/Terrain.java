import java.util.List;

/**
 * Represents a LayerObject which resides within the Terrain layer
 * 
 * @version 0
 */
public abstract class Terrain extends LayerObject
{
    /**
     * Create a new Terrain object, at a given location within a Terrain layer
     * @param layer The layer to add the object to
     * @param location The location of the object within the layer.
     */
    public Terrain(TerrainLayer layer, Location location) {
        super(layer, location);
    }
    
    /**
     * This method is called by the TerrainLayer at every step
     * Override this method to make changes at each step of the simulation
     * @param newTerrain The new terrain objects to add to the layer
     */
    public abstract void act(List<Terrain> newTerrain);
    
    /**
     * Get the layer containing this object
     * @return The terrain layer containing this object
     */
    protected TerrainLayer getLayer() {
        return (TerrainLayer) layer;
    }
}
