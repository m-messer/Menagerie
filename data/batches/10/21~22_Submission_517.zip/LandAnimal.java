import java.util.HashMap;
import java.util.List;
import java.util.function.Consumer;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Map;
import java.util.Collections;

/**
 * LandAnimal represents an Animal with age, hunger and an ability to meet, gestate and give birth.
 * 
 * @version 0
 */
public abstract class LandAnimal extends Animal
{
    //Randomizer
    protected static final Random rand = Randomizer.getRandom();
    
    //Status IDs
    protected static final String ASLEEP_STATUS_ID = "ASLEEP";
    protected static final String IDLE_STATUS_ID = "IDLE";
    protected static final String FOOD_HUNTING_STATUS_ID = "FOOD_HUNTING";
    protected static final String MATE_HUNTING_STATUS_ID = "MATE_HUNTING";
    
    //Values which can be altered by each LandAnimal subclass using setters
    private double breedingAge = 30;
    private double maxAgeMean = 250;
    private double maxAgeSD = 50;
    private int maxHunger = 20;
    private double gestationPeriodLength = 1;
    private double remainDecay = 0.1;
    private double meetCooldown = 10;
    private double maleChance = 0.5;
    private int maxBirths = 3;
    private String initialStatusID = ASLEEP_STATUS_ID;
    private double maxSuffocationDuration = 0.4;
    
    //Instance fields - meeting
    private boolean isGestating = false;
    private double gestationPeriodRemaining = -1;
    private double ageAtLastMeet;
    private boolean isMale;
    private double currentSuffocationDuration = 0;
    private HashMap<Class, FoodPair> foodValues = new HashMap<>();
    
    //Instance fields - animal properties
    private double maxAge;
    private double age;
    private int hungerLevel;

    //Instance fields - status
    private HashMap<String, Consumer<LandAnimal>> statuses;
    private String status;
   
    /**
     * Creates a new LandAnimal. Calls initialiseStatuses() followed by setupProperties(), then sets up the instance fields.
     * @param randomAge Whether the age of the animal should be randomly generated or 0
     * @param layer The animal layer
     * @param location The location of the animal
     */
    public LandAnimal(boolean randomAge, AnimalLayer layer, Location location)
    {
        super(layer, location);
        
        statuses = new HashMap<String, Consumer<LandAnimal>>();
        
        intialiseStatuses(statuses);
        setupProperties();
        
        isMale = rand.nextDouble() <= maleChance;
        maxAge = rand.nextGaussian()*maxAgeSD + maxAgeMean;
        if (maxAge <= 0) {
            maxAge = 1;
        }
        age = randomAge ? rand.nextInt((int) maxAge) : 0;
        hungerLevel =  0;
        setStatus(initialStatusID);
    }
    
    /**
     * Use this method to setup the properies of a LandAnimal subclass. If not overriden, default properties are used. Subclasses should use the setters provided.
     */
    protected void setupProperties() { }
    
    
    
    
    //Methods used for meeting
    /**
     * 'Meet' is attempted between the two animals.
     * @return true if the meet succeded, in which case the afterMeetAction for each animal is called. Returns false if the meet failed.
     */
    protected static boolean meet(LandAnimal animal1, LandAnimal animal2) {
        if (!(animal1.canMeetWith(animal2) && animal2.canMeetWith(animal1))) {
            return false;
        }
        
        animal1.afterMeetAction();
        animal2.afterMeetAction();
        return true;
    }
    
    /**
     * Determines what actions are carried out after meeting
     * For all LandAnimals, the age at last meet is set - this is used for checking the cooldown.
     * For female land animals, the gestation period begins.
     */
    protected void afterMeetAction() {
        if (!isMale) {
            isGestating = true;
            gestationPeriodRemaining = gestationPeriodLength;
        }
        ageAtLastMeet = age;
    }
    
    /**
     * Determines if this animal can meet with a specific land animal
     * @param animal The other LandAnimal to try and meetWith.
     * @return true if the animal can meet with the other.
     */
    protected boolean canMeetWith(LandAnimal animal) {
        return canMeet() && 
                (animal.getClass().equals(getClass())) &&
                (animal.isMale != isMale) &&
                (animal.isAlive());
    }
    
    /**
     * Determines if this land animal can meet with any other land animal
     * @return true if not gestating, older than the minimum breeding age, and the meet cooldown has expired.
     */
    protected boolean canMeet() {
        return !isGestating && 
                age > breedingAge &&
                age - ageAtLastMeet > meetCooldown;
    }
    
    /**
     * Gives birth to new baby animals
     * @param newAnimals A list to recieve the new animals.
     */
    private void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = getFreeAdjacentLocations();
        int births = rand.nextInt(maxBirths);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            LandAnimal young = newBabyAnimal(getLayer(), loc);
            newAnimals.add(young);
        }
        isGestating = false;
    }
    
    /**
     * Define a new baby animal
     * @param layer The AnimalLayer
     * @param location The location of the baby animal
     * @return The baby animal
     */
    protected abstract LandAnimal newBabyAnimal(AnimalLayer layer, Location location);
    
    /**
     * Determine if this animal is hungry
     * By default, the animal is hungry if the hunger level is above 75% of its maximum.
     */
    protected boolean isHungry() {
        return hungerLevel > maxHunger * 0.6;
    }
    
    /**
     * Feed the object to a land animal
     * @param obj The object to feed
     * @param to The animal to feed
     * @return true if successful, or false if not.
     */
    protected boolean tryEat(LayerObject obj) {
        FoodPair foodValue = foodValues.get(obj.getClass());
        
        if (foodValue != null) {
            int alterValue = foodValue.getHungerAlterValue();
            double amount = foodValue.getAmount();
            
            if (obj instanceof ConsumableFood) {
                double foodEaten = ((ConsumableFood) obj).eat(amount);
                
                alterHungerLevel((int) (alterValue * (foodEaten / amount)));
                
                return foodEaten > 0;
            } else {
                alterHungerLevel(alterValue);
                return true;
            }
        } else {
            return false;
        }
    }
    
    /**
     * Set the statuses that this LandAnimal can take.
     * @param statuses A HashMap of a StatusID and a Consumer function representing the action at that status.
     * If overriden, call super to initialise the default statuses.
     */
    protected void intialiseStatuses(HashMap<String, Consumer<LandAnimal>> statuses) {
        statuses.put(IDLE_STATUS_ID, (animal) -> {
            if (rand.nextBoolean()) {
                moveToRandomAdjacentLocation();
            }
        });
        
        statuses.put(FOOD_HUNTING_STATUS_ID, (animal) -> {
            List<LayerObject> objectsAdjacent = objectsAdjacent();
        
            for (LayerObject obj : objectsAdjacent) {
                Location loc = obj.getLocation();
                boolean success = animal.tryEat(obj);
                
                if (success) {
                    return;
                }
            }
            
            List<LayerObject> objectsInView = objectsInVision();
            for (LayerObject object : objectsInView) {
                if (isFood(object.getClass())) {
                    moveWithRespectTo(object.getLocation(), true);
                    return;
                }
            }
            
            animal.moveToRandomAdjacentLocation();
        });
        
        statuses.put(MATE_HUNTING_STATUS_ID, (animal) -> {
            List<LayerObject> objectsAdjacent = objectsAdjacent();
            
            for (LayerObject object : objectsAdjacent) {
                if (object.getClass().equals(getClass())) {
                    boolean met = LandAnimal.meet((LandAnimal) object, animal);
                    
                    if (met) {
                        return;
                    }
                }
            }
            
            List<LayerObject> animalsInView = objectsInVision();
            for (LayerObject object : animalsInView) {
                if (object.getClass().equals(getClass()) && ((LandAnimal) object).canMeetWith(this)) {
                    animal.moveWithRespectTo(animal.getLocation(), true);
                    return;
                }
            }
            
            animal.moveToRandomAdjacentLocation();
        });
        
        statuses.put(ASLEEP_STATUS_ID, (animal) -> {
        });
    }
    
    /**
     * Check if a location is free to move to
     * @param loc The location to check
     * @return True if the location is empty and on land.
     */
    protected boolean isFree(Location loc) {
        return !(field.getPlantLayer().getObjectAt(loc) instanceof Tree) &&
                 field.getTerrainLayer().getObjectAt(loc) == null &&
                 layer.getObjectAt(loc) == null;
    }
    
    /**
     * Check if a location will suffocate the animal
     * @param loc The location to check
     */
    protected boolean doesLocationSuffocate(Location loc) {
        return field.getPlantLayer().getObjectAt(loc) instanceof Tree ||
                 field.getTerrainLayer().getObjectAt(loc) != null;
    }
    
    /**
     * Move if the animal is suffocating, to a free location or towards a free location
     * @return true if the animal is suffocating, false if the animal is not suffocating
     */
    protected boolean moveIfSuffocating() {
        if (doesLocationSuffocate(location)) {
            List<Location> adjacentLocations = getAdjacentLocations();
            for (Location adj : adjacentLocations) {
                if (isFree(adj)) {
                    setLocation(adj);
                    return true;
                }
            }
            
            for (Location visible : visibleLocations()) {
                if (isFree(visible)) {
                    moveWithRespectTo(visible, true);
                    return true;
                }
            }
            
            if (adjacentLocations.size() > 0) {
                setLocation(adjacentLocations.get(0));
                return true;
            } 
            
            setDead("Suffocation");
            return true;
        }
        return false;
    }
    
    /**
     * Get locations adjacent to the animal.
     * @return Adjacent locations which are on land.
     */
    @Override
    public List<Location> getAdjacentLocations() {
       List<Location> adjacent = super.getAdjacentLocations();
       List<Location> onLand = new ArrayList<Location>();
       
       for (Location loc : adjacent) {
           Location locBelow = new Location(loc.getX(), loc.getY() - 1, loc.getZ()); 
           LayerObject objectBelow = field.getTerrainLayer().getObjectAt(locBelow);
           
           if (objectBelow instanceof Rock || (objectBelow instanceof Water && ((Water) objectBelow).isFrozen())
                && (field.getTerrainLayer().getObjectAt(loc) == null)) {
               onLand.add(loc);
           }
        }
       return onLand;
    }
    
    //Animal overriden methods
    /**
     * Provides an action for the animal. 
     * Calls incrementOnStep(), beforeChangeStatus(), tryChangeStatus(), beforeAction(), afterAction() which can be overriden.
     * @param newAnimals A list to accept new animals.
     */
    public final void act(List<Animal> newAnimals) {
        //Decay if dead
         if (!isAlive()) {
            removeRemains(remainDecay);
            return;
        }

        //Move if suffocating
        if (moveIfSuffocating()) {
            return;
        }
        
        //Reduce gestation period or give birth if gestating
        if (isGestating) {
            gestationPeriodRemaining -= 1d/16d;
            
            if (gestationPeriodRemaining <= 0) {
                giveBirth(newAnimals);
                gestationPeriodRemaining = -1;
            }
        }
        
        incrementOnStep();
        
        beforeChangeStatus();
        
        tryChangeStatus();
        
        beforeAction();
        
        Consumer<LandAnimal> action = statuses.get(status);
        if (action != null) {
            action.accept(this);
        }
        
        afterAction();
    }
    
    //'Delegate' methods
    
    /**
     * Override this method to increment the status values of the animal e.g. age and hunger.
     * Default implementation increases hunger by 1 and increments age, and causes death if neccecary.
     */
    protected void incrementOnStep() {
        incrementAge();
        incrementHunger();
    }
    /**
     * Override this method to make changes before the status is changed
     */
    protected void beforeChangeStatus() {}
    /**
     * Override this method to change the status of the animal on each step.
     */
    protected abstract void tryChangeStatus();
    
    /**
     * Override this method to make changes before the action is performed
     */
    protected void beforeAction() {}
    /**
     * Override this method to make changes after the action is performed
     */
    protected void afterAction() {}
    
    
    protected void incrementAge() {
        age += 1/16d;
        if (age >= maxAge) {
            setDead("Old Age");
        }
    }
    
    protected void incrementHunger() {
        hungerLevel += 1;
        if (hungerLevel > maxHunger) {
            setDead("Hunger");
        }
    }
    
    //Getters for use by subclasses
    /**
     * Get the age of the animal
     * @return The age in days
     */
    protected final double getAge() { 
        return age;
    }
    
    /**
     * Get the hunger level of the animal
     * @return The hunger level
     */
    protected final int getHungerLevel() { 
        return hungerLevel;
    }
    
    protected final boolean isFood(Class c) {
        return (foodValues.get(c) != null);
    }
    
    /**
     * Alter the hunger level
     * @param delta The value by which to alter the hunger.
     */
    protected final void alterHungerLevel(int delta) {
        hungerLevel += delta;
        if (hungerLevel < 0) {
            hungerLevel = 0;
        }
    }
    
    /**
     * Set the current status using a valid status ID
     * @param status The status ID to change. If invalid, no changes are made.
     */
    protected void setStatus(String status) {
        if (statuses.get(status) != null) {
            this.status = status;
        }
    }
    
    /**
     * Get the status ID of the animal
     * @return The status ID.
     */
    protected String getStatus() {
        return status;
    }
    
    //Setters for use in setupProperties()
    /**
     * Set the minimum age at which the LandAnimal can breed
     * Default value = 30
     * @param age The minimum breeding age, in days.
     */
    protected final void setBreedingAge(double age) {
        if (age >= 0) {
            breedingAge = age;
        }
    }
    
    /**
     * Set the mean maximum age (mean age at death from old age).
     * Default value = 250
     * @param age The mean maximum, in days.
     */
    protected final void setMaxAgeMean(double age) {
        if (age >= 0) {
            maxAgeMean = age;
        }
    }
   
    /**
     * Set the standard deviation of the maximum age (sd of age at death from old age).
     * Default value = 50
     * @param age The standard deviation, in days.
     */
    protected final void setMaxAgeSD(double age) {
        if (age >= 0) {
            maxAgeSD = age;
        }
    }
    
    /**
     * Set the maximum hunger that the LandAnimal can withstand.
     * Default value = 20
     * @param hunger The maximum hunger, as a non-negative integer.
     */
    protected final void setMaxHunger(int hunger) {
        if (hunger >= 0) {
            maxHunger = hunger;
        }
    }
    
    /**
     * Set the length of the gestation period for female LandAnimals 
     * Default value = 1
     * @param length The gestation period length, in days.
     */
    protected final void setGestationPeriodLength(double length) {
        if (length >= 0) {
            gestationPeriodLength = length;
        }
    }
    
    /**
     * Set the value by which the remains decay, per step, after death.
     * Default value = 0.1
     * @param decay The decay amount, which is a decimal between 0 and 1.
     */
    protected final void setRemainDecay(double decay) {
        if (decay > 0 && decay <= 1) {
            remainDecay = decay;
        }
    }
    
    /**
     * Set the cooldown for the time between this LandAnimal meeting.
     * Default value = 10
     * @param length The cooldown amount, in days.
     */
    protected final void setMeetCooldown(double length) {
        if (length >= 0) {
            meetCooldown = length;
        }
    }
    
    /**
     * Set the probability that the animal is male.
     * Default value = 0.5
     * @param length The probability of this animal being male, as a decimal between 0 and 1.
     */
    protected final void setMaleChance(double probability) {
        if (probability >= 0 && probability <= 1) {
            maleChance = probability;
        }
    }
   
    /**
     * Set the initial status of the LandAnimal, which should be one of the statuses defined by default or by using 'initialiseStatuses'
     * Default value = ASLEEP_STATUS_ID
     * @param statusID The status ID of the initial status.
     */
    protected void setInitialStatus(String statusID) {
        if (statuses.get(status) != null) {
            initialStatusID = statusID;
        }
    }
    
    /**
     * Set the maximum number of births that can occur after any gestation cycle ends.
     * Default value = 3
     * @param age The maximum number of births
     */
    protected final void setMaxBirths(int births) {
        if (births >= 1) {
            maxBirths = births;
        }
    }
    
    /**
     * Set the maximum duration for which this animal can suffocate, in days
     * Default value: 3/16 days
     * @param The maximum duration to set
     * Note: This feature only works if moveIfSuffocating is called in act.
     */
    protected final void setMaxSuffocationDuration(double duration) {
        if (duration > 0) {
            maxSuffocationDuration = duration;
        }
    }
    
    /**
     * Add a food that the animal can eat
     * @param food The class of the food
     * @param amount The amount (as an decimal between 0 and 1) of the food that is consumed. Only used for ConsumableFood.
     * @param hungerAlterValue, the value by which hunger is changed - negative if it reduces hunger, positive if it increases hunger.
     */
    protected final void addFood(Class food, double amount, int hungerAlterValue) {
        if (amount > 0 && amount <= 1) {
            foodValues.put(food, new FoodPair(amount, hungerAlterValue));
        }
    }
    
    /**
     * Represents a pair of values that define the value of a certain food: A hunger alter value, and an amount
     */
    protected class FoodPair {
        private int hungerAlterValue;
        private double amount;
        
        /**
         * Create a new FoodPair
         * @param amount The amount of the food that provides the hungerAlterValue
         * @param hungerAlterValue The number to alter the hunger by, positive to increase hunger, negative to decrease
         */
        protected FoodPair(double amount, int hungerAlterValue) {
            this.hungerAlterValue = hungerAlterValue;
            this.amount = amount;
        }
        
        /**
         * Get the amount
         * @return the amount
         */
        private double getAmount() {
            return amount;
        }
        
        /**
         * Get the hunger alter value
         * @return the hunger alter value
         */
        private int getHungerAlterValue() {
            return hungerAlterValue;
        }
    }
    
    /**
     * Generate a String representation of the object
     * @return The string representation
     */
    public String toString() {
        String returnString = " isMale: " + isMale + "\n maxAge: " + maxAge + "\n age: " + age + "\n\n isGestating: " 
        + isGestating + "\n gestationPeriodRemaining: " + gestationPeriodRemaining
        + "\n ageAtLastMeet: " + ageAtLastMeet 
        + "\n\n hungerLevel: " + hungerLevel + "\n status: " + status;
        if (!isAlive()) {
            returnString += "\n\nDead due to: " + deathString + "\n remains: " + getRemains();
        }
        return returnString;
    }
}
