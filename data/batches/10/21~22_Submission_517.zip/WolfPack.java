import java.util.ArrayList;

/**
 * A class representing a pack of wolves.
 *  
 * @version 0
 */
public class WolfPack {
    ArrayList<Wolf> members;
    
    /**
     * Create a new wolf pack consisting of no members.
     */
    public WolfPack() {
        members = new ArrayList<Wolf>();
    }
    
    /**
     * Get the leader of the wolf pack
     * @return The leader, or null if the pack is empty
     */
    public Wolf getLeader() {
        if (members.size() > 0) {
            return members.get(0);
        } else {
            return null;
        }
    }
    
    /**
     * Add a wolf to the pack
     * @param wolf The wolf to add
     */
    public void remove(Wolf wolf) {
        members.remove(wolf);
    }
    
    /**
     * Remove a wolf to the pack
     * @param wolf The wolf to add
     */
    public void add(Wolf wolf) {
        members.add(wolf);
    }
}
