import java.util.List;

/**
 * Represents 'Grass' as a Plant object
 * 
 * @version 0
 */
public class Grass extends Plant
{
     /**
     * Create a new Grass object in at a location in a layer
     * @param layer The layer to add the grass to
     * @param location The location in which to place the grass
     */
    public Grass(PlantLayer layer, Location location) {
        super(layer, location);
    }
    
    /**
     * Make the Grass act at every terrain layer
     * The grass is not a managed object and it does nothing at every simulation step.
     */
    public void act(List<Plant> newPlant) {
        
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return "Grass";
    }
    
}
