import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A FieldLayer responsible for creating a plant wildlife of grass, trees, kelp and berries
 * 
 * @version 0
 */
public class PlantLayer extends FieldLayer
{   
    private static final double TREE_CREATION_PROBABILITY = 0.02;
    private static final double BERRY_BUSH_CREATION_PROBABILITY = 0.007;
    private static final double KELP_CREATION_PROBABILITY = 0.2;
    
    /**
     * Create a PlantLayer to be a part of the field.
     * @param field the field in which the layer conforms to
     */
    public PlantLayer(Field field)
    {
        super(field);
    }
    
    /**
     * Populates the layer with grass, trees, kelp and berries
     */
    public void populateRandomly() {
        int length = getField().getLength();
        int width = getField().getWidth();
        int height = getField().getHeight();
        TerrainLayer terrainLayer = getField().getTerrainLayer();
        
        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                for (int y = height - 2; y >= 0; y--) {
                    Location location = new Location(x, y, z);
                    Location locationAbove = new Location(x, y+1, z);
                    
                    if (terrainLayer.getObjectAt(location) instanceof Rock && terrainLayer.getObjectAt(locationAbove) == null) {
                        if (rand.nextDouble() < BERRY_BUSH_CREATION_PROBABILITY) {
                            BerryBush bush = new BerryBush(this, locationAbove, true);
                            managedObjects.add(bush);
                        } else if (rand.nextDouble() < TREE_CREATION_PROBABILITY) { //Create tree
                            int newY = y+1;
                            while (getField().isValidLocation(locationAbove) && terrainLayer.getObjectAt(locationAbove) == null) {
                                Tree tree = new Tree(this, new Location(x, newY, z));
                                if (rand.nextDouble() < 0.3) {
                                    newY++;
                                    locationAbove = new Location(x, newY, z);
                                } else {
                                    locationAbove = null;
                                }
                            }
                        } else {
                            Grass grass = new Grass(this, locationAbove);
                        }
                        break;
                    } else if (terrainLayer.getObjectAt(location) instanceof Water) {
                        if (rand.nextDouble() < KELP_CREATION_PROBABILITY) {
                            Kelp kelp = new Kelp(this, location);
                        }
                    }                    
                }  
            }
        }
        
    }
    
    /**
     * Tell the layer to carry out one step of the simulation
     */
    public void simulateOneStep() {
        List<Plant> newPlants = new ArrayList<>(); 
        for(Iterator<LayerObject> it = managedObjects.iterator(); it.hasNext();) {
            Plant plant = (Plant) it.next();
            plant.act(newPlants);
            if(plant.getLocation() == null) {
                it.remove();
            }
        }
        managedObjects.addAll(newPlants);
    }
    
}
