import java.util.List;

/**
 * Represents 'Kelp' as a Plant material
 * 
 * @version 0
 */
public class Kelp extends Plant
{
     /**
     * Create a new Kelp object in at a location in a layer
     * @param layer The layer to add the kelp to
     * @param location The location in which to place the kelp
     */
    public Kelp(PlantLayer layer, Location location) {
        super(layer, location);
    }

    /**
     * Make the Kelp act at every terrain layer
     * Kelp is not a managed object and it does nothing at every simulation step.
     */
    public void act(List<Plant> newPlant) {
        
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return "Kelp";
    }
    
}
