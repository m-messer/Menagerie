import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.HashMap;
import javafx.scene.paint.Color;
import java.util.Set;
import java.util.HashSet;

/**
 * Represents a stack of field layers, all of which use the same coordinate system.
 * Each layer is simulated sequentially.
 *  
 * @version 2016.02.29
 */
public class Field
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();
    
    // The depth and width of the field.
    private int length, height, width;
    private List<FieldLayer> layers;
    
    //The layers
    private TerrainLayer terrainLayer;
    private PlantLayer plantLayer;
    private AnimalLayer animalLayer;
    
    private Simulator simulator;
    
    /**
     * Represent a field of the given dimensions.
     * @param length The length of the field. (X)
     * @param height The height of the field. (Y)
     * @param width The width of the field. (Z)
     * @param simulator The simulator attached to the field.
     */
    public Field(int length, int height, int width, Simulator simulator)
    {
        this.length = length;
        this.width = width;
        this.height = height;
        this.simulator = simulator;
        
        layers = new ArrayList<>();
        
        terrainLayer = new TerrainLayer(this);
        plantLayer = new PlantLayer(this);
        animalLayer = new AnimalLayer(this);
        //The order in which layers are added matters!
        layers.add(terrainLayer);
        layers.add(plantLayer);
        layers.add(animalLayer);
    }
    
    //Simulation
    /**
     * Perform one step of the simulation by making all layers perform one step
     */
    public void simulateOneStep() {
        layers.forEach(l -> l.simulateOneStep());
    }
    
    /**
     * Determine if the simulation is viable (if all layers are viable)
     * @return true if the simulation should continue 
     */
    public boolean isViable() {
        for (FieldLayer layer : layers) {
            if (!layer.isViable()) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Reset the simulation to initial conditions
     */
    public void reset() {
        layers.forEach(l -> l.reset());
    }
    
    //Field information
    /**
     * Get the step number of the simulation that the field is currently displaying.
     */
    public int getStepNumber() {
        return simulator.getStep();
    }
    
    /**
     * Get whether this field is currently dark
     * @return true if the field is dark
     */
    public boolean isDark() {
        int progressWithinDay = simulator.getStep() % 16;
        return (progressWithinDay < 3 || progressWithinDay > 13);
    }
    
    /**
     * Get whether it is winter in this field
     * @return true if it is winter in this field.
     */
    public boolean isWinter() {
        int progressWithinYear = simulator.getStep() % 365;
        return progressWithinYear > 355 || progressWithinYear < 79;
    }
    
    /**
     * Determine if a location is within the bounds of this field and non-null
     * @return true if the location is valid
     */
    public boolean isValidLocation(Location location) {
        return location != null && !location.isOutsideBounds(length, height, width);
    }
    
    //Getters
    /**
     * Get all layers
     * @return A list containing all layers
     */
    public List<FieldLayer> getLayers() {
        return layers;
    }
    
    /**
     * Get the terrain layer
     * @return The terrain layer
     */
    public TerrainLayer getTerrainLayer() {
        return terrainLayer;
    }
    
    /**
     * Get the plant layer
     * @return The plant layer
     */
    public PlantLayer getPlantLayer() {
        return plantLayer;
    }
    
    /**
     * Get the animal layer
     * @return The animal layer
     */
    public AnimalLayer getAnimalLayer() {
        return animalLayer;
    }

    /**
     * Return the height of the field.
     * @return The height of the field.
     */
    public int getHeight()
    {
        return height;
    }
    
    /**
     * Return the width of the field.
     * @return The width of the field.
     */
    public int getWidth()
    {
        return width;
    }
    
     /**
     * Return the length of the field.
     * @return The length of the field.
     */
    public int getLength()
    {
        return length;
    }
}
