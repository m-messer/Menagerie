import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.HashMap;

/**
 * Representation of a fish animal
 * 
 * @version 0
 */
public class Fish extends Animal
{
    private final static Random rand = Randomizer.getRandom();
    //Probabilities for probability-based animal
    private final static double DEATH_PROBABILITY = 0.003;
    private final static double DUPLICATION_PROBABILITY = 0.006;
    private final static double HUNGER_PROBABILITY = 0.2;
    private final static double SUFFOCATION_PROBABILITY = 0.5;
    private final static double HUNGER_DEATH_PROBABILITY = 0.7;
    
    private final HashMap<Class, Double> food; //Food to amount eaten
    
    /**
     * Create a new fish
     * @param layer The layer of the fish
     * @paral location The location within the layer
     */
    public Fish(AnimalLayer layer, Location location)
    {
        super(layer, location);
        food = new HashMap<Class, Double>();
        food.put(Kelp.class, 1d);
    }

    /**
     * Called at every simulation step to make the fish act, based on its defining probabilities
     */
    public void act(List<Animal> newAnimals) {
        if (!isAlive()) {
            removeRemains(0.4);
            return;
        }
        
        if (!(field.getTerrainLayer().getObjectAt(location) instanceof Water)) {
            if (rand.nextDouble() < SUFFOCATION_PROBABILITY) {
                setDead("Suffocation");
                return;
            } else {
                moveToRandomAdjacentLocation();
                return;
            }
        }
        
        
        if (rand.nextDouble() < DEATH_PROBABILITY) {
            setDead("Natural death");
            return;
        }
        
        if (rand.nextDouble() < DUPLICATION_PROBABILITY) {
            duplicate(newAnimals);
        }
        
        if (rand.nextDouble() < HUNGER_PROBABILITY) {
            boolean isEatSuccess = eatFood();
            if (!isEatSuccess && rand.nextDouble() < HUNGER_DEATH_PROBABILITY) {
                setDead("Hunger");
            }
        }
        
        moveToRandomAdjacentLocation();
    }
    
    /**
     * Get the fish to eat food in its adjacent locations
     * @return true if food was found and eaten, or false if not.
     */
    private boolean eatFood() {
        for (LayerObject adjacentObject : objectsAdjacent()) {
            Double amount = food.get(adjacentObject.getClass());
            if (amount != null) {
                if (adjacentObject instanceof ConsumableFood) {
                    double amountEaten = ((ConsumableFood) adjacentObject).eat(amount);
                    if (amountEaten > 0) {
                        return true;
                    }
                } else {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Duplicate this fish to create a new fish
     * @param newAnimals A list to accept new fish 
     */
    private void duplicate(List<Animal> newAnimals) {
        Location freeAdjacentLocation = freeAdjacentLocation();
        FieldLayer l  = getLayer();
        Fish babyFish = new Fish(getLayer(), freeAdjacentLocation);
        newAnimals.add(babyFish);
    }
    
    /**
     * Determines whether a location is free for the fish to move to
     * @param loc The loction to check
     * @return true if the fish can move to the location
     */
    protected boolean isFree(Location loc) {
        LayerObject objectAtTerrainLayer = field.getTerrainLayer().getObjectAt(loc);
        return objectAtTerrainLayer instanceof Water && 
                !((Water) objectAtTerrainLayer).isFrozen() &&
                layer.getObjectAt(loc) == null;
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return "Fish";
    }
}
