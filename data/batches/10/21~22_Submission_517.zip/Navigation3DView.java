import javafx.animation.TranslateTransition;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.collections.ObservableList;
import javafx.geometry.Bounds;
import javafx.geometry.Point3D;
import javafx.scene.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Transform;
import javafx.util.Duration;

/**
 * A JavaFX pane to display a 3D content defined in a Group and allow user navigation via the keyboard and mouse
 *  
 * @version 0
 */
public abstract class Navigation3DView extends StackPane
{
    private final Scene parent;
    
    private Camera camera;
    private SubScene contentScene;
    private Group content = new Group();

    /**
     * Create a new Navigation3DView
     * @param parent The scene in which the view will be added. Used for event handling purposes.
     */
    public Navigation3DView(Scene parent)
    {
        super();
        this.parent = parent;
        this.content = content;
        
        contentScene = createContentScene();

        /**
         * Reference: Using a StackPane to allow resizing of a JavaFX subscene
         * From stackoverflow.com, answered by MitchBroadhead on Aug 11, 2014
         * https://stackoverflow.com/questions/24606392/how-to-resize-a-javafx-3d-subscene
         * Accessed 24 Feb 2022
         */
        getChildren().add(contentScene);
        contentScene.setManaged(false);
        contentScene.widthProperty().bind(widthProperty());
        contentScene.heightProperty().bind(heightProperty());
    }
    
    /**
     * Create a content subscene with a perspective camera, keyboard control for moving the camera, mouse control for panning the camera.
     * @return The created subscene
     */
    private SubScene createContentScene() {
        /**
         * Reference: Using a SubScene to display 3D content in a 2D environment. 
         * Inspired from stackoverflow.com, answered by jewelsea on Mar 4, 2014
         * https://stackoverflow.com/questions/22161586/javafx-embed-scene-in-scene
         * Accessed 24 Feb 2022
         */
        SubScene contentScene = new SubScene(content, 100, 100, true, SceneAntialiasing.BALANCED);
        contentScene.fillProperty().set(Color.BLACK);

        /**
         * Reference: Basics of JavaFX 3D.
         * Inspired from https://www.youtube.com/watch?v=nBjwBmH8OhQ and https://www.youtube.com/watch?v=CO0q99ZJouM
         * Videos were created by 'Genuine Coder' on 22 and 23 Sep 2018 respectively,
         * Accessed 23 Feb 2022
         */
        camera = new PerspectiveCamera(true);
        camera.setNearClip(1);
        camera.setFarClip(10000);
        contentScene.setCamera(camera);

        parent.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            Bounds cameraBounds = camera.getBoundsInParent();

            switch (event.getCode()) {
                case W:
                    Point3D moveForward = new Point3D(0, 0, 30);
                    Point3D translated = applyTransformations(moveForward, camera.getTransforms());
                    translateCamera(translated);
                    break;
                case S:
                    Point3D moveBack = new Point3D(0, 0, -30);
                    Point3D translated2 = applyTransformations(moveBack, camera.getTransforms());
                    translateCamera(translated2);
                    break;
                case A:
                    Point3D moveLeft = new Point3D(-30, 0, 0);
                    Point3D translated3 = applyTransformations(moveLeft, camera.getTransforms());
                    translateCamera(translated3);
                    break;
                case D:
                    Point3D moveRight = new Point3D(30, 0, 0);
                    Point3D translated4 = applyTransformations(moveRight, camera.getTransforms());
                    translateCamera(translated4);
                    break;
                case E:
                    translateCamera(new Point3D(0, -30, 0));
                    break;
                case C:
                    translateCamera(new Point3D(0, 30, 0));
                    break;
            }
        });

        initMouseControl();
        return contentScene;
    }
    
    /**
     * Set the content of the view. Called by subclasses which provide custom content.
     * @param content The content to display
     */
    protected void setContent(Group content) {
        this.content = content;
        contentScene.rootProperty().set(content);
    }
    
    /**
     * Set the camera position
     * @param pos The point to set the camera to
     * @param angleX The angle in the +/- X direction to pan the camera to
     * @param angleY The angle in the +/- Y direction to pan the camera to
     */
    public void setCameraPosition(Point3D pos, double angleX, double angleY) {
        camera.translateXProperty().set(pos.getX());
        camera.translateYProperty().set(pos.getY());
        camera.translateZProperty().set(pos.getZ());
        
        this.angleX.set(angleX);
        this.angleY.set(angleY);
    }

    /**
     * Helper method to transform one point by each of a list of transforms sequentially
     * @param point The initial (object) point
     * @param transforms The transforms to be applied, in order, the point
     * @return The final (image) point
     */
    private Point3D applyTransformations(Point3D point, ObservableList<Transform> transforms) {
        Point3D translatedPoint = point;
        for (Transform transform : transforms) {
            translatedPoint = transform.transform(translatedPoint);
        }
        return translatedPoint;
    }

    /**
     * Helper method to animate the camera to a new position, defined by a translation vector
     * @param translation The translation vector.
     */
    private void translateCamera(Point3D translation) {
        /**
         * Reference: Transitions in JavaFX, inspired from this Oracle tutorial
         * https://docs.oracle.com/javase/8/javafx/visual-effects-tutorial/basics.htm
         * Accessed on 25 Feb 2022
         */
        TranslateTransition transition = new TranslateTransition(Duration.millis(20), camera);
        transition.setByX(translation.getX());
        transition.setByY(translation.getY());
        transition.setByZ(translation.getZ());
        transition.play();
    }

    /**
     * Reference: Panning the camera by dragging on the pane. The code below this point was copied from a part of this reference
     * Copied rom stackoverflow.com, from the QUESTION asked by Joshua Chambers on Sep 20, 2021
     * https://stackoverflow.com/questions/69249037/most-simple-rotate-camera-via-mouse-not-working
     * Accessed 24 Feb 2022
     */
    private double anchorX, anchorY;
    private double anchorAngleX = 0;
    private double anchorAngleY = 0;
    private DoubleProperty angleX = new SimpleDoubleProperty(0);
    private DoubleProperty angleY = new SimpleDoubleProperty(0);
    
    /**
     * Begin the mouse control to allow panning of the camera by dragging
     */
    private void initMouseControl() {
        Rotate xRotate = new Rotate(0, Rotate.X_AXIS);
        Rotate yRotate = new Rotate(0, Rotate.Y_AXIS);
    
        camera.getTransforms().addAll(xRotate, yRotate);

        xRotate.angleProperty().bind(angleX);
        yRotate.angleProperty().bind(angleY);

        setOnMousePressed(event -> {
            anchorX = event.getSceneX();
            anchorY = event.getSceneY();
            anchorAngleX = angleX.get();
            anchorAngleY = angleY.get();
        });

        setOnMouseDragged(event -> {
            angleX.set(anchorAngleX - (anchorY - event.getSceneY()));
            angleY.set(anchorAngleY + anchorX - event.getSceneX());
        });
    }
    
    
}
