import java.util.List;

/**
 * A representation of a Plant
 *
 * @version 0
 */
public abstract class Plant extends LayerObject
{
    /**
     * Create a new Plant in at a location in a layer
     * @param layer The layer to add the plant to
     * @param location The location in which to place the plant
     */
    public Plant(PlantLayer layer, Location location) {
        super(layer, location);
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     */
    abstract public void act(List<Plant> newPlants);
}
