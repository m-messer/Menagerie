import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

/**
 * Represent a location in a 3D grid.
 *  
 * @version 2016.02.29
 */
public class Location
{
    // Coordinate values
    private int x;
    private int y;
    private int z;

    /**
     * Represent a coordinate
     * @param x The x coordinate 
     * @param y The y coordinate 
     * @param z The z coordinate
     */
    public Location(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    /**
     * Add two locations together, using vector addition
     * @param l1 The first location to add
     * @param l2 The second location to add
     * @return The addition
     */
    public static Location add(Location l1, Location l2) {
        return new Location(l1.getX() + l2.getX(), l1.getY() + l2.getY(), l1.getZ() + l2.getZ());
    }

    /**
     * Get the locations 3D box of points around a centre location
     * @param centreLocation The centre
     * @param radius The 1/2 length of the box side
     * @return A list of locations that define the box.
     */
    public static List<Location> boxOfPointsAround(Location centreLocation, int radius) {
        ArrayList<Location> locations = new ArrayList<Location>();
        
        if (radius <= 0) {
            return locations;
        }
        
        for (int i = -radius; i <= radius; i++) {
            Location newLocation1 = Location.add(centreLocation, new Location(-radius, 0, i));
            Location newLocation2 = Location.add(centreLocation, new Location(radius, 0, i));
            locations.add(newLocation1);
            locations.add(newLocation2);
        }
        
        for (int i = -radius + 1; i <= radius - 1; i++) {
            Location newLocation1 = Location.add(centreLocation, new Location(i, 0, radius));
            Location newLocation2 = Location.add(centreLocation, new Location(i, 0, -radius));
            locations.add(newLocation1);
            locations.add(newLocation2);
        }
        
        return locations;
    }
    
    /**
     * Get a line of points (2D) around a centre location of a certain length
     * @param centreLocation The centre location
     * @param length The length of the line
     * @param direction The direction of the line - 0 for X, 1 for Y, 2 for Z
     * @return A list of points in the line, or an empty list if an invalid direction is specified.
     */
    public static Set<Location> lineOfPoints(Location centreLocation, int length, int direction) {
        Set<Location> locations = new HashSet<Location>();
        
        if (direction == 0) { //X
            for (int i = centreLocation.getX()-length/2; i <= centreLocation.getX()+length/2; i++) {
                locations.add(new Location(i, centreLocation.getY(), centreLocation.getZ()));
            }
        } else if (direction == 1) {//Y
            for (int i = centreLocation.getY()-length/2; i <= centreLocation.getY()+length/2; i++) {
                locations.add(new Location(centreLocation.getX(), i, centreLocation.getZ()));
            }
        } else if (direction == 2) {//Z
            for (int i = centreLocation.getZ()-length/2; i <= centreLocation.getZ()+length/2; i++) {
                locations.add(new Location(centreLocation.getX(), centreLocation.getY(), i));
            }
        }
        
        return locations;
    }
    
    /**
     * Determine if a location is outside the bounds of a 3D cuboid specified by the perameters
     * @return true if the location is outside the bounds
     */
    public boolean isOutsideBounds(int maxX, int maxY, int maxZ, int minX, int minY, int minZ) {
        return x >= maxX || x < minX || y >= maxY || y < minY || z >= maxZ || z < minZ;
    }
    
    
    /**
     * Determine if a location is outside the bounds of a 3D cuboid with one vertex being the origin and the other specified by the perameters
     * @return true if the location is outside the bounds
     */
    public boolean isOutsideBounds(int maxX, int maxY, int maxZ) {
        return isOutsideBounds(maxX, maxY, maxZ, 0, 0, 0);
    }
    
    /**
     * Get the distance between this point and another
     * @param otherLocation The other location
     */
    public double distanceTo(Location otherLocation) {
        return Math.sqrt(
            Math.pow((getX() - otherLocation.getX()), 2) + 
            Math.pow((getY() - otherLocation.getY()), 2) + 
            Math.pow((getZ() - otherLocation.getZ()), 2)
        );
    }
    
    /**
     * Implement content equality.
     */
    public boolean equals(Object obj)
    {
        if(obj instanceof Location) {
            Location other = (Location) obj;
            return x == other.getX() && y == other.getY() && z == other.getZ();
        }
        else {
            return false;
        }
    }
    
    /**
     * Return a string of the form XxYyZz
     * @return A string representation of the location.
     */
    public String toString()
    {
        return "X" + x + "Y" + y + "Z" + z;
    }
    
    /**
     * Get a unique value for each (x, y, z) pair
     * @return A hashcode for the location.
     */
    public int hashCode()
    {
        return (x << 32) + (y << 16) + z;
    }
    
    /**
     * @return The X.
     */
    public int getX()
    {
        return x;
    }
    
    /**
     * @return The Y.
     */
    public int getY()
    {
        return y;
    }
    /**
     * @return The Z.
     */
    public int getZ()
    {
        return z;
    }
}
