import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.SceneAntialiasing;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;

/**
 * The main window for the application, providing user control over the simulation.
 *  
 * @version 0
 */
public class SimulatorView extends Application
{
    private Simulator simulator;
    private FieldView fieldView;
    private Scene scene;
    private Thread taskThread;

    /**
     * Initialise the UI of the application
     *
     * @param stage the primary stage for this application.
     */
    @Override
    public void start(Stage stage)
    {
        simulator = new Simulator(this);

        BorderPane root = new BorderPane();
        root.setMinSize(300, 300);

        scene = new Scene(root, 1000, 700, true, SceneAntialiasing.BALANCED);
        
        //Toolbar buttons
        Button simulateOneStepButton = new Button("Simulate one step");
        Button simulateSomeSteps = new Button("Simulate n steps");
        Button runLongSimulationButton = new Button("Run long simulation");
        Button createNewButton = new Button("Create new simulation");
        Button cameraToHomeButton = new Button("Move camera home");
        Button changeDimensionsButton = new Button("Change dimensions");

        simulateOneStepButton.setOnAction(this::simulateOneStep);        
        simulateSomeSteps.setOnAction(this::simulateSomeSteps);
        runLongSimulationButton.setOnAction(this::runLongSimulation);
        createNewButton.setOnAction(this::createNewSimulation);
        cameraToHomeButton.setOnAction(this::moveCameraToHome);
        changeDimensionsButton.setOnAction(this::changeDimensions);
        
        //Toolbar
        ToolBar toolBar = new ToolBar(
            simulateOneStepButton,
            simulateSomeSteps,
            runLongSimulationButton,
            new Separator(),
            cameraToHomeButton,
            new Separator(),
            createNewButton,
            changeDimensionsButton
        );
        root.topProperty().set(toolBar);
    
        //Field view
        fieldView = new FieldView(scene, simulator.getField());
        root.centerProperty().set(fieldView);
        
        stage.setTitle("Simulation");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Action for 'Simulate one step' button, simulates one step
     * @param event The action event
     */
    private void simulateOneStep(ActionEvent event) {
        showRunningSimulationWarningIfNeccecary();
        simulator.simulateOneStep();
    }

    /**
     * Action for 'Simulate n steps' button, displays a dialog to accept some text and simulates that many number of steps
     * @param event The action event
     */
    private void simulateSomeSteps(ActionEvent event) {
        showRunningSimulationWarningIfNeccecary();
        /**
         * Reference: The dialog usage from Oracle Docs, 2015
         * https://docs.oracle.com/javase/8/javafx/api/javafx/scene/control/Dialog.html
         * Accessed 25 Mar 2022
         */
        TextInputDialog dialog = new TextInputDialog("0");
        dialog.setHeaderText("Simulate n steps");
        dialog.setContentText("How many steps to simulate?");
        dialog.setTitle("Simulate n steps");
        
        dialog.showAndWait().ifPresent(response -> {
            Integer numOfSteps = Integer.parseInt(response);
            if (numOfSteps == null || numOfSteps <= 0) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setContentText("Please enter a positive integer");
                alert.showAndWait();
            } else {
                /**
                 * Reference: Background threads for auxillary tasks and Platform.runLater for main tasks
                 * http://tutorials.jenkov.com/javafx/concurrency.html, by Jakob Jenkov on 30 Mar 2020
                 * Accessed 25 Feb 2022
                 */
                taskThread = new Thread(() -> simulator.simulate(numOfSteps));
                taskThread.start();
            }
        });
    }

    /**
     * Action for 'Run long simulation' button, runs a long simulation (4000 steps)
     * @param event The action event
     */
    private void runLongSimulation(ActionEvent event) {
        showRunningSimulationWarningIfNeccecary();
        /**
         * Reference: Background threads for auxillary tasks and Platform.runLater for main tasks
         * http://tutorials.jenkov.com/javafx/concurrency.html, by Jakob Jenkov on 30 Mar 2020
         * Accessed 25 Feb 2022
         */
        //Run on background thread to allow UI to still be responsive
        taskThread = new Thread(() -> simulator.runLongSimulation());
        taskThread.start();
    }
    
    /**
     * Action for 'Move camera to home' button, positions the camera to home
     * @param event The action event
     */
    private void moveCameraToHome(ActionEvent event) {
        fieldView.moveCameraToHome();
    }

    /**
     * Action for 'Reset simulation' button, resets the simulation
     * @param event The action event
     */
    private void createNewSimulation(ActionEvent event) {
        showRunningSimulationWarningIfNeccecary();
        simulator.reset();
    }
    
    /**
     * Action for 'Change dimensions' button, displays a dialog to change the dimensions and resets the simulation to the new dimensions
     * @param event The action event
     */
    private void changeDimensions(ActionEvent event) {
        showRunningSimulationWarningIfNeccecary();
        
        TextInputDialog dialog = new TextInputDialog("");
        dialog.setHeaderText("Change dimensions of the simulation");
        dialog.setContentText("Performing this action will reset the current simulation");
        dialog.setTitle("Change dimensions");
        
        dialog.showAndWait().ifPresent(response -> {
            String[] components = response.split(",");
            
            if (components.length != 3) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setContentText("Please enter dimensions in the form X,Y,Z e.g. 120,10,150");
                alert.showAndWait();
                return;
            }
            
            Integer length = Integer.parseInt(components[0]);
            Integer height = Integer.parseInt(components[1]);
            Integer width = Integer.parseInt(components[2]);
            
            
            if (length == null || length < 60 || width == null || width < 60 || height == null || height < 10) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setContentText("Please enter a integer for each of the dimensions, in the form X,Y,Z e.g. 120,10,150 \n The minimum X is 60, minimum Y is 10 and minimum Z is 60");
                alert.showAndWait();
            } else {
                simulator = new Simulator(this, length, height, width);
            }
        });
    }
    
    /**
     * Update the field view
     */
    public void updateFieldView() {
        /**
         * Reference: Background threads for auxillary tasks and Platform.runLater for main tasks
         * http://tutorials.jenkov.com/javafx/concurrency.html, by Jakob Jenkov on 30 Mar 2020
         * Accessed 25 Feb 2022
         */
        Platform.runLater(() -> {
            fieldView.update();
        });
    }

    /**
     * Reset the field view to the currently simulated field.
     */
    public void resetFieldView() {
        /**
         * Reference: Background threads for auxillary tasks and Platform.runLater for main tasks
         * http://tutorials.jenkov.com/javafx/concurrency.html, by Jakob Jenkov on 30 Mar 2020
         * Accessed 25 Feb 2022
         */
        Platform.runLater(() -> {
            fieldView.reset(simulator.getField());
        });
    }

    private void showRunningSimulationWarningIfNeccecary() {
        /**
         * Reference: Checking if a thread is still running
         * From stackoverflow.com, answered by Eddie on 31 Mar 2009
         * https://stackoverflow.com/questions/702415/how-to-know-if-other-threads-have-finished
         * Accessed 1 Mar 2022
         */
        if (taskThread != null && taskThread.isAlive()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setContentText("A simulation is currently running. Please wait for it to end.");
            alert.showAndWait();
            return;
        }
    }
}
