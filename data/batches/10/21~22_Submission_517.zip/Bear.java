import java.util.List;
import java.util.Random;
import java.util.HashMap;
import java.util.function.Consumer;

/**
 * A representation of a Bear. Bears are LandAnimals that hibernate during the winter, and eat squirrels and fish.
 *  
 * @version 0
 */
public class Bear extends LandAnimal
{   
    protected static final String HIBERNATION_STATUS_ID = "HIBERNATION";
    
    /**
     * Create a new bear at location in layer.
     * 
     * @param layer The layer to occupy.
     * @param location The location within the layer.
     * @param randomAge Whether the newly created bear should have a random age or an age of 0
     */
    public Bear(boolean randomAge, AnimalLayer layer, Location location)
    {
        super(randomAge, layer, location);
    }
    
    /**
     * Set the properties of the bear
     */
    protected void setupProperties() {
        setBreedingAge(1);
        setMaxAgeMean(450);
        setMaxAgeSD(100);
        setMaxHunger(20);
        setGestationPeriodLength(0.5);
        setVisionRadius(2);
        setMoveRadius(2);
        setMeetCooldown(1);
        addFood(Squirrel.class, 0.5, -10);
        addFood(Deer.class, 0.5, -20);
        addFood(Fish.class, 1, -5);
    }
    
    public double eat(double amount) {
        if (getStatus().equals(HIBERNATION_STATUS_ID) && rand.nextDouble() > 0.2 || rand.nextDouble() > 0.6) {
            moveToRandomAdjacentLocation();
            return 0;
        } else{
            return super.eat(amount);
        }
    }
    
    protected void incrementOnStep() {
        if (getStatus().equals(HIBERNATION_STATUS_ID)) {
            incrementAge();
        } else {
            super.incrementOnStep();
        }
    }
    
    /**
     * Set how the status of the bear changes on each step
     */
    protected void tryChangeStatus() {
        if (field.isWinter()) {
            setStatus(HIBERNATION_STATUS_ID);
            return;
        }
        
        if (isHungry() || (getStatus().equals(FOOD_HUNTING_STATUS_ID) && rand.nextDouble() < 0.2)) {
            setStatus(FOOD_HUNTING_STATUS_ID);
            return;
        }
        
        if (field.isDark()) {
            setStatus(ASLEEP_STATUS_ID);
            return;
        }
        
        if (rand.nextDouble() < 0.3) {
            setStatus(FOOD_HUNTING_STATUS_ID);
            return;
        }
        
        if (canMeet() && rand.nextDouble() < 0.7 || getStatus().equals(MATE_HUNTING_STATUS_ID)) {
            setStatus(MATE_HUNTING_STATUS_ID);
            return;
        }
        
        setStatus(IDLE_STATUS_ID);
    }
    
    /**
     * Get a new bear of age 0 
     * @param layer The layer of the bear
     * @param location The location of the bear
     * @return A new baby deer
     */
    protected LandAnimal newBabyAnimal(AnimalLayer layer, Location location) {
        return new Bear(false, layer, location);
    }
    
     /**
     * Override initialiseStatuses to add the HIBERNATION status.
     */
    protected void intialiseStatuses(HashMap<String, Consumer<LandAnimal>> statuses) {
        super.intialiseStatuses(statuses);
        
        statuses.put(HIBERNATION_STATUS_ID, (animal) -> {
        });
    }
    
}
