import java.util.Random;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

/**
 * A FieldLayer responsible for the creation of a 3D terrain of a hilly rocky area with a water river. Simulation of the terrain involves the river freezing and flooding.
 * 
 * @version 0
 */
public class TerrainLayer extends FieldLayer
{
    //Flooding-related fields 
    private static double FLOOD_GROWTH_LENGTH = 3d/16d; //The amount of time for which the flood should grow
    private static double FLOOD_STABLE_LENGTH = 5d/16d; //The amount of time for which the flood at max height should stay
    private static double FLOOD_PROBABILITY = 0.002;
    private double floodGrowthLengthRemaining;
    private double floodStableLengthRemaining;
    
    /**
     * Create a TerrainLayer to be a part of the field.
     * @param field the field in which the layer conforms to
     */
    public TerrainLayer(Field field)
    {
        super(field);
        floodGrowthLengthRemaining = 0;
        floodStableLengthRemaining = 0;
    }
    
    /**
     * Simulate one step of the simulation, by initiating a flood where neccecary, maining a flood, and ending a flood. Also tells all managed terrain objects to act.
     */
    public void simulateOneStep() {
        if (floodGrowthLengthRemaining > 0) {
            floodGrowthLengthRemaining -= 1d/16d;
            if (floodGrowthLengthRemaining <= 0) {
                floodGrowthLengthRemaining = 0;
                floodStableLengthRemaining = FLOOD_STABLE_LENGTH;
            }
        } else if (floodStableLengthRemaining > 0) {
            floodStableLengthRemaining -= 1d/16d;
        } else if (!getField().isWinter() && rand.nextDouble() < FLOOD_PROBABILITY) {
            floodGrowthLengthRemaining = FLOOD_GROWTH_LENGTH;
        }
        
        List<Terrain> newTerrain = new ArrayList<>(); 
        for(Iterator<LayerObject> it = managedObjects.iterator(); it.hasNext();) {
            Terrain terrain = (Terrain) it.next();
            terrain.act(newTerrain);
            if(terrain.getLocation() == null) {
                it.remove();
            }
        }
        managedObjects.addAll(newTerrain);
    }
    
    /**
     * Determine whether the river should be frozen
     * @return true if the river should be frozen.
     */
    protected boolean shouldFreezeRiver() {
        return getField().isWinter();
    }
    
    /**
     * Determine whether the river should be flooded
     * @return true if the river should be flooded.
     */
    protected boolean shouldFloodRiver() {
        return floodGrowthLengthRemaining > 0;
    }
    
    /**
     * Determine whether the river flood should subside
     * @return true if the river should unflood.
     */
    protected boolean shouldUnfloodRiver() {
        return floodStableLengthRemaining <= 0;
    }
     
    /**
     * Create a hilly Rock terrain with a randomly generated Water river within
     */
    public void populateRandomly() {
        int length = getField().getLength();
        int width = getField().getWidth();
        int height = getField().getHeight();
        
        //Generate river
        boolean isRiverHorizontal = rand.nextBoolean();
        int riverHeight = 2 + rand.nextInt(3);
        int minRiverWidth = 3;
        Location riverStartPoint;
        
        int randomLength = length/5 + rand.nextInt(length - 2*length/5);
        int randomWidth = width/5 + rand.nextInt(width - 2*width/5);
        
        if (isRiverHorizontal) {
            riverStartPoint = new Location(0, 0, randomWidth);
        } else {
            riverStartPoint = new Location(randomLength, 0, 0);
        }
        
        HashSet<Location> riverCells = generateRiverCells(riverStartPoint, isRiverHorizontal, minRiverWidth, riverHeight, 15, 0, new HashSet<Location>());
        
        
        for (int x = 0; x < length; x++) {
            for (int y = 0; y <= riverHeight; y++) {
                for (int z = 0; z < width; z++) {
                    Location location = new Location(x, y, z);
                    if (riverCells.contains(location)) {
                        Water water = new Water(this, location, y == riverHeight && shouldFreezeRiver());
                        managedObjects.add(water);
                    } else {
                        Rock rock = new Rock(this, location);
                        //Rock not a managed object
                    }
                }
            }
        }
        
        //Generate hills
        HashSet<Location> hillCells = new HashSet<>();
        
        for (int x = 0; x < length; x += length/10) {
            for (int z = 0; z < width; z += width/10) {
                Location startPoint = new Location(x, riverHeight, z);
                
                if ((isRiverHorizontal && Math.abs(randomWidth - z) > 40)
                    || (!isRiverHorizontal && Math.abs(randomLength - x) > 40) && rand.nextDouble() > 0.5) {
                        hillCells.addAll(generateHillCells(startPoint, rand.nextInt(40), height - 2, new HashSet<Location>()));
                }
            }
        }
        
        
        for (int x = 0; x < length; x++) {
            for (int y = riverHeight + 1; y < height; y++) {
                for (int z = 0; z < width; z++) {
                    Location location = new Location(x, y, z);
                    if (hillCells.contains(location)) {
                        Rock rock = new Rock(this, location);
                    }
                }
            }
        }
    }
    
    /**
     * Create a set of locations in which rocks should be placed to form one hill
     * @param startPoint The centre point of the base of the hill
     * @param radius The radius of the base of the hill
     * @param maxY The y-coordinate of the peak of the hill
     * @param currentCells A set of current cells used internally by the method. To call this method, supply an empty set.
     * @return A set of locations to be included in the hill
     */
    private HashSet<Location> generateHillCells(Location startPoint, double radius, int maxY, HashSet<Location> currentCells) {
        int minY = startPoint.getY();
        
        if (minY == maxY || startPoint.isOutsideBounds(getField().getLength(), getField().getHeight(), getField().getWidth())) {
            return currentCells;
        }
        
        HashSet<Location> points = new HashSet<Location>();
        for (int r = 0; r <= radius; r++) {
            points.addAll(Location.boxOfPointsAround(startPoint, r));
            points.add(startPoint);
        }
        
        Iterator<Location> it = points.iterator();
        while (it.hasNext()) {
            Location point = it.next();
            if (startPoint.distanceTo(point) > radius) {
                it.remove();
            }
        }
        currentCells.addAll(points);
        startPoint = Location.add(startPoint, new Location(0, 1, 0));
        
        return generateHillCells(startPoint, radius*0.6, maxY, currentCells);
    }
    
    /**
     * Create a set of locations in which water should be placed to form one river.
     * @param startPoint The point at which the river should start. Preferably use a point at the edge of the field.
     * @param isHorizontal Set true for the river should move in the +/- X direction, false for the +/- Z direction.
     * @param riverWidth The width of the river.
     * @param riverHeight The height of the river
     * @param stepLength A value to determine how often (as a distance) small direction variations are made in the river.
     * @param offset Used internally to make smooth changes to the river direction. Set to 0 when calling this method yourself.
     * @param currentCells A set of current cells used internally by the method. To call this method, supply an empty set.
     * @return A set of locations to be included in the river
     */
    private HashSet<Location> generateRiverCells(Location startPoint, boolean isHorizontal, int riverWidth, int riverHeight, int stepLength, int offset, HashSet<Location> currentCells) {
        if (startPoint.isOutsideBounds(getField().getLength(), getField().getHeight(), getField().getWidth())) {
            return currentCells;
        }
        Location nextPoint;
        int directionChange = offset + rand.nextInt(stepLength/2) * (rand.nextBoolean() ? -1 : 1); //Make some variations to the direction of the river
        
        if (isHorizontal) {
            nextPoint = Location.add(startPoint, new Location(stepLength, 0, directionChange));
                 
            for (int i=startPoint.getX(); i <= nextPoint.getX(); i++) {
                 double completion = ((double) (i-startPoint.getX()))/((double) (nextPoint.getX() - startPoint.getX()));
                 if (completion < 0) { completion *= -1; }

                 double nextZ = completion*(nextPoint.getZ() - startPoint.getZ()) + startPoint.getZ();
                 Location centrePoint = new Location(i, 0, (int) nextZ);
                 
                 for (int y = 0; y <= riverHeight; y++) {
                      currentCells.addAll(Location.lineOfPoints(
                          Location.add(centrePoint, new Location(0, y, 0)), 
                          riverWidth + y,
                        2));
                 }
                 
                
            }
        } else {
            nextPoint = Location.add(startPoint, new Location(directionChange, 0, stepLength));
             
            for (int i=startPoint.getZ(); i <= nextPoint.getZ(); i++) {
                 double completion = ((double) (i-startPoint.getZ()))/((double) (nextPoint.getZ() - startPoint.getZ()));
                 if (completion < 0) { completion *= -1; }
                
                 double nextX = completion*(nextPoint.getX() - startPoint.getX()) + startPoint.getX();
                 Location centrePoint = new Location((int) nextX, 0, i) ;
                 
                 for (int y = 0; y <= riverHeight; y++) {
                      currentCells.addAll(Location.lineOfPoints(
                          Location.add(centrePoint, new Location(0, y, 0)), 
                          riverWidth + y,
                        0));
                 }
            }
        }
        
        return generateRiverCells(nextPoint, isHorizontal, riverWidth, riverHeight, stepLength, directionChange, currentCells);
    }

}
