import javafx.geometry.Insets;
import javafx.geometry.Point3D;
import javafx.geometry.Pos;
import javafx.scene.AmbientLight;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Shape3D;
import javafx.scene.shape.Sphere;
import java.util.*;
import javafx.scene.control.Alert.AlertType;
import javafx.application.Platform;
/**
 * A 3D representation of a 3D Field
 * 
 * @version 0
 */
public class FieldView extends Navigation3DView
{
    private Field field;
    private Group content;
    private Label statisticsLabel;
    private static int CUBE_EDGE = 10;
    private int length, height, width;
    
    private HashMap<LayerObject, LayerObject3D> currentlyDisplayedObjects; //Record of currently displayed object
    
    /**
     * Create a new FieldView
     * @param parent The scene to add the view to, used for user input events
     * @param field The field to display
     */
    public FieldView(Scene parent, Field field) {
        super(parent);
        statisticsLabel = new Label();
        statisticsLabel.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));
        statisticsLabel.setTextFill(Color.WHITE);
        getChildren().add(statisticsLabel);
        /**
         * Reference: Alignment of a node within a StackPane
         * From stackoverflow.com, answered by jewelsea on 20 Feb 2013
         * https://stackoverflow.com/questions/14983706/javafx-stackpane-x-y-coordinates
         * Accessed 28 Feb 2022
         */
        setAlignment(statisticsLabel, Pos.BOTTOM_CENTER);
        reset(field);
    }
    
    /**
     * Reset the field view to what is defined by a Field object
     * @param newField The field to consider
     */
    public void reset(Field newField) {
        this.field = newField;
        currentlyDisplayedObjects = new HashMap<>();
        
        length = field.getLength();
        height = field.getHeight();
        width = field.getWidth();
        
        initialiseContent();
        
        setContent(content);
        moveCameraToHome();
    }
    
    /**
     * Intiailise the content of the view with the field's data
     * NOTE: this contains an optimisation in which any nodes below a 'Rock' object are ignored, so any implementations of caves etc. may be affected.
     */
    private void initialiseContent() {
        content = new Group();
        
        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                for (int y = height - 1; y >= 0; y--) {
                    
                    List<LayerObject> contents = new ArrayList<>();
                    for (FieldLayer layer: field.getLayers()) {
                        LayerObject obj = layer.getObjectAt(x, y, z);
                        if (obj != null) {
                            contents.add(obj);
                        }
                    }
                    Collections.reverse(contents);
                    
                    boolean containedRock = false;
                    for (LayerObject obj : contents) {
                        addObjectToContent(obj);
                    
                        if (obj instanceof Rock) {
                            containedRock = true;
                        }  
                    }
                    //If this block had a rock and is not at the edge of the field, move to the next (x, z) pair
                    if (containedRock && x != 0 && z != 0 && x != length - 1 && z != width - 1 ) { break; }
                }  
            }
        }
        
        updateStatisticsLabel();
        AmbientLight light = new AmbientLight();
        content.getChildren().addAll(light);
    }
    
    /**
     * Update the view to conform to the current state of the field.
     */
    public void update() {
        HashSet<LayerObject> latestObjects = new HashSet<>();
        for (FieldLayer layer : field.getLayers()) {
            latestObjects.addAll(layer.getManagedObjects());
        }
        latestObjects.removeAll(currentlyDisplayedObjects.keySet());
        
        for (LayerObject newObject : latestObjects) {
            addObjectToContent(newObject);
        }
        
        Iterator<Map.Entry<LayerObject, LayerObject3D>> it = currentlyDisplayedObjects.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<LayerObject, LayerObject3D> entry = it.next();
            boolean isRemoved = !entry.getValue().update();
            if (isRemoved) {
                removeObjectFromContent(entry.getKey());
                it.remove();
            }
        }
        
        updateStatisticsLabel();
    }
    
    /**
     * Update the statistics label to show the step number and animal statistics
     */
    private void updateStatisticsLabel() {
        HashMap<Class, Integer> counts = new HashMap<>();
        for (LayerObject object : currentlyDisplayedObjects.keySet()) {
            if (object instanceof Animal && ((Animal) object).isAlive()) {
                Class animalClass = object.getClass();
                if (counts.get(animalClass) == null) {
                    counts.put(animalClass, 1);
                } else {
                    counts.put(animalClass, counts.get(animalClass) + 1);
                }
            }
        }
        String displayString = "Step " + field.getStepNumber();
        for (Class c : counts.keySet()) {
            displayString += ", " + c.getName() + ": " + counts.get(c);
        }
        
        statisticsLabel.setText(displayString);
    }
    
    /**
     * Add an object to the content's children
     * @param object The object to add, as a LayerObject
     */
    private void addObjectToContent(LayerObject object) {
        LayerObject3D objectModel = new LayerObject3D(object);
        content.getChildren().addAll(objectModel.model);
        currentlyDisplayedObjects.put(object, objectModel);
    }
    
    /**
     * Remove an object from the content's children
     * @param object The object to remove, as a LayerObject
     */
    private void removeObjectFromContent(LayerObject object) {
        LayerObject3D objectModel = currentlyDisplayedObjects.get(object);
        content.getChildren().remove(objectModel.model);
    }

    /**
     * Set the position of the camera to 'home'
     */
    public void moveCameraToHome() {
        setCameraPosition(new Point3D(CUBE_EDGE*length/2, -2*CUBE_EDGE*height, -width*3), 0, 0);
    }
    
    /**
     * LayerObject3D is a 3D representation of a LayerObject, for use in a FieldView.
     */
    private class LayerObject3D {
        private LayerObject representedObject;
        private Shape3D model;
        private double yOffset; //Used for some models to translate up or down.
        
        /**
         * Create a LayerObject3D from a LayerObject
         * @param object The object to create a 3D representation
         */
        public LayerObject3D(LayerObject object) {
            this.representedObject = object;
            determineObjectModel();
            if (object.getLocation() != null) {
                setLocation(object.getLocation());
            }
        }
        
        public boolean update() {
            if (representedObject.getLocation() == null) { 
                return false;
            } else {
                if (representedObject instanceof Animal) {
                    Animal animal = (Animal) representedObject;
                    setLocation(representedObject.getLocation());
                    if (!animal.isAlive()) {
                        model.setMaterial(new PhongMaterial(Color.BLACK));
                    }
                } else if (representedObject instanceof Water) {
                    if (((Water) representedObject).isFrozen()) {
                        model.setMaterial(new PhongMaterial(Color.WHITE));
                    } else {
                        model.setMaterial(new PhongMaterial(Color.color(0, 0.1, 0.9, 0.2)));
                    }
                }
                return true;
            }
        }
        
        /**
         * Set the 3D shape of the LayerObject3D based on the type of LayerObject used.
         */
        private void determineObjectModel() {
            model = new Box();
            if (representedObject instanceof Rock) {
                model = new Box(CUBE_EDGE, CUBE_EDGE, CUBE_EDGE);
                model.setMaterial(new PhongMaterial(Color.GREY));
            } else if (representedObject instanceof Water) {
                Water water = (Water) representedObject;
                if (water.isFrozen()) {
                    model = new Box(CUBE_EDGE, CUBE_EDGE, CUBE_EDGE);
                    model.setMaterial(new PhongMaterial(Color.WHITE));
                } else {
                    model = new Box(CUBE_EDGE, CUBE_EDGE, CUBE_EDGE);
                    model.setMaterial(new PhongMaterial(Color.color(0, 0.1, 0.9, 0.2)));
                }
            } else if (representedObject instanceof Grass) {
                model = new Box(CUBE_EDGE, CUBE_EDGE/10, CUBE_EDGE);
                yOffset = 0.45;
                model.setMaterial(new PhongMaterial(Color.GREEN));
            } else if (representedObject instanceof Kelp) {
                model = new Sphere(CUBE_EDGE/3);
                model.setMaterial(new PhongMaterial(Color.CYAN));
            } else if (representedObject instanceof Tree) {
                model = new Cylinder(CUBE_EDGE/3, CUBE_EDGE);
                model.setMaterial(new PhongMaterial(Color.BROWN));
            } else if (representedObject instanceof BerryBush) {
                model = new Box(CUBE_EDGE, CUBE_EDGE, CUBE_EDGE);
                model.setMaterial(new PhongMaterial(Color.color(0, 0.9, 0.1, 0.3)));
            } else if (representedObject instanceof Wolf) {
                model = new Sphere(CUBE_EDGE/2);
                model.setMaterial(new PhongMaterial(Color.WHITE));
            } else if (representedObject instanceof Bear) {
                model = new Sphere(CUBE_EDGE/2);
                model.setMaterial(new PhongMaterial(Color.RED));
            } else if (representedObject instanceof Squirrel) {
                model = new Sphere(CUBE_EDGE/2);
                model.setMaterial(new PhongMaterial(Color.PURPLE));
            } else if (representedObject instanceof Deer) {
                model = new Sphere(CUBE_EDGE/2);
                model.setMaterial(new PhongMaterial(Color.DARKOLIVEGREEN));
            } else if (representedObject instanceof Fish) {
                model = new Sphere(CUBE_EDGE/2);
                model.setMaterial(new PhongMaterial(Color.YELLOW));
            }
            
            /**
             * Reference: Event handlers on models
             * From stackoverflow.com, answered by jdub1581 on 4 Mar 2015
             * https://stackoverflow.com/questions/28863312/javafx-3d-graphics-mouse-click-position-on-3d-object
             * Accessed 28 Feb 2022
             */
            model.setOnMouseClicked(e -> {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Inspector");
                alert.setContentText(representedObject.toString());
                alert.setHeaderText(representedObject.getClass().getName());
                alert.showAndWait();
            });
        }
        
        /**
         * Set the location of the model to a new location within the field, using any yOffset required
         * @param location The location to set to.
         */
        private void setLocation(Location location) {
            model.setTranslateX(location.getX() * CUBE_EDGE);
            model.setTranslateY(-location.getY() * CUBE_EDGE + yOffset * CUBE_EDGE);
            model.setTranslateZ(location.getZ() * CUBE_EDGE);
        }
        
         /**
         * Get the shape of the model
         * @return The shape of the model
         */
        public Shape3D getShape() {
            return model;
        }
    }
}
