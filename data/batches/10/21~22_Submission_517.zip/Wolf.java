import java.util.List;
import java.util.Random;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A representation of wolves. Wolves are LandAnimals which eat squirrels and deer, and travel in packs.
 *  
 * @version 0
 */
public class Wolf extends LandAnimal 
{
    //The wolf pack
    private WolfPack pack;
    
    /**
     * Create a new wolf at location in layer.
     * @param pack The pack that the wolf resides in.
     * @param layer The layer to occupy.
     * @param location The location within the layer.
     * @param randomAge Whether the newly created wolf should have a random age or an age of 0
     */
    public Wolf(WolfPack pack, boolean randomAge, AnimalLayer layer, Location location)
    {
        super(randomAge, layer, location);
        this.pack = pack;
        pack.add(this);
    }
    
    /**
     * Set the properties of the wolf
     */
    protected void setupProperties() {
        setBreedingAge(5);
        setMaxAgeMean(200.5);
        setMaxAgeSD(34.8);
        setMaxHunger(30);
        setGestationPeriodLength(0.2);
        setMaxBirths(2);
        setVisionRadius(5);
        setMoveRadius(4);
        setMeetCooldown(10);
        addFood(Squirrel.class, 0.5, -20);
        addFood(Deer.class, 0.2, -30);
        addFood(Bear.class, 0.2, -40);
    }

    /**
     * Set how the status of the wolf changes on each step
     */
    protected void tryChangeStatus() {
        if (field.isDark()) {
            setStatus(ASLEEP_STATUS_ID);
            return;
        }
        
        if (isHungry()) {
            setStatus(FOOD_HUNTING_STATUS_ID);
            return;
        }
        
        if (canMeet() && rand.nextDouble() < 0.3 || getStatus() == MATE_HUNTING_STATUS_ID) {
            setStatus(MATE_HUNTING_STATUS_ID);
            return;
        }
        
        setStatus(IDLE_STATUS_ID);
    }

    /**
     * Create a new wolf in this pack of age 0
     * @param layer The layer of the pack
     * @param location The location of the wolf in the layer
     */
    protected LandAnimal newBabyAnimal(AnimalLayer layer, Location location) {
        Wolf newWolf = new Wolf(pack, false, layer, location);
        return newWolf;
    }
    
    /**
     * Override setDead to remove this wolf from the pack if the animal dies.
     */
    protected void setDead(String deathString) {
        super.setDead(deathString);
        if (pack != null) {
            pack.remove(this);
            pack = null;
        }
    }
    
    /**
     * Override moveToRandomAdjacentLocation to move in the direction of the pack leader, or if the wolf is the pack leader (or some other conditions), move randomly.
     */
    protected void moveToRandomAdjacentLocation() {
        if (pack != null) {
            if (this.equals(pack.getLeader())) {
                setMoveRadius(7);
            }
            if (this.equals(pack.getLeader()) || pack.getLeader() == null || rand.nextBoolean()) {
                super.moveToRandomAdjacentLocation();
            } else if (pack.getLeader() != null) {
                moveWithRespectTo(pack.getLeader().getLocation(), true);
            }
        } else {
            super.moveToRandomAdjacentLocation();
        }
    }
    
}
