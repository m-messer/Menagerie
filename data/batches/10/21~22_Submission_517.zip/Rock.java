import java.util.List;

/**
 * Represents 'Rock' as a terrain material
 * 
 * @version 0
 */
public class Rock extends Terrain
{
    /**
     * Create a new Rock terrain object, at a certain location within the Terrain layer.
     * @param layer The layer to add the Rock to
     * @param location The location within the layer to add the Rock
     */   
    public Rock(TerrainLayer layer, Location location) {
        super(layer, location);
    }
    
    /**
     * Make the Rock act at every terrain layer
     * The rock is not a managed object and it does nothing at every simulation step.
     */
    public void act(List<Terrain> newTerrain) {
        
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return "Rock";
    }
}
