import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

/**
 * AnimalLayer represents a layer of the simulation which manages the creation and simulation of animals
 * 
 * @version 0
 */
public class AnimalLayer extends FieldLayer
{
    private static final double DEER_CREATION_PROBABILITY = 0.05;
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.8;
    private static final double WOLF_PACK_CREATION_PROBABILITY = 0.1;
    private static final int WOLF_PACK_RADIUS = 2;
    private static final double BEAR_CREATION_PROBABILITY = 0.015;
    private static final double FISH_CREATION_PROBABILITY = 0.09;
    
    /**
     * Create an AnimalLayer to be a part of the field.
     * @param field the field in which the layer conforms to
     */
    public AnimalLayer(Field field)
    {
        super(field);
    }
    
    /**
     * Populates the layer with animals
     */
    public void populateRandomly() {
        int length = getField().getLength();
        int width = getField().getWidth();
        int height = getField().getHeight();
        PlantLayer plantLayer = getField().getPlantLayer();
        TerrainLayer terrainLayer = getField().getTerrainLayer();
        
        
        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                for (int y = height - 1; y >= 0; y--) {
                    Location location = new Location(x, y, z);
                    
                    if (plantLayer.getObjectAt(location) instanceof Grass) { 
                        if (rand.nextDouble() < DEER_CREATION_PROBABILITY) {
                            Deer deer = new Deer(true, this, location);
                            managedObjects.add(deer);
                            break;
                        } else if (rand.nextDouble() < BEAR_CREATION_PROBABILITY) {
                            Bear bear = new Bear(true, this, location);
                            managedObjects.add(bear);
                            break;
                        }
                    } else if (plantLayer.getObjectAt(location) instanceof Tree) {
                        if (rand.nextDouble() < SQUIRREL_CREATION_PROBABILITY) {
                            Animal squirrel = new Squirrel(true, this, location);
                            managedObjects.add(squirrel);
                            break;
                        }
                    } else if (terrainLayer.getObjectAt(location) instanceof Water) {
                        Water water = (Water) terrainLayer.getObjectAt(location);
                        if (!water.isFrozen() && rand.nextDouble() < FISH_CREATION_PROBABILITY) {
                            Fish fish = new Fish(this, location);
                            managedObjects.add(fish);
                        }
                    }
                }  
            }
        }
        
         //Wolf packs
        for (int x = 0; x < length; x += length/15) {
            for (int z = 0; z < width; z += width/15) {
                Location location = new Location(x, height-1, z);
                
                if (rand.nextDouble() <= WOLF_PACK_CREATION_PROBABILITY) {
                    List<Location> points = Location.boxOfPointsAround(location, WOLF_PACK_RADIUS);
                    List<Location> pointsAtGround = new ArrayList<Location>();
                    
                    for (Location point : points) {
                        Location pointToTest = point;
                        boolean success = false;
                        while (pointToTest.getY() >= 0 && !success) {
                            LayerObject obj = plantLayer.getObjectAt(pointToTest);
                            if (obj instanceof Grass) {
                                success = true;
                            } else {
                                pointToTest = new Location(pointToTest.getX(), pointToTest.getY() - 1, pointToTest.getZ());
                            }
                        }
                        if (success) {
                            pointsAtGround.add(pointToTest);
                        }
                    }
                    
                    if (pointsAtGround.size() > 0) {
                        WolfPack pack = new WolfPack();
                        for (Location loc : pointsAtGround) {
                            Wolf wolf = new Wolf(pack, true, this, loc);
                            managedObjects.add(wolf);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Tell the layer to carry out one step of the simulation
     */
    public void simulateOneStep() {
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<LayerObject> it = managedObjects.iterator(); it.hasNext(); ) {
            Animal animal = (Animal) it.next();
            animal.act(newAnimals);
            if(animal.getIsFinished()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        managedObjects.addAll(newAnimals);
    }
    
    /**
     * Determine whether the simulation should contine based on this layer
     * @return Whether any animals are still being simulated
     */
    public boolean isViable() {
        return managedObjects.size() > 0;
    }
}
