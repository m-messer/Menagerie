import javafx.scene.paint.Color;
import java.util.List;

/**
 * Represents an object which can be held in a FieldLayer.
 * 
 * @version 0
 */
public abstract class LayerObject
{
    protected FieldLayer layer;
    protected Field field;
    protected Location location;
    
    /**
     * Create a new LayerObject within a FieldLayer at a certain location
     * @param layer The layer to add this object to
     * @param location The location within the layer to add the object to
     */
    public LayerObject(FieldLayer layer, Location location) {
        this.layer = layer;
        this.field = layer.getField();
        this.location = location;
        setLocation(location);
    }
    
    /**
     * Place the object at the new location in it's layer.
     * @param newLocation The objects's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            layer.clear(location);
        }
        location = newLocation;
        layer.place(this, newLocation);
    }
    
    /**
     * Get the location of the object in its layer
     * @return The location of the object.
     */
    protected Location getLocation() {
        return location;
    }
}
