 import java.util.List;
import javafx.scene.paint.Color;
import java.util.LinkedList;
import java.util.ArrayList;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends LayerObject implements ConsumableFood
{
    // Whether the animal is alive or not.
    private boolean alive;
    private double remains;
    private boolean isFinished;
    
    //Attributes for moving location
    private int visionRadius = 3;
    private int jumpHeight = 1;
    private int moveRadius = 1;
    
    protected String deathString = null;
    
    /**
     * Create a new animal at location in layer.
     * 
     * @param layer The layer currently occupied.
     * @param location The location within the layer.
     */
    public Animal(AnimalLayer layer, Location location)
    {
        super(layer, location);
        alive = true;
        remains = 1;
        isFinished = false;
    }
    
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Determine if a location can be moved to by this animal
     * @param loc The location to test
     * @return Whether the location is free
     */
    protected abstract boolean isFree(Location loc);
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is not removed from the field - it is dead and starts to decay.
     */
    protected void setDead(String deathString)
    {
        alive = false;
        this.deathString = deathString;
    }
    
    /**
     * Indicate that this animal is finished (fully decayed)
     * It is removed from the layer.
     */
    public void setFinished() {
        isFinished = true;
        if(location != null) {
            layer.clear(location);
            location = null;
            layer = null;
        }
    }
    
    /**
     * Get whether the animal is finished
     * @return Whether the animal is finished
     */
    protected boolean getIsFinished() {
        return isFinished;
    }
    
    /**
     * Get the current remains of the animal
     * @return The current remains, a number between 0 and 1.
     */
    protected double getRemains() {
        return remains;    
    }
    
    /**
     * Try to remove the remains of the animal by a certain amount
     * @param The amount by which the remains is attemped to be removed
     * @return The actual amount by which the remains were removed.
     */
    protected double removeRemains(double amount) {
        if (remains > amount) {
            remains -= amount;
            return amount;
        } else {
            double removedRemains = remains;
            remains = 0;
            setFinished();
            return removedRemains;
        }
    }
    
    public double eat(double amount) {
        if (alive) {
            setDead("Eaten");
        }
        return removeRemains(amount);
    }
    
    //Getters and setters
    /**
     * Get the vision radius of the animal, how far it can see
     * @return The vision radius.
     */
    protected final int getVisionRadius() {
        return visionRadius;
    }
    
    /**
     * Get how high the animal can jump up or down
     * @return The jump height of the animal
     */
    protected final int getJumpHeight() {
        return jumpHeight;
    }
    
    /**
     * Get how far the animal can move in a single moveLocation call
     * @return The move radius.
     */
    protected final int getMoveRadius() {
        return moveRadius;
    }
    
    /**
     * Set the vision radius of the animal, how far it can see
     * Default value = 3
     * @param radius The vision radius.
     */
    protected final void setVisionRadius(int radius) {
        if (radius >= 0) {
            visionRadius = radius;
        }
    }
    
    /**
     * Set how high the animal can jump up or down
     * Default value = 1
     * @param height The jump height of the animal
     */
    protected final void setJumpHeight(int height) {
        if (height >= 1) {
            jumpHeight = height;
        }
    }
    
    /**
     * Set how far the animal can move in a single moveLocation call
     * Default value = 1
     * @param radius The move radius.
     */
    protected final void setMoveRadius(int radius) {
        if (radius >= 1) {
            moveRadius = radius;
        }
    }
    
    //Location methods
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if (isFree(newLocation)) {
            super.setLocation(newLocation);
        }
    }
    
    /**
     * Get locations adjacent to this animal
     */
    protected List<Location> getAdjacentLocations() {
        return layer.adjacentLocations(location, jumpHeight, moveRadius);
    }
    
    /**
     * Get a shuffled list of the free adjacent locations.
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */
    protected List<Location> getFreeAdjacentLocations()
    {
        List<Location> free = new LinkedList<>();
        List<Location> adjacent = getAdjacentLocations();
        
        for(Location next : adjacent) {
            if(isFree(next)) {
                free.add(next);
            }
        }
        return free;
    }

    /**
     * Try to find a free location that is adjacent to the
     * given location. If there is none, return null.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    protected Location freeAdjacentLocation()
    {
        // The available free ones.
        List<Location> free = getFreeAdjacentLocations();
        if(free.size() > 0) {
            return free.get(0);
        }
        else {
            return null;
        }
    }
    
    /**
     * Move towards or away from another location, based on the moveRadius
     * @param otherLocation The location to consider
     * @param towards Set true to move towards, false to move away from the location.
     */
    protected void moveWithRespectTo(Location otherLocation, boolean towards) {
        Location location = getLocation();
        
        if (otherLocation == null) {
            moveToRandomAdjacentLocation();
            return;
        }
        
        List<Location> possibleLocations = getFreeAdjacentLocations();
        if (possibleLocations.size() <= 0) {
            setDead("Overcrowding");
            return;
        }
        
        Location maxDistanceLoc = possibleLocations.get(0);
        double maxDistance = maxDistanceLoc.distanceTo(otherLocation);
        Location minDistanceLoc = possibleLocations.get(0);
        double minDistance = minDistanceLoc.distanceTo(otherLocation);
        
        for (Location loc: possibleLocations) {
            double distance = loc.distanceTo(otherLocation);
            if (distance > maxDistance) {
                maxDistance = distance;
                maxDistanceLoc = loc;
            } else if (distance < minDistance) {
                minDistance = distance;
                minDistanceLoc = loc;
            }
        }
       
        if (towards) {
            setLocation(minDistanceLoc);
        } else {
            setLocation(maxDistanceLoc);
        }
    }
    
    /**
     * Move to random adjacent location
     * If none exists, overcrowding occurs and the animal dies.
     */
    protected void moveToRandomAdjacentLocation() {
        Location newLocation = freeAdjacentLocation();
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            setDead("Overcrowding");
        }
    }
    
    /**
     * Get a list of locations in the animal's vision, dependent on the visionRadius
     * @return The list of locations in view
     */
    protected List<Location> visibleLocations() {
        return layer.adjacentLocations(location, jumpHeight, visionRadius);
    }
    
    /**
     * Get a list of the objects in this layer the animal's vision, dependent on the visionRadius
     * @return The list of objects
     */
    protected List<LayerObject> objectsInVision() {
        return layer.objectsInLocations(visibleLocations());
    }
    
    /**
     * Get a list of the objects in adjacent locations to this animal, dependent on the adjacentLocations, in all layers
     * @return The list of objects
     */
    protected List<LayerObject> objectsAdjacent() {
        List<Location> adjacentLocations = getAdjacentLocations();
        return objectsInLocations(adjacentLocations);
    }
    
    /**
     * Get a list of the objects stored in all layers at the list of locations
     * @param locations The locations to check
     * @return The list of objects
     */
    private List<LayerObject> objectsInLocations(List<Location> locations) {
        ArrayList<LayerObject> objects = new ArrayList<LayerObject>();
        for (FieldLayer layer : field.getLayers()) {
            objects.addAll(layer.objectsInLocations(locations));
        }
        return objects;
    }
    
    /**
     * Get the animal layer that this animal is currently in
     * @return The layer
     */
    protected AnimalLayer getLayer() {
        return (AnimalLayer) layer;
    }
   
}

