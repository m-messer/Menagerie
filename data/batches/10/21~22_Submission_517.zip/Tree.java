import java.util.List;

/**
 * A representation of a Tree object
 * 
 * @version 0
 */
public class Tree extends Plant
{   
    /**
     * Create a new Tree object in at a location in a layer
     * @param layer The layer to add the tree to
     * @param location The location in which to place the tree
     */
    public Tree(PlantLayer layer, Location location) {
        super(layer, location);
    }
    
    /**
     * Make the Tree act at every terrain layer
     * The tree is not a managed object and it does nothing at every simulation step.
     */
    public void act(List<Plant> newPlant) {
        
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return "Tree";
    }
}
