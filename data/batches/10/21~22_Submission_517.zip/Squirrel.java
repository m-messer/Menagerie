import java.util.List;
import java.util.HashMap;
import java.util.function.Consumer;

/**
 * Representation of a squirrel animal. Squirrels are LandAnimals which travel home to a near tree at every night. They eat grass.
 * 
 * @version 0
 */
public class Squirrel extends LandAnimal
{
    protected static final String TRAVEL_HOME_STATUS_ID = "TRAVEL_HOME";
    private Location nearestAvailableTree;

    /**
     * Create a new squirrel at location in layer.
     * 
     * @param layer The layer to occupy.
     * @param location The location within the layer.
     * @param randomAge Whether the newly created deer should have a random age or an age of 0
     */
    public Squirrel(boolean randomAge, AnimalLayer layer, Location location)
    {
        super(randomAge, layer, location);
        nearestAvailableTree = location;
    }
    
    /**
     * Set the properties of the squirrel
     */
    protected void setupProperties() {
        setBreedingAge(20);
        setMaxAgeMean(155);
        setMaxAgeSD(34);
        setMaxHunger(16);
        setJumpHeight(2);
        setMeetCooldown(0.5);
        setGestationPeriodLength(0.1);
        addFood(Grass.class, 1, -5);
        addFood(BerryBush.class, 0.25, -2);
    }
    
    /**
     * Get locations adjacent to the animal.
     * @return Adjacent locations which are on land.
     */
    @Override
    public List<Location> getAdjacentLocations() {
       List<Location> adjacent = layer.adjacentLocations(location, getJumpHeight(), getMoveRadius());
       List<Location> onLand = super.getAdjacentLocations();
       for (Location loc : adjacent) {
           if (field.getPlantLayer().getObjectAt(loc) instanceof Tree) {
               onLand.add(loc);
           }
       }
       return onLand;
    }
    
    /**
     * Override beforeChangeStatus to update the location of the nearest visible tree
     */
    protected void beforeChangeStatus() {
        //Update nearest available tree
        Location location = getLocation();
        FieldLayer plantLayer = getLayer().getField().getPlantLayer();
        
        if (plantLayer.getObjectAt(location) instanceof Tree) {
            nearestAvailableTree = location;
            return;
        }
        
        List<LayerObject> objects = plantLayer.objectsInLocations(visibleLocations());
        for (LayerObject object : objects) {
            if (object instanceof Tree) {
                nearestAvailableTree = object.getLocation();
                return;
            }
        }
        
        nearestAvailableTree = null; //Can not see a tree near.
        return;
    }
    
    /**
     * Change the status of the squirrel at each step
     */
     protected void tryChangeStatus() {

        if (field.isDark()) {
            if (location.equals(nearestAvailableTree) || (getStatus().equals(TRAVEL_HOME_STATUS_ID) && rand.nextDouble() > 0.6)) {
                setStatus(ASLEEP_STATUS_ID);
                return;
            } else {
                setStatus(TRAVEL_HOME_STATUS_ID);
                return;
            }
        }
        
         if (getHungerLevel() > 7 || rand.nextDouble() < 0.2 || (getStatus().equals(FOOD_HUNTING_STATUS_ID) && rand.nextDouble() < 0.4)) {
            setStatus(FOOD_HUNTING_STATUS_ID);
            return;
        }
       
        
        if (canMeet() && rand.nextDouble() < 0.8 || (getStatus().equals(MATE_HUNTING_STATUS_ID) && rand.nextDouble() < 0.4)) {
            setStatus(MATE_HUNTING_STATUS_ID);
            return;
        }

        setStatus(IDLE_STATUS_ID);
    }
    
    /**
     * Check if a location is free to move to
     * Overriden to allow squirrels to enter trees
     * @param loc The location to check
     * @return True if the location is empty and on land.
     */
    @Override
    protected boolean isFree(Location loc) {
        if (field.getPlantLayer().getObjectAt(loc) instanceof Tree) {
            return true;
        } else {
            return super.isFree(loc);
        }
        
    }
    
    /**
     * Check if a location will suffocate the animal
     * @param loc The location to check
     */
    protected boolean doesLocationSuffocate(Location loc) {
        if (field.getPlantLayer().getObjectAt(loc) instanceof Tree) {
            return false;
        } else {
            return super.doesLocationSuffocate(loc);
        }
    }
    
    /**
     * Get a new squirrel of age 0 
     * @param layer The layer of the deer
     * @param location The location of the deer
     * @return A new baby deer
     */
    protected LandAnimal newBabyAnimal(AnimalLayer layer, Location location) {
        return new Squirrel(false, layer, location);
    }
    
    /**
     * Override initialiseStatuses to add the TRAVEL_HOME status.
     */
    protected void intialiseStatuses(HashMap<String, Consumer<LandAnimal>> statuses) {
        super.intialiseStatuses(statuses);
        
        statuses.put(TRAVEL_HOME_STATUS_ID, (animal) -> {
            Squirrel squirrel = (Squirrel) animal;
            animal.moveWithRespectTo(squirrel.nearestAvailableTree, true);
        });
    }
    
    /**
     * Generate a string representation of the object
     * @return The string representation
     */
    public String toString() {
        return super.toString() + "\n Location:" + location + " Nearest tree: " + nearestAvailableTree;
    }
}
