import java.util.List;
import java.util.Random;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.function.Consumer;

/**
 * A class representing a deer. Deer care for their young, and eat grass.
 *  
 * @version 0
 */
public class Deer extends LandAnimal
{   
    
    /**
     * Create a new deer at location in layer.
     * 
     * @param layer The layer to occupy.
     * @param location The location within the layer.
     * @param randomAge Whether the newly created deer should have a random age or an age of 0
     */
    public Deer(boolean randomAge, AnimalLayer layer, Location location)
    {
        super(randomAge, layer, location);
    }
    
    /**
     * Set the properties of the deer
     */
    protected void setupProperties() {
        setBreedingAge(2);
        setMaxAgeMean(250);
        setMaxAgeSD(50);
        setMaxHunger(10);
        setGestationPeriodLength(1);
        setVisionRadius(4);
        setMoveRadius(4);
        setMeetCooldown(0.5);
        addFood(Grass.class, 1, -10);
        addFood(BerryBush.class, 0.25, -5);
    }
    
    
    /**
     * Set how the status of the deer changes on each step
     */
    protected void tryChangeStatus() {
        if (isHungry()) {
            setStatus(FOOD_HUNTING_STATUS_ID);
            return;
        }
        
        if (field.isDark()) {
            setStatus(ASLEEP_STATUS_ID);
            return;
        }
        
        if (canMeet() && rand.nextDouble() < 0.4 || getStatus().equals(MATE_HUNTING_STATUS_ID)) {
            setStatus(MATE_HUNTING_STATUS_ID);
            return;
        }
        
        setStatus(IDLE_STATUS_ID);
    }
    
    /**
     * Get a new deer of age 0 
     * @param layer The layer of the deer
     * @param location The location of the deer
     * @return A new baby deer
     */
    protected LandAnimal newBabyAnimal(AnimalLayer layer, Location location) {
        return new Deer(false, layer, location);
    }
    
    
}
