import java.util.Random;

/**
 * This class has three weathers clear sky, rainy and stormy. 
 * These are generated randomly and are returned.
 * Some species are also affected by the weather.
 *
 * @version 22/02/2020
 */
public class Weather
{
    // The probability that the weather will be generated in any given time.
    private static final double WEATHER_PROBABILITY = 0.04;
    // Default weather.
    private static String currentWeather = "Clear Sky";

    /**
     * Constructor of weather, which generates randomly.
     */
    public int Weather(){
        Random rand = new Random();
        int weatherRandom = rand.nextInt(100);
        return weatherRandom;
    }

    /**
     * Generates weather based on the weather probability.
     */
    public void generateWeather(){
        Random rand = Randomizer.getRandom();
        int w = Weather();
        String weather = "";
        if(rand.nextDouble() <= WEATHER_PROBABILITY) {
            if(w <= 20 ){
                currentWeather = "Rainy";
            }else if(w <= 25 ){
                currentWeather = "Stormy";
            }else{ 
                currentWeather = "Clear Sky";
            }
        }
    }

    /**
     * This method sets the weather effects on the species.
     */
    public void WeatherEffects(){
        if(currentWeather == "Rainy" ){
            SeaWeed.BREEDING_PROBABILITY = 0.99;
            SeaWeed.MAX_AGE = 400;
            Shark.BREEDING_PROBABILITY=0.05;
            KillerWhale.BREEDING_PROBABILITY=0.05;
        }else if(currentWeather == "Stormy"){
            SeaWeed.BREEDING_PROBABILITY = 0.4;
            SeaWeed.MAX_AGE = 300;
            Shark.BREEDING_PROBABILITY=0.05;
            KillerWhale.BREEDING_PROBABILITY=0.05;
        }else{
            SeaWeed.BREEDING_PROBABILITY = 0.9;
            SeaWeed.MAX_AGE = 400;
            Shark.BREEDING_PROBABILITY=0.2;
            KillerWhale.BREEDING_PROBABILITY=0.2;
        }
    }

    /**
     * Returns the current weather.
     */
    public String getCurrentWeather(){
        return currentWeather;
    }

}
