import java.util.Random;
import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 22/02/2020
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's age.
    private int age = getAge();
    // The animal's position in the field.
    private Location location;
    // Checks if animal is male.
    private boolean male;
    // Checks if animal is infected.
    protected boolean infected;
    // Random object for the whole class.
    private static final Random rand = Randomizer.getRandom();
    // Breeding probability of the animals.
    private double BREEDING_PROBABILITY = getBreedingProbability();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        male = setGender();                     //The animal is randomly given a gender (true or false)
        infected = setInfected();               //If the animal is infected (true or false)
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract protected void act(List<Animal> newAnimals);

    /**
     * Abstract method for finding the food.
     */
    abstract protected Location findFood();

    /**
     * Abstract method for finding the mate.
     */
    abstract protected void findMate(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the animal is male or not.
     * @return true if the animal is male.
     */
    protected boolean isMale()
    {
        return male;
    }

    /**
     * Check whether the animal is infected or not.
     * @return true if the animal is infected.
     */
    protected boolean isInfected()
    {
        return infected;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Sets genders to half the population of animals.
     */
    protected boolean setGender(){
        Random rand = new Random();
        int genInt = rand.nextInt(10);
        return genInt <= 4;
    }

    /**
     * Sets disease to half the population of animals.
     */
    protected boolean setInfected(){
        Random rand = new Random();
        int InfectionInt = rand.nextInt(10);
        return InfectionInt <= 0.1;
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        int MAX_AGE = getMaxAge();
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Makes the animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        int foodLevel = getFoodLevel();
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        int MAX_LITTER_SIZE = getMaxLitterSize();
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An animak can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        int BREEDING_AGE = getBreedingAge();
        return age >= BREEDING_AGE;
    }

    /**
     * Abstract method for returning breeding probability of the animals.
     */
    abstract protected double getBreedingProbability();

    /**
     * Abstract method for returning age of the animals.
     */
    abstract protected int getAge();

    /**
     * Abstract method for returning max litter size of the animals.
     */
    abstract protected int getMaxLitterSize();

    /**
     * Abstract method for returning breeding age of the animals.
     */
    abstract protected int getBreedingAge();

    /**
     * Abstract method for returning max age of the animals.
     */
    abstract protected int getMaxAge();

    /**
     * Abstract method for returning food level of the animals.
     */
    abstract protected int getFoodLevel();

}
