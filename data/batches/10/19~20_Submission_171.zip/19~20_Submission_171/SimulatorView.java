import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 22/02/2020
 */
public class SimulatorView extends JFrame implements ActionListener
{
    // Colors used for empty locations.
    private Color EMPTY_COLOR = Color.white;
    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String TIME_PREFIX = "Time: ";
    private final String WEATHER_PREFIX = "Weather: ";
    private final String POPULATION_PREFIX = "Population: ";
    private JLabel stepLabel, timeLabel, weatherLabel, population, infoLabel;
    private FieldView fieldView;
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;
    // A weather object to get current weather.
    private Weather currentWeather;
    // A simulator object for the menu bar.
    private Simulator simulator;
    // A string to store the current time of the day.
    private String time;
    // A counter for time.
    private int clock = 0;
    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width, Simulator simulatorObject) 
    {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();
        currentWeather = new Weather();
        // Creating the Menu bar.
        makeFrame();

        simulator = simulatorObject;

        setTitle("Aquatic Predator/Prey Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        timeLabel = new JLabel(TIME_PREFIX, JLabel.CENTER);
        weatherLabel = new JLabel(WEATHER_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        setLocation(100, 50);
        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new BorderLayout());
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(timeLabel, BorderLayout.EAST);
        infoPane.add(infoLabel, BorderLayout.CENTER);
        infoPane.add(weatherLabel, BorderLayout.CENTER);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }

    /**
     * Create the menu bar.
     */
    private void makeFrame()
    {
        makeMenuBar();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    /**
     * Putting all the buttons.
     */
    private void makeMenuBar()
    {
        JMenuBar menuBar = new JMenuBar();

        // Creating the File menu.
        JMenu fileMenu = new JMenu("Menu");
        menuBar.add(fileMenu);

        // Creating the sub menu.
        JMenu stepMenu = new JMenu("Steps");

        // Reset button.
        JMenuItem resetItem = new JMenuItem("Reset");
        resetItem.setToolTipText("resets the simulation");
        resetItem.addActionListener(this);
        fileMenu.add(resetItem);

        fileMenu.add(stepMenu);

        // One step button.
        JMenuItem oneItem = new JMenuItem("One-step");
        oneItem.setToolTipText("simulates one step");
        oneItem.addActionListener(this);
        stepMenu.add(oneItem);

        // Long run button.
        JMenuItem longItem = new JMenuItem("Long run");
        longItem.setToolTipText("simulates for many steps");
        longItem.addActionListener(this);
        stepMenu.add(longItem);

        // Quit button,
        JMenuItem quitItem = new JMenuItem("Quit");
        quitItem.addActionListener(this);
        fileMenu.add(quitItem);

        setJMenuBar(menuBar);
        setVisible(true);
    }

    /**
     * Adding the actions to the buttons.
     */
    public void actionPerformed(ActionEvent e) 
    { 
        String s = e.getActionCommand();  

        if(s.equals("Reset")){
            simulator.reset();
        }else if(s.equals("One-step")){
            simulator.simulateOneStep();
        }else if(s.equals("Long run")){
            MyBackgroundWorker BGWorker = new MyBackgroundWorker();
            BGWorker.execute();
        }else if(s.equals("Quit")){
            System.exit(0);
        }
    } 

    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass)
    {
        Color col = colors.get(animalClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }

        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();

        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    if((animal instanceof Animal) && ((Animal)animal).isInfected()==true){             
                        fieldView.drawMark(col, row, Color.BLACK);
                    } else  {
                        stats.incrementCount(animal.getClass());
                        fieldView.drawMark(col, row, getColor(animal.getClass()));
                    }
                } else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Sets the empty cells colour, 
     * according to time and weather.
     */
    public void time(){
        String weather = "";
        clock++;        
        weather = currentWeather.getCurrentWeather(); 

        if(clock%600 == 0 ){
            clock = 0;
        }

        if((clock >= 400) && (clock <= 600)){
            EMPTY_COLOR = new Color(78, 173, 246);
            time = "Night";
        }else if((clock >= 200) && (clock <= 400)){
            EMPTY_COLOR = new Color(205, 234, 255);
            time = "Evening";
        }else{
            EMPTY_COLOR = new Color(239, 249, 255); 
            time = "Morning";
        }
        timeLabel.setText(TIME_PREFIX + time);

        if(weather.equals("Rainy")){
            EMPTY_COLOR = new Color(230,230,230);
        }else if(weather.equals("Stormy")){
            EMPTY_COLOR = new Color(200,200,200);
        }

        weatherLabel.setText(WEATHER_PREFIX + weather);
    }
    
    /**
     * Resets the time to morning.
     */
    public void timeClear(){
        clock = 0;
    }
    
    /**
     * Returns the current time.
     */
    public String getTime(){
        return time;
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * To make the runlongsimulation method work simantaneously, without breaks.
     */
    public class MyBackgroundWorker extends SwingWorker<Integer, String> {
        @Override
        protected Integer doInBackground() throws Exception {
            simulator.runLongSimulation();
            return 0;
        }
    }

    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR, gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillOval(x * xScale , y * yScale , xScale+1, yScale+1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {                    
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
