import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A aquatic predator-prey simulator, based on a rectangular field
 * containing Sharks, Killer Whales, Sea Lions, Squid, Crabs and Seaweeds.
 *
 * @version 22/02/2020
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 110;
    // The probability that a species will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.015;//015
    private static final double WHALE_CREATION_PROBABILITY = 0.02;//015
    private static final double SEA_LION_CREATION_PROBABILITY = 0.07;//07
    private static final double SQUID_CREATION_PROBABILITY = 0.03;//03 
    private static final double CRAB_CREATION_PROBABILITY = 0.09;//09
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current weather of the simulation
    private Weather weather;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);

        view.setColor(Shark.class, Color.BLUE);
        view.setColor(KillerWhale.class, Color.ORANGE);
        view.setColor(SeaLion.class, Color.GRAY);
        view.setColor(Squid.class, Color.YELLOW);
        view.setColor(Crab.class, Color.RED);
        view.setColor(SeaWeed.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
        }
    }

    public void setDelay(){
        for(int step = 1; step <= 4000 && view.isViable(field); step++) {
            simulateOneStep();
            delay(100);   // To run more slowly
        } 
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * species.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn species.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Let all animals act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born species to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);
        view.time();
        weather.generateWeather();
        view.showStatus(step, field);

        // Adding plants in random empty cells (no plants at night).
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(! view.getTime().equals("Night")){
                    if(rand.nextDouble() <= 0.1) {
                        Location location = new Location(row, col);
                        SeaWeed weeds = new SeaWeed(true, field, location);
                        if(! weeds.isAlive()){
                            plants.add(weeds);
                        }
                    }
                }
            }
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        view.timeClear();
        view.time();
        weather.generateWeather();
        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with aquatic animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    KillerWhale whale = new KillerWhale(true, field, location);
                    animals.add(whale);
                }
                else if(rand.nextDouble() <= SEA_LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    SeaLion sealion = new SeaLion(true, field, location);
                    animals.add(sealion);
                }
                else if(rand.nextDouble() <= SQUID_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squid squid = new Squid(true, field, location);
                    animals.add(squid);
                }
                else if(rand.nextDouble() <= CRAB_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Crab crab = new Crab(true, field, location);
                    animals.add(crab);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
