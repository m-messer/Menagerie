import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Shark.
 * Sharks age, move, eat rabbits, and die.
 *
 * @version 22/02/2020
 */
public class Shark extends Animal
{
    // Characteristics shared by all Sharks (class variables).

    // The age at which a Shark can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a Shark can live.
    public static int MAX_AGE = 350;
    // The likelihood of a Shark breeding.
    public static double BREEDING_PROBABILITY = 0.04;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value. In effect, this is the
    // number of steps a Shark can go before it has to eat again.
    private static final int SEA_LION_FOOD_VALUE = 9;
    private static final int SEA_WEED_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Shark's age.
    private int age;
    // The Shark's food level, which is increased by eating food.
    private int foodLevel;
    /**
     * Create a Shark. A Shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shark(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SEA_LION_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SEA_LION_FOOD_VALUE;
        }
    }

    /**
     * This is what the Shark does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSharks A list to return newly born Sharks.
     */
    public void act(List<Animal> newSharks)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            findMate(newSharks);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first live animal/plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof SeaLion) {
                SeaLion sealion = (SeaLion) animal;
                if(sealion.isAlive()) { 
                    sealion.setDead();
                    foodLevel = SEA_LION_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof SeaWeed) {
                SeaWeed weeds = (SeaWeed) animal;
                if(weeds.isAlive()) { 
                    weeds.setDead();
                    foodLevel = SEA_WEED_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Look for mate adjacent to the current location.
     * Breed if the mate is of opposite gender.
     */
    protected void findMate(List<Animal> newSharks)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shark) {
                Shark mate = (Shark) animal;
                if(mate.isAlive() && mate.isMale() != this.isMale()) { 
                    giveBirth(newSharks);
                }
            }
        }
    }

    /**
     * Check whether or not this Shark is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSharks A list to return newly born Sharks.
     */
    private void giveBirth(List<Animal> newSharks)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Shark young = new Shark(false, field, loc);
            newSharks.add(young);
        }
    }

    /**
     * Returns breeding probability.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns age.
     */
    public int getAge(){
        return age;
    }

    /**
     * Returns food level.
     */
    public int getFoodLevel(){
        return foodLevel;
    }

    /**
     * Returns breeding age.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Returns max age.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Returns max litter size.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

}
