import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.Set;

/**
 * A class representing shared characteristics of all animals.
 *
 * @version 2019.02.21
 */
public abstract class Animal
{
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    // Whether the animal is alive or not.
    private boolean alive;
    // The age of an animal.
    private int age;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's gender.
    private boolean isMale;
    // Whether the animal sleeps during the night or not.
    private boolean sleepsDuringNight;
    // The current food ("fullness") level of an animal.
    private int foodLevel;    
    // Whether the animal has a disease or not.
    private boolean isInfected;

    // Probability of a predator missing prey in foggy weather.
    public static final double PREDATOR_MISSES_PREY_IN_FOGGY = 0.4;
    // Probability of an animal getting randomly infected at each step.
    public static final double PROBABILITY_OF_RANDOM_INFECTION = 0.008;
    // Probability of death at each step when being infected.
    public static final double PROBABILITY_OF_DEATH_FROM_INFECTION = 0.05;
    // The age to which an animal can live.
    protected static final int MAX_AGE = 150;
    // Mating season modifier.
    public static final double MATING_SEASON_BREEDING_PROBABILITY_MODIFIER = 1.5;
    
    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        isMale = (rand.nextInt(2) == 1);
        isInfected = false;
        sleepsDuringNight = false;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Make this animal look for food.
     * @param preyToEat For predators, a set of animals they can eat, for prey, null.
     * @return Location that has food, if no such location exists, null.
     */
    abstract protected Location findFood(Set<String> preyToEat);
    
    /**
    * If possible, give birth to new animals.
    * New births will be made into free adjacent locations.
    * @param newAnimals A list to return newly born animals.
    */
    abstract protected void giveBirth(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return True if the animal is alive, false otherwise.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Check whether the animal is male or not.
     * @return True if the animal is male, false if female.
     */
    protected boolean isMale()
    {
        return isMale;
    }
    
    /**
     * Check whether the animal sleeps during the night.
     * @return True if the animal sleeps during the night, false otherwise.
     */
    protected boolean getSleepsDuringNight()
    {
        return sleepsDuringNight;
    }
    
    /**
     * Get the animal's age
     * @return The animal's age
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Age the animal by one.
     */
    protected void ageByOne()
    {
        age++;
    }
    
    /**
     * Set the animal's age.
     * @param age The age to set the animal to.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * Set whether the animal is infected or not.
     * @param infected True if infected, false if not.
     */
    protected void setInfected(boolean infected)
    {
        isInfected = infected;
    }
    
    /**
     * Return whether the animal is infected.
     * @return True if the animal is infected, false otherwise.
     */
    protected boolean getInfected()
    {
        return isInfected;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at a new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Get the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Make this animal hungrier. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Set the animal's food level.
     * @param foodLevel The new food level.
     */
    protected void setFoodLevel(int foodLevel) {
        this.foodLevel = foodLevel;
    }
    
    /**
     * Get the animal's food level.
     * @return The animal's food level.
     */
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(int breedingAge, int maxLitterSize, double breedingProbability)
    {
        int births = 0;
        if(canBreed(breedingAge) && rand.nextDouble() <= breedingProbability) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }
    
    /**
     * Check if this animal can breed with an adjacent animal.
     * Takes into account genders, breeding ages,
     * and whether they're the same species.
     * @param breedingAge The age after which animals of this species can breed.
     * @return Whether the animal can breed.
     */
    protected boolean canBreed(int breedingAge)
    {
        if (getAge() < breedingAge) return false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal != null && animal.getClass().equals(this.getClass())) {
                Animal anotherAnimal = (Animal) animal;
                // If the animal is alive, of breeding age and of different gender than adjacent animal.
                if(anotherAnimal.isAlive() && anotherAnimal.getAge() >= breedingAge && anotherAnimal.isMale() != this.isMale()) { 
                    // If at least one is infected, infect both of them.
                    if (anotherAnimal.getInfected() || this.getInfected()) {
                        anotherAnimal.setInfected(true);
                        this.setInfected(true);
                    }
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Increase the animal's age.
     * This could result in the animal's death.
     */
    protected void incrementAge(int maxAge)
    {
        ageByOne();
        if(getAge() > maxAge) {
            setDead();
        }
    }
    
    /**
     * Every step is 4 hours in a 24 hour day. Half of the day is a day, and the other half is a night.
     * @return True if it's currently day, false if it's night.
     */
    public boolean isDay() {
        return field.isDay();
    }
}
