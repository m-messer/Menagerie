import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

/**
 * A simple model of a bear.
 * Bears age, move, eat other animals, and die.
 * They can accumulate food and they hibernate during the winter (don't move or act for a whole season).
 *
 * @version 2019.02.21
 */
public class Bear extends Predator
{
    // Characteristics shared by all bears (class variables).
   
    // The animals a bear can eat
    protected static final Set<String> preyToEat = new HashSet<>(Arrays.asList("Rabbit", "Duck"));
    // The age at which a bear can start to breed.
    private static final int BREEDING_AGE = 18;
    // The age to which a bear can live.
    private static final int MAX_AGE = 2000;
    // The likelihood of a bear breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
 
    /**
     * Create a bear. A bear can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the bear will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bear(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location,MAX_AGE);
    }
    
    /**
     * Look for prey rabbits and ducks adjacent to the current location.
     * Only the first live rabbit/duck is eaten.
     * Bears are special because they can accumulate food.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood(Set<String> preyToEat)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            // Looking for food is harder in foggy weather
            if (field.getWeather().equals("Foggy") && rand.nextDouble() < PREDATOR_MISSES_PREY_IN_FOGGY) continue;
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Duck && canEat("Duck", preyToEat)) {
                Duck duck = (Duck) animal;
                if(duck.isAlive()) { 
                    if (duck.getInfected()) setInfected(true);
                    duck.setDead();
                    setFoodLevel(getFoodLevel() + Duck.FOOD_VALUE);
                    return where;
                }
            }
            if(animal instanceof Rabbit && canEat("Rabbit", preyToEat)) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    if (rabbit.getInfected()) setInfected(true);
                    rabbit.setDead();
                    setFoodLevel(getFoodLevel() + Rabbit.FOOD_VALUE);
                    return where;
                }
            }
            
        }
        return null;
    }
    
    /**
     * This is what the bear does most of the time: it hunts for
     * prey animals. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newBears A list to return newly born bears.
     */
    public void act(List<Animal> newBears)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            // Bears hibernate during the winter
            if (getField().getSeason() == 1) return;
            // If this animal has a disease, there is a small chance it will die this step
            if (getInfected() && rand.nextDouble() < PROBABILITY_OF_DEATH_FROM_INFECTION) {
                setDead();
                return;
            }
            if (!isDay()) return; // Bears sleep during the night and don't hunt or move
            giveBirth(newBears);            
            // Move towards a source of food if found.
            Location newLocation = findFood(preyToEat);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Check whether or not this bears is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBears A list to return newly born bears.
     */
    protected void giveBirth(List<Animal> newBears)
    {
        // New bears are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(BREEDING_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bear young = new Bear(false, field, loc);
            newBears.add(young);
        }
    }
}
