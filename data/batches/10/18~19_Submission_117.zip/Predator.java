import java.util.List;
import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

/**
 * A class representing shared characteristics of predators.
 *
 * @version 2019.02.21
 */
public abstract class Predator extends Animal
{
    // Stores the names of prey animals this predator eats.
    // Change this in the child classes to pick which animals they eat.
    // Default is only Mouse.
    protected static final Set<String> preyToEat = new HashSet<>(Arrays.asList("Mouse"));
    
    /**
     * Create a new predator animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location, int maxAge)
    {
        super(field,location);
        if(randomAge) {
            setAge(rand.nextInt(maxAge));
            setFoodLevel(rand.nextInt(Rabbit.FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(Rabbit.FOOD_VALUE);
        }
    }
    
    /**
     * Returns whether a predator can eat a specific type of animal.
     * @param preyName The name of the prey.
     * @param preyToEat Set of animals a predator can eat.
     * @return True if the predator can eat the prey, false otherwise.
     */
    protected static boolean canEat(String preyName, Set<String> preyToEat)
    {
        return preyToEat.contains(preyName);
    }
    
    /**
     * Look for prey animals adjacent to the current location.
     * Only the first live prey animal is eaten.
     * @param preyToEat Set of animals a predator can eat.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood(Set<String> preyToEat)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            // Looking for food is harder in foggy weather
            if (field.getWeather().equals("Foggy") && rand.nextDouble() < PREDATOR_MISSES_PREY_IN_FOGGY) continue;
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Duck && canEat("Duck", preyToEat) && getFoodLevel() < Duck.FOOD_VALUE) {
                Duck duck = (Duck) animal;
                if(duck.isAlive()) { 
                    if (duck.getInfected()) setInfected(true);
                    duck.setDead();
                    setFoodLevel(Duck.FOOD_VALUE);
                    return where;
                }
            }
            else if(animal instanceof Rabbit && canEat("Rabbit", preyToEat) && getFoodLevel() < Duck.FOOD_VALUE) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    if (rabbit.getInfected()) setInfected(true);
                    rabbit.setDead();
                    setFoodLevel(Rabbit.FOOD_VALUE);
                    return where;
                }
            }
            else if(animal instanceof Mouse && canEat("Mouse", preyToEat) && getFoodLevel() < Duck.FOOD_VALUE) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) { 
                    if (mouse.getInfected()) setInfected(true);
                    mouse.setDead();
                    setFoodLevel(Mouse.FOOD_VALUE);
                    return where;
                }
            }
            
        }
        return null;
    }
    
    /**
     * Default act method for predators. A predator will hunt and move.
     * In the process, it might breed, die of hunger, or die of old age.
     * @param field The field currently occupied.
     * @param newAnimals list to return newly born animals.
     */
    public void act(List<Animal> newAnimals)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            // If this animal has a disease, there is a small chance it will die this step
            if (getInfected() && rand.nextDouble() < PROBABILITY_OF_DEATH_FROM_INFECTION) {
                setDead();
                return;
            }
            if (!isDay() && getSleepsDuringNight()) return; // Animals that sleep during the night don't hunt or move
            giveBirth(newAnimals);            
            // Move towards a source of food if found.
            Location newLocation = findFood(preyToEat);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
}
