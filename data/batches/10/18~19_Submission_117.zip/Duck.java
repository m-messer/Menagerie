import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a duck.
 * Ducks age, move, eat plants, and die.
 *
 * @version 2019.02.21
 */
public class Duck extends Prey
{
    // Characteristics shared by all ducks (class variables).

    // The age at which a duck can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a duck can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a duck breeding.
    private static final double BREEDING_PROBABILITY = 0.70;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20;
    // The food value predators get when eating ducks
    public static final int FOOD_VALUE = 24;

    /**
     * Create a new duck. A duck may be created with age
     * zero (a new born) or with a random age.
     * @param randomAge If true, the duck will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Duck(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE);
    }
    
    /**
     * This is what the duck does most of the time - it runs 
     * around and tries to eat plants. 
     * Sometimes it will breed, or die of old age or disease.
     * @param newDucks A list to return newly born ducks.
     */
    public void act(List<Animal> newDucks)
    {
        if (!getInfected()) setInfected(rand.nextDouble() < PROBABILITY_OF_RANDOM_INFECTION);
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            // If this animal has a disease, there is a small chance it will die this step
            if (getInfected() && rand.nextDouble() < PROBABILITY_OF_DEATH_FROM_INFECTION) {
                setDead();
                return;
            }
            giveBirth(newDucks);            
            // Move towards a source of food if found.
            Location newLocation = findFood(null);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Check whether or not this duck is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDucks A list to return newly born ducks.
     */
    protected void giveBirth(List<Animal> newDucks)
    {
        // New ducks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(BREEDING_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Duck young = new Duck(false, field, loc);
            newDucks.add(young);
        }
    }   
}
