import java.util.List;
import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

/**
 * A simple model of an eagle.
 * Eagles age, move, eat other animals, and die.
 *
 * @version 2019.02.21
 */
public class Eagle extends Predator
{
    // Characteristics shared by all eagles (class variables).
    
    // The animals an eagle can eat
    protected static final Set<String> preyToEat = new HashSet<>(Arrays.asList("Mouse","Rabbit"));
    // The age at which an eagle can start to breed.
    private static final int BREEDING_AGE = 22;
    // The age to which an eagle can live.
    private static final int MAX_AGE = 300;
    // The likelihood of an eagle breeding.
    private static final double BREEDING_PROBABILITY = 0.40;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
 
    /**
     * Create a eagle. A eagle can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the eagle will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Eagle(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE);
    }
    
    /**
     * This is what the eagle does most of the time: it hunts for
     * rabbits and mice. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newEagles A list to return newly born eagles.
     */
    public void act(List<Animal> newEagles)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            // If this animal has a disease, there is a small chance it will die this step
            if (getInfected() && rand.nextDouble() < PROBABILITY_OF_DEATH_FROM_INFECTION) {
                setDead();
                return;
            }
            if (!isDay()) return; // Eagles sleep during the night and don't hunt or move
            giveBirth(newEagles);            
            // Move towards a source of food if found.
            Location newLocation = findFood(preyToEat);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    
    /**
     * Check whether or not this eagle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newEagles A list to return newly born eagles.
     */
    protected void giveBirth(List<Animal> newEagles)
    {
        // New eagles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(BREEDING_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Eagle young = new Eagle(false, field, loc);
            newEagles.add(young);
        }
    }
    
}
