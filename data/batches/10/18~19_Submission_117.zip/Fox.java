import java.util.List;
import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2019.02.21
 */
public class Fox extends Predator
{
    // Characteristics shared by all foxes (class variables).
    
    // The animals a fox can eat
    protected static final Set<String> preyToEat = new HashSet<>(Arrays.asList("Mouse","Rabbit","Duck"));
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 19;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.37;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
 
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE);
    }
    
    /**
     * This is what the fox does most of the time: it hunts for
     * prey animals. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Animal> newFoxes)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            // If this animal has a disease, there is a small chance it will die this step
            if (getInfected() && rand.nextDouble() < PROBABILITY_OF_DEATH_FROM_INFECTION) {
                setDead();
                return;
            }
            if (!isDay()) return; // Foxes sleep during the night and don't hunt or move
            giveBirth(newFoxes);            
            // Move towards a source of food if found.
            Location newLocation = findFood(preyToEat);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    protected void giveBirth(List<Animal> newFoxes)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(BREEDING_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fox young = new Fox(false, field, loc);
            newFoxes.add(young);
        }
    }
}
