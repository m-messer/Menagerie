
/**
 * This class represents a plant that prey eat.
 *
 * @version 2019.02.21
 */
public class Plant
{
    // Characteristics shared by all plants (class variables).
    private static final int GROWTH_MAX = 6;
    public static final int FOOD_VALUE = 24;
    
    // Object-specific characteristics
    private boolean isEaten;
    private int counter;
    
    /**
     * Constructor for objects of class Plant
     */
    public Plant()
    {
        isEaten = false;
        counter = 0;
    }

    /**
     * Getter for the isEaten field.
     * @return True if the plant is eaten already, false otherwise.
     */
    public boolean getIsEaten()
    {
        return isEaten;
    }
    
    /**
     * Plant "ages" one turn.
     * If the plant is eaten, it regenerates.
     */
    public void passTurn()
    {
        if (isEaten) {
            counter++;
            if (counter >= GROWTH_MAX) {
                counter = 0;
                isEaten = false;
            }
        }
    }
    
    /**
     * Plant "ages" by n turns.
     * If the plant is eaten, it regenerates.
     */
    public void passTurns(int n)
    {
        if (isEaten){
            for (int i = 0; i < n; i++) passTurn();
        }
    }
    
    /**
     * Plant gets eaten by an animal.
     */
    public void getEaten()
    {
        isEaten = true;
        counter = 0;
    }
}
