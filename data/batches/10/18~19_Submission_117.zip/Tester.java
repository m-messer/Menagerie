import java.util.Random;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.File;
import java.io.IOException;

/**
 * A helper class used to find optimal configurations for long-lasting simulations
 * 
 * !!! NOTE !!!
 * To make this work, all the below listed parameters (Bear.BREEDNG_AGE etc.)
 * have to be set to public (and can't be final), so that Tester can modify them.
 * After the tests have run, and a good configuration has been found,
 * change them back to private final (or whatever their intended state should be).
 * 
 * Tester also relies on the GUI being turned off.
 * This can be done by setting Simulator.showGUI to false.
 *
 * @version 2019.02.21
 */
public class Tester
{
    private static Random r = new Random();
    // Stores the values used for the various parameters
    // starts populated by the original values, but quickly diverges
    double[] vals = new double[]{
            /* Uncomment this if you want to use the Tester class
            Simulator.FOX_CREATION_PROBABILITY,
            Simulator.RABBIT_CREATION_PROBABILITY,
            Simulator.DUCK_CREATION_PROBABILITY,
            Simulator.EAGLE_CREATION_PROBABILITY,
            Simulator.MOUSE_CREATION_PROBABILITY,
            Simulator.BEAR_CREATION_PROBABILITY, 
            Simulator.PLANT_CREATION_PROBABILITY,
            Animal.PREDATOR_MISSES_PREY_IN_FOGGY,
            Animal.PROBABILITY_OF_RANDOM_INFECTION,
            Animal.PROBABILITY_OF_DEATH_FROM_INFECTION,
            Animal.MATING_SEASON_BREEDING_PROBABILITY_MODIFIER,
            Bear.BREEDING_AGE,
            Bear.MAX_AGE,
            Bear.BREEDING_PROBABILITY,
            Bear.MAX_LITTER_SIZE,
            Eagle.BREEDING_AGE,
            Eagle.MAX_AGE,
            Eagle.BREEDING_PROBABILITY,
            Eagle.MAX_LITTER_SIZE,
            Fox.BREEDING_AGE,
            Fox.MAX_AGE,
            Fox.BREEDING_PROBABILITY,
            Fox.MAX_LITTER_SIZE,
            Mouse.BREEDING_AGE,
            Mouse.MAX_AGE,
            Mouse.BREEDING_PROBABILITY,
            Mouse.MAX_LITTER_SIZE,
            Mouse.FOOD_VALUE,
            Duck.BREEDING_AGE,
            Duck.MAX_AGE,
            Duck.BREEDING_PROBABILITY,
            Duck.MAX_LITTER_SIZE,
            Duck.FOOD_VALUE,
            Rabbit.BREEDING_AGE,
            Rabbit.MAX_AGE,
            Rabbit.BREEDING_PROBABILITY,
            Rabbit.MAX_LITTER_SIZE,
            Rabbit.FOOD_VALUE,
            Plant.GROWTH_MAX,
            Plant.FOOD_VALUE*/
        };
    
    // Some constants to limit the randomness of new values
    private final int MIN_BREEDING_AGE = 10;
    private final int MIN_MAX_LITTER_SIZE = 2;
    private final int MIN_GROWTH_MAX = 3;
    
    // How much variance to the values. 0.3 means that it can go from 70% to 130% of its previous value (30% up/down)
    private double percentage = 0.3;
    // The simulator the Tester uses
    private Simulator s;
    private int testsPerStage = 1; // how many simulations with one config
    private double[] bestVals = vals; // Stores the values that reached the highest step count
    private int nSteps = 500; // starting number of steps to simulate, goes up with each reaching of nSteps
    private int incrementNSteps = 1; // By how much nSteps increases if it's reached
    private int mostSteps = 0; // keeps the current record of most steps reached
    
    /**
     * To run tests, all you need to do is make a Tester object.
     * After it's made, it automatically starts running tests and recording the best results.
     */
    public Tester() {
        s = new Simulator();
        for (int n = 0; n < 60; n++) {
            System.out.println("Stage "+String.valueOf(n));
            runTests();
            printCurrentBest();
            recordCurrentBest();
            System.out.println("");
        }
        
    }
    
    /**
     * Runs the tests, running simulations with randomly altered parameters.
     * Keeps track of the best-performing configurations, prints them to terminal,
     * and writes them to an included text file ("testerLogs.txt")
     */
    private void runTests() {
        setVars(percentage);
        for (int i = 0; i < testsPerStage; i++) {
            s.reset();
            s.simulate(nSteps);
            if (s.step > mostSteps) {
                mostSteps = s.step;
                for (int i2 = 0; i2 < vals.length; i2++) bestVals[i2] = vals[i2];
            }
            if (s.step == nSteps) {
                System.out.println("Config reached max step count " + String.valueOf(nSteps));
                nSteps += incrementNSteps;
                return;
            }
        }
        // At the end of testing, sets vals to the best values reached so far
        for (int i2 = 0; i2 < vals.length; i2++) vals[i2] = bestVals[i2];
    }
    
    /**
     * Sets the parameters to new, randomly altered values
     * Double variables are altered with the percentageOffset,
     * Int variables can randomly shift some predetermined amount higher/lower
     * @param percentageOffset how much can the double variables change. 0.3 means they go from their 70% to their 130%
     */
    private void setVars(double percentageOffset) {
        // Note that while all parameters are listed, some are commented out to preserve their value
        // This way, you can pick and choose which to alter and which to keep the same
        /* Uncomment this if you want to use the Tester class (and the vals at the top)
        Simulator.FOX_CREATION_PROBABILITY = vals[0]*(1-percentageOffset) + (vals[0]*percentageOffset*2)*r.nextDouble();
        vals[0] = Simulator.FOX_CREATION_PROBABILITY;
        Simulator.RABBIT_CREATION_PROBABILITY = vals[1]*(1-percentageOffset) + (vals[1]*percentageOffset*2)*r.nextDouble();
        vals[1] = Simulator.RABBIT_CREATION_PROBABILITY;
        Simulator.DUCK_CREATION_PROBABILITY = vals[2]*(1-percentageOffset) + (vals[2]*percentageOffset*2)*r.nextDouble();
        vals[2] = Simulator.DUCK_CREATION_PROBABILITY;
        Simulator.EAGLE_CREATION_PROBABILITY = vals[3]*(1-percentageOffset) + (vals[3]*percentageOffset*2)*r.nextDouble();
        vals[3] = Simulator.EAGLE_CREATION_PROBABILITY;
        Simulator.MOUSE_CREATION_PROBABILITY = vals[4]*(1-percentageOffset) + (vals[4]*percentageOffset*2)*r.nextDouble();
        vals[4] = Simulator.MOUSE_CREATION_PROBABILITY;
        Simulator.BEAR_CREATION_PROBABILITY = vals[5]*(1-percentageOffset) + (vals[5]*percentageOffset*2)*r.nextDouble();
        vals[5] = Simulator.BEAR_CREATION_PROBABILITY;
        Simulator.PLANT_CREATION_PROBABILITY = vals[6]*(1-percentageOffset) + (vals[6]*percentageOffset*2)*r.nextDouble();
        vals[6] = Simulator.PLANT_CREATION_PROBABILITY;
        
        // Animal.PREDATOR_MISSES_PREY_IN_FOGGY = vals[7]*(1-percentageOffset) + (vals[7]*percentageOffset*2)*r.nextDouble();
        // vals[7] = Animal.PREDATOR_MISSES_PREY_IN_FOGGY;
        Animal.PROBABILITY_OF_RANDOM_INFECTION = vals[8]*(1-percentageOffset) + (vals[8]*percentageOffset*2)*r.nextDouble();
        vals[8] = Animal.PROBABILITY_OF_RANDOM_INFECTION;
        Animal.PROBABILITY_OF_DEATH_FROM_INFECTION = vals[9]*(1-percentageOffset) + (vals[9]*percentageOffset*2)*r.nextDouble();
        vals[9] = Animal.PROBABILITY_OF_DEATH_FROM_INFECTION;
        // Animal.MATING_SEASON_BREEDING_PROBABILITY_MODIFIER = vals[10]*(1-percentageOffset) + (vals[10]*percentageOffset*2)*r.nextDouble();
        // vals[10] = Animal.MATING_SEASON_BREEDING_PROBABILITY_MODIFIER;
        
        Bear.BREEDING_AGE = (int)vals[11] - 3 + r.nextInt(7);
        if (Bear.BREEDING_AGE < MIN_BREEDING_AGE) Bear.BREEDING_AGE = MIN_BREEDING_AGE;
        vals[11] = Bear.BREEDING_AGE;
        //Bear.MAX_AGE = (int)(vals[12]*(1-percentageOffset) + (vals[12]*percentageOffset*2)*r.nextDouble());
        //if (Bear.MAX_AGE <= 0) Bear.MAX_AGE = 1;
        //vals[12] = Bear.MAX_AGE;
        Bear.BREEDING_PROBABILITY = vals[13]*(1-percentageOffset) + (vals[13]*percentageOffset*2)*r.nextDouble();
        vals[13] = Bear.BREEDING_PROBABILITY;
        //Bear.MAX_LITTER_SIZE = (int)vals[14] - 2 + r.nextInt(5);
        //if (Bear.MAX_LITTER_SIZE < MIN_MAX_LITTER_SIZE) Bear.MAX_LITTER_SIZE = MIN_MAX_LITTER_SIZE;
        //vals[14] = Bear.MAX_LITTER_SIZE;
        
        Eagle.BREEDING_AGE = (int)vals[15] - 3 + r.nextInt(7);
        if (Eagle.BREEDING_AGE < MIN_BREEDING_AGE) Eagle.BREEDING_AGE = MIN_BREEDING_AGE;
        vals[15] = Eagle.BREEDING_AGE;
        //Eagle.MAX_AGE = (int)(vals[16]*(1-percentageOffset) + (vals[16]*percentageOffset*2)*r.nextDouble());
        //if (Eagle.MAX_AGE <= 0) Eagle.MAX_AGE = 1;
        //vals[16] = Eagle.MAX_AGE;
        Eagle.BREEDING_PROBABILITY = vals[17]*(1-percentageOffset) + (vals[17]*percentageOffset*2)*r.nextDouble();
        vals[17] = Eagle.BREEDING_PROBABILITY;
        //Eagle.MAX_LITTER_SIZE = (int)vals[18] - 2 + r.nextInt(5);
        //if (Eagle.MAX_LITTER_SIZE < MIN_MAX_LITTER_SIZE) Eagle.MAX_LITTER_SIZE = MIN_MAX_LITTER_SIZE;
        //vals[18] = Eagle.MAX_LITTER_SIZE;
        
        Fox.BREEDING_AGE = (int)vals[19] - 3 + r.nextInt(7);
        if (Fox.BREEDING_AGE < MIN_BREEDING_AGE) Fox.BREEDING_AGE = MIN_BREEDING_AGE;
        vals[19] = Fox.BREEDING_AGE;
        //Fox.MAX_AGE = (int)(vals[20]*(1-percentageOffset) + (vals[20]*percentageOffset*2)*r.nextDouble());
        //if (Fox.MAX_AGE <= 0) Fox.MAX_AGE = 1;
        //vals[20] = Fox.MAX_AGE;
        Fox.BREEDING_PROBABILITY = vals[21]*(1-percentageOffset) + (vals[21]*percentageOffset*2)*r.nextDouble();
        vals[21] = Fox.BREEDING_PROBABILITY;
        //Fox.MAX_LITTER_SIZE = (int)vals[22] - 2 + r.nextInt(5);
        //if (Fox.MAX_LITTER_SIZE < MIN_MAX_LITTER_SIZE) Fox.MAX_LITTER_SIZE = MIN_MAX_LITTER_SIZE;
        //vals[22] = Fox.MAX_LITTER_SIZE;
        
        Mouse.BREEDING_AGE = (int)vals[23] - 3 + r.nextInt(7);
        if (Mouse.BREEDING_AGE < MIN_BREEDING_AGE) Mouse.BREEDING_AGE = MIN_BREEDING_AGE;
        vals[23] = Mouse.BREEDING_AGE;
        //Mouse.MAX_AGE = (int)(vals[24]*(1-percentageOffset) + (vals[24]*percentageOffset*2)*r.nextDouble());
        //if (Mouse.MAX_AGE <= 0) Mouse.MAX_AGE = 1;
        //vals[24] = Mouse.MAX_AGE;
        Mouse.BREEDING_PROBABILITY = vals[25]*(1-percentageOffset) + (vals[25]*percentageOffset*2)*r.nextDouble();
        vals[25] = Mouse.BREEDING_PROBABILITY;
        //Mouse.MAX_LITTER_SIZE = (int)vals[26] - 2 + r.nextInt(5);
        //if (Mouse.MAX_LITTER_SIZE < MIN_MAX_LITTER_SIZE) Mouse.MAX_LITTER_SIZE = MIN_MAX_LITTER_SIZE;
        //vals[26] = Mouse.MAX_LITTER_SIZE;
        Mouse.FOOD_VALUE = (int)vals[27] - 2 + r.nextInt(5);
        if (Mouse.FOOD_VALUE <= 0) Mouse.FOOD_VALUE = 1;
        vals[27] = Mouse.FOOD_VALUE;
        
        Duck.BREEDING_AGE = (int)vals[28] - 3 + r.nextInt(7);
        if (Duck.BREEDING_AGE < MIN_BREEDING_AGE) Duck.BREEDING_AGE = MIN_BREEDING_AGE;
        vals[28] = Duck.BREEDING_AGE;
        //Duck.MAX_AGE = (int)(vals[29]*(1-percentageOffset) + (vals[29]*percentageOffset*2)*r.nextDouble());
        //if (Duck.MAX_AGE <= 0) Duck.MAX_AGE = 1;
        //vals[29] = Duck.MAX_AGE;
        Duck.BREEDING_PROBABILITY = vals[30]*(1-percentageOffset) + (vals[30]*percentageOffset*2)*r.nextDouble();
        vals[30] = Duck.BREEDING_PROBABILITY;
        //Duck.MAX_LITTER_SIZE = (int)vals[31] - 2 + r.nextInt(5);
        //if (Duck.MAX_LITTER_SIZE < MIN_MAX_LITTER_SIZE) Duck.MAX_LITTER_SIZE = MIN_MAX_LITTER_SIZE;
        //vals[31] = Duck.MAX_LITTER_SIZE;
        Duck.FOOD_VALUE = (int)vals[32] - 2 + r.nextInt(5);
        if (Duck.FOOD_VALUE <= 0) Duck.FOOD_VALUE = 1;
        vals[32] = Duck.FOOD_VALUE;
        
        Rabbit.BREEDING_AGE = (int)vals[33] - 3 + r.nextInt(7);
        if (Rabbit.BREEDING_AGE < MIN_BREEDING_AGE) Rabbit.BREEDING_AGE = MIN_BREEDING_AGE;
        vals[33] = Rabbit.BREEDING_AGE;
        //Rabbit.MAX_AGE = (int)(vals[34]*(1-percentageOffset) + (vals[34]*percentageOffset*2)*r.nextDouble());
        //if (Rabbit.MAX_AGE <= 0) Rabbit.MAX_AGE = 1;
        //vals[34] = Rabbit.MAX_AGE;
        Rabbit.BREEDING_PROBABILITY = vals[35]*(1-percentageOffset) + (vals[35]*percentageOffset*2)*r.nextDouble();
        vals[35] = Rabbit.BREEDING_PROBABILITY;
        //Rabbit.MAX_LITTER_SIZE = (int)vals[36] - 2 + r.nextInt(5);
        //if (Rabbit.MAX_LITTER_SIZE < MIN_MAX_LITTER_SIZE) Rabbit.MAX_LITTER_SIZE = MIN_MAX_LITTER_SIZE;
        //vals[36] = Rabbit.MAX_LITTER_SIZE;
        Rabbit.FOOD_VALUE = (int)vals[37] - 2 + r.nextInt(5);
        if (Rabbit.FOOD_VALUE <= 0) Rabbit.FOOD_VALUE = 1;
        vals[37] = Rabbit.FOOD_VALUE;
        
        Plant.GROWTH_MAX = (int)vals[38] - 2 + r.nextInt(5);
        if (Plant.GROWTH_MAX < MIN_GROWTH_MAX) Plant.GROWTH_MAX = MIN_GROWTH_MAX;
        vals[38] = Plant.GROWTH_MAX;
        Plant.FOOD_VALUE = (int)vals[39] - 2 + r.nextInt(5);
        if (Plant.FOOD_VALUE <= 0) Plant.FOOD_VALUE = 1;
        vals[39] = Plant.FOOD_VALUE;
        
        // Lastly, checks if some values accidentally dipped below 0, sets them to 0
        for (int i = 0; i < vals.length; i++) {
            if (vals[i] < 0) vals[i] = 0;
        }
        */
    }
    
    /**
     * Generates a string describing the configuration that reached the best step count so far.
     * @return a string describing the best configuration so far
     */
    private String generateReport()
    {
        String report = "";
        report += "Current best: " + String.valueOf(mostSteps)+"\n";
        report += "Simulator.FOX_CREATION_PROBABILITY = "+String.valueOf(bestVals[0])+"\n";
        report += "Simulator.RABBIT_CREATION_PROBABILITY = "+String.valueOf(bestVals[1])+"\n";
        report += "Simulator.DUCK_CREATION_PROBABILITY = "+String.valueOf(bestVals[2])+"\n";
        report += "Simulator.EAGLE_CREATION_PROBABILITY = "+String.valueOf(bestVals[3])+"\n";
        report += "Simulator.MOUSE_CREATION_PROBABILITY = "+String.valueOf(bestVals[4])+"\n";
        report += "Simulator.BEAR_CREATION_PROBABILITY = "+String.valueOf(bestVals[5])+"\n";
        report += "Simulator.PLANT_CREATION_PROBABILITY = "+String.valueOf(bestVals[6])+"\n";
        report += "Animal.PREDATOR_MISSES_PREY_IN_FOGGY = "+String.valueOf(bestVals[7])+"\n";
        report += "Animal.PROBABILITY_OF_RANDOM_INFECTION = "+String.valueOf(bestVals[8])+"\n";
        report += "Animal.PROBABILITY_OF_DEATH_FROM_INFECTION = "+String.valueOf(bestVals[9])+"\n";
        report += "Animal.MATING_SEASON_BREEDING_PROBABILITY_MODIFIER = "+String.valueOf(bestVals[10])+"\n";
        report += "Bear.BREEDING_AGE = "+String.valueOf((int)(bestVals[11]))+"\n";
        report += "Bear.MAX_AGE = "+String.valueOf((int)(bestVals[12]))+"\n";
        report += "Bear.BREEDING_PROBABILITY = "+String.valueOf(bestVals[13])+"\n";
        report += "Bear.MAX_LITTER_SIZE = "+String.valueOf((int)(bestVals[14]))+"\n";
        report += "Eagle.BREEDING_AGE = "+String.valueOf((int)(bestVals[15]))+"\n";
        report += "Eagle.MAX_AGE = "+String.valueOf((int)(bestVals[16]))+"\n";
        report += "Eagle.BREEDING_PROBABILITY = "+String.valueOf(bestVals[17])+"\n";
        report += "Eagle.MAX_LITTER_SIZE = "+String.valueOf((int)(bestVals[18]))+"\n";
        report += "Fox.BREEDING_AGE = "+String.valueOf((int)(bestVals[19]))+"\n";
        report += "Fox.MAX_AGE = "+String.valueOf((int)(bestVals[20]))+"\n";
        report += "Fox.BREEDING_PROBABILITY = "+String.valueOf(bestVals[21])+"\n";
        report += "Fox.MAX_LITTER_SIZE = "+String.valueOf((int)(bestVals[22]))+"\n";
        report += "Mouse.BREEDING_AGE = "+String.valueOf((int)(bestVals[23]))+"\n";
        report += "Mouse.MAX_AGE = "+String.valueOf((int)(bestVals[24]))+"\n";
        report += "Mouse.BREEDING_PROBABILITY = "+String.valueOf(bestVals[25])+"\n";
        report += "Mouse.MAX_LITTER_SIZE = "+String.valueOf((int)(bestVals[26]))+"\n";
        report += "Mouse.FOOD_VALUE = "+String.valueOf((int)(bestVals[27]))+"\n";
        report += "Duck.BREEDING_AGE = "+String.valueOf((int)(bestVals[28]))+"\n";
        report += "Duck.MAX_AGE = "+String.valueOf((int)(bestVals[29]))+"\n";
        report += "Duck.BREEDING_PROBABILITY = "+String.valueOf(bestVals[30])+"\n";
        report += "Duck.MAX_LITTER_SIZE = "+String.valueOf((int)(bestVals[31]))+"\n";
        report += "Duck.FOOD_VALUE = "+String.valueOf((int)(bestVals[32]))+"\n";
        report += "Rabbit.BREEDING_AGE = "+String.valueOf((int)(bestVals[33]))+"\n";
        report += "Rabbit.MAX_AGE = "+String.valueOf((int)(bestVals[34]))+"\n";
        report += "Rabbit.BREEDING_PROBABILITY = "+String.valueOf(bestVals[35])+"\n";
        report += "Rabbit.MAX_LITTER_SIZE = "+String.valueOf((int)(bestVals[36]))+"\n";
        report += "Rabbit.FOOD_VALUE = "+String.valueOf((int)(bestVals[37]))+"\n";
        report += "Plant.GROWTH_MAX = "+String.valueOf((int)(bestVals[38]))+"\n";
        report += "Plant.FOOD_VALUE = "+String.valueOf((int)(bestVals[39]))+"\n";
        
        return report;
    }
    
    /**
     * Writes the current best configuration to the testerLogs.txt text file.
     */
    private void recordCurrentBest()
    {
        String report = generateReport();
        BufferedWriter writer = null;
        try {
            // Writing the best results to a text file so you can get back to them later
            File logFile = new File("testerLogs.txt");
            writer = new BufferedWriter(new FileWriter(logFile,true));
            writer.write(report);
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {writer.close();} catch (Exception e) {}
        }
    }
    
    /**
     * Prints the current best configuration to the terminal.
     */
    private void printCurrentBest()
    {
        String report = generateReport();
        System.out.println(report);
    }
}
