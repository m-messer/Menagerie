import java.util.List;
import java.util.Iterator;
import java.util.Set;

/**
 * A class representing shared characteristics of prey animals.
 *
 * @version 2019.02.21
 */
public abstract class Prey extends Animal
{
    /**
     * Create a new prey animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location, int maxAge)
    {
        super(field, location);
        setAge(0);
        if(randomAge) {
            setAge(rand.nextInt(maxAge));
            setFoodLevel(rand.nextInt(Plant.FOOD_VALUE));
        }
        else {
            setFoodLevel(Plant.FOOD_VALUE);
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first uneaten plant is eaten.
     * @param preyToEat null.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood(Set<String> preyToEat)
    {
        preyToEat = null;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Plant plant = field.getPlantAt(where);
            if(plant != null && !plant.getIsEaten()) {
                setFoodLevel(Plant.FOOD_VALUE);
                plant.getEaten();
                getField().addPlantToGrow(plant);
                return where;
            }
        }
        return null;
    }
}
