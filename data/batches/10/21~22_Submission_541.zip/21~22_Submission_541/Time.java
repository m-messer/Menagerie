/**
 * The current Time.
 * 
 *
 * @version 2022.02.25
 */
public enum Time {
    /**
     * The DAY Time.
     */
    DAY,

    /**
     * The Night Time.
     */
    NIGHT;

    /**
     * Returns the alternate Time.
     *
     * @param time The current time.
     * @return The alternate Time
     */
    public static Time switchTime(Time time)
    {
        if(time == DAY){
            return NIGHT;

        }else{
            return DAY;

        }
    }
}
