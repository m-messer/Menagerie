/**
 * AffectedActor helps to identify whether a disease object applies to a Plant or an Actor. 
 *
 * @version 2022.03.02
 */
public enum AffectedActor
{
    /**
     * This identifies the Plant Actor.
     */
    PLANT,

    /**
     * This identifies the Animal Actor.
     */
    ANIMAL;
}
