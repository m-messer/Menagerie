/**
 * The Gender for the Actors. 
 *
 * @version 2022.02.25
 */
public enum Gender {
    /**
     * The MALE gender.
     */
    MALE,

    /**
     * The FEMALE gender.
     */
    FEMALE,

    /**
     * The ASEXUAL Gender.
     * For plants like trees and algae.
     */
    ASEXUAL;
}
