/**
 * The Strength of the Disease.
 * 
 *
 * @version 2022.02.22
 */
public enum Strength 
{
    /**
     * The LOW strength.
     */
    LOW(0.03),

    /**
     * The MEDIUM strength.
     */
    MEDIUM(0.08),

    /**
     * The HIGH strength.
     */
    HIGH(0.15);

    private double strength;

    Strength(double strength)
    {
        this.strength = strength;
    }

    public double getStrength()
    {
        return strength;
    }
}
