/**
 * Main class to start the program.
 *
 * @version 2022.03.02
 */
public class Main 
{
    /**
     * Main method class SimulatorView class.
     */
    public static void main(String[] args)
    {
        new SimulatorView();
    }
}
