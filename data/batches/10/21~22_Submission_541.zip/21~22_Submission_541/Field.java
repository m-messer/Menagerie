import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * Represent a rectangular grid of field positions.
 * Each position is able to store a single actor.
 * Field class can retrieve locations based on
 * specific parameters such as actor gender and Prey.
 * Implements check to ensure actors are returned locations
 * within their allocated bounds.
 *
 * @version 2022.02.25
 */
public class Field
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();

    // The depth of the field
    private final int depth;

    // The width of the field
    private final int width;

    // Storage for the animals.
    private final Object[][] field;

    /**
     * Represent a field of the given dimensions.
     *
     * @param depth The depth of the field.
     * @param width The width of the field.
     */
    public Field(int depth, int width)
    {

        this.depth = depth;
        this.width = width;

        field = new Object[depth][width];
    }

    /**
     * Empty the field.
     */
    public void clear()
    {
        for (int row = 0; row < depth; row++) {
            for (int col = 0; col < width; col++) {
                field[row][col] = null;
            }
        }
    }

    /**
     * Generate a random location that is adjacent to the
     * given location, or is the same location.
     * The returned location will be within the valid bounds
     * of the field.
     *
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the defined bounds.
     */
    public Location randomAdjacentLocation(Location location, ArrayList<Bound> bounds, int searchDistance)
    {
        List<Location> adjacent = adjacentLocations(location, bounds, searchDistance);
        return adjacent.get(0);
    }

    /**
     * Get a shuffled list of the free adjacent locations.
     *
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */
    public List<Location> getFreeAdjacentLocations(Location location, ArrayList<Bound> bounds, int searchDistance)
    {
        // The list to be returned.
        List<Location> free = new LinkedList<>();

        // All the locations.
        List<Location> adjacent = adjacentLocations(location, bounds, searchDistance);

        for (Location next : adjacent) {
            if (getObjectAt(next) == null) {
                free.add(next);
            }
        }
        return free;
    }

    /**
     * Try to find a free location that is adjacent to the
     * given location. If there is none, return null.
     * The returned location will be within the valid defined bounds.
     *
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location freeAdjacentLocation(Location location, ArrayList<Bound> bounds, int searchDistance)
    {
        // The available free locations.
        List<Location> free = getFreeAdjacentLocations(location, bounds, searchDistance);

        if (free.size() > 0) {
            return free.get(0);
        } else {
            return null;
        }
    }

    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the defined bounds.
     *
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    public List<Location> adjacentLocations(Location location, ArrayList<Bound> bounds, int searchDistance)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of all locations.
        List<Location> allLocations = new LinkedList<>();

        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();

        if (location != null) {

            int row = location.getRow();
            int col = location.getCol();

            for (int roffset = (-1 * searchDistance); roffset <= (1 * searchDistance); roffset++) {

                int nextRow = row + roffset;

                if (nextRow >= 0 && nextRow < depth) {
                    for (int coffset = (-1 * searchDistance); coffset <= (1 * searchDistance); coffset++) {
                        int nextCol = col + coffset;
                        // Exclude invalid locations and the original location.
                        if (nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
                            allLocations.add(new Location(nextRow, nextCol));
                        }
                    }
                }
            }

            //Filter through the locations, to exclude those not within the predefined bounds.
            locations = allLocations.stream()
                    .filter(location1 -> Bound.isWithinBound(location1, bounds))
                    .collect(Collectors.toList());


            // Shuffle the list. Several other methods rely on the list
            // being in a random order.
            Collections.shuffle(locations, rand);
        }
        return locations;
    }

    /**
     * Return a list of adjacent locations with actors of a predefined
     * class. This will be within the defined bounds for the actor and
     * within a specified search distance.
     *
     * @param location       The location, from which to retreive adjacent locations.
     * @param bounds         The predefined bounds for the actor.
     * @param interestedIn   The class, the actor is interested in.
     * @param searchDistance The distance within the field to search, relative to the given location.
     * @return A list of adjacent locations, within a bound, with the specified actor.
     */
    public List<Location> adjacentLocations(Location location, ArrayList<Bound> bounds, Class[] interestedIn, int searchDistance)
    {

        // Get a list of adjacent locations.
        List<Location> adjacent = adjacentLocations(location, bounds, searchDistance);
        List<Location> adjacentWithInterestedEntity = new ArrayList<>();

        Iterator<Location> it = adjacent.iterator();

        while (it.hasNext()) {
            Location nextLocation = it.next();
            for (int i = 0; i < interestedIn.length; i++) {
                if (interestedIn[i].isInstance(getObjectAt(nextLocation))) {
                    // If the actor is an instance of the desired class add it to the list.
                    adjacentWithInterestedEntity.add(nextLocation);
                }
            }
        }

        return adjacentWithInterestedEntity;
    }

    /**
     * Retrieves a list of adjacent locations, within specified bounds
     * and a search distance, containing actors of a specific class
     * and gender.
     *
     * @param location       The location to retreive adjacent locations from.
     * @param bounds         The bounds to search within.
     * @param actorSpecies   The species of actor to be searched for.
     * @param gender         The gender of the required actors.
     * @param searchDistance The distance to search within the field.
     * @return A list of adjacent locations, with the specified gender and actors.
     */
    public List<Location> adjacentLocationOfGender(Location location, ArrayList<Bound> bounds, Class actorSpecies, Gender gender, int searchDistance)
    {
        // Get a list of adjacent locations with actors of a certain class.
        List<Location> adjacentWithSameActors = adjacentLocations(location, bounds, new Class[]{actorSpecies}, searchDistance);

        // Filter through the above list to retrieve the locations of actors of a certain gender.
        List<Location> adjacentRequiredActors = adjacentWithSameActors.stream()
                .map(loc -> getObjectAt(loc))
                .filter(obj -> obj != null)
                .filter(actor -> ((Actor) actor).getGender() == gender)
                .map(requiredActor -> (((Actor) requiredActor).getLocation()))
                .collect(Collectors.toList());

        return adjacentRequiredActors;
    }

    /**
     * Clear the given location.
     *
     * @param location The location to clear.
     */
    public void clear(Location location)
    {
        field[location.getRow()][location.getCol()] = null;
    }

    /**
     * Place an actor at the given location.
     * If there is already an actor at the location it will
     * be lost.
     *
     * @param actor The actor to be placed.
     * @param row   Row coordinate of the location.
     * @param col   Column coordinate of the location.
     */
    public void place(Object actor, int row, int col)
    {
        place(actor, new Location(row, col));
    }

    /**
     * Place an actor at the given location.
     * If there is already an actor at the location it will
     * be lost.
     *
     * @param actor    The actor to be placed.
     * @param location Where to place the actor.
     */
    public void place(Object actor, Location location)
    {
        field[location.getRow()][location.getCol()] = actor;
    }

    /**
     * Return the actor at the given location, if any.
     *
     * @param location Where in the field, the actor is located.
     * @return The actor at the given location, or null if there is none.
     */
    public Object getObjectAt(Location location)
    {
        return getObjectAt(location.getRow(), location.getCol());
    }

    /**
     * Return the actor at the given location, if any.
     *
     * @param row The desired row.
     * @param col The desired column.
     * @return The actor at the given location, or null if there is none.
     */
    public Object getObjectAt(int row, int col)
    {
        return field[row][col];
    }

    /**
     * Return the depth of the field.
     *
     * @return The depth of the field.
     */
    public int getDepth()
    {
        return depth;
    }

    /**
     * Return the width of the field.
     *
     * @return The width of the field.
     */
    public int getWidth()
    {
        return width;
    }
}