/**
 * An interface for the Actors who are the prey (Herbivores)
 *
 * @version 22.02.25
 */
public interface Prey 
{
    void findFood();
}