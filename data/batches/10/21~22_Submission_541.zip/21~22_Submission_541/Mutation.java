/**
 * This represents the type of the mutation for the Actors. 
 *
 * @version 2022.03.02
 */
public enum Mutation
{
    /**
     * Affects the breeding probability of the Actor.
     */
    BREEDING_PROBABILITY,

    /**
     * Affects the breeding age of the Actor.
     */
    BREEDING_AGE,

    /**
     * Affects the max litter size of the Actor.
     */
    MAX_LITTER_SIZE;
}
