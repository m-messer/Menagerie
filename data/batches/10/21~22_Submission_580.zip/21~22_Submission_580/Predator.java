import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of predators.
 * These age, move, breed, eat, and die.
 *
 * @version 20/02/2022
 */
public abstract class Predator extends Animal
{
    // Characteristics shared by all predators (class variables).
    
    // The age at which a predator can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a predator can live.
    private static final int MAX_AGE = 150;
    // The initial food level of a predator.
    private static final int DEFAULT_FOOD_LEVEL = 10;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The predator's food level, which is increased by eating.
    // In effect, this is the number of steps a predator can go before it has to eat again.
    // private int foodLevel;
    
    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(field, location, DEFAULT_FOOD_LEVEL);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        }
        else {
            setAge(0);
        }
    }
    
    /**
     * Return the breeding age for predators.
     * @return the breeding age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Predators sleep from 4am to 10pm.
     */
    protected boolean isWoke()
    {
        int current_time = getTime();
        return current_time>=4 && current_time<=22;
    }
    
    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newPredators A list to return newly born redators.
     */
    public void act(List<LivingOrganism> newPredators)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && isWoke()) {
            giveBirth(newPredators);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age. This could result in the predator's death.
     */
    protected void incrementAge()
    {
        setAge(getAge() + 1);
        if(getAge() > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
}
