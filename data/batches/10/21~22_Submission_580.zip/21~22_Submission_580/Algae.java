import java.util.List;
import java.util.Random;

/**
 * A simple model of algae.
 * Algae can grow, spread and die.
 *
 * @version 23/02/2022
 */
public class Algae extends LivingOrganism
{
    // Characteristics shared by all algae (class variables).
    
    // Chance of algae spreading 
    private static final double SPREADING_PROBABILITY = 0.99;
    // Growing counter 
    private static final int SPREADING_GROWTH = 1;
    // Age for death 
    private static final int MAX_GROWTH = 9;
    
    // Individual characteristics (instance fields).
    
    // Growth counter
    private int growthCounter;
    
    /**
     * Create new algae.
     * 
     * @param   field       The field currently occupied.
     * @param   location    The location within the field.
     */
    public Algae(Field field, Location location)
    {
        super(field, location);
        // initialise instance variables
        growthCounter = 0;
    }

    /**
     * This is what algae does most of the time - they grow and spread.
     * They only grow during the day (5am to 6pm).
     *
     * @param   newAlgae    A list to return new algae.
     */
    public void act(List<LivingOrganism> newAlgae)
    {
        // Day time growth from 5am to 6pm
        int currentTime = getTime();
        if (currentTime>=0 && currentTime<16){       
            incrementGrowth();
    
            if(isAlive()){
                algaeSpread(newAlgae);
                //Try move into a free location
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null){
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * Method to allow algae to spread once it has reached the max growth 
     * 
     * @param   newAlgae    A list to return newly grown algae.
     */
    public void algaeSpread(List<LivingOrganism> newAlgae)
    {
        // New algae is spread into adjacent locations.
        // Get a list of asjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        Random rand = new Random();
        int random_spread = rand.nextInt(2);     // max number of algae to grow out
        
        if(growthCheck()){
            for(int b = 0; b < random_spread && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Algae young = new Algae(field, loc);
                newAlgae.add(young);   
            }
        }
    }
    
    /**
     * Method to increment the growth counter of the plant
     */
    public void incrementGrowth()
    {
        growthCounter++;
        if(growthCounter >= MAX_GROWTH){
              setDead();
        }
    }
    
    /**
     * Method to check if algae is grown enough to be eaten
     * 
     * @return  True if algae is grown enough to be eaten
     */
    public boolean growthCheck()
    {
        return growthCounter >= SPREADING_GROWTH;
    }
}
