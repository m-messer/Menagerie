import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an orca.
 * Orcas are an apex predator of this model.
 * Orcas age, move, breed, eat, and die.
 *
 * @version 16/02/2022
 */
public class Orca extends Predator
{
    // Characteristics shared by all orcas (class variables).
    
    // The likelihood of an orca breeding.
    private static final double BREEDING_PROBABILITY = 0.5;    // originally 0.08
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of prey.
    private static final int FOOD_VALUE = 40;
    
    // Individual characteristics (instance fields).
    
    /**
     * Create an orca. An orca can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the orca will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Orca(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Get the breeding probability of the orca.
     * @return the orca's breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Get the maximum litter size of the orca.
     * @return the orca's maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Check whether or not this orca is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrcas A list to return newly born orcas.
     */
    protected void giveBirth(List<LivingOrganism> newOrcas)
    {
        // New orcas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Orca young = new Orca(false, field, loc);
            newOrcas.add(young);
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Penguin) {
                Penguin penguin = (Penguin) animal;
                if(penguin.isAlive()) { 
                    penguin.setDead();
                    if(FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(FOOD_VALUE);
                    }
                    return where;
                }
            }
            else if(animal instanceof Squid) {
                Squid squid = (Squid) animal;
                if(squid.isAlive()) { 
                    squid.setDead();
                    if(FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(FOOD_VALUE);
                    }
                    return where;
                }
            }
            else if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setDead();
                    if(FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(FOOD_VALUE);
                    }
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * An orca can breed if it has reached the breeding age and if there is an orca of the
     * opposite sex in an adjacent location.
     * @return true if an orca can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return (getAge() >= getBreedingAge()) && adjacentPartner("Orca");
    }
}
