import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a penguin.
 * Penguins age, move, breed, eat and die.
 *
 * @version 16/02/2022
 */
public class Penguin extends Predator
{
    // Characteristics shared by all penguins (class variables).
    
    // The likelihood of a penguin breeding.
    private static final double BREEDING_PROBABILITY = 0.3;    // originally 0.25
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single squid.
    private static final int SQUID_FOOD_VALUE = 15;
    // The food value of a single fish.
    private static final int FISH_FOOD_VALUE = 15;
    
    // Individual characteristics (instance fields).
    
    /**
     * Create a new penguin.
     * 
     * @param randomAge If true, the penguin will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Penguin(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Get the breeding probability of the penguin.
     * @return the penguin's breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Get the maximum litter size of the penguin.
     * @return the penguin's maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Check whether or not this penguin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPenguins A list to return newly born penguin.
     */
    protected void giveBirth(List<LivingOrganism> newPenguins)
    {
        // New penguins are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Penguin young = new Penguin(false, field, loc);
            newPenguins.add(young);
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setDead();
                    if(FISH_FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(FISH_FOOD_VALUE);
                    }
                    return where;
                }
            }
            else if(animal instanceof Squid) {
                Squid squid = (Squid) animal;
                if(squid.isAlive()) { 
                    squid.setDead();
                    if(SQUID_FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(SQUID_FOOD_VALUE);
                    }
                    return where;
                }
            }
        }
        return null;
    }    
    
    /**
     * A penguin can breed if it has reached the breeding age and if there 
     * is a penguin of the opposite sex in an adjacent location.
     * @return true if the penguin can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return (getAge() >= getBreedingAge()) && adjacentPartner("Penguin");
    }
}