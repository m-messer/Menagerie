import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 16/02/2022
 */
public abstract class Animal extends LivingOrganism
{
    // The flag for the animal's sex.
    private boolean female;
    // The animal's age.
    private int age;
    // The animal's food level, which is increased by eating.
    private int foodLevel;
    // In effect, this is the number of steps a predator can go before it has to eat again.
    
    /**
     * Create a new animal at location in field.
     * 
     * @param   field           The field currently occupied.
     * @param   location        The location within the field.
     * @param   foodLevelNumber The level of food the animal can eat.
     */
    public Animal(Field field, Location location, int foodLevelNumber)
    {
        super(field, location);
        // randomise the sex of the animal
        Random rand = Randomizer.getRandom();
        female = rand.nextBoolean();
        foodLevel = foodLevelNumber;
    }
    
    /**
     * Get the breeding probability of the animal.
     * 
     * @return  The animal's breeding probability.
     */
    protected abstract double getBreedingProbability();
    
    /**
     * Get the maximum litter size of the animal.
     * 
     * @return  The animal's maximum litter size.
     */
    protected abstract int getMaxLitterSize();      
    
    /**
     * Make this animal act - that is: make it do whatever it 
     * wants/needs to do.
     * 
     * @param   newAnimals  A list to receive newly born animals.
     */
    abstract public void act(List<LivingOrganism> newAnimals);

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param   newAnimals  A list to return newly born animals.
     */
    protected abstract void giveBirth(List<LivingOrganism> newAnimals); 
    
    /**
     * A herbivore can breed if it has reached the breeding age and if there 
     * is a herbivore of the opposite sex in an adjacent location.
     * 
     * @return  True if the herbivore can breed, false otherwise.
     */
    protected abstract boolean canBreed();    

    /**
     * Check whether the animal is a female or not.
     * 
     * @return  True if the animal is a female, false otherwise.
     */
    protected boolean isFemale()
    {
        return female;
    }
    
    /**
     * Set the animal's age.
     * 
     * @param   age The chosen age of the animal.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * Return the animal's age.
     * 
     * @return  The animal's age.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Get the food level.
     * 
     * @return  The predator's food level.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the food level.
     * 
     * @param   level   The new food level.
     */
    protected void setFoodLevel(int level)
    {
        foodLevel = level;
    }
    
    /**
     * Make this predator more hungry. This could result in the predator's death.
     */
    protected void incrementHunger()
    {
        if(isWoke()){
            foodLevel--;
            if(foodLevel <= 0) {
                setDead();
            }
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * 
     * @return  Where food was found, or null if it wasn't.
     */
    protected abstract Location findFood();
    
    /**
     * Check if the animal is woke and therefore can proceed with moving, eating, etc.
     * 
     * @return  True if the animal is awake, false otherwise.
     */
    protected abstract boolean isWoke();
    
    /**
     * Checks if there is an animal of the opposite sex in an adjacent location.
     * 
     * @param   name    The name of the species of the animal that is looking for a partner.
     * @return  True if there is an animal of the opposite sex in an adjacent location.
     */
    protected boolean adjacentPartner(String name)
    {
        Field field = getField();

        // Put every location adjacent to the animal in a list
        List<Location> adjacent = field.adjacentLocations(getLocation());

        for(Location location: adjacent){
            // Cast the object at each location as a LivingOrganism object
            LivingOrganism adjacentOrganism = (LivingOrganism) field.getObjectAt(location);
            
            if(adjacentOrganism != null && adjacentOrganism instanceof Animal){
                // Check that the organism is not null and an animal, then cast if true
                Animal adjacentAnimal = (Animal) adjacentOrganism;
                
                // Check the adjacent animal's gender and assign it to this variable
                boolean a = adjacentAnimal.isFemale();
                // Check THIS animal's gender and assign it to this variable
                boolean b = this.isFemale();
                
                if((adjacentOrganism.getOrganismName().equals(name))
                    // Check if the adjacent animal is of the same specifies
                    && (a != b)){
                    // Mating only happens with the opposite sex
                    return true;
                }
            }
        }
        
        // If no conditions are met
        return false;
    }
}