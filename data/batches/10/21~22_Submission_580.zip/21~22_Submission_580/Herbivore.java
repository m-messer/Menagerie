import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of herbivores.
 * Herbivores only eat plants.
 * Herbivores age, move, breed, and die.
 *
 * @version 18/02/2022
 */
public abstract class Herbivore extends Animal
{
    // Characteristics shared by all herbivores (class variables).

    // The age at which a herbivore can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a herbivore can live.
    private static final int MAX_AGE = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The initial food level of a herbivore.
    private static final int DEFAULT_FOOD_LEVEL = 5;
    
    // Individual characteristics (instance fields).
    
    /**
     * Create a new herbivore. A herbivore may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the herbivore will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Herbivore(boolean randomAge, Field field, Location location)
    {
        super(field, location, DEFAULT_FOOD_LEVEL);
        setAge(0);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        }
    }
    
    /**
     * Return the breeding age for herbivores.
     * @return the breeding age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }  
    
    /**
     * Hervibores sleep from 11pm to 3am.
     */
    protected boolean isWoke()
    {
        int current_time = getTime();
        return current_time>=0 && current_time<22;
    }
    
    /**
     * This is what the herbivore does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newHerbivores A list to return newly born herbivores.
     */
    public void act(List<LivingOrganism> newHerbivores)
    {
        incrementAge(); 
        incrementHunger();
        if(isAlive() && isWoke()) {
            giveBirth(newHerbivores); 
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age.
     * This could result in the herbivore's death.
     */
    protected void incrementAge()
    {
        setAge(getAge() + 1);
        if(getAge() > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    

}
