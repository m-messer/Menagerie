import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a squid.
 * Squids age, move, breed, and die.
 *
 * @version 23/02/2022
 */
public class Squid extends Herbivore
{
    // Characteristics shared by all squids (class variables).
    
    // The likelihood of a squid breeding.
    private static final double BREEDING_PROBABILITY = 0.99;    // originally 0.12
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of a single algae
    private static final int ALGAE_FOOD_VALUE = 15;
    
    // Individual characteristics (instance fields).
    
    /**
     * Create a new squid.
     * 
     * @param randomAge If true, the squid will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Squid(boolean randomAge, Field field, Location location)
    {        
        super(randomAge, field, location);
    }
    
    /**
     * Return the breeding probability for squids.
     * @return the breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum litter size for squids.
     * @return the maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }    
    
    /**
     * Check whether or not this squid is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSquid A list to return newly born squid.
     */
    protected void giveBirth(List<LivingOrganism> newSquid)
    {
        // New squid are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Squid young = new Squid(false, field, loc);
            newSquid.add(young);
        }
    }
    
    /**
     * A squid can breed if it has reached the breeding age and if there 
     * is a squid of the opposite sex in an adjacent location.
     * @return true if the squid can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return (getAge() >= getBreedingAge()) && adjacentPartner("Squid");
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Algae) {
                Algae algae = (Algae) plant;
                if(algae.isAlive()) {           //algae.growthCheck()
                    algae.setDead();
                    if(ALGAE_FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(ALGAE_FOOD_VALUE);
                    }
                    return where;
                }
            }
        }
        return null;
    }
}