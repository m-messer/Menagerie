import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a seal.
 * Seals are an apex predator of this model.
 * Seals age, move, breed, eat, and die.
 *
 * @version 16/02/2022
 */
public class Seal extends Predator
{
    // Characteristics shared by all seals (class variables).
    
    // The likelihood of an seal breeding.
    private static final double BREEDING_PROBABILITY = 0.5;    // originally 0.08
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of prey.
    private static final int FOOD_VALUE = 40;
    
    // Individual characteristics (instance fields).
    
    /**
     * Create a seal. A seal can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the seal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seal(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Get the breeding probability of the seak.
     * @return the seal's breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Get the maximum litter size of the seal.
     * @return the seal's maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Check whether or not this seal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSeals A list to return newly born seals.
     */
    protected void giveBirth(List<LivingOrganism> newSeals)
    {
        // New seals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seal young = new Seal(false, field, loc);
            newSeals.add(young);
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Penguin) {
                Penguin penguin = (Penguin) animal;
                if(penguin.isAlive()) { 
                    penguin.setDead();
                    if(FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(FOOD_VALUE);
                    }
                    return where;
                }
            }
            else if(animal instanceof Squid) {
                Squid squid = (Squid) animal;
                if(squid.isAlive()) { 
                    squid.setDead();
                    if(FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(FOOD_VALUE);
                    }
                    return where;
                }
            }
            else if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setDead();
                    if(FOOD_VALUE > getFoodLevel()){
                        setFoodLevel(FOOD_VALUE);
                    }
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * A seal can breed if it has reached the breeding age and if there is a seal of the
     * opposite sex in an adjacent location.
     * @return true if a seal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return (getAge() >= getBreedingAge()) && adjacentPartner("Seal");
    }
}