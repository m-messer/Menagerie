import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of living organisms.
 *
 * @version 23/02/2022
 */
public abstract class LivingOrganism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // Time counter.
    private static int timeCounter;
    
    /**
     * Create a new organism at a location in field.
     * 
     * @param   field       The field currently occupied.
     * @param   location    The location within the field.
     */
    public LivingOrganism(Field field, Location location)
    {
        // initialise instance variables
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Set the time.
     * 
     * @param   time    The chosen time.
     */
    public void setTime(int time)
    {
        timeCounter = time;
    }
    
    /**
     * The time of the day (using the step counter)
     * 
     * @return  The time of day.
     */
    public int getTime()
    {
        return timeCounter;
    } 
    
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param   newOrganisms    A list to receive new organisms.
     */
    abstract public void act(List<LivingOrganism> newOrganisms);
    
    /**
     * Return the name of the organism.
     * 
     * @return  The name of the organism.
     */
    protected String getOrganismName()
    {
        return this.getClass().getSimpleName();
    }
    
    /**
     * Check whether the organism is alive or not.
     * 
     * @return  True if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * 
     * @return  The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * 
     * @param   newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * 
     * @return  The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
