import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing penguins and orcas.
 *
 * @version 23/02/2022
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that an orca will be created in any given grid position.
    private static final double ORCA_CREATION_PROBABILITY = 0.01;   // was 0.02 then was 0.01
    // The probability that a seal will be created in any given grid position.
    private static final double SEAL_CREATION_PROBABILITY = 0.01;   // was 0.02 then was 0.01
    // The probability that a penguin will be created in any given grid position.
    private static final double PENGUIN_CREATION_PROBABILITY = 0.03;    // was 0.08 then was 0.02
    // The probability that a squid will be created in any given grid position.
    private static final double SQUID_CREATION_PROBABILITY = 0.045;   //was 0.04
    // The probability that a fish will be created in any given grid position.
    private static final double FISH_CREATION_PROBABILITY = 0.045;   //was 0.08
    // The probability that algae will be created in any given grid position.
    private static final double ALGAE_CREATION_PROBABILITY = 0.1;

    // List of organisms in the field.
    private List<LivingOrganism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;  
    // A graphical view of the simulation.
    private List<SimulatorView> views;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        views = new ArrayList<>();
        
        SimulatorView view1 = new GridView(depth, width);
        view1.setColor(Orca.class, Color.BLACK);
        view1.setColor(Seal.class, Color.RED);
        view1.setColor(Penguin.class, Color.ORANGE);
        view1.setColor(Squid.class, Color.PINK);
        view1.setColor(Fish.class, Color.BLUE);
        view1.setColor(Algae.class, Color.GREEN);
        views.add(view1);
        
        SimulatorView view2 = new GraphView(500, 150, 500);
        view2.setColor(Orca.class, Color.BLACK);
        view2.setColor(Seal.class, Color.RED);
        view2.setColor(Penguin.class, Color.ORANGE);
        view2.setColor(Squid.class, Color.PINK);
        view2.setColor(Fish.class, Color.BLUE);
        view2.setColor(Algae.class, Color.GREEN);
        views.add(view2);

        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (2000 steps).
     */
    public void runLongSimulation()
    {
        simulate(2000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 0; step <= numSteps && views.get(0).isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * orca and penguin.
     */
    public void simulateOneStep()
    {
        int stepValue = step;
        step++;
        
        // Provide space for newborn animals.
        List<LivingOrganism> newOrganism = new ArrayList<>();        
        // Let all organisms act.
        for(Iterator<LivingOrganism> it = organisms.iterator(); it.hasNext(); ) {
            LivingOrganism organism = it.next();
            
            if(stepValue%10 == 0){    
                organism.setTime((stepValue%240)/10);
            }
            
            organism.act(newOrganism);
            
            if(! organism.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganism);

        updateViews();
    }  
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        for (SimulatorView view : views) {
            view.reset();
        }

        populate();
        updateViews();
    }
    
    /**
     * Update all existing views.
     */
    private void updateViews()
    {
        for (SimulatorView view : views) {
            view.showStatus(step, field);
        }
    }
    
    /**
     * Randomly populate the field with orcas, penguins, squid and fish.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= ORCA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Orca orca = new Orca(true, field, location);
                    organisms.add(orca);
                }
                else if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location);
                    organisms.add(seal);
                }
                else if(rand.nextDouble() <= PENGUIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Penguin penguin = new Penguin(true, field, location);
                    organisms.add(penguin);
                }
                else if(rand.nextDouble() <= SQUID_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squid squid = new Squid(true, field, location);
                    organisms.add(squid);
                }
                else if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fish fish = new Fish(true, field, location);
                    organisms.add(fish);
                }
                else if(rand.nextDouble() <= ALGAE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Algae algae = new Algae(field, location);
                    organisms.add(algae);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
