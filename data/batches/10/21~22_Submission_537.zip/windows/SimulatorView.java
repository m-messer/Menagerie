package windows;

import engine.Location;
import engine.field.Field;
import engine.field.FieldStats;
import engine.helpers.FileProperties;
import engine.helpers.PropertyFileReader;
import environment.Viewable;
import environment.food.Entity;
import org.jdesktop.swingx.StackLayout;
import windows.components.JTextPrompt;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2022.03.03
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    // Map for Viewable object display colours.
    private final Map<Class<? extends Viewable>, Color> COLOR_MAP = new HashMap<>();

    private final String STEP_PREFIX = "Step: ";
    private final String DEFAULT_FONT_NAME = new JLabel().getFont().getName();
    private final String POPULATION_PREFIX = "Population - ";
    private JLabel stepLabel, population, infoLabel;
    private FieldView fieldView;

    // UI elements which should have their behaviours defined externally/be used to define behaviour.
    private JTextField stepField = new JTextField();
    private JLabel timeOfDayLabel = new JLabel("Time: MORNING");
    private JLabel diseaseLabel = new JLabel("Infected: None");
    private JLabel weatherLabel = new JLabel("Weather: Clear");
    private JLabel plantLabel = new JLabel("Plants: None");
    private JLabel structureLabel = new JLabel("Structures: None");
    private JButton oneStepButton = new JButton("Simulate One Step");
    private JButton longSimButton = new JButton("Simulate Multiple Steps");
    private JButton resetFieldButton = new JButton("Reset Simulation");

    // A statistics object computing and storing simulation information
    private FieldStats stats;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();

        setTitle("Field Simulation");
        stepLabel = new JLabel(STEP_PREFIX+"Loading", JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX+"Loading", JLabel.CENTER);

        setLocation(100, 50);

        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        JPanel detailsPane = new JPanel(new BorderLayout());
        JPanel buttonHolder = new JPanel(new GridBagLayout());

        JPanel titleAndControls = new JPanel(new GridBagLayout());

        GridBagConstraints titleConstraints = new GridBagConstraints();
        titleConstraints.fill = GridBagConstraints.BOTH;
        titleConstraints.insets = new Insets(0, 5, 5, 5);
        titleConstraints.gridx = 0;
        titleConstraints.gridy = 0;

        Label titleLabel = new Label("Details");
        titleLabel.setFont(new Font(DEFAULT_FONT_NAME, Font.BOLD, 32));
        titleLabel.setAlignment(Label.CENTER);
        titleAndControls.add(titleLabel, titleConstraints);

        detailsPane.add(stepLabel, BorderLayout.SOUTH);

        // Specify GridBagConstraints.

        GridBagConstraints columnConstraint = new GridBagConstraints();
        columnConstraint.fill = GridBagConstraints.BOTH;
        columnConstraint.insets = new Insets(5, 5, 5, 5);
        columnConstraint.gridx = 0;
        columnConstraint.gridy = GridBagConstraints.RELATIVE;

        // Add buttons to holder.

        GridBagConstraints controlConstraints = new GridBagConstraints();
        controlConstraints.insets = new Insets(0, 5, 5, 5);
        controlConstraints.fill = GridBagConstraints.BOTH;
        controlConstraints.gridx = 0;
        controlConstraints.gridy = 1;

        JTextPrompt stepsPrompt = new JTextPrompt(new JLabel("Steps: "), stepField);
        buttonHolder.add(oneStepButton, columnConstraint);
        columnConstraint.insets = new Insets(5, 0, 5, 5);
        buttonHolder.add(stepsPrompt, columnConstraint);
        columnConstraint.insets = new Insets(5, 5, 5, 5);
        buttonHolder.add(longSimButton, columnConstraint);
        buttonHolder.add(resetFieldButton, columnConstraint);
        buttonHolder.add(plantLabel, columnConstraint);
        buttonHolder.add(diseaseLabel, columnConstraint);
        buttonHolder.add(structureLabel, columnConstraint);
        buttonHolder.add(timeOfDayLabel, columnConstraint);
        buttonHolder.add(weatherLabel, columnConstraint);
        titleAndControls.add(buttonHolder, controlConstraints);

        detailsPane.add(titleAndControls, BorderLayout.NORTH);

        // Add panes to the window.

        //JPanel infoPane = new JPanel(new BorderLayout());
        //infoPane.add(infoLabel, BorderLayout.CENTER);

        // Create loading container for the main view.
        JPanel stackPane = new JPanel(new StackLayout());
        JLabel loadingLabel = new JLabel("Building Field...");
        loadingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        stackPane.add(loadingLabel);
        stackPane.add(fieldView);

        //contents.add(infoPane, BorderLayout.NORTH);
        contents.add(detailsPane, BorderLayout.WEST);
        contents.add(stackPane, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);
        pack();
        setVisible(true);
    }

    public void check() {
        System.out.println(oneStepButton.getActionListeners().length == 1);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Entity entity) {
        Color col = COLOR_MAP.get(entity.getClass());
        if(col == null) {
            PropertyFileReader reader = new PropertyFileReader(entity.getPropertyFile());
            String[] row = reader.getRow(entity.getClass().getSimpleName());
            String[] colValues = reader.getValueByColumn(row, FileProperties.DISPLAY_COLOUR).split(PropertyFileReader.SECONDARY_DELIMITER);
            int[] rgbValues = new int[3];
            for (int i = 0; i < colValues.length; i++) rgbValues[i] = Integer.parseInt(colValues[i]);
            col = new Color(rgbValues[0], rgbValues[1], rgbValues[2]);
            COLOR_MAP.put(entity.getClass(), col);
        }
        return col;
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }

        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();

        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Entity entity = field.getEntityAt(new Location(row, col));
                try {
                    //System.out.println("step "+step+" - "+new Location(row, col)+": "+entity.getClass().getSimpleName());
                    if(entity != null) {
                        stats.incrementCount(entity.getClass());
                        fieldView.drawMark(col, row, getColor(entity));
                    }
                    else {
                        fieldView.drawMark(col, row, EMPTY_COLOR);
                    }
                }
                catch (NullPointerException ignored) {}
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    // Methods to define button behaviour.

    public JTextField getSimStepsField() {
        return stepField;
    }

    public JLabel getTimeOfDayLabel() {
        return timeOfDayLabel;
    }

    public JLabel getDiseaseLabel() {
        return diseaseLabel;
    }
    
    public JLabel getStructureLabel() {
        return structureLabel;
    }

    public JLabel getWeatherLabel() {
        return weatherLabel;
    }

    public JLabel getPlantLabel() {
        return plantLabel;
    }

    public JButton getOneStepButton() {
        return oneStepButton;
    }

    public JButton getLongSimButton() {
        return longSimButton;
    }

    public JButton getResetFieldButton() {
        return resetFieldButton;
    }

    /**
     * Provide a graphical view of a rectangular field. This is
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                    gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if (!size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}

