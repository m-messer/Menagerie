package windows.components;

import javax.swing.*;
import java.awt.*;

/**
 * This is a simple class to hold a TextField next to a prompt.
 * @version 2022.03.02
 */
public class JTextPrompt extends JPanel {

    private JLabel prompt;
    private JTextField textField;

    public JTextPrompt(JLabel prompt, JTextField textField) {
        this.prompt = prompt;
        this.textField = textField;
        super.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        arrange();
    }

    private void arrange() {
        super.add(prompt);
        super.add(textField);
    }
}
