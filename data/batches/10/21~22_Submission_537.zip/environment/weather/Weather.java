package environment.weather;

/**
 * This is a simple container for Weather conditions which could affect the simulation.
 * Currently, weather only affects the growth of Producers.
 * @version 2022.03.02
 */
public abstract class Weather {

    Weather() {}

}
