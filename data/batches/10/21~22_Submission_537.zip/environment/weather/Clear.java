package environment.weather;

/**
 * Container class for clear weather conditions.
 * @version 2022.03.02
 */
public class Clear extends Weather {

    public Clear() {
        super();
    }
}
