package environment.weather;

/**
 * Container class for heatwave-esque weather conditions.
 * @version 2022.03.02
 */
public class Heatwave extends Weather {

    public Heatwave() {
        super();
    }
}
