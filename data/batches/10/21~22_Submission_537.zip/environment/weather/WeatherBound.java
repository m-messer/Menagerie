package environment.weather;

/**
 * This interface is to define classes which should be affected
 * by weather conditions in one way or another.
 * @version 2022.03.02
 */
public interface WeatherBound {

    /**
     * Establish how growth is affected by the weather.
     */
    void buildCreationMap();

    /**
     * Establish how death is affected by the weather.
     */
    void buildRemovalMap();

    /**
     * @return a modifier for creation chance based on weather conditions.
     */
    double getCreationModifier(Class<? extends Weather> weather);

    /**
     * @return a modifier for removal chance based on weather conditions.
     */
    double getRemovalModifier(Class<? extends Weather> weather);
}
