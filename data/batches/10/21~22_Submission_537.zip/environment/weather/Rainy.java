package environment.weather;

/**
 * Container class for rainy weather conditions.
 * @version 2022.03.02
 */
public class Rainy extends Weather {

    public Rainy() {
        super();
    }
}
