package environment.food;

import engine.Location;
import engine.field.FieldCell;
import engine.helpers.ListSet;
import environment.PropertyFileBound;
import environment.Viewable;
import environment.factors.diseases.Disease;

import java.util.List;

public interface Entity extends Food, Viewable, PropertyFileBound {

    /**
     * @return the probability that an entity will be created
     * on some board space.
     */
    double getCreationProbability();

    /**
     * @return the diseases this entity is carrying.
     */
    ListSet<Disease> getDiseases();

    /**
     * @return true if the animal is already carrying a disease of this type.
     */
    boolean diseasesContains(Class<? extends Disease> aClass);

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     */
    List act();

    /**
     * @return the location of this entity.
     */
    Location getLocation();

    /**
     * @return true if this entity should act.
     */
    boolean isActive();

    /**
     * Check whether the entity is alive or not.
     * @return true if the entity is still alive.
     */
    boolean isAlive();

    /**
     * Makes the entity die.
     */
    void setDead();

    /**
     * Defines whether an Entity can breed or not on this step.
     */
    void allowBreeding(boolean value);

    /**
     * Makes the Entity use some stamina.
     */
    void useStamina();

    /**
     * Method to allow Entities to eat other foods.
     */
    void consume(Food food);
    
    /**
     * @return this entity's location in the field.
     */
    FieldCell getFieldCell();
}
