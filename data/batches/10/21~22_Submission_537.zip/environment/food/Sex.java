package environment.food;

import engine.helpers.Randomizer;

/**
 * This class is to signpost objects which should have
 * some assignable value for sex.
 * @version 2022.03.01
 */
public interface Sex {

    /**
     * @return a random binary sex.
     */
    static SexValue getBinarySex() {
        SexValue[] values = {SexValue.MALE, SexValue.FEMALE};
        return values[Randomizer.getRandom().nextInt(values.length)];
    }

}
