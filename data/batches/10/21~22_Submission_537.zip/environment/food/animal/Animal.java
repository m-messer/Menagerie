package environment.food.animal;

import engine.field.TimeOfDay;
import engine.helpers.FileProperties;
import engine.helpers.ListSet;
import engine.helpers.ClassSet;
import engine.helpers.Randomizer;
import engine.field.Field;
import engine.field.FieldCell;
import engine.Location;
import engine.helpers.PropertyFileReader;
import environment.factors.EnvironmentalFactor;
import environment.factors.diseases.Disease;
import environment.factors.diseases.effects.DiseaseEffect;
import environment.factors.diseases.effects.EffectActor;
import environment.food.*;
import environment.food.producer.Producer;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.URISyntaxException;
import java.util.*;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A class representing shared characteristics of animals.
 * @version 2022.02.27
 */
public abstract class Animal implements Entity, Sex {

    private static final String PROPERTY_FILE_NAME = "animalProperties.csv";
    private static final Random RAND = Randomizer.getRandom();
    // Multiply the consumption rate by this if an Animal is not acting.
    private static final double NON_ACTING_CONSUMPTION_MODIFIER = 0.5;

    /**
     * Animal property variables. The values for these should be acquired
     * from animalProperties.csv.
     */

    // The age at which a fox can start to breed.
    protected int breedingAge;
    // The age to which a fox can live.
    protected int maxAge;
    // The likelihood that a fox will appear on the field.
    protected double creationProbability;
    // The likelihood of a fox breeding.
    protected double breedingProbability;
    // The maximum number of births.
    protected int maxLitterSize;
    // The food value of a single instance of this Animal. In effect, this is the
    // number of steps an Animal which eats this one can go before it has to eat again.
    protected int foodValue;
    // The time a female animal should wait before giving birth.
    protected int birthTime;

    /**
     * These fields should be defined in the subclass.
     */

    protected final Set<TimeOfDay> OPERATING_TIMES;        // The times that this animal should act.
    protected final Set<Class<? extends Food>> FOOD_EATEN; // The set of foods this animal eats.
    protected final float MAX_FOOD_VALUE;                    // The maximum amount of food this animal can hold at once.
    protected final float FOOD_CONSUMPTION_RATE;           // The amount of food consumed per simulation step.

    /**
     * Instance variables for simulation.
     */

    // The sex of the animal.
    protected final SexValue sex;
    // The amount of food the animal has.
    protected float currentFoodValue;
    // The current age of this Animal.
    protected int age;
    // Whether the animal is alive or not.
    protected boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;
    // Determines whether the animal is currently fertile.
    protected boolean canBreed;
    // A pregnancy the Animal may be carrying.
    protected Pregnancy pregnancy;
    // A set of the diseases this Animal is currently holding.
    protected ListSet<Disease> diseasesHeld;

    /**
     * Creates an Animal purely for using utility
     * methods such as getPropertyFile().
     */
    public Animal() {
        FOOD_EATEN = new LinkedHashSet<>();
        MAX_FOOD_VALUE = 0;
        FOOD_CONSUMPTION_RATE = 0;
        OPERATING_TIMES = new HashSet<>();
        sex = SexValue.NON_BINARY;
        diseasesHeld = new ListSet<>();
    }

    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxFoodValue The maximum amount of food this animal can hold.
     * @param consumptionRate The base rate at which this animal uses energy.
     * @param randomAge Should the Animal have a random starting age?
     * @param sex The sex of this Animal.
     * @param operatingTimes The times at which this animal can act.
     */
    protected Animal(Field field, Location location, Set<Class<? extends Food>> foodEaten, float maxFoodValue,
                     float consumptionRate, boolean randomAge, SexValue sex, Set<TimeOfDay> operatingTimes)
    {
        initialiseValues();
        this.alive = true;
        this.field = field;
        this.FOOD_EATEN = foodEaten;
        this.MAX_FOOD_VALUE = maxFoodValue;
        this.FOOD_CONSUMPTION_RATE = consumptionRate;
        this.age = randomAge ? Randomizer.getRandom().nextInt(maxAge) : 0;
        this.currentFoodValue = this.foodValue;
        this.sex = sex;
        this.OPERATING_TIMES = operatingTimes;
        this.pregnancy = new Pregnancy();
        this.diseasesHeld = new ListSet<>();
        allowBreeding(true);
        setLocation(location);
    }

    /**
     * @return the animalProperties.csv resource file.
     */
    @Override
    public File getPropertyFile() {
        return new File(PROPERTY_FILE_NAME);
    }

    /**
     * Every animal in the field will act on each simulation step.
     */
    @Override
    public List<Animal> act()
    {
        List<Animal> newAnimals = new ArrayList<>();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (pregnancy.isViable()) {
                pregnancy.incrementTime();
                if (pregnancy.isDone()) {
                    newAnimals = giveBirth();
                    pregnancy = new Pregnancy();
                }
            }
            if (isActive()) {
                breed();
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                    checkForDiseases();
                    for (Disease disease : diseasesHeld) {
                        for (DiseaseEffect effect : disease.getEffects()) {
                            EffectActor.act(this, effect);
                        }
                    }
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        return newAnimals;
    }

    /**
     * Checks the surrounding entities and this animal's square for any diseases this animal
     * can catch. Transmit this disease if the transmission criteria are met.
     */
    private void checkForDiseases() {
        // Check own square for disease.
        ClassSet<EnvironmentalFactor> locationFactors = field.getFactorsAt(location);
        locationFactors.removeIf(factor -> !Disease.class.isAssignableFrom(factor.getClass()));
        if (locationFactors.size() != 0) {
            for (EnvironmentalFactor factor : locationFactors) {
                Disease disease = (Disease) factor;
                if (checkDiseaseIsValid(disease)) addDiseaseToThis(disease);
            }
        }

        // Check surrounding squares for diseases.
        List<Entity> nearbyEntities = getNearbyEntities(false);
        for (Entity entity : nearbyEntities) {
            for (Disease disease : entity.getDiseases()) {
                if (checkDiseaseIsValid(disease)) {
                    addDiseaseToThis(disease);
                }
            }
        }
    }

    /**
     * Check if a disease should be added to the Animal.
     * @param disease the disease to add.
     * @return true if the disease should be added.
     */
    private boolean checkDiseaseIsValid(Disease disease) {
        return disease.getAffectedEntities().contains(this.getClass()) &&
                disease.transmit() &&
                !diseasesContains(disease.getClass());
    }

    /**
     * Add the specified disease to this animal.
     * @param disease the disease to add.
     */
    private void addDiseaseToThis(Disease disease) {
        diseasesHeld.add(disease);
    }

    @Override
    public boolean diseasesContains(Class<? extends Disease> diseaseClass) {
        Set<Class<? extends Disease>> seen = new HashSet<>();
        for (Disease disease : diseasesHeld) {
            if (!seen.contains(disease.getClass())) seen.add(disease.getClass());
            else return true;
        }
        return false;
    }

    @Override
    public ListSet<Disease> getDiseases() {
        return diseasesHeld;
    }

    @Override
    public void allowBreeding(boolean value) {
        canBreed = value;
    }

    @Override
    public double getCreationProbability() {
        return creationProbability;
    }

    /**
     * @return if the Animal is alive or not.
     */
    @Override
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * @return the food value of this Animal instance.
     */
    @Override
    public float getFoodValue() {
        return foodValue;
    }

    /**
     * The animal dies and is removed from the field.
     */
    @Override
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Makes use of the Animal's consumption rate to use stamina.
     */
    @Override
    public void useStamina() {
        currentFoodValue -= FOOD_CONSUMPTION_RATE;
    }

    /**
     * Adds the value of the food to the Animal.
     * @param food the food to add.
     */
    @Override
    public void consume(Food food) {
        currentFoodValue = Math.max(currentFoodValue + food.getFoodValue(), MAX_FOOD_VALUE);
    }

    /**
     * Method for finding food in the field. Animals inside environmental
     * factors such as trees are not able to be found by this method.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location location : adjacent) {
            if (findEntity(location)) return location;
            if (findProducers(location)) return location;
        }
        return null;
    }

    /**
     * Checks the adjacent squares for entities of this type.
     * @param matchType if true, only add entities of the same dynamic class as this.
     * @return a list of matching entities.
     */
    public List<Entity> getNearbyEntities(boolean matchType) {
        List<Entity> nearby = new ArrayList<>();
        List<Location> locations = field.adjacentLocations(location);
        for (Location location : locations) {
            Entity atLocation = field.getEntityAt(location);
            if (atLocation != null) {
                if (!matchType || atLocation.getClass() == this.getClass()) {
                    nearby.add(atLocation);
                }
            }
        }
        return nearby;
    }

    /**
     * @param location the location to check.
     * @return true if there is an entity at the location which this entity can eat.
     */
    private boolean findEntity(Location location) {
        Entity entity = field.getEntityAt(location);
        try {
            Class<? extends Entity> entityClass = entity.getClass();
            if (FOOD_EATEN.contains(entityClass)) {
                if (entity.isAlive()) {
                    consume(entity);
                    entity.setDead();
                    return true;
                }
            }
        }
        catch (NullPointerException ignored) {}
        return false;
    }

    /**
     * @param location the location to check.
     * @return true if there is a producer at the location which this animal can eat.
     */
    private boolean findProducers(Location location) {
        ClassSet<Producer> producers = field.getProducersAt(location);
        try {
            Producer foodNearby = null;
            for (Producer producer : producers) {
                if (FOOD_EATEN.contains(producer)) {
                    foodNearby = producer;
                    break;
                }
            }
            // If there is a relevant producer, eat it.
            if (foodNearby != null) {
                consume(foodNearby);
                return true;
            }
        }
        catch (NullPointerException e) {}
        return false;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * @return true if this animal is pregnant.
     */
    protected boolean isPregnant() {
        return pregnancy.isViable();
    }

    /**
     * @return true if the animal should act on this step based on its operating hours.
     */
    public boolean isActive() {
        if (location == null) return false;
        return OPERATING_TIMES.contains(field.getTimeOfDay());
    }

    /**
     * @return this animal's sex.
     */
    protected SexValue getSex() {
        return sex;
    }
    
    @Override
    public FieldCell getFieldCell() {
        return field.getFieldCellAt(location);
    }

    /**
     * Increase the age. This could result in the fox's death.
     */
    private void incrementAge()
    {
        age++;
        if (age > maxAge) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry based on its consumption rate.
     * This will result in the animal's death if hunger value falls below 1.
     */
    private void incrementHunger()
    {
        currentFoodValue -= FOOD_CONSUMPTION_RATE * (isActive() ? 1 : NON_ACTING_CONSUMPTION_MODIFIER);
        if (currentFoodValue <= 0) {
            setDead();
        }
    }

    /**
     * Check whether this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     */
    private List<Animal> giveBirth() {

        List<Animal> newAnimals = new ArrayList<>();

        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(location);
        int births = ThreadLocalRandom.current().nextInt(1, maxLitterSize + 1);

        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            try {
                Animal young = this.getClass()
                        .getDeclaredConstructor(Boolean.class, Field.class, Location.class)
                        .newInstance(false, field, loc);
                newAnimals.add(young);
            }
            catch (NoSuchMethodException e) {
                System.out.println(this.getClass()+" does not have a properly implemented constructor.");
                e.printStackTrace();
            } catch (InvocationTargetException | InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
            }
        }

        return newAnimals;
    }

    /**
     * If applicable, create a new pregnancy for this Animal.
     */
    private void breed()
    {
        List<Entity> nearbyMatches = getNearbyEntities(true);
        for (Entity entity : nearbyMatches) {
            // Check if sexes match.
            Animal animal = (Animal) entity;
            if (sex == SexValue.FEMALE && animal.getSex() == SexValue.MALE) {
                if (canBreed() && RAND.nextDouble() <= breedingProbability) {
                    pregnancy = new Pregnancy(birthTime);
                    break;
                }
            }
        }
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= breedingAge && !isPregnant() && canBreed;
    }

    /**
     * Reads the class variable values from the properties file and assigns
     * them to said variables.
     * @return the values to assign.
     */
    private String[] getAnimalValues() {
        String animalName = this.getClass().getSimpleName();
        try {
            File animalStatsFile = getPropertyFile();
            PropertyFileReader reader = new PropertyFileReader(animalStatsFile);
            String[] stats = reader.getRow(animalName);
            if (stats.length != 0) return stats;
            else throw new EntityNotFoundException("Animal "+animalName+" not found in "+PROPERTY_FILE_NAME);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Takes values found in the animal properties file and assigns them to the
     * relevant class variables.
     */
    public void initialiseValues() {
        PropertyFileReader reader = new PropertyFileReader(getPropertyFile());
        String[] values = getAnimalValues();
        assert values != null : "Expected some values from property file, found none.";
        breedingAge = Integer.parseInt(reader.getValueByColumn(values, FileProperties.BREEDING_AGE));
        maxAge = Integer.parseInt(reader.getValueByColumn(values, FileProperties.MAX_AGE));
        birthTime = Integer.parseInt(reader.getValueByColumn(values, FileProperties.BIRTH_TIME));
        creationProbability = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CREATION_PROBABILITY));
        breedingProbability = Double.parseDouble(reader.getValueByColumn(values, FileProperties.BREEDING_PROBABILITY));
        maxLitterSize = Integer.parseInt(reader.getValueByColumn(values, FileProperties.MAX_LITTER_SIZE));
        foodValue = Integer.parseInt(reader.getValueByColumn(values, FileProperties.FOOD_VALUE));
    }

}

