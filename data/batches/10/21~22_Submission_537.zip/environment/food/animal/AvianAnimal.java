package environment.food.animal;

import engine.Location;
import engine.field.Field;
import engine.field.TimeOfDay;
import environment.food.Food;
import environment.food.SexValue;

import java.util.Set;

/**
 * This class defines the behaviour of avian animals. Currently,
 * there is not much distinction between this and a normal animal,
 * but the relationship is there for future development.
 * @version 2022.03.01
 */
public abstract class AvianAnimal extends Animal {

    protected AvianAnimal() {}

    protected AvianAnimal(Field field, Location location, Set<Class<? extends Food>> foodEaten, float maxFoodValue,
                          float consumptionRate, boolean randomAge, SexValue sex, Set<TimeOfDay> operatingHours) {
        super(field, location, foodEaten, maxFoodValue, consumptionRate, randomAge, sex, operatingHours);
    }

    /*@Override
    public List<Animal> act() {
        return null;
    }*/
}
