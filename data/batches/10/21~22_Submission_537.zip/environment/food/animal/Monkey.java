package environment.food.animal;

import engine.Location;
import engine.field.Field;
import engine.field.TimeOfDay;
import engine.helpers.Randomizer;
import engine.helpers.ClassSet;
import environment.food.Food;
import environment.food.Sex;
import environment.factors.structures.EnvironmentalStructure;
import environment.factors.structures.Tree;
import java.util.List;

import java.util.Random;
import java.util.Set;

public class Monkey extends Animal {

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The set of food classes the Monkey eats.
    private static final Set<Class<? extends Food>> foodEaten = Set.of(Vole.class, Rabbit.class);
    // The times that a Monkey can act().
    private static final Set<TimeOfDay> operatingHours = Set.of(TimeOfDay.MORNING, TimeOfDay.MIDDAY, TimeOfDay.EVENING);
    // The maximum amount energy a Monkey can have at once.
    private static final float MAX_FOOD_VALUE = 50;
    // The base rate at which Monkey use energy.
    private static final float CONSUMPTION_RATE = 5;

    /**
     * Create an empty Monkey. Used to get the properties file.
     */
    public Monkey() {}

    /**
     * Create a Monkey. A Monkey can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the Monkey will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Monkey(Boolean randomAge, Field field, Location location)
    {
        super(field, location, foodEaten, MAX_FOOD_VALUE, CONSUMPTION_RATE, randomAge, Sex.getBinarySex(), operatingHours);
    }
    
    /**
     * On top of the normal actions, Monkeys should
     * move into trees on the same square.
     * @return newly born animals.
     */
    @Override
    public List<Animal> act() {
        List<Animal> newAnimals = super.act();
        // If the Animal was newly born, it won't have a location yet.
        if (location != null) {
            ClassSet<EnvironmentalStructure> structures = field.getStructuresAt(location);
            if (structures != null) {
                EnvironmentalStructure tree = structures.getClassInstance(Tree.class);
                if (tree != null && isAlive()) {
                    tree.addEntity(this);
                }
            }
        }
        return newAnimals;
    }
}
