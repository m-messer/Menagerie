package environment.food.animal;

/**
 * This class tracks the pregnancy of a certain entity
 * and indicates when a new one/s should be created.
 * @version 2022.03.01
 */
public class Pregnancy {

    private final int requiredTime;
    private int timeSinceStart;

    /**
     * Creates a non-functional pregnancy: isDone() will never
     * return true.
     */
    public Pregnancy() {
        this.timeSinceStart = 0;
        this.requiredTime = -1;
    }

    /**
     * Creates a new Pregnancy.
     * @param requiredTime the time for a baby to incubate.
     */
    public Pregnancy(int requiredTime) {
        this.timeSinceStart = 0;
        this.requiredTime = requiredTime;
    }

    /**
     * @return if the required pregnancy time has been met.
     */
    public boolean isDone() {
        return timeSinceStart >= requiredTime;
    }

    /**
     * @return true if this is not a placeholder pregnancy.
     */
    public boolean isViable() {
        return requiredTime >= 0;
    }

    /**
     * Increment the internal counter if viable.
     */
    public void incrementTime() {
        if (isViable()) timeSinceStart++;
    }

}
