package environment.food.animal;

import engine.field.Field;
import engine.Location;
import engine.field.TimeOfDay;
import engine.helpers.Randomizer;
import environment.food.Food;
import environment.food.Sex;
import environment.food.producer.Fern;
import environment.food.producer.Grass;

import java.awt.*;
import java.sql.Time;
import java.util.Random;
import java.util.Set;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 * @version 2022.03.02
 */
public class Rabbit extends Animal
{
    // The set of food classes the Rabbit eats.
    private static final Set<Class<? extends Food>> foodEaten = Set.of(Grass.class, Fern.class);
    // The times that a Rabbit can act.
    private static final Set<TimeOfDay> operatingHours = Set.of(TimeOfDay.MORNING, TimeOfDay.MIDDAY, TimeOfDay.EVENING);
    // The maximum amount energy a fox can have at once.
    private static final int MAX_FOOD_VALUE = 10;
    // The base rate at which foxes use energy.
    private static final int CONSUMPTION_RATE = 1;

    /**
     * Create an empty Rabbit. Used to get the properties file.
     */
    public Rabbit() {}

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(Boolean randomAge, Field field, Location location)
    {
        super(field, location, foodEaten, MAX_FOOD_VALUE, CONSUMPTION_RATE, randomAge, Sex.getBinarySex(), operatingHours);
    }

}
