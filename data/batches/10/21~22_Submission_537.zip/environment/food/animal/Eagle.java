package environment.food.animal;

import engine.Location;
import engine.field.Field;
import engine.field.TimeOfDay;
import engine.helpers.Randomizer;
import environment.food.Food;
import environment.food.Sex;

import java.util.Random;
import java.util.Set;

/**
 * Model of an Eagle extending the Animal framework.
 * @version 2022.03.01
 */
public class Eagle extends AvianAnimal {

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The set of food classes the Eagle eats.
    private static final Set<Class<? extends Food>> foodEaten = Set.of(Rabbit.class, Fox.class, Monkey.class);
    // The times that an Eagle functions.
    private static final Set<TimeOfDay> operatingHours = Set.of(TimeOfDay.MORNING, TimeOfDay.MIDDAY, TimeOfDay.EVENING);
    // The maximum amount energy an Eagle can have at once.
    private static final float MAX_FOOD_VALUE = 50;
    // The base rate at which Eagles use energy.
    private static final float CONSUMPTION_RATE = 6;

    /**
     * Create an empty Eagle. Used to get the properties file.
     */
    public Eagle() {}

    /**
     * Create an Eagle. An Eagle can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the Eagle will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Eagle(Boolean randomAge, Field field, Location location)
    {
        super(field, location, foodEaten, MAX_FOOD_VALUE, CONSUMPTION_RATE, randomAge, Sex.getBinarySex(), operatingHours);
    }
}
