package environment.food.animal;

import engine.Location;
import engine.field.Field;
import engine.field.FieldCell;
import engine.field.TimeOfDay;
import engine.helpers.Randomizer;
import engine.helpers.ClassSet;
import environment.food.Food;
import environment.food.Sex;
import environment.food.producer.Fern;
import environment.food.producer.Grass;
import environment.factors.structures.EnvironmentalStructure;
import environment.factors.structures.Burrow;
import java.util.List;

import java.util.Random;
import java.util.Set;

/**
 * A model of a Vole which extends the Animal framework.
 * @version 2022.03.01
 */
public class Vole extends Animal {

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The times that a Vole will act.
    private static final Set<TimeOfDay> operatingHours = Set.of(TimeOfDay.MORNING, TimeOfDay.EVENING);
    // The set of food classes the Vole eats.
    private static final Set<Class<? extends Food>> foodEaten = Set.of(Grass.class, Fern.class);
    // The maximum amount energy a Vole can have at once.
    private static final float MAX_FOOD_VALUE = 20;
    // The base rate at which Moles use energy.
    private static final float CONSUMPTION_RATE = 1;
    // Probability that on a given step, a Vole will create a new Burrow.
    private static final double BURROW_CREATION_CHANCE = 0.2;

    /**
     * Create an empty Vole. Used to get the properties file.
     */
    public Vole() {}

    /**
     * Create a Vole. A Vole can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the Vole will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Vole(Boolean randomAge, Field field, Location location)
    {
        super(field, location, foodEaten, MAX_FOOD_VALUE, CONSUMPTION_RATE, randomAge, Sex.getBinarySex(), operatingHours);
    }
    
    /**
     * On top of acting normally, Voles may enter an existing
     * burrow in their cell or create a new one then enter it.
     * @return newly born animals.
     */
    @Override
    public List<Animal> act() {
        List<Animal> newAnimals = super.act();
        if (location != null) {
            ClassSet<EnvironmentalStructure> structures = field.getStructuresAt(location);
            if (structures != null) {
                EnvironmentalStructure burrow = structures.getClassInstance(Burrow.class);
                if (burrow != null && isAlive()) {
                    burrow.addEntity(this);
                }
                // Try and create Burrow.
                else if (Randomizer.getRandom().nextDouble() <= BURROW_CREATION_CHANCE) {
                    Burrow newBurrow = new Burrow(field);
                    newBurrow.addEntity(this);
                    structures.add(newBurrow);
                }
            }
        }
        return newAnimals;
    }
}
