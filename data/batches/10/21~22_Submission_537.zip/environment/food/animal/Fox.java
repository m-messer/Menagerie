package environment.food.animal;

import engine.field.Field;
import engine.Location;
import engine.field.TimeOfDay;
import engine.helpers.Randomizer;
import environment.food.Food;
import environment.food.Sex;
import environment.food.SexValue;
import environment.food.producer.Grass;

import java.util.Random;
import java.util.Set;

/**
 * Model of a Fox following the Animal framework.
 * @version 2022.02.09
 */
public class Fox extends Animal
{
    // The set of food classes the Fox eats.
    private static final Set<Class<? extends Food>> foodEaten = Set.of(Rabbit.class, Vole.class);
    // The times that Foxes can act.
    private static final Set<TimeOfDay> operatingHours = Set.of(TimeOfDay.MIDDAY, TimeOfDay.EVENING, TimeOfDay.NIGHT);
    // The maximum amount energy a fox can have at once.
    private static final float MAX_FOOD_VALUE = 20;
    // The base rate at which foxes use energy.
    private static final float CONSUMPTION_RATE = 4;

    /**
     * Create an empty Fox. Used to get the properties file.
     */
    public Fox() {}

    /**
     * Create a fox. A fox can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(Boolean randomAge, Field field, Location location)
    {
        super(field, location, foodEaten, MAX_FOOD_VALUE, CONSUMPTION_RATE, randomAge, Sex.getBinarySex(), operatingHours);
    }
}

