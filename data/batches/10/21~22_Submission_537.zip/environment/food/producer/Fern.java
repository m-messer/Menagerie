package environment.food.producer;

import engine.helpers.FileProperties;
import engine.helpers.PropertyFileReader;
import environment.weather.Clear;
import environment.weather.Heatwave;
import environment.weather.Rainy;
import environment.weather.Weather;

import java.util.HashMap;
import java.util.Map;

/**
 * Implementation of Ferns using the Producer framework.
 * @version 2022.03.03
 */
public class Fern implements Producer {

    private static int FOOD_VALUE = 3;
    private static int MAX_LIFESPAN = 10;
    private static double BASE_DEATH_CHANCE = 0.01;
    private static double BASE_CREATION_CHANCE = 0.3;
    private Map<Class<? extends Weather>, Double> CREATION_MAP;
    private Map<Class<? extends Weather>, Double> DEATH_MAP;
    private int currentAge;

    public Fern() {
        this.currentAge = 0;
        buildCreationMap();
        buildRemovalMap();
    }

    @Override
    public void buildCreationMap() {
        CREATION_MAP = new HashMap<>();
        // Map weather states to a multiplier for creation chance.
        CREATION_MAP.put(Clear.class, 1.0);
        CREATION_MAP.put(Heatwave.class, 0.3);
        CREATION_MAP.put(Rainy.class, 1.5);
    }

    @Override
    public void buildRemovalMap() {
        DEATH_MAP = new HashMap<>();
        // Map weather states to a multiplier for creation chance.
        DEATH_MAP.put(Clear.class, 1.0);
        DEATH_MAP.put(Heatwave.class, 1.5);
        DEATH_MAP.put(Rainy.class, 0.8);
    }

    @Override
    public float getFoodValue() {
        return FOOD_VALUE;
    }

    @Override
    public int getMaxLifeSpan() {
        return MAX_LIFESPAN;
    }
    
    /**
     * @return true if currentAge exceeds the maximum.
     */
    private boolean shouldDie() {
        return currentAge > MAX_LIFESPAN;
    }

    @Override
    public double getDeathChance(Class<? extends Weather> weather) {
        return (shouldDie()) ? BASE_DEATH_CHANCE * getRemovalModifier(weather) : 1.0;
    }

    @Override
    public double getCreationChance(Class<? extends Weather> weather) {
        return BASE_CREATION_CHANCE * getCreationModifier(weather);
    }

    @Override
    public double getCreationModifier(Class<? extends Weather> weather) {
        return CREATION_MAP.get(weather);
    }

    @Override
    public double getRemovalModifier(Class<? extends Weather> weather) {
        return DEATH_MAP.get(weather);
    }
    
    @Override
    public void incrementAge() {
        currentAge++;
    }
    
    @Override
    public void initialiseValues() {
        PropertyFileReader reader = new PropertyFileReader(getPropertyFile());
        String[] values = reader.getRow(this.getClass().getSimpleName());
        FOOD_VALUE = Integer.parseInt(reader.getValueByColumn(values, FileProperties.FOOD_VALUE));
        MAX_LIFESPAN = Integer.parseInt(reader.getValueByColumn(values, FileProperties.MAX_AGE));
        BASE_CREATION_CHANCE = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CREATION_PROBABILITY));
        BASE_DEATH_CHANCE = Double.parseDouble(reader.getValueByColumn(values, FileProperties.DISAPPEARANCE_PROBABILITY));
    }
}
