package environment.food.producer;

import environment.PropertyFileBound;
import environment.food.Food;
import environment.weather.Weather;
import environment.weather.WeatherBound;

import java.io.File;
import java.net.URISyntaxException;
import java.util.Objects;

/**
 * This interface is for things which can be eaten but
 * cannot eat other entities.
 * For example, Grass is eaten by Rabbits, but it will not eat
 * the Rabbit or any other Animal.
 * @version 2022.03.03
 */
public interface Producer extends Food, PropertyFileBound, WeatherBound {

    String PRODUCER_PROPERTIES = "producerProperties.csv"; // HAS NO IMPLEMENTED FUNCTION

    /**
     * @return the producer properties file.
     */
    @Override
    default File getPropertyFile() {
        return new File(PRODUCER_PROPERTIES);
    }

    /**
     * Producers should have some maximum time they can
     * exist before being removed from the field.
     * @return the maximum lifespan of the producer.
     */
    int getMaxLifeSpan();

    /**
     * @param weather the given weather.
     * @return the chance of death given the weather.
     */
    double getDeathChance(Class<? extends Weather> weather);

    /**
     * @param weather the given weather.
     * @return the chance of creating a new instance given the weather.
     */
    double getCreationChance(Class<? extends Weather> weather);
    
    /**
     * Increments the age of this Producer.
     */
    void incrementAge();
}
