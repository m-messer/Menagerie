package environment.food;

/**
 * This class is for things which an Animal would eat, but does
 * not move or eat other animals. For example, Grass.
 */
public interface Food {

    float getFoodValue();

}
