package environment.food;

public enum SexValue {
    MALE, FEMALE, NON_BINARY
}
