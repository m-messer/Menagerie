package environment;

import engine.helpers.FileProperties;
import engine.helpers.PropertyFileReader;

import java.awt.*;
import java.io.File;

/**
 * This interface is to define which classes should be
 * able to be displayed on the field.
 */
public interface Viewable {

    Color DEFAULT_COLOUR = Color.PINK;
    String COLOUR_DELIMITER = "&";

    /**
     * @param file the CSV file to look for a colour string in.
     * @param className the name of the class to lookup in the file.
     * @return the colour that the viewable object should display.
     */
    default Color getDisplayColor(File file, String className) {
        PropertyFileReader reader = new PropertyFileReader(file);
        String[] row = reader.getRow(className);
        String[] rgbValues = reader.getValueByColumn(row, FileProperties.DISPLAY_COLOUR).split(COLOUR_DELIMITER);
        int[] intRGB = new int[3];
        for (int i = 0; i < rgbValues.length; i++) intRGB[i] = Integer.parseInt(rgbValues[i]);
        return new Color(intRGB[0], intRGB[1], intRGB[2]);
    }

}
