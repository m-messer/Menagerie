package environment;

import java.io.File;

/**
 * Interface for classes which should pull information about
 * themselves from external files.
 * @version 2022.02.28
 */
public interface PropertyFileBound {

    /**
     * @return the properties file associated with this class.
     */
    File getPropertyFile();

    /**
     * Initialise the values gotten from the property file.
     */
    void initialiseValues();
}
