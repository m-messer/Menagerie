package environment.factors.diseases;

import environment.factors.diseases.effects.DiseaseEffect;
import environment.food.Entity;

import java.util.Set;

/**
 * This disease type will act based off probability, so symptoms
 * may or may not occur on a given turn.
 * @version 2022.02.16
 */
public abstract class ChanceDisease extends Disease {

    private double symptomChance;

    protected ChanceDisease(Set<Class<? extends Entity>> affects, DiseaseEffect[] effects, double symptomChance) {
        super(affects, effects);
        this.symptomChance = symptomChance;
    }

    /**
     * @return true if the symptoms should act on this turn.
     */
    @Override
    protected boolean performAct() {
        return RAND.nextDouble() <= symptomChance;
    }

    @Override
    public boolean createInstance() {
        return RAND.nextDouble() <= creationProbability;
    }

    @Override
    public boolean removeInstance() {
        return RAND.nextDouble() <= disappearanceProbability;
    }

}
