package environment.factors.diseases;

import engine.helpers.FileProperties;
import engine.helpers.PropertyFileReader;
import engine.helpers.Randomizer;
import environment.PropertyFileBound;
import environment.factors.EnvironmentalFactor;
import environment.factors.diseases.effects.DiseaseEffect;
import environment.food.Entity;

import java.io.File;
import java.net.URISyntaxException;
import java.util.Objects;
import java.util.Random;
import java.util.Set;

/**
 * Diseases can affect entities' properties. This class is a high-level
 * template for diseases which can be caught by entities.
 * @version 2022.02.16
 */
public abstract class Disease implements PropertyFileBound, EnvironmentalFactor {

    protected static final String PROPERTY_FILE_NAME = "diseaseProperties.csv";
    protected static final Random RAND = Randomizer.getRandom();

    // Contains the Entities this disease affects.
    protected Set<Class<? extends Entity>> affects;
    // The effects of the disease.
    protected DiseaseEffect[] effects;
    // The chance that adjacent Animals will catch this disease.
    protected double spreadChance;
    // The chance that an Animal on a cell containing the disease will catch it.
    protected double catchChance;
    // The longest period an Animal can have this disease.
    protected int maxCarryTime;
    // The chance that this disease will be created on a given cell.
    protected double creationProbability;
    // The chance that this disease will disappear from the cell it is on.
    protected double disappearanceProbability;

    protected Disease(Set<Class<? extends Entity>> affects, DiseaseEffect[] effects) {
        this.affects = affects;
        this.effects = effects;
        initialiseFileValues();
    }

    /**
     * @return the associated properties file for diseases.
     */
    @Override
    public File getPropertyFile() {
        return new File(PROPERTY_FILE_NAME);
    }

    /**
     * @return the appearance probability for this disease.
     */
    @Override
    public double getCreationProbability() {
        return creationProbability;
    }

    @Override
    public double getDisappearanceProbability() {
        return disappearanceProbability;
    }

    /**
     * Defines if the disease should do something on a given step.
     */
    protected abstract boolean performAct();

    // Instance variable getters.

    public Set<Class<? extends Entity>> getAffectedEntities() {
        return affects;
    }

    public DiseaseEffect[] getEffects() {
        return effects;
    }

    /**
     * @return true if this disease should be transmitted.
     */
    public boolean transmit() {
        return doCatch() && doSpread();
    }

    private boolean doSpread() {
        return RAND.nextDouble() <= spreadChance;
    }

    private boolean doCatch() {
        return RAND.nextDouble() <= catchChance;
    }

    /**
     * Initialises values which are retrieved from the properties file.
     */
    private void initialiseFileValues() {
        PropertyFileReader reader = new PropertyFileReader(getPropertyFile());
        String[] values = reader.getRow(this.getClass().getSimpleName());
        spreadChance = Double.parseDouble(reader.getValueByColumn(values, FileProperties.SPREAD_CHANCE));
        catchChance = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CATCH_CHANCE));
        maxCarryTime = Integer.parseInt(reader.getValueByColumn(values, FileProperties.MAX_CARRY_TIME));
        creationProbability = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CREATION_PROBABILITY));
        disappearanceProbability = Double.parseDouble(reader.getValueByColumn(values, FileProperties.DISAPPEARANCE_PROBABILITY));
    }

}
