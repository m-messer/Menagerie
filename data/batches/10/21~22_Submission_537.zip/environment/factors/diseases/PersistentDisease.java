package environment.factors.diseases;

import engine.helpers.Randomizer;
import environment.factors.diseases.effects.DiseaseEffect;
import environment.food.Entity;

import java.util.Random;
import java.util.Set;

/**
 * This class is for diseases which are guaranteed to have
 * their symptoms occur on a given turn.
 * @version 2022.02.16
 */
public abstract class PersistentDisease extends Disease {

    protected PersistentDisease(Set<Class<? extends Entity>> affects, DiseaseEffect[] effects) {
        super(affects, effects);
    }

    /**
     * Determines if the effect should take place.
     * @return true as symptoms should occur on every step.
     */
    @Override
    protected boolean performAct() {
        return true;
    }

    @Override
    public boolean createInstance() {
        return Randomizer.getRandom().nextDouble() <= creationProbability;
    }

    @Override
    public boolean removeInstance() {
        return Randomizer.getRandom().nextDouble() <= disappearanceProbability;
    }
}
