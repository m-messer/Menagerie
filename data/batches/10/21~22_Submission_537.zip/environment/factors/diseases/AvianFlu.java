package environment.factors.diseases;

import engine.helpers.PropertyFileReader;
import engine.helpers.FileProperties;
import environment.factors.diseases.effects.Death;
import environment.factors.diseases.effects.DiseaseEffect;
import environment.factors.diseases.effects.ReducedStamina;
import environment.food.Entity;
import environment.food.animal.AvianAnimal;
import environment.food.animal.Eagle;
import environment.food.animal.Fox;
import environment.food.animal.Rabbit;

import java.util.HashSet;
import java.util.Set;

/**
 * Implementation of Avian Flu.
 * @version 2022.03.02
 */
public class AvianFlu extends PersistentDisease {

    private static final DiseaseEffect[] effects = {new Death(0.005), new ReducedStamina(0.2)};
    private static final Set<Class<? extends Entity>> affects = Set.of(Eagle.class);

    public AvianFlu() {
        super(affects, effects);
    }

    @Override
    public void initialiseValues() {
        PropertyFileReader reader = new PropertyFileReader(getPropertyFile());
        String[] values = reader.getRow(getClass().getSimpleName());
        creationProbability = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CREATION_PROBABILITY));
        disappearanceProbability = Double.parseDouble(reader.getValueByColumn(values, FileProperties.DISAPPEARANCE_PROBABILITY));
        catchChance = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CATCH_CHANCE));
        spreadChance = Double.parseDouble(reader.getValueByColumn(values, FileProperties.SPREAD_CHANCE));
        maxCarryTime = Integer.parseInt(reader.getValueByColumn(values, FileProperties.MAX_CARRY_TIME));
    }
}
