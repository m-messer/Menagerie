package environment.factors.diseases.effects;

import engine.helpers.Randomizer;
import environment.food.Entity;

/**
 * Used to increase the amount of energy used per step through disease.
 * @version 2022.02.16
 */
public class ReducedStamina extends DiseaseEffect {

    public ReducedStamina(double actingChance) {
        super(actingChance);
    }

    @Override
    public void act(Entity entity) {
        if (Randomizer.getRandom().nextDouble() < actingChance) {
            entity.useStamina();
        }
    }
}
