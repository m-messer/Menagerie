package environment.factors.diseases.effects;

import environment.food.Entity;

/**
 * Class for applying disease effects to an entity.
 * @version 2022.02.16
 */
public class EffectActor {

    private EffectActor() {}

    /**
     * Applies a given effect to a given entity.
     * @param entity the entity to affect.
     * @param effect the effect to apply.
     */
    public static void act(Entity entity, DiseaseEffect effect) {
        effect.act(entity);
    }

}
