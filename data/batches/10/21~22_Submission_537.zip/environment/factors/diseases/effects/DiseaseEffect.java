package environment.factors.diseases.effects;

import environment.food.Entity;

/**
 * Defines the basic characteristics of a disease symptom.
 */
public abstract class DiseaseEffect {

    protected double actingChance;

    protected DiseaseEffect(double actingChance) {
        this.actingChance = actingChance;
    }

    /**
     * Performs actions on the entity passed in.
     */
    public abstract void act(Entity entity);

}
