package environment.factors.diseases.effects;

import engine.helpers.Randomizer;
import environment.food.Entity;

/**
 * Used to kill an entity through a disease.
 * @version 2022.02.16
 */
public class Death extends DiseaseEffect {

    public Death(double actingChance) {
        super(actingChance);
    }

    @Override
    public void act(Entity entity) {
        if (Randomizer.getRandom().nextDouble() < actingChance) {
            entity.setDead();
        }
    }
}
