package environment.factors.structures;

import engine.field.Field;
import engine.helpers.Randomizer;
import engine.helpers.PropertyFileReader;
import engine.helpers.FileProperties;
import environment.food.Entity;
import environment.food.producer.Producer;
import environment.weather.*;

import java.util.*;

/**
 * The tree is an Environmental Structure which certain Entities can move into.
 * A monkey could get into the tree, but something like a vole could not.
 * @version 2022.02.21
 */
public class Tree implements EnvironmentalStructure {

    private Entity entityPresent;

    // Static generation information.
    private static double APPEARANCE_PROBABILITY;
    private static double DISAPPEARANCE_PROBABILITY;
    private static Map<Class<? extends Weather>, Double> CREATION_MAP;
    private static Map<Class<? extends Weather>, Double> DISAPPEARANCE_MAP;
    private Field field;

    public Tree(Field field) {
        this.field = field;
        buildCreationMap();
        buildRemovalMap();
        initialiseValues();
    }
    
    @Override
    public Field getField() {
        return field;
    }
    
    public void setField(Field field) {
        this.field = field;
    }

    // Inherited methods.

    @Override
    public void buildCreationMap() {
        CREATION_MAP = new HashMap<>();
        CREATION_MAP.put(Clear.class, 1.0);
        CREATION_MAP.put(Heatwave.class, 0.75);
        CREATION_MAP.put(Rainy.class, 1.25);
    }

    @Override
    public void buildRemovalMap() {
        DISAPPEARANCE_MAP = new HashMap<>();
        DISAPPEARANCE_MAP.put(Clear.class, 1.0);
        DISAPPEARANCE_MAP.put(Heatwave.class, 1.25);
        DISAPPEARANCE_MAP.put(Rainy.class, 1.1);
    }

    @Override
    public double getCreationModifier(Class<? extends Weather> weather) {
        return CREATION_MAP.get(weather);
    }

    @Override
    public double getRemovalModifier(Class<? extends Weather> weather) {
        return DISAPPEARANCE_MAP.get(weather);
    }

    @Override
    public double getCreationProbability() {
        return APPEARANCE_PROBABILITY;
    }

    @Override
    public double getDisappearanceProbability() {
        return DISAPPEARANCE_PROBABILITY;
    }

    @Override
    public boolean createInstance(Class<? extends Weather> weather) {
        return Randomizer.getRandom().nextDouble() <= APPEARANCE_PROBABILITY * getCreationModifier(weather);
    }

    @Override
    public boolean removeInstance(Class<? extends Weather> weather) {
        return Randomizer.getRandom().nextDouble() <= DISAPPEARANCE_PROBABILITY * getRemovalModifier(weather);
    }

    @Override
    public Entity getEntitiesPresent() {
        return entityPresent;
    }

    /**
     * Add this entity to the Tree if there is nothing there already.
     * @return true if added to the Tree.
     */
    @Override
    public boolean addEntity(Entity entity) {
        if (entityPresent == null) {
            entityPresent = entity;
        }
        return entityPresent == entity;
    }

    @Override
    public Entity removeEntity() {
        Entity temp = entityPresent;
        entityPresent = null;
        return temp;
    }
    
    @Override
    public void initialiseValues() {
        PropertyFileReader reader = new PropertyFileReader(getPropertyFile());
        String[] values = reader.getRow(getClass().getSimpleName());
        APPEARANCE_PROBABILITY = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CREATION_PROBABILITY));
        DISAPPEARANCE_PROBABILITY = Double.parseDouble(reader.getValueByColumn(values, FileProperties.DISAPPEARANCE_PROBABILITY));
    }
}
