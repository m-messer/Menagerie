package environment.factors.structures;

import engine.field.Field;
import environment.PropertyFileBound;
import environment.factors.EnvironmentalFactor;
import environment.food.Entity;
import environment.food.producer.Producer;
import environment.weather.Weather;
import environment.weather.WeatherBound;
import java.io.File;

import java.util.Set;

/**
 * This interface is intended for environmental factors which can store some extension
 * of Food. For example, a Bird may be stored in a Tree.
 * @version 2022.02.21
 */
public interface EnvironmentalStructure extends WeatherBound, PropertyFileBound {
    
    String PROPERTIES_FILE_NAME = "structureProperties.csv";
    
    /**
     * @return the structure properties file.
     */
    @Override
    default File getPropertyFile() {
        return new File(PROPERTIES_FILE_NAME);
    }

    /**
     * @return the creation probability of this structure.
     */
    double getCreationProbability();

    /**
     * @return the disappearance probability of this structure.
     */
    double getDisappearanceProbability();

    /**
     * @param weather the current weather conditions.
     * @return true if an instance of this structure should be created.
     */
    boolean createInstance(Class<? extends Weather> weather);

    /**
     * @param weather the current weather conditions.
     * @return true if this instance of structure should be removed.
     */
    boolean removeInstance(Class<? extends Weather> weather);

    /**
     * @return any entities in the structure.
     */
    Object getEntitiesPresent();

    /**
     * Add an Entity to the structure.
     * @param entity the entity to add to the structure.
     * @return false if there is already an entity in the tree.
     */
    boolean addEntity(Entity entity);

    /**
     * Removes an entity from the structure.
     * @return the entity removed.
     */
    Entity removeEntity();
    
    /**
     * @return the field this entity is situated in.
     */
    Field getField();

}
