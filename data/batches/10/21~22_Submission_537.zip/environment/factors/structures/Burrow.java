package environment.factors.structures;

import engine.field.Field;
import engine.helpers.Randomizer;
import engine.helpers.PropertyFileReader;
import engine.helpers.FileProperties;
import engine.helpers.ListSet;
import environment.food.Entity;
import environment.food.producer.Producer;
import environment.weather.*;

import java.util.*;

/**
 * Implementation of a Vole burrow following the EnvironmentalStructure
 * framework.
 * @version 2022.03.03
 */
public class Burrow implements EnvironmentalStructure {
    
    private Entity entityPresent;

    // Static generation information.
    private static double APPEARANCE_PROBABILITY;
    private static double DISAPPEARANCE_PROBABILITY;
    private static Map<Class<? extends Weather>, Double> CREATION_MAP;
    private static Map<Class<? extends Weather>, Double> DISAPPEARANCE_MAP;
    private Field field;

    public Burrow(Field field) {
        this.field = field;
        buildCreationMap();
        buildRemovalMap();
        initialiseValues();
    }
    
    @Override
    public Field getField() {
        return field;
    }
    
    public void setField(Field field) {
        this.field = field;
    }

    // Inherited methods.

    @Override
    public void buildCreationMap() {
        CREATION_MAP = new HashMap<>();
        CREATION_MAP.put(Clear.class, 1.0);
        CREATION_MAP.put(Heatwave.class, 1.25);
        CREATION_MAP.put(Rainy.class, 0.75);
    }

    @Override
    public void buildRemovalMap() {
        DISAPPEARANCE_MAP = new HashMap<>();
        DISAPPEARANCE_MAP.put(Clear.class, 1.0);
        DISAPPEARANCE_MAP.put(Heatwave.class, 0.75);
        DISAPPEARANCE_MAP.put(Rainy.class, 1.25);
    }

    @Override
    public double getCreationModifier(Class<? extends Weather> weather) {
        return CREATION_MAP.get(weather);
    }

    @Override
    public double getRemovalModifier(Class<? extends Weather> weather) {
        return DISAPPEARANCE_MAP.get(weather);
    }

    @Override
    public double getCreationProbability() {
        return APPEARANCE_PROBABILITY;
    }

    @Override
    public double getDisappearanceProbability() {
        return DISAPPEARANCE_PROBABILITY;
    }

    @Override
    public boolean createInstance(Class<? extends Weather> weather) {
        return Randomizer.getRandom().nextDouble() <= APPEARANCE_PROBABILITY * getCreationModifier(weather);
    }

    @Override
    public boolean removeInstance(Class<? extends Weather> weather) {
        return Randomizer.getRandom().nextDouble() <= DISAPPEARANCE_PROBABILITY * getRemovalModifier(weather);
    }

    @Override
    public Entity getEntitiesPresent() {
        return entityPresent;
    }

    /**
     * Add this entity to the Burrow. They are assumed to be
     * of an infinite size as Voles could burrow more.
     * @return true if added to the Burrow.
     */
    @Override
    public boolean addEntity(Entity entity) {
        if (entityPresent == null) {
            entityPresent = entity;
        }
        return entityPresent == entity;
    }

    /**
     * @return the entity in the Burrow.
     */
    @Override
    public Entity removeEntity() {
        Entity temp = entityPresent;
        entityPresent = null;
        return temp;
    }
    
    @Override
    public void initialiseValues() {
        PropertyFileReader reader = new PropertyFileReader(getPropertyFile());
        String[] values = reader.getRow(getClass().getSimpleName());
        APPEARANCE_PROBABILITY = Double.parseDouble(reader.getValueByColumn(values, FileProperties.CREATION_PROBABILITY));
        DISAPPEARANCE_PROBABILITY = Double.parseDouble(reader.getValueByColumn(values, FileProperties.DISAPPEARANCE_PROBABILITY));
    }
}
