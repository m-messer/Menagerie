package environment.factors;

import environment.weather.Weather;
import environment.weather.WeatherBound;

/**
 * This interface is for non-food items which shouldn't be displayed
 * on the view, but should still have an effect on the simulation.
 * For example, this could be a disease.
 * @version 2022.03.02
 */
public interface EnvironmentalFactor {

    /**
     * @return the base probability that this factor will appear on a given cell.
     */
    double getCreationProbability();

    /**
     * @return the base probability that this factor will disappear from a cell on a given step.
     */
    double getDisappearanceProbability();

    /**
     * @return true if a new instance of this factor should be created.
     */
    boolean createInstance();

    /**
     * @return true if this instance of factor should be removed.
     */
    boolean removeInstance();
}
