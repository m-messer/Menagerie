package engine.field;

import engine.Counter;
import engine.Location;
import engine.helpers.ClassSet;
import engine.helpers.ListSet;
import engine.helpers.Propagator;
import engine.helpers.Randomizer;
import environment.factors.EnvironmentalFactor;
import environment.factors.diseases.Disease;
import environment.factors.structures.EnvironmentalStructure;
import environment.food.Entity;
import environment.food.producer.Producer;
import environment.weather.Clear;
import environment.weather.Heatwave;
import environment.weather.Rainy;
import environment.weather.Weather;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * Represent a rectangular grid of field positions.
 * Each position is able to store a single FieldCell which
 * can hold many types of simulation variables.
 * @version 2022.03.03
 */
public class Field
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();

    // The depth and width of the field.
    private int depth, width;
    // Storage for anything relevant to the field.
    private FieldCell[][] field;
    // Stores if new Animals should use their default characteristics
    // or user-defined ones.
    private boolean defaultAnimalValues = true;
    // The current step of time.
    private Counter stepCounter;
    // An array of possible times of day in the field.
    private final TimeOfDay[] times = {TimeOfDay.MORNING, TimeOfDay.MIDDAY, TimeOfDay.EVENING, TimeOfDay.NIGHT};
    // Binds the probability of weather types with that type.
    private ListSet<Propagator<Weather, Double>> weatherPropagators;
    // The current weather in the field.
    private Weather currentWeather;

    /**
     * Represent a field of the given dimensions.
     * @param depth The depth of the field.
     * @param width The width of the field.
     */
    public Field(int depth, int width)
    {
        this.depth = depth;
        this.width = width;
        this.field = new FieldCell[depth][width];
        this.stepCounter = new Counter("Step");
        defineWeatherPropagator();
        this.currentWeather = new Clear();
        populateFieldCells();
    }

    public Weather getCurrentWeather() {
        return currentWeather;
    }

    public void changeWeather() {
        Collections.shuffle(weatherPropagators);
        for (Propagator<Weather, Double> propagator : weatherPropagators) {
            if (Randomizer.getRandom().nextDouble() <= propagator.getValue()) {
                currentWeather = propagator.getBoundObject();
                break;
            }
        }
    }

    private void defineWeatherPropagator() {
        weatherPropagators = new ListSet<>();
        weatherPropagators.add(new Propagator<>(new Clear(), 0.4));
        weatherPropagators.add(new Propagator<>(new Heatwave(), 0.1));
        weatherPropagators.add(new Propagator<>(new Rainy(), 0.3));
    }

    public FieldCell[][] getField() {
        return field;
    }
    
    public FieldCell getFieldCellAt(Location location) {
        return field[location.getRow()][location.getCol()];
    }

    /**
     * @return the time of day based on the modulo of the number of states.
     */
    public TimeOfDay getTimeOfDay() {
        return times[stepCounter.getCount() % times.length];
    }

    /**
     * @return the time counter.
     */
    public Counter getStepCounter() {
        return stepCounter;
    }

    /**
     * Empty the field.
     */
    public void clear()
    {
        populateFieldCells();
    }

    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    public void clear(Location location)
    {
        field[location.getRow()][location.getCol()] = new FieldCell();
    }

    /**
     * Place an entity at the given location.
     * If there is already an entity at the location it will
     * be lost.
     * @param entity The animal to be placed.
     * @param location Where to place the entity.
     */
    public void place(Entity entity, Location location)
    {
        field[location.getRow()][location.getCol()].setEntity(entity);
    }

    /**
     * Place some producer at the given location.
     * The producer will be added to a set of producers.
     * @param producer The producer to be placed.
     * @param location Where to place the food.
     */
    public void place(Producer producer, Location location)
    {
        field[location.getRow()][location.getCol()].addProducer(producer);
    }

    /**
     * Place an Environmental Factor at the specified location.
     * This method adds the factor to a set of factors.
     * @param factor The Environmental Factor to be introduced.
     * @param location Where to place the food.
     */
    public void place(EnvironmentalFactor factor, Location location)
    {
        field[location.getRow()][location.getCol()].addEnvironmentalFactor(factor);
    }

    /**
     * @param location the location in the field.
     * @return The entity at the given location, or null if there is none.
     */
    public Entity getEntityAt(Location location)
    {
        return field[location.getRow()][location.getCol()].getEntityOccupant();
    }

    /**
     * @param location the location in the field.
     * @return The producers at the given location, or null if there is none.
     */
    public ClassSet<Producer> getProducersAt(Location location)
    {
        return field[location.getRow()][location.getCol()].getProducersOccupying();
    }

    /**
     * @param location the location in the field.
     * @return The environmental factors at the given location, or null if there is none.
     */
    public ClassSet<EnvironmentalFactor> getFactorsAt(Location location)
    {
        return field[location.getRow()][location.getCol()].getEnvironmentalFactorsPresent();
    }

    /**
     * @param location the location in the field.
     * @return The environmental structures at the given location, or null if there is none.
     */
    public ClassSet<EnvironmentalStructure> getStructuresAt(Location location)
    {
        return field[location.getRow()][location.getCol()].getEnvironmentalStructuresPresent();
    }

    /**
     * Generate a random location that is adjacent to the
     * given location, or is the same location.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location randomAdjacentLocation(Location location)
    {
        List<Location> adjacent = adjacentLocations(location);
        return adjacent.get(0);
    }

    /**
     * Get a shuffled list of the free adjacent locations.
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */
    public List<Location> getFreeAdjacentLocations(Location location)
    {
        List<Location> free = new LinkedList<>();
        List<Location> adjacent = adjacentLocations(location);
        for(Location next : adjacent) {
            if(getEntityAt(next) == null) {
                free.add(next);
            }
        }
        return free;
    }

    /**
     * Try to find a free location that is adjacent to the
     * given location. If there is none, return null.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location freeAdjacentLocation(Location location)
    {
        // The available free ones.
        List<Location> free = getFreeAdjacentLocations(location);
        if(free.size() > 0) {
            return free.get(0);
        }
        else {
            return null;
        }
    }

    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    public List<Location> adjacentLocations(Location location)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        int row = location.getRow();
        int col = location.getCol();
        for(int roffset = -1; roffset <= 1; roffset++) {
            int nextRow = row + roffset;
            if(nextRow >= 0 && nextRow < depth) {
                for(int coffset = -1; coffset <= 1; coffset++) {
                    int nextCol = col + coffset;
                    // Exclude invalid locations and the original location.
                    if(nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
                        locations.add(new Location(nextRow, nextCol));
                    }
                }
            }

            // Shuffle the list. Several other methods rely on the list
            // being in a random order.
            Collections.shuffle(locations, rand);
        }
        return locations;
    }

    /**
     * Return the depth of the field.
     * @return The depth of the field.
     */
    public int getDepth()
    {
        return depth;
    }

    /**
     * Return the width of the field.
     * @return The width of the field.
     */
    public int getWidth()
    {
        return width;
    }

    /**
     * @return true if new entities should use their default characteristics.
     */
    public boolean isDefaultValues() {
        return defaultAnimalValues;
    }

    /**
     * @return the map of diseases in the field.
     */
    public Map<Class<? extends Disease>, Integer> getDiseaseMap() {
        Map<Class<? extends Disease>, Integer> diseaseMap = new HashMap<>();
        for (FieldCell[] row : field) {
            for (FieldCell cell : row) {
                Entity occupant = cell.getEntityOccupant();
                if (occupant != null) {
                    ListSet<Disease> diseases = occupant.getDiseases();
                    diseases.forEach(disease -> updateDiseaseMap(disease.getClass(), diseaseMap));
                }
            }
        }
        return diseaseMap;
    }

    /**
     * Updates the disease map.
     */
    private void updateDiseaseMap(Class<? extends Disease> diseaseClass, Map<Class<? extends Disease>, Integer> diseaseMap) {
        if (diseaseMap.containsKey(diseaseClass)) {
            int initialCount = diseaseMap.get(diseaseClass);
            diseaseMap.put(diseaseClass, initialCount + 1);
        }
        else {
            diseaseMap.put(diseaseClass, 1);
        }
    }

    /**
     * @return the map of plants in the field.
     */
    public Map<Class<? extends Producer>, Integer> getPlantMap() {
        Map<Class<? extends Producer>, Integer> plantMap = new HashMap<>();
        for (FieldCell[] row : field) {
            for (FieldCell cell : row) {
                cell.getProducersOccupying().forEach(producer -> updatePlantMap(producer.getClass(), plantMap));
            }
        }
        return plantMap;
    }

    /**
     * Updates the plant map.
     */
    private void updatePlantMap(Class<? extends Producer> plantClass, Map<Class<? extends Producer>, Integer> plantMap) {
        if (plantMap.containsKey(plantClass)) {
            int initialCount = plantMap.get(plantClass);
            plantMap.put(plantClass, initialCount + 1);
        }
        else {
            plantMap.put(plantClass, 1);
        }
    }
    
    /**
     * @return the map of structures in the field.
     */
    public Map<Class<? extends EnvironmentalStructure>, Integer> getStructureMap() {
        Map<Class<? extends EnvironmentalStructure>, Integer> structureMap = new HashMap<>();
        for (FieldCell[] row : field) {
            for (FieldCell cell : row) {
                cell.getEnvironmentalStructuresPresent().forEach(structure -> updateStructureMap(structure.getClass(), structureMap));
            }
        }
        return structureMap;
    }

    /**
     * Updates the structure map.
     */
    private void updateStructureMap(Class<? extends EnvironmentalStructure> structureClass, Map<Class<? extends EnvironmentalStructure>, Integer> structureMap) {
        if (structureMap.containsKey(structureClass)) {
            int initialCount = structureMap.get(structureClass);
            structureMap.put(structureClass, initialCount + 1);
        }
        else {
            structureMap.put(structureClass, 1);
        }
    }

    /**
     * Fill the field cells with new FieldCell objects.
     */
    private void populateFieldCells() {
        for (int i = 0; i < depth; i++) {
            for (int j = 0; j < width; j++) {
                field[i][j] = new FieldCell();
            }
        }
    }

    /**
     * Checks each cell in the field and adds/removes producers.
     * @param simulatedProducers the producers to possibly add.
     */
    public void addressProducers(ListSet<Class<? extends Producer>> simulatedProducers) {
        for (FieldCell[] row : field) {
            for (FieldCell cell : row) {
                if (cell.getProducersOccupying() != null) removeDeadProducers(cell);
                addNewProducers(cell, simulatedProducers);
            }
        }
    }

    /**
     * Remove any producers from the cell which return a value greater than a random double.
     */
    private void removeDeadProducers(FieldCell cell) {
        // Incremement the age of each producer.
        for (Producer producer : cell.getProducersOccupying()) {
            producer.incrementAge();
        }
        // If the producer is at maximum age or randomly dies, remove it from the field.
        cell.getProducersOccupying().removeIf(producer -> Randomizer.getRandom().nextDouble() <=
                producer.getDeathChance(currentWeather.getClass()));
    }

    /**
     * Add new producers to the cell.
     */
    private void addNewProducers(FieldCell cell, ListSet<Class<? extends Producer>> simulatedProducers) {
        for (Class<? extends Producer> producer : simulatedProducers) {
            try {
                // Create a new instance of Producer using the dynamic class's constructor.
                Producer newProducer = producer
                        .getDeclaredConstructor()
                        .newInstance();
                if (Randomizer.getRandom().nextDouble() <= newProducer.getCreationChance(currentWeather.getClass())) {
                    cell.getProducersOccupying().add(newProducer);
                }
            }
            catch (NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Remove any old factors, then add new ones to the field.
     * @param simulatedFactors the factors to add from.
     */
    public void addressEnvironmentalFactors(ListSet<Class<? extends EnvironmentalFactor>> simulatedFactors) {
        for (FieldCell[] row : field) {
            for (FieldCell cell : row) {
                if (cell.getEnvironmentalFactorsPresent() != null) removeDefunctFactors(cell);
                addNewFactors(cell, simulatedFactors);
            }
        }
    }

    /**
     * Add new factors to the cell if the condition is met.
     * @param cell the cell in question.
     * @param simulatedFactors the factors to choose from.
     */
    private void addNewFactors(FieldCell cell, ListSet<Class<? extends EnvironmentalFactor>> simulatedFactors) {
        for (Class<? extends EnvironmentalFactor> factor : simulatedFactors) {
            try {
                EnvironmentalFactor newFactor = factor
                        .getDeclaredConstructor()
                        .newInstance();
                if (Randomizer.getRandom().nextDouble() <= newFactor.getCreationProbability()) {
                    cell.getEnvironmentalFactorsPresent().add(newFactor);
                }
            } catch (InvocationTargetException | InstantiationException | IllegalAccessException | NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Remove any factors which meet the condition.
     * @param cell the cell in question.
     */
    private void removeDefunctFactors(FieldCell cell) {
        cell.getEnvironmentalFactorsPresent().removeIf(EnvironmentalFactor::removeInstance);
    }

    /**
     * Remove certain structures based on removeInstance(), then add new ones to the field.
     * @param simulatedStructures the structures to choose from.
     */
    public void addressEnvironmentalStructures(ListSet<Class<? extends EnvironmentalStructure>> simulatedStructures) {
        for (FieldCell[] row : field) {
            for (FieldCell cell : row) {
                if (cell.getEnvironmentalStructuresPresent() != null) removeBrokenStructures(cell);
                addNewStructures(cell, simulatedStructures);
            }
        }
    }

    /**
     * Add some structures to the cell if createInstance(Weather) returns true is met.
     * @param field the field this structure is in.
     * @param cell the cell in question.
     * @param simulatedStructures the structures to pick from to add.
     */
    private void addNewStructures(FieldCell cell, ListSet<Class<? extends EnvironmentalStructure>> simulatedStructures) {
        for (Class<? extends EnvironmentalStructure> structure : simulatedStructures) {
            try {
                EnvironmentalStructure newStructure = structure
                        .getDeclaredConstructor(Field.class)
                        .newInstance(this);
                if (newStructure.createInstance(currentWeather.getClass())) {
                    cell.getEnvironmentalStructuresPresent().add(newStructure);
                }
            } catch (InvocationTargetException | InstantiationException | IllegalAccessException | NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Remove any structures from the cell where removeInstance(Weather) is true.
     * @param cell the cell to check.
     */
    private void removeBrokenStructures(FieldCell cell) {
        cell.getEnvironmentalStructuresPresent().removeIf(structure ->
                structure.removeInstance(currentWeather.getClass()));
    }
}

