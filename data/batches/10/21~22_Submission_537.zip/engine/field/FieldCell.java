package engine.field;

import engine.helpers.ListSet;
import engine.helpers.ClassSet;
import environment.factors.EnvironmentalFactor;
import environment.factors.structures.EnvironmentalStructure;
import environment.food.Entity;
import environment.food.producer.Producer;

public class FieldCell {

    private Entity entityOccupant;
    private ClassSet<Producer> producersOccupying;
    private ClassSet<EnvironmentalFactor> environmentalFactorsPresent;
    private ClassSet<EnvironmentalStructure> environmentalStructuresPresent;

    public FieldCell() {
        this.producersOccupying = new ClassSet<>();
        this.environmentalFactorsPresent = new ClassSet<>();
        this.environmentalStructuresPresent = new ClassSet<>();
    }

    public void setEntity(Entity entity) {
        if (entityOccupant != null) entityOccupant.setDead();
        entityOccupant = entity;
    }

    public void addProducer(Producer producer) {
        producersOccupying.add(producer);
    }

    public void addEnvironmentalFactor(EnvironmentalFactor factor) {
        environmentalFactorsPresent.add(factor);
    }

    public void addEnvironmentalStructure(EnvironmentalStructure structure) {
        environmentalStructuresPresent.add(structure);
    }

    // Getters for instance variables.

    public Entity getEntityOccupant() {
        return entityOccupant;
    }

    public ClassSet<Producer> getProducersOccupying() {
        return producersOccupying;
    }

    public ClassSet<EnvironmentalFactor> getEnvironmentalFactorsPresent() {
        return environmentalFactorsPresent;
    }

    public ClassSet<EnvironmentalStructure> getEnvironmentalStructuresPresent() {
        return environmentalStructuresPresent;
    }
}
