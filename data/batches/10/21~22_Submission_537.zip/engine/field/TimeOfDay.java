package engine.field;

public enum TimeOfDay {
    MORNING, MIDDAY, EVENING, NIGHT
}
