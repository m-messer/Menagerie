package engine;

import engine.helpers.ListSet;
import environment.factors.EnvironmentalFactor;
import environment.factors.structures.EnvironmentalStructure;
import environment.factors.structures.Tree;
import environment.food.Entity;
import environment.food.producer.Producer;
import environment.factors.diseases.Disease;

import java.util.List;

/**
 * This is a utility class to store various types of
 * parameters as one composite object.
 * @version 2022.03.02
 */
public class SimulationParameters {

    // Set of the entities to be included in the simulation.
    private ListSet<Class<? extends Entity>> simulatedEntities;
    // Set of the producers to simulate.
    private ListSet<Class<? extends Producer>> simulatedProducers;
    // Set of the environmental factors to simulate.
    private ListSet<Class<? extends EnvironmentalFactor>> simulatedFactors;
    // Set of the structures being simulated.
    private ListSet<Class<? extends EnvironmentalStructure>> simulatedStructures;

    // Create a new instance of SimulatorParameters.
    public SimulationParameters() {
        this.simulatedEntities = new ListSet<>();
        this.simulatedProducers = new ListSet<>();
        this.simulatedFactors = new ListSet<>();
        this.simulatedStructures = new ListSet<>();
    }

    // Getter methods for simulation factors.

    public ListSet<Class<? extends Entity>> getSimulatedEntities() {
        return simulatedEntities;
    }

    public ListSet<Class<? extends Producer>> getSimulatedProducers() {
        return simulatedProducers;
    }

    public ListSet<Class<? extends EnvironmentalFactor>> getSimulatedFactors() {
        return simulatedFactors;
    }
    
    public ListSet<Class<? extends EnvironmentalFactor>> getSimulatedDiseases() {
        ListSet<Class<? extends EnvironmentalFactor>> returnSet = new ListSet<>();
        returnSet.addAll(simulatedFactors);
        returnSet.removeIf(element -> !Disease.class.isAssignableFrom(element));
        return simulatedFactors;
    }

    public ListSet<Class<? extends EnvironmentalStructure>> getSimulatedStructures() {
        return simulatedStructures;
    }

    // Simulation factor setters.

    @SafeVarargs
    public final void setSimulatedEntities(Class<? extends Entity>... entities) {
        simulatedEntities.clear();
        simulatedEntities.addAll(List.of(entities));
    }

    @SafeVarargs
    public final void setSimulatedProducers(Class<? extends Producer>... producers) {
        simulatedProducers.clear();
        simulatedProducers.addAll(List.of(producers));
    }

    @SafeVarargs
    public final void setSimulatedFactors(Class<? extends EnvironmentalFactor>... factors) {
        simulatedFactors.clear();
        simulatedFactors.addAll(List.of(factors));
    }

    @SafeVarargs
    public final void setSimulatedStructures(Class<? extends EnvironmentalStructure>... structures) {
        simulatedStructures.clear();
        simulatedStructures.addAll(List.of(structures));
    }
}
