package engine.helpers;

import java.io.*;
import java.util.Scanner;

/**
 * This class serves to read and interpret CSV files
 * containing properties for various environmental objects.
 * @version 2022.10.02
 */
public class PropertyFileReader {

    public static final String DELIMITER = ",";
    public static final String SECONDARY_DELIMITER = "&";

    private final File file;
    private Scanner reader; // Must be reset at the start of every access method.
    private String fileContents;

    public PropertyFileReader(File file) {
        this.file = file;
        readFile();
    }

    /**
     * @param key The search value for the first item in the desired row.
     * @return the full row if the provided key matches.
     */
    public String[] getRow(String key) {
        resetScanner();
        String line;
        while (reader.hasNextLine()) {
            line = reader.nextLine();
            String[] splitLine = line.split(DELIMITER);
            if (splitLine[0].equals(key)) return splitLine;
        }
        return null;
    }

    /**
     * @return a value from an array based on the column title.
     */
    public String getValueByColumn(String[] values, FileProperties property) {
        resetScanner();
        String[] columnNames = reader.nextLine().split(DELIMITER);
        for (int columnIndex = 0; columnIndex < values.length; columnIndex++) {
            if (columnNames[columnIndex].equals(property.name())) return values[columnIndex];
        }
        return null;
    }

    /**
     * Reset the scanner to the starting line.
     */
    private void resetScanner() {
        reader = new Scanner(fileContents);
        reader.useDelimiter(DELIMITER);
    }

    /**
     * Reads the contents of the file into the contents variable.
     */
    private void readFile(){
        Scanner fileScanner;
        try {
            fileScanner = new Scanner(new FileReader(file));
            StringBuilder builder = new StringBuilder();
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                // Include line if it isn't a comment.
                if (line.charAt(0) != '#') builder.append(line).append("\n");
            }
            fileContents = builder.toString();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
