package engine.helpers;
import java.util.ArrayList;
import java.util.HashSet;
import environment.factors.structures.Tree;


/**
 * This is an implementation of ArrayList which
 * will store one instance of each object class.
 * @version 2022.03.02
 */
public class ClassSet<E> extends ArrayList<E> {
    
    /**
     * Allows a single instance of each class in the list.
     * @param element the element to add.
     * @return true if the element was added to the list (and it wasn't there already).
     */
    @Override
    public boolean add(E element) {
        if (getClassInstance(element.getClass()) == null) {
            super.add(element);
            return true;
        }
        return false;
    }
    
    /**
     * Looks for an object of the specified type, then returns it if present.
     * @param checkFor the class to check for.
     * @return true if the set contains an instance of this class.
     */
    public E getClassInstance(Class checkFor) {
        for (E listElement : this) {
            Class elementClass = listElement.getClass();
            if (elementClass.equals(checkFor)) {
                return listElement;
            }
        }
        return null;
    }
}
