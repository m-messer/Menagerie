package engine.helpers;

/**
 * This class allows one to bind a value with
 * some object.
 * @version 2022.03.02
 */
public class Propagator<T, V> {

    T boundObject;
    V value;

    public Propagator(T boundObject, V value) {
        this.boundObject = boundObject;
        this.value = value;
    }

    public T getBoundObject() {
        return boundObject;
    }

    public V getValue() {
        return value;
    }
}
