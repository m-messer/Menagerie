package engine.helpers;

import java.util.ArrayList;

/**
 * This class is to provide a collection-based set
 * mainly to allow use of Collection.shuffle().
 * @param <E> the set type.
 * @version 2022.02.28
 */
public class ListSet<E> extends ArrayList<E> {

    /**
     * Allows a single copy of each element in the list.
     * @param element the element to add.
     * @return true if the element was added to the list (and it wasn't there already).
     */
    @Override
    public boolean add(E element) {
        if (!super.contains(element)) {
            super.add(element);
            return true;
        }
        return false;
    }

}
