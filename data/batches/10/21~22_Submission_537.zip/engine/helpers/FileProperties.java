package engine.helpers;

/**
 * This enum stores potential values to be stored in
 * property files.
 * @version 2022.03.03
 */
public enum FileProperties {
    NAME, BREEDING_AGE, MAX_AGE, BIRTH_TIME, CREATION_PROBABILITY,
    DISAPPEARANCE_PROBABILITY, BREEDING_PROBABILITY, MAX_LITTER_SIZE, FOOD_VALUE, DISPLAY_COLOUR,
    CATCH_CHANCE, SPREAD_CHANCE, MAX_CARRY_TIME
}
