package engine;

import engine.field.Field;
import engine.helpers.*;
import environment.factors.EnvironmentalFactor;
import environment.factors.structures.EnvironmentalStructure;
import environment.factors.diseases.Anthrax;
import environment.factors.diseases.AvianFlu;
import environment.factors.diseases.Disease;
import environment.factors.structures.Tree;
import environment.factors.structures.Burrow;
import environment.food.Entity;
import environment.food.animal.*;
import environment.food.producer.Fern;
import environment.food.producer.Grass;
import environment.food.producer.Producer;
import windows.SimulatorView;

import javax.swing.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2022.03.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // Stores all the parameters for this simulation.
    private SimulationParameters parameters;
    // Storage for each of the objects which could be present on the field.
    private List<Entity> entities;

    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Can be used to start the program.
     * @param args program arguments.
     */
    public static void main(String[] args) {
        Simulator simulator = new Simulator();
        //simulator.runLongSimulation();
    }

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        // Sets the parameters which should be applied to the simulation.
        parameters = new SimulationParameters();
        parameters.setSimulatedEntities(Rabbit.class, Fox.class, Eagle.class, Vole.class, Monkey.class);
        parameters.setSimulatedProducers(Grass.class, Fern.class);
        parameters.setSimulatedFactors(Anthrax.class, AvianFlu.class);
        parameters.setSimulatedStructures(Tree.class, Burrow.class);

        entities = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        // Establish the behaviour of buttons.
        setViewButtonBehaviour();

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep() {
        if (view.isViable(field)) {

            // Set up the field for the next step.
            field.changeWeather();
            field.getStepCounter().increment();
            field.addressProducers(parameters.getSimulatedProducers());
            field.addressEnvironmentalFactors(parameters.getSimulatedFactors());
            field.addressEnvironmentalStructures(parameters.getSimulatedStructures());
            // Provide space for newborn animals.
            List<Entity> newEntities = new ArrayList<>();

            // Let all entities act.
            for (Iterator<Entity> it = entities.iterator(); it.hasNext(); ) {
                Entity entity = it.next();
                List<Entity> received = entity.act();
                newEntities.addAll(received);
                if (!entity.isAlive()) {
                    it.remove();
                }
            }

            // Add the newly born entities to the main list.
            entities.addAll(newEntities);
            updateStructureLabel();
            updateDiseaseLabel();
            updateTimeOfDayLabel();
            updateWeatherLabel();
            updatePlantLabel();
            view.showStatus(field.getStepCounter().getCount(), field);
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        field.getStepCounter().reset();
        entities.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(field.getStepCounter().getCount(), field);
    }

    /**
     * @return a random value from a set.
     */
    private <T> T getRandomListSetValue(ListSet<T> set) {
        Collections.shuffle(set);
        return set.get(0);
    }

    /**
     * Randomly populate the field with entities.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                
                ListSet<Class<? extends Entity>> seen = new ListSet<>();
                ListSet<Class<? extends Entity>> simulated = parameters.getSimulatedEntities();
                
                tryAddRandomPlant(new Location(row, col));
                tryAddRandomDisease(new Location(row, col));
                tryAddRandomStructure(new Location(row, col));
                
                while (seen.size() < simulated.size()) {
                    Class<? extends Entity> entityClass = getRandomListSetValue(simulated);
                    try {
                        PropertyFileReader reader = new PropertyFileReader(entityClass.getDeclaredConstructor().newInstance().getPropertyFile());
                        String[] dataRow = reader.getRow(entityClass.getSimpleName());
                        if (!seen.contains(entityClass) &&
                                Double.parseDouble(reader.getValueByColumn(dataRow, FileProperties.CREATION_PROBABILITY))
                                        >= rand.nextDouble()) {
                            Entity toAdd = entityClass
                                    .getDeclaredConstructor(Boolean.class, Field.class, Location.class)
                                    .newInstance(true, field, new Location(row, col));
                            entities.add(toAdd);
                            break;
                        }
                        else seen.add(entityClass);
                    } catch (InvocationTargetException | InstantiationException | IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (NoSuchMethodException e) {
                        System.out.println(entityClass+" does not have correctly implemented constructor/s.");
                        e.printStackTrace();
                    }
                }
            }
        }
        updateDiseaseLabel();
        updatePlantLabel();
        updateStructureLabel();
    }

    /**
     * Go through the simulated plants and check if they meet the chance to spawn.
     * @param location the location to add a disease at.
     */
    private void tryAddRandomPlant(Location location) {
        for (Class<? extends Producer> producerClass : parameters.getSimulatedProducers()) {
            try {
                Producer instance = producerClass.getDeclaredConstructor().newInstance();
                if (Randomizer.getRandom().nextDouble() <= instance.getCreationChance(field.getCurrentWeather().getClass())) {
                    field.getProducersAt(location).add(instance);
                }
            } catch (InvocationTargetException | InstantiationException | IllegalAccessException | NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Go through the simulated environmental structures and check if they meet the spawn condition.
     * When creating new structures, it should be noted that the constructor takes the field it is in as an argument.
     * @param location the location to add a structure at.
     */
    private void tryAddRandomStructure(Location location) {
        for (Class<? extends EnvironmentalStructure> structureClass : parameters.getSimulatedStructures()) {
            try {
                EnvironmentalStructure instance = structureClass.getDeclaredConstructor(Field.class).newInstance(field);
                if (instance.createInstance(field.getCurrentWeather().getClass())) {
                    field.getStructuresAt(location).add(instance);
                }
            } catch (InvocationTargetException | InstantiationException | IllegalAccessException | NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Go through the simulated diseases and check if they meet the chance to spawn.
     * @param location the location to add a disease at.
     */
    private void tryAddRandomDisease(Location location) {
        for (Class<? extends EnvironmentalFactor> diseaseClass : parameters.getSimulatedDiseases()) {
            try {
                Disease instance = (Disease) diseaseClass.getDeclaredConstructor().newInstance();
                if (instance.createInstance()) {
                    field.getFactorsAt(location).add(instance);
                }
            } catch (InvocationTargetException | InstantiationException | IllegalAccessException | NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Get and set the contents of the weather label.
     */
    private void updateWeatherLabel() {
        JLabel weatherLabel = view.getWeatherLabel();
        weatherLabel.setText("Weather: "+field.getCurrentWeather().getClass().getSimpleName());
    }

    /**
     * Get and set the contents of the time of day label from SimulatorView.
     */
    private void updateTimeOfDayLabel() {
        JLabel timeOfDayLabel = view.getTimeOfDayLabel();
        timeOfDayLabel.setText("Time: "+field.getTimeOfDay().name());
    }

    /**
     * Get the disease label from SimulatorView and set the text.
     */
    private void updateDiseaseLabel() {
        StringBuilder diseaseString = new StringBuilder();
        Map<Class<? extends Disease>, Integer> diseaseMap = field.getDiseaseMap();
        for (Class<? extends Disease> diseaseClass : diseaseMap.keySet()) {
            diseaseString.append("<br>").append("- ");
            diseaseString.append(diseaseClass.getSimpleName());
            diseaseString.append(" (").append(diseaseMap.get(diseaseClass)).append(")");
        }
        // Wrapping the text in <html> allows for line breaks.
        view.getDiseaseLabel().setText((diseaseString.toString().length() == 0) ?
                "Infected: None" : "<html>Infected: "+diseaseString+"</html>");
    }

    /**
     * Get the plants label from SimulatorView and set the text.
     */
    private void updatePlantLabel() {
        StringBuilder plantString = new StringBuilder();
        Map<Class<? extends Producer>, Integer> plantMap = field.getPlantMap();
        for (Class<? extends Producer> plantClass : plantMap.keySet()) {
            plantString.append("<br>").append("- ");
            plantString.append(plantClass.getSimpleName());
            plantString.append(" (").append(plantMap.get(plantClass)).append(")");
        }
        // Wrapping the text in <html> allows for line breaks.
        view.getPlantLabel().setText((plantString.toString().length() == 0) ?
                "Plants: None" : "<html>Plants: "+plantString+"</html>");
    }
    
    /**
     * Get the structure label from SimulatorView and set the text.
     */
    private void updateStructureLabel() {
        StringBuilder structureString = new StringBuilder();
        Map<Class<? extends EnvironmentalStructure>, Integer> structureMap = field.getStructureMap();
        for (Class<? extends EnvironmentalStructure> structureClass : structureMap.keySet()) {
            structureString.append("<br>").append("- ");
            structureString.append(structureClass.getSimpleName());
            structureString.append(" (").append(structureMap.get(structureClass)).append(")");
        }
        // Wrapping the text in <html> allows for line breaks.
        view.getStructureLabel().setText((structureString.toString().length() == 0) ?
                "Structures: None" : "<html>Structures: "+structureString+"</html>");
    }

    /**
     * Run methods to define UI button behaviours.
     */
    private void setViewButtonBehaviour() {
        setOneStepButton();
        setLongSimButton();
        setResetButton();
    }

    private void setOneStepButton() {
        JButton oneStep = view.getOneStepButton();
        oneStep.addActionListener(event -> simulateOneStep());
    }

    private void setLongSimButton() {
        // Define text field behaviour to work with the button.
        JTextField textField = view.getSimStepsField();
        textField.setToolTipText("Insert the number of steps to simulate.");
        textField.setText("1");
        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {} // do nothing

            // If the text field does not contain a number, overwrite it.
            @Override
            public void focusLost(FocusEvent e) {
                try {
                    Integer.parseInt(textField.getText());
                }
                catch (NumberFormatException ignored) {
                    textField.setText("1");
                }
            }
        });
        // Define button behaviour.
        JButton longSimButton = view.getLongSimButton();
        longSimButton.addActionListener(event -> SwingUtilities.invokeLater(
                () -> simulate(Integer.parseInt(textField.getText()))
        ));

    }

    private void setResetButton() {
        JButton resetButton = view.getResetFieldButton();
        resetButton.addActionListener(event -> reset());
    }
}

