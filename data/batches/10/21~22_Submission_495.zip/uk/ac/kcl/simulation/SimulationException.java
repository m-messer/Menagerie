package uk.ac.kcl.simulation;

import uk.ac.kcl.util.Tuple;

public class SimulationException extends RuntimeException {
    public SimulationException(String message) { super(message); }

    protected static SimulationException
    invalidMove(Tuple<Integer, Integer> position,
                Tuple<Integer, Integer> destination, String reason) {
        return new SimulationException("cannot move agent from " + position +
                                       " to " + destination + ", as " + reason);
    }

    protected static IndexOutOfBoundsException indexOutOfBounds(int row,
                                                                int column) {
        return new IndexOutOfBoundsException(String.format(
            "cannot access the cell at [%d][%d], as it does not exist", row,
            column));
    }
}
