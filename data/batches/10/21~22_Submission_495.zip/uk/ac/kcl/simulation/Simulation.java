package uk.ac.kcl.simulation;

import java.awt.Graphics;
import java.util.*;
import java.util.function.Function;
import uk.ac.kcl.simulation.Agent.Descriptor;
import uk.ac.kcl.util.Option;
import uk.ac.kcl.util.Percentage;
import uk.ac.kcl.util.Tuple;
import java.awt.Color;

public class Simulation {
    State state;
    Set<Agent> agents;
    Set<BackgroundAgent> backgroundAgents = new HashSet<>();
    // the time, as a long representing the number of ticks elapsed
    long time;

    /**
     * Return the total number of elapsed ticks in this simulation
     * @return a <code>long</code>
     */
    public long time() { return this.time; }

    /**
     * A Builder for a <code>Simulation</code>
     * You should set: <code>spawners</code>,
     * <code>dimensions</code>, <code>totalCoverage</code> and <code>view</code>
     */
    public static class Builder {
        /**
         * A list of <code>SpawnDescriptor</code> objects describing the various
         * types of agents we should spawn
         */
        public ArrayList<Descriptor> spawners = new ArrayList<>();
        /** Describes the grid of cells that the simulation will use */
        public Tuple<Integer, Integer> dimensions =
            new Tuple<Integer, Integer>(20, 20);
        /** The chance that a cell will spawn any agent */
        public Percentage totalCoverage = new Percentage(0.2);
        /**
         * Background agents in this simulation, a background agent is not
         * spawned in to a cell, but does have its <code>update</code> method
         * called each tick
         */
        public ArrayList<BackgroundAgent> backgroundAgents = new ArrayList<>();

        public Builder() {}

        /**
         * Consumes this builder, returning a <code>Simulation</code>
         */
        public Simulation build() { return new Simulation(this); };
    }

    Simulation(Simulation.Builder builder) {
        int width = builder.dimensions.getA();
        int height = builder.dimensions.getB();
        this.state = new State(width, height);
        this.agents = new HashSet<>();

        // populate cells
        ArrayList<Tuple<Double, Agent.Descriptor>> weightedSpawners =
            new ArrayList<>(builder.spawners.size());
        double total = 0;
        for (Agent.Descriptor spawner : builder.spawners) {
            total += spawner.weight;
        }
        double acc = 0;
        for (Agent.Descriptor spawner : builder.spawners) {
            acc += spawner.weight / total * builder.totalCoverage.get();
            weightedSpawners.add(new Tuple<>(acc, spawner));
        }

        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                double random = Math.random();
                for (Tuple<Double, Agent.Descriptor> weightedSpawner :
                     weightedSpawners) {
                    if (random <= weightedSpawner.getA()) {
                        this.spawnAgent(weightedSpawner.getB(), i, j);
                        break;
                    }
                }
                state.get(i, j);
            }
        }

        // Add background agents
        for (BackgroundAgent agent : builder.backgroundAgents) {
            this.backgroundAgents.add(agent);
        }
    }

    /** The color that the screen will be cleared with */
    Color backgroundColor = Simulation.DEFAULT_BACKGROUND_COLOR;

	/** A suggested default background color */
	public static final Color DEFAULT_BACKGROUND_COLOR = Color.WHITE;

	/**
	 * Getter for the background color of this simulation -- the
	 * simulation view will be cleared with this color before drawing 
	 * the agents
	 * @return the <code>Color</code> of this simulation
	 */
	public Color backgroundColor() {
		return this.backgroundColor;
	}

	/**
	 * Set the background color -- see <code>Simualtion.backgroundColor()
	 * </code> for more information
	 * @param backgroundColor the <code>Color</code> to set the background 
	 * to
	 */
	public void setBackgroundColor(Color backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

    /**
     * Draw the contents of this simulation to the view
     * specified
     */
    protected void draw(SimulationView view, Graphics g) {
		g.setColor(this.backgroundColor());
		g.fillRect(0, 0, view.width, view.height);

        int stepX = view.cellDimensions.getA();
        int stepY = view.cellDimensions.getB();
        int posX = 0;
        int posY = 0;

        for (int i = 0; i < this.state().height(); i++) {
            for (int j = 0; j < this.state().width(); j++) {
                Cell cell = this.state().get(i, j);
                if (cell.agent().isNone()) {
                    posX += stepX;
                    continue;
                }
                Agent agent = cell.agent().unwrap();
                g.setColor(agent.colorFilter(this, agent.descriptor.color));
                g.fillRect(posX, posY, stepX, stepY);
                posX += stepX;
            }
            posX = 0;
            posY += stepY;
        }
    }

    /**
     * update all the agents in this simulation.
     * Calls the <code>Agent.update(Simulation simulation)</code>
     * method on each agent
     */
    public void update() {
        this.time++;

        // We are putting these in an ArrayList first so we don't get concurrent
        // access exceptions (which, btw, don't exist in safe rust)
        ArrayList<Agent> agents = new ArrayList<>();
        for (Agent agent : this.agents) {
            agents.add(agent);
        }
        for (Agent agent : agents) {
            if (agent.queuedToDie) {
                this.agents.remove(agent);
                continue;
            }
            agent.update(this);
        }
        for (BackgroundAgent backgroundAgent : this.backgroundAgents) {
            backgroundAgent.update(this);
        }
    }

    /**
     * Returns a set containing all the agents in this simulation --
     * note, an agent may be <code>queuedToDie</code>, agents that are
     * <code>queuedToDie</code> should not be handled!
     * @return <code>Set<Agent></code> of all agents in the
     * simulation
     */
    public Set<Agent> agents() { return this.agents; }

    /**
     * Moves the agent at <code>position</code> to the point at
     * <code>destination</code>
     * @param position the position of the agent you would like to move
     * @param destination the destination of the agent
     */
    public void move(Tuple<Integer, Integer> position,
                     Tuple<Integer, Integer> destination)
        throws SimulationException {
        Cell fromCell = this.state().get(position.getA(), position.getB());
        Cell toCell = this.state().get(destination.getA(), destination.getB());

        this.move(fromCell, toCell);
    }

    /**
     * Same as <code>Simulation.State.move()</code> but using a position
     * and destination <code>Cell</code> instead
     * @param fromCell the starting cell
     * @param toCell the destination cell
     */
    public void move(Cell fromCell, Cell toCell) {
        Tuple<Integer, Integer> position =
            new Tuple<>(fromCell.column(), fromCell.row());
        Tuple<Integer, Integer> destination =
            new Tuple<>(toCell.column(), toCell.row());

        if (fromCell.agent().isNone()) {
            throw SimulationException.invalidMove(
                position, destination, "there is no agent at `position`");
        } else if (!toCell.agent().isNone()) {
            throw SimulationException.invalidMove(
                position, destination, "the cell at `destination` is occupied");
        }

        Agent agent = fromCell.agent().unwrap();
        agent.row = destination.getB();
        agent.column = destination.getA();
        fromCell.clear();
        toCell.set(agent);
    }

    /**
     * Kills the agent at the specified cell -- if no agent exists in this
     * cell, nothing happens
     * @param cell the cell where the agent that will die lives
     */
    public void kill(Cell cell) {
        if (!cell.agent().isNone()) {
            Agent agent = cell.agent().unwrap();
            agent.queuedToDie = true;
        }
        cell.clear();
    }

    /**
     * Create a new agent and spawn it at a specified location.
     * Agents must be created this way so that the <code>Simulation</code> can
     * manage them
     */
    public Agent spawnAgent(Agent.Descriptor descriptor, int row, int column) {
        if (this.state().inBounds(row, column)) {
            Agent agent = descriptor.spawn.apply();
            agent.row = row;
            agent.column = column;
            this.agents.add(agent);
            this.state().get(row, column).set(agent);
            return agent;
        }
        throw SimulationException.indexOutOfBounds(row, column);
    }

    /**
     * Represents a cell in the simulation
     */
    public static class Cell {
        Option<Agent> agent;
        // location of the cell
        int row;
        int column;

        Cell(int row, int column, Option<Agent> agent) {
            this.agent = agent;
            this.row = row;
            this.column = column;
        }

        /**
         * Getter for the agent that this cell encapsulates
         * @return the agent that this cell encapsulates or None, if this
         * cell is empty
         */
        public Option<Agent> agent() { return this.agent; }

        /**
         * Protected setter for this cell's agent
         * @param agent the agent that this cell should be set to
         * contain
         */
        void set(Agent agent) { this.agent = Option.some(agent); }

        /**
         * Clear this cell so it does not encapsulate any agent
         */
        void clear() { this.agent = Option.none(); }

        /**
         * Getter for the row compoonent of this cell's position
         * @return an <code>int</code> representing this cell's position
         */
        public int row() { return this.row; }

        /**
         * Setter for the column component of this cell's position
         * @return a <code>int</code> representing this cell's positio
         */
        public int column() { return this.column; }
    }

    /**
     * Contains the cells of the simulation
     */
    public static class State {
        // The cells of this state
        Cell[][] cells;
        int width;
        int height;

        State(int width, int height) {
            this.width = width;
            this.height = height;
            this.cells = new Cell[height][width];
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    this.cells[i][j] = new Cell(i, j, Option.none());
                }
            }
        }

        /**
         * Handy list of the locations of all the relative bordering cells
         * aka, row + x = the bordering cell's row
         */
        public static ArrayList<Tuple<Integer, Integer>>
            BORDERING_CELL_OFFSETS = new ArrayList<Tuple<Integer, Integer>>() {
                {
                    add(new Tuple<>(-1, 0));
                    add(new Tuple<>(-1, 1));
                    add(new Tuple<>(0, 1));
                    add(new Tuple<>(1, 1));
                    add(new Tuple<>(1, 0));
                    add(new Tuple<>(1, -1));
                    add(new Tuple<>(0, -1));
                    add(new Tuple<>(-1, -1));
                }
            };

        /** internal method -- just hoping java callbacks aren't trash */
        private ArrayList<Cell>
        getBorderingCellsFiltered(int row, int column,
                                  Function<Cell, Boolean> cbfun) {
            ArrayList<Cell> borderingCells = new ArrayList<>();
            for (Tuple<Integer, Integer> offset : BORDERING_CELL_OFFSETS) {
                Option<Cell> option =
                    this.tryGet(row + offset.y(), column + offset.x());
                if (!option.isNone()) {
                    Cell cell = option.unwrap();
                    if (cbfun.apply(cell)) {
                        borderingCells.add(cell);
                    }
                }
            }
            return borderingCells;
        }

        /**
         * Returns the cells bordering a specified cell
         * @param row the row of the center cell
         * @param column teh column of the center cell
         * @return a list of bordering cells
         */
        public ArrayList<Cell> getBorderingCells(int row, int column) {
            return this.getBorderingCellsFiltered(row, column,
                                                  (cell) -> { return true; });
        }

        /**
         * Gets all the cells bordering a specific cell, that are empty
         * @param row the row of the center cell
         * @param column the column of the center cell
         * @return a list of bordering cells
         */
        public ArrayList<Cell> getEmptyBorderingCells(int row, int column) {
            return this.getBorderingCellsFiltered(
                row, column, (cell) -> { return cell.agent().isNone(); });
        }

        /**
         * Gets all the cells bordering a specific cell, that are occupied
         * a.k.a
         * @param row the row of the center cell
         * @param column the column of the center cell
         * @return a list of boerdering cells
         */
        public ArrayList<Cell> getOccupiedBorderingCells(int row, int column) {
            return this.getBorderingCellsFiltered(
                row, column, (cell) -> { return !cell.agent().isNone(); });
        }

        /**
         * Checks if a given position exists in this state
         * @param row the row component of the posiiton
         * @param column the column component of the position
         * @return a <code>boolean</code> indicating if the specified position
         *     exists
         */
        public boolean inBounds(int row, int column) {
            return row < this.cells.length && row >= 0 && column >= 0 &&
                column < this.cells[row].length;
        }

        /**
         * Get the cell at a specified position
         * @param row the row index of the cell
         * @param column the column index of the cell
         * @return a <code>Cell</code> in this state
         */
        public Cell get(int row, int column) {
            if (this.inBounds(row, column)) {
                return this.cells[row][column];
            }
            throw SimulationException.indexOutOfBounds(row, column);
        }

        /**
         * The same as <code>State.get</code>, but returns a None variant
         * instead of panicking when we cannot access the cell at the specified
         * location
         */
        public Option<Cell> tryGet(int row, int column) {
            if (this.inBounds(row, column)) {
                return Option.some(this.cells[row][column]);
            }
            return Option.none();
        }

        /**
         * getter for the state's width
         * @return an <code>int</code> retpresenting the state's width
         */
        public int width() { return this.width; }

        /**
         * getter for the state's height
         * @return an <code>int</code> representing the state's height
         */
        public int height() { return this.height; }
    }

    /**
     * Returns the state of this simulation
     * @return the <code>State</code> of this simulation
     */
    public State state() { return this.state; }

    Simulation() {}
}
