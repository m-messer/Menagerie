package uk.ac.kcl.simulation;

import java.awt.*;
import javax.swing.*;
import uk.ac.kcl.util.Tuple;

/**
 * Class managing the swing GUI for this simulation
 */
public class SimulationView extends JPanel {
    /** The main JFrame */
    JFrame frame;
    Simulation simulation;
    Image image;
    Graphics imageGraphics;

    /** the size of one cell in this simulation */
    protected Tuple<Integer, Integer> cellDimensions;
    /** the inner width of this window */
    protected int width;
    /** the inner height of this window */
    protected int height;

    @Override
    public void paint(Graphics panelGraphics) {
		if (image == null || imageGraphics == null) return;
        imageGraphics.clearRect(0, 0, frame.getContentPane().getWidth(),
                                frame.getContentPane().getHeight());
        simulation.draw(this, imageGraphics);
        panelGraphics.drawImage(this.image, 0, 0, null);
    }

	/**
	 * updates this to display the current state of the simulation
	 */
	public void update() {
		this.repaint();
	}

    /**
     * Sets up and starts the simulation
     */
    protected SimulationView(Builder builder) {
        this.simulation = builder.simulation;
        this.cellDimensions = builder.cellDimensions;

        this.frame = new JFrame(builder.title);
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.width = simulation.state().width() * builder.cellDimensions.getA();
        this.height =
            simulation.state().height() * builder.cellDimensions.getB();
        this.frame.getContentPane().setPreferredSize(
            new Dimension(width, height));
        this.frame.pack();

        this.frame.setVisible(true);
        this.frame.getContentPane().add(this);
        this.frame.setVisible(true);
        this.frame.setResizable(false);

        this.image = this.createImage(this.width, this.height);
        this.imageGraphics = this.image.getGraphics();
    }

    /**
     * Class for setting the parameters to the SimulationView
     * window.
     */
    public static class Builder {
        /** The title of the window */
        public String title = "No Title";
        /**
         * the size (width, height), in pixels, of one tile in
         * this simulation
         */
        public Tuple<Integer, Integer> cellDimensions =
            new Tuple<Integer, Integer>(10, 10);
        /** The simluation that this view should draw */
        public Simulation simulation;

        /** Create a new SimulatinViewBuilder */
        public Builder() {}

        /**
         * Consumes this builder, returning a SimulationView
         * and initialising it
         */
        public SimulationView build() { return new SimulationView(this); }
    }
}