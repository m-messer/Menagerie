package uk.ac.kcl.simulation;

/**
 * A special kind of agent that only calls update
 * This is separate from <code>Agent</code> to reduce
 * the need for casting when creating agents
 */
public class BackgroundAgent {
    /** Same as <code>Agent.update(Simulation simulation)</code> */
    public void update(Simulation simulation) {}

    /**
     * The name of this background agent
     * @return the name of this background agent (to be displayed)
     */
    public String name() { return "no_name"; }
}
