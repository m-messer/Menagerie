package uk.ac.kcl.simulation;

import java.awt.Color;

/**
 * Represents anything that can exist
 * in the simulation
 */
public class Agent {
    protected Descriptor descriptor;
    // the position of this agent
    protected int row;
    protected int column;
    // if this agent has been killed, set flag to true
    protected boolean queuedToDie = false;

    /** How many update cycles this agent has existed for */
    public int ticksLived;

    public Agent() {}

    @Override
    public String toString() {
        return this.descriptor.name + " agent";
    }

    /**
     * Check if this agent is queued to die -- agents that
     * are should not be handled!
     * @return <code>true</code> if this agent is queued to die,
     *  otherwise <code>false</code>
     */
    public boolean queuedToDie() {
		return this.queuedToDie;
	}

    /**
     * Functional interface for a spawner for an <code>
     * Agent</code> This should return a new <code>Agent</code>
     */
    @FunctionalInterface
    public static interface SpawnFunction {
        Agent apply();
    }

    /**
     * get the row of this agent
     * @return an <code>int</code> representing the index of the row
     * that the agent is on
     */
    public int row() { return this.row; }

    /**
     * get the column of this agent
     * @return an <code>int</code> representing the index of the column
     * that the agent is on
     */
    public int column() { return this.column; }

    /**
     * Describes how to spawn an <code>Agent</code>
     */
    public static class Descriptor {
        protected String name;
        protected Color color;
        protected double weight;
        protected SpawnFunction spawn;

        Descriptor() {}

        /** A builder for an <code>Agent.Descriptor</cpde> */
        public static class Builder {
            /** the name of this agent */
            public String name = "no_name";
            /** the color that this agent will appear as in the simulation */
            public Color color = Color.BLACK;
            /** the spawn weight of this agent */
            public double spawnWeight = 1;
            /** a constructor for this agent */
            public SpawnFunction spawnFunction = () -> { return new Agent(); };

            /** build a <code>Descriptor</code> with this builder */
            public Descriptor build() {
                Agent.Descriptor descriptor = new Descriptor();
                SpawnFunction spawnFunctionDecorated = () -> {
                    Agent agent = this.spawnFunction.apply();
                    agent.descriptor = descriptor;
                    return agent;
                };
                descriptor.name = this.name;
                descriptor.color = this.color;
                descriptor.spawn = spawnFunctionDecorated;
                descriptor.weight = this.spawnWeight;
                return descriptor;
            }
        }
    }

    /**
     * Every time an agent is drawn, it is first passed through a colour
     * filter, which takes its base color in and spits out another color
     * @param color the base color of this agent
     * @return the color that this agent will be displayed as
     */
    public Color colorFilter(Simulation simulation, Color color) {
        return color;
    }

    /**
     * Constructor for this <code>Agent</code> used internally
     * by the simulation manager
     * @return a new <code>Agent</code>
     */
    public static Agent spawn() { return new Agent(); }

    /**
     * Called each time the simulation updates
     * @param simulation the <code>Simulation</code> that this agent
     * is a part of
     */
    public void update(Simulation simulation) { this.ticksLived += 1; }
}
