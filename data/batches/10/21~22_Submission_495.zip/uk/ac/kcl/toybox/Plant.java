package uk.ac.kcl.toybox;

import java.util.ArrayList;
import uk.ac.kcl.simulation.*;
import uk.ac.kcl.util.Percentage;

public class Plant extends AgentSusceptibleToDisease {
    /** The number of ticks it takes for this plant to die */
    public int ticksToKill = 100;
    /** The chance of this plant spreading to a neighbouring cell each tick */
    public Percentage spreadChance = new Percentage(0.05);
    /** The number of ticks that need to pass before this plant can spread */
    public int ticksUntilBloomed = 50;

    /**
     * Additional method called each time the plant may grow to see if it
     * can
     * @return a boolean representing if this plant can grow
     */
    public boolean canGrow() { return true; }

    @Override
    public void update(Simulation simulation) {
        super.update(simulation);
        // kill this plant if necessary
        if (this.ticksToKill <= this.ticksLived) {
            simulation.kill(simulation.state().get(this.row, this.column));
            return;
        }

        // if this plant should not spread, stop early
        if (this.ticksLived < this.ticksUntilBloomed ||
            !this.spreadChance.run() || !this.canGrow()) {
            return;
        }

        ArrayList<Simulation.Cell> emptyBorderingCells =
            simulation.state().getEmptyBorderingCells(this.row, this.column);
        if (emptyBorderingCells.size() > 0) {
            int randint =
                uk.ac.kcl.util.Math.randint(0, emptyBorderingCells.size());
            Simulation.Cell destination = emptyBorderingCells.get(randint);
            simulation.spawnAgent(this.descriptor, destination.row(),
                                  destination.column());
        }
    }
}