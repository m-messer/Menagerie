package uk.ac.kcl.toybox;

import java.awt.Color;
import uk.ac.kcl.simulation.Agent;
import uk.ac.kcl.simulation.Simulation;

/**
 * Represents any agent that can be infected and should
 * check to see the progress of the infection. An agent
 * that is infected will. ALl this adds is an additional
 * field <code>ticksDiseased</code>
 */
public class AgentSusceptibleToDisease extends Agent {
    private int ticksDiseased = 0;

    /**
     * Keeps track of how long this agent has been
     * infected with a given disease
     * @return an integer representing how long this agent
     * has been infected
     */
    public int ticksDiseased() { return this.ticksDiseased; }

    /**
     * Set the number of ticks this agent has been
     * infected for
     * @param ticks the number of ticks...
     */
    public void setTicksDiseased(int ticks) { this.ticksDiseased = ticks; }

	// returns a redder version of this color
    @Override
    public Color colorFilter(Simulation simulation, Color color) {
        Color superColor = super.colorFilter(simulation, color);
        if (this.ticksDiseased > 0) {
            Color filteredColor = new Color(
                superColor.getRed() < 255 - 50 ? superColor.getRed() + 50 : 255,
                superColor.getGreen(), superColor.getBlue()).darker();
			return filteredColor;
        }
        return superColor;
    }
}
