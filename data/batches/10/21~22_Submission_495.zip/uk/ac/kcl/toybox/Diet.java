package uk.ac.kcl.toybox;

import java.util.HashSet;
import java.util.Set;

/**
 * Represents what a given animal might eat, or what a 
 * certain disease might infect
 */
public class Diet {
    Set<Class<?>> diet = new HashSet<Class<?>>();

    /**
     * Construct a new <code>Diet</code> with the given agents in it
     * @param foods All the different types that this animal can
     * consume
     */
    public Diet(Class<?>... foods) {
        for (Class<?> food : foods) {
            diet.add(food);
        }
    }

	/**
	 * Check if a given agent is in this diet
	 * @param food the class of the thing that might be in this diet
	 * @return <code>true</code> if this agent is present in this diet, otherwise
	 * false
	 */
    public boolean contains(Class<?> food) {
		return this.diet.contains(food);
	}
}
