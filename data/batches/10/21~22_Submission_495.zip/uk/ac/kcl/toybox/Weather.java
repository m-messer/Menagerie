package uk.ac.kcl.toybox;

import java.awt.Color;
import uk.ac.kcl.simulation.BackgroundAgent;
import uk.ac.kcl.simulation.Simulation;
import uk.ac.kcl.util.Percentage;

/** Represents a weather system */
public class Weather extends BackgroundAgent {
    boolean isActive = false;

    /**
     * Polled to see if this weather is currently prevalent
     * @return <code>true</code> if this weather is prevalent,
     * otherwise false.
     */
    public boolean isActive() { return this.isActive; }

    /**
     * Set this to the color that the background should be whenever
     * this system is active
     */
    public Color backgroundColor = Color.BLACK;
    /**
     * The chance that this weather system activates at any given
     * update
     */
    public Percentage activateChance = new Percentage(0.1);
    /**
     * The chance that this weather system deactivates at any given
     * update
     */
    public Percentage deactivateChance = new Percentage(0.1);

    @Override
    public void update(Simulation simulation) {
        if (this.isActive()) {
            simulation.setBackgroundColor(this.backgroundColor);
            if (this.deactivateChance.run()) {
                this.isActive = false;
            }
        } else {
            simulation.setBackgroundColor(Simulation.DEFAULT_BACKGROUND_COLOR);
            if (this.activateChance.run()) {
                this.isActive = true;
            }
        }
    }

    public Weather() {}
}
