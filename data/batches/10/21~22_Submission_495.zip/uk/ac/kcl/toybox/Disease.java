package uk.ac.kcl.toybox;

import java.util.*;

import uk.ac.kcl.simulation.*;
import uk.ac.kcl.simulation.Simulation;
import uk.ac.kcl.util.Percentage;

/**
 * Simulates a disease -- a disease can spawn in a set of agents,
 * infect a set of agents and kill a set of agents, these sets
 * all may differ
 * <h3>Things to Set</h1>
 * <ul>
 * 	<li><code>int spawnsIn</code></li>
 * 	<li><code>Percentage chanceOfSpreading</code></li>
 * 	<li><code>Diet hosts</code></li>
 * 	<li><code>Diet kills</code></li>
 * 	<li><code>int ticksToKill</code></li>
 * 	<li><code>Percentage chanceOfCuring</code></li>
 * </ul>
 */
public class Disease extends BackgroundAgent {
    /** Constructs a new Disease */
    public Disease() {}

    /**
     * The chance of any agent in  being infected by this
     * disease. The disease will run this number on all agents
     * every tick
     */
    public Percentage chanceOfSpawning = new Percentage(0.001);
    /**
     * The agents that this disease can spawn in, this disease
     * will randomly spawn in one of these agents at a rate of
     * <code>Disease.chanceOfSpawning</code> per agent per tick
     */
    public Diet spawnsIn = new Diet();
    /** The chance of a disease infecting a neighbouring agent */
    public Percentage chanceOfSpreading = new Percentage(0.5);
    /** All agents that can carry this disease */
    public Diet hosts = new Diet();
    /** All agents that can die from this disease */
    public Diet kills = new Diet();
    /**
     * The number of ticks it takes  for this disease to
     * kill an agent
     */
    public int ticksToKill = 100;
    /**
     * The chance, per agent, per tick, that any agent might be
     * cured of this disease
     */
    public Percentage chanceOfCuring = new Percentage(0.2);

    /** The infected agents */
    private Set<AgentSusceptibleToDisease> agents =
        new HashSet<AgentSusceptibleToDisease>();
    /**
     * Getter for the agents that hosts this disease
     * @return the <code>Agent</code> that hosts this disease
     */
    public Set<AgentSusceptibleToDisease> agents() { return this.agents; }

    @Override
    public void update(Simulation simulation) {
        super.update(simulation);
        for (Agent agent : simulation.agents()) {
            // we might infect other diseases if we don't do this! weird!
            if (!(agent instanceof AgentSusceptibleToDisease)) {
                continue;
            }
            AgentSusceptibleToDisease susAgent =
                (AgentSusceptibleToDisease)agent;
            Class<?> susAgentClass = susAgent.getClass();
            // This agent is already infected
            if (this.agents.contains(agent)) {
                susAgent.setTicksDiseased(susAgent.ticksDiseased() + 1);
                // if this disease actually kills this
                if (this.kills.contains(susAgentClass) &&
                    this.ticksToKill <= susAgent.ticksDiseased()) {
                    // oh no it died!
                    simulation.kill(
                        simulation.state().get(agent.row(), agent.column()));
                    // if it gets lucky enough to be cured, cure it
                } else if (this.chanceOfCuring.run()) {
                    susAgent.setTicksDiseased(0);
                    this.agents().remove(susAgent);
                } else {
                    // spread the disease to a neighbouring agent
                    if (!this.chanceOfSpreading.run()) {
                        continue;
                    }
                    ArrayList<Simulation.Cell> occupiedBorderingCells =
                        simulation.state().getOccupiedBorderingCells(
                            susAgent.row(), susAgent.column());
					if (!(occupiedBorderingCells.size() > 0)) {
						continue;
					}
                    int rand = uk.ac.kcl.util.Math.randint(
                        0, occupiedBorderingCells.size());
                    Simulation.Cell cell = occupiedBorderingCells.get(rand);
                    Agent unluckyAgent = cell.agent().unwrap();
                    // only spread if the target is a host
                    if (unluckyAgent instanceof AgentSusceptibleToDisease &&
                        this.hosts.contains(unluckyAgent.getClass())) {
                        AgentSusceptibleToDisease susUnluckyAgent =
                            (AgentSusceptibleToDisease)unluckyAgent;
                        susUnluckyAgent.setTicksDiseased(1);
                        this.agents.add(susUnluckyAgent);
                    }
                }
            } else if (this.spawnsIn.contains(susAgentClass)) {
                // spawn this disease
                if (this.chanceOfSpawning.run()) {
                    susAgent.setTicksDiseased(1);
                    this.agents().add(susAgent);
                }
            }
        }
    }
}
