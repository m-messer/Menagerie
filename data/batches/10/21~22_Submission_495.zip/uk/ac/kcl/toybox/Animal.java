package uk.ac.kcl.toybox;

import java.awt.Color;
import java.util.*;

import uk.ac.kcl.simulation.*;
import uk.ac.kcl.util.Percentage;

/**
 * An agent that randomly moves around, and polls to see if it should die. It
 * also comes with a sex, so that if two animals of the same sex are next to
 * eachother, they might reproduce
 */
public class Animal extends AgentSusceptibleToDisease {
    public static Diet diet = new Diet() {};
    /**
     * The diet of this animal
     * @return a set containing all agents that this animal eats
     */
    public Diet diet() { return Animal.diet; }

    /**
     * Indicates whether this animal is hungry or not, an animal
     * will only eat when it is hungry
     * @return a boolean representing whether or not this animal is
     * hungry
     */
    public boolean isHungry() { return true; }

    /**
     * indicates whether or not this animal is sleeping, an animal
     * that is sleeping will not get hungrier and will not move
     * @return a boolean representing whether or not this animal is
     * sleeping
     */
    public boolean isSleeping(Simulation simulation) { return false; }

    // /**
    //  * Indicates whether this animal can mate or not, an animal
    //  * might not be able to mat eif it is very hugnry for example
    //  * @return a boolean representing whether or not this animal
    //  * can mate
    //  */
    // public boolean canMate() { return true; }

    public Animal() {
        if (new Percentage(0.5).run()) {
            this.sex = Sex.MALE;
        } else {
            this.sex = Sex.FEMALE;
        }
        {
            int tenPercent = (int)(this.ticksToKill * 0.1);
            int plusMinus = (int)(Math.random() * tenPercent);
            plusMinus -= tenPercent / 2;
            this.ticksToKill += plusMinus;
        }
    }

    /** Essentially a boolean equivalent, that can either be MALE or FEMALE */
    public static enum Sex {
        MALE,
        FEMALE;

        public static boolean canMate(Sex sexA, Sex sexB) {
            return sexA == MALE && sexB == FEMALE ||
                sexA == FEMALE && sexB == MALE;
        }
    }

    /** The animal's sex, set randomly by default */
    public final Sex sex;
    /**
     * The chance that this animal will reproduce successfully
     * with another animal
     */
    public Percentage reproductionSuccess = new Percentage(0.1);
    /** The number of ticks since this animal last ate something */
    public int ticksSinceLastMeal = 0;
    /**
     * An animal can only reproduce if it is an adult, this is the time
     * it takes for an animal to become an adult
     */
    public int ticksUntilAdult = 100;
    /**
     * If the animal has not eaten for this many ticks, it will starve
     * and die
     */
    public int ticksToStarve = 200;
	/**
	 * The number of update cycles this animal should live for
	 */
	public int ticksToKill = 300;
	/** Whether this agent is an adult or not (can reprduce) */
    protected boolean isAdult = false;

    @Override
    public Color colorFilter(Simulation simulation, Color color) {
		Color superColor = super.colorFilter(simulation, color);
        // if the animal is sleeping, it should be darker
        if (this.isSleeping(simulation)) {
            return superColor.darker();
        }
        return superColor;
    }

    @Override
    public void update(Simulation simulation) {
        super.update(simulation);

        Simulation.Cell position =
            simulation.state().get(this.row, this.column);
        this.ticksSinceLastMeal++;

        // this grows to an adult when it is time
        if (this.ticksLived == this.ticksUntilAdult) {
            this.isAdult = true;
        }

        // starve if need be
        if (this.ticksSinceLastMeal >= this.ticksToStarve) {
            simulation.kill(simulation.state().get(this.row, this.column));
            return;
        }
        // no need to update anything if this animal is sleeping
        if (this.isSleeping(simulation)) {
            return;
        }

        // if the animal has lived too long, kill it
        if (this.ticksLived >= this.ticksToKill) {
            simulation.kill(position);
        } else {
            // decide what neighbouring cell to interact with,
            ArrayList<Simulation.Cell> borderingCells =
                simulation.state().getBorderingCells(this.row, this.column);
            if (borderingCells.size() > 0) {
                int rand = (int)(Math.random() * borderingCells.size());
                Simulation.Cell destination = borderingCells.get(rand);
                // if something is not in this cell, we move to it
                if (destination.agent().isNone()) {
                    simulation.move(position, destination);
                    return;
                }
                // if an agent is in this cell, we can see how we might interact
                // with it
                Agent targetAgent = destination.agent().unwrap();
                // See if we can breed with the target
                if (targetAgent.getClass() == this.getClass() &&
                    Sex.canMate(this.sex, ((Animal)targetAgent).sex)) {
                    ArrayList<Simulation.Cell> emptyBorderingCells =
                        simulation.state().getEmptyBorderingCells(this.row,
                                                                  this.column);
                    // if there is space for the baby to be born
                    if (emptyBorderingCells.size() > 0) {
                        int randint = uk.ac.kcl.util.Math.randint(
                            0, emptyBorderingCells.size());
                        Simulation.Cell cell = emptyBorderingCells.get(randint);
                        // if the mating is successful, spawn a new baby
                        if (this.isAdult && this.reproductionSuccess.run()) {
                            simulation.spawnAgent(this.descriptor, cell.row(),
                                                  cell.column());
                            return;
                        }
                    }
                    // see if we can eat the target
                } else if (this.diet().contains(targetAgent.getClass())) {
                    if (this.isHungry()) {
                        simulation.kill(destination);
                        this.ticksSinceLastMeal = 0;
                    }
                }
            }
        }
    }
}