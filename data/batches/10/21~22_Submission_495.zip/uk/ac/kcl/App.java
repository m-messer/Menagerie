package uk.ac.kcl;

import java.awt.Color;
import java.util.ArrayList;
import java.util.WeakHashMap;
import uk.ac.kcl.simulation.Agent;
import uk.ac.kcl.simulation.BackgroundAgent;
import uk.ac.kcl.simulation.Simulation;
import uk.ac.kcl.simulation.SimulationView;
import uk.ac.kcl.toybox.Animal;
import uk.ac.kcl.toybox.Diet;
import uk.ac.kcl.toybox.Disease;
import uk.ac.kcl.toybox.Plant;
import uk.ac.kcl.toybox.Weather;
import uk.ac.kcl.util.*;

class Consts {
    public static int LENGTH_OF_DAY = 80;
}

class Fox extends Animal {
    public Fox() {
        super();
        this.ticksToKill = 800;
        this.ticksToStarve = 100;
        this.ticksUntilAdult = 150;
        this.reproductionSuccess = new Percentage(0.1);
    }

    public static Diet diet =
        new Diet(Pigeon.class, Rabbit.class, Squirrel.class, Seagull.class);

    @Override
    public Diet diet() {
        return Fox.diet;
    }

    @Override
    public boolean isSleeping(Simulation simulation) {
        return simulation.time() % Consts.LENGTH_OF_DAY < 30;
    }

    @Override
    public boolean isHungry() {
        return this.ticksSinceLastMeal > 20;
    }
}

class Seagull extends Animal {
    public Seagull() {
        super();
        this.ticksToKill = 600;
        this.ticksToStarve = 100;
        this.ticksUntilAdult = 200;
        this.reproductionSuccess = new Percentage(0.6);
    }

    public static Diet diet = new Diet(Pigeon.class, Rabbit.class);

    @Override
    public Diet diet() {
        return Seagull.diet;
    }

    @Override
    public boolean isHungry() {
        return this.ticksSinceLastMeal > 5;
    }

    @Override
    public boolean isSleeping(Simulation simulation) {
        long time = simulation.time() % Consts.LENGTH_OF_DAY;
        return time >= 70 && time < 90;
    }
}

class Rabbit extends Animal {
    public Rabbit() {
        super();
        this.ticksToKill = 200;
        this.ticksToStarve = 80;
        this.ticksUntilAdult = 100;
        this.reproductionSuccess = new Percentage(1);
    }

    public static Diet diet = new Diet(Grass.class);

    @Override
    public boolean isHungry() {
        return this.ticksSinceLastMeal > 5;
    }

    @Override
    public Diet diet() {
        return Rabbit.diet;
    }
}

class Pigeon extends Animal {
    public static Diet diet = new Diet(Nuts.class, Grass.class);

    @Override
    public Diet diet() {
        return Pigeon.diet;
    }

    @Override
    public boolean isHungry() {
        return this.ticksSinceLastMeal > 20;
    }

    public Pigeon() {
        super();
        this.ticksToKill = 400;
        this.ticksToStarve = 160;
        this.ticksUntilAdult = 200;
        this.reproductionSuccess = new Percentage(0.5);
    }
}

class Squirrel extends Animal {
    public static Diet diet = new Diet(Nuts.class);

    @Override
    public Diet diet() {
        return Squirrel.diet;
    }

    public Squirrel() {
        super();
        this.ticksToKill = 300;
        this.ticksToStarve = 80;
        this.ticksUntilAdult = 70;
        this.reproductionSuccess = new Percentage(1);
    }
}

class Grass extends Plant {
	Rain rainSystem;

    public Grass(Rain rainSystem) {
        super();
		this.rainSystem = rainSystem;
        this.ticksToKill = 60;
        this.ticksUntilBloomed = 10;
        this.spreadChance = new Percentage(0.8);
    }

	@Override
	public boolean canGrow() {
		return this.rainSystem.isActive();
	}
}

class Nuts extends Plant {
    public Nuts() {
        super();
        this.ticksToKill = 200;
        this.ticksUntilBloomed = 50;
        this.spreadChance = new Percentage(0.01);
    }
}

class PlantPlague extends Disease {
    @Override
    public String name() {
        return "plant plague";
    }

    public PlantPlague() {
        super();
        this.spawnsIn = new Diet(Grass.class);
        ;
        this.hosts = new Diet(Grass.class, Rabbit.class, Squirrel.class);
        this.kills = new Diet(Grass.class, Rabbit.class);

        this.chanceOfCuring = new Percentage(0.1);
        this.chanceOfSpreading = new Percentage(1);
        this.chanceOfSpawning = new Percentage(0.00001);

        this.ticksToKill = 4;
    }
}

class Rain extends Weather {
    public Rain() {
		this.backgroundColor = new Color(200, 200, 230);
		this.activateChance = new Percentage(0.02);
		this.deactivateChance = new Percentage(0.01);
	}
}

/**
 * Hello world!
 */
public class App {
    public App() throws Exception { App.main(null); }

    public static void main(String[] args) throws Exception {
        Rain rainSystem = new Rain();

        Simulation sim =
            new Simulation
                .Builder() {
                    {
                        spawners = new ArrayList<Agent.Descriptor>() {
                            {
                                add(new Fox.Descriptor
                                        .Builder() {
                                            {
                                                name = "fox";
                                                color = Color.ORANGE;
                                                spawnWeight = 0.5;
                                                spawnFunction = () -> {
                                                    return new Fox();
                                                };
                                            }
                                        }
                                        .build());
                                add(new Seagull.Descriptor
                                        .Builder() {
                                            {
                                                name = "seagull";
                                                color =
                                                    new Color(100, 100, 100);
                                                spawnWeight = 1;
                                                spawnFunction = () -> {
                                                    return new Pigeon();
                                                };
                                            }
                                        }
                                        .build());
                                add(new Rabbit.Descriptor
                                        .Builder() {
                                            {
                                                name = "rabbit";
                                                color = Color.BLUE;
                                                spawnWeight = 2;
                                                spawnFunction = () -> {
                                                    return new Rabbit();
                                                };
                                            }
                                        }
                                        .build());
                                add(new Pigeon.Descriptor
                                        .Builder() {
                                            {
                                                name = "pigeon";
                                                color = new Color(40, 40, 40);
                                                spawnWeight = 1;
                                                spawnFunction = () -> {
                                                    return new Pigeon();
                                                };
                                            }
                                        }
                                        .build());
                                add(new Squirrel.Descriptor
                                        .Builder() {
                                            {
                                                name = "squirrel";
                                                color = Color.PINK;
                                                spawnWeight = 2;
                                                spawnFunction = () -> {
                                                    return new Squirrel();
                                                };
                                            }
                                        }
                                        .build());
                                add(new Grass.Descriptor
                                        .Builder() {
                                            {
                                                name = "grass";
                                                color = Color.GREEN;
                                                spawnWeight = 4;
                                                spawnFunction = () -> {
                                                    return new Grass(
                                                        rainSystem);
                                                };
                                            }
                                        }
                                        .build());
                                add(new Nuts.Descriptor
                                        .Builder() {
                                            {
                                                name = "nuts";
                                                color = new Color(100, 70, 5);
                                                spawnWeight = 1;
                                                spawnFunction = () -> {
                                                    return new Nuts();
                                                };
                                            }
                                        }
                                        .build());
                            }
                        };
                        backgroundAgents = new ArrayList<BackgroundAgent>() {
                            {
                                add(new PlantPlague());
                                add(rainSystem);
                            }
                        };
                        dimensions = new Tuple<>(200, 100);
                        totalCoverage = new Percentage(0.9);
                    }
                }
                .build();
        SimulationView view =
            new SimulationView
                .Builder() {
                    {
                        simulation = sim;
                        title = "Predator Prey";
                        cellDimensions = new Tuple<Integer, Integer>(10, 10);
                    }
                }
                .build();

        for (int i = 0; i < 1000; ++i) {
            sim.update();
            view.update();
            Thread.sleep(50);
        }
    }
}
