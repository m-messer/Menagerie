package uk.ac.kcl.util;

/**
 * Represents a percentage chance
 */
public class Percentage {
	double chance;

	/**
	 * Creates a bounded chance
	 * @param chance the chance. If this is greater than 1.0,
	 * it is bounded at 1.0, if it is less than 0.0, we bound 
	 * this to 0.0
	 */
	public Percentage(double chance) {
		this.set(chance);
	}

	/**
	 * get the internal double for this <code>Percentage</code>
	 * @return a <code>double</code> with the same value as
	 * this <code>Percentage</code>
	 */
	public double get() {
		return this.chance;
	}

	/**
	 * Set the internal double for this <code>Percentage</code>
	 */
	public void set(double chance) {
		if (chance > 1.0) {
			this.chance = 1.0;
		} else if (chance < 0.0) {
			this.chance = 0.0;
		}
		this.chance = chance;
	} 

	/**
	 * Using <code>Math.random()</code>, runs this chance and 
	 * returns <code>true</code> this percentage of the time
	 * @return high if the run is success
	 */
	public boolean run() {
		return java.lang.Math.random() <= this.get();
	}
}
