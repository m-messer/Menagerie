package uk.ac.kcl.util;

/**
 * Explicit nullable type (replicates Rust's Option<T>)
 */
public class Option<T> {
    private T value;
    private boolean isNone = false;

	protected Option(T value) { this.value = value; }
	
	@Override
	public String toString() {
		if (isNone) {
			return "Option.none()";
		} 
		return "Option.some(" + value.toString() + ")";
	}

    /**
     * Construct a new `Option::Some(T)` from `value`
     * @param value The value of this Option
	 * @return a new `Option<T>` of the `Some` variant
     */
	public static <T> Option<T> some(T value) {
		return new Option<T>(value); 
	}

    /** Null equivalent */
    public static <T> Option<T> none() {
		Option<T> option = new Option<T>(null);
		option.isNone = true;
		return option;
	}

    /**
     * Returns the value contained in this object, or throws a
     * `CannotUnwrapException` if the variant is None
     * @return the value this Option contains
     */
    public T unwrap() {
        return this.expect(CannotUnwrapException.DEFAULT_MESSAGE);
    }

    /**
     * Equivalent to `Option.unwrap()`, but with a custom error message
     * @param message the custom error message to be displayed, if this
     * panics
     * @return the value this Option contains
     */
    public T expect(String message) {
        if (isNone) {
            throw new CannotUnwrapException(message);
        } else {
            return this.value;
        }
    }

	/**
	 * Determine whether or not this option is a None variant
	 * @return
	 */
	public boolean isNone() {
		return this.isNone;
	}

	public static class CannotUnwrapException extends RuntimeException {
		protected static String DEFAULT_MESSAGE =
			"called `Option.unwrap()` on a `None` value";
	
		protected CannotUnwrapException() { super(DEFAULT_MESSAGE); }
	
		protected CannotUnwrapException(String message) { super(message); }
	}
}
