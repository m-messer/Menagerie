package uk.ac.kcl.util;

/**
 * A pair of items, this seems to come in handy in all
 * sorts of scenarios. We're using it for readability 
 * and clean code mainly!
 */
public final class Tuple<A, B> {
    private A a;
    private B b;

    public Tuple(A a, B b) {
        this.a = a;
        this.b = b;
    }

    /** Setter for the first element of this tuple */
    public void setA(A a) { this.a = a; }

    /** Getter for the first element of this tuple */
    public A getA() { return this.a; }

    /** Analagous to getA() */
    public A x() { return this.getA(); }

    /** Setter for the second element of this tuple */
    public void setB(B b) { this.b = b; }

    /** Getter for the second element of this tuple */
    public B getB() { return this.b; }

    /** Analgous to getB() */
    public B y() { return this.getB(); }

    @Override
    public String toString() {
        return "Tuple(" + this.a + ", " + this.b + ")";
    }
}
