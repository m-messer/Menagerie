package uk.ac.kcl.util;

public class Math {
	/**
	 * Returns a random integer
	 * @param from the first (inclusive) number in the range
	 * @param to the last (not inclusive) number in the range
	 * @return a random integer in the specified range
	 */
	public static int randint(int from, int to) {
		return (int)(java.lang.Math.random() * (to - from));
	}
}
