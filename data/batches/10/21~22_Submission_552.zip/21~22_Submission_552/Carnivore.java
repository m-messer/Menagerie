import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A  model of a Carnivore.
 * Carnivores age, move, eat other animals, and die.
 * Carnivores can die of old age, overcrowding, disease or hunger
 * They can spread disease if they are infected
 * Carnivores can only mate with animals of the exact same type and opposite gender
 *
 * @version 2016.02.29 (2)
 */
public abstract class Carnivore extends Animal
{   
    /**
     * Create a Carnivore. A carnivore can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the carnivore will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Carnivore(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setFoodLevel(rand.nextInt(20));
    }

    /**
     * This is what the carnivore does most of the time: it hunts for
     * foos. In the process, it might breed, die (of hunger/old age/ disease)
     * @param field The field currently occupied.
     * @param newCarnivores A list to return newly born carnivores.
     */
    protected void act(List<Organism> newCarnivores, boolean isDay)
    {
        incrementAge();
        incrementHunger();
        incrementDiseaseSteps();
        
        if(isAlive()) {
            spreadDisease();
            giveBirth(newCarnivores);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood();

    /**
     * Check whether or not this carnivore is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCarnivores A list to return newly born carnivores.
     */
    abstract protected void giveBirth(List<Organism> newCarnivores);

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * A carnivore can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }
}
