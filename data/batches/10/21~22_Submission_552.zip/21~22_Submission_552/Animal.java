import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.awt.Color;

/**
 * Abstract class representing shared characteristics of animals.
 * Animal reprsents living creatures in the simulation that can breath, move and reproduce
 * Animals can eat, move and die.
 * Animals can die from hunger, old age or overcrowding.
 * Animals can only eat certain organisms in their diet which is specified in subclasses
 *
 * @version 01/03/2022
 */
public abstract class Animal extends Organism
{
    // Random number generator
    protected static final Random rand = Randomizer.getRandom();

    // The animals energy vaule if it is eaten by another animal
    private int foodValue;
    // The animals breeding age
    private int breedingAge;
    // The animals maximum litter size it can produce
    private int maxLitterSize;
    // The animals probability of breeding 
    private double breedingProbability;
    // The animals food level
    private int foodLevel;
    // The animals gender
    private boolean isMale;
    // Field for if the animal as disease
    private boolean hasDisease;
    // Steps taken whilst having disease
    private int diseaseSteps;

    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        hasDisease = false;
        diseaseSteps = 0;
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first food found is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood();

    /**
     * Return the animals food value
     * @return The foodValue fields value
     */
    protected int getFoodValue()
    {
        return foodValue;
    }

    /**
     * Sets the animals food value
     * @param The foodValue fields value
     */
    protected void setFoodValue(int value)
    {
        foodValue = value;
    }

    /**
     * Return the animal's breeding age.
     * @return The animal's breeding age.
     */
    protected int getBreedingAge()
    {
        return breedingAge;
    }

    /**
     * Sets the animals food value
     * @param The breadingAge fields value
     */
    protected void setBreedingAge(int age)
    {
        breedingAge = age;
    }

    /**
     * Return the animal's max litter size.
     * @return The animal's max litter size.
     */
    protected int getMaxLitterSize()
    {
        return maxLitterSize;
    }

    /**
     * Sets the animals max litter sixe
     * @param The maxLitterSize fields value
     */
    protected void setMaxLitterSize(int maxSize)
    {
        maxLitterSize = maxSize;
    }

    /**
     * Return the animal's breeding probabilty .
     * @return The animal's breeding probabilty.
     */
    protected double getBreedingProbability()
    {
        return breedingProbability;
    }

    /**
     * Sets the animals breeding probabilty
     * @param The probability breeding probabilty
     */
    protected void setBreedingProbability(double probability)
    {
        breedingProbability = probability;
    }

    /**
     * Return the animal's food level .
     * @return The animal's foodLevel.
     */
    protected int getfoodLevel()
    {
        return foodLevel;
    }

    /**
     * Sets the animals food level
     * @param The animals foodLevel
     */
    protected void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }

    /**
     * Make this animal more hungry. This could result in the animals's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animals's death.
     */
    protected void incrementHunger(int reduceBy)
    {
        foodLevel = foodLevel - reduceBy;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increase food level by the amount passed as a parameter
     */
    protected void increaseFoodLevel(int level)
    {
        foodLevel += level;
    }

    /**
     * Sets the animals gender
     * @param The animals gender
     */
    protected void setGender()
    {
        int r = new Random().nextInt(2);
        if (r == 0) {
            isMale = true;
        }
        else {
            isMale = false;
        }
    }

    /**
     * Gets the animals gender
     * @return The animals gender
     */
    protected boolean getGender() 
    {
        return isMale;
    }

    /**
     * Checks if the neighbouring cell has a different gender to it and can therefore breed
     */
    private boolean checkNeighbourGender(List<Animal> surroundingAnimals, boolean ownGender)
    {
        boolean differentGenderMatch = false;

        // for all surrounding animals of the same type, it checks that there is at least one with a differnt gender
        for(Iterator<Animal> it = surroundingAnimals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.getGender() != ownGender) {
                differentGenderMatch = true;
            }
        }

        return differentGenderMatch;
    }

    /**
     * Returns the boolean value of hasDisease
     * Indicates if the animal has disease or not
     */
    public boolean getDiseaseStatus()
    {
        return hasDisease;
    }

    /**
     * Sets hasDisease to true
     * sets colour to red to show disease
     */
    public void setDisease()
    {
        hasDisease = true;
        setColor(Color.RED);
    }

    /**
     * Sets hasDisease to false
     * resets colour to original to show it is no longer infected
     */
    public void resetDisease()
    {
        hasDisease = false;
        resetDiseaseSteps();
        resetColor();
    }

    /**
     * Infects the animal that is passed as a parameter with disease
     * Changes its colour to red to show it has been infected
     */
    protected void infect(Animal animal)
    {
        animal.setDisease();
        animal.setColor(Color.RED);
    }

    /**
     * Spreads disease to surrounding animals of the same exact type
     */
    protected void spreadDisease(){
        if(getDiseaseStatus()){
            Field field = getField();
            List<Location> full = field.getFullAdjacentLocations(getLocation());

            for(Iterator<Location> it = full.iterator(); it.hasNext(); ) {
                Location location = it.next();
                // gets the object at the location
                Object object = field.getObjectAt(location);

                if(object instanceof Animal){
                    Animal animal = (Animal) object;
                    //checks they are the same type of animals
                    String currentAnimal = getClass().getName();
                    String neighbour = object.getClass().getName();

                    if (currentAnimal.equals(neighbour)){ 
                        animal.setDisease();
                    }
                }
            }
        }
    }

    /**
     * Increments steps taken whilst the animal is infected.
     * Checks if it has reached a maximum and if so the animal dies
     * An infected animal can take a maximum of 10 steps whilst infected
     */
    protected void incrementDiseaseSteps()
    {
        if(getDiseaseStatus()){
            diseaseSteps++;
            if(diseaseSteps>10){
                setDead();
            }
        }
    }
    
    /**
     * Resets disease steps to 0.
     * When the animal is cured, reinfection is not influence by passed infections
     */
    private void resetDiseaseSteps()
    {
        diseaseSteps = 0;
    }
}