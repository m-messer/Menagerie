import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.awt.Color;

/**
 * Abstract class Organism 
 * Contains all methods and variables shared by all organisms in the simulation
 * Is the super class to Animal and Plant.
 * Organism represents all living matter in the simulation
 *
 * @version 01/03/2022
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism field.
    private Field field;
    // The organism position in the field.
    private Location location;
    // The organism age
    private int age;
    // The organism maximum age
    private int maxAge;
    // The organisms colour
    private Color color; 
    
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Abstract method for when the organism acts.
     * Takes the parameter of the time of day and the list of new organisms created
     */
    protected void act (List<Organism> newOrganism, boolean isDay) 
    {
        incrementAge();
    }
    
    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        if (age >= maxAge){
            setDead();
        }
        
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the organism's age .
     * @return The organism's age.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Sets the organisms age
     * @param The organisms age
     */
    protected void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * Return the organisms maximum age
     * @return The organisms maximum age.
     */
    protected int getMaxAge()
    {
        return maxAge;
    }
    
    /**
     * Sets the organisms maximum age
     * @param The maxAge fields value
     */
    protected void setMaxAge(int age)
    {
        maxAge = age;
    }
    
    /**
     * Increase the age. This could result in the organism's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Returns the colour of the organism
     */
    public Color getColor()
    {
        return color;
    }
    
    /**
     * Sets the colour to a new colour
     */
    protected void setColor(Color color1)
    {
        color = color1;
    }
    
    /**
     * Abstract method
     * Resets coulor back to original colour
     */
    protected abstract void resetColor();
}