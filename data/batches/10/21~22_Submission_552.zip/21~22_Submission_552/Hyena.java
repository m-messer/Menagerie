import java.util.List;
import java.util.Iterator;
import java.awt.Color;

/**
 * Class contating attributes and methods of Hyena.
 * Subclass of Carniove.
 * Hyena eat Wildebeest
 * 
 * During the day Hyena move, attempt to mate, eat, spread disease and can die
 * During the night Hyena do not move but can still die.
 *
 * @version 01/03/2022
 */
public class Hyena extends Carnivore
{
    /**
     * Constructor for objects of class Hyena
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setFoodLevel(25);
        setBreedingAge(15);
        setMaxLitterSize(2);
        setMaxAge(250);
        setBreedingProbability(0.2);
        setGender();
        resetColor();
        
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
        }
        else {
            setAge(0); 
        }
    }

    /**
     * Overrides method from Carnivore class
     * Check whether or not this hyena is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCarnivores A list to return newly born carnivores of type hyena.
     */
    protected void giveBirth(List<Organism> newCarnivores)
    {        
        // New hyena are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        //returns a list of surrounding free locations
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        //returns a list of surrounding full locations - not necessarily animals 
        List<Location> full = field.getFullAdjacentLocations(getLocation());
        // Current class name as string

        boolean canGiveBirth = false;
        for(Iterator<Location> it = full.iterator(); it.hasNext(); ) {
            Location location = it.next();
            // gets the object at the location
            Object object = field.getObjectAt(location);

            //checks they are the same type of animals and different genders in oder to give birth
            String currentAnimal = getClass().getName();
            String neighbour = object.getClass().getName();
            if (currentAnimal.equals(neighbour)){ 
                Hyena partner = (Hyena) object;
                if (partner.getGender() != getGender()){
                    canGiveBirth = true;
                }
            }
        }
        
        // gives birth once necessary checks are approved
        if(canGiveBirth){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Hyena young = new Hyena(false, field, loc);
                newCarnivores.add(young);
            }
        }
    }
    
    /**
     * Overrrides method in animal class
     * Look for food adjacent to the current location.
     * Only the first live wilderbeest is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wildebeest) {
                Wildebeest wildebeest = (Wildebeest) animal;
                if(wildebeest.isAlive()) { 
                    wildebeest.setDead();
                    increaseFoodLevel(wildebeest.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
    * Overrides the act method in order to change behaviour at night 
    */
    protected void act(List<Organism> newHerbivore, boolean isDay)
    {
        if(isDay){
            super.act(newHerbivore, isDay);
        }
        else{
            incrementAge();
        }
    }
    
    /**
     * Overrides method in organism to reset colour to original colour
     */
    protected void resetColor()
    {
        setColor(Color.BLUE);
    }
}
