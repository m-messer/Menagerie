import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of plants.
 * 
 * Plant represents organic matter that grows and dies
 * It can die or old age or being eaten.
 * Plants cannot move or eat.
 *
 * @version 01/03/2022
 */
public abstract class Plant extends Organism
{
    // Random number generator
    protected static final Random rand = Randomizer.getRandom();

    // The plants energy vaule if it is eaten by another animal
    private int foodValue;
    // The plants growing age
    private int growAge;
    // The plants probability of growing
    private double growRate;
    // The plants max growth size
    private int maxGrowthSize;

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Return the plants food value
     * @return The foodValue fields value
     */
    protected int getFoodValue()
    {
        return foodValue;
    }

    /**
     * Sets the plants food value
     * @param The foodValue fields value
     */
    protected void setFoodValue(int value)
    {
        foodValue = value;
    }

    /**
     * Return the plants growing age.
     * @return The plants growing age.
     */
    protected int getGrowthAge()
    {
        return growAge;
    }

    /**
     * Sets the plants growing age
     * @param The age fields value
     */
    protected void setGrowingAge(int age)
    {
        growAge = age;
    }

    /**
     * Return the plants growth rate .
     * @return The plants growth rate.
     */
    protected double getGrowthRate()
    {
        return growRate;
    }

    /**
     * Sets the plants growth rate
     * @param The rate plants growth rate
     */
    protected void setGrowthRate(double rate)
    {
        growRate = rate;
    }

    /**
     * Return the plant's growth size .
     * @return The plant's growth size
     */
    protected int getGrowthSize()
    {
        return maxGrowthSize;
    }

    /**
     * Sets the plants growth size
     * @param The plants growth size
     */
    protected void setGrowthSize(int size)
    {
        maxGrowthSize = size;
    }

    /**
     * Generate a number representing the number of growths,
     * if it can grow
     * @return The number of growths (may be zero).
     */
    protected int grow()
    {
        int growths = 0;
        if(canGrow() && rand.nextDouble() <= getGrowthRate()) {
            growths = rand.nextInt(getGrowthSize()) + 1;
        }
        return growths;
    }

    /**
     * A plant can grow if it has reached the growing age.
     * @return true if the plant can grow, false otherwise.
     */
    private boolean canGrow()
    {
        return getAge() >= getGrowthAge();
    }
}