
/**
 * Time class used to create and track time within the simulation.
 * Time of day has an impact on organisms behaviour
 * All animals sleep at night but plants continue to grow however at a slower rate
 * 
 * A complete time period consits of two sections: a day and night, 
 * Both of equal length
 *
 * @version 01/03/2022
 */
public class Time
{
    // Counts time which is incremented with every step. Tracks position in the day
    private int timeCounter;
    // Boolean value for if it day or night
    private boolean isDay;
    // Length of day in steps
    private int dayLength;
    
    /**
     * Constructor for objects of class Time
     */
    public Time(int length)
    {
        dayLength = length;
        timeCounter = 0;
        isDay = true; //simulation starts as day
    }

    /**
     * Method increments time counter by 1.
     * Checks if the incrementation changes if it day or night
     */
    public void incrementTimeCounter()
    {
        timeCounter++;
        if (dayLength == timeCounter){
            setToNight();
        }
        else if (timeCounter == (dayLength + dayLength)){
            setToDay(); 
        }
    }
    
    /**
     * Sets the time to Day. Resets time counter to show new day has started
     */
    private void setToDay()
    {
        isDay = true;
        timeCounter = 0;
    }
    
    /**
     * Sets time position to night 
     */
    private void setToNight()
    {
        isDay = false;
    }
    
    /**
     * Resets the simulations time clock.
     * Start of a day at timeCounter 0
     */
    public void resetTime()
    {
        isDay = true;
        timeCounter = 0;
    }
    
    /**
     * Accessor method for isDay
     */
    public boolean getIsDay()
    {
        return isDay;
    }
}
