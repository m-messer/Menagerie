import java.util.List;
import java.util.Iterator;
import java.awt.Color;

/**
 * Class contating attributes and methods of Wildebeest.
 * Subclass of Herbivore.
 * Wildebeest eat Plants (specifically grass)
 * 
 * During the day wildebeest move, attempt to mate, eat, spread disease and can die
 * During the night wildebeest do not move but can still die.
 *
 * @version 01/03/2022
 */
public class Wildebeest extends Herbivore
{
    /**
     * Constructor for objects of class Wilderbeest
     */
    public Wildebeest(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setBreedingAge(1);
        setMaxLitterSize(4);
        setFoodValue(20);
        setMaxAge(200);
        setBreedingProbability(0.4);
        setFoodLevel(100);
        setGender();
        resetColor();

        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
        }
        else {
            setAge(0); 
        }
    }

    /**
     * Overrides current method in Herbivore class
     * Check whether or not this wildebeest is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHerbivores A list to return newly born herbivore which are type wildebeest.
     */
    protected void giveBirth(List<Organism> newHerbivores)
    {
        // New wildebeest are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        //returns a list of surrounding free locations
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        //returns a list of surrounding full locations - not necessarily animals 
        List<Location> full = field.getFullAdjacentLocations(getLocation());
        // Current class name as string

        boolean canGiveBirth = false;
        for(Iterator<Location> it = full.iterator(); it.hasNext(); ) {
            Location location = it.next();
            // gets the object at the location
            Object object = field.getObjectAt(location);

            //checks they are the same type of animals and different genders in oder to give birth
            String currentAnimal = getClass().getName();
            String neighbour = object.getClass().getName();
            if (currentAnimal.equals(neighbour)){ 
                Wildebeest partner = (Wildebeest) object;
                if (partner.getGender() != getGender()){
                    canGiveBirth = true;
                }
            }
        }

        // gives birth once necessary checks are approved
        if(canGiveBirth){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Wildebeest young = new Wildebeest(false, field, loc);
                newHerbivores.add(young);
            }
        }
    }

    /**
     * Overrides the act method in order to change behaviour at night 
     */
    protected void act(List<Organism> newHerbivore, boolean isDay)
    {
        if(isDay){
            super.act(newHerbivore, isDay);
        }
        else{
            incrementAge();
        }
    }

    /**
     * Overrides method in organism to reset colour to original colour
     */
    protected void resetColor()
    {
        setColor(Color.MAGENTA);
    }
}

