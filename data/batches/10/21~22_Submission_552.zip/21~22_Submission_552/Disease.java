import java.util.List;
import java.util.Random;
import java.awt.Color;
import java.util.Iterator;

/**
 * Disease class used to create and track disease within the simulation.
 * Only animals can be infectred with a disease
 * Disease infection is random and is triggered by a button click.
 * Class also contains cure which removes all active disease from the simulation
 *
 * @version 01/03/2022
 */
public class Disease
{
    private boolean outbreak;
    private boolean disease;
    private boolean cure;

    //Random class used for random number generator
    Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Disease
     */
    public Disease()
    {
        // simulation starts with no active disease
        outbreak = false;
        disease = false;
        cure = false;
    }

    /**
     * Accessor method for outbreak variable
     */
    public boolean isOutbreak()
    {
        return outbreak;
    }

    /**
     * Accessor method for disease variable
     */
    public boolean isDisease()
    {
        return disease;
    }

    /**
     * Accessor method for cure variable
     */
    public boolean isCure()
    {
        return cure;
    }

    /**
     * Setter method for outbreak to show there needs to be an outbreak
     */
    public void setOutbreakTrue()
    {
        outbreak = true;
    }

    /**
     * Setter method for outbreak to show that outbreak has been started
     * Used when there does not need to be another 'start' of outbreak
     */
    public void setOutbreakFalse()
    {
        outbreak = false;
    }

    /**
     * Setter method for cure to show that cure has been started
     */
    public void setCureTrue()
    {
        cure = true;
    }

    /**
     * Method starts the disease outbreak in the population
     * Randomly selects an animal from all alive orgainsm and infects it
     * @param List<Organism> organisms All living organisms 
     * @return List<Organism> organisms Updated version of all living organisms
     */
    public List<Organism> createOutbreak(List<Organism> organisms)
    {
        disease = true; // from this point there is currently disease in the simulation

        int size = organisms.size();
        int index = 0;
        boolean animalFound = false;
        Organism selected = null;

        while(!animalFound){
            index = rand.nextInt(size);
            selected = organisms.get(index);
            if(selected instanceof Animal){
                animalFound = true;
            }
        }

        Animal selected2 = (Animal) selected;
        selected2.setDisease();

        organisms.set(index, selected2);

        selected.setColor(Color.RED);

        return organisms;
    }

    /**
     * Method that inplements the cure.
     * All the infected animals are uninfected and returend to their original colour
     * @param List<Organism> organisms All living organisms 
     * @return List<Organism> organisms Updated version of all living organisms
     */
    public List<Organism> createCure(List<Organism> organisms)
    {
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            if(organism instanceof Animal) {
                Animal animal = (Animal) organism;
                if(animal.getDiseaseStatus()){ //if the animal has disease
                    animal.resetDisease();
                }
            }
        }

        cure = false;
        disease = false;
        return organisms;
    }
}
