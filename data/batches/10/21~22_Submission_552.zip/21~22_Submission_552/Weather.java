import java.util.Iterator;
import java.util.List;

/**
 * Weather class used to create and track weather events within the simulation.
 * Weather impacts the organisms in the simulation
 * Weather events display the impact instantly of the completed weather event
 *
 * @version 01/03/2022
 */

public class Weather
{
    private boolean storm;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
       storm = false; 
    }

    /**
     * Method creates the effect of a storm.
     * All plants are killed
     * @param List<Organism> organisms. All living organisms in the simulation
     * @return List<Organism> organisms. Updated list of living organisims.
     */
    public List<Organism> storm(List<Organism> organisms)
    {      
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            if(organism  instanceof Grass){
                organism.setDead();
                it.remove();
            }
        }
       
        return organisms;
    }
    
    /**
     * sets the storm value to true - there has been a storm
     */
    public void setStormTrue()
    {
        storm = true;
    }
    
    /**
     * sets the storm value to fasle - there is not a storm or the storm has finsihed
     */
    public void setStormFalse()
    {
        storm = false;
    }
    
    /**
     * Accesor method for if there is a storm
     */
    public boolean isStorm()
    {
        return storm;
    }
}
