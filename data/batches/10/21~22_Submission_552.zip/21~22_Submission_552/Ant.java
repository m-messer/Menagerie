import java.util.List;
import java.util.Iterator;
import java.awt.Color;

/**
 * Class contating attributes and methods of Ant.
 * Subclass of Herbivore.
 * Ant eat Plants (specifically grass)
 * 
 * During the day Ant move, attempt to mate, eat, spread disease and can die
 * During the night their behaviour is the same as the day.
 *
 * @version 01/03/2022
 */
public class Ant extends Herbivore
{
    /**
     * Constructor for objects of class Ant
     */
    public Ant(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setBreedingAge(10);
        setMaxLitterSize(2);
        setFoodValue(3);
        setMaxAge(75);
        setBreedingProbability(0.1);
        setFoodLevel(50);
        setGender();
        resetColor();
        
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
        }
        else {
            setAge(0); 
        }
    }

    /**
     * Overrides current mehtod in Herbivore class
     * Check whether or not this ant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHerbivores A list to return newly born herbivore wich are type ant.
     */
    protected void giveBirth(List<Organism> newHerbivores)
    {
        // New Ant are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        //returns a list of surrounding free locations
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        //returns a list of surrounding full locations - not necessarily animals 
        List<Location> full = field.getFullAdjacentLocations(getLocation());
        // Current class name as string

        boolean canGiveBirth = false;
        for(Iterator<Location> it = full.iterator(); it.hasNext(); ) {
            Location location = it.next();
            // gets the object at the location
            Object object = field.getObjectAt(location);

            //checks they are the same type of animals and different genders in oder to give birth
            String currentAnimal = getClass().getName();
            String neighbour = object.getClass().getName();
            if (currentAnimal.equals(neighbour)){ 
                Ant partner = (Ant) object;
                if (partner.getGender() != getGender()){
                    canGiveBirth = true;
                }
            }
        }
        
        // gives birth once necessary checks are approved
        if(canGiveBirth){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Ant young = new Ant(false, field, loc);
                newHerbivores.add(young);
            }
        }
    }
    
    /**
     * Overrides method in organism to reset colour to original colour
     */
    protected void resetColor()
    {
        setColor(Color.PINK);
    }
}
