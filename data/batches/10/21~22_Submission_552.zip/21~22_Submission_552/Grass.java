import java.util.List;
import java.util.Random;
import java.awt.Color;
/**
 * Class containing attributes and methods of Grass.
 * Grass is a subclass of plant
 * Grass grows randomly in empty fields in the simulation
 * Grass is eaten by herbivores
 *
 * @version 01/03/2022
 */
public class Grass extends Plant
{
    /**
     * Constructor for objects of class Grass
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
        setAge(0);
        setGrowingAge(3);
        setFoodValue(25);
        setMaxAge(10);
        setGrowthRate(0.1);
        setGrowthSize(3);
        resetColor();
    }

    /**
     * Overrides method in superclass Organism
     * This is what grass does - they grow during the day, 
     * they die if they are to old 
     */
    protected void act(List<Organism> newPlants, boolean isDay)
    {
        incrementAge();
        if(isAlive()) {
            growPlant(newPlants);
        }
        else if (getAge() > getMaxAge()){
            setDead();
        }
    }
    
    /**
     * Checks if the space next to it is free and grows into that space
     */
    private void growPlant(List<Organism> newPlants)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int growths = grow();
        for(int b = 0; b < growths && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass sapling = new Grass(field, loc);
            newPlants.add(sapling);
        }
    }

    /**
     * Overrides method in organism to reset colour to original colour
     */
    protected void resetColor()
    {
        setColor(Color.GREEN);
    }
}
