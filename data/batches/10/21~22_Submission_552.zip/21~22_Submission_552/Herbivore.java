import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A model of a Herbivore.
 * Herbivores age, move, breed, and die.
 * Herbivores eat Plants (grass specifically)
 * Herbivores can die because of hunger, overcrowding, disease or old age
 * Herbivores can only mate with animals of the exact same type and opposite gender
 * They can spread disease if they are infected
 *
 * @version 01/03/2022
 */
public abstract class Herbivore extends Animal
{
    /**
     * Create a new herbivore. A herbivore may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the herbivore will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Herbivore(boolean randomAge, Field field, Location location)
    {
        super(field, location);
    }

    /**
     * This is what the herbivore does at day time - it runs 
     * around. Sometimes it will breed or die of old age or eat.
     * @param newHerbivore A list to return newly born herbivore.
     */
    protected void act(List<Organism> newHerbivore, boolean isDay)
    {
        incrementAge();
        incrementHunger();
        incrementDiseaseSteps();

        if(isAlive()) {
            spreadDisease();
            giveBirth(newHerbivore);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this herbivore is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHerbivores A list to return newly born herbivore.
     */
    abstract protected void giveBirth(List<Organism> newHerbivores);

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * A herbivore can breed if it has reached the breeding age.
     * @return true if the herbivore can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }
    
    /**
     * Overrides the find food method in the animal class
     * Looks for plants near herbivore and eats it
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    increaseFoodLevel(grass.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
}