import java.util.List;
import java.util.Iterator;
import java.awt.Color;

/**
 * Class contating attributes and methods of Termite.
 * Subclass of Herbivore.
 * Termite eat Plants (specifically grass)
 * 
 * During the day Termite move, attempt to mate, eat, spread disease and can die
 * During the night their behaviour is the same as the day.
 *
 * @version 01/03/2022
 */
public class Termite extends Herbivore
{
    /**
     * Constructor for objects of class Termite
     */
    public Termite(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setBreedingAge(10);
        setMaxLitterSize(2);
        setFoodValue(5);
        setMaxAge(75);
        setBreedingProbability(0.1);
        setFoodLevel(50);
        setGender();
        resetColor();
        
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
        }
        else {
            setAge(0); 
        }
    }

    /**
     * Overrides method from Herbivore class
     * Check whether or not this termite is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHerbivores A list to return newly born herbivore of type termite.
     */
    protected void giveBirth(List<Organism> newHerbivores)
    {
        // New termite are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        //returns a list of surrounding free locations
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        //returns a list of surrounding full locations - not necessarily animals 
        List<Location> full = field.getFullAdjacentLocations(getLocation());
        // Current class name as string

        boolean canGiveBirth = false;
        for(Iterator<Location> it = full.iterator(); it.hasNext(); ) {
            Location location = it.next();
            // gets the object at the location
            Object object = field.getObjectAt(location);

            //checks they are the same type of animals and different genders in oder to give birth
            String currentAnimal = getClass().getName();
            String neighbour = object.getClass().getName();
            if (currentAnimal.equals(neighbour)){ 
                Termite partner = (Termite) object;
                if (partner.getGender() != getGender()){
                    canGiveBirth = true;
                }
            }
        }
        
        // gives birth once necessary checks are approved
        if(canGiveBirth){
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Termite young = new Termite(false, field, loc);
                newHerbivores.add(young);
            }
        }
    }
    
    /**
     * Overrides method in organism to reset colour to original colour
     */
    protected void resetColor()
    {
        setColor(Color.ORANGE);
    }
}
