import java.util.List;
import java.util.stream.*;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.20
 */
public abstract class Animal extends Actor
{
    // Default probability of infection when an animal is created
    private static final int chanceOfInfection = 1;
    protected double hungerLevel;
    protected boolean isMale;
    // Represents if the animal is nocturnal (sleeps during the day as apposed to the night)
    protected boolean isNocturnal;
    protected boolean isInfected;
    // List of classes that this animal can eat
    protected ArrayList<Class<?>> foodList;

    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param environment The environment the animal is in
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        foodList = new ArrayList<Class<?>>();
        isInfected = rand.nextInt(100) < chanceOfInfection;
        if(randomAge){
            setAge(rand.nextInt(getMaxAge()));
            setHungerLevel(rand.nextInt(getFoodValue()));
        }else {
            setAge(0);
            setHungerLevel(getFoodValue());
        }
        generateSex();
    }

    /**
     * This method transfers the infection to the animal if it is already not infected.
     * Takes in a parameter to increase the chance of infection.
     * @param additonalChance Represents a number (int) to add to the predefined chanceOfInfection
     */
    public void transferInfection(int additonalChance)
    {
        if(!isInfected){ 
            isInfected = rand.nextInt(100) < (chanceOfInfection + additonalChance);
        }
    }

    /**
     * Method that generates the sex of an animal, 50/50 chance of being male or female
     */
    public void generateSex()
    {
        isMale = (rand.nextDouble()>= 0.5) ? true : false;
    }

    /**
     * Look for actors (plants or animals) it can eat that are adjacent to the current location.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            if(field.canActorBePlaced(this.getClass(), where)){ // Check if the animal can move towards the food as it can be in an inaccessible terrain
                Object object = field.getObjectAt(where);
                if(object != null && canEat(object)){
                    Actor food = (Actor) object;
                    Location loc = eat(food, where); 
                    if(food instanceof Animal){ // Because only animals can have the infection
                        Animal eatenFood = (Animal) food;
                        if(!isInfected && eatenFood.isInfected){
                            transferInfection(5);
                        }
                    }
                    return loc; // Return location of food eaten to move towards it
                }
            }
        }
        return null;
    }

    /**
     * Method that checks if the actor can eat the object/actor specified.
     * @param food Object representing the actor/object to eat
     * @return boolean true of the actor can eat the object, false otherwise
     */
    protected boolean canEat(Object food)
    {
        // Iterates through the list of classes (foodList) which represents the food the animal can eat
        for(Class<?> foodClass : foodList){ 
            if(food.getClass().equals(foodClass)){
                return true;
            }
        }
        return false;
    }

    /**
     * Method that makes the current animal object eat the food specified at the specified
     * location.
     * @param food Actor representing the food to be eaten by the animal
     * @param where Location representing the location of the food to be eaten by the animal
     */
    protected Location eat(Actor food, Location where){
        if(food.isEdible()){
            setHungerLevel(hungerLevel + food.getFoodValue());
            food.setInedible();
            return where;
        }
        return null;
    }

    /**
     * Makes the current animal 'act'. Inheritance hierarchy makes it so this method applies to all
     * animals. acting includes moving to nearby locations, eating and breeding.
     * This method is called each tick in the simulator on all animals.
     * @param newAnimals A list to return newly born animals.
     */
    public void act(List<Animal> newAnimal)
    {
        incrementAge();
        if(field.getEnvironment().getClimate().getTemperature() < 10){
            incrementHunger(0.5);
            transferInfection(1); // If its cold, an animal can contract the infection
        }
        if(isAsleep()){
            incrementHunger(0.01); // Special condition for when animal is asleep
        }else{
            incrementHunger();
            if(isAlive()){
                if(isInfected && rand.nextInt(100) < 2){
                    setDead();
                }else{
                    giveBirth(newAnimal);
                    // Move towards a source of food if found.
                    Location newLocation = findFood();
                    if(newLocation == null){
                        // No food found - try to move to a free location.
                        // Loop used to find a free location in a terrain accessible by the animal
                        for(Location loc : getField().getFreeAdjacentLocations(getLocation())){
                            if(getField().canActorBePlaced(this.getClass(), loc)){
                                newLocation = loc;
                                break;
                            }
                        }
                    }
                    // See if it was possible to move.
                    // If the location is a plant, dont move towards it. Plants cant be 'stepped' on.
                    if(newLocation != null && !(getField().getObjectAt(newLocation) instanceof Plant)){
                        setLocation(newLocation);
                    }else{
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()){
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return boolean true if the animal has reached its breeding age, otherwise false
     */
    protected boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }
    
    /**
     * Method that makes 2 animals of the same species of different genders mate and give birth
     * to a new animal of the same species. The animals must be in adjacent cells.
     * @param newAnimals A list of animals to add new born animals to
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        // Get the field this animal is in
        Field field = getField();
        // Get all the surrounding locations on the field around the animal
        List<Location> surroundingCells = field.adjacentLocations(getLocation());
        /*
        This list is generated using a stream
        All the surrounding locations are mapped to the object in that location
        All the objects which are null or of a different class of animal are removed
        The animals left in the stream are cast to the same class of animal as this animal
        Animals of the same sex and those which are too young to breed are removed from the stream
         */
        List<Animal> surroundingAnimals = surroundingCells.stream()
            .map(cell -> field.getObjectAt(cell))
            .filter(cellObj -> cellObj != null && this.getClass().equals(cellObj.getClass()))
            .map(animal -> this.getClass().cast(animal))
            .filter(animal -> animal.getSex() != this.getSex() && animal.canBreed())
            .collect(Collectors.toList());
        /*
        If the surroundingAnimals is not empty it means there is a surrounding animal 
        of the opposite sex and same class which this animal can breed with.
         */
        if(!surroundingAnimals.isEmpty()){
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            for(Location loc : free){
                if(getField().canActorBePlaced(this.getClass(), loc)){ // Checks if the location to give birth in is in an accessible terrain
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        // Create a baby based on dynamic type of animal, due to effective use of inheritance
                        Animal young = getChild(false, field, loc);
                        Animal mate = surroundingAnimals.get(0); // The other animal the current animal mated with
                        // If either this animal or its mate are infected,
                        // There is a chance the infection is spread to the mate and child
                        if(isInfected || mate.isInfected){ // Make child infected if either parent is infected
                            young.transferInfection(10);
                            mate.transferInfection(8);
                            transferInfection(8);
                        }
                        newAnimals.add(young);
                    }
                    break;
                }
            }
        }
    }
    
    /**
     * Set the animal to be inedible, which means kill the animal.
     */
    protected void setInedible(){
        setDead();
    }

    /**
     * Sets the hunger level of the animal to the parameter value
     * @param hungerLevel int representing the number to set the animal's hungerLevel to
     */
    public void setHungerLevel(double hungerLevel)
    {
        this.hungerLevel = hungerLevel;
    }
    
    /**
     * Make this animal more hungry by a specified amount. This could result in the animals's death.
     * @param hungerAmount double representing amount of 'hunger' to remove from hungerLevel
     */
    protected void incrementHunger(double hungerAmount)
    {
        double hungerLevel = getHungerLevel();
        hungerLevel = hungerLevel - hungerAmount;
        setHungerLevel(hungerLevel);
        if(hungerLevel <= 0){
            setDead();
        }
    }

    /**
     * Make this animal more hungry by 1 unit. This could result in the animals's death.
     */
    protected void incrementHunger()
    {
        incrementHunger(1);
    }
    
    // Getter methods
    /**
     * @return hungerLevel int representing the hunger level of the animal
     */
    public double getHungerLevel()
    {
        return hungerLevel;
    }
    
    /**
     * Returns if the animal is infected or not
     * @return boolean true if infected, false otherwise
     */
    public boolean getIsInfected()
    {
        return isInfected;
    }

    /**
     * Returns if the animal is asleep or awake
     * @return boolean true if asleep, false if awake
     */
    protected boolean isAsleep()
    {
        // Being asleep depends on whether it is day or night, and whether the animal is nocturnal.
        return isNocturnal == field.getEnvironment().getIsDay();
    }
    
    /**
     * @return isMale boolean representing the hunger level of the animal
     */
    public boolean getSex()
    {
        return isMale;
    }

    /**
     * @return age int representing the age of the animal
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * @return boolean true if the animal is edible, otherwise false
     */
    protected boolean isEdible(){
        return isAlive();
    }

    //Abstract methods
    /**
     * Abstract method to return a new instance of an animal based on dynamic type
     */
    abstract Animal getChild(boolean randomAge, Field field, Location location);
    
    /**
     * Abstract method to return the animal's breeding probability
     */
    abstract double getBreedingProbability();
    
    /**
     * Abstract method to return the animal's breeding age
     */
    abstract int getBreedingAge();

    /**
     * Abstract method to return the animal's max age
     */
    abstract int getMaxAge();

    /**
     * Abstract method to return the animal's max litter size (babies it can produce at once)
     */
    abstract int getMaxLitterSize();
}