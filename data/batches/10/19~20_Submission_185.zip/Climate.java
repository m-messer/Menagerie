/**
 * Climate which has a name, temperature and multiple weather attributes
 *
 * @version 2020.02.20
 */
public class Climate
{
    private String name;
    private boolean isSunny;
    private boolean isRaining;
    private boolean isCloudy;
    // Temperature in degrees Celcius
    private int temperature;
    /**
     * Constructs a climate
     * @param name  The name of the climate
     * @param isSunny   Whether this climate is sunny or not
     * @param isRaining Whether this climate is rainy or not
     * @param isCloudy  Whether this climate is cloudy or not
     * @param temperature   The temperature of this climate
     */
    public Climate(String name, boolean isSunny, boolean isRaining, boolean isCloudy, int temperature)
    {
        this.name = name;
        this.isSunny = isSunny;
        this.isRaining = isRaining;
        this.isCloudy = isCloudy;
        this.temperature = temperature;
    }

    /**
     * Constructs a climate
     * @param name  The name of the climate
     * @param isSunny   Whether this climate is sunny or not
     * @param isRaining Whether this climate is rainy or not
     * @param isCloudy  Whether this climate is cloudy or not
     */
    public Climate(String name, boolean isSunny, boolean isRaining, boolean isCloudy)
    {
        this.name = name;
        this.isSunny = isSunny;
        this.isRaining = isRaining;
        this.isCloudy = isCloudy;
        temperature = 15;
    }

    /**
     * Returns whether or not it is sunny
     * @return isSunny  True if sunny, otherwise false
     */
    public boolean getIsSunny()
    {
        return isSunny;
    }

    /**
     * Returns whether or not it is raining
     * @return isRaining  True if raining, otherwise false
     */
    public boolean getIsRaining()
    {
        return isRaining;
    }

    /**
     * Returns whether or not it is cloudy
     * @return isCloudy  True if cloudy, otherwise false
     */
    public boolean getIsCloudy()
    {
        return isCloudy;
    }

    /**
     * Returns the current temperature
     * @return temperature  The current temperature in degrees celcius
     */
    public int getTemperature()
    {
        return temperature;
    }

    /**
     * Returns the name of the climate
     * @return name The name of this climate
     */
    public String getName()
    {
        return name;
    }
}
