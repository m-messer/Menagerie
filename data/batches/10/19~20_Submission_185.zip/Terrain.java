import java.util.ArrayList;

/**
 * This class is the 'Terrain' class, it is used to represent different terrains (examples include: high lands, deserts, forests, etc.)
 * Different terrains can allow different actors (including animal and plants) to inhabit them.
 * Each terrain has an actorList which is an ArrayList which contains all the actor classes it allows.
 * Actors can only spawn and move into terrains which include their actor classes in the actorList.
 * For example, a terrain called forest can be created where only carrots (plant) and foxes (animal) can be placed inside of them.
 *
 * @version 2020.02.20
 */
public class Terrain
{
    private String name;
    private ArrayList<Class<?>> actorList; // ArrayList of actors that the terrain will allow access to
    private Location topLeft, bottomRight; // Location objects representing the co-ordinates of the terrain in a square-shape

    /**
     * Constructor for the terrain object.
     * @param name The String object representing the terrain name
     * @param topLeft The Location object representing the co-ordinate of the top left cell of the terrain box
     * @param bottomRight The Location object representing the co-ordinate of the bottom right cell of the terrain box
     */
    public Terrain(String name, Location topLeft, Location bottomRight)
    {
        this.name = name;
        this.topLeft = topLeft;
        this.bottomRight = bottomRight;
        actorList = new ArrayList<>();
    }

    /**
     * Add given actor classes to actorList.
     * @param actorClass Takes in a variable number of classes to add to actorList
     */
    public void addActorsToTerrain(Class<?>...actorClass)
    {
        for(Class<?> actor : actorClass){
            actorList.add(actor);
        }
    }
    
    // Getter methods
    /**
     * Return the actorList
     * @return actorList The ArrayList of actor classes that the terrain will allow to inhabit
     */
    public ArrayList<Class<?>> getActorList()
    {
        return actorList;
    }
    
    /**
     * Return name of terrain
     * @return name String representing name of terrain
     */
    public String getName()
    {
        return name;
    }

    /**
     * Return the left-most x-cordrinate of the terrain 
     * @return x1Axis left-most x-cordrinate of terrain
     */
    public int getX1Axis()
    {
        return topLeft.getCol();
    }

    /**
     * Return the right-most x-cordrinate of the terrain 
     * @return x2Axis right-most x-cordrinate of terrain
     */
    public int getX2Axis()
    {
        return bottomRight.getCol();
    }

    /**
     * Return the top-most y-cordrinate of the terrain 
     * @return y1Axis top-most y-cordrinate of terrain
     */
    public int getY1Axis()
    {
        return topLeft.getRow();
    }

    /**
     * Return the bottom-most y-cordrinate of the terrain 
     * @return y2Axis left-most y-cordrinate of terrain
     */
    public int getY2Axis()
    {
        return bottomRight.getRow();
    }
}