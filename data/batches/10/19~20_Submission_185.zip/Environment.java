import java.util.ArrayList;
import java.util.Random;

/**
 * An environment which tracks and controls the time, whether it's day and the climate
 *
 * @version 2020.02.20
 */
public class Environment
{
    // The time is is measured start of the environment and is related to the steps
    private int time;
    private boolean isDay;
    // The current climate of the environment
    private Climate climate;
    // List of possible climates in this environment
    private ArrayList<Climate> climateList = new ArrayList<>();
    /**
     * Constructs an environment
     */
    public Environment()
    {
        generateClimates();
        // Set the current climate to a random climate
        climate = nextClimate();
        isDay = getDayOrNight();
    }
    
    /**
     * Method to declare and initalise different climates
     */
    private void generateClimates()
    {
        Climate rainy = new Climate("Rainy", false, true, true, 10);
        Climate sunny = new Climate("Sunny", true, false, false, 20);
        Climate cloudy = new Climate("Cloudy", false, false, true, 15);
        Climate windy = new Climate("Windy", false, false, true, 7);
        addClimate(rainy, sunny, cloudy, windy);
    }
    
    /**
     * Adds all Climate objects passed as a parameter (varargs) to the list of possible climates
     */
    public void addClimate(Climate...climates)
    {
        for(Climate climate : climates){
            climateList.add(climate);
        }
    }
    
    /**
     * Returns a random climate from the list of possible climates
     * @return A random climate from climateList
     */
    public Climate nextClimate()
    {
        Random rand = new Random();
        return climateList.get(rand.nextInt(climateList.size()));
    }
    
    /**
     * Generates and returns the current time
     * How time changes can be modified. Currently time just increments
     * @return The new time
     */
    private int generateTime()
    {
        return time + 1;
    }
    
    /**
     * Returns the current time
     * @return time The current time
     */
    public int getTime()
    {
        return time;
    }
    
    /**
     * Sets the time to the given time
     * @param newTime   An integer value which the current time will be changed to
     */
    public void setTime(int newTime)
    {
        time = newTime;
    }
    
    /**
     * A set of operations that occur when the time changes
     */
    public void updateTime()
    {
        // Update the time
        setTime(generateTime());
        // Update isDay
        isDay = getDayOrNight();
        // Update the climate
        updateClimate();
    }
    
    /**
     * Updates the climate based on some probability
     */
    public void updateClimate()
    {
        Random rand = new Random();
        // 2% chance that the climate changes
        if(rand.nextInt(100) < 2){
            climate = nextClimate();
        }
    }
    
    /**
     * Uses modular arithmatic to decide whether it is day or night
     * Days are split up into units called tick
     * @return Boolean where true represents it is day and false represents it is night
     */
    public boolean getDayOrNight()
    {
        int tick = 100;
        return time%tick >= tick/2 ? true : false;
    }
    
    /**
     * Returns the isDay field
     * @return isDay Which represents whether it is day or night
     */
    public boolean getIsDay()
    {
        return isDay;
    }
    
    /**
     * Returns the name of the current climate
     * @return The name of the current climate
     */
    public String getWeatherStats()
    {
        return climate.getName();
    }
    
    /**
     * Returns the current climate
     * @return climate  The current climate
     */
    public Climate getClimate()
    {
        return climate;
    }
    
    /**
     * Returns whether it is day or night as a string
     * Similar to getDayorNight() but returns a string instead of boolean
     * @return Day or Night as a string
     */
    public String getTimeStats()
    {
        return isDay ? "Day" : "Night";
    }
}
