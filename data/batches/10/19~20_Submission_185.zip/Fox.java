/**
 * A simple model of a fox.
 * They can age, move, breed, die and can get sick.
 *
 * @version 2020.02.20
 */
public class Fox extends Animal
{
    // Characteristics shared by all foxes (class variables):
    // The age at which this animal can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which this animal can live. 
    private static final int MAX_AGE = 200;
    // The likelihood of this animal breeding.
    private static final double BREEDING_PROBABILITY = 0.375;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // This is how much food value it provides when eaten
    private static final int FOOD_VALUE = 9;
    
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setHungerLevel(12); // Set initial hunger level when created
        isNocturnal = true;
        foodList.add(Rabbit.class);
        foodList.add(Nut.class);
        foodList.add(Deer.class);
    }

    // Getter methods
    /**
     * @return int breeding age of the animal
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return int max age of the animal
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return double breeding probability of the animal
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return int max litter size of the animal
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return int food value of the animal (how much less hungry will an animal be if it eats this animal)
     */
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * @return Fox returns a new instance of this animal
     */
    public Animal getChild(boolean randomAge, Field field, Location location) 
    {
        return new Fox(randomAge, field, location);
    }
}