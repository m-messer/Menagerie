/**
 * A simple model of a rabbit.
 * They can age, move, breed, die and can get sick.
 *
 * @version 2020.02.20
 */
public class Rabbit extends Animal
{
    // Characteristics shared by all rabbits (class variables):
    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 900;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // This is how much food value it provides when eaten
    private static final int FOOD_VALUE = 10;

    /**
     * Create a new rabbit. A rabbit can be created as a new born (age zero
     * and not hungry) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setHungerLevel(50); // Set initial hunger level when created
        isNocturnal = false;
        foodList.add(Carrot.class);
        foodList.add(Nut.class);
    }

    // Getter methods
    /**
     * @return int breeding age of the animal
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return int max age of the animal
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return double breeding probability of the animal
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return int max litter size of the animal
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return int food value of the animal (how much less hungry will an animal be if it eats this animal)
     */
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * @return Rabbit returns a new instance of this animal
     */
    public Animal getChild(boolean randomAge, Field field, Location location) 
    {
        return new Rabbit(randomAge, field, location);
    }
}