/**
 * A class representing nuts and providing functionality to iteract with them.
 *
 * @version 2020.02.20
 */
public class Nut extends Plant
{
    // The age to which a Nut can live.
    private static final int MAX_AGE = 10;
    // How much this nut satiates whatever eats it
    private static final int FOOD_VALUE = 3;
    // Ages at which the nut can be eaten
    private static final int EDIBLE_AGE = 3;

    /**
     * Constructs a nut
     * @param randomAge if true then the age will be random, otherwise the age will be zero
     * @param field the field this nut will be on
     * @param location  the location on the field that this nut will be placed
     */
    public Nut(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        waterLevel = sunLevel = 50;
    }

    /**
     * Returns the max age this can live to
     * @return  MAX_AGE Returns the max age
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the edible age at which this can be eaten
     * @return  EDIBLE_AGE Returns the edible age
     */
    public int getEdibleAge()
    {
        return EDIBLE_AGE;
    }

    /**
     * Returns the food value from eating this plant
     * @return FOOD_VALUE   The value of eating this plant
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
}
