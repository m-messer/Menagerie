import java.util.Random;
import java.util.List;
/**
 * A class representing shared characteristics of actors on the field.
 *
 * @version 2020.02.20
 */
public abstract class Actor
{
    // Whether the actor is alive or not.
    private boolean alive;
    // The field the actor is in.
    protected Field field;
    // The actor's position in the field.
    private Location location;
    // A random number generator used in the subclasses
    protected static final Random rand = Randomizer.getRandom();
    //Age of actor
    protected int age;
    
    /**
     * Constructs an actor
     * @param field The field this actor is in
     * @param location The location in the field this actor is to be placed
     */
    public Actor(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null){
            field.clear(location);
            location = null;
        }
    }
    
    /**
     * Sets the age of the actor to the parameter value
     * @param age int representing the number to set the actor to
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Increase the age. This could result in the actor's death or being inedible.
     */
    protected void incrementAge()
    {
        int age = getAge();
        age++;
        setAge(age);
        if(getAge() > getMaxAge()){
            setInedible();
        }
    }
    
    /**
     * @return age of the plant as an int
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null){
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return whether the actor is edible or not.
     * Can be overwritten as for different actors being edible can mean different things
     * By default actors are edible if they are alive
     * @return A boolean representing whether they are edible or not
     */
    protected boolean isEdible()
    {
        return isAlive();
    }

    /**
     * Abstract method for actors to be made inedible
     */
    abstract void setInedible();

    /**
     * Abstract method for actors to return their food value as in int
     */
    abstract int getFoodValue();
    
    /**
     * Abstract method for actors to return their max age as in int
     */
    abstract int getMaxAge();
}
