/**
 * A simple model of a panther.
 * They can age, move, breed, die and can get sick.
 *
 * @version 2020.02.20
 */
public class Panther extends Animal
{
    // Characteristics shared by all panthers (class variables):
    // The age at which a panther can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a panther can live. 
    private static final int MAX_AGE = 110;
    // The likelihood of a panther breeding.
    private static final double BREEDING_PROBABILITY = 0.37;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // This is how much food value it provides when eaten
    private static final int FOOD_VALUE = 9;

    /**
     * Create a panther. A panther can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Panther(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setHungerLevel(47); // Set initial hunger level when created
        isNocturnal = true;
        foodList.add(Rabbit.class);
        foodList.add(Fox.class);
        foodList.add(Boar.class);
        foodList.add(Deer.class);
    }
    
    // Getter methods
    /**
     * @return int breeding age of the animal
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return int max age of the animal
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return double breeding probability of the animal
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return int max litter size of the animal
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return int food value of the animal (how much less hungry will an animal be if it eats this animal)
     */
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * @return Panther returns a new instance of this animal
     */
    public Animal getChild(boolean randomAge, Field field, Location location) 
    {
        return new Panther(randomAge, field, location);
    }
}