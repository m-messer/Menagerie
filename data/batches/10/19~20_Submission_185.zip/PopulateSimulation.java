import java.util.Random;
import java.util.List;

/**
 * Helper class for Simulator class to populate the simulation to imporve coupling and class structure. 
 *
 * @version 2020.02.20
 */
public class PopulateSimulation
{
    // The probability that each actor will be created in any given grid position
    private static final double FOX_CREATION_PROBABILITY = 0.023014;
    private static final double RABBIT_CREATION_PROBABILITY = 0.0845;
    private static final double CARROT_CREATION_PROBABILITY = 0.063421;
    private static final double NUT_CREATION_PROBABILITY = 0.04636;
    private static final double PANTHER_CREATION_PROBABILITY = 0.010851979000845;
    private static final double BOAR_CREATION_PROBABILITY = 0.04187699747;
    private static final double DEER_CREATION_PROBABILITY = 0.08071645;
    
    /**
     * Randomly populate the field with actors, including animals and plants.
     */
    public static void populateSimulator(Field field, List<Animal> animals, List<Plant> plants)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++){
            for(int col = 0; col < field.getWidth(); col++){
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    if(field.canActorBePlaced(Fox.class, location)){ //Checks if the actor can be placed into the location based on terrain
                        Fox fox = new Fox(true, field, location);
                        animals.add(fox);
                    }
                }else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    if(field.canActorBePlaced(Rabbit.class, location)){
                        Rabbit rabbit = new Rabbit(true, field, location);
                        animals.add(rabbit);
                    }
                }else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    if(field.canActorBePlaced(Deer.class, location)){
                        Deer deer = new Deer(true, field, location);
                        animals.add(deer);
                    }
                }else if(rand.nextDouble() <= PANTHER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    if(field.canActorBePlaced(Panther.class, location)){
                        Panther panther = new Panther(true, field, location);
                        animals.add(panther);
                    }
                }else if(rand.nextDouble() <= BOAR_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    if(field.canActorBePlaced(Boar.class, location)){
                        Animal boar = new Boar(true, field, location);
                        animals.add(boar);
                    }
                }else if(rand.nextDouble() <= CARROT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    if(field.canActorBePlaced(Carrot.class, location)){
                        Plant plant = new Carrot(true, field, location);
                        plants.add(plant);
                    }
                }else if(rand.nextDouble() <= NUT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    if(field.canActorBePlaced(Nut.class, location)){
                        Plant plant = new Nut(true, field, location);
                        plants.add(plant);
                    }
                }
            }
        }
    }
}