/**
 * A class representing carrots and providing functionality to iteract with them.
 *
 * @version 2020.02.20
 */
public class Carrot extends Plant
{
    // The age to which a Carrot can live.
    private static final int MAX_AGE = 15;
    // How much this carrot satiates whatever eats it
    private static final int FOOD_VALUE = 4;
    // Ages at which the carrot can be eaten
    private static final int EDIBLE_AGE = 4;
    
    /**
     * Constructs a carrot
     * @param randomAge if true then the age will be random, otherwise the age will be zero
     * @param field the field this carrot will be on
     * @param location  the location on the field that this carrot will be placed
     */
    public Carrot(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        waterLevel = sunLevel = 30;
    }

    /**
     * Returns the max age this can live to
     * @return  MAX_AGE Returns the max age
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the edible age at which this can be eaten
     * @return  EDIBLE_AGE Returns the edible age
     */
    public int getEdibleAge()
    {
        return EDIBLE_AGE;
    }

    /**
     * Returns the food value from eating this plant
     * @return FOOD_VALUE   The value of eating this plant
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
}
