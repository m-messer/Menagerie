import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * Represent a rectangular grid of field positions.
 * Each position is able to store a single actor.
 *
 * @version 2020.02.20
 */
public class Field
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();

    // The depth and width of the field.
    private int depth, width;
    // Storage for the actors.
    private Object[][] field;
    // Storage for the terrain.
    private Object[][] terrainField;
    // ArrayList of all the classes of terrains in the field
    private ArrayList<Terrain> terrainList;
    // Environment object used to represent the environment
    private Environment environment;

    /**
     * Represent a field of the given dimensions.
     * @param depth The depth of the field.
     * @param width The width of the field.
     */
    public Field(int depth, int width)
    {
        this.depth = depth;
        this.width = width;
        field = new Object[depth][width];
        terrainField = new Object[depth][width];
        terrainList = new ArrayList<>();
        environment = new Environment();
    }

    /**
     * Return the current environment
     * @return environment  The environment of the field
     */
    public Environment getEnvironment()
    {
        return environment;
    }

    /**
     * Adds the given terrain to the list of terrains this field has
     * @param terrain  The terrain to be added to the list
     */
    public void addTerrain(Terrain terrain)
    {
        terrainList.add(terrain);
    }

    /**
     * This method will apply all the terrains in the terrainList, which means it will essentially fill the
     * terrainField with all terrain objects at the correct locations.
     * @param terrainList ArrayList of Terrain objects to fill to the terrainField 
     */
    public void applyTerrains()
    {
        for(Terrain terrain : terrainList){
            //Apply the terrains (fill the terrainField with the correct Terrain objects)
            for(int row = terrain.getX1Axis(); row <= terrain.getX2Axis(); row++) {
                for(int col = terrain.getY1Axis(); col <= terrain.getY2Axis(); col++) {
                    if(getObjectTerrainAt(row, col) == null){ //Check if a terrain does not already exist at the location
                        placeTerrain(terrain, new Location(row, col));
                    }
                }
            }
        }
    }

    /**
     * Check whether an actor can be placed at the specified location based on the object's/actor's class due to the terrain
     * @param animalClass Represents the class of the object to be added to the specified location
     * @param loc Represents the location where an actor is to be placed
     * @return true if an actor/object can be placed at the speicifed location 
     */
    public boolean canActorBePlaced(Class<?> actorClass, Location loc)
    {
        Terrain terrain = (Terrain) getObjectTerrainAt(loc.getRow(),loc.getCol());
        if(terrain == null){
            return true;
        }else{
            for(Class elementClass : terrain.getActorList()){
                if(actorClass.equals(elementClass)){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Assign a terrain to a location in the terrainField.
     * @param terrain Terrain object which will be added to the location specified
     * @param location The location where the terrain is to be placed in the terrainField
     */
    private void placeTerrain(Terrain terrain, Location location)
    {
        terrainField[location.getRow()][location.getCol()] = terrain;
    }

    /**
     * Returns the object at the specified location (row, col) from the terrainField
     * @param row int representing the row in the terrainField
     * @param col int representing the column in the terrainField
     * @return Object at the specified location
     */
    private Object getObjectTerrainAt(int row, int col)
    {
        return terrainField[row][col]; 
    }

    /**
     * Empty the terrainField.
     */
    public void clearTerrainField()
    {
        for(int row = 0; row < depth; row++){
            for(int col = 0; col < width; col++){
                terrainField[row][col] = null;
            }
        }
    }

    /**
     * Empty the field.
     */
    public void clear()
    {
        for(int row = 0; row < depth; row++){
            for(int col = 0; col < width; col++){
                field[row][col] = null;
            }
        }
    }

    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    public void clear(Location location)
    {
        field[location.getRow()][location.getCol()] = null;
    }

    /**
     * Place an animal at the given location.
     * If there is already an animal at the location it will
     * be lost.
     * @param animal The animal to be placed.
     * @param row Row coordinate of the location.
     * @param col Column coordinate of the location.
     */
    public void place(Object animal, int row, int col)
    {
        place(animal, new Location(row, col));
    }

    /**
     * Place an animal at the given location.
     * If there is already an animal at the location it will
     * be lost.
     * @param animal The animal to be placed.
     * @param location Where to place the animal.
     */
    public void place(Object animal, Location location)
    {
        field[location.getRow()][location.getCol()] = animal;
    }

    /**
     * Return the animal at the given location, if any.
     * @param location Where in the field.
     * @return The animal at the given location, or null if there is none.
     */
    public Object getObjectAt(Location location)
    {
        return getObjectAt(location.getRow(), location.getCol());
    }

    /**
     * Return the animal at the given location, if any.
     * @param row The desired row.
     * @param col The desired column.
     * @return The animal at the given location, or null if there is none.
     */
    public Object getObjectAt(int row, int col)
    {
        return field[row][col];
    }

    /**
     * Generate a random location that is adjacent to the
     * given location, or is the same location.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location randomAdjacentLocation(Location location)
    {
        List<Location> adjacent = adjacentLocations(location);
        return adjacent.get(0);
    }

    /**
     * Get a shuffled list of the free adjacent locations.
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */
    public List<Location> getFreeAdjacentLocations(Location location)
    {
        List<Location> free = new LinkedList<>();
        List<Location> adjacent = adjacentLocations(location);
        for(Location next : adjacent){
            if(getObjectAt(next) == null){
                free.add(next);
            }
        }
        return free;
    }

    /**
     * Try to find a free location that is adjacent to the
     * given location. If there is none, return null.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location freeAdjacentLocation(Location location)
    {
        // The available free ones.
        List<Location> free = getFreeAdjacentLocations(location);
        if(free.size() > 0){
            return free.get(0);
        }else{
            return null;
        }
    }

    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    public List<Location> adjacentLocations(Location location)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        if(location != null){
            int row = location.getRow();
            int col = location.getCol();
            for(int roffset = -1; roffset <= 1; roffset++){
                int nextRow = row + roffset;
                if(nextRow >= 0 && nextRow < depth){
                    for(int coffset = -1; coffset <= 1; coffset++){
                        int nextCol = col + coffset;
                        // Exclude invalid locations and the original location.
                        if(nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)){
                            locations.add(new Location(nextRow, nextCol));
                        }
                    }
                }
            }

            // Shuffle the list. Several other methods rely on the list
            // being in a random order.
            Collections.shuffle(locations, rand);
        }
        return locations;
    }

    /**
     * Return the depth of the field.
     * @return The depth of the field.
     */
    public int getDepth()
    {
        return depth;
    }

    /**
     * Return the width of the field.
     * @return The width of the field.
     */
    public int getWidth()
    {
        return width;
    }
}
