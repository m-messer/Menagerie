/**
 * A class representing shared characteristics of plants.
 *
 * @version 2020.02.20
 */
public abstract class Plant extends Actor
{
    // Water level of plant
    protected int waterLevel;
    // Sun level of plant
    protected int sunLevel;
    
    /**
     * Constructor for objects of class Plant
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
        setAge(rand.nextInt(getMaxAge()));
    }

    /**
     * Method resets the plant's attributes, essentially making it 'reborn'.
     */
    public void setInedible()
    {
        age = 0;
        waterLevel = 0;
        sunLevel = 0; 
    }

    /**
     * Method that makes the plant act. A plant acts by decrementing its water and sun levels if they are not equal to 0.
     * A plant grows if it has sufficient amount of water and sun. All plants act using this method in this class.
     * A plant is also inedible if it has a low level of water or sun.
     */
    public void act()
    {
        if(waterLevel > 0){
            waterLevel--;
        }
        if(sunLevel > 0){
            sunLevel--;
        }
        if(field.getEnvironment().getClimate().getIsRaining()){
            waterLevel += 10;
        }
        if(field.getEnvironment().getClimate().getIsSunny()){
            sunLevel += 10;
        }
        if(waterLevel > 10 && sunLevel > 10){
            incrementAge();
        }
        if(waterLevel < 1 || sunLevel < 1){
            setInedible();
        }
    }

    // Getter methods
    /**
     * @return age of the plant as an int
     */
    public int getAge()
    {
        return age;
    }

    /**
     * Method checks if the plant is edible. A plant is edible if its age is greater or equal to it's edible age
     * @return boolean true if the plant is edible, otherwise false
     */
    public boolean isEdible()
    {
        return getAge() >= getEdibleAge();
    }

    /**
     * @return int water level of the plant
     */
    private int getWaterLevel()
    {
        return waterLevel;
    }

    /**
     * @return int sun level of the plant
     */
    private int getSunLevel()
    {
        return sunLevel;
    }

    // Abstract methods
    /**
     * Abstract method to return the max age of the plant as an int
     */
    abstract int getMaxAge();

    /**
     * Abstract method to return the edible age of the plant as an int
     */
    abstract int getEdibleAge();
}