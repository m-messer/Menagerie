import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.LinkedList;
/**
 * A simple model of a wildebeast.
 * Rabbits age, move, breed, and die.
 *
 * @version 2019.2.22
 */
public class Wildebeest extends Animal
{
    // Characteristics shared by all wildebeasts (class variables).

    // The age at which a wildebeast can start to breed.
    private static final int BREEDING_AGE = 21;
    // The age to which a wildebeast can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a wildebeast breeding.
    private static final double BREEDING_PROBABILITY = 0.21;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
   
    /**
     * Create a new wildebeast. A wildebeast may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the wildebeast will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wildebeest(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(GRASS_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(GRASS_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the wildebeast does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newWildebeasts A list to return newly born wildebeasts.
     */
    public void act(List<Organisms> newWildebeests)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWildebeests);            
            // Try to move into a free location.
            Location foodLocation = findFood(1, getField().adjacentLocations(getLocation()), new LinkedList<Location>());
            if(foodLocation == null) { 
                foodLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(foodLocation != null) {
                setLocation(foodLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }    
        }  
    }
    
    /**
     * Check whether or not this wildebeast is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWildebeasts A list to return newly born wildebeasts.
     */
    private void giveBirth(List<Organisms> newWildebeasts)
    {
        // New wildebeasts are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wildebeest young = new Wildebeest(false, field, loc);
            newWildebeasts.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed(BREEDING_AGE) && 
        rand.nextDouble() <= BREEDING_PROBABILITY && breedCheck(this)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * @return it returns the max age of Wildebeest.
     */
    protected  int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Inherited from superclass, it seaches area around the animal and we can modify the radius.
     * @param count radius of search
     * @param adjacent list of locations around the current location
     * @param previous list of the lcoations that have been checked 
     */
    protected Location findFood(int count, List<Location>  adjacent, List<Location> previous)
    {
        if (count < 0){
            return null;
        }

        List<Location> previousLocations = previous;

        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = getField().getObjectAt(where);

            if(organism instanceof Grass) {
                killGrass((Grass) organism);
                return where;
            }

            if(previousLocations.contains(where)){continue;}

            previousLocations.add(where);

            if (findFood(count - 1, getField().adjacentLocations(where), previousLocations)!= null){
                return where;
            }
        }
        return null;
    }
    
    /**
     * set the specipic animals to death
     * @param grass The animal that the animal eat
     */
     protected void killGrass(Grass grass)    
    {
        grass.setDead();
    }
}