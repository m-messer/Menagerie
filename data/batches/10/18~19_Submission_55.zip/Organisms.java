import java.util.Random;
import java.util.List;
/**
 * An abstract class shows the characters that all the organisms have.
 * and it is the superclass of animals and plants.
 *
 * @version 2019.2.22
 */

public abstract class Organisms
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organims's field.
    private Field field;
    // The organism's position in the field.
    private Location location;    
    // The organism's age 
    protected int age;
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Organisms(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
        
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
        
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract protected void act(List<Organisms> newAnimals);
    
    /**
     * @return Returns the age, with the type int.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set the age of the animal to a certain value.
     * @param age The age we would like to set to the animal.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * Increase the age. This could result in the organism's death.
     * 
     * @param maxage it is used to check if the age too old to live.
     */
    protected void incrementAge(int maxAge)
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }
}


