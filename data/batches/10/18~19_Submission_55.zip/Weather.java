
/**
 * Enumeration class Weather
 * It contains all the weathers that are existing in this
 * simulation.
 *
 * @version 2019.2.22
 * 
 */

public enum Weather
{
    FOG(),RAIN(),WIND(),SNOW(),SUNNY();
}
