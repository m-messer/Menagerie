import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 * And it is the superclass of all kinds of animals clasess.
 *
 * @version 2019.2.22
 */
public abstract class Animal extends Organisms
{
    // The animal's gender.
    private String gender;

    // The animal's food level and if it is too low
    // the animal dies
    private int foodLevel;        
    // The random number is used to ditermine if the animal is male.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single hyena.
    protected static final int HYENA_FOOD_VALUE = 110;
    // The food value of a single deer.
    protected static final int DEER_FOOD_VALUE = 95;
    // The food value of a single wildebeast.
    protected static final int WILDEBEEST_FOOD_VALUE = 100;
    // The food value of a single deer.
    protected static final int RHINO_FOOD_VALUE = 110;
    //The food value of a single blade of grass
    protected static final int GRASS_FOOD_VALUE = 35;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Animal(Field field, Location location)
    {
        super(field,location);        
        gender = setGender();
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the wildebeast can breed, false otherwise.
     */
    protected boolean canBreed(int breedingAge)
    {
        return age >= breedingAge;
    }

    /**
     * The disease will accelerlate animal's death
     * @param maxAge it gives the max age of the animal
     */
    protected void diseaseEffect(int maxAge)
    {
        age = age + 10;
        if(age > maxAge) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Indicate if the animal is male.
     * @return returns the gender of the animal.
     */
    protected String setGender()
    {   
        if(rand.nextInt(2) == 1){   
            return "male";
        }
        else{
            return "female";
        }
    }

    /**
     * return the gender of the animal.
     * @return returns the gender with the type of String.
     */
    protected String getGender()
    {
        return gender;
    }
    
    /**
     * This checks if this animal and the adjacent animal are the same species and have different 
     * gender.
     * @param anim input the animal that we want to check
     * @return return ture if one of the adjacent animals can breed with the animal and false 
     * otherwise.
     */
    protected boolean breedCheck(Animal anim){
        Field field = getField();
        //get a list of adjacent locaitons
        List<Location> adjacent = field.adjacentLocations(getLocation());
        //initialize the boolean variable
        boolean check = false;
        for(Location where : adjacent) {
            try{
                Animal animal = (Animal) field.getObjectAt(where);//get the animal on the location
                //check if these two animals have the same subclass
                if(animal.getClass() == anim.getClass()) {
                    //check if these two animals have diffferent genders
                    if(!anim.getGender().equals(animal.getGender())){
                        return !check;
                    }
                    return check;
                } 
            }catch(NullPointerException e){

            }catch(ClassCastException c){}
        }
        return check;
    }
       
    /**
     * @return returns the food level.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * set the food level of the animal to a certain value.
     * @param the food level, with the type int, we want to set.
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected abstract int breed();
    
    /**
     * @return the max age, that is private in different classes, of the animal.
     */
    protected abstract int getMaxAge();
    
    /**
     * This method allows the animal to find the food a few cells away and to move towards 
     * the food. Recursion is used in this method to check the food in a certain area. And, 
     * if the animal has not found any food with the adjacent locations(4 locaitons), we call
     * the method again and put one of adjacent locations into the method.
     * @param count max times we wish to repeat the process. In other words, how big we wish the
     * searching area to be.
     * @param adjacent list of locations around the current location where the animal stays.
     * @param previous list of the lcoations that have been checked. And, with this check,the whole
     * method become more efficient.
     */
    protected abstract Location findFood(int count, List<Location>  adjacent, List<Location> previous);    
}
