import java.util.Random;
import java.util.List;
/**
 * A class representing shared characteristics of plants.
 * And it is the superclass of grass.
 *
 * @version 2019.2.22
 */
public abstract class Plants extends Organisms
{       
    // If it rains how much water level is added to grass.
    protected static final int WATER_LEVEL_INCREMENT = 10;
    // The minimum water level for grass and, if it is below this, the grass will die.
    protected static final int MINIMAL_WATER_LEVEL = 50;
    // The likelihood of a grass breeding.
    protected static final double BREEDING_PROBABILITY_INCREMENT = 0.05;
    // The likelihood of a grass is died from snowing.
    protected static final double DIE_FROM_SNOW_PROBABILITY = 0.05;
    // The water level for each grass.
    private int waterLevel;
    // The random number is used to for different purposes.
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a plant. A plant can be created as a new born (age zero
     * and not hungry).
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(Field field, Location location)
    {
        super(field,location);
        waterLevel = rand.nextInt(51)+ rand.nextInt(50);
    }
    
    /**
     * @return returns the water level of this grass.
     */
    protected int getWaterLevel()
    {
        return waterLevel;
    }
    
    /**
     * increase the water level of this grass.
     */
    protected void incrementWaterLevel()
    {
        waterLevel += WATER_LEVEL_INCREMENT;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    protected abstract void act(List<Organisms> newAnimals);
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return returns the number of births (may be zero).
     */
    protected abstract int breed();
}

