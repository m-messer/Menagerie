import java.util.Random;
import java.util.List;
/**
 * A simple model of a grass.
 * grass age,and die.
 * And grass are affected by the weather.
 *
 * @version 2019.2.22
 */
public class Grass extends Plants
{
    // The age to which a grass can live.
    private static final int MAX_AGE = 8;
    // The likelihood of a grass breeding.
    private double breedingProbability = 0.40;
    // The the probability of breeding.
    private final static double BREEDING_PROBABILITY = 0.55;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private static final int MAX_AMOUNT_OF_GRASS = 1000;
    // Individual characteristics (instance fields).
    /**
     * Create a grass. A grass can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the grass will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge,Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        }
        else{   
            setAge(0);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= breedingProbability) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * This is what the grass does.
     * @param newDeers A list to return newly born deers.
     */
    protected void act(List<Organisms> newGrass)
    {
        incrementAge(MAX_AGE);
        if(isAlive()) {
            giveBirth(newGrass);               
        }
        
        //check the location to see if there is weather
        Location WeatherLocation;
        try{
            WeatherLocation = getField().getLocationFromWeather(getLocation());
        }catch(NullPointerException e){
            WeatherLocation = null;
        }
            
        //act to raining weather and the water value will increase
        if(WeatherLocation != null && WeatherLocation.getWeather().equals(Weather.RAIN)){
            incrementWaterLevel();
        }// check if plant dies and add to water level function 
        
        //act to winding weather and winding may increase the breeding rate
        if(WeatherLocation != null && WeatherLocation.getWeather().equals(Weather.WIND)){
            breedingProbability += BREEDING_PROBABILITY_INCREMENT;
        }
        else{
            breedingProbability = BREEDING_PROBABILITY;
        }
        
        //act to snowing weather and grass may die from snowing
       if(WeatherLocation != null && WeatherLocation.getWeather().equals(Weather.SNOW)){
            if( rand.nextDouble() <= DIE_FROM_SNOW_PROBABILITY){
                setDead();
            }
        }
        
        //if the water level is too low then it is set to death
        if(getWaterLevel() < MINIMAL_WATER_LEVEL){
            setDead();
        }
    }
    
    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrass A list to return newly born grass.
     */
    private void giveBirth(List<Organisms> newGrass)
    {
        // New deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
    
}
