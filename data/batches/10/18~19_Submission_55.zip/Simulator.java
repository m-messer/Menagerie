import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2019.2.22
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.01;
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.03; 
    // The probability that a hyena will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.17; 
    // The probability that a hyena will be created in any given grid position.
    private static final double WILDEBEEST_CREATION_PROBABILITY = 0.15; 
    // The probability that a hyena will be created in any given grid position.
    private static final double RHINO_CREATION_PROBABILITY = 0.15; 
    
    private static final double GRASS_CREATION_PROBABILITY = 1.00; 
    
    private static final double WEATHER_PROBABILLITY = 0.50;
    
    private static final double DISEASE_PROBABILLITY = 0.01;
    

    // List of animals in the field.
    private List<Organisms> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //add grass to simulator
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Hyena.class, Color.BLUE);
        view.setColor(Deer.class, Color.ORANGE);
        view.setColor(Rhino.class, Color.GRAY);
        view.setColor(Wildebeest.class, Color.BLACK);
        view.setColor(Grass.class, Color.GREEN); 
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /*
     * Main method to run long simulation (quicker for testing 
     * purposes
     */
    public static void main(String[] args)
    {
        Simulator simulator = new Simulator();
        simulator.runLongSimulation();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        Random rand = new Random();
        
        if(rand.nextDouble() <= WEATHER_PROBABILLITY){
            field.setWeather();
        }
        
        if(rand.nextDouble() <= DISEASE_PROBABILLITY){
            field.setDisease();
        }
        
        // Provide space for newborn animals.
        List<Organisms> newAnimals = new ArrayList<>();        
        // Let all organisms act.
        for(Iterator<Organisms> it = animals.iterator(); it.hasNext(); ) {
            Organisms animal = it.next();
            if (checkIfNight() && checkOrganism(animal)){
                continue;
            }
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
                        
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }
    
    /**
     * This method check if it is night
     * @return Returns true for night and false for day.
     */
    private boolean checkIfNight()
    {
        return (step % 4) == 2 || (step % 4) == 3;
    }
    
    /**
     * This method check these organisms so that they do not move at night.
     * @return Returns true for right organsm, false for wrong organism.
     */
    private boolean checkOrganism(Organisms organism)
    {
        return organism instanceof Deer || organism instanceof Rhino || 
        organism instanceof Plants;
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(true, field, location);
                    animals.add(hyena);
                }
                else if(rand.nextDouble() <= RHINO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rhino rhino = new Rhino(true, field, location);
                    animals.add(rhino);
                }
                else if(rand.nextDouble() <= WILDEBEEST_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wildebeest wildebeast = new Wildebeest(true, field, location);
                    animals.add(wildebeast);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    animals.add(deer);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(false, field, location);
                    animals.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
