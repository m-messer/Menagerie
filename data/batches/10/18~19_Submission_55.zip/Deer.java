import java.util.List;
import java.util.Random;
import java.util.*;
/**
 * A simple model of a deer.
 * Rabbits age, move, breed, and die.
 *
 * @version 2019.2.22
 */
public class Deer extends Animal
{
    // Characteristics shared by all deers (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 13;
    // The age to which a deer can live.
    private static final int MAX_AGE = 95;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.27;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(GRASS_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(GRASS_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the deer does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newDeers A list to return newly born deers.
     */
    protected void act(List<Organisms> newDeers)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            giveBirth(newDeers);            
            // Try to move into a free location.
            Location foodLocation = findFood(1, getField().adjacentLocations(getLocation()), new LinkedList<Location>());
            if(foodLocation == null) { 
                foodLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(foodLocation != null) {
                setLocation(foodLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }    
        }  
    }
    
    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeers A list to return newly born deers.
     */
    private void giveBirth(List<Organisms> newDeers)
    {
        // New deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc);
            newDeers.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return returns the number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed(BREEDING_AGE) && 
        rand.nextDouble() <= BREEDING_PROBABILITY && breedCheck(this)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * @return returns the max age of Deer.
     */
    protected  int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Inherited from superclass, it seaches area around the animal and we can modify the radius.
     * @param count radius of search
     * @param adjacent list of locations around the current location
     * @param previous list of the lcoations that have been checked 
     */
    protected Location findFood(int count, List<Location>  adjacent, List<Location> previous)
    {
        if (count < 0){
            return null;
        }

        List<Location> previousLocations = previous;

        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = getField().getObjectAt(where);

            if(organism instanceof Grass) {
                killGrass((Grass) organism);
                return where;
            }


            if(previousLocations.contains(where)){continue;}

            previousLocations.add(where);

            if (findFood(count - 1, getField().adjacentLocations(where), previousLocations)!= null){
                return where;
            }
        }
        return null;
    }
    
    /**
     * set the specipic animals to death
     * @param grass The animal that the animal eat
     */
     protected void killGrass(Grass grass)    
    {
        grass.setDead();
    }
}
