import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.LinkedList;
/**
 * A simple model of a lion.
 * Lions age, move, eat deer, wildbeest, and Hyena and die.
 * And lions are affected by the weather.
 *
 * @version 2019.2.22
 */
public class Lion extends Animal
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a lion can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.10;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));

            setFoodLevel(rand.nextInt(HYENA_FOOD_VALUE) + 
                rand.nextInt(DEER_FOOD_VALUE) + 
                rand.nextInt(WILDEBEEST_FOOD_VALUE));
        }
        else {
            setAge(0);

            setFoodLevel(HYENA_FOOD_VALUE + DEER_FOOD_VALUE + 
                WILDEBEEST_FOOD_VALUE);
        }
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * hyenas, deers and wildebeasts. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born liones.
     */
    public void act(List<Organisms> newLions)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            giveBirth(newLions);            
            // Move towards a source of food if found.
            Location foodLocation = findFood(1, getField().adjacentLocations(getLocation()), new LinkedList<Location>());
            if(foodLocation == null) { 
                foodLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(foodLocation != null) {
                setLocation(foodLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born liones.
     */
    private void giveBirth(List<Organisms> newLions)
    {
        // New liones are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return returns the number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed(BREEDING_AGE) && rand.nextDouble() <= BREEDING_PROBABILITY && breedCheck(this)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * @return returns the max age of lion.
     */
    protected  int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Inherited from superclass, it seaches area around the animal and we can modify the radius.
     * @param count radius of search
     * @param adjacent list of locations around the current location
     * @param previous list of the lcoations that have been checked
     */
    protected Location findFood(int count, List<Location>  adjacent, List<Location> previous)
    {
        if (count < 0){
            return null;
        }

        List<Location> previousLocations = previous;

        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = getField().getObjectAt(where);

            if(animal instanceof Hyena || animal instanceof Wildebeest || 
            animal instanceof Deer) {
                if(getField().adjacentLocations(getLocation()).contains(where)){
                    killAnimal((Animal) animal);
                }
                return where;
            }

            if(previousLocations.contains(where)){continue;}

            previousLocations.add(where);

            if (findFood(count - 1, getField().adjacentLocations(where), previousLocations)!= null){
                return where;
            }
        }
        return null;
    }
    
    /**
     * set the specipic animals to death
     * @param animal The animal that the animal eat
     */
    protected void killAnimal(Animal animal)
    {
        if(animal instanceof Hyena) {
            Hyena hyena = (Hyena) animal;
            if(hyena.isAlive()) { 
                hyena.setDead();
                setFoodLevel(HYENA_FOOD_VALUE);
            }
        }
        else if(animal instanceof Deer) {
            Deer deer = (Deer) animal;
            if(deer.isAlive()) { 
                deer.setDead();
                setFoodLevel(DEER_FOOD_VALUE);
            }
        }
        else if(animal instanceof Wildebeest) {
            Wildebeest wildebeast = (Wildebeest) animal;
            if(wildebeast.isAlive()) { 
                wildebeast.setDead();
                setFoodLevel(WILDEBEEST_FOOD_VALUE);
            }
        }
    }
}
