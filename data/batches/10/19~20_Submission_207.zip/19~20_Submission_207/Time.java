/**
 * the time class is a static class therefore, no instance of it needs to be made
 * it keeps track of the current step and from that, calculates the current day/time
 *
 * @version 2020.02.21
 */
public class Time {
    //the actual step counter. initialise at day time
    private static int step = Constants.Game.ONE_DAY / 2;

    //if the game is paused or not
    private static boolean isPaused = false;

    //these are all static methods so they can be called from any object without instantiation

    /**
     * toggle the pause i.e. if paused, resume and if not paused, pause
     */
    public static void togglePause() {
        isPaused = !isPaused;
    }

    /**
     * @return if the game is currently paused
     */
    public static boolean isPaused() {
        return isPaused;
    }

    /**
     * increase the step
     */
    public static void increaseStep() {
        step++;
    }

    /**
     * reset the step to 0
     */
    public static void resetStep() {
        step = 0;
    }

    /**
     * @return the current step
     */
    public static int getStep() {
        return step;
    }

    /**
     * get how many days it has been which is the integer division of how many days fit into the current step
     *
     * @return the amount of days since the simulation started
     */
    public static int getDays() {
        return step / Constants.Game.ONE_DAY;
    }

    /**
     * get the time of day which is the remainder of how many days go into the step
     * @return the current time of day
     */
    public static int getTimeOfDay() {
        return step % Constants.Game.ONE_DAY;
    }

    /**
     * @return a string of the time of day
     */
    public static String getTimeOfDayString() {
        if (getTimeOfDay() < Constants.Game.ONE_DAY / 2) {
            return Constants.Strings.TIME_NIGHT;
        } else {
            return Constants.Strings.TIME_DAY;
        }
    }
}
