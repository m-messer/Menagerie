/**
 * the class with the main function that is called when the application is run
 *
 * @version 2020.02.21
 */
class Application {
    /**
     * the main function to run the program
     * start with default values and (try to) run for 2000 steps
     *
     * @param args arguments to pass to the main method
     */
    public static void main(String[] args) {
        Simulator s = new Simulator();
        s.simulate(2000);
    }
}