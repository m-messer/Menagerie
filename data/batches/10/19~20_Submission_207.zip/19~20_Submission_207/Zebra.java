/**
 * A simple model of a Zebra.
 * Zebras age, move, breed, and die.
 *
 * @version 2020.02.21
 */
public class Zebra extends Prey {
    /**
     * Create a new Zebra. A Zebra may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Zebra will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, Constants.Zebra.BREEDING_AGE, Constants.Zebra.MAX_AGE, Constants.Zebra.BREEDING_PROBABILITY, Constants.Zebra.NIGHT_ACTIVITY, Constants.Zebra.FOOD_VALUE, Constants.Zebra.RAIN_ACTIVITY, Constants.Zebra.NUM_OF_BIRTHS);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * create a new animal to breed
     * @param field the field to breed in
     * @param loc the actual location within the field to breed
     * @return return the animal to breed
     */
    @Override
    protected Animal createNewAnimal(Field field, Location loc) {
        return new Zebra(false, field, loc);
    }
}

