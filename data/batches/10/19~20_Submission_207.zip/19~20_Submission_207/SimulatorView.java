import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2020.02.21
 */
public class SimulatorView extends JFrame {
    // Colors used for empty locations and other non organism squares
    private static final Color EMPTY_COLOR = Color.white;
    private static final Color DISEASE_COLOR = Color.black;
    private static final Color NIGHT_COLOR = Color.lightGray;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    //strings
    private final String STEP_PREFIX = Constants.Strings.STEP_PREFIX;
    private final String POPULATION_PREFIX = Constants.Strings.POPULATION_PREFIX;

    private JLabel stepLabel, population, infoLabel;
    private FieldView fieldView;

    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;


    private int xScale, yScale;

    /**
     * Create a view of the given width and height.
     *
     * @param field  the field in which the simulation is running
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width, Field field) {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Nature Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        setLocation(5, 5); //where to put the application on the user's screen

        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new BorderLayout());
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(infoLabel, BorderLayout.CENTER);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);

        //add a mouse listener which listens to the window for when the user clicks the screen
        contents.addMouseListener(new MouseAdapter() {
            //when the mouse is pressed, get the location, convert it to
            //rows and columns and try and find out the organism info
            //whilst there, pause the game
            @Override
            public void mousePressed(MouseEvent e) {
                //get the object at the mouse x, y locations on the current field (remembering the scaling)
                Object obj = field.getObjectAt(e.getY() / yScale - 3, e.getX() / xScale);

                //if it's not a blank square, and is actually an organism
                if (obj instanceof Organism) {
                    Time.togglePause(); //pause it
                    Organism org = (Organism) obj; //cast it so we get the organism methods
                    String name = org.getClass().toString().substring(5); //get the name of the class (and get rid of the "class ..." bit)

                    //create a formatted string with the info of the organism
                    String info = "Selected organism: " + name +
                            "\nCurrent age: " + org.getAge() +
                            "\nRotten: " + org.isRotten();

                    //if the organism is an animal
                    if (org instanceof Animal) {
                        Animal animal = (Animal) org; //cast it

                        //create a longer info string as animals have more info to be shown
                        info = "Selected organism: " + name +
                                "\nCurrent age: " + animal.getAge() +
                                "\nRotten: " + animal.isRotten() +
                                "\nInfected: " + animal.getIsInfected() +
                                "\nGender: " + animal.getGender() +
                                "\nFood Level: " + animal.current_food_value();
                    }

                    //create a dialog assigned to the parent panel with the info and name
                    //assign it to a variable so that we can check for when the user has pressed the ok button
                    int input = JOptionPane.showOptionDialog(contents, info, name, JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);

                    //once the ok button pressed, resume the simulation
                    if (input == JOptionPane.OK_OPTION) {
                        Time.togglePause();
                    }
                }
            }
        });
        pack();
        setVisible(true);
    }

    /**
     * Define a color to be used for a given class of animal.
     *
     * @param animalClass The animal's Class object.
     * @param color       The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color) {
        colors.put(animalClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text) {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass) {
        Color col = colors.get(animalClass);
        if (col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        } else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     *
     * @param step  Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field) {
        if (!isVisible()) {
            setVisible(true);
        }

        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();

        fieldView.preparePaint();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object Organism = field.getObjectAt(row, col);
                if (Organism != null) {
                    stats.incrementCount(Organism.getClass());

                    //if the user wants night/day/rotten graphics....
                    if (Constants.Game.BETTER_GRAPHICS) {
                        //if it's an animal and infected, it is a different colour
                        if (Organism instanceof Animal && ((Animal) Organism).getIsInfected()) {
                            fieldView.drawMark(col, row, DISEASE_COLOR);
                        } else if (Organism instanceof Organism && ((Organism) Organism).isRotten()) {
                            //if it is an organism and it's rotten, then it is a box which is displayed
                            //by passing another parameter
                            Organism organism = (Organism) Organism;
                            fieldView.drawMark(col, row, getColor(Organism.getClass()), organism.isRotten());
                        } else {
                            //otherwise just draw it as normal
                            fieldView.drawMark(col, row, getColor(Organism.getClass()));
                        }
                    } else {
                        //draw it as normal if the user does not want any of the fancy graphics
                        fieldView.drawMark(col, row, getColor(Organism.getClass()));
                    }
                } else {
                    //if the user wants to see night and day....
                    if (Constants.Game.BETTER_GRAPHICS) {
                        int tod = Time.getTimeOfDay();
                        //get the time of day and if it's < halfway - display night
                        if (tod < Constants.Game.ONE_DAY / 2) {
                            fieldView.drawMark(col, row, NIGHT_COLOR);
                        } else {
                            //otherwise just display an empty coloour
                            fieldView.drawMark(col, row, EMPTY_COLOR);
                        }
                    } else {
                        //display an empty colour
                        fieldView.drawMark(col, row, EMPTY_COLOR);
                    }
                }
            }
        }
        stats.countFinished();

        //display all the information at the bottom of the screen
        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field) + "  Day: " + Time.getDays()
                + "  Time: " + Time.getTimeOfDayString() + "  Weather: " + Weather.getWeather());
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     *
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field) {
        return stats.isViable(field);
    }

    /**
     * Provide a graphical view of a rectangular field. This is
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this
     * for your project if you like.
     */
    private class FieldView extends JPanel {
        private final int GRID_VIEW_SCALING_FACTOR = 6;
        Dimension size;
        private int gridWidth, gridHeight;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width) {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize() {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                    gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint() {
            if (!size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if (xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if (yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         * this method takes another parameter which, if true, draws a hollow rectangle rather
         * than a filled rectangle
         * @param color the color to draw the square
         * @param drawNoFill if true, only the outline is drawn and not filled in
         * @param x  location to draw the mark - x co-ordinate
         * @param y  location to draw the mark - y co-ordinate
         */
        public void drawMark(int x, int y, Color color, Boolean drawNoFill) {
            resetMark(x, y);

            g.setColor(color);
            if (drawNoFill) {
                g.drawRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
            } else {
                g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         * this method takes another parameter which, if true, draws a hollow rectangle rather
         * than a filled rectangle
         * @param color the color to draw the square
         * @param x  location to draw the mark - x co-ordinate
         * @param y  location to draw the mark - y co-ordinate
         */
        public void drawMark(int x, int y, Color color) {
            resetMark(x, y);
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
        }

        /**
         * set a mark to empty
         *
         * @param x x co-ordinate to set empty
         * @param y y co-ordinate to set empty
         */
        public void resetMark(int x, int y) {
            g.setColor(EMPTY_COLOR);
            g.drawRect(x * xScale, y * yScale, xScale - 1, yScale - 1);

            g.clearRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g) {
            if (fieldImage != null) {
                Dimension currentSize = getSize();
                if (size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                } else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
