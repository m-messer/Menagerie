import java.util.List;
import java.util.Random;

/**
 * the ultimate super-class for each living thing in the simulation
 * contains many properties that all organisms share
 *
 * @version 2020.02.21
 */

public abstract class Organism {
    // A shared random number generator to control breeding.
    protected static Random rand = Randomizer.getRandom();
    // The age at which an Organism can start to breed.
    protected static int BREEDING_AGE;
    // The age to which an Organism can live.
    protected static int MAX_AGE;
    // The likelihood of an Organism breeding.
    protected static double BREEDING_PROBABILITY;
    // Whether the Organism thing is alive or not.
    protected boolean alive;
    // The Organism's current field.
    protected Field field;
    // The Organism's position in the field.
    protected Location location;
    //the Organism's age
    protected int age;
    //how much energy other organisms get from eating this organism - i.e. how many steps they can take before starvation
    protected int FOOD_VALUE;
    //the likelihood of the organism being active in the rain
    protected double rain_activity;
    //if the animal is rotten (dead but still on screen & can infect animals)
    protected boolean isRotten = false;

    /**
     * Create a new organism at location in field.
     *
     * @param field                The field currently occupied.
     * @param location             The location within the field.
     * @param breeding_age         The age at which an Organism can start to breed.
     * @param max_age              The age to which an Organism can live.
     * @param breeding_probability The likelihood of an Organism breeding.
     * @param food_value           how much energy is provided by eating this animal
     * @param rain_activity        the likelihood of this organism being active in the rain
     */
    public Organism(Field field, Location location, int breeding_age, int max_age, double breeding_probability, int food_value, double rain_activity) {
        alive = true;
        this.field = field;
        setLocation(location);
        BREEDING_AGE = breeding_age;
        MAX_AGE = max_age;
        BREEDING_PROBABILITY = breeding_probability;
        FOOD_VALUE = food_value;
        this.rain_activity = rain_activity;
    }

    /**
     * Check whether the Organism is alive or not.
     *
     * @return true if it is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that it is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        if (location != null) {
            alive = false;
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * there is a chance when a human kills an organism for it to become rotten
     * otherwise, it dies as normal
     */
    protected void setIsRotten() {
        //there is only a slight chance of the meat becoming rotten
        if (rand.nextDouble() <= Constants.Game.ROTTEN_PROBABILITY) {
            isRotten = true;
        } else {
            setDead();
        }
    }

    /**
     * @return if it is rotten or not
     */
    protected boolean isRotten() {
        return isRotten;
    }

    /**
     * @return the age of the organism
     */
    protected int getAge() {
        return age;
    }

    /**
     * Increase the age.
     * This could result in the Organism's death.
     */
    protected void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Return the current location.
     *
     * @return The current location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the Organism at the new location in the given field.
     *
     * @param newLocation The new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the Organism's field.
     *
     * @return The Organism's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * An Organism can breed if it has reached the breeding age.
     *
     * @return true if the Organism can breed, false otherwise.
     */
    protected boolean canBreed() {
        return (age >= BREEDING_AGE && !isRotten());
    }

    /**
     * @return the food value of this organism
     */
    protected int get_food_value() {
        return FOOD_VALUE;
    }

    /**
     * what each organism does every step, overridden by subclasses to implement custom behaviour
     *
     * @param newOrganism list of organisms to add too
     */
    protected abstract void act(List<Organism> newOrganism);

    /**
     * set the max age of the organism
     *
     * @param maxAge the new max age to set
     */
    protected void setMaxAge(int maxAge) {
        MAX_AGE = maxAge;
    }
}
