import java.util.List;

/**
 * A simple model of a coyote.
 * Coyotes age, move, try and hunt in packs, eat predators, and die.
 * They are an extension of the predator class
 *
 * @version 2020.02.21
 */
public class Coyote extends Predator {
    // Characteristics shared by all coyotes (class variables).

    /**
     * Create a coyote. A coyote can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the coyote will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Coyote(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, Constants.Coyote.BREEDING_AGE, Constants.Coyote.MAX_AGE, Constants.Coyote.BREEDING_PROBABILITY, Constants.Coyote.NIGHT_ACTIVITY, Constants.Coyote.RAIN_ACTIVITY, Constants.Coyote.NUM_OF_BIRTHS);
    }

    /**
     * create a new animal to breed
     * @param field the field to breed in
     * @param loc the actual location within the field to breed
     * @return return the animal to breed
     */
    @Override
    protected Animal createNewAnimal(Field field, Location loc) {
        return new Coyote(false, field, loc);
    }

    /**
     * coyotes priortise finding each other as they hunt in a pack. if they cannot find each other, they try and find food
     *
     * @return the location as to which to move
     */
    @Override
    protected Location getNewLocation() {
        Location newLocation = null; //start with no new location

        //the coyote prioritises finding mates as they work in a pack

        //iterate through the adjacent locations in the current field
        Field field = this.getField();
        List<Location> l = field.adjacentLocations(this.getLocation());
        for (int i = 0; i < l.size(); i++) {
            Object adj = field.getObjectAt(l.get(i));

            //if the adjacent animal is a coyote...
            if (adj instanceof Coyote) {

                //find a free location near it
                List<Location> free = field.getFreeAdjacentLocations(l.get(i));
                if (free.size() > 0) {
                    //return the free location near it if it exists (and therefore move that way)
                    return free.remove(0);
                }
            }
        }

        //if we could not move towards the coyote, try and find food instead
        if (newLocation == null) {
            // try and find food instead
            newLocation = findFood();
        }

        if (newLocation == null) {
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        return newLocation;
    }
}
