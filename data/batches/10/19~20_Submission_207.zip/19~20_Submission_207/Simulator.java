import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing gazelles and lions.
 *
 * @version 2020.02.21
 */
public class Simulator {
    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(Constants.Game.DEFAULT_DEPTH, Constants.Game.DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = Constants.Game.DEFAULT_DEPTH;
            width = Constants.Game.DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, field);
        view.setColor(Gazelle.class, new Color(255, 140, 0)); //dark orange
        view.setColor(Lion.class, Color.BLUE);
        view.setColor(Coyote.class, Color.YELLOW);
        view.setColor(Zebra.class, Color.CYAN);
        view.setColor(Buffalo.class, new Color(165,42,42)); //brown
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Human.class, Color.MAGENTA);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        //a while loop has been used to enable the game to be used. the while loop will only increment
        // - and get closer to finishing - whilst the game is running, however, the while loop is always running

        int step = 1; //counter for the while loop

        //whilst we're within the num. steps to do and it's viable
        while (step <= numSteps && view.isViable(field)) {

            //if it's not paused, simulate one step (with a delay) and increment the counter
            //(otherwise do nothing)
            if (!Time.isPaused()) {
                simulateOneStep();
                delay(Constants.Game.DELAY);   // uncomment this to run more slowly
                step++;
            }
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each organism.
     * The weather changes based on probability.
     */
    public void simulateOneStep() {
        //the time class contains everything to do with step so run the static method to increment the step
        Time.increaseStep();

        // Provide space for newborn organism.
        List<Organism> newOrganism = new ArrayList<>();
        // Let all organisms act.
        for (Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next(); //the next organism in the list

            //if it's not alive, remove it and if it's not rotten, let it act which is the main
            //activities it does such as breed or find food
            if (!organism.isAlive()) {
                it.remove();
            } else if (!organism.isRotten()) {
                organism.act(newOrganism);
            }
        }

        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganism);

        view.showStatus(Time.getStep(), field);

        //Changes the weather every x steps
        if (Time.getStep() % Constants.Game.WEATHER_CHANGE == 0) {
            Weather.setWeather();
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        Time.resetStep();
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(Time.getStep(), field);
    }

    /**
     * Randomly populate the field with all organisms.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        //for each row (y) and for each (x) there is differing chances of producing varying animals
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= Constants.Game.BUFFALO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Buffalo buffalo = new Buffalo(true, field, location);
                    organisms.add(buffalo);
                } else if (rand.nextDouble() <= Constants.Game.COYOTE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Coyote coyote = new Coyote(true, field, location);
                    organisms.add(coyote);
                } else if (rand.nextDouble() <= Constants.Game.GAZELLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Gazelle gazelle = new Gazelle(true, field, location);
                    organisms.add(gazelle);
                } else if (rand.nextDouble() <= Constants.Game.ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    organisms.add(zebra);
                } else if (rand.nextDouble() <= Constants.Game.LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    organisms.add(lion);
                } else if (rand.nextDouble() <= Constants.Game.GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    organisms.add(grass);
                } else if (rand.nextDouble() <= Constants.Game.HUMAN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Human human = new Human(true, field, location);
                    organisms.add(human);
                }
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
