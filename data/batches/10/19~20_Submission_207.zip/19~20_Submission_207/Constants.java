public final class Constants {
    public final class Game {
        // Constants representing configuration information for the simulation.
        // The default width for the grid.
        public static final int DEFAULT_WIDTH = 120;
        // The default depth of the grid.
        public static final int DEFAULT_DEPTH = 80;

        //the delay per step
        public static final int DELAY = 200;

        //the probability that each of these organisms are created initially
        public static final double LION_CREATION_PROBABILITY = 0.13;
        public static final double COYOTE_CREATION_PROBABILITY = 0.08;
        public static final double GAZELLE_CREATION_PROBABILITY = 0.25;
        public static final double ZEBRA_CREATION_PROBABILITY = 0.25;
        public static final double BUFFALO_CREATION_PROBABILITY = 0.2;
        public static final double GRASS_CREATION_PROBABILITY = 0.3;
        public static final double HUMAN_CREATION_PROBABILITY = 0.15;

        // The probability that it will be raining.
        public static final double RAIN_PROBABILITY = 0.4;
        // Changes the weather every x steps;
        public static final double WEATHER_CHANGE = 12;

        //the steps in one day.
        public static final int ONE_DAY = 24;

        //how many species should be alive when the simulation stops.
        public static final int STOP_AT_NUM_SPECIES = 1;

        //the chance of an animal dying becoming rotten.
        public static final double ROTTEN_PROBABILITY = 1.101;

        //probability of an animal being randomly infected.
        public static final double RANDOM_DISEASE = 0.00005;

        //chance of death from disease
        public static final double DEATH_FROM_DISEASE = 0.5;

        //whether to show weather/infected/rotten graphics
        public static final boolean BETTER_GRAPHICS = true;

        //probability of the newly born species being infected.
        public static final double CHILD_CARRIES_DISEASE = 0.4;

        // chance of a species being randomly male or female.
        public static final double GENDER_DISTRIBUTION = 0.5;
    }

    // Strings appearing in the GUI.
    public final class Strings {
        public static final String WEATHER_SUNNY = "Sunny";
        public static final String WEATHER_RAINY = "Rainy";
        public static final String TIME_NIGHT = "Night";
        public static final String TIME_DAY = "Day";
        public static final String STEP_PREFIX = "Step: ";
        public static final String POPULATION_PREFIX = "Population: ";
        public static final String FEMALE = "Female";
        public static final String MALE = "Male";
    }

    public final class Human {
        // The age at which a human can start to breed.
        public static final int BREEDING_AGE = 23;
        // The age to which a human can live.
        public static final int MAX_AGE = 100;
        // The likelihood of a human breeding.
        public static final double BREEDING_PROBABILITY = 0.8;

        //number of children that one human can have in one go.
        public static final int NUM_OF_BIRTHS = 2;

        //distribution of species that are active during the night
        public static final double NIGHT_ACTIVITY = 0.2;

        //distribution of species that are active during rain
        public static final double RAIN_ACTIVITY = 0.7;
    }

    public final class Gazelle {
        // The age at which a gazelle can start to breed.
        public static final int BREEDING_AGE = 5;
        // The age to which a gazelle can live.
        public static final int MAX_AGE = 80;
        // The likelihood of a gazelle breeding.
        public static final double BREEDING_PROBABILITY = 0.9;

        // The food value of this organism. In effect, this is the
        // number of steps an animal can go before it has to eat again.
        public static final int FOOD_VALUE = 30;

        //number of children that one gazelle can breed in one go
        public static final int NUM_OF_BIRTHS = 4;

        //distribution of species that are active during the night
        public static final double NIGHT_ACTIVITY = 0.0;

        //distribution of species that are active during rain
        public static final double RAIN_ACTIVITY = 0.4;
    }

    public final class Buffalo {
        // The age at which a buffalo can start to breed.
        public static final int BREEDING_AGE = 6;
        // The age to which a buffalo can live.
        public static final int MAX_AGE = 100;
        // The likelihood of a buffalo breeding.
        public static final double BREEDING_PROBABILITY = 0.6;

        // The food value of this organism. In effect, this is the
        // number of steps an animal can go before it has to eat again.
        public static final int FOOD_VALUE = 25;

        //number of children that one buffalo can breed in one go
        public static final int NUM_OF_BIRTHS = 4;

        //distribution of species that are active during the night
        public static final double NIGHT_ACTIVITY = 0.1;

        //distribution of species that are active during rain
        public static final double RAIN_ACTIVITY = 0.4;
    }

    public final class Zebra {
        // The age at which a zebra can start to breed.
        public static final int BREEDING_AGE = 8;
        // The age to which a zebra can live.
        public static final int MAX_AGE = 100;
        // The likelihood of a zebra breeding.
        public static final double BREEDING_PROBABILITY = 0.8;

        // The food value of this organism. In effect, this is the
        // number of steps an animal can go before it has to eat again.
        public static final int FOOD_VALUE = 15;


        //number of children that one zebra can breed in one go
        public static final int NUM_OF_BIRTHS = 3;

        //distribution of species that are active during the night
        public static final double NIGHT_ACTIVITY = 0.1;

        //distribution of species that are active during rain
        public static final double RAIN_ACTIVITY = 0.4;
    }

    public final class Lion {
        // The age at which a lion can start to breed.
        public static final int BREEDING_AGE = 6;
        // The age to which a lion can live.
        public static final int MAX_AGE = 100;
        // The likelihood of a lion breeding.
        public static final double BREEDING_PROBABILITY = 0.7;

        //number of children that one lion can breed in one go
        public static final int NUM_OF_BIRTHS = 2;

        //distribution of species that are active during the night
        public static final double NIGHT_ACTIVITY = 0.1;

        //distribution of species that are active during rain
        public static final double RAIN_ACTIVITY = 0.4;
    }

    public final class Coyote {
        // The age at which a coyote can start to breed.
        public static final int BREEDING_AGE = 10;
        // The age to which a coyote can live.
        public static final int MAX_AGE = 100;
        // The likelihood of a coyote breeding.
        public static final double BREEDING_PROBABILITY = 0.4;

        //number of children that one coyote can breed in one go
        public static final int NUM_OF_BIRTHS = 1;

        //distribution of species that are active during the night
        public static final double NIGHT_ACTIVITY = 0.4;

        //distribution of species that are active during rain
        public static final double RAIN_ACTIVITY = 0.4;
    }

    public final class Grass {
        // The age to which a grass can live.
        public static final int MAX_AGE = 30;
        // The likelihood of a grass breeding.
        public static final double BREEDING_PROBABILITY = 0.5;

        //distribution of species that are active during rain
        public static final double RAIN_ACTIVITY = 1.0;

        // The food value of this organism. In effect, this is the
        // number of steps an animal can go before it has to eat again.
        public static final int FOOD_VALUE = 20;
    }
}
