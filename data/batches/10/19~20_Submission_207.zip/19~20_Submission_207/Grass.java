import java.util.List;

/**
 * A grass class for representing the grass object, which can only spawn more grass when it's daytime and sunny
 * An extension of the plant class
 *
 * @version 2020.02.21
 */
public class Grass extends Plant {
    /**
     * Create new grass. Grass may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Zebra will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location) {
        super(field, location, 0, Constants.Grass.MAX_AGE, Constants.Grass.BREEDING_PROBABILITY, Constants.Grass.FOOD_VALUE, Constants.Grass.RAIN_ACTIVITY);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    public void act(List<Organism> newGrass) {
        //grass can only create more grass if it's day time and rainy
        if (Time.getTimeOfDayString().equals(Constants.Strings.TIME_DAY) && Weather.getWeather().equals(Constants.Strings.WEATHER_RAINY)) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            //get the free locations and check if within the probability of creation
            if (free.size() > 0 && rand.nextDouble() <= Constants.Grass.BREEDING_PROBABILITY) {
                //if it is, create a new grass object
                Location loc = free.remove(0);
                Grass grass = new Grass(false, field, loc);
                newGrass.add(grass);
            }
        }

        //increment the grasses age so eventually it will die out if not eaten
        incrementAge();
    }
}
