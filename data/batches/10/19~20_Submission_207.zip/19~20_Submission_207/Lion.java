import java.util.List;

/**
 * A simple model of a lion.
 * Lions age, move, eat prey, and die.
 *
 * @version 2020.02.21
 */
public class Lion extends Predator {
    // Characteristics shared by all lions (class variables).

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * Calls from the Constants class different variables holding values.
     */
    public Lion(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, Constants.Lion.BREEDING_AGE, Constants.Lion.MAX_AGE, Constants.Lion.BREEDING_PROBABILITY, Constants.Lion.NIGHT_ACTIVITY, Constants.Lion.RAIN_ACTIVITY, Constants.Lion.NUM_OF_BIRTHS);
    }

    /**
     * create a new animal to breed
     * @param field the field to breed in
     * @param loc the actual location within the field to breed
     * @return return the animal to breed
     */
    @Override
    protected Animal createNewAnimal(Field field, Location loc) {
        return new Lion(false, field, loc);
    }

    /**
     * adult lions (more than a third max age), prioritise finding food
     * all other lions try and and find other lions surrounding them
     *
     * @return the location to move too
     */
    @Override
    protected Location getNewLocation() {
        Location newLocation = null;
        //if it's an adult - more than a third the age they can be, try and find food otherwise move towards other lions
        if (this.getAge() > MAX_AGE / 3) {
            // Move towards a source of food if found.
            newLocation = findFood();
        } else {
            //the lion is not an adult as it is less than a third the max age
            //therefore, look for other lions instead as this means they can work in a 'pack'

            //get the free adjacent locations
            Field field = this.getField();
            List<Location> l = field.adjacentLocations(this.getLocation());

            //go through all the locations
            for (int i = 0; i < l.size(); i++) {
                Object adj = field.getObjectAt(l.get(i));

                //if any of the adjacent locations are a lion...
                if (adj instanceof Lion) {

                    //try and move to a free location
                    List<Location> free = field.getFreeAdjacentLocations(l.get(i));
                    if (free.size() > 0) {
                        newLocation = free.remove(0);
                    }
                }
            }
        }

        if (newLocation == null) {
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        return newLocation;
    }
}
