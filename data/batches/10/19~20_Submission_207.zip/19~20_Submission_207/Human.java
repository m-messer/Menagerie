import java.util.Iterator;
import java.util.List;

/**
 * A human class to represent humans
 * humans can eat prey, kill predators (which may make them infected), age, breed, and die
 * they are an extension of an animal
 *
 * @version 2020.02.21
 */
public class Human extends Animal {

    /**
     * Create a new animal at location in field.
     *
     * @param randomAge if the human should start at a random age
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Human(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, Constants.Human.BREEDING_AGE, Constants.Human.MAX_AGE, Constants.Human.BREEDING_PROBABILITY, Constants.Human.NIGHT_ACTIVITY, 0, Constants.Human.RAIN_ACTIVITY, Constants.Human.NUM_OF_BIRTHS);
    }

    /**
     * create a new animal to breed
     *
     * @param field the field to breed in
     * @param loc   the actual location within the field to breed
     * @return return the animal to breed
     */
    @Override
    protected Animal createNewAnimal(Field field, Location loc) {
        return new Human(false, field, loc);
    }

    /**
     * the human tries to find food - it can only eat prey/plants
     * however, if it finds a predator it will kill it which can cause it to become rotten
     *
     * @return the location to move to
     */
    @Override
    protected Location findFood() {
        //get the current adjacent locations in the field
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        //iterate through them
        while (it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);

            //check if the adjacent blocks are an organism
            if (Organism instanceof Organism) {
                Organism o = (Organism) Organism; // cast them

                //if they're prey or plant, eat the organism (and increase our food level)
                if (canEatThis(o)) {
                    o.setDead();
                    foodLevel = o.get_food_value();
                    return where;
                } else if (Organism instanceof Predator) { //otherwise, if it is a predator, turn it into rotten meat
                    //since the setIsRotten is only on the predator class, organism must be first case to a predator
                    //this only works because we are already checking if the organism is an instance of predator
                    ((Predator) Organism).setIsRotten();
                    return where;
                }
            }
        }
        //no locations were found
        return null;
    }

    protected boolean canEatThis(Organism organism) {
        return (((organism instanceof Prey || organism instanceof Plant) && organism.isAlive()) || organism.isRotten());
    }
}
