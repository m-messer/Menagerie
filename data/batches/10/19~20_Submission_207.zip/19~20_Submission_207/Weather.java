import java.util.Random;

/**
 * the weather class is a static class therefore, no instance of it needs to be made
 * it keeps track of the current weather and can change the weather depending on a random
 * probability
 *
 * @version 2020.02.21
 */
public class Weather {
    // A random number generator
    protected static Random rand = Randomizer.getRandom();
    // Current weather condition.
    private static String weather = Constants.Strings.WEATHER_SUNNY;

    /**
     * @return the current weather condition
     */
    public static String getWeather() {
        return weather;
    }

    /**
     * every time the weather is set there is a slight chance of rain
     */
    public static void setWeather() {
        //if the random number is within the probability of rain, then the weather is set to raining
        //otherwise it is sunny
        if (rand.nextDouble() <= Constants.Game.RAIN_PROBABILITY) {
            weather = Constants.Strings.WEATHER_RAINY;
        } else {
            weather = Constants.Strings.WEATHER_SUNNY;
        }
    }
}
