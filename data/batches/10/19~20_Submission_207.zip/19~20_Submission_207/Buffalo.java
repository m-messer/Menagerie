/**
 * A simple model of a Buffalo. It is prey so can be eaten by predators and survives by eating plants
 *
 * @version 2020.02.21
 */
public class Buffalo extends Prey {
    /**
     * Create a new Buffalo. A Buffalo may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Buffalo will have a random age and start with a random food value
     * @param field     The field currently occupied.
     * @param location  The location within the field to spawn.
     */
    public Buffalo(boolean randomAge, Field field, Location location) {
        //extends prey so pass all the parameters, which are constants from the constants class
        super(randomAge, field, location, Constants.Buffalo.BREEDING_AGE, Constants.Buffalo.MAX_AGE, Constants.Buffalo.BREEDING_PROBABILITY, Constants.Buffalo.NIGHT_ACTIVITY, Constants.Buffalo.FOOD_VALUE, Constants.Buffalo.RAIN_ACTIVITY, Constants.Buffalo.NUM_OF_BIRTHS);
    }


    /**
     * create a new animal to breed
     * @param field the field to breed in
     * @param loc the actual location within the field to breed
     * @return return the animal to breed
     */
    @Override
    protected Animal createNewAnimal(Field field, Location loc) {
        return new Buffalo(false, field, loc);
    }
}

