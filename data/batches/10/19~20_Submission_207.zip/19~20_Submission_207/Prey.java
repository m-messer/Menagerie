/**
 * the prey class which represents all organisms that can eat plants, be eaten by predators, move, breed
 *
 * @version 2020.02.21
 */

public abstract class Prey extends Animal {
    /**
     * Create a new prey at location in field.
     *
     * @param randomAge            whether or not to start at a random age/food level
     * @param field                The field currently occupied.
     * @param location             The location within the field.
     * @param breeding_age         The age at which prey can start to breed.
     * @param max_age              The age to which prey predator  can live.
     * @param breeding_probability The likelihood of prey breeding.
     * @param rain_activity        the likelihood of this prey being active in the rain
     * @param night_activity       the likelihood of this prey being active in the night
     * @param num_of_young         the number of young this prey can have per mate
     * @param food_value           the amount of energy a predator gets from eating this species
     */
    public Prey(boolean randomAge, Field field, Location location, int breeding_age, int max_age, double breeding_probability, double night_activity, int food_value, double rain_activity, int num_of_young) {
        //pass the parameters to the super class, animal
        super(randomAge, field, location, breeding_age, max_age, breeding_probability, night_activity, food_value, rain_activity, num_of_young);
    }

    /**
     * returns a boolean if the organism can be eaten and conforms to the hierarchy/restrictions
     *
     * @param organism the organism to check for
     * @return if the organism can be eaten
     */
    protected boolean canEatThis(Organism organism) {
        return (organism instanceof Plant || organism.isRotten());
    }
}
