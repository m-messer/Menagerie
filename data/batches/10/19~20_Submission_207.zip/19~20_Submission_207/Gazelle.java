import java.util.List;

/**
 * A simple model of a gazelle.
 * Gazelles age, move, breed, and die.
 *
 * @version 2020.02.21
 */
public class Gazelle extends Prey {
    /**
     * Create a new gazelle. A gazelle may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the gazelle will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * Calls from the Constants class different variables holding values.
     */
    public Gazelle(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, Constants.Gazelle.BREEDING_AGE, Constants.Gazelle.MAX_AGE, Constants.Gazelle.BREEDING_PROBABILITY, Constants.Gazelle.NIGHT_ACTIVITY, Constants.Gazelle.FOOD_VALUE, Constants.Gazelle.RAIN_ACTIVITY, Constants.Gazelle.NUM_OF_BIRTHS);
        age = 0;

        //when spawning, start at a random age
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * create a new animal to breed
     * @param field the field to breed in
     * @param loc the actual location within the field to breed
     * @return return the animal to breed
     */
    @Override
    protected Animal createNewAnimal(Field field, Location loc) {
        return new Gazelle(false, field, loc);
    }


    /**
     * gazelles try and avoid predators as much as they can. they do this by scouting around all adjacent locations
     * for how many predators surround them
     * otherwise, they try and find food
     *
     * @return the location to move too
     */
    @Override
    protected Location getNewLocation() {
        //set this number really high as we're trying to find the lowest
        //every time we override this IF the new number is less than the current
        int numberOfPredators = 999999;
        Location bestLoc = null; //the best location to move too - has fewest predators around it

        //iterate through all the adjacent locations
        Field field = this.getField();
        List<Location> l = field.adjacentLocations(this.getLocation());
        for (int i = 0; i < l.size(); i++) {
            int predInThisLocation = 0; //for each adjacent location, count for number of predators

            //the adjacent locations for each location surrounding the gazelle
            List<Location> l2 = field.adjacentLocations(l.get(i));

            //iterate through these locations
            for (int j = 0; j < l2.size(); j++) {

                //if it contains a predator, increase the counter
                if (field.getObjectAt(l2.get(j)) instanceof Predator) {
                    predInThisLocation++;
                }
            }

            //if this location now has the fewest predators, set this to be the best location
            if (predInThisLocation < numberOfPredators) {
                numberOfPredators = predInThisLocation;

                bestLoc = l.get(i);
            }
        }

        //get free locations around the best location and try to move to them
        List<Location> free = field.getFreeAdjacentLocations(bestLoc);
        if (free.size() > 0) {
            return free.remove(0);
        } else {
            //if there are no locations to move too, prioritise finding food next
            return findFood();
        }
    }
}
