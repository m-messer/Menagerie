import java.util.List;

/**
 * a plant class which represents any organisms that do not eat nor move
 * they randomly spawn around each other
 *
 * @version 2020.02.21
 */
public abstract class Plant extends Organism {
    /**
     * Create a new plant at location in field.
     *
     * @param field                The field currently occupied.
     * @param location             The location within the field.
     * @param breeding_age         The age at which a plant can start to breed.
     * @param max_age              The age to which a plant can live.
     * @param breeding_probability The likelihood of a plant breeding.
     * @param food_value           how much energy is provided by eating this animal
     * @param rain_activity        the likelihood of this plant being active in the rain
     */
    public Plant(Field field, Location location, int breeding_age, int max_age, double breeding_probability, int food_value, double rain_activity) {
        //pass all these parameters to the super class, organism
        super(field, location, breeding_age, max_age, breeding_probability, food_value, rain_activity);
    }

    /**
     * what the plant does each step
     *
     * @param newOrganism list of organisms to add too
     */
    protected abstract void act(List<Organism> newOrganism);
}
