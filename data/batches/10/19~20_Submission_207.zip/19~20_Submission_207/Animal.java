import java.util.Iterator;
import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.21
 */
public abstract class Animal extends Organism {
    // The Animal's food level, which is increased by eating
    protected int foodLevel;

    //the gender of the animal
    protected String gender;

    //the likeliness of this animal also being active (i.e. eating, breeding) at night
    protected double night_activity;

    //if this animal is infected or not
    protected Boolean isInfected = false;

    //the amount of animals possible to have per mate
    protected int num_of_young = 1;

    /**
     * Create a new animal at location in field.
     *
     * @param field                The field currently occupied.
     * @param location             The location within the field.
     * @param breeding_age         The age at which an Organism can start to breed.
     * @param max_age              The age to which an Organism can live.
     * @param breeding_probability The likelihood of an Organism breeding.
     * @param randomAge            whether or not the animal should be born at a random age (and random food level) - for initial population
     * @param food_value           the amount of 'energy' an animal gets from eating this animal.
     * @param night_activity       the likelihood of this animal being active at night
     * @param rain_activity        the likelihood of this animal being active in the rain
     * @param num_of_young         the number of young that can be had per mate
     */
    public Animal(boolean randomAge, Field field, Location location, int breeding_age, int max_age, double breeding_probability, double night_activity, int food_value, double rain_activity, int num_of_young) {
        super(field, location, breeding_age, max_age, breeding_probability, food_value, rain_activity);

        //there is a random distribution of females and males
        if (rand.nextDouble() < Constants.Game.GENDER_DISTRIBUTION) {
            gender = Constants.Strings.FEMALE;
        } else {
            gender = Constants.Strings.MALE;
        }

        //if we do want a random age, e.g. for initial population, set it between 0 and the max age
        //set a random food level
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(Constants.Gazelle.FOOD_VALUE);
        } else {
            //otherwise, start from the age of 0
            age = 0;
            foodLevel = Constants.Gazelle.FOOD_VALUE;
        }

        this.night_activity = night_activity;

        this.num_of_young = num_of_young;
    }

    /**
     * return if this current animal is infected
     *
     * @return a boolean if the animal is infected
     */
    public Boolean getIsInfected() {
        return isInfected;
    }

    /**
     * set this current animal to be infected
     */
    public void setIsInfected() {
        isInfected = true;
    }

    /**
     * Make this Animal more hungry. This could result in the Animals's death.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * get the gender of the animal
     *
     * @return which is the gender of the animal
     */
    protected String getGender() {
        return gender;
    }

    /**
     * This is what the animal does most of the time.
     *
     * @param newAnimals A list to return newly born animals
     */
    public void act(List<Organism> newAnimals) {
        incrementAge();
        incrementHunger();

        //there's a very slight chance that the animal will become randomly infected
        //the animal will become infected if it's not already infected and
        //it matches the probability - i.e. random number below chance of disease
        if (rand.nextDouble() <= Constants.Game.RANDOM_DISEASE && !getIsInfected()) {
            setIsInfected();
        }

        //if they are infected, there is a small (random) chance they die from disease
        if (getIsInfected() && rand.nextDouble() <= Constants.Game.DEATH_FROM_DISEASE) {
            setDead();
            return;
        }

        //if it's day or this animal also works at night AND it's sunny or this animal also works in the rain, do
        //all the usual animal activities such as finding food and breeding.
        //some animals work at night/in rain depending on if the random number generated is within their probability
        //to work. this means there is a distribution of animals that work at night/rain
        if (((rand.nextDouble() < night_activity && Time.getTimeOfDayString().equals(Constants.Strings.TIME_NIGHT)) ||
                Time.getTimeOfDayString().equals(Constants.Strings.TIME_DAY)) &&
                ((rand.nextDouble() < rain_activity && Time.getTimeOfDayString().equals(Constants.Strings.TIME_NIGHT)) || Weather.getWeather().equals(Constants.Strings.WEATHER_SUNNY))) {
            if (isAlive()) {
                giveBirth(newAnimals);

                //this method finds the location of food, or a new empty location
                //however, some animals override this for more complex behaviour
                Location newLocation = getNewLocation();

                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * this method tries to find food, otherwise if not found, just a free adjacent location
     * this method is usually overridden by the animal classes to implement more complex behaviour
     *
     * @return a location of the location to move too (i.e. contains food or is a free location)
     */
    protected Location getNewLocation() {
        // Move towards a source of food if found.
        Location newLocation = findFood();
        if (newLocation == null) {
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        return newLocation;
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first food is eaten.
     * the food can only be eaten if it is within the hierarchy
     * they may become infected if they eat an animal that is infected or rotten
     *
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        //get the adjacent locations to the animal in the current field
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());

        //iterate through the locations
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            //predators can eat prey and prey can eat plants
            if (Organism instanceof Organism && canEatThis((Organism) Organism)) {
                Organism o = (Organism) Organism; //cast it to get the organism methods
                if (o.isAlive()) {
                    //if the animal is rotten or infected, set this animal to infected too
                    if (o.isRotten() || (o instanceof Animal && ((Animal) o).getIsInfected())) {
                        this.setIsInfected();
                    }

                    //the organism was eaten so kill it and set this animal's food level
                    o.setDead();
                    foodLevel = o.get_food_value();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * returns a boolean if the organism can be eaten and conforms to the hierarchy/restrictions
     *
     * @param organism the organism to check for
     * @return if the organism can be eaten
     */
    protected abstract boolean canEatThis(Organism organism);

    /**
     * the breed method calculates the number of young to breed depending on various factors including breeding probability
     * and opposite gendered mates surrounding the animal
     *
     * @param field       the current field the animal is in
     * @param species     the species of the animal it can mate with
     * @return the number of young to produce
     */
    protected int breed(Field field, Class species) {
        //if the animal can breed and the chance is within the probability...
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            //counters for how many animals to breed
            int num = 0;
            int oppGender = 0;

            //get the adjacent locations, and loop through them
            List<Location> l = field.adjacentLocations(this.getLocation());
            for (int i = 0; i < l.size(); i++) {

                //check if an animal adjacent to us is the same species
                Object adj = field.getObjectAt(l.get(i));
                if (species.isInstance(adj)) {
                    //if it is, increase the counters.
                    num++;

                    //check for opposite genders to produce the amount of young to birth
                    if (this.gender.equals(Constants.Strings.MALE) && ((Animal) adj).getGender().equals(Constants.Strings.FEMALE)) {
                        oppGender++;
                    }
                    if (this.gender.equals(Constants.Strings.FEMALE) && ((Animal) adj).getGender().equals(Constants.Strings.MALE)) {
                        oppGender++;
                    }
                }
            }

            //the animal breeds with every animal of the opposite gender adjacent to it AND
            //per mate, can produce 1 to x babies
            //where x is how many babies a specific species can produce per mate
            return oppGender * rand.nextInt(num_of_young + 1);
        }
        return 0;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Organism> newAnimals) {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        //calculate how many animals to breed and then try and breed them into free locations
        int births = breed(field, this.getClass());
        for (int b = 0; b < births && free.size() > 0; b++) {
            //find a free location
            Location loc = free.remove(0);

            //create an animal - this is overridden in each of the animal classes
            Animal young = createNewAnimal(field, loc);

            //if the current animal is infected, the young is infected and cannot live as long
            if (this.getIsInfected() && rand.nextDouble() <= Constants.Game.CHILD_CARRIES_DISEASE) {
                young.setIsInfected();
                young.setMaxAge(MAX_AGE / 2);
            }
            newAnimals.add(young);
        }
    }

    /**
     * this creates a new animal and returns it. typically overridden in the animal class so different animals can be bred
     *
     * @param field the current field
     * @param loc   the location within the field
     * @return the animal made
     */
    protected abstract Animal createNewAnimal(Field field, Location loc);

    /**
     * @return the level of food the current animal has
     */
    protected int current_food_value() {
        return foodLevel;
    }
}
