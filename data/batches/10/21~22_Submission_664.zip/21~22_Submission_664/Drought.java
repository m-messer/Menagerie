import java.util.Random;
import java.util.List;

/**
 * The Drought class represents a drought weather system
 * in the simulation. 
 * 
 * Drought effects the rate at which plants grow when the 
 * weather system is active. 
 *
 * @version 18-02-2022
 */
public class Drought extends WeatherSystem
{
    // Track the intensity of the drought.
    private int intensity;
    
    /**
     * Construct the Drought system with default settings.
     * By default, the Drought system is inactive. 
     */
    public Drought()
    {
        super(false, 0);
    }

    /**
     * Construct the Drought system with specific settings.
     * 
     * @param weatherActive Set to true to activate weather system
     * @param duration Set the length of time the weather system will last. 
     */
    public Drought(boolean weatherActive, int duration)
    {
        super(weatherActive, duration);
        if (weatherActive == true)
        {
            generateIntensity();
        }
    }
    
    /**
     * Return the intensity of the drought. Ranges between
     * 1 - 3. 
     * @return The intensity of the drought. 
     */
    public int getIntensity()
    {
        return intensity;
    }
    
    /**
     * Set the intensity of drought. Must be between 1 - 3.
     * @param intensity The intensity of the drought. 
     */
    private void setIntensity(int intensity)
    {
        if (intensity < 1 || intensity > 3)
        {
            intensity = 1; 
        }
        
        this.intensity = intensity;
    }
    
    /**
     * Generate the intensity of the drought. 1 is low
     * intensity, 2 is medium intensity, and 3 is high intensity.
     */
    private void generateIntensity()
    {
        Random rand = new Random();
        intensity = rand.nextInt(3);
    }
    
    /**
     * Simulate the impact of the weather system on plants. 
     * @return The multipler value caused by the weather system. 
     */
    @Override
    public double effectPlants()
    {
        double multiplier = 1.0; 
        generateIntensity();
        
        if (getIntensity() == 1)
        {
            multiplier = 0.75;
        }
        else if (getIntensity() == 2)
        {
            multiplier = 0.5;
        }
        else if (getIntensity() == 3)
        {
            multiplier = 0.25;
        }
        
        return multiplier;
    }
    
    /**
     * Simulate the impact of the weather system on actors.
     * @param newActors The list of actors affected by the weather system. 
     * @param weatherSystem The current weather system. 
     * @return The new list of actors affected by the weather system. 
     */
    @Override
    public List<Actor> effectActors(List<Actor> newActors, WeatherSystem weatherSystem)
    {
        return newActors;
    }
}
