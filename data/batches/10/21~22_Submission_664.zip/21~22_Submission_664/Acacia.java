import java.util.List;
import java.util.ArrayList;
import java.util.Random;
 
/**
* This class represents an acacia plant in the
 * simulation. 
 * 
 * An acacia plant can reproduce new seedlings when 
 * there are free spaces in the field, and the plant
 * has reached pollination age. 
 *
* @version 15/02/2022
*/
public class Acacia extends Edible
{
    // Plant characteristics
    private static final int POLLINATION_AGE = 2;
    private static final double POLLINATION_PROBABILITY = 2.5;
    private static final int MAX_SEED_SIZE = 5;
 
    // A random number generator to control seeding.
    private static final Random rand = Randomizer.getRandom();
 
    /**
     * Create a new Acacia plant. All Acacia plants are created with age 0.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Acacia(Field field, Location location)
    {
        super(field, location);
    }
   
    /**
     * This causes an Acacia plant to reproduce new seedlings when
     * the Acacia plant has reached its pollination age.
     *
     * @param newPlants A list to return new plants.
     * @param weatherEffect The effect the weather has on the plant.
     */
    @Override
    public void act(List<Actor> newPlants, double weatherEffect)
    {
        super.incrementAge();
        if(isAlive()) {
            pollinate(newPlants, weatherEffect);           
        }
    }
   
    /**
     * Return the pollination age of the plant.
     * @return The pollination age.
     */
    @Override
    protected int getPollinationAge()
    {
        return POLLINATION_AGE;
    }
   
    /**
     * Return the plant's pollination probability.
     * @return The pollination probability.
     */
    @Override
    protected double getPollinationProbability()
    {
        return POLLINATION_PROBABILITY;
    }
   
    /**
     * Return the plants's maximum seed size.
     * @return The maximum seed size.
     */
    @Override
    protected int getMaxSeedSize()
    {
        return MAX_SEED_SIZE;
    }
   
    /**
     * Return a new Acacia plant object to simulate a seedling being
     * born.
     * @return A new Acacia object.
     */
    @Override
    protected Acacia newPlant(Field field, Location loc)
    {
        return new Acacia(field, loc);
    }
}