import java.util.List;

/**
 * This Seasons class represents the different seasons in the simulator.
 * 
 * Different seasons effect how often different weather systems are
 * generated. The season in the simulation initally starts in Spring. 
 *
 * @version 2022.02.19
 */
public class Seasons
{
    // Link to the weather generator.
    private WeatherGenerator weatherGen;
    // A place to store a new weather system.
    private WeatherSystem weatherSystem; 
    // The default weather if no weather system is in place. 
    private static final String DEFAULT_WEATHER_NAME = "Sunny";
    // Field to keep track of the season. 
    private int season;         // Spring (0), Summer (1),Autumn (2), Winter (3)
    // The name of the current season.
    private String seasonName;
    // The default season - set to Spring. 
    private static final int DEFAULT_SEASON = 0; 

    /**
     * Construct a new Season. Initally start the season in the default 
     * season. 
     */
    public Seasons()
    {
        this(DEFAULT_SEASON);
    }
    
    /**
     * Construct a new Season and specify the starting season.
     * @param season The starting season: Spring (0), Summer (1),Autumn (2), Winter (3)
     */
    public Seasons(int season)
    {
        weatherGen = new WeatherGenerator();
        weatherSystem = weatherGen.generateWeather();
        this.season = season - 1; // minus 1 because setSeason changes the season on step 0
    }
    
    /**
     * Determines the current season and whether there is a weather
     * system active. If there is a weather system active, this affects
     * the simulation.
     * For instance, more rainfall will cause plants to grow at a higher
     * rate. 
     * @param steps The current number of steps in the simulation.
     * @return The percentage the weather affects the system.
     */
    public double effectPlants()
    {
        double weatherEffect = 1.0;

        if (weatherSystem != null){
            if (weatherSystem.isActive()){
                weatherEffect = weatherSystem.effectPlants();
                weatherSystem.decreaseDuration();
            } else {
                weatherSystem = null;
            }
        }

        if (weatherSystem == null) {
            weatherSystem = weatherGen.generateWeather();
        }

        return weatherEffect;
    }
    
    /**
     * Simulate the impact of the weather system on actors.
     * @param newActors The list of actors affected by the weather system. 
     * @param weatherSystem The current weather system. 
     * @return The new list of actors affected by the weather system. 
     */
    public List<Actor> effectActors(List<Actor> newActors)
    {
        if (weatherSystem == null)
        {
            return newActors; 
        }
        return weatherSystem.effectActors(newActors, weatherSystem);
    }
    
    // Methods related to seasons
    /**
     * Set the season based on the current number of steps.
     * Different seasons effect how often different weather 
     * systems are created. 
     * For instance, higher probability of rainfall during
     * the winter season. 
     * @param steps The current number of steps in the simulation. 
     */
    public void setSeason(int steps)
    {
        int day = (steps % 1095);
        boolean seasonHasChanged = false; 
        
        if (day == 0 || day == 276 || day == 552 || day == 825){
            seasonHasChanged = true;
            changeSeason(seasonHasChanged);
        }
        
        // Set the seasonal effect based on the current season.
        if (day <= 275){
            setMultipler(season);
        }
        else if (day > 275 && day <= 551){
            setMultipler(season);
        }
        else if (day > 551 && day <= 824){
            setMultipler(season);
        }
        else if (day > 824 && day <= 1095){
            setMultipler(season);
        } 
    }

    /**
     * Change the season if the season has changed.
     * @param seasonHasChanged Has the season changed. 
     * @return True if the season has changed, false otherwise. 
     */
    private boolean changeSeason(boolean seasonHasChanged)
    {
        if (seasonHasChanged)
        {
            season++; 
            season = ((season) % 4);
            seasonHasChanged = false;
            return true;
        }
        return false; 
    }

    /**
     * Set the multiplier values in the weather generator 
     * depending on the season.
     * @param season The current season. 
     */
    private void setMultipler(int season)
    {
        if (season == 0){
            setSeasonName("Spring");
            setMultiplier(0.68, 0.05, 0.03);
        }
        else if (season == 1){
            setSeasonName("Summer");
            setMultiplier(0.2, 1.5, 0.01);
        }
        else if (season == 2){
            setSeasonName("Autumn");
            setMultiplier(1.1, 0.4, 0.05);
        }
        else if (season == 3){
            setSeasonName("Winter");
            setMultiplier(1.5, 0.02, 0.07); 
        }
    }

    /**
     * Set the name of the current season.
     * @param seasonName The current season name. 
     */
    public void setSeasonName(String seasonName)
    {
        this.seasonName = seasonName;
    }
    
    /**
     * Return the name of the current season.
     * @return The name of the season. 
     */
    public String getSeasonName()
    {
        return seasonName;
    }
    
    /**
     * Set the multiplier values in the weather generator.
     * 
     * @param rainfall The value for the rainfall multiplier.
     * @param drought The value for the drought multiplier.
     * @param thunderstorm The value for the thunderstorm multiplier.
     */
    private void setMultiplier(double rainfall, double drought, double thunderstorm)
    {
        weatherGen.setRainfallMultiplier(rainfall);
        weatherGen.setDroughtMultiplier(drought);
        weatherGen.setThunderstormMultiplier(thunderstorm);
    }
    
    // Methods related to the weather system
    /**
     * Return the current weather system object active in the simulation.
     * @return The active weather system. 
     */
    public WeatherSystem getWeatherSystem(){
        return weatherSystem;
    }
    
    /**
     * Check if there is an active weather system. 
     * @param weatherSystem The weather system to be tested. 
     * @return True us there is an active weather system, false otherwise. 
     */
    private boolean hasWeather(WeatherSystem weatherSystem)
    {
        if (weatherSystem != null)
        {
            return true;
        }
        return false;
    }
    
    /**
     * Return the name of the current weather system. 
     * @return The name of the weather system. 
     */
    public String getWeatherSystemName()
    {
        if (weatherSystem == null){
            return DEFAULT_WEATHER_NAME;
        }
        return weatherSystem.getClass().getName();
    }
    
    /**
     * Reset the seasons in the simulation. 
     */
    public void reset(int initialSeasonNumber)
    {
        weatherSystem = null;
        season = initialSeasonNumber;
        setSeason(1);
    }
}
