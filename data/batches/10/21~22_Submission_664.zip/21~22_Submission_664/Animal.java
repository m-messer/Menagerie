import java.util.List;
import java.util.Random;

/**
 * This class represents an animal in the simulation.
 * 
 * An animal can move around, hunt, and give birth to new young. 
 * The animal live to a certain age limit before they die. Eating 
 * another animal increases an animal's food level. If the food level
 * reaches zero, the animal dies.
 * Animal's have genders and only female animals can breed new young when
 * opposite genders of the same species metts. 
 *
 * @version 2022.02.15
 */
public abstract class Animal implements Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's age
    private int age; 
    // The animal's gender (true = female, false = male)
    private boolean gender; 

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        age = 0;
        gender = generateGender(); 
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param weatherEffect The current effect the weather has on the animal. 
     */
    abstract public void act(List<Actor> newAnimals, double weatherEffect);

    /**
     * Generate a new gender. True is female, false is male.
     * 
     * @return The gender of the animal. 
     * 
     */
    private boolean generateGender()
    {
        return rand.nextBoolean();
    }

    /**
     * Return an animal's gender.
     * 
     * @return True if female, false if male. 
     */
    protected boolean getGender()
    {
        return gender; 
    }

    /**
     * Set the age of the animal to the specified value.
     * @param newAge The new age of the animal. 
     */
    protected void setAge(int newAge)
    {
        this.age = newAge;
    }

    /**
     * Return the age of the animal.
     * @return The age of the animal. 
     */
    protected int getAge()
    {
        return this.age; 
    }

    /**
     * Increase the age.
     * This could result in an animals's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Check whether the animal is active or not.
     * @return true if the animal is still active.
     */
    @Override
    public boolean isActive()
    {
        return isAlive();
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    // Animal characteristics related to breeding 
    /**
     * Return the breeding age of the animal. 
     * @return The breeding age.
     */
    abstract protected int getBreedingAge();

    /**
     * Return the maximum age the animal will live. 
     * @return The maximum age. 
     */
    abstract protected int getMaxAge(); 

    /**
     * Return the animal's breeding probability.
     * @return The breeding probability. 
     */
    abstract protected double getBreedingProbability();

    /**
     * Return the animal's maximum litter size.
     * @return The maximum litter size. 
     */
    abstract protected int getMaxLitterSize();

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param animal A list to add newly born animals.
     */
    protected void giveBirth(List<Actor> animal)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);

            Animal young = newAnimal(field, loc); 
            animal.add(young); 
        }
    }

    /**
     * Make animals in neighbouring spaces meet. Used for female animals
     * to meet male animals. Only animals of the same species can meet. 
     * @param femaleAnimal The object of the female animal. 
     * @return True if the neighbouring animal is male, false otherwise. 
     */
    protected boolean meet(Animal femaleAnimal)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());

        String femaleAnimalClassName = femaleAnimal.getClass().getName();

        for(Location loc : adjacent) {
            // get object and check the gender
            Object actor = field.getObjectAt(loc);
            if (actor instanceof Animal)
            {
                String animalClassName = field.getObjectAt(loc).getClass().getName();

                if (animalClassName.equals(femaleAnimalClassName))
                {
                    Animal neighbourAnimal = (Animal) actor;
                    boolean objectIsFemale = neighbourAnimal.getGender();
                    if (!objectIsFemale)
                    {
                        return true;
                    } 
                }
            }
        }
        return false; 
    }

    /**
     * Return a new animal object to simulate a young animal being
     * born.
     * @param field The simulator field.
     * @param loc The location to place the new young. 
     * @return A new animal object. 
     */
    abstract protected Animal newAnimal(Field field, Location loc); 
}
