import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * This class generates the population of actors within the simulator 
 * and defines the pixel colours of each actor in the simulation.
 *
 * @version 2022.02.10
 */
public class PopulationGenerator
{    
    // The probability that an actor will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.05;           
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.09;       
    private static final double GAZELLE_CREATION_PROBABILITY = 0.12;      
    private static final double HYENA_CREATION_PROBABILITY = 0.05;      
    private static final double ACACIA_CREATION_PROBABILITY = 0.15;     
    private static final double OLEANDER_CREATION_PROBABILITY = 0.01;

    // List of actors and drawable actors in the field.
    private List<Actor> actors;
    private List<Drawable> drawables;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current state of the field.
    private Field field;    

    /**
     * Constructor to generate the actor population in the simulator.
     * @param depth The field depth.
     * @param width The field width.
     */
    public PopulationGenerator(int depth, int width)
    {
        actors = new ArrayList<>();
        drawables = new ArrayList<>();
        field = new Field(depth, width); 

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        setDrawableActorColors();
    }

    /**
     * Set the pixel colour for each of the drawable character. This
     * color will appear in the simulator GUI for the actor specified. 
     */
    private void setDrawableActorColors()
    {
        view.setColor(Lion.class, Color.red.darker());
        view.setColor(Hyena.class, Color.orange.darker());
        view.setColor(Gazelle.class, Color.yellow.darker());
        view.setColor(Giraffe.class, Color.ORANGE);
        view.setColor(Hunter.class, Color.green.darker());
        view.setColor(Tourist.class, Color.cyan.darker());
    }

    /**
     * Randomly populate the field with actors.
     * @param step The current step in the simulation.
     * @param seasonName The current season's name.
     * @param weatherSystemName The current weather system's name.
     */
    public void populate(int step, String seasonName, String weatherSystemName)
    {
        field.clear();
        Random rand = Randomizer.getRandom();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    actors.add(lion);
                    drawables.add(lion);
                }
                else if(rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Giraffe giraffe = new Giraffe(true, field, location);
                    actors.add(giraffe);
                    drawables.add(giraffe);
                }
                else if(rand.nextDouble() <= GAZELLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Gazelle gazelle = new Gazelle(true, field, location);
                    actors.add(gazelle);
                    drawables.add(gazelle);
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(true, field, location);
                    actors.add(hyena);
                    drawables.add(hyena);
                }
                else if(rand.nextDouble() <= OLEANDER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Oleander oleander = new Oleander(field, location);
                    actors.add(oleander);
                }
                else if(rand.nextDouble() <= ACACIA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Acacia acacia = new Acacia(field, location);
                    actors.add(acacia);
                }
            }
        }

        showFieldDetails(step, seasonName, weatherSystemName);
    }

    /**
     * Show the simulator details in the simulator GUI.
     * @param step The current number of steps.
     * @param seasonName The current name of the season. 
     * @param weatherSystemName The name of the active weather system. 
     */
    public void showFieldDetails(int step, String seasonName, String weatherSystemName)
    {        
        view.showStatus(step, seasonName, weatherSystemName, field);
    }

    /**
     * Retieve the stats value from all actors and update stats map. 
     */
    public void retrieveStats()
    {
        view.retrieveStats(actors);
    }

    /**
     * Reset the simulation to a starting position.
     * @param seasonName The current season's name.
     * @param weatherSystemName The current weather system's name.
     */
    public void reset(String seasonName, String weatherSystemName)
    {
        actors.clear();
        drawables.clear(); 
        view.reset();
        populate(0, seasonName, weatherSystemName);
    }

    /**
     * Determine whether the simulation is still viable.
     * I.e., should it continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable()
    {
        return view.isViable(field); 
    }

    /**
     * Return the list of actors in the simulator. 
     * @return The list of active actors in the simulation. 
     */
    public List<Actor> getActorList()
    {
        return actors;
    }

    /**
     * Set the actor's list in the simulator. This updates the actors
     * List, and adds new actors into the simulator.
     * @param newActors Actors to be added to the simulator. 
     */
    public void setActorList(List<Actor> newActor)
    {
        actors.addAll(newActor); 
    }

    /**
     * Return the list of drawable actors in the simulator.
     * @return The drawable actors in the simulator. 
     */
    public List<Drawable> getDrawableList()
    {
        return drawables;    
    }

    /**
     * Checks whether an actor is drawable.
     * @param actor An actor in the simulation
     * @return True if the actor is drawable, false otherwise.
     */
    public boolean isDrawable(Actor actor)
    {
        return drawables.contains(actor);
    }

    /**
     * Return the simulator field.
     * @return The field object of the simulator. 
     */
    public Field getField()
    {
        return field; 
    }
}
