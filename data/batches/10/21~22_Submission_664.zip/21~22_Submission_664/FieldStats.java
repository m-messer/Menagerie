import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/**
 * This class collects and provides some statistical data on the state 
 * of a field. It is flexible: it will create and maintain a counter 
 * for any class of object that is found within the field.
 *
 * @version 2016.02.29
 */
public class FieldStats
{
    // Counters for each type of entity in the simulation.
    private HashMap<Class, Counter> counters;
    // Whether the counters are currently up to date.
    private boolean countsValid;
    // Create new map to store stats
    private HashMap<String, Integer> statsMap; 
    private int hunterStats;
    private int touristStats;

    /**
     * Construct a FieldStats object.
     */
    public FieldStats()
    {
        // Set up a collection for counters for each type of animal that
        // we might find
        counters = new HashMap<>();
        countsValid = true;
        statsMap = new HashMap<>();
    }

    /**
     * Get details of what is in the field.
     * @return A string describing what is in the field.
     */
    public String getPopulationDetails(Field field)
    {
        StringBuffer buffer = new StringBuffer();
        if(!countsValid) {
            generateCounts(field);
        }
        for(Class key : counters.keySet()) {
            Counter info = counters.get(key);
            buffer.append(info.getName());
            buffer.append(": ");
            buffer.append(info.getCount());
            buffer.append(' ');
        }
        return buffer.toString();
    }

    /**
     * Invalidate the current set of statistics; reset all 
     * counts to zero.
     */
    public void reset()
    {
        countsValid = false;
        for(Class key : counters.keySet()) {
            Counter count = counters.get(key);
            count.reset();
        }
    }

    /**
     * Increment the count for one class of animal.
     * @param animalClass The class of animal to increment.
     */
    public void incrementCount(Class animalClass)
    {
        Counter count = counters.get(animalClass);
        if(count == null) {
            // We do not have a counter for this species yet.
            // Create one.
            count = new Counter(animalClass.getName());
            counters.put(animalClass, count);
        }
        count.increment();
    }

    /**
     * Indicate that an animal count has been completed.
     */
    public void countFinished()
    {
        countsValid = true;
    }

    /**
     * Determine whether the simulation is still viable.
     * I.e., should it continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        // How many counts are non-zero.
        int nonZero = 0;
        if(!countsValid) {
            generateCounts(field);
        }
        for(Class key : counters.keySet()) {
            Counter info = counters.get(key);
            if(info.getCount() > 0) {
                nonZero++;
            }
        }
        return nonZero > 1;
    }

    /**
     * Generate counts of the number of animals.
     * These are not kept up to date as animals
     * are placed in the field, but only when a request
     * is made for the information.
     * @param field The field to generate the stats for.
     */
    private void generateCounts(Field field)
    {
        reset();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    incrementCount(animal.getClass());
                }
            }
        }
        countsValid = true;
    }
    
    /**
     * Return the stats tracked by the actors.
     * @return All the actor's stats.
     */
    public Map<String, Integer> getStats()
    {
        return statsMap; 
    }

    /**
     * Retieve the stats value from all actors and update stats map. 
     * @param actorList The list of actors in the simulation. 
     */
    public void retrieveStats(List actorList)
    {
        for(Object actor : actorList){
            if (actor instanceof Human){                
                String actorName = actor.getClass().getName();
                Human human = (Human) actor;
                if (statsMap.containsKey(actorName)){
                    int newStat = statsMap.get(actorName) + human.getStats(); 
                    statsMap.put(actorName, newStat);
                }
                else {
                    statsMap.put(actorName, human.getStats());
                }
                setStats();
            }
        }
    }
    
    /**
     * Set the stats counters for the simulation.
     */
    private void setStats()
    {
        for (String key : statsMap.keySet()){
            if (key.equals("Hunter")){
                hunterStats = statsMap.get(key);
            }
            else if (key.equals("Tourist")){
                touristStats = statsMap.get(key);
            }
        }
    }
    
    /**
     * Get the hunterStats integer value.
     * @return The hunterStats integer value.
     */
    public String getHunterStats()
    {
        return hunterStats + "";
    }
    
    /**
     * Get the touristStats integer value.
     * @return The touristStats integer value.
     */
    public String getTouristStats()
    {
        return touristStats + "";
    }
}
