import java.util.List;
import java.util.ArrayList; 
import java.util.Iterator;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing safari animals.
 * A day in the simulator is represented by 3 steps. 
 *
 * @version 2022.02.10
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width and depth for the grid.
    private static final int DEFAULT_WIDTH = 90;
    private static final int DEFAULT_DEPTH = 50;
    // The current step of the simulation.
    private int step;
    // Field to hold the effect of certain weather conditions
    private double weatherEffect;
    // Field to hold the name and number of the starting season
    private String initialSeason; 
    private int initialSeasonNumber;
    // Link classes required for the simulation
    private PopulationGenerator population;             
    private ActorRegenerator actorRegen;
    private Seasons season;

    /**
     * Construct a simulation field with default size.
     * Default starting season set to Spring. 
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH, 0);
    }

    /**
     * Create a simulation field with the given size, and specified
     * starting season.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * @param startSeason Can be: Spring(0), Summer(1), Autumn(2), Winter(3)
     */
    public Simulator(int depth, int width, int startSeason)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        // Setup field with the population of actors
        population = new PopulationGenerator(depth, width);
        // Initalise the actor regenerator and seasons
        actorRegen = new ActorRegenerator();
        if (startSeason < 0 || startSeason > 3)
        {
            System.out.println("Invalid season. Season set to default.");
            startSeason = 0;        // default is spring
        }
        season = new Seasons(startSeason);
        setInitialSeason(startSeason);

        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Create a simulation field with the default size, and specified
     * starting season.
     * @param startSeason Can be: Spring(0), Summer(1), Autumn(2), Winter(3)
     */
    public Simulator(int startSeason)
    {
        // Setup field with the population of actors
        population = new PopulationGenerator(DEFAULT_DEPTH, DEFAULT_WIDTH);
        // Initalise the actor regenerator and seasons
        actorRegen = new ActorRegenerator();
        if (startSeason < 0 || startSeason > 3)
        {
            System.out.println("Invalid season. Season set to default.");
            startSeason = 0;        // default is spring
        }
        season = new Seasons(startSeason);
        setInitialSeason(startSeason);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * One step represents one period of time during the day.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && population.isViable(); step++) {
            simulateOneStep();
        }
    }
    
    /**
     * Run the simulation from its current state for the given number of steps, with
     * delay between steps.
     * One step represents one period of time during the day.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    private void simulateWithDelay(int numSteps)
    {
        for(int step = 1; step <= numSteps && population.isViable(); step++) {
            simulateOneStep();
            delay(300);
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * A single step represents a time of day (Morning, Afternoon, Evening)
     * Iterate over the whole field updating the state of each actor.
     */
    private void simulateOneStep()
    {
        step++;
        
        season.setSeason(step);
        weatherEffect = season.effectPlants();

        if (!((step % 3) == 2)){ // Actors do not act during the night
            // Provide space for new actors.
            List<Actor> newActors = new ArrayList<>();        
            // Let all actors act.
            List<Actor> regenActor = actorRegen.regenerate(population.getField(), getActorList());

            for(Iterator<Actor> it = regenActor.iterator(); it.hasNext(); ) {
                Actor actor = it.next();
                actor.act(newActors, weatherEffect);
                if(! actor.isActive()) {
                    it.remove();
                }

                if (actor.isActive() && population.isDrawable(actor))
                {
                    Drawable drawActor = (Drawable) actor;
                    drawActor.draw();
                }
            }

            // Add the new actors to the main lists.
            setActorList(newActors);
        }

        season.effectActors(getActorList());
        
        population.retrieveStats();
        population.showFieldDetails(step, season.getSeasonName(), season.getWeatherSystemName()); 
    }
    
    /**
     * Run the simulation for one day worth of steps with a delay 
     * between steps.
     */
    public void simulateOneDay()
    {
        simulateWithDelay(3);
    }
    
    /**
     * Run the simulation for one year worth of steps.
     */
    public void simulateOneYear()
    {
        simulate(1095);
    }
    
    /**
     * Run the simulation for two years worth of steps. 
     */
    public void simulateTwoYears()
    {
        simulate(2190);
    }

    /**
     * Return the list of actors in the simulator. 
     * @return The list of active actors in the simulation. 
     */
    private List<Actor> getActorList()
    {
        return population.getActorList();    
    }

    /**
     * Set the actor's list in the simulator. This updates the actors
     * list, and adds new actors into the simulator.
     * @param newActors List of actors to be added into the simulator. 
     */
    private void setActorList(List<Actor> newActors)
    {
        population.setActorList(newActors); 
    }

    /**
     * Return the intial starting season.
     * @return The initial starting season of the simulation. 
     */
    private int getInitialSeasonNumber()
    {
        return initialSeasonNumber;
    }
    
    /**
     * Set the initial season number to the given season number.
     * @param initialSeasonNumber The initial starting season of the simulator. 
     */
    private void setInitialSeasonNumber(int initialSeasonNumber)
    {
        this.initialSeasonNumber = initialSeasonNumber; 
    }
    
    /**
     * Return the name of the initial starting season.
     * @return The name of the starting season. 
     */
    private String getInitialSeason()
    {
        return initialSeason;
    }
    
    /**
     * Set the name of the initial season field depending on the
     * starting season.
     * @param initialSeasonNumber The integer of the starting season. Can choose
     * Spring(0), Summer(1), Autmumn(2), or Winter(3)
     */
    private void setInitialSeason(int initialSeasonNumber)
    {
        setInitialSeasonNumber(initialSeasonNumber);
        if (getInitialSeasonNumber() == 0){
            initialSeason = "Spring";
        }
        else if (getInitialSeasonNumber() == 1){
            initialSeason = "Summer";
        }
        else if (getInitialSeasonNumber() == 2){
            initialSeason = "Autumn";
        }
        else if (getInitialSeasonNumber() == 3){
            initialSeason = "Winter";
        }
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        weatherEffect = 1.0;
        season.reset(getInitialSeasonNumber());
        population.reset(getInitialSeason(), season.getWeatherSystemName());
    }
    
    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}