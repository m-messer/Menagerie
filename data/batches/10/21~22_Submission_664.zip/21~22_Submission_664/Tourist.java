import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class represents a tourist in the simulation.
 * 
 * A tourists visits the safari and takes pictures of 
 * animals. Tourists can be eaten by lions. 
 *
 * @version 15-02-2022
 */
public class Tourist extends Human implements Drawable
{
    // The steps for which a tourist stays in the safari.
    private static final int MAX_STAY = 15;
    // The respawn probability
    private static final double RESPAWN_PROBABILITY = 0.04;
    // Field to track the number of photos taken 
    private int photos; 

    /**
     * Create a tourist and place the tourist into the field at
     * the given location. 
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tourist(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Draw the actor in the simulator.
     */
    @Override
    public void draw(){
        // currently does nothing
    }
    
    /**
     * This is what the tourist does most of the time: takes pictures
     * of animals, and move into free adjacent spaces. 
     * 
     * @param newhumans A list to receive newly regenerated humans.
     * @param weatherEffect The effect the weather has on the human.
     */
    @Override
    public void act(List<Actor> newHumans, double weatherEffect)
    {
        super.incrementAge();
        if(isActive()) {        
            respawn(newHumans); 
            takePhotos();
            
            Location newLocation = move();
            if(newLocation == null) { 
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setInactive();
            }
        }
    }
    
    /**
     * Move into the next free adjacent space in the field. 
     * @return Where the next free adjacent space is, or null if it there isn't.
     */
    private Location move()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            return where; 
        }
        return null;
    }

    /**
     * Take photos of neighbouring animals.
     */
    private void takePhotos()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());

        for(Location loc : adjacent) {
            Object actor = field.getObjectAt(loc);
            if (actor instanceof Animal)
            {
                photos++;
                //System.out.println(photos + " taken"); 
            }
        }
    }
    
    /**
     * Return the maximum number of steps the tourist will stay in the 
     * safari.
     * @return The maximum number of steps.
     */
    @Override
    protected int getMaxStay()
    {
        return MAX_STAY; 
    }

    /**
     * Return the probabiltiy of a tourist being regenerated.
     * @return The probability a tourist will be regenerated. 
     */
    @Override
    protected double getRespawnProbability()
    {
        return RESPAWN_PROBABILITY;
    }
    
    /**
     * Return the stats related to this tourist object.
     * @return The stats related to this object. 
     */
    public int getStats()
    {
        return photos;
    }
    
    /**
     * Return a new tourist object to simulate a tourist arriving at the
     * safari. 
     * @param field The simulator field.
     * @param loc The location to place the new human. 
     * @return A new tourist object. 
     */
    @Override
    protected Tourist newHuman(Field field, Location loc)
    {
        return new Tourist(field, loc); 
    }
}
