import java.util.Random; 
import java.util.List;
import java.util.ArrayList;

/**
 * This class represents a plant in the simulation.
 * 
 * A plant can be eaten by other animals, and can reproduce
 * seedlings. Additionally, weather conditions can cause a plant
 * to die, or produce less seedlings.  
 * All plants start with an inital age of 0 at the start of
 * the simulation. 
 *
 * @version 10/02/2022
 */
public abstract class Plant extends ActorRegenerator implements Actor
{
    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // The plant's age
    private int age; 

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new plant at given location in the field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        age = 0; 
    }

    /**
     * Plants act and mainly reproduce seedlings. 
     * 
     * @param newPlants A list to receive newly born seedlings.
     * @param weatherEffect The effect the weather has on the plant. 
     */
    abstract public void act(List<Actor> newPlants, double weatherEffect);

    /**
     * Return the age of the plant.
     * @return The age of the plant. 
     */
    protected int getAge()
    {
        return this.age; 
    }

    /**
     * Increase the age of the plant.
     */
    protected void incrementAge()
    {
        age++;
    }

    /**
     * Check whether the plant is active or not.
     * @return true if the plant is still active.
     */
    @Override
    public boolean isActive()
    {
        return isAlive();
    }

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }

    // Plant characteristics related to breeding 
    /**
     * Return the pollination age of the plant. 
     * @return The pollination age.
     */
    abstract protected int getPollinationAge();

    /**
     * Return the plant's pollination probability.
     * @return The pollination probability. 
     */
    abstract protected double getPollinationProbability();

    /**
     * Return the plant's maximum seed size.
     * @return The maximum seed size. 
     */
    abstract protected int getMaxSeedSize();

    /**
     * A plant can reproduce if it has reached the pollination age.
     * @return True if the plant can reproduce, False otherwise.
     */
    protected boolean canReproduce()
    {
        return age >= getPollinationAge();
    }

    /**
     * Generate a number representing the number of seeds,
     * if it can reproduce.
     * @param weatherEffect The effect the weather has on the plant. 
     * @return The number of seeds (may be zero).
     */
    protected int reproduce(double weatherEffect)
    {
        int seeds = 0;

        if(canReproduce() && rand.nextDouble() <= weatherEffect * getPollinationProbability()) {
            seeds = rand.nextInt(getMaxSeedSize()) + 1;
        }
        return seeds;
    }

    /**
     * Check whether or not the plant is to produce new seeds.
     * New plants will be made into free adjacent locations.
     * @param plantList A list to add new plants.
     * @param weatherEffect The effect the weather has on the plant. 
     */
    protected void pollinate(List<Actor> plantList, double weatherEffect)
    {
        int seeds = reproduce(weatherEffect);
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        for(int s = 0; s < seeds && free.size() > 0; s++) {
            Location loc = free.remove(0);

            Plant seedling = newPlant(field, loc); 
            plantList.add(seedling); 
        }
    }

    /**
     * Return a new plant object to simulate a seedling being
     * born.
     * @return A new plant object. 
     */
    abstract protected Plant newPlant(Field field, Location loc); 
}
