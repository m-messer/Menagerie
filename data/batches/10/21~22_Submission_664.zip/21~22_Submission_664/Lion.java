import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing a Lion in the simulator.
 * 
 * A lion can hunt, breed, and give birth to new young.
 * A lion can hunt gazelles, giraffes, and tourists. Hunting
 * one of these species will increase the Lion's food level.
 *
 * @version 2022.02.15
 */
public class Lion extends Predator implements Drawable
{
    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 10;
    // Maximum age a lion can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The probability a lion's hunt will be successfull
    private static final double HUNT_SUCCESS_PROBABILITY = 0.38;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single prey. 
    private static final int PREY_FOOD_VALUE = 15;
    // The food value of a single tourist.
    private static final int TOURIST_FOOD_VALUE = 9;
    // The lion's food level.
    private int foodLevel;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            foodLevel = rand.nextInt(MAX_AGE);
        }
        else {
            super.setAge(0);
            foodLevel = MAX_AGE;
        }
    }

    /**
     * Draw the actor in the simulator. 
     */
    @Override
    public void draw(){
        // currently does nothing
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * gazelles, giraffes, and tourists. In the process, 
     * it might breed, die of hunger, or die of old age.
     * @param newLions A list to return newly born lions.
     * @param weatherEffect The current effect the weather has on the animal. 
     */
    @Override
    public void act(List<Actor> newLions, double weatherEffect)
    {
        super.incrementAge();
        incrementHunger();
        if(isActive()) {
            if (super.getGender() && meet(this)){
                giveBirth(newLions); 
            } 

            Location newLocation = null;
            newLocation = findFood();      
            
            // Move towards a source of food if found.
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * If under the hunt probability, only the first live 
     * animal or tourist is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);

            Random rand = new Random();
            if (!(rand.nextDouble() < HUNT_SUCCESS_PROBABILITY))
            {
                return null;
            }

            if(actor instanceof Prey) {
                Prey prey = (Prey) actor;
                if(prey.isActive()) { 
                    prey.setDead();
                    foodLevel = this.foodLevel + PREY_FOOD_VALUE;
                    return where;
                }
            }

            if(actor instanceof Tourist) {
                Tourist tourist = (Tourist) actor;
                if(tourist.isActive()) { 
                    tourist.setInactive();
                    foodLevel = this.foodLevel + TOURIST_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Return the breeding age of the lion. 
     * @return The breeding age.
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the maximum age the lion will live. 
     * @return The maximum age. 
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE; 
    }

    /**
     * Return the lion's breeding probability.
     * @return The breeding probability. 
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the lion's maximum litter size.
     * @return The maximum litter size. 
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return a new lion object to simulate a young lion being
     * born.
     * @param field The simulator field.
     * @param loc The location to place the new young. 
     * @return A new lion object. 
     */
    @Override
    protected Lion newAnimal(Field field, Location loc)
    {
        return new Lion(false, field, loc); 
    }
}
