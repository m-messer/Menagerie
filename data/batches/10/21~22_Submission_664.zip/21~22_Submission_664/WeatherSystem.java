import java.util.List;

/**
 * This class represents different weather systems
 * in the simulation.
 * 
 * The simulation have various types of weather systems, such as 
 * rainfall, drought, and thunderstorms. These weather systems 
 * change over time. 
 *
 * @version 18-02-2022
 */
public abstract class WeatherSystem
{    
    // Track the weather system is active.
    private boolean active;
    // Track the duration of the weather system. 
    private int duration; 
    
    /**
     * Construct a new Weather system.
     * 
     * @param active If the new weather system is active.
     * @param duration The duration of the weather system. 
     */
    public WeatherSystem(boolean active, int duration)
    {
        if (duration <= 0)
        {
            active = false;
            duration = 0; 
        }
        else {
            this.active = active;
            this.duration = duration;
        }
    }
    
    /**
     * Return if the weather system is active.
     * @return True if the weather system is active, false otherwise.  
     */
    public boolean getActive()
    {
        return active;
    }
    
    /**
     * Set the weather system to active or inactive. 
     * @param active True sets the weather system to active. 
     */
    public void setActive(boolean active)
    {
        this.active = active;
    }
    
    /**
     * Toggle the activity of the weather system so it is either
     * active or inactive. 
     */
    public void toggleActive()
    {
        this.active = !active; 
    }
    
    /**
     * Return the duration of the weather system.
     * @return The weather system duration. 
     */
    public int getDuration()
    {
        return duration;
    }
    
    /**
     * Set the duration of the weather system
     * @param duration The number of steps the weather system will endure
     * for. 
     */
    public void setDuration(int duration)
    {
        this.duration = duration;
    }
    
    /**
     * Decrease the duration of the weather system by one step. 
     */
    public void decreaseDuration()
    {
        this.duration--;
    }
    
    /**
     * Check if the weather system is currently active.
     * @return True if the weather system is active. 
     */
    public boolean isActive()
    {
        if(duration > 0)
        {
            return true;
        }
        setInactive();
        return false; 
    }
    
    /**
     * End the weather system. 
     */
    public void setInactive()
    {
        setActive(false);
        duration = 0; 
    }
    
    /**
     * Simulate the impact of the weather system on the plants.
     * @return The multipler value caused by the weather system. 
     */
    abstract public double effectPlants(); 
    
    /**
     * Simulate the impact of the weather system on the actors.
     * @param newActors The list of actors affected by the weather system. 
     * @param weatherSystem The current weather system. 
     * @return The new list of actors affected by the weather system. 
     */
    abstract public List<Actor> effectActors(List<Actor> newActors, WeatherSystem weatherSystem); 
}
