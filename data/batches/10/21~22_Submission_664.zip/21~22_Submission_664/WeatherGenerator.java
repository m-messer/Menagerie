import java.util.Random;

/**
 * The WeatherGenerator class generates new weather systems
 * in the simulator. 
 * 
 * The weather this class can generate includes rainfall, drought,
 * and thunderstorms.
 *
 * @version 18-02-2022
 */
public class WeatherGenerator
{
    // Probabilies of generating various weather systems
    private static final double RAINFALL_PROBABILITY = 0.05;
    private static final double DROUGHT_PROBABILITY = 0.03;
    private static final double THUNDERSTORM_PROBABILITY = 0.7;
    
    // The weather system multiplier that effects the probability of generating
    // the weather system. 
    private double rainfallMultiplier;
    private double droughtMultiplier;
    private double thunderstormMultiplier;

    /**
     * Construct the WeatherGenerator and prepare to create a 
     * new weather system.
     */
    public WeatherGenerator()
    {
        // currently does nothing
    }

    /**
     * Generate a new weather system. Can return null if no weather
     * system is created.
     * @return The new weather system. 
     */
    public WeatherSystem generateWeather()
    {
        Random rand = new Random();

        if (rand.nextDouble() <= RAINFALL_PROBABILITY * getRainfallMultiplier())
        {
            return new Rainfall(true, rand.nextInt(15) + 1);
        }
        else if (rand.nextDouble() <= DROUGHT_PROBABILITY * getDroughtMultiplier())
        {
            return new Drought(true, rand.nextInt(30) + 1);
        }
        else if (rand.nextDouble() <= THUNDERSTORM_PROBABILITY * getThunderstormMultiplier())
        {
            return new Thunderstorm(true, rand.nextInt(5) + 1);
        }
        return null;
    }

    /**
     * Return the rainfall multiplier.
     * @return The rainfall multiplier. 
     */
    public double getRainfallMultiplier()
    {
        return rainfallMultiplier;
    }

    /**
     * Set the rainfall multiplier. 
     * @param rainfallMultiplier The value to set the multipler. 
     */
    public void setRainfallMultiplier(double rainfallMultiplier)
    {
        this.rainfallMultiplier = rainfallMultiplier;
    }

    /**
     * Return the drought multiplier.
     * @return The drought multiplier. 
     */
    public double getDroughtMultiplier()
    {
        return droughtMultiplier;
    }

    /**
     * Set the drought multiplier. 
     * @param droughtMultiplier The value to set the multipler.
     */
    public void setDroughtMultiplier(double droughtMultiplier)
    {
        this.droughtMultiplier = droughtMultiplier;
    }

    /**
     * Return the thunderstorm multiplier.
     * @return The thunderstorm multiplier.  
     */
    public double getThunderstormMultiplier()
    {
        return thunderstormMultiplier;
    }

    /**
     * Set the thunderstorm multiplier. 
     * @param thunderstormMultiplier The value to set the multipler.
     */
    public void setThunderstormMultiplier(double thunderstormMultiplier)
    {
        this.thunderstormMultiplier = thunderstormMultiplier;
    }
}