import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of actor can be defined using the
 * setColor method.
 *
 * @version 2022.02.26
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.white;

    private final String DAY_PREFIX = "Day: ";
    private String timeOfDay = "";
    private final String YEAR_PREFIX = "Year: ";
    private int yearCounter;
    private final String SEASON_PREFIX = "Season: ";
    private final String WEATHER_PREFIX = "Weather: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String HUMAN_PREFIX = "Human Statistics: ";
    private final String HUNTER_PREFIX = "Lions Hunted: ";
    private final String TOURIST_PREFIX = "Photos Taken: ";
    private JLabel dayLabel, timeOfDayLabel, yearLabel, seasonLabel, weatherLabel, population, humanLabel, hunterLabel, touristLabel;
    private FieldView fieldView;

    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Safari Simulation");
        dayLabel = new JLabel(DAY_PREFIX, JLabel.CENTER);
        timeOfDayLabel = new JLabel(timeOfDay, JLabel.CENTER);
        yearLabel = new JLabel(YEAR_PREFIX, JLabel.CENTER);
        seasonLabel = new JLabel(SEASON_PREFIX, JLabel.CENTER);
        weatherLabel = new JLabel(WEATHER_PREFIX, JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        humanLabel = new JLabel(HUMAN_PREFIX, JLabel.CENTER);
        hunterLabel = new JLabel(HUNTER_PREFIX, JLabel.CENTER);
        touristLabel = new JLabel(TOURIST_PREFIX, JLabel.CENTER);
        
        setLocation(100, 50);

        fieldView = new FieldView(height, width);

        Container contents = getContentPane();
        contents.add(makeTopContainer(), BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(makeBottomContainer(), BorderLayout.SOUTH);
        
        pack();
        setVisible(true);
    }

    /**
     * Create the layout of the top container of the simulation.
     * @return The top container.
     */
    private Container makeTopContainer()
    {
        Container topContainerNorth = new Container();
        topContainerNorth.setLayout(new GridLayout(1,0));
        topContainerNorth.add(dayLabel);
        topContainerNorth.add(timeOfDayLabel);
        topContainerNorth.add(yearLabel);
        
        Container topContainerSouth = new Container();
        topContainerSouth.setLayout(new GridLayout(1,0));
        topContainerSouth.add(seasonLabel);
        topContainerSouth.add(weatherLabel);
        
        Container topContainer = new Container();
        topContainer.setLayout(new BorderLayout());
        topContainer.add(topContainerNorth, BorderLayout.NORTH);
        topContainer.add(topContainerSouth, BorderLayout.SOUTH);
        
        return topContainer;
    }
    
    /**
     * Create the layout of the bottom container of the simulation.
     * @return The top container.
     */
    private Container makeBottomContainer()
    {   
        Container bottomContainerSouth = new Container();
        bottomContainerSouth.setLayout(new GridLayout(1,0));
        bottomContainerSouth.add(humanLabel);
        bottomContainerSouth.add(hunterLabel);
        bottomContainerSouth.add(touristLabel);
        
        Container bottomContainer = new Container();
        bottomContainer.setLayout(new BorderLayout());
        bottomContainer.add(population, BorderLayout.NORTH);
        bottomContainer.add(bottomContainerSouth, BorderLayout.SOUTH);
        
        return bottomContainer;
    }
    
    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass)
    {
        Color col = colors.get(animalClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param seasonName The current season's name.
     * @param weatherSystemName The current weather system's name.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, String seasonName, String weatherSystemName, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }
        
        // set text to the labels
        dayLabel.setText(DAY_PREFIX + convertStepsToDays(step));
        changeTimeOfDay(step);
        timeOfDayLabel.setText(timeOfDay);
        yearLabel.setText(YEAR_PREFIX + changeYear(step));
        seasonLabel.setText(SEASON_PREFIX + seasonName);
        
        if (weatherSystemName == null){
            weatherSystemName = "Default";
        }
        weatherLabel.setText(WEATHER_PREFIX + weatherSystemName);
        stats.reset();

        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    stats.incrementCount(animal.getClass());
                    fieldView.drawMark(col, row, getColor(animal.getClass()));
                }
                else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        
        hunterLabel.setText(HUNTER_PREFIX + stats.getHunterStats());
        touristLabel.setText(TOURIST_PREFIX + stats.getTouristStats());
        
        fieldView.repaint();
    }
    
    /**
     * Retieve the stats value from all actors and update stats map. 
     * @param actorList The list of actors in the simulation. 
     */
    public void retrieveStats(List actorList)
    {
        stats.retrieveStats(actorList);
    }
    
    /**
     * Change the yearCounter to the appropriate year within the simulation.
     * @param step Which iteration step it is.
     * @return The String containing the year.
     */
    private int changeYear(int step)
    {
        if (step % 1095 == 0){
            yearCounter++;
        }
        return yearCounter - 1;
    }
    
    /**
     * Change the timeOfDay String to the appropriate time within the day.
     * @param step Which iteration step it is.
     * @return The String containing the time of day.
     */
    private String changeTimeOfDay(int step)
    {
        if (step % 3 == 0){
            return timeOfDay = "Morning";
        }
        else if (step % 3 == 1){
            return timeOfDay = "Afternoon";
        }
        else if (step % 3 == 2){
            return timeOfDay = "Evening";
        }
        return null;
    }
    
    /**
     * Converts the steps of the simulation to days.
     * @param step Which iteration step it is.
     * @return The corresponding day.
     */
    private int convertStepsToDays(int step)
    {
        return (step / 3) % 365;
    }
    
    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * Reset the simulator view to prepare the a new simulation. 
     */
    public void reset()
    {
        yearCounter = 0; 
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
