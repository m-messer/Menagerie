import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing a Giraffe in the simulator.
 * 
 * A giraffe can eat plants, breed, and give birth to new young.
 *
 * @version 2022.02.15
 */
public class Giraffe extends Prey implements Drawable
{
    // The age at which a giraffe can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a giraffe can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a giraffe breeding.
    private static final double BREEDING_PROBABILITY = 0.38;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single edible plant. 
    private static final int EDIBLE_FOOD_VALUE = 9;
    // The giraffe's food level.
    private int foodLevel;  
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a giraffe. A giraffe can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the giraffe will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Giraffe(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            foodLevel = rand.nextInt(MAX_AGE);
        }
        else {
            super.setAge(0);
            foodLevel = MAX_AGE;
        }
    }

    /**
     * Draw the actor in the simulator.
     */
    @Override
    public void draw(){
        // currently does nothing
    }
    
    /**
     * This is what the giraffe does most of the time: it looks for
     * plants. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newGiraffes A list to return newly born giraffes.
     * @param weatherEffect The current effect the weather has on the animal.
     */
    @Override
    public void act(List<Actor> newGiraffe, double weatherEffect)
    {
        super.incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (super.getGender() && meet(this)){
                giveBirth(newGiraffe); 
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            // Check if the animal has eaten a poisonous plant
            if (!isActive())
            {
                return; 
            }
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this giraffe more hungry. This could result in the giraffe's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            
            if (plant instanceof Edible){
                Edible edible = (Edible) plant;
                if (edible.isActive()){
                    edible.setDead();
                    foodLevel = EDIBLE_FOOD_VALUE;
                    return where;
                }
            }
            
            if (plant instanceof Poisonous){
                this.setDead();
                Poisonous poisonous = (Poisonous) plant;
                if (poisonous.isActive()){
                    poisonous.setDead();
                    return null;
                }
            }
        }
        return null;
    }

    /**
     * Return the breeding age of the giraffe. 
     * @return The breeding age.
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the maximum age the giraffe will live. 
     * @return The maximum age. 
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE; 
    }

    /**
     * Return the giraffe's breeding probability.
     * @return The breeding probability. 
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the giraffe's maximum litter size.
     * @return The maximum litter size. 
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return a new giraffe object to simulate a young giraffe has been
     * born.
     * @param field The simulator field.
     * @param loc The location to place the new young.
     * @return A new giraffe object. 
     */
    @Override
    protected Giraffe newAnimal(Field field, Location loc)
    {
        return new Giraffe(false, field, loc); 
    }
}
