import java.util.List;

/**
 * This class represents a predator in the simulator. 
 * 
 * A predator can hunt for prey, give birth to new young,
 * and move into different locations in the field.
 *
 * @version 20-02-2022
 */
public abstract class Predator extends Animal
{
    /**
     * Construct a new predator in the simulator and 
     * poisiton the predator in the field given a location.
     */
    public Predator(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param weatherEffect The current effect the weather has on the animal. 
     */
    abstract public void act(List<Actor> newAnimals, double weatherEffect);

    // Animal characteristics related to breeding 
    /**
     * Return the breeding age of the predator. 
     * @return The breeding age.
     */
    abstract protected int getBreedingAge();

    /**
     * Return the maximum age the predator will live. 
     * @return The maximum age. 
     */
    abstract protected int getMaxAge(); 

    /**
     * Return the predator's breeding probability.
     * @return The breeding probability. 
     */
    abstract protected double getBreedingProbability();

    /**
     * Return the predator's maximum litter size.
     * @return The maximum litter size. 
     */
    abstract protected int getMaxLitterSize();
    
    /**
     * Return a new animal object to simulate a young animal has been
     * born.
     * @param field The simulator field.
     * @param loc The location to place the new young. 
     * @return A new animal object. 
     */
    abstract protected Animal newAnimal(Field field, Location loc); 
}
