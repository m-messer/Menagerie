import java.util.List;

/**
 * The interface to be extended by any actor wishing 
 * to be shown in the simulation.
 *
 * @version 10/02/2022
 */
public interface Drawable
{
    /**
     * Draw an actor in the simulation 
     */
    void draw();
}
