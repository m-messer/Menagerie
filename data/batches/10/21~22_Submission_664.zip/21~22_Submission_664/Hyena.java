import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing a Hyena in the simulator.
 * 
 * A hyena can hunt, breed, and give birth to new young.
 * A hyena can hunt gazelles only. Huntinga gazelle will 
 * increase the hyena's food level.
 *
 * @version 2022.02.15
 */
public class Hyena extends Predator implements Drawable
{
    // The age at which a hyena can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a hyena can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The probability a hyena's hunt will be successfull
    private static final double HUNT_SUCCESS_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single prey.
    private static final int PREY_FOOD_VALUE = 15;
    // The hyena's food level.
    private int foodLevel;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a hyena. A hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hyena will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            foodLevel = rand.nextInt(MAX_AGE);
        }
        else {
            super.setAge(0);
            foodLevel = MAX_AGE;
        }
    }

    /**
     * Draw the actor in the simulator.
     */
    @Override
    public void draw(){
        // currently does nothing
    }

    /**
     * This is what the hyena does most of the time: it hunts for
     * gazelles. In the process, it might breed, die of hunger, or 
     * die of old age.
     * @param newHyenas A list to return newly born hyenas.
     * @param weatherEffect The current effect the weather has on the animal. 
     */
    @Override
    public void act(List<Actor> newHyenas, double weatherEffect)
    {
        super.incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (super.getGender() && meet(this)){
                giveBirth(newHyenas); 
            }                     

            Location newLocation = null;
            newLocation = findFood();

            // Move towards a source of food if found.
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this hyena more hungry. This could result in the hyena's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * If the below meets the hunting probability conditions,
     * only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);

            if(actor instanceof Gazelle) {
                Random rand = new Random();
                if (!(rand.nextDouble() < HUNT_SUCCESS_PROBABILITY))
                {
                    return null;
                }

                Gazelle gazelle = (Gazelle) actor;
                if(gazelle.isAlive()) { 
                    gazelle.setDead();
                    foodLevel = this.foodLevel + PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Return the breeding age of the hyena. 
     * @return The breeding age.
     */
    @Override
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Return the maximum age the hyena will live. 
     * @return The maximum age. 
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE; 
    }

    /**
     * Return the hyena's breeding probability.
     * @return The breeding probability. 
     */
    @Override
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the hyena's maximum litter size.
     * @return The maximum litter size. 
     */
    @Override
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return a new hyena object to simulate a young hyena has been
     * born.
     * @param field The simulator field.
     * @param loc The location to place the new young. 
     * @return A new hyena object. 
     */
    @Override
    protected Hyena newAnimal(Field field, Location loc)
    {
        return new Hyena(false, field, loc); 
    }
}
