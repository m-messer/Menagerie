import java.util.Random;
import java.util.List;

/**
 * The Rainfall class represents the rainfall weather system
 * in a simulation.
 * 
 * Rainfall can have a different number of rainfall inches when 
 * the system is active. Rainfall effects the rate at which plants
 * grow in the simulation. 
 *
 * @version 18-02-2022
 */
public class Rainfall extends WeatherSystem
{
    // Track the number of inches of rain. 
    private int inches;
    
    /**
     * Construct the Rainfall system with the default settings.
     * By default, the Rainfall system is inactive. 
     */
    public Rainfall()
    {
        super(false, 0);
    }
    
    /**
     * Construct the Rainfall system with specific settings.
     * @param weatherActive Set to true to activate weather system
     * @param duration The length of time the weather system will last. 
     */
    public Rainfall(boolean weatherActive, int duration)
    {
        super(weatherActive, duration);
        if (weatherActive == true)
        {
            generateInches();
        }
    }
    
    /**
     * Return the number of inches of rainfall. Ranges between
     * 1 - 10. 
     * @return The inches of rainfall. 
     */
    public int getInches()
    {
        return inches;
    }
    
    /**
     * Set the number of inches of rainfall. Must be between 1 - 10.
     * @param inches The number of inches of rainfall. 
     */
    public void setInches(int inches)
    {
        if (inches < 1 || inches > 10)
        {
            inches = 1; 
        }
        
        this.inches = inches;
    }
    
    /**
     * Generate the number of inches of rain. 1 - 3 is light
     * rainfall, 4 - 7 is moderate rainfall, 8 - 10 is heavy 
     * rainfall. 
     */
    private void generateInches()
    {
        Random rand = new Random();
        inches = rand.nextInt(10);
    }
    
    /**
     * Simulate the impact of the weather system on plants. 
     * @return The multipler value caused by the weather system.
     */
    @Override
    public double effectPlants()
    {
        double multiplier = 1.0; 
        generateInches();
        
        if (getInches() < 8 && getInches() > 3)
        {
            multiplier = 1.15;
        }
        else if (getInches() > 8)
        {
            multiplier = 1.25;
        }
        
        return multiplier;
    }
    
    /**
     * Simulate the impact of the weather system on actors.
     * @param newActors The list of actors affected by the weather system. 
     * @param weatherSystem The current weather system. 
     * @return The new list of actors affected by the weather system. 
     */
    @Override
    public List<Actor> effectActors(List<Actor> newActors, WeatherSystem weatherSystem){
        return newActors;
    }
}
