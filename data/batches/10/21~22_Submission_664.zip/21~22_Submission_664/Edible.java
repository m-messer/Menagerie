import java.util.List;
import java.util.ArrayList;
import java.util.Random;
 
/**
 * This class represents an edible plant in the
 * simulation.
 *
 * An edible plant can reproduce new seedlings when 
 * there are free spaces in the field, and the plant
 * has reached pollination age. 
 *
* @version 15/02/2022
*/
public abstract class Edible extends Plant
{
    // Plant characteristics
    private static final int POLLINATION_AGE = 2;
    private static final double POLLINATION_PROBABILITY = 2.5;
    private static final int MAX_SEED_SIZE = 5;
 
    // A random number generator to control seeding.
    private static final Random rand = Randomizer.getRandom();
 
    /**
     * Create a plant. All plants are created with age 0.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Edible(Field field, Location location)
    {
        super(field, location);
    }
   
    /**
     * This causes an edible plant to reproduce new seedlings when
     * the plant has reached its pollination age.
     *
     * @param newPlants A list to return new plants.
     * @param weatherEffect The effect the weather has on the plant. 
     */
    abstract public void act(List<Actor> newPlants, double weatherEffect);
   
    // Plant characteristics related to breeding 
    /**
     * Return the pollination age of the plant. 
     * @return The pollination age.
     */
    abstract protected int getPollinationAge();

    /**
     * Return the plant's pollination probability.
     * @return The pollination probability. 
     */
    abstract protected double getPollinationProbability();
   
    /**
     * Return the plant's maximum seed size.
     * @return The maximum seed size. 
     */
    abstract protected int getMaxSeedSize();
   
    /**
     * Return a new plant object to simulate a seedling being
     * born.
     * @return A new plant object. 
     */
    abstract protected Plant newPlant(Field field, Location loc);
}