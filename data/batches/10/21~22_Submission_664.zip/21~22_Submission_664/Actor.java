import java.util.List;

/**
 * The interface to be extended by any class wishing 
 * to participate in the simulation as an actor.
 *
 * @version 2022.02.10
 */
public interface Actor
{
    /**
     * Perform the actor's regular behavior.
     * @param newActors A list for receiving newly created actors.
     */
    void act(List<Actor> newActors, double weatherEffect);
    
    /**
     * Is the actor still active?
     * @return true if still active, false if not.
     */
    boolean isActive(); 
}