import java.util.Random;
import java.util.List;
import java.util.Iterator; 

/**
 * The class regenerates actors in the simulation.
 * 
 * An actor is regenerated into the simulation when
 * the field has free space and when the regeneration 
 * rate for the actor has been met. 
 *
 * @version 18/02/2022
 */
public class ActorRegenerator
{    
    // Regeneration rates of actors that can be regenerated
    private static final double HUNTER_REGEN_RATE = 0.4;
    private static final double TOURIST_REGEN_RATE = 0.5;
    private static final double OLEANDER_REGEN_RATE = 0.1;
    private static final double ACACIA_REGEN_RATE = 0.33;

    // The rows and column numbers of the location in the field
    private int row;
    private int col;
    
    // Randomly generate a new number
    private Random rand;

    /**
     * Construct the actor regenerator and prepare to 
     * regenerate actors.
     */
    public ActorRegenerator()
    {
        // currently does nothing
    }

    /**
     * Regenerate actors and place into the simulation.
     * @param field The simulation field. 
     * @param actors The list of current actors in the simulation.
     * @return A new list of actors currently in the simulation. 
     */
    public List<Actor> regenerate(Field field, List<Actor> actors)
    {
        rand = Randomizer.getRandom();

        if (rand.nextDouble() <= TOURIST_REGEN_RATE)
        {
            if (findSpace(field))
            {
                Location loc = new Location(getRow(), getCol());
                actors.add(new Tourist(field, loc));
            }
        }
        
        if (rand.nextDouble() <= HUNTER_REGEN_RATE)
        {
            if (findSpace(field))
            {
                Location loc = new Location(getRow(), getCol());
                actors.add(new Hunter(field, loc));
            }
        }
        
        if (rand.nextDouble() <= OLEANDER_REGEN_RATE)
        {
            if (findSpace(field))
            {
                Location loc = new Location(getRow(), getCol());
                actors.add(new Oleander(field, loc));
            }
        }
        
        if (rand.nextDouble() <= ACACIA_REGEN_RATE)
        {
            if (findSpace(field))
            {
                Location loc = new Location(getRow(), getCol());
                actors.add(new Acacia(field, loc));
            }
        }
        return actors;
    }

    /**
     * Check the field randomly for free space to place actors
     * into the simulation.
     * 
     * @param field The simulation field. 
     * @return True if there is free space in the field, false otherwise. 
     */
    private boolean findSpace(Field field)
    {                
        int randRow = rand.nextInt(field.getDepth()); 
        int randCol = rand.nextInt(field.getWidth());
        
        Object freeSpace = field.getObjectAt(randRow, randCol);
        
        while(freeSpace == null)
        {
            randRow = rand.nextInt(field.getDepth()); 
            randCol = rand.nextInt(field.getWidth());
            
            if (field.getObjectAt(randRow, randCol) == null)
            {
                setRow(randRow);
                setCol(randCol);
            
                return true;
            }
            break;
        }
        
        return false;
    }

    /**
     * Return the row number of the free space in the field. 
     * @return The row number. 
     */
    private int getRow()
    {
        return row;
    }

    /**
     * Set the row number to the number given. 
     * @parm row The row number given.
     */
    private void setRow(int row)
    {
        this.row = row; 
    }
    
    /**
     * Return the column number of the free space in the field. 
     * @return The column number. 
     */
    private int getCol()
    {
        return col; 
    }
    
    /**
     * Set the column number to the number given. 
     * @parm col The column number given.
     */
    private void setCol(int col)
    {
        this.col = col; 
    }
}
