import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class represents a hunter in the simulation.
 * 
 * A hunter visits the safari and hunts for lions - 
 * affecting the lion population. Hunters visits the
 * safari for a specific amount of steps before 
 * leaving the safari. 
 *
 * @version 15-02-2022
 */
public class Hunter extends Human implements Drawable
{
    // The maximum steps for which a human stays in the safari.
    private static final int MAX_STAY = 36;
    // The respawn probability
    private static final double RESPAWN_PROBABILITY = 0.025;
    // track the amount of lions hunted by hunters
    private int lionHunted;

    /**
     * Create a hunter and place the hunter into the field at
     * the given location. 
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hunter(Field field, Location location)
    {
        super(field, location);
        lionHunted = 0; 
    }

    /**
     * Draw the actor in the simulator.
     */
    @Override
    public void draw(){
        // currently does nothing
    }
    
    /**
     * This is what the hunter does most of the time: hunts lions
     * and move into free adjacent spaces. 
     * 
     * @param newhumans A list to receive newly regenerated humans.
     * @param weatherEffect The effect the weather has on the human.
     */
    @Override
    public void act(List<Actor> newHumans, double weatherEffect)
    {
        super.incrementAge();
        if(isActive()) {        
            respawn(newHumans); 
            
            Location newLocation = hunt();
            if(newLocation == null) { 
                // No lions found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setInactive();
            }
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal or tourist is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location hunt()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);

            if(animal instanceof Lion) {
                Lion lion = (Lion) animal;
                if(lion.isAlive()) { 
                    lion.setDead();
                    ++lionHunted;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Return the maximum number of steps the hunter will stay in the 
     * safari.
     * @return The maximum number of steps. 
     */
    @Override
    protected int getMaxStay()
    {
        return MAX_STAY; 
    }

    /**
     * Return the probabiltiy of a hunter being regenerated.
     * @return The probability a hunter will be regenerated. 
     */
    @Override
    protected double getRespawnProbability()
    {
        return RESPAWN_PROBABILITY;
    }
    
    /**
     * Return the stats related to this hunter object.
     * @return The stats related to this object. 
     */
    public int getStats()
    {
        return lionHunted;
    }
    
    /**
     * Return a new hunter object to simulate a hunter arriving at the
     * safari. 
     * @param field The simulator field.
     * @param loc The location to place the new human. 
     * @return A new hunter object. 
     */
    @Override
    protected Hunter newHuman(Field field, Location loc)
    {
        return new Hunter(field, loc); 
    }
}
