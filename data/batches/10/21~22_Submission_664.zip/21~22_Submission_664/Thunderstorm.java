import java.util.Random;
import java.util.List;

/**
 * The Thunderstorm class represents a thunderstorm weather system
 * in the simulation. 
 * 
 * Thunderstorm effects the simulation's population when the 
 * weather system is active. It can either kill off a random
 * drawable actor or reduce its lifespan by half.
 *
 * @version 25-02-2022
 */
public class Thunderstorm extends WeatherSystem
{
    // Track if the thunder strike is fatal.
    private boolean fatality;

    // Used to generate a random boolean value.
    private Random rand;
    
    /**
     * Construct the Thunderstorm system with the default settings.
     * By default, the Rainfall system is inactive. 
     */
    public Thunderstorm()
    {
        super(false, 0);
    }

    /**
     * Construct the Thunderstorm system with specific settings.
     * @param weatherActive Set to true to activate weather system
     * @param duration Set the length of time the weather system will last. 
     */
    public Thunderstorm(boolean weatherActive, int duration)
    {
        super(weatherActive, duration);
        if (weatherActive == true)
        {
            rand = new Random();
            generateFatality();
        }
    }

    /**
     * Return the fatality of the thunderstorm.
     * @return True if the thunderstrike is fatal. 
     */
    public boolean getFatality()
    {
        return fatality;
    }

    /**
     * Set the fatality of the thunderstorm.
     * @param fatality The fatality of the thundersrike. 
     */
    public void setFatality(boolean fatality)
    {
        this.fatality = fatality;
    }

    /**
     * Generate the fatality of the thunderstorm. True immediately
     * sets the actor as dead and false reduces its lifespan by half.
     */
    private void generateFatality()
    {
        fatality = rand.nextBoolean();
    }

    /**
     * Simulate the impact of the weather system on plants. 
     * @return The multipler value caused by the weather system.
     */
    @Override
    public double effectPlants(){
        return 1.0;
    }
    
    /**
     * Simulate the impact of the weather system on actors.
     * @param newActors The list of actors affected by the weather system. 
     * @param weatherSystem The current weather system. 
     * @return The new list of actors affected by the weather system. 
     */
    @Override
    public List<Actor> effectActors(List<Actor> newActors, WeatherSystem weatherSystem)
    {
        generateFatality();
        Random rand = new Random();
        
        boolean isActor = false;
        while (!isActor){
            Actor randomActor = newActors.get(rand.nextInt(newActors.size()));
            
            if (randomActor instanceof Animal){
                Animal animal = (Animal) randomActor;
                if (fatality){
                    animal.setDead();
                    newActors.remove(animal);
                }
                else {
                    animal.setAge(animal.getAge()*(1/2));
                }
                isActor = true;
            }
            else if (randomActor instanceof Human){
                Human human = (Human) randomActor;
                if (fatality){
                    human.setInactive();
                    newActors.remove(human);
                }
                else {
                    human.setStay(human.getStay()*(1/2));
                }
                isActor = true;
            }
        }
        return newActors;
    }
}
