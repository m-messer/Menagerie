import java.util.List;
import java.util.Random; 

/**
 * This class represents a human in the simulation.
 * 
 * A human visits the safari and can affect the animal 
 * population. A human can stay in the safari for a 
 * certain amount of steps, before leaving the safari. 
 *
 * @version 2022.02.15
 */
public abstract class Human extends ActorRegenerator implements Actor
{
    // Whether the human is active or not.
    private boolean active;
    // The human's field.
    private Field field;
    // The human's position in the field.
    private Location location;
    // The human's length of stay in the safari
    private int stay; 

    // A shared random number generator to control respawn.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new human at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Human(Field field, Location location)
    {
        active = true;
        this.field = field;
        setLocation(location);
        stay = 0;
    }

    /**
     * Make this human act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newhumans A list to receive newly born humans.
     * @param weatherEffect The effect the weather has on the human. 
     */
    abstract public void act(List<Actor> newHuman, double weatherEffect);

    /**
     * Return the number of steps left the human stays in the safari.
     * 
     * @return The number of steps remaining. 
     */
    protected int getStay()
    {
        return this.stay; 
    }

    /**
     * Set the number of steps the human will stay in the safari.
     * @param stay The number of steps the human will stay.
     */
    protected void setStay(int stay){
        this.stay = stay;
    }

    /**
     * Increase the number of steps the human has stayed in the safari.
     * This could result in the human's leaving the safari.
     */
    protected void incrementAge()
    {
        stay++;
        if(stay > getMaxStay()) {
            setInactive();
        }
    }

    /**
     * Return the maximum number of steps the human stays
     * in the safari. 
     * @return The maximum number of steps. 
     */
    abstract protected int getMaxStay(); 

    /**
     * Check whether the human is active or not.
     * @return true if the human is still active.
     */
    @Override
    public boolean isActive()
    {
        return active;
    }

    /**
     * Indicate that the human is no longer in the safari.
     * The human is removed from the field.
     */
    protected void setInactive()
    {
        active = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the human's respawn probability.
     * @return The respawn probability. 
     */
    abstract protected double getRespawnProbability();

    /**
     * Generate the number of humans to regenerate, if the 
     * respawn probability is met. 
     * @return The number of humans to regenerate (may be zero).
     */
    protected int spawnHuman()
    {
        int births = 0;
        if(rand.nextDouble() <= getRespawnProbability()) {
            births = 1;
        }
        return births;
    }

    /**
     * Respawn a new human into the safari. 
     * @param newHumans A list to return newly respawn humans.
     */
    protected void respawn(List<Actor> newHumans)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        int respawn = spawnHuman();
        for(int r = 0; r < respawn && free.size() > 0; r++) {
            Location loc = free.remove(0);

            Human human = newHuman(field, loc); 
            newHumans.add(human); 
        }
    }

    /**
     * Return the human's location.
     * @return The human's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the human at the new location in the given field.
     * @param newLocation The human's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the human's field.
     * @return The human's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the stats related to this human object.
     * @return The stats related to this object. 
     */
    abstract public int getStats();
    
    /**
     * Return a new human object to simulate a human appearing in the field.
     * @param field The simulator field.
     * @param loc The location to place the new human. 
     * @return A new human object. 
     */
    abstract protected Human newHuman(Field field, Location loc); 
}
