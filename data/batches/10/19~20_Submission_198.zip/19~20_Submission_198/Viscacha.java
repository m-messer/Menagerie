/**
 * A subclass composed of properties shared by all the viscachas and a method to create baby viscachas.
 * @version 2020.02.21
 */
public class Viscacha extends Prey
 {
	/*
	 * Properties shared by all viscachas
	 * First value of the array represent the minimum of the value
	 * Second value of the array represent the variance that is going
	 * to be randomly added to the minimum of the value
	 */
	private static final int[] VIEW_RANGE = {4, 2}; // The distance to where a viscacha can see
	private static final int[] BREEDING_AGE = {7, 3}; // The age at which a viscacha can start to breed (in steps)
	private static final int[] BREEDING_REST_PERIOD = {2, 3}; // The number of steps between potential mating sessions
	private static final int[] SLEEP_HOUR = {18, 3}; // The time when viscachas go to sleep
	private static final int[] WAKE_HOUR = {5, 3}; // The time when viscachas wake up
	private static final int[] MAX_FOOD_LEVEL = {300, 200}; // Maximum food viscachas can eat
	private static final int[] FOOD_VALUE = {50, 15}; // Maximum food unit viscachas can be
	// Then  multiplied by 0,01 to get a probability
	private static final int[] SICKNESS_PROBABILITY = {20, 50}; // Viscachas' probability of getting infected by the virus
	private static final int[] SICKNESS_DEATH_PROBABILITY = {10, 35}; // Viscachas' probability of dying when infected
	private static final int[] REMISSION_PROBABILITY = {1, 5}; // Viscachas' probability of being cured when having the virus

	private static final int AVERAGE_AGE = 75; // The life expectancy of a viscacha (in steps)
	private static final double BREEDING_PROBABILITY = 0.75; // Viscachas' probability of breeding
	private static final int MAX_LITTER_SIZE = 4; // The maximum number of children a viscacha can have at once.

	private static Class[] canEat = {Moss.class, Grass.class}; // Entities that viscachas can eat

	/**
	 * Create a new viscacha. A viscacha may be created with age
	 * zero (a new born) or with a random age and sex
	 * @param randomAge If true, the viscacha will have a random age, zero otherwise
	 * @param field     The field currently occupied
	 * @param location  The location within the field
	 * @param isFemale If true the sex of the viscacha will be female, male otherwise
	 */
	public Viscacha(boolean randomAge, Field field, Location location, boolean isFemale)
	{
		super(randomAge, field, location, isFemale, MAX_FOOD_LEVEL, BREEDING_AGE, AVERAGE_AGE,
				WAKE_HOUR, SLEEP_HOUR, MAX_LITTER_SIZE, VIEW_RANGE, BREEDING_REST_PERIOD, FOOD_VALUE,
				SICKNESS_PROBABILITY, SICKNESS_DEATH_PROBABILITY, REMISSION_PROBABILITY, BREEDING_PROBABILITY, canEat);
	}

	/**
	 * Create a new born viscacha of age zero
	 * @param field The field the new viscacha is in
	 * @param location Which location the new viscacha is at
	 * @return the newly created viscacha
	 */
	@Override
	protected Animal newBaby(Field field, Location location)
	{
		return new Viscacha(false, field, location, rand.nextBoolean());
	}
}