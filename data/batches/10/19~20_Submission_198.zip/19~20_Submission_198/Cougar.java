/**
 * A subclass composed of properties shared by all the cougars and a method to create baby cougars.
 * @version 2020.02.21
 */
public class Cougar extends Predator
{
    /*
     * Properties shared by all cougars
     * First value of the array represent the minimum of the value
     * Second value of the array represent the variance that is going
     * to be randomly added to the minimum of the value
     */
    private static final int[] VIEW_RANGE = {3, 1}; // The distance to where a cougar can see
    private static final int[] BREEDING_AGE = {10, 5}; // The age at which a cougar can start to breed (in steps)
    private static final int[] BREEDING_REST_PERIOD = {7, 20}; // The number of steps between potential mating sessions
    private static final int[] SLEEP_HOUR = {18, 3}; // The time when cougars go to sleep
    private static final int[] WAKE_HOUR = {5, 3}; // The time when cougars wake up
    private static final int[] MAX_FOOD_LEVEL = {1000, 500}; // Maximum food cougars can eat
    private static final int[] FOOD_VALUE = {75, 20}; // Maximum food unit cougars can be
    // Then  multiplied by 0,01 to get a probability
    private static final int[] SICKNESS_PROBABILITY = {8, 60}; // Cougars' probability of getting infected by the virus
    private static final int[] SICKNESS_DEATH_PROBABILITY = {90, 9}; // Cougars' probability of dying when infected
    private static final int[] REMISSION_PROBABILITY = {1, 3}; // Cougars' probability of being cured when having the virus

    private static final int AVERAGE_AGE = 100; // The life expectancy of a cougar (in steps)
    private static final double BREEDING_PROBABILITY = 0.8; // Cougars' probability of breeding
    private static final int MAX_LITTER_SIZE = 2; // The maximum number of children a cougar can have at once.

    private static Class[] canEat = {Viscacha.class, Chinchilla.class, Llama.class}; // Entities that cougars can eat

    /**
     * Create a new cougar. A cougar may be created with age
     * zero (a new born) or with a random age and sex
     * @param randomAge If true, the cougar will have a random age, zero otherwise
     * @param field     The field currently occupied
     * @param location  The location within the field
     * @param isFemale If true the sex of the cougar will be female, male otherwise
     */
    public Cougar(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(randomAge, field, location, isFemale, MAX_FOOD_LEVEL, BREEDING_AGE, AVERAGE_AGE, WAKE_HOUR,
                SLEEP_HOUR, MAX_LITTER_SIZE, VIEW_RANGE, BREEDING_REST_PERIOD, FOOD_VALUE, SICKNESS_PROBABILITY,
                SICKNESS_DEATH_PROBABILITY, REMISSION_PROBABILITY, BREEDING_PROBABILITY, canEat);
    }

    /**
     * Create a new born cougar of age zero
     * @param field The field the new cougar is in
     * @param location Which location the new cougar is at
     * @return the newly created cougar
     */
    @Override
    protected Animal newBaby(Field field, Location location)
    {
        return new Cougar(false, field, location, rand.nextBoolean());
    }
}

