import java.util.ArrayList;
import java.util.Random;
import java.util.LinkedList;
import java.util.List;
import java.util.Collections;

/**
 * Represent a rectangular grid of field positions with several layers.
 * Each position is able to store as many entities as it has layers.
 * Each layer is reserved for one type of entity: one for animals, the other for plants.
 * @version 2020.02.15
 */
public class Field
{
	private static final int LAYERS = 2; // The number of layers this field has: 1 for animals and 1 for plants
	static final int PLANT_LAYER = 0;
	static final int ANIMAL_LAYER = 1;

	private static final Random rand = Randomizer.getRandom(); // A random number generator for providing random locations.
	private int height; // The x axis of the field going up to down
	private int width; // The y axis of the field going left to right
	private int depth; // How many "layers" the field has (eg. an animal layer and a plant layer)

	private Entity[][][] field; // 3D Entity array storing all entities in the simulation

	/**
	 * Represent a field of the given dimensions.
	 * @param height The number of rows the field has
	 * @param width  The number of columns the field has
	 */
	public Field(int height, int width)
	{
		this.height = height;
		this.width = width;
		this.depth = LAYERS;

		field = new Entity[height][width][depth];
	}

	/**
	 * Empty the field.
	 */
	public void clear()
	{
		field = new Entity[height][width][depth];
	}

	/**
	 * Clear the given location.
	 * @param location The location to clear.
	 */
	public void clear(Location location)
	{
		field[location.getRow()][location.getCol()][location.getLayer()] = null;
	}

	/**
	 * Place an Entity in a given location.
	 * @param entity   The entity to be placed.
	 * @param location The location to be placed in
	 */
	public void place(Entity entity, Location location)
	{
		field[location.getRow()][location.getCol()][location.getLayer()] = entity;
	}

	/**
	 * Return the entity at the given location, if any.
	 * @param location Where in the field.
	 * @return Entity at the given location, or null if there is none.
	 */
	public Entity getEntityAt(Location location)
	{
		return field[location.getRow()][location.getCol()][location.getLayer()];
	}

	/**
	 * Returns a list of entities found in a cuboid with Location topLeft at the top left of the cuboid and
	 * location bottomRight as opposite corner.
	 * @param topLeft Top left corner of the field to search
	 * @param bottomRight Opposite corner of field to search
	 * @return List of entities found (may be empty)
	 */
	public List<Entity> getAllEntitiesInRect(Location topLeft, Location bottomRight)
	{
		ArrayList<Entity> foundEntities = new ArrayList<>();

		for (int row = topLeft.getRow(); row <= bottomRight.getRow(); row++) {
			for (int col = topLeft.getCol(); col <= bottomRight.getCol(); col++) {
				for (int layer = bottomRight.getLayer(); layer <= topLeft.getLayer(); layer++) {
					// Exclude null entities
					if (field[row][col][layer] != null) {
						foundEntities.add(field[row][col][layer] );
					}
				}
			}
		}

		return foundEntities;
	}

	/**
	 * Returns a list of animals found in a cuboid with Location topLeft at the top left of the cuboid and
	 * location bottomRight as opposite corner.
	 * @param topLeft Top left corner of the field to search
	 * @param bottomRight Opposite corner of field to search
	 * @return List of entities found (may be empty)
	 */
	public ArrayList<Animal> getAllAnimalsInRect(Location topLeft, Location bottomRight)
	{
		ArrayList<Animal> foundEntities = new ArrayList<>();

		for(int row = topLeft.getRow(); row <= bottomRight.getRow(); row++) {
			for(int col = topLeft.getCol(); col <= bottomRight.getCol(); col++) {
				for(int layer = bottomRight.getLayer(); layer <= topLeft.getLayer(); layer++) {
					// Only keep the animals
					if(field[row][col][layer] != null && field[row][col][layer] instanceof Animal) {
						foundEntities.add((Animal) field[row][col][layer]);
					}
				}
			}
		}

		return foundEntities;
	}

	/**
	 * @param origin Where the animal is located
	 * @param range To where the animal can see
	 * @return The top left location that can be seen by an animal
	 */
	public Location findTopLeft(Location origin, int range)
	{
		int row, col;

		row = origin.getRow() - range;
		col = origin.getCol() - range;

		if (row < 0) {
			row = 0;
		}

		if (col < 0) {
			col = 0;
		}

		return new Location(row, col, LAYERS - 1);
	}

	/**
	 * @param origin Where the animal is located
	 * @param range To where the animal can see
	 * @return The bottom right location that can be seen by an animal
	 */
	public Location findBottomRight(Location origin, int range)
	{
		int row = origin.getRow() + range;
		int col = origin.getCol() + range;

		if (row >= height) {
			row = height - 1;

		}

		if (col >= width) {
			col = width - 1;
		}

		return new Location(row, col, 0);
	}

	/**
	 * @return A shuffled list of all the free location on the ground layer
	 */
	public List<Location> getFreeGroundLocations()
	{
		List<Location> free = new LinkedList<>();
		for(int row = 0; row < height; row++) {
			for(int col = 0; col < width; col++) {
				if(field[row][col][0] == null) {
					free.add(new Location(row, col, 0));
				}
			}
		}
		// Shuffle the list. Several other methods rely on the list
		Collections.shuffle(free, rand);

		return free;
	}

	/**
	 * Find all locations adjacent to the given location.
	 * The returned locations will be within the valid bounds of the field.
	 * The locations are not checked for occupants.
	 * @param location The location to which the returned locations are adjacent
	 * @return A shuffled list of valid adjacent locations
	 */
	private List<Location> getAdjacentLocations(Location location)
	{
		assert location != null : "Null location passed to adjacentLocations";

		// The list of locations to be returned.
		List<Location> locations = new LinkedList<>();

		int row = location.getRow();
		int col = location.getCol();
		int depth = location.getLayer();

		for (int roffset = -1; roffset <= 1; roffset++) {
			int nextRow = row + roffset;
			if (nextRow >= 0 && nextRow < height) {
				for (int coffset = -1; coffset <= 1; coffset++) {
					int nextCol = col + coffset;
					// Exclude invalid locations and the original location.
					if (nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
						locations.add(new Location(nextRow, nextCol, depth));
					}
				}
			}
		}

		// Shuffle the list. Several other methods rely on the list
		Collections.shuffle(locations, rand);

		return locations;
	}

	/**
	 * Get a shuffled list of the free adjacent locations.
	 * @param location Get locations adjacent to this.
	 * @return A list of free adjacent locations.
	 */
	public List<Location> getFreeAdjacentLocations(Location location)
	{
		List<Location> free = new LinkedList<>();
		List<Location> adjacent = getAdjacentLocations(location);

		for (Location next : adjacent) {
			// Verify that the location is not occupied
			if (getEntityAt(next) == null) {
				free.add(next);
			}
		}
		Collections.shuffle(free, rand);

		return free;
	}

	/**
	 * Get a shuffled list of busy adjacent locations
	 * @param location Get locations adjacent to this
	 * @return A list of occupied locations adjacent on the same layer
	 */
	public List<Location> getBusyAdjacentLocations(Location location)
	{
		List<Location> busy = new LinkedList<>();
		List<Location> adjacent = getAdjacentLocations(location);

		for (Location next : adjacent) {
			// Verify that there is an entity at the location
			if (getEntityAt(next) != null) {
				busy.add(next);
			}
		}

		return busy;
	}

	/**
	 * Get a shuffled list of busy adjacent locations on all layers
	 * @param location Get locations adjacent to this
	 * @return A list of occupied locations adjacent to the location passed
	 */
	public List<Location> getBusyAdjacentLocationsAllLayers(Location location)
	{
		List<Location> busy = new LinkedList<>();
		List<Location> adjacent = getAdjacentLocations(location);

		for(int layer = 0; layer < Field.LAYERS; layer++) {
			adjacent.addAll(getAdjacentLocations(new Location(location.getRow(), location.getCol(), layer)));
			for (Location next : adjacent) {
				// Verify that there is an entity at the location
				if (getEntityAt(next) != null) {
					busy.add(next);
				}
			}
		}

		return busy;
	}

	/**
	 * @return The height of the field
	 */
	public int getHeight()
	{
		return height;
	}

	/**
	 * @return The width of the field
	 */
	public int getWidth()
	{
		return width;
	}

	/**
	 * @return The depth of the field.
	 */
	public int getDepth()
	{
		return depth;
	}
}