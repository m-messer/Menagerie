import java.util.*;
import java.awt.Color;

/**
 * A simple grid-based ecology simulatord.
 * @version 2020.02.15
 */
public class Simulator
{
    // Constants representing default configuration information for the simulation.
    private static final int DEFAULT_WIDTH = 120;
    private static final int DEFAULT_HEIGHT = 80;

    //probabilities that types of Entities are created on simulation setup
    private static final double COUGAR_CREATION_PROBABILITY = 0.035;
    private static final double SNAKE_CREATION_PROBABILITY = 0.04;
    private static final double CONDOR_CREATION_PROBABILITY = 0.04;
    private static final double CHINCHILLA_CREATION_PROBABILITY = 0.08;
    private static final double VISCACHA_CREATION_PROBABILITY = 0.08;
    private static final double LLAMA_CREATION_PROBABILITY = 0.08;
    private static final double GRASS_CREATION_PROBABILITY = 0.04;
    private static final double MOSS_CREATION_PROBABILITY = 0.08;

    // Debug booleans enable/disable different entities of the simulation
    private static boolean preyEnabled = true;
    private static boolean predatorsEnabled = true;
    private static boolean plantsEnabled = true;

    private ArrayList<Animal> animals; // ArrayList of all animals in the field.
    private ArrayList<Plant> plants; // ArrayList of all plants in the field.

    // Variables handling simulated timing
    private int step;
    private int day;
    private int hour;
    private static Weather weather; // the current weather in the simulation

    private Field field;
    private SimulatorView view;
    private Random rand = Randomizer.getRandom();

    /**
     * Construct a simulation field with default values.
     */
    public Simulator()
    {
        this(DEFAULT_HEIGHT, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param height Depth of the field. Must be greater than zero.
     * @param width  Width of the field. Must be greater than zero.
     */
    public Simulator(int height, int width)
    {
        field = new Field(height, width);
        animals = new ArrayList<>();
        plants = new ArrayList<>();

        //check for invalid height/width
        if (width <= 0 || height <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            height = DEFAULT_HEIGHT;
            width = DEFAULT_WIDTH;
        }

        // Create a view of the state of each location in the field.
        view = new SimulatorView(this, height, width);

        // Initialise colours for different entities
        view.setColor(Chinchilla.class, new Color(244, 164, 130));
        view.setColor(Cougar.class, new Color(199, 21, 133));
        view.setColor(Snake.class, new Color(180, 255, 50));
        view.setColor(Llama.class, new Color(255, 215, 0));
        view.setColor(Condor.class, new Color(176, 196, 222));
        view.setColor(Viscacha.class, new Color(230, 133, 63));
        view.setColor(Moss.class, new Color(0, 50, 0));
        view.setColor(Grass.class, new Color(0, 100, 0));

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        //  Create a new threat in order to display the evolution of the simulator on the simulator view
        Thread thread = new Thread(){
            public void run(){
                for (int step = 0; step < numSteps && view.isViable(field); step++) {
                    simulateOneStep();
                    //delay(500);   // uncomment this to run more slowly
                }
            }
        };
        
        thread.start();
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each entities.
     */
    public void simulateOneStep()
    {
        step++;
        hour++;
        
        if (hour == 24) {
            day++;
            hour = 0;
            weather = Weather.getRandom(); // change weather once a day
            
            List<Plant> newPlants = new ArrayList<>();
            // Grow new grass if it is raining
            if (weather == Weather.RAINING) {
                newPlants.addAll(Grass.growNewGrass(field));
            }
            
            // Plants reproduce once a day
            for (Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
                Plant plant = it.next();
                if (plant.isAlive()) {
                    newPlants.addAll(plant.act(weather)); // Typecast the returned list to a List of Plants
                }
                else {
                    it.remove();
                }
            }
            // Add newly created plants to the main list
            plants.addAll(newPlants);
        }
        
        // animals act once a step
        List<Animal> newAnimals = new ArrayList<>();
        for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if (animal.isAlive()) {
                animal.sleepHandler(hour); // Make sure the animal is sleeping or awake when it should be
                newAnimals.addAll(animal.act(weather));
            }
            else {
                it.remove();
            }
        }

        // Add the newly created animals to the main list
        animals.addAll(newAnimals);

        // Remove the plants that have been eaten by the animals
        plants.removeIf(plant -> !plant.isAlive());

        // Update the GUI
        view.showStatus(step, field, day, hour);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        day = 0;
        hour = rand.nextInt(24);
        weather = Weather.getRandom();

        // Repopulate the field
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, day, hour);
    }

    /**
     * Populate the field with the different entities
     */
    private void populate()
    {
        field.clear();
    	populatePlant();
    	populateAnimal();
    }
    
    /**
     * Randomly populate the field with cougars, llamas, condors, snakes
     * chinchillas and viscachas
     */
    private void populateAnimal()
    {
    	for (int row = 0; row < field.getHeight(); row++) {
    		for (int col = 0; col < field.getWidth(); col++) {
    			if (rand.nextDouble() <= SNAKE_CREATION_PROBABILITY && predatorsEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Snake snake = new Snake(true, field, location, rand.nextBoolean());
    				animals.add(snake);
    			}
    			else if (rand.nextDouble() <= COUGAR_CREATION_PROBABILITY && predatorsEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Cougar cougar = new Cougar(true, field, location, rand.nextBoolean());
    				animals.add(cougar);
    			}
    			else if (rand.nextDouble() <= CHINCHILLA_CREATION_PROBABILITY && preyEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Chinchilla chinchilla = new Chinchilla(true, field, location, rand.nextBoolean());
    				animals.add(chinchilla);
    			}
    			else if (rand.nextDouble() <= VISCACHA_CREATION_PROBABILITY && preyEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Viscacha viscacha = new Viscacha(true, field, location, rand.nextBoolean());
    				animals.add(viscacha);
    			}
    			else if (rand.nextDouble() <= LLAMA_CREATION_PROBABILITY && preyEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Llama llama = new Llama(true, field, location, rand.nextBoolean());
    				animals.add(llama);
    			}
    			else if (rand.nextDouble() <= CONDOR_CREATION_PROBABILITY && predatorsEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Condor condor = new Condor(true, field, location, rand.nextBoolean());
    				animals.add(condor);
    			}
    			// else leave the location empty
    		}
    	}
    }
    
    /**
     * Randomly populate the field with moss and grass
     */
    private void populatePlant() {
    	for (int row = 0; row < field.getHeight(); row++) {
    		for (int col = 0; col < field.getWidth(); col++) {
    			if (rand.nextDouble() <= GRASS_CREATION_PROBABILITY && plantsEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Grass grass = new Grass(true, field, location);
    				plants.add(grass);
    			}
    			else if (rand.nextDouble() <= MOSS_CREATION_PROBABILITY && plantsEnabled) {
    				Location location = new Location(row, col, Field.PLANT_LAYER);
    				Moss moss = new Moss(field, location);
    				plants.add(moss);
    			}
    			// Else leave the location empty
    		}
    	}
    }
    
    /**
     * @return True if it is daytime, false if it nighttime
     */
    public boolean isDay()
    {
    	return hour <= 20 && hour > 8;
    }
    
    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
    	try {
    		Thread.sleep(millisec);
    	}
    	catch (InterruptedException ie) {
    		// Wake up
    	}
    }
    
    /**
     * @return The current weather of the simulation
     */
    public static Weather getWeather()
    {
    	return weather;
    }
    
    /**
     * @return The current number of steps the simulation is at
     */
    public int getStep()
    {
    	return step;
    }
    
    /**
     * @return The day the simulation is at
     */
    public int getDay()
    {
    	return day;
    }
    
    /**
     * @return The hour the simulation is at
     */
    public int getHour()
    {
    	return hour;
    }
    
    /**
     * @return The field where is the simulation is taking place
     */
    public Field getField()
    {
        return field;
    }
}
