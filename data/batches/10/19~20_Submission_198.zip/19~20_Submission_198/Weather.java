/**
 * Enum of different possible weather types.
 *
 * @version 2020.02.08
 */
public enum Weather
{
	SUNNY,
	RAINING,
	FOGGY,
	DROUGHT;


	/**
	 * Generates a random weather type.
	 * @return Randomly generated weather enum
	 */
	public static Weather getRandom()
	{
		return Weather.values()[Randomizer.getRandom().nextInt(Weather.values().length)];
	}
}
