/**
 * A subclass composed of properties shared by all the llamas and a method to create baby llamas.
 * @version 2020.02.21
 */
public class Llama extends Prey
{
    /*
     * Properties shared by all llamas
     * First value of the array represent the minimum of the value
     * Second value of the array represent the variance that is going
     * to be randomly added to the minimum of the value
     */
    private static final int[] VIEW_RANGE = {4, 1}; // The distance to where a llama can see
    private static final int[] BREEDING_AGE = {10, 5}; // The age at which a llama can start to breed (in steps)
    private static final int[] BREEDING_REST_PERIOD = {3, 6}; // The number of steps between potential mating sessions
    private static final int[] SLEEP_HOUR = {19, 2}; // The time when llamas go to sleep
    private static final int[] WAKE_HOUR = {6, 2}; // The time when llamas wake up
    private static final int[] MAX_FOOD_LEVEL = {500, 200}; // Maximum food llamas can eat
    private static final int[] FOOD_VALUE = {75, 25}; // Maximum food unit llamas can be
    // Then  multiplied by 0,01 to get a probability
    private static final int[] SICKNESS_PROBABILITY = {22, 34}; // Llamas' probability of getting infected by the virus
    private static final int[] SICKNESS_DEATH_PROBABILITY = {70, 10}; // Llamas' probability of dying when infected
    private static final int[] REMISSION_PROBABILITY = {1, 4}; // Llamas' probability of being cured when having the virus

    private static final int AVERAGE_AGE = 75; // The life expectancy of a llama (in steps)
    private static final double BREEDING_PROBABILITY = 0.9; // Llamas' probability of breeding
    private static final int MAX_LITTER_SIZE = 2; // The maximum number of children a llama can have at once.

    private static Class[] canEat = {Moss.class, Grass.class}; // Entity that llamas can eat

    /**
     * Create a new llama. A llama may be created with age
     * zero (a new born) or with a random age and sex
     * @param randomAge If true, the llama will have a random age, zero otherwise
     * @param field     The field currently occupied
     * @param location  The location within the field
     * @param isFemale If true the sex of the llama will be female, male otherwise
     */
    public Llama(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(randomAge, field, location, isFemale, MAX_FOOD_LEVEL, BREEDING_AGE, AVERAGE_AGE,
                WAKE_HOUR, SLEEP_HOUR, MAX_LITTER_SIZE, VIEW_RANGE, BREEDING_REST_PERIOD, FOOD_VALUE,
                SICKNESS_PROBABILITY, SICKNESS_DEATH_PROBABILITY, REMISSION_PROBABILITY, BREEDING_PROBABILITY, canEat);
    }

    /**
     * Create a new born llama of age zero
     * @param field The field the new llama is in
     * @param location Which location the new llama is at
     * @return the newly created llama
     */
    @Override
    protected Animal newBaby(Field field, Location location)
    {
        return new Llama(false, field, location, rand.nextBoolean());
    }
}