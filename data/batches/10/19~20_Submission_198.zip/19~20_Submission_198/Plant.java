import java.util.List;

/**
 * Represents a plant.
 * Plants cannot move or eat other entities, but they can reproduce and be eaten.
 * @version 2020.02.20
 */
public abstract class Plant extends Entity
{
	private final int daysSurviveWithoutWater; // // How long the plant can live without water before dying
	private int daysWithoutWater; // Counts how many days the plant has gone without water

	/**
	 * Create a new grass. A grass may be created with size one
	 * or with a random size
	 * @param field     The field currently occupied
	 * @param location  The location within the field
	 * @param foodValue The number of food unit a moss is
	 * @param averageDaySurviveWithoutWater How long the plant can live without water
	 */
	public Plant(Field field, Location location, int foodValue, int[] averageDaySurviveWithoutWater)
	{
		super(field, location, foodValue);

		// Initialise the plant's variables: the first value of the array is the minimum and the second is the variance
		daysSurviveWithoutWater = averageDaySurviveWithoutWater[0] + rand.nextInt(averageDaySurviveWithoutWater[1] + 1);
		daysWithoutWater = 0;
	}

	/**
	 * Increments the number of day without water and eventually
	 * kills the plant
	 */
	protected void dry()
	{
		daysWithoutWater++;

		if(daysWithoutWater > daysSurviveWithoutWater) {
			setDead();
		}
	}

	/**
	 * Set the plant to a location passed as parameter
	 * @param location the location the plant is going to occupy
	 */
	public void setLocation(Location location)
	{
		if (getLocation() != null) {
			getField().clear(getLocation());
		}

		Location newLocation = new Location(location.getRow(), location.getCol(), Field.PLANT_LAYER);

		super.setLocation(newLocation);
		getField().place(this, newLocation);
	}

	/**
	 * Grows, spreads or dies according to the weather
	 * @param currentWeather The current state of the weather
	 * @return A list of newly grown plant
	 */
	@Override
	public abstract List<? extends Plant> act(Weather currentWeather);
}