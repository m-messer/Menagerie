import java.util.ArrayList;
import java.util.List;

/**
 * Class composed of methods shared by all the animals.
 * @version 2020.02.21
 */
public abstract class Animal extends Entity
{
	// Immutable characteristics shared by all animals, set by constructor
	private final int maxFoodLevel; // Maximum amount of food the animal can have inside it at one time
	private final int averageAge;   // The average age of natural death for the animal
	private final int breedingAge; // The age past which an animal can breed
	private final int maxLitterSize; // Maximum number of children the animal can have at once
	private final int breedingRestPeriod; // Time that an animal has to wait before another breed
	private final double breedingProbability; // Probability of breeding
	private final int wakeHour; // Time when the animal wakes up
	private final int sleepHour; // Time when the animal goes to sleep
	private final int normalViewRange; // Normal view range of an animal, when the weather is sunny for instance
	private final double sicknessProbability; // Probability of getting infected by the virus
	private final double sicknessDeathProbability; // Probability of dying when having the virus
	private final double remissionProbability; // Probability of surviving the virus
	private final Class[] canEat; // Array of entity types this animal can eat

	private boolean isFemale; // State if the animal is a male or a female
	private boolean isAsleep; // State if the animal is currently asleep
	private boolean isSick; // State if the animal is currently sick
	private int currentViewRange; // State the view range of the animal at each time
	private int breedingCountdown; // State the time remaining before the animal can breed again
	private int age; // State the age in steps of the animal
	private int foodLevel; // State the hunger of the animal
	private int stepsSick; // State the number of steps the animal have been sick
	private Intent currentIntent; // State what the animal is trying to do at the moment
	private Entity currentTarget; // State the target of the animal's intended action

	/**
	 * Create a new animal at location in field.
	 * @param randomAge Boolean used to set a random age to animals at the beginning of the simulation
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 * @param isFemale Boolean that states if the animal is a female or a male
	 * @param maxFoodLevel Maximum food the animal can eat (simulate a stomach)
	 * @param breedingAge Minimum age when the animal can start breeding
	 * @param averageAge Life expectancy of the animals of this specie
	 * @param wakeHour Time of the day when the animal wakes up
	 * @param sleepHour Time of the day when the animal goes to sleep
	 * @param maxLitterSize Maximum number of children the animal can have
	 * @param viewRange Normal (and maximum) view range the animal can have
	 * @param breedingRestPeriod Time that an animal will have to wait before being able to breed again
	 * @param foodValue Value that the animal is worth (when eaten)
	 * @param sicknessProbability Probability that the animal will get infected by the virus
	 * @param sicknessDeathProbability Probability that the animal will die when having the virus
	 * @param remissionProbability Probability that the animal will survive if he has been infected by the virus
	 * @param breedingProbability Probability that the animal can breed at any time
	 * @param edibleEntities All the entities that the animal can eat
	 */
	public Animal(boolean randomAge, Field field, Location location, boolean isFemale, int[] maxFoodLevel,
				  int[] breedingAge, int averageAge, int[] wakeHour, int[] sleepHour, int maxLitterSize,
				  int[] viewRange, int[] breedingRestPeriod, int[] foodValue, int[] sicknessProbability,
				  int[] sicknessDeathProbability, int[] remissionProbability, double breedingProbability,
				  Class[] edibleEntities)
	{
		// field. location and foodValue are attributes shared by all entities
		super(field, location, foodValue[0] + rand.nextInt(foodValue[1] + 1));

		// Set characteristics for this animal: the first value of the array is the minimum and the second is the variance
		this.maxFoodLevel = (maxFoodLevel[0] + rand.nextInt(maxFoodLevel[1] + 1));
		this.breedingAge = (breedingAge[0] + rand.nextInt(breedingAge[1] + 1));
		this.wakeHour = (wakeHour[0] + rand.nextInt(wakeHour[1] + 1));
		this.sleepHour = (sleepHour[0] + rand.nextInt(sleepHour[1] + 1));
		this.breedingRestPeriod = (breedingRestPeriod[0] + rand.nextInt(breedingRestPeriod[1] + 1));
		this.normalViewRange = (viewRange[0] + rand.nextInt(viewRange[1] + 1));
		this.sicknessProbability = (sicknessProbability[0] + rand.nextInt(sicknessProbability[1] + 1)) * 0.01;
		this.sicknessDeathProbability = (sicknessDeathProbability[0] + rand.nextInt(sicknessDeathProbability[1] + 1)) * 0.01;
		this.remissionProbability = (remissionProbability[0] + rand.nextInt(remissionProbability[1] + 1)) * 0.01;
		this.isFemale = isFemale;
		this.averageAge = averageAge;
		this.canEat = edibleEntities;
		this.maxLitterSize = maxLitterSize;
		this.breedingProbability = breedingProbability;

		foodLevel = rand.nextInt(this.maxFoodLevel + 1);
		currentViewRange = normalViewRange;

		// At creation the animal is not in the process of doing anything
		currentIntent = Intent.NOTHING;
		currentTarget = null;

		// If the animal is the children of another animal then is age is 0, else (creation of simulator) the age is random
		age = 0;
		if (randomAge) {
			age = rand.nextInt(averageAge);
		}

		// The random chance of animal being created to be infected
		if (rand.nextDouble() <= this.sicknessProbability) {
			setSick();
		}
	}

	/**
	 * Handles the behaviour of the animal according to what the animal is trying to do at the moment
	 * @param currentWeather The weather of the simulator at the moment of the action
	 * @return List of newly created Animal instances
	 */
	@Override
	public List<? extends Animal> act(Weather currentWeather)
	{
		ArrayList<Animal> newAnimals = new ArrayList<>();

		// Determine what the animal should do according to its status (hunger...) and position
		calculateIntent();

		// Call different methods according to the intent that has been previously calculated
		switch (currentIntent) {
			case NOTHING:
				move();
				break;
			case MOVE_TO_FOOD:
				move();
				if (currentTarget.isAdjacentTo(getLocation())) {
					eat(currentTarget);
				}
				break;
			case MOVE_TO_MATE:
				move();
				if (currentTarget.isAdjacentTo(getLocation())) {
					if(isFemale) {
						newAnimals.addAll(giveBirth());
						setCurrentTarget(null);
					}
				}
				break;
			case EAT:
				eat(currentTarget);
				break;
			case MATE:
				if(isFemale) {
					newAnimals.addAll(giveBirth());
					setCurrentTarget(null);
				}
				break;
			case SLEEP:
				break;
		}

		// Update the age, hunger of the animal at each step
		update();

		return newAnimals;
	}

	/**
	 * If the animal is sick, he transmits the virus to all the animal around it
	 * Tries to move towards current target if possible.
	 * If there is no current target, moves randomly.
	 * If there is no free adjacent location, the animal dies.
	 * Only moves one square at a time.
	 */
	private void move()
	{
		if (isAlive()) {
			if (isSick) { // Infects the animals around
				getField().getBusyAdjacentLocations(getLocation()).stream().
						map(s -> getField().getEntityAt(s)).
						filter(s -> s instanceof Animal || !((Animal) s).isSick()).
						forEach(s -> ((Animal) s).receiveIllness());
			}
			if (currentTarget == null) { // Randomly moves if it can
				ArrayList<Location> freeLocations = new ArrayList<>(getField().getFreeAdjacentLocations(getLocation()));
				if (!freeLocations.isEmpty()) {
					setLocation(getField().getFreeAdjacentLocations(getLocation()).get(0));
					}
				else {
					setDead();
				}
			}
			else { // Moves towards the animal's target
				// Get the difference between animal's location and target's location
				int deltaX = currentTarget.getLocation().getCol() - getLocation().getCol();
				int deltaY = currentTarget.getLocation().getRow() - getLocation().getRow();
				int addX;
				int addY;

				// Calculate change in x position
				if (deltaX > 0) {
					addX = 1;
				}
				else if (deltaX == 0) {
					addX = 0;
				}
				else {
					addX = -1;
				}

				// Calculate change in y position
				if (deltaY > 0) {
					addY = 1;
				}
				else if (deltaY == 0) {
					addY = 0;
				}
				else {
					addY = -1;
				}

				// Create a new location with deltas added
				Location newLocation = new Location(getLocation().getRow() + addY, getLocation().getCol() + addX, Field.ANIMAL_LAYER);

				// Moves if there is space
				if (getField().getEntityAt(newLocation) == null) {
					setLocation(newLocation);
				}
			}
		}
	}

	/**
	 * Eats the passed entity. The consumee will be set to dead, the consumer
	 * will have their hunger increased by the caloric value of the consumee.
	 * @param consumee The entity to be eaten.
	 */
	private void eat(Entity consumee)
	{
		// Check if the consumee is available to be eaten
		if (!consumee.isAlive() || (consumee instanceof Animal && !((Animal)consumee).isAsleep())) {
			return;
		}

		// If the consumee can be eaten by the consumer, it is set to dead and its food value added to the animal's food level
		if (isEdible(consumee.getClass())) {
			Location newLoc = consumee.getLocation();
			consumee.setDead();

			increaseFoodLevel(consumee.getFoodValue());
			setLocation(newLoc);
		}
	}

	/**
	 * @return True if the animal is sick False otherwise
	 */
	protected boolean isSick()
	{
		return isSick;
	}

	/**
	 * Method that finds all the entities that can be eaten by the animal according to its view range
	 * @param range The distance to where the animal can see
	 * @return A list of Entity that can be eaten by the animal in it view range
	 */
	public List<Entity> findEdibleInRange(int range)
	{
		/*
		 * Create bounding box for search, limiting range by edges of field
		 * Create top left corner of bounding box
		 * Create bottom right corner of bounding box
		*/
		Location rangeTopLeft = getField().findTopLeft(getLocation(), range);
		Location rangeBottomRight = getField().findBottomRight(getLocation(), range);

		// Find all entities in bounding box
		ArrayList<Entity> nearbyEntities = new ArrayList<>(getField().getAllEntitiesInRect(rangeTopLeft, rangeBottomRight));

		// Remove inedible entities from nearbyEntities
		nearbyEntities.removeIf(s -> !isEdible(s.getClass()));

		return nearbyEntities;
	}

	/**
	 * Determine wether an entity can be eaten
	 * @param cls the class of the entity
	 * @return True if the entity can be eaten by the animal false otherwise
	 */
	protected boolean isEdible(Class cls)
	{
		for (Class c : canEat) {
			if (c.equals(cls)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return A List of newly created Animal instances, might be empty if
	 * breeding failed.
	 */
	private List<? extends Animal> giveBirth()
	{
		ArrayList<Animal> babies = new ArrayList<>();
		ArrayList<Location> freeLocations = new ArrayList<>(getField().getFreeAdjacentLocations(getLocation()));
		int litter = rand.nextInt(maxLitterSize + 1); // Number of children that the animal will breed

		// Breed if there is free space and the number of children is greater than zero
		if (litter > 0 && freeLocations.size() > 0) {
			for (Location loc : freeLocations) {
				if (litter-- == 0) {
					break;
				}
				babies.add(newBaby(getField(), loc));
			}
			resetBreedingCountdown();
		}
		return babies;
	}

	/**
	 * Set the animal to a new location after moving
	 * @param location the next location the animal is going to occupy
	 */
	public void setLocation(Location location)
	{
		if (getLocation() != null) {
			getField().clear(getLocation());
		}

		// Make sure that the animal will stay on the animal layer of the field (1)
		Location newLocation = new Location(location.getRow(), location.getCol(), Field.ANIMAL_LAYER);

		super.setLocation(newLocation); // Update the animal's location
		getField().place(this, newLocation); // Update the animal's location in the field
	}

	/**
	 * Ages the animal and kill him if randomDeathProbability is greater ot equals to 1
	 */
	private void age()
	{
		age++;

		// The older the animal is, the more likely it is to die
		double randomDeathProbability = 0.2 + (rand.nextDouble() * ((age * 1.0) / averageAge));

		if (randomDeathProbability >= 1) {
			setDead();
		}
	}

	/**
	 * Decrease this animal's food level (hunger) and kill it
	 * if it reaches zero
	 */
	private void decreaseFoodLevel()
	{
		foodLevel--;
		if (foodLevel <= 0) {
			setDead();
		}
	}

	/**
	 * Increase this animal's food level (Feed this animal)
	 * @param inc How much to increase the animal's food
	 * level by (usually the food value of the entity eaten by the animal)
	 */
	private void increaseFoodLevel(int inc)
	{
		foodLevel += inc;
		if (foodLevel > maxFoodLevel) {
			foodLevel = maxFoodLevel;
		}
	}

	/**
	 * @return True if this animal is able to breed False otherwise
	 */
	protected boolean canBreed()
	{
		if (isFemale && age >= breedingAge && breedingCountdown == 0 && rand.nextDouble() <= breedingProbability) {
			return true;
		}
		else {
			return !isFemale && age >= breedingAge && rand.nextDouble() <= breedingProbability;
		}
	}

	/**
	 * Method call when another animal around it is sick.
	 * Randomly infect to animal according to its sickness probability
	 */
	private void receiveIllness()
	{
		if (rand.nextDouble() <= sicknessProbability) {
			setSick();
		}
	}

	/**
	 * The animal is infected by the virus
	 */
	private void setSick()
	{
		isSick = true;
		stepsSick = 1;
	}

	/**
	 * Method that checks whether the animal should sleep or wake up at the time passed
	 * @param hour The time to check
	 */
	protected void sleepHandler(int hour)
	{
		if (hour == sleepHour && !isAsleep) {
			isAsleep = true;
		}
		else if (hour == wakeHour && isAsleep) {
			isAsleep = false;
		}
	}

	/**
	 * The animal just has given birth, the breeding countdown
	 * is reset to to the rest period
	 */
	private void resetBreedingCountdown()
	{
		breedingCountdown = breedingRestPeriod;
	}

	/**
	 * Update the status of the animal
	 */
	private void update()
	{
		if (!isAsleep) {
			decreaseFoodLevel();
			age();
		}
		if (isSick()) {
			sicknessHandler();
		}
		decreaseBreedingCountdown();
	}

	/**
	 * Decrease the breeding countdown in order to breed again
	 */
	private void decreaseBreedingCountdown()
	{
		if (breedingCountdown > 0) {
			breedingCountdown--;
		}
	}

	/**
	 * Handles sick animal: the longer the animal has been sick
	 * the more likely he is to be cured or dead
	 */
	private void sicknessHandler()
	{
		stepsSick++;

		if (((rand.nextDouble() * stepsSick) / 10) <= remissionProbability) {
			isSick = false;
		}
		else if (((rand.nextDouble() * stepsSick) / 10) <= sicknessDeathProbability) {
			setDead();
		}
	}

	/**
	 * Find the closest target from the position of the animal
	 * among a list of entities
	 * @param entities List of entities to check
	 * @return the closest entity, in the list, to the animal
	 */
	protected Entity getClosestEntity(ArrayList<Entity> entities)
	{
		Entity closestEntity = entities.get(0);
		for (Entity entity : entities) {
			if (entity.getLocation().getDistanceTo(getLocation()) < closestEntity.getLocation().getDistanceTo(getLocation())) {
				closestEntity = entity;
			}
		}
		return closestEntity;
	}

	/**
	 * @return the maximum food level that the animal can eat
	 */
	protected int getMaxFoodLevel()
	{
		return maxFoodLevel;
	}

	/**
	 * @return the current food level of the animal
	 */
	protected int getFoodLevel()
	{
		return foodLevel;
	}

	/**
	 * @return True if the animal is asleep, False otherwise
	 */
	protected boolean isAsleep()
	{
		return isAsleep;
	}

	/**
	 * Change the intent of the animal
	 * @param currentIntent is the new intent of the animal
	 */
	protected void setCurrentIntent(Intent currentIntent)
	{
		this.currentIntent = currentIntent;
	}

	/**
	 * @return The current target (prey or mate) of the animal
	 */
	protected Entity getCurrentTarget()
	{
		return currentTarget;
	}

	/**
	 * Set a new target to the animal
	 * @param currentTarget The new target
	 */
	protected void setCurrentTarget(Entity currentTarget)
	{
		this.currentTarget = currentTarget;
	}

	/**
	 * @return True if the animal is a female, False otherwise
	 */
	protected boolean isFemale()
	{
		return isFemale;
	}

	/**
	 * @return The current view range of the animal
	 */
	protected int getCurrentViewRange()
	{
		return currentViewRange;
	}

	/**
	 * Set a new view range to the animal
	 * @param newViewRange is the new view range the animal is will have
	 */
	protected void setCurrentViewRange(int newViewRange)
	{
		currentViewRange = newViewRange;
	}

	/**
	 * @return The normal (and maximum) view range of the animal
	 */
	protected int getNormalViewRange()
	{
		return normalViewRange;
	}

	/**
	 * Calculates the intent for the animal's next step
	 * and updates currentTarget and currentIntent accordingly.
	 */
	protected abstract void calculateIntent();

	/**
	 * The animal gives birth to a new animal
	 * @param field The field where the animal is
	 * @param loc The location where the children will born
	 */
	protected abstract Animal newBaby(Field field, Location loc);
}