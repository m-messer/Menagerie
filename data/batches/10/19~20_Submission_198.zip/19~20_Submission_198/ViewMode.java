/**
 * Enum of different possible simulator view modes.
 *
 * @version 2020.02.20
 */
public enum ViewMode
{
    NORMAL,
    SICK
}