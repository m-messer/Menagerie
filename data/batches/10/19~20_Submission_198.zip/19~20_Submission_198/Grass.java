import java.util.ArrayList;
import java.util.List;

/**
 * Represents a clump of grass. The grass can grow in height and also start growing
 * on empty location if it is raining
 *
 * @version 2020.02.20
 */
public class Grass extends Plant
{

	// Probability that grass can spawn on an empty location if raining
	private static final double GRASS_CREATION_PROBABILITY = 0.08;

	/*
	 * Properties shared by all grass
	 * First value of the array represent the minimum of the value
	 * Second value of the array represent the variance that is going
	 * to be randomly added to the minimum of the value
	 */
	private static final int[] DAYS_SURVIVES_WITHOUT_WATER = {2, 1}; // How long grass can live without water before dying
	private static final int[] MAX_SIZE = {2, 8}; // Maximum height all grass can grow
	private static final int FOOD_VALUE_PER_LEVEL = 3; // Food unit for each level of size of the grass

	private final int maxSize; // Maximum size of a particular grass
	private int size; // Current size of the grass

	/**
	 * Method that makes new grass spawn on empty locations of the field
	 * zero (a new born) or with a random age and sex
	 * @param field The field currently occupied
	 */
	public static List<Grass> growNewGrass(Field field)
	{
		ArrayList<Grass> newGrass = new ArrayList<>();

		for (Location loc : field.getFreeGroundLocations()) {
			// Make randomly spawn grass
			if (rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
				Grass grass = new Grass(false, field, loc);
				newGrass.add(grass);
			}
		}

		return newGrass;
	}

	/**
	 * Create a new grass. A grass may be created with size one
	 * or with a random size
	 * @param randomSize If true, the grass will have a random size, one otherwise
	 * @param field     The field currently occupied
	 * @param location  The location within the field
	 */
	public Grass(boolean randomSize, Field field, Location location)
	{
		super(field, location, FOOD_VALUE_PER_LEVEL, DAYS_SURVIVES_WITHOUT_WATER);

		/*
		 * Initialise the instance's variables
		 * The first value of the array is the minimum and the second is the variance
		 */
		maxSize = MAX_SIZE[0] + rand.nextInt(MAX_SIZE[1] + 1);
		size = 1;
		if (randomSize) {
			size = rand.nextInt(maxSize);
		}
	}

	/**
	 * Grows or dies according to the weather
	 * @param currentWeather The current state of the weather
	 * @return An empty list.
	 */
	@Override
	public List<Grass> act(Weather currentWeather)
	{
		switch (currentWeather) {
			case RAINING:
				size += 2; // Grows twice as fast in rain
				break;
			case DROUGHT:
				dry(); // dries in drought
				break;
			default:
				size++; // Grows normally
				break;
			}

			// Make sure that the size of the grass can be greater than its max size
			if(size > maxSize) {
				size = maxSize;
			}

		return new ArrayList<>();
	}

	/**
	 * @return The number of food unit of the entire grass according
	 * to its size
	 */
	@Override
	public int getFoodValue()
	{
		return size * FOOD_VALUE_PER_LEVEL;
	}
}