import java.util.List;
import java.util.ArrayList;

/**
 * Represents a clump of moss. The grass can grow in height and also spread on
 * free adjacent locations
 *
 * @version 2020.02.20
 */
public class Moss extends Plant
{

	private static final int[] DAYS_SURVIVES_WITHOUT_WATER = {3, 10}; // How long this moss can live without water before dying
	private static final int MAX_SPREAD = 8; // Maximum new mosses created when moss spreads
	private static final int FOOD_VALUE = 4; // Number of food unit a moss is

	/**
	 * Create a new moss.
	 * @param field     The field currently occupied
	 * @param location  The location within the field
	 */
	public Moss(Field field, Location location)
	{
		super(field, location, FOOD_VALUE, DAYS_SURVIVES_WITHOUT_WATER);
	}

	/**
	 * Grows and spreads according to the weather.
	 * @param currentWeather The current state of the weather
	 * @return A List of new moss instances (can be null).
	 */
	@Override
	public List<Moss> act(Weather currentWeather)
	{
		ArrayList<Moss> newMosses = new ArrayList<>();

		switch(currentWeather) {
			case RAINING:
				newMosses.addAll(spread(rand.nextInt(MAX_SPREAD + 1)));
				break;
			case DROUGHT:
				dry(); // dries up in drought
				break;
			default:
				dry();
				break;
		}
		
		return newMosses;
	}

	/**
	 * Creates a specified number of new moss plants adjacent to this one.
	 * @param newMosses Number of new moss instances to be created.
	 * @return A list of new moss instances.
	 */
	private List<Moss> spread(int newMosses)
	{
		ArrayList<Location> freeLocations = new ArrayList<>(getField().getFreeAdjacentLocations(getLocation()));
		ArrayList<Moss> newPlants = new ArrayList<>();

			// Create the new mosses as long there are free locations
			for (Location loc : freeLocations) {
				if (newMosses == 0) {
					break;
				}
				newPlants.add(new Moss(getField(), loc));
				newMosses--;
			}

		return newPlants;
	}

	/**
	 * @return The food value of this clump of moss.
	 */
	@Override
	public int getFoodValue()
	{
		return FOOD_VALUE;
	}
}
