/**
 * A subclass composed of properties shared by all the condors and a method to create baby condors.
 * @version 2020.02.21
 */
public class Condor extends Predator
{
    /*
     * Properties shared by all condors
     * First value of the array represent the minimum of the value
     * Second value of the array represent the variance that is going
     * to be randomly added to the minimum of the value
     */
    private static final int[] VIEW_RANGE = {3, 3}; // The distance to where a condor can see
    private static final int[] BREEDING_AGE = {7, 3}; // The age at which a condor can start to breed (in steps)
    private static final int[] BREEDING_REST_PERIOD = {2, 10}; // The number of steps between potential mating sessions
    private static final int[] SLEEP_HOUR = {20, 2}; // The time when condors go to sleep
    private static final int[] WAKE_HOUR = {7, 2}; // The time when condors wake up
    private static final int[] MAX_FOOD_LEVEL = {300, 200}; // Maximum food condors can eat
    private static final int[] FOOD_VALUE = {50, 15}; // Maximum food unit condors can be
    // Then  multiplied by 0,01 to get a probability
    private static final int[] SICKNESS_PROBABILITY = {20, 40}; // Condors' probability of getting infected by the virus
    private static final int[] SICKNESS_DEATH_PROBABILITY = {85, 5}; // Condors' probability of dying when infected
    private static final int[] REMISSION_PROBABILITY = {1, 6}; // Condors' probability of being cured when having the virus

    private static final int AVERAGE_AGE = 40; // The life expectancy of a condor (in steps)
    private static final double BREEDING_PROBABILITY = 0.8; // Condors' probability of breeding
    private static final int MAX_LITTER_SIZE = 3; // The maximum number of children a condor can have at once.

    private static Class[] canEat = {Snake.class, Chinchilla.class, Viscacha.class}; // Entities that condors can eat

    /**
     * Create a new condor. A condor may be created with age
     * zero (a new born) or with a random age and sex
     * @param randomAge If true, the viscacha will have a random age, zero otherwise
     * @param field     The field currently occupied
     * @param location  The location within the field
     * @param isFemale If true the sex of the condor will be female, male otherwise
     */
    public Condor(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(randomAge, field, location, isFemale, MAX_FOOD_LEVEL, BREEDING_AGE, AVERAGE_AGE,
                WAKE_HOUR, SLEEP_HOUR, MAX_LITTER_SIZE, VIEW_RANGE, BREEDING_REST_PERIOD,
                FOOD_VALUE, SICKNESS_PROBABILITY, SICKNESS_DEATH_PROBABILITY, REMISSION_PROBABILITY,
                BREEDING_PROBABILITY, canEat);
    }

    /**
     * Create a new born condor of age zero
     * @param field The field the new condor is in
     * @param location Which location the new condor is at
     * @return the newly created condor
     */
    @Override
    protected Animal newBaby(Field field, Location location)
    {
        return new Condor(false, field, location, rand.nextBoolean());
    }
}