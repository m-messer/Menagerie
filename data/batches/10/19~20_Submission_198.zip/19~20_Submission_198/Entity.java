import java.util.List;
import java.util.Random;

/**
 * Represents any entity (plant or animal) that exists in the simulation.
 * @version 2020.02.20
 */
public abstract class Entity
{
    // Random variable used to create the same simulation every time
    static final Random rand = Randomizer.getRandom();

    // Attributes common to all the entities
    private Field field;
    private Location location;
    private boolean isAlive;
    private final int foodValue;

    /**
     * Create a new entity and place it a location in field.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param foodValue The number of food unit of the entity
     */
    public Entity(Field field, Location location, int foodValue)
    {
        isAlive = true; // Entity is alive by default
        this.field = field;
        this.foodValue = foodValue;
        setLocation(location);
    }

    /**
     * Kill the entity and removed it from the field.
     */
    protected void setDead()
    {
        isAlive = false;

        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Returns true if this entity is within a range extending in all directions from the origin location.
     * @param origin The location at the centre of the "range box"
     * @param range The range
     * @return True if this entity is in range of the origin location, False otherwise
     */
    protected boolean isInRange(Location origin, int range)
    {
        int deltaCol = Math.abs(origin.getCol() - getLocation().getCol());
        int deltaRow = Math.abs(origin.getRow() - getLocation().getRow());

        if(deltaCol > range) {
            return false;
        }

        if(deltaRow > range) {
            return false;
        }

        return true;
    }

    /**
     * Changes the entity's location.
     * @param newLocation The new location of the entity
     */
    protected void setLocation(Location newLocation)
    {
        location = newLocation;
    }

    /**
     * Returns true if the location is within 1 grid square of this entity
     * @param origin The location to check for adjacency with
     * @return True if this location is next to the origin location
     */
    protected boolean isAdjacentTo(Location origin)
    {
        return this.isInRange(origin, 1);
    }

    /**
     * @return True if the Entity is alive, False otherwise
     */
    protected boolean isAlive()
    {
        return isAlive;
    }

    /**
     * @return The entity's field
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * @return The entity's location in the field
     */
    protected Location getLocation()
    {
        return location;
    }


    /**
     * @return the number of food unit of the entity
     */
    protected int getFoodValue()
    {
        return foodValue;
    }

    /**
     * Make this entity act according to the weather
     * @return List of entities created if the entity reproduced
     */
    abstract public List<? extends Entity> act(Weather currentWeather);
}