import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.ConcurrentModificationException;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 * There are clickable buttons that perform particular actions
 * @version 2019.02.20
 */
public class SimulatorView extends JFrame
{
    // Color used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    // Different strings, labels and buttons that will be displayed on the GUI
    private JLabel stepLabel, population, infoLabel, timeLabel;
    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String TIME_PREFIX = "Time: ";
    private final JButton singleStepButton;
    private final JButton playButton;
    private final JButton playLongButton;

    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;

    // A statistics object computing and storing simulation information
    private FieldStats stats;

    private Simulator simulator; // The simulator that is displayed
    private ViewMode viewMode; // The current view that is displayed (Normal or Disease)
    private FieldView fieldView;


    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(Simulator simulator, int height, int width)
    {
        this.simulator = simulator;
        fieldView = new FieldView(height, width);
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        // Organisation of the GUI
        setTitle("Andes Wildlife Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        timeLabel = new JLabel(TIME_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        // Button that when clicked simulates one step on the simulator
        singleStepButton = new JButton("Simulate 1 Step");
        singleStepButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                simulator.simulateOneStep();
            }
        });

        // Button that when clicked simulates one day on the simulator
        playButton = new JButton("Simulate 1 Day");
        playButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                simulator.simulate(24);
            }
        });

        // Button that when clicked simulates 4000 steps on the simulator
        playLongButton = new JButton("Simulate 4000 Steps");
        playLongButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                simulator.simulate(4000);
            }
        });
        
        // Create display mode radio Normal button
        JRadioButton normalViewModeButton = new JRadioButton("Normal");
        normalViewModeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewMode = ViewMode.NORMAL;
                showStatus(simulator.getStep(), simulator.getField(), simulator.getDay(), simulator.getHour());
            }
        });
        normalViewModeButton.setSelected(true);

        // Create display mode radio Disease button
        JRadioButton sickViewModeButton = new JRadioButton("Disease");
        sickViewModeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewMode = ViewMode.SICK;
                showStatus(simulator.getStep(), simulator.getField(), simulator.getDay(), simulator.getHour());
            }
        });

        // Gather and display the radio buttons
        ButtonGroup viewButtonGroup = new ButtonGroup();
        JPanel viewButtonPane = new JPanel(new FlowLayout());
        viewButtonGroup.add(normalViewModeButton);
        viewButtonGroup.add(sickViewModeButton);
        viewButtonPane.add(normalViewModeButton);
        viewButtonPane.add(sickViewModeButton);

        // Where the GUI is located on the screen
        setLocation(100, 50);

        // Different panel that will display various information (population, time...)
        JPanel infoPane = new JPanel();
        infoPane.setLayout(new BoxLayout(infoPane, BoxLayout.LINE_AXIS));
        infoPane.setBorder(BorderFactory.createEmptyBorder( 5, 10, 5, 10));
        infoPane.add(stepLabel);
        infoPane.add(Box.createGlue());
        infoPane.add(timeLabel);
        infoPane.add(infoLabel);
        infoPane.add(Box.createGlue());

        JPanel runPane = new JPanel();
        runPane.setLayout(new BoxLayout(runPane, BoxLayout.PAGE_AXIS));
        runPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 20, 10));
        runPane.add(singleStepButton);
        runPane.add(Box.createRigidArea(new Dimension(0, 10)));
        runPane.add(playButton);
        runPane.add(Box.createRigidArea(new Dimension(0, 10)));
        runPane.add(playLongButton);

        JPanel viewSettingsPane = new JPanel();
        viewSettingsPane.setLayout(new BorderLayout());
        viewSettingsPane.add(viewButtonPane, BorderLayout.NORTH);
        viewSettingsPane.add(population, BorderLayout.SOUTH);

        Container contents = getContentPane();
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(viewSettingsPane, BorderLayout.SOUTH);
        contents.add(runPane, BorderLayout.EAST);

        pack();
        setVisible(true);

        viewMode = ViewMode.NORMAL;
    }

    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color       The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass)
    {
        Color col = colors.get(animalClass);
        if (col == null) {
            // No color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * @param step  Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field, int day, int hour)
    {
        if (!isVisible()) {
            setVisible(true);
        }

		stepLabel.setText(STEP_PREFIX + step);
		timeLabel.setText(TIME_PREFIX + "Day " + day + " Hour " + String.format("%02d", hour) + " " + Simulator.getWeather().toString());
		stats.reset();

		fieldView.preparePaint();

		for (int row = 0; row < field.getHeight(); row++) {
			for (int col = 0; col < field.getWidth(); col++) {
				boolean isEmpty = true;
				for (int dep = 0; dep < field.getDepth(); dep++) {
					Entity entity = field.getEntityAt(new Location(row, col, dep));
					if (entity != null) {
						if (viewMode == ViewMode.NORMAL) { // the normal mode radio has been selected
							Color color = getColor(entity.getClass());
							// Change the grids according to the time of the day
							if (!simulator.isDay()) {
								color = color.darker();
							}

							stats.incrementCount(entity.getClass());
							fieldView.drawMark(col, row, color);
						}
						else if (viewMode == ViewMode.SICK) { // The sick mode radio has been selected
							stats.incrementCount(entity.getClass());

							if (entity instanceof Animal) {
								// Sick animals are drawn in red
								if (((Animal) entity).isSick()) {
									fieldView.drawMark(col, row, new Color(204,0,0));
								}
								// Non sick animals are in dark gray
								else {
									fieldView.drawMark(col, row, Color.darkGray);
								}
							}
							// Other entities (plants) are drawn in light gray
							else {
								fieldView.drawMark(col, row, Color.lightGray);
							}
						}

						isEmpty = false;
					}
				}
				if (isEmpty) {
					Color color = EMPTY_COLOR;
					// Draw darker free locations at nighttime
					if (!simulator.isDay()) {
						fieldView.drawMark(col, row, color.darker());
					}
					// If it is daytime the color is set to normal
					else {
						fieldView.drawMark(col, row, color);
					}
				}
			}
		}

		stats.countFinished();
		population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
		fieldView.repaint();
	}

	/**
	 * Determine whether the simulation should continue to run.
	 * @return true If there is more than one species alive.
	 */
	public boolean isViable(Field field)
	{
		return stats.isViable(field);
	}

	/**
	 * Provide a graphical view of a rectangular field. This is
	 * a nested class (a class defined inside a class) which
	 * defines a custom component for the user interface. This
	 * component displays the field.
	 * This is rather advanced GUI stuff - you can ignore this
	 * for your project if you like.
	 */
	private class FieldView extends JPanel
	{
		private final int GRID_VIEW_SCALING_FACTOR = 6;

		private int gridWidth, gridHeight;
		private int xScale, yScale;
		private Dimension size;
		private Graphics g;
		private Image fieldImage;

		/**
		 * Create a new FieldView component.
		 */
		private FieldView(int height, int width)
		{
			gridHeight = height;
			gridWidth = width;
			size = new Dimension(0, 0);
		}

		/**
		 * Tell the GUI manager how big we would like it to be
		 */
		public Dimension getPreferredSize()
		{
			return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
					gridHeight * GRID_VIEW_SCALING_FACTOR);
		}

		/**
		 * Prepare for a new round of painting. Since the component
		 * may be resized, compute the scaling factor again.
		 */
		public void preparePaint()
		{
			if (!size.equals(getSize())) {  // if the size has changed...
				size = getSize();
				fieldImage = fieldView.createImage(size.width, size.height);
				g = fieldImage.getGraphics();

				xScale = size.width / gridWidth;
				if (xScale < 1) {
					xScale = GRID_VIEW_SCALING_FACTOR;
				}

				yScale = size.height / gridHeight;
				if (yScale < 1) {
					yScale = GRID_VIEW_SCALING_FACTOR;
				}
			}
		}

		/**
		 * Paint on grid location on this field in a given color.
		 */
		private void drawMark(int x, int y, Color color)
		{
			g.setColor(color);
			g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
		}

		/**
		 * The field view component needs to be redisplayed. Copy the
		 * internal image to screen.
		 */
		public void paintComponent(Graphics g)
		{
			if (fieldImage != null) {
				Dimension currentSize = getSize();
				if (size.equals(currentSize)) {
					g.drawImage(fieldImage, 0, 0, null);
				}
				else {
					// Rescale the previous image.
					g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
				}
			}
		}
	}
}