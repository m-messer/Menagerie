/**
 * Enum of different possible intent that animals can have.
 *
 * @version 2020.02.18
 */

public enum Intent
{
	NOTHING,
	MOVE_TO_FOOD,
	EAT,
	MOVE_TO_MATE,
	MATE,
	SLEEP,
}