import java.util.ArrayList;

/**
 * A superclass composed of methods shared by all the preys
 * @version 2020.02.21
 */
public abstract class Prey extends Animal
{
    /**
     * Create a new predator at location in field.
     * @param randomAge Boolean used to set a random age to predators at the beginning of the simulation
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param isFemale Boolean that states if the predator is a female or a male
     * @param maxFoodLevel Maximum food the predator can eat (simulate a stomach)
     * @param breedingAge Minimum age when the predator can start breeding
     * @param averageAge Life expectancy of the predators
     * @param wakeHour Time of the day when the predator wakes up
     * @param sleepHour Time of the day when the predator goes to sleep
     * @param maxLitterSize Maximum number of children the predator can have
     * @param viewRange Normal (and maximum) view range the predator can have
     * @param breedingRestPeriod Time that an predator will have to wait before being able to breed again
     * @param foodValue Value that the predator is worth (when eaten)
     * @param sicknessProbability Probability that the predator will get infected by the virus
     * @param sicknessDeathProbability Probability that the predator will die when having the virus
     * @param remissionProbability Probability that the predator will survive if he has been infected by the virus
     * @param breedingProbability Probability that the predator can breed at any time
     * @param edibleEntities All the entities that the predator can eat
     */
    public Prey(boolean randomAge, Field field, Location location, boolean isFemale, int[] maxFoodLevel,
                int[] breedingAge, int averageAge, int[] wakeHour, int[] sleepHour, int maxLitterSize, int[] viewRange,
                int[] breedingRestPeriod, int[] foodValue, int[] sicknessProbability, int[] sicknessDeathProbability,
                int[] remissionProbability, double breedingProbability, Class[] edibleEntities)
    {
        super(randomAge, field, location, isFemale, maxFoodLevel, breedingAge, averageAge, wakeHour, sleepHour,
                maxLitterSize, viewRange, breedingRestPeriod, foodValue, sicknessProbability, sicknessDeathProbability,
                remissionProbability, breedingProbability, edibleEntities);
    }

    /**
     * Calculates the intent for the animal's next step
     * and updates currentTarget and currentIntent accordingly.
     */
    @Override
    public void calculateIntent()
    {
        // Base case
        setCurrentIntent(Intent.NOTHING);

        // Purge the targets that have died
        if (getCurrentTarget() != null && !getCurrentTarget().isAlive()) {
            setCurrentTarget(null);

        }

        // Check if the prey is asleep
        if (isAsleep()) {
            setCurrentIntent(Intent.SLEEP);
            setCurrentTarget(null);
        }
        else {
            ArrayList<Entity> targets = new ArrayList<>();

            if (getFoodLevel() < getMaxFoodLevel() * 0.12) { // // The prey is hungry and  will look for target around it
                targets.addAll(findEdibleInRange(getCurrentViewRange()));

                if (!targets.isEmpty()) {
                    // Pick the closest target
                    setCurrentTarget(getClosestEntity(targets));
                    setCurrentIntent(Intent.MOVE_TO_FOOD);
                }
            }
            else { // The prey is not too hungry so it will start looking for mates to breed
                // The prey is looking to the adjacent locations around it to see if there is something it can eat
                for (Location loc : getField().getBusyAdjacentLocationsAllLayers(getLocation())) {
                    targets.add(getField().getEntityAt(loc));
                }

                // Remove all the entities that the prey can't eat
                targets.removeIf(s -> !isEdible(s.getClass()));

                // Eat the entity that is next to it
                if (!targets.isEmpty() && getFoodLevel() < getMaxFoodLevel() * 0.2) {
                    setCurrentTarget(targets.get(0));
                    setCurrentIntent(Intent.EAT);
                }
                else if (canBreed()) { // The prey can breed and so will try to move toward a mate
                    ArrayList<Entity> potentialMates = new ArrayList<>();

                    // Find potential mates at adjacent locations
                    for (Location loc : getField().getBusyAdjacentLocations(getLocation())) {
                        potentialMates.add(getField().getEntityAt(loc));
                    }
                    potentialMates.removeIf(s -> !s.getClass().equals(this.getClass()) || ((Animal) s).isFemale() == !isFemale() || !((Animal) s).canBreed());

                    // If there is a mate next to it, the prey will try to mate with it
                    if (!potentialMates.isEmpty()) {
                        setCurrentTarget(potentialMates.get(0));
                        setCurrentIntent(Intent.MATE);
                    }
                    else { // The prey will try to find a mate further away
                        Location topLeft = getField().findTopLeft(getLocation(), getCurrentViewRange());
                        Location bottomRight = getField().findBottomRight(getLocation(), getCurrentViewRange());

                        // Determine the possible mates in the prey view range
                        potentialMates.addAll(getField().getAllAnimalsInRect(topLeft, bottomRight));
                        potentialMates.removeIf(s -> !s.getClass().equals(this.getClass()) || ((Animal) s).isFemale() == isFemale() || !((Animal) s).canBreed() || s.equals(this));

                        // If there is a mate in the predator view range, the prey will try to move toward it
                        if (!potentialMates.isEmpty()) {
                            setCurrentTarget(getClosestEntity(potentialMates));
                            setCurrentIntent(Intent.MOVE_TO_MATE);
                        }
                    }
                }
            }
        }
    }
}