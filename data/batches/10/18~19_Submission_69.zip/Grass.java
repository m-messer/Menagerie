import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Grass extends Plant
{
    // Characteristics shared by all grass (class variables).

    // The age to which a grass can live.
    private static final int MAX_AGE = 100;
    // the age at which a new grass is formed
    private static final int BREEDING_AGE = 9;
    //variable to store the age of the grass
    private int age;

    /**
     * Create a new grass. A grass may be created with age
     * zero (a new born)
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass( Field field, Location location)
    {
        super(field, location);
        age = 0;
    }

    /**
     * This infects the soil nearby.
     */
    public void setInfection()
    {
        if(infected)
            Location.FERTILITY_PROBABILITY = 0.20;

        else
            Location.FERTILITY_PROBABILITY = 1.15;
    }

    /**
     * This makes new  grass whenever the age of the current grass is limit/10
     * @param newGrass A list to return newly born grass.
     */
    public void act(List<Plant> newGrass)
    {
        setInfection();
         
        incrementAge();

        if(age==BREEDING_AGE)
        {
            createGrass(newGrass);

        }
    
    }

    /**
     * This makes new  grass wherever the soil is fertile in the map in the adjacent location of the current grass
     * @param newGrass A list to return newly born grass.
     */
    private void createGrass(List<Plant> newGrass)
    {

        
        Field field = getField();
        if(getLocation()!=null)
        {

            List<Location> free = field.getFreeAdjacentLocations(getLocation());

            for(Iterator<Location> it = free.iterator(); it.hasNext();){
                Location loc = it.next();
                
                if(loc.getFertility())
                {
                    Grass young = new Grass(field, loc);
                    newGrass.add(young);

                }
            }

        }

    }

    /**
     * Increase the age.
     * This could result in grass death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

}