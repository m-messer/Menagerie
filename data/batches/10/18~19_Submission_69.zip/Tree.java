import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Tree extends Plant
{
    // Characteristics shared by all trees (class variables).
    // To set the maximum age of the tree
    private static final int MAX_AGE = 2000;

    
    //variable to store the age of the tree
    private int age;

    /**
     * Create a new tree. A tree may be created with age
     * zero (a new born)
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tree( Field field, Location location)
    {
        super(field, location);
        age = 0;
    }

    /**
     * This makes new tree whenever the age of the current grass is max age -1
     * @param newTree A list to return newly born tree.
     */
    public void act(List<Plant> newTree)
    {
        int limit = 0;   
        limit = MAX_AGE -1;
        if(age==limit)
        {
            createTree(newTree);

        }
    }

    /**
     * This makes new  tree in the adjacent location of the current tree
     * @param newTree A list to return newly born tree.
     */
    private void createTree(List<Plant> newTree)
    {

        Field field = getField();
        if(getLocation()!=null)
        {

            List<Location> free = field.getFreeAdjacentLocations(getLocation());

            for(Iterator<Location> it = free.iterator(); it.hasNext();){
                Location loc = it.next();
                if(loc.getFertility())
                {
                    Tree young = new Tree(field, loc);
                    newTree.add(young);
                }
            }
        }
    }


}
