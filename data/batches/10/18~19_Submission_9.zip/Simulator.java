import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @Assignment 3
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.03;
    // The probability that a Lion will be created in any given grid position.    
    private static final double LION_CREATION_PROBABILITY = 0.03;
    // The probability that a Tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.03;
    // The probability that a Mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.03;    
    // The probability that a Deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.06;
    // The probability that Grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.10; 
    // Keeps count of the total number of steps and is used to control the seasons
    private int season_steps = 0;
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation and controller for day and night cycle.
    private int step = 0;
    // A graphical view of the simulation.
    private SimulatorView view;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Mouse.class, Color.ORANGE);
        view.setColor(Snake.class, Color.BLUE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Deer.class, Color.BLACK);
        view.setColor(Tiger.class, Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * Keeps track of day and night cycle (simulation is slowed at night) 
     * Keeps track of season change depending on number of steps (season_steps) 
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
            for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            season_steps++;
            if (step <= 12){
                delay(60);   // run slowly; add delay in movement
            }
            
            if (step == 24){
                step = 0; // Reset day and night cycle counter
            }
            // Changes season to Winter
            if (season_steps == 1000){
                Mouse.winterSeason();
                Snake.winterSeason();
                Deer.winterSeason();
                Tiger.winterSeason();
                Lion.winterSeason();
            }
            // Changes season to Spring
            if (season_steps == 2000){
                Mouse.springSeason();
                Snake.springSeason();
                Deer.springSeason();
                Tiger.springSeason();
                Lion.springSeason();
            }
            // Changes season to Summer
            if (season_steps == 3000){
                Mouse.summerSeason();
                Snake.summerSeason();
                Deer.summerSeason();
                Tiger.summerSeason();
                Deer.summerSeason();
            }
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }  
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                boolean genderSetter = Randomizer.gender(); // sets a random gender for the newly created animals
                double INT_SIZE = Grass.getINITIAL_SIZE();  // sets initial size for newly created grass
                boolean isSick = Randomizer.isSick();   // randomly sets if an animal is infected or not for the newly created
                if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location, genderSetter);
                    animals.add(snake);
                }
                if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location, genderSetter, isSick);
                    animals.add(mouse);
                }
                if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location, genderSetter, isSick);
                    animals.add(deer);
                }
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location, genderSetter);
                    animals.add(lion);
                }
                if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location, genderSetter);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, INT_SIZE, field, location);
                    plants.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
