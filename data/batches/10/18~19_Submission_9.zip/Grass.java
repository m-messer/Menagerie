import java.util.List;
import java.util.Random;
public class Grass extends Plant
{
    //rate at which the grass is growing
    private static final double GROWING_RATE = 0.1;
    // the current size of the grass at a time
    private static double CURRENT_SIZE = 0.0;
    //the size the grass starts with
    private static final double INITIAL_SIZE = 0.1;
    //the max size grass can reach
    private static final int MAX_SIZE = 1;
    // A shared random number generator to control growing
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create grass. Grass can be created with initial size
     * or with random size.
     * 
     * @param Alive If true, the grass is alive.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean alive, double size, Field field, Location location)
    {    
        super(field, location);
        size = INITIAL_SIZE;
        if (alive)
        {
            size = rand.nextInt(MAX_SIZE);
        }
        else
        {
            size = INITIAL_SIZE;
        }
    }
    
    /**
     * This is what the grass does most of the time: it keeps growing.
     * In the process, it might be eaten and decrease in size.
     * @param field The field currently occupied.
     * @param newtigers A list to return newly born plants.
     */
    public void act(List<Plant> newGrass)
    {
        incrementSize();
    }
    
    /**
     * allowing the variable initial-size to be used in other classes
     * @returns INITIAL_SIZE;
     */
    public static double getINITIAL_SIZE()
    {
        return INITIAL_SIZE;
    }
    
    /**
     * if the current size is less than max size the grass keeps growing
     */
    public void incrementSize()
    {
        if(CURRENT_SIZE < MAX_SIZE)
        {
            CURRENT_SIZE = CURRENT_SIZE + GROWING_RATE;
        }
    }
    
    /**
     * when the grass is eaten by a deer or a mouse the grass' size decreases
     */
    public void decrementSize(String animal)
    {
        if (animal.equals("Deer"))
        {
            CURRENT_SIZE = CURRENT_SIZE - 0.3;
        }
        if (animal.equals("Mouse"))
        {
            CURRENT_SIZE = CURRENT_SIZE - 0.3;
        }
    }
}