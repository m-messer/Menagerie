import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of plants.
 * Plants are grown at random heights. They grow taller, or shorter when 
 * eaten, and eventually die. 
 *
 * @version 29.02.2021
 */
public abstract class Plant implements Actor
{
    // Whether the plant is alive or not.
    private boolean alive;
    //The plant's location.
    private Location location;
    // The plant's field.
    private Field field;
    //The current height of the plant.
    private int currentHeight;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        currentHeight = 1;
    }
    
    /**
     * Make this plant act - that is: make it do whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     * @param day  If it is day or night.
     * @param weather  The current weather type
     */
    abstract public void act(List<Actor> newPlants, boolean day, WeatherType weather);
    
    /**
     * Gets the plants current height. 
     * @return plant height
     */
    private int getHeight()
    {
        return currentHeight;
    }
    
    /**
     * Sets the height of the plant
     * @param the new height of the plant
     */
    protected void setHeight(int newHeight)
    {
        currentHeight = newHeight;
    }
    
    /**
     * Sets a random age to the animal, within their max age.
     */
    protected void setRandomHeight()
    {
        currentHeight = rand.nextInt(getMaxHeight())+1;
    }
  
    /**
     * A plant grows taller within its set location
     * The height is incremented by a given number if the plant's current height 
     * is less than its maximum height. 
     * @param increment the number the plant should be incremented by
     */
    protected void incrementHeight(int increment){
        if (currentHeight < getMaxHeight()){
            currentHeight += increment;
        }  
    }
    
    /**
     * A plant is being eaten and its height is reduced.
     * The height is decremented by 1. 
     */
    public void decrementHeight(){
        if (currentHeight > 0){
            currentHeight--;
        }  
        else {
            setDead();
        }
    }
    
    /**
     * Check whether the plant is alive or not.
     * @return true  If the plant is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    private void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the plant at a new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Gets the plant's maximum height - that is:the height at which 
     * it stops growing.
     * @return the maximum height of this plant 
     */
    abstract protected int getMaxHeight();
}
