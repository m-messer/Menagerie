/**
 * Represents the time of the simulation, which can be either night or day.
 * Currently, one day lasts 100 steps
 *
 * @version 29.02.2021
 */
public class Time
{    
    //keeps track of the time of day
    private boolean isDay;
    //the number of steps in one day
    private int stepsInADay;

    /**
     * Constructor for objects of class time
     * The simulation starts off in the day time. 
     */
    public Time()
    {
        isDay = true;
        stepsInADay=100;  
    }

    /**
     * Checks whether it is night or day in the simulation.
     * @param step the current step in the simulation. 
     * @return true if it is day. 
     */
    public boolean findDayOrNight(int step)
    {
        int time = step % stepsInADay;
        if (time <= ((stepsInADay/2)-1)){
            isDay = true;
        }
        else{
            isDay = false;
        }
        return isDay;
    }
    
    /**
     * Returns the time of day as a String 
     * @return time in string 
     */
    public String timeString(){
        if (isDay){
            return("Day");
        }
        else{
            return ("Night");
        }
    }
}
