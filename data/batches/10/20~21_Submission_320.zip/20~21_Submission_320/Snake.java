import java.util.*;
/**
 * A model of a snake.
 * Snakes age, mate, move, eat mice, and die. 
 *
 * @version 27.02.2021
 */
public class Snake extends Animal
{
    // Characteristics shared by all snakes (class variables).

    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a snake can live.
    private static final int MAX_AGE = 100;
     // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.09;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single mouse. In effect, this is the
    // number of steps a snake can go before it has to eat again.
    private static final int MOUSE_FOOD_VALUE = 20;
    // The snake's food level, which is increased by eating mice.
    private int foodLevel;
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a snake. A snake may be created with age zero 
     * (a new born) or with a random age.
     * 
     * @param randomAge If true, the snake will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setRandomAge();
            foodLevel = rand.nextInt(MOUSE_FOOD_VALUE);
        }
        else {
            setAge(0);
            foodLevel = MOUSE_FOOD_VALUE;
        }
        setRandomGender();
    }
    
    /**
     * This is what the snake does during the night - it runs 
     * around and hunts mice. In the process it will breed, die
     * of hunger, or die of old age.
     * @param newSnakes A list to return newly born snakes.
     * @param day The time of day it is. 
     * @param weather  The current weather type
     */
    public void act(List<Actor> newSnakes, boolean day, WeatherType weather)
    {
        if (!day){
            incrementHunger();
            incrementAge();
            if(isAlive()) {
                findPartner(newSnakes);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * Returns the maximum age of a snake
     * @return The maximum age of a snake
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * Returns the maximum litter size of a snake. 
     * (Number of children a snake can produce)
     * @return The maximum litter size of a snake
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Returns the breeding probability of a snake
     * @return The breeding probability of a snake
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the breeding age of a snake
     * @return The breeding age of a snake
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
   
    /**
     * Creates and returns a new snake after breeding, in a free adjacent location 
     * to its parents. 
     * @param randomAge  If true, the koala will have a random age.
     * @param field  The field currently occupied.
     * @param location  The location within the field.
     * @return The maximum age, field and location of a new koala
     */
    public Animal newAnimal (boolean randomAge, Field field, Location location)
    {
        return new Snake(randomAge, field, location);
    }  
    
    /**
     * Checks to see if there is a snake of the opposite gender within a 
     * distance of two squares. If so, the pair breed. 
     * @param newAnimal A list to return potential partners.
     */
     private void findPartner(List<Actor> newAnimal)
    {        
        Field field = getField();
        List<Location> adjacent = field.rangeLocations(getLocation());
        
        Object currentAnimal = field.getObjectAt(getLocation()); 
        
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object potentialPartner = field.getObjectAt(where);
            
            if(potentialPartner instanceof Snake){
                Snake partnerSnake = (Snake) potentialPartner;
                Snake thisSnake = (Snake) currentAnimal;
            
                if (thisSnake.checkForFemale() != partnerSnake.checkForFemale()){
                    giveBirth(newAnimal);
                }
            }
        }
    }
    
    /**
     * Look for mice adjacent to the current location.
     * Only the first live mouse is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) { 
                    mouse.setDead();
                    foodLevel = MOUSE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Make this snake more hungry. 
     * This could result in the snake's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
}
