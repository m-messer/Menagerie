import java.util.Random;
/**
 * Represents the weather, which changes randomly after a random number of steps.
 * Weather can affect the behaviour of actors in the simulation.
 *
 * @version 27.02.2021
 */
public class Weather
{
    private static final Random rand = Randomizer.getRandom();
    private boolean canChangeWeather;
    //Will store a random number that determines when the weather should next change. 
    private int durationOfWeather;    
    private WeatherType currentWeather; 
    
    /**
     * Creates a weather with an initial random weather type.
     */
    public Weather()
    {
         canChangeWeather = true;
         changeWeatherType();
    }
    
    /**
     * Checks if enough steps has passed in the simulation for weather to change. 
     * @param step the current step in the simulation.
     * @return true  If the weather can change.
     */

    public boolean isWeatherChange(int step)
    {        
        int time = step % durationOfWeather;
        if (time == 0){
            canChangeWeather = true;            
        }
        else{
            canChangeWeather = false; 
        }
        return canChangeWeather;
    }
    
    /**
     * If the weather can change, randomly select a weather type.
     * If not, keep the current weather
     * @return currentWeather the current weather type 
     */
    public WeatherType changeWeatherType()
    {
        if (canChangeWeather){
            currentWeather = WeatherType.getRandomWeather();
            getRandomWeatherDuration();            
        }        
        return currentWeather;
    }
    
    /**
     * Returns the current weather in a String format 
     * @return currentWeather in String 
     */
    public String weatherString()
    {
        String string = currentWeather.toString().toLowerCase();
        String output = string.substring(0,1).toUpperCase() + string.substring(1);
        return output;
    }
    
    /**
     * Sets a random duration that the current weather type should last for.
     * @return durationOfWeather The duration the weather should last for.
     */
    private int getRandomWeatherDuration(){
        durationOfWeather = rand.nextInt(99)+10;
        return durationOfWeather;
    }
}
