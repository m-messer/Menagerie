import java.util.List;

/**
 * An actor in the jungle simulation 
 *
 * @version 27.02.2021
 */

public interface Actor
 {
    /**
    * Perform the actor's regular behaviour
    * @param newActors A list for storing newly created actors.
    * @param day  If it is day or night.
    * @param weather  The current weather type
    */
    void act(List<Actor> newActors, boolean day, WeatherType weather);

    /**
    * Returns if the actor is still alive
    * @return True If still alive, false if not.
    */
    boolean isAlive();
}