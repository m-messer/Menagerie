import java.util.*;
/**
 * A model of a owl.
 * Owls age,mate, move, eat mice, and die.
 *
 * @version 27.02.2021
 */
public class Owl extends Animal
{
    // Characteristics shared by all owls (class variables).

    // The age at which a owl can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a owl can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a owl breeding.
    private static final double BREEDING_PROBABILITY = 0.09;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single mouse. In effect, this is the
    // number of steps a owl can go before it has to eat again.
    private static final int MOUSE_FOOD_VALUE = 20;
    // The owl's food level, which is increased by eating mice.
    private int foodLevel;
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create an owl. A owl can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the owl will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Owl(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setRandomAge();
            foodLevel = rand.nextInt(MOUSE_FOOD_VALUE);
        }
        else {
            setAge(0);
            foodLevel = MOUSE_FOOD_VALUE;
        }
        setRandomGender();
    }

    /**
     * This is what the owl does during the night - it runs 
     * around and hunts mice. In the process it will breed, 
     * die of hunger,or die of old age.
     * @param newOwl A list to return newly born owl.
     * @param day The time of day it is. 
     * @param weather  The current weather type
     */
    public void act(List<Actor> newOwls, boolean day, WeatherType weather)
    {
        if (!day){
            incrementHunger();
            incrementAge();
            if(isAlive()) {
                //check for potential partners and breed.
                findPartner(newOwls);
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Returns the maximum age of a owl
     * @return The maximum age of a owl
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Returns the maximum litter size of a owl. 
     * (Number of children an owl can produce)
     * @return The maximum litter size of a owl
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the breeding probability of a owl
     * @return The breeding probability of a owl
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the breeding age of a owl
     * @return The breeding age of a owl
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Checks to see if there is a owl of the opposite gender within a 
     * distance of two squares. If so, the pair breed. 
     * @param newAnimal A list to return potential partners.
     */
    private void findPartner(List<Actor> newAnimal)
    {        
        Field field = getField();
        List<Location> adjacent = field.rangeLocations(getLocation());
        
        Object currentAnimal = field.getObjectAt(getLocation()); 

        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object potentialPartner = field.getObjectAt(where);

            if(potentialPartner instanceof Owl){
                Owl partnerOwl = (Owl) potentialPartner;
                Owl thisOwl = (Owl) currentAnimal;

                if (thisOwl.checkForFemale() != partnerOwl.checkForFemale()){
                    giveBirth(newAnimal);
                }
            }
        }
    }
    
    /**
     * Makes a new born owl after breeding.
     * @param randomAge  If true, the owl will have a random age.
     * @param field  The field currently occupied.
     * @param location  The location within the field.
     * @return The maximum age, field and location of a new owl
     */
    public Animal newAnimal (boolean randomAge, Field field, Location location){
        return new Owl(randomAge, field, location);
    }
    
    /**
     * Look for mice adjacent to the current location.
     * Only the first live mouse is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) { 
                    mouse.setDead();
                    foodLevel = MOUSE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Make this owl more hungry. 
     * This could result in the owl's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
}
