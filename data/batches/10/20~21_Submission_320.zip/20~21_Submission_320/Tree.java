import java.util.*;
/**
 * A model of a tree.
 *
 * @version 29.02.2021
 */
public class Tree extends Plant
{   
    // Characteristics shared by all trees (class variables).
    
    //the highest level to which a tree can grow    
    private static final int MAX_HEIGHT = 30; 
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();  
    
    /**
     * Create a new tree.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tree(Field field,Location location)
    {
        super(field, location);
        setRandomHeight();
    }

    /**
     * This is what the tree does all the time: it grows.
     * The tree grows by different amounts depending on the weather. 
     * @param newTree A list to return newly born trees.
     * @param day  If it is day or night.
     * @param weather  The current weather type
     */
    public void act(List<Actor> newTree, boolean day, WeatherType weather)
    {
        if(isAlive()) {
            switch(weather){
                case RAINY:
                incrementHeight(4);
                break;
                
                case CLEAR:
                incrementHeight(2);
                break;
                
                case CLOUDY:
                incrementHeight(1);
                break;
            }
        }
    }
    
    /**
     * Returns the maximum height of a tree
     * @return The maximum height of a tree
     */
    public int getMaxHeight(){
        return MAX_HEIGHT;
    }
}
