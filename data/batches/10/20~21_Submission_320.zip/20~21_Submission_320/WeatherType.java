import java.util.Random;
import java.util.List;

/**
 * Representations for all the types of weathers.
 *
 * @version 28.02.2020
 */
public enum WeatherType
 {
    CLEAR, CLOUDY, RAINY;
    private static final Random rand = Randomizer.getRandom();  
    
    /**
     * Returns a random weather type. 
     * @return a random weather type. 
     */
    public static WeatherType getRandomWeather(){
         return values()[rand.nextInt(values().length)];
    }
 } 
 