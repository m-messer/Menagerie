import java.util.*;
/**
 * A simple model of a mouse.
 * Mice age, move, mate, breed, and die.
 *
 * @version 27.02.2021
 */
public class Mouse extends Animal
{
    // Characteristics shared by all mouses (class variables).

    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 40;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 400;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 1.0;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 30;

    /**
     * Create a new mouse. A mouse may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the mouse will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The location within the field.
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setRandomAge();
        }
        else{
            setAge(0);
        }
        setRandomGender();
    }

    /**
     * This is what the mouse does during the day and night - it runs around 
     * In the process it will breed, die of hunger,or die of old age.
     * @param newMouse A list to return newly born mouse.
     * @param day The time of day it is. 
     * @param weather  The current weather type
     */
    public void act(List<Actor> newMice, boolean day, WeatherType weather)
    {      
        incrementAge();
        if(isAlive()) {
            //giveBirth(newMice); 
            findPartner(newMice);
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Returns the maximum age of a mouse
     * @return The maximum age of a mouse
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Returns the maximum litter size of a mouse. 
     * (Number of children a frog can prouduce)
     * @return The maximum litter size of a mouse
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the breeding probability of a mouse
     * @return The breeding probability of a mouse
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the breeding age of a mouse
     * @return The breeding age of a mouse
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Checks to see if there is a mouse of the opposite gender within a 
     * distance of two squares. If so, the pair breed. 
     * @param newAnimal A list to return potential partners.
     */
    private void findPartner(List<Actor> newAnimal)
    {        
        Field field = getField();
        //List<Location> adjacent = field.adjacentLocations(getLocation());
        List<Location> adjacent = field.rangeLocations(getLocation());
        Object currentAnimal = field.getObjectAt(getLocation()); 

        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object potentialPartner = field.getObjectAt(where);

            if(potentialPartner instanceof Mouse){
                Mouse partnerMouse = (Mouse) potentialPartner;
                Mouse thisMouse = (Mouse) currentAnimal;

                if (thisMouse.checkForFemale() != partnerMouse.checkForFemale()){
                    giveBirth(newAnimal);
                }
            }
        }
    }
    
    /**
     * Makes a new born mouse after breeding.
     * @param randomAge  If true, the owl will have a random age.
     * @param field  The field currently occupied.
     * @param location  The location within the field.
     * @return The maximum age, field and location of a new mouse
     */
    public Animal newAnimal (boolean randomAge, Field field, Location location)
    {
        return new Mouse(randomAge, field, location);
    }
}
