import java.util.*;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 27.02.2021
 */
public abstract class Animal implements Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's age. 
    private int age;
    // Whether the animal is a female or not.
    private boolean isFemale;    
    // A shared random number generator to control breeding and gender.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at a location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        age = 0;
        isFemale = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this animal act - that is: make it do whatever it wants/needs to do
     * during the time of day that it is active.
     * @param newAnimals A list to receive newly born animals.
     * @param day  If it is day or night.
     * @param weather  The current weather type
     */
    abstract public void act(List<Actor> newAnimals, boolean day, WeatherType weather);
    
    /**
     * Sets a random gender to the animal.
     */
    protected void setRandomGender()
    {
         isFemale = rand.nextBoolean();
    }
    
    /**
     * Returns if the animal is a female or not
     * @return true  If the animal is a female
     */
    protected boolean checkForFemale()
    {
        return isFemale; 
    }
    
    /**
     * Sets the age of the animal
     * @param the new age of the animal
     */
    protected void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * Sets a random age to the animal, within their max age.
     */
    protected void setRandomAge()
    {
        age = rand.nextInt(getMaxAge());
    }
    
    /**
     * Gets this animal's maximum age before it can die.
     * @return The maximum age of the animal
     */
    abstract protected int getMaxAge();
    
    /**
     * Increase the age by 1.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }   
 
    /**
     * Check whether the animal is alive or not.
     * @return true  If the animal is alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Gets the breeding age of this animal 
     * @return the breeding age of this animal.
     */
    abstract protected int getBreedingAge();

    /**
     * Returns if the animal can breed, depending on their age 
     * and if they are female.
     * @return True if animal can breed, otherwise false. 
     */
    protected boolean canBreed()
    {
        return ((age>= getBreedingAge())&& checkForFemale());  
    }

    /**
     * Return the breeding probability of this animal 
     * @return the bredding probability of this animal.
     */
    abstract protected double getBreedingProbability();

    /**
     * Return the maximum litter size of this animal 
     * @return the maximum litter size of this animal.
     */
    abstract protected int getMaxLitterSize();
    
    /**
     * Generate a number representing the number of births, if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBornAnimal A list to return newly born animals.
     */
    protected void giveBirth(List<Actor> newBornAnimal)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newBornAnimal.add(newAnimal(false, field, loc));
        }
    }
    
    /**
     * Makes a new born animal after breeding.
     * @param randomAge If true, the animal will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    abstract protected Animal newAnimal(boolean randomAge, Field field, Location location);
}
