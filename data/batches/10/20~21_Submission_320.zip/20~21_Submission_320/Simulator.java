import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A predator-prey simulator, based on a rectangular field
 * containing animals and plants, whose behaviours are affected by
 * time and weather conditions. 
 *
 * @version 01.03.2021
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that an owl will be created in any given grid position.
    private static final double OWL_CREATION_PROBABILITY = 0.02;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.05;  
    // The probability that a giraffe will be created in any given grid position.
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.02;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.01;    
    // The probability that a koala will be created in any given grid position.
    private static final double KOALA_CREATION_PROBABILITY = 0.02;
    // The probability that a tree will be created in any given grid position.    
    private static final double TREE_CREATION_PROBABILITY = 0.05;
    
    // List of actors in the field.
    private List<Actor> actor;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current time of day of this simulation.
    private Time time; 
    //The current weather of the simulation
    private Weather weather;
    
    /**
     * Construct a simulation field with time, weather and default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        time = new Time();
        weather= new Weather();
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actor = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Owl.class, Color.BLUE);
        view.setColor(Giraffe.class, Color.PINK);
        view.setColor(Mouse.class, Color.ORANGE);
        view.setColor(Snake.class, Color.YELLOW);
        view.setColor(Koala.class, Color.RED);
        view.setColor(Tree.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actor.
     */
    public void simulateOneStep()
    {
        step++;
        
        // Provide space for newborn actors.
        List<Actor>newActors = new ArrayList<>();
        
        //Checks if enough steps has passed for the weather type to change
        weather.isWeatherChange(step);
        WeatherType currentWeather = weather.changeWeatherType();
        
        //Checks the current time of day
        boolean currentTime = time.findDayOrNight(step);
        
        // Let all actors act.
        for(Iterator<Actor> it = actor.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors,currentTime, currentWeather);
            if(! actor.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born actors to the main lists.
        actor.addAll(newActors);
        view.showStatus(step, weather.weatherString(), time.timeString(), field);  
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actor.clear();
        populate();
        String weather = "  ";
        String time = "  ";
        
        // Show the starting state in the view.
        view.showStatus(step, weather, time, field);
    }
    
    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    actor.add(owl);      
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    actor.add(mouse);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    actor.add(snake);  
                }            
                else if(rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Giraffe giraffe = new Giraffe(true, field, location);
                    actor.add(giraffe);
                }
                else if(rand.nextDouble() <= KOALA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Koala koala = new Koala(true, field, location);
                    actor.add(koala);
                }
                else if(rand.nextDouble() <= TREE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tree tree = new Tree(field, location);
                    actor.add(tree);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
