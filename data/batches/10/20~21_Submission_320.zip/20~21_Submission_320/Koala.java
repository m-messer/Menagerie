import java.util.*;
/**
 * A model of a koala.
 * Koalas age, mate, move, breed, and die.
 *
 * @version 27.02.2021
 */
public class Koala extends Animal
{
    // Characteristics shared by all koalas (class variables).

    // The age at which a koala can start to breed.
    private static final int BREEDING_AGE = 5; 
    // The age to which a koala can live.
    private static final int MAX_AGE = 100;   
    // The likelihood of a koala breeding.
    private static final double BREEDING_PROBABILITY = 0.04;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;    
    // The food value of a single tree. In effect, this is the
    // number of steps a koala can go before it has to eat again.
    private static final int TREE_FOOD_VALUE = 35;    
    // The koala's food level, which is increased by eating trees.
    private int foodLevel;    
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();  
    
    /**
     * Create a new koala. A koala may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the koala will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Koala(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setRandomAge();
            foodLevel = rand.nextInt(TREE_FOOD_VALUE);
        }
        else {
            setAge(0);
            foodLevel = TREE_FOOD_VALUE;
        }
        setRandomGender();
    }
    
    /**
     * This is what the koala does during the night - it runs 
     * around and consumes trees. In the process it will breed, 
     * die of hunger, or die of old age.
     * @param newKoala A list to return newly born koalas.
     * @param day The time of day it is.
     * @param weather  The current weather type
     */
    public void act(List<Actor> newKoala, boolean day, WeatherType weather)
    {
        if (!day){
            incrementHunger();
            incrementAge();
            if(isAlive()) {
                findPartner(newKoala);
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
   
    /**
     * Returns the maximum age of a koala
     * @return The maximum age of a koala
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * Returns the maximum litter size of a koala. 
     * (Number of children a koala can produce)
     * @return The maximum litter size of a koala
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Returns the breeding probability of a koala
     * @return The breeding probability of a koala
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the breeding age of a koala
     * @return The breeding age of a koala
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
   
    /**
     * Makes a new born koala after breeding.
     * @param randomAge  If true, the koala will have a random age.
     * @param field  The field currently occupied.
     * @param location  The location within the field.
     * @return The maximum age, field and location of a new koala
     */
    public Animal newAnimal (boolean randomAge, Field field, Location location)
    {
        return new Koala(randomAge, field, location);
     }
   
    /**
     * Checks to see if there is a koala of the opposite gender within a 
     * distance of two squares. If so, the pair breed. 
     * @param newAnimal A list to return potential partners.
     */
     private void findPartner(List<Actor> newAnimal)
    {        
        Field field = getField();
        List<Location> adjacent = field.rangeLocations(getLocation());

        Object currentAnimal = field.getObjectAt(getLocation()); 
        
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object potentialPartner = field.getObjectAt(where);
            if(potentialPartner instanceof Koala){
                Koala partnerKoala = (Koala) potentialPartner;
                Koala thisKoala = (Koala) currentAnimal;
            
                if (thisKoala.checkForFemale() != partnerKoala.checkForFemale()){
                    giveBirth(newAnimal);
                }
            }
        }
    }   
    
    /** 
     * Look for trees adjacent to the current location.
     * Only the first live tree is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Tree) {
                Tree tree = (Tree) actor;
                if(tree.isAlive()) { 
                    tree.decrementHeight();
                    foodLevel = TREE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Make this koala more hungry. 
     * This could result in the koala's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
}
