import java.util.ArrayList;
/**
 * A model of the Qwill prey species.
 * Includes a list of items edible for the Qwill.
 *
 * @version 2019.02.22
 */
public class Qwill extends Prey
{
    // remember to look at above fields and change for this class
    private static final ArrayList<Class> edible = new ArrayList<>();
    /**
     * Constructor for objects of class Zog
     */
    public Qwill(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location);
        edible.add(Orchidnus.class);
        edible.add(Dandinus.class);
    }
    
    /**
     * Overrides the equals method from the Object Class.
     */
    public boolean equals(Object object){
        if((Qwill.class).isInstance(object)){
            return true;
        }
        return false;
    }
    
    /**
     * Checks if an object is edible for the Qwill.
     * @return boolean if object is edible to Qwill.
     */
    protected boolean isEdible(Class toEat){
        return edible.contains(toEat);
    }
}