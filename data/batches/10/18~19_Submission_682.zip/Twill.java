import java.util.ArrayList;
/**
 * A model of the Twill prey species.
 * Includes a list of items edible for the Twill during the day and 
 * a list of items edible for the Twill at night.
 *
 * @version 2019.02.22
 */
public class Twill extends Prey
{
    // remember to look at above fields and change for this class
    private static final ArrayList<Class> edible = new ArrayList<>();
    private static final ArrayList<Class> edibleNight = new ArrayList<>();
    /**
     * Constructor for objects of class Zog
     */
    public Twill(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location);
        // Add items to list of edible
        edible.add(Dandinus.class);
        edible.add(Orchidnus.class);
        
        // Add items to list of edible at night
        edibleNight.add(Zwill.class);
        edibleNight.add(Qwill.class);
        edibleNight.add(Dandinus.class);
        edibleNight.add(Orchidnus.class);
    }
    
    /**
     * Overrides the equals method from the Object Class.
     */
    public boolean equals(Object object)
    {
        if((Twill.class).isInstance(object)){
            return true;
        }
        return false;
    }
    
    /**
     * Checks if an object is edible for the Twill during the day.
     * Checks if an object is edible for the Twill during the night.
     * @return boolean if object is edible to Twill.
     */
    protected boolean isEdible(Class toEat){
        if (Simulator.getTimeOfDay())
        {
            return edible.contains(toEat);
        }
        return edibleNight.contains(toEat);
    }
    
 }