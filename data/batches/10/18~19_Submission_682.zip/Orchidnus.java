/**
 * A model of the Orchidnus plant species.
 * Specifies the field, location, and gestation period of
 * the Orchidnus plant.
 *
 * @version 2019.02.22
 */
public class Orchidnus extends Plant
{
    protected static final int GESTATION_PERIOD = 2;
    /**
     * Constructor for objects of class Orchidnus
     */
    public Orchidnus(Field field, Location location)
    {
        super(field,location);
    }
    
    /**
     * Returns gestation period for Orchidnus.
     * @return int gestation period.
     */
    protected int getGestationPeriod()
    {
        return GESTATION_PERIOD;
    }
}
