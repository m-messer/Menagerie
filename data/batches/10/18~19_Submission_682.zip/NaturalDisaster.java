import java.util.Random;
/**
 * A model of Natural Disasters. This is an abstract class.
 *
 * @version 2019.02.22
 */
public abstract class NaturalDisaster extends Organism
{
    protected static final Random rand = Randomizer.getRandom();
    /**
     * Constructor for objects of class NaturalDisaster
     */
    public NaturalDisaster(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * Abstract method of incrementLifeSpan() to be overwritten.
     */
    abstract void incrementLifeSpan();
}
