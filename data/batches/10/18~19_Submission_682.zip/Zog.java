import java.util.ArrayList;
import java.util.Random;
/**
 * A model of the Zog species (of the type Predator).
 * Includes a list of items edible for the Zog.
 *
 * @version 2019.02.22
 */
public class Zog extends Predator
{
    // remember to look at above fields and change for this class
    private static final ArrayList<Class> edible = new ArrayList<>();

    /**
     * Constructor for objects of class Zog
     */
    public Zog(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location);
        Random rand = new Random();
        edible.add(Qwill.class);
        //edible.add(Twill.class);
        //edible.add(Zwill.class);
        edible.add(Dandinus.class);
        
        if(rand.nextInt(1)==0){
            //edible.add(Dandinus.class);
            edible.add(Twill.class);
        }
        
    }
    
    /**
     * Overrides the equals method from the Object Class.
     */
    public boolean equals(Object object)
    {
        if((Zog.class).isInstance(object)){
            return true;
        }
        return false;
    }
    
    /**
     * Checks if an object is edible for the Zog.
     * @return boolean if object is edible to Zog.
     */
    protected boolean isEdible(Class toEat)
    {
        return edible.contains(toEat);
    }
}