import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.HashMap;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.22
 */
public abstract class Organism
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();
    // Whether the organism is alive or not.
    protected boolean alive;
    // Whether the organism is male or female. false denotes female, true denotes male.
    protected boolean gender;
    // The organism's field.
    protected Field field;
    // The organism's position in the field.
    protected Location location;
    // Stores the plants the organism has eaten.
    protected HashMap<Plant,Integer> eaten = new HashMap<>();
    // The organism's infected status.
    protected boolean infected;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        gender = setGender();
        this.field = field;
        setLocation(location);
        infected = false;
    }
    
    /**
     * Make this Organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born Organisms.
     */
    protected void act(List<Organism> newOrganisms){
       for(Plant plant : eaten.keySet()){
           eaten.put(plant,eaten.get(plant)-1);  
       }
       
       for (Plant name: eaten.keySet()){
            String key =name.toString();
            String value = eaten.get(name).toString();   
       }
       
       Iterator<Plant> it = eaten.keySet().iterator();
       while(it.hasNext()){
           Plant key = it.next();
           if(eaten.get(key) == 0){
               gestationReproduction(key,newOrganisms);
               it.remove();
           }
       }
    }
    
    /**
     * Enacts the gestation reproduction cycle of plants within Preys/Predators.
     */
    protected void gestationReproduction(Plant plant,List<Organism> newOrganisms)
    {
        Field field = getField();
        try{
            List<Location> free = field.getFreeAdjacentLocations(getLocation()); 
            if (Orchidnus.class.isInstance(plant)){
               Location loc = free.remove(0);
               Orchidnus young = new Orchidnus(field, loc);
               newOrganisms.add(young);
            }
            if (Dandinus.class.isInstance(plant)){
               Location loc = free.remove(0);
               Dandinus young = new Dandinus(field, loc);
               newOrganisms.add(young);
            }  
        }catch(Exception e){
        }
        
    }
    
    /**
     * Check whether the Organism is alive or not.
     * @return true if the Organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Returns the gender of an Organism.
     * False denotes female, true denotes male.
     */
    protected boolean getGender(){
        return gender;
    }
    
    /**
     * Method to decide the organism's gender
     */
    protected boolean setGender()
    {
        Random random = new Random();
        return random.nextBoolean();
    }
    
    /**
     * Returns if Organism is infected.
     */
    protected boolean getInfected()
    {
        return infected;
    }
    
    /**
     * Sets the infected status of Organism.
     */
    protected void setInfected()
    {
        infected = true;
    }
    
    /**
     * Indicate that the Organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the Organism's location.
     * @return The Organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the Organism at the new location in the given field.
     * @param newLocation The Organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the Organism's field.
     * @return The Organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
    * Helps an organism find food based on its dietary preferences (isEdible()).
    * Iterates through adjacent locations to determine if object type is 
    * Class Plant or Class Prey. Both Plant and Prey are potentially edible.
    * If eaten, the eaten object has its state changed from alive to dead.
    * @return 
    */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Object eater = field.getObjectAt(location);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Plant) {
                if(isEdible(((Organism)organism).getClass() )){
                    Plant plant = (Plant) organism;
                    //check if plant has std and then add STD to plant
                    if(plant.getDisease() == true){
                        ((Organism) eater).setInfected();
                    }
                    if(plant.isAlive()) { 
                        eaten.put(plant,plant.getGestationPeriod());
                        plant.setDead();
                        return where;
                    }
                }
            }
            else if(organism instanceof Prey) {
                if(isEdible(((Organism)organism).getClass() )){
                    Prey prey = (Prey) organism;
                    //Checks if the prey is infected. If so, spreads infection.
                    if(prey.getInfected() == true){
                        ((Organism) eater).setInfected();
                    }
                    //Checks if the prey is alive. If so, sets prey to dead.
                    if(prey.isAlive()) { 
                        prey.setDead();
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Checks to see if an object is edible for an organism. Overridden by Prey/Predator subclasses.
     */
    protected boolean isEdible(Class toEat){
        return true;
    }
}
