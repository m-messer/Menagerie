import java.util.ArrayList;
import java.util.Random;
/**
 * A model of the Bog species (of the type Predator).
 * Includes a list of items edible for the Bog.
 *
 * @version 2019.02.22
 */

public class Bog extends Predator
{
    // remember to look at above fields and change for this class
    private static final ArrayList<Class> edible = new ArrayList<>();
    /**
     * Constructor for objects of class Bog
     */
    public Bog(boolean randomAge, Field field, Location location)
    {
       super(randomAge,field,location);
       Random rand = new Random();
       //edible.add(Qwill.class);
       //edible.add(Twill.class);
       edible.add(Zwill.class);
       edible.add(Orchidnus.class);
       
       if(rand.nextInt(1)==0){
           //edible.add(Orchidnus.class);
           edible.add(Twill.class);
        }
       
    }
    
    /**
     * Overrides the equals method from the Object Class.
     */
    public boolean equals(Object object){
        if((Bog.class).isInstance(object)){
            return true;
        }
        
        return false;
    }
    
    /**
     * Checks if an object is edible for the Bog.
     * @return boolean if object is edible to Bog.
     */
    public boolean isEdible(Class toEat){
        return edible.contains(toEat);
    }
}
