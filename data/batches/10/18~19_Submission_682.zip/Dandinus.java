/**
 * A model of the Dandinus plant species.
 * Specifies the field, location, and gestation period of
 * the Dandinus plant.
 *
 * @version 2019.02.22
 */
public class Dandinus extends Plant
{
    protected static final int GESTATION_PERIOD = 2;
    /**
     * Constructor for objects of class Dandinus.
     */
    public Dandinus(Field field, Location location)
    {
        super(field,location);
    }
    
    /**
     * Returns the gestation period of the Dandinus plant.
     * @return int gestation period.
     */
    protected int getGestationPeriod()
    {
        return GESTATION_PERIOD;
    }
}
