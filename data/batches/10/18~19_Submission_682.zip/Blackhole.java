import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A model for Blackholes, which are a subclass of NaturalDisaster.
 * Blackholes create spaces on the field that turn black and occupy
 * space that cannot be inhabited by other organisms.
 *
 * @version 2019.02.22
 */
public class Blackhole extends NaturalDisaster
{
    protected static final int MAX_LIFESPAN = 16000;
    protected static int currentLife = 0;

    /**
     * Constructor for objects of class Blackhole
     */
    public Blackhole(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * act method to enact creation of blackholes.
     */
    protected void act(List<Organism> newBlackholes)
    {
        Field field = getField();
        if(currentLife == MAX_LIFESPAN){
            field.clearSpecies(Blackhole.class);
        }else{
            incrementLifeSpan();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            ArrayList<Location> free = new ArrayList<>(field.getFreeAdjacentLocations(location));
            Iterator<Location> it = adjacent.iterator();
            if(isAlive()) {
                Location newLocation = field.randomLocation();
                if(newLocation == null) { 
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                if(newLocation != null) {
                    if(!free.isEmpty()){
                        Location loc = free.remove(0);
                        Blackhole young = new Blackhole(field, loc);
                        newBlackholes.add(young);
                    }
                }
            }
        }

    }
    
    /**
     * @Overwrites incrementLifeSpan() abstract method in NaturalDisaster
     */
    protected void incrementLifeSpan(){
        currentLife++;
    }
}
