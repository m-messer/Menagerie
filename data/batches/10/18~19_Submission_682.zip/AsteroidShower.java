import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A model for AsteroidShower, which are a subclass of NaturalDisaster.
 * Asteroid Showers create spaces on the field that turn gray and occupy
 * space that cannot be inhabited by other organisms.
 *
 * @version 2019.02.22
 */
public class AsteroidShower extends NaturalDisaster
{
    protected static final int MAX_LIFESPAN = 9000;
    protected static int currentLife = 0;

    /**
     * Constructor for objects of class AsteroidShower
     */
    public AsteroidShower(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * act method to enact the asteroid shower.
     */
    protected void act(List<Organism> newAsteroidShowers)
    {
        Field field = getField();
        if(currentLife == MAX_LIFESPAN){
            field.clearSpecies(AsteroidShower.class);
        }else{
            incrementLifeSpan();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            ArrayList<Location> free = new ArrayList<>(field.getFreeAdjacentLocations(location));
            Iterator<Location> it = adjacent.iterator();
            if(isAlive()) {
                Location newLocation = field.randomLocation();
                if(newLocation == null) { 
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                if(newLocation != null) {
                    if(!free.isEmpty()){
                        Location loc = free.remove(0);
                        AsteroidShower young = new AsteroidShower(field, loc);
                        newAsteroidShowers.add(young);
                    }
                }
            }
        }

    }
    
    /**
     * @Overwrites incrementLifeSpan() abstract method in NaturalDisaster
     */
    protected void incrementLifeSpan(){
        currentLife++;
    }
}
