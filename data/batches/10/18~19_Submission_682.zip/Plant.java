import java.util.List;
import java.util.Random;
/**
 * A model of a plant.
 * Plants age, reproduce asexually, reproduce via gestation,
 * and may hold disease.
 *
 * @version 2019.02.22
 */
public class Plant extends Organism
{
    // Characteristics shared by all Plants (class variables).
    // The probability of a plant have a disease
    protected static final double DISEASE_PROBABILITY = 0.17;
    // The probability of a plant breeding asexually
    protected static final double BREEDING_PROBABILITY = 0.11;
    // The maximum number of offspring a plant can have
    protected static final int MAX_LITTER_SIZE = 1;
    // Random generator
    protected static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics of plants
    // Disease status
    protected boolean disease;
    
    /**
     * Constructor for Plant Class
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
        disease = false;
        setDisease();
    }
    
    /**
     * This is what the plant does most of the time: it might breed or get eaten.
     * @param newPlants A list to return newly born Plants.
     */
    protected void act(List<Organism> newPlants)
    {
        // FIGURE OUT LOCATION
        if(isAlive()) {
            asexualReproduction(newPlants);
            Location newLocation = field.randomLocation();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Returns the gestation period of plant.
     */
    protected int getGestationPeriod()
    {
        return 1; //returns temporary value to be overridden by subclasses
    }
    
    /**
     * Performs asexual reproduction by filling free adjacent spaces with
     * a limited number of offspring of the same species of plant.
     */
    protected void asexualReproduction(List<Organism> newPlants)
    {
        // New plants are born into adjacent locations
        Field field = getField();
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        Object progenitor = field.getObjectAt(location); //the parent plant
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            if (Orchidnus.class.isInstance(progenitor)){
               Location loc = free.remove(0);
               Orchidnus young = new Orchidnus(field, loc);
               newPlants.add(young);
            }
            else if (Dandinus.class.isInstance(progenitor)){
               Location loc = free.remove(0);
               Dandinus young = new Dandinus(field, loc);
               newPlants.add(young);
            }
        }
    }

    /**
     * Sets the disease status.
     */
    protected void setDisease()
    {
        if (rand.nextDouble() <= DISEASE_PROBABILITY){
            disease = true;
        }
        
    }
    
    /**
     * Returns the disease status.
     */
    protected boolean getDisease()
    {
        return disease;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;}
        return births;
    }
}
    
