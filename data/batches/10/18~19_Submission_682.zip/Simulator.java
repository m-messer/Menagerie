import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Preys and Predatores.
 *
 * @version 2019.02.22
 */
public class Simulator
{
    private static final Random rand = Randomizer.getRandom();
    
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Predator will be created in any given grid position.
    private static final double Predator_CREATION_PROBABILITY = 0.04;
    // The probability that a Prey will be created in any given grid position.
    private static final double Prey_CREATION_PROBABILITY = 0.04;  
    // The probability that a Plant will be created in any given grid position.
    private static final double Plant_CREATION_PROBABILITY = 0.04;    

    // List of Organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    public static boolean timeOfDay = true; //false is night, true is day
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        // Setting the colors
        view.setColor(Zog.class, Color.RED);
        view.setColor(Bog.class, Color.BLUE);
        view.setColor(Twill.class, Color.CYAN);
        view.setColor(Qwill.class, Color.YELLOW);
        view.setColor(Zwill.class, Color.ORANGE);
        view.setColor(Dandinus.class, Color.GREEN);
        view.setColor(Orchidnus.class, Color.MAGENTA);
        view.setColor(AsteroidShower.class, Color.LIGHT_GRAY);
        view.setColor(Blackhole.class, Color.BLACK);
        view.setColor(Crater.class, Color.WHITE);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
           simulateOneStep();
           naturalDisasterSimulation();
           delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Predator and Prey.
     */
    public void simulateOneStep()
    {
        step++;
        updateTime();
        // Provide space for newborn Organisms.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms);
            if(! organism.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born Predators and Preys to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, timeOfDay, field);
    }
    
    /**
     * Updates time of day depending on the step progression.
     */
    public void updateTime()
    {
        if (step % 48 > 24){
            timeOfDay = true; //day
        }
        else{
            timeOfDay = false; //night
        }
    }
    
    /**
     * Returns the time of day.
     * @return boolean true for day, false for night
     */
    public static boolean getTimeOfDay()
    {
        return timeOfDay;
    }
    
    /**
     * Returns the step during the progression of the simulation.
     * @return int the number of steps
     */
    public int getStep()
    {
        return step;
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, timeOfDay, field);
    }
    
    /**
     * Planet enters wormhole and population resets planet in a timeloop.
     */
    private void wormhole()
    {
        delay(10);
        organisms.clear();
        populate();
        view.showStatus(step, timeOfDay, field); 
        //System.out.println("WORMHOLE");
    }
    
    /**
     * Planet enters blackhole and population in large areas of the field is removed.
     */
    private void blackhole()
    {
        Blackhole blackhole = new Blackhole(field,getDisasterLocation());
        organisms.add(blackhole);
        //System.out.println("BLACKHOLE");
    }
    
    /**
     * Planet experiences a crater, which creates large areas where the organisms
     * cannot roam. Craters eventually disappear and areas can be inhabited again.
     */
    private void crater(){
        Crater crater = new Crater(field,getDisasterLocation());
        organisms.add(crater);
        //System.out.println("CRATER");
    }
    
    /**
     * Asteroid shower hits the planet, killing off organisms in the location
     * of the asteriods, which also grow in radiation radius.
     */
    private void asteroidShower(){
        AsteroidShower asteroid = new AsteroidShower(field,getDisasterLocation());
        organisms.add(asteroid);
        //System.out.println("ASTEROID SHOWER");
    }
    
    /**
     * Generates the location of a Natural Disaster.
     * @return Location the location of the natural disaster.
     */
    private Location getDisasterLocation(){
        Random rand = new Random();
        int row = rand.nextInt(field.getDepth()-1);
        int col = rand.nextInt(field.getWidth()-1);
        Location location1 = new Location(row,col);
        return location1;
    }
    
    /**
     * Creates random occurrences of natural disasters during the night.
     * Examples of natural disasters:
     *      > Wormholes
     *      > Blackholes
     *      > Craters
     *      > Asteroid Showers
     */
    private void naturalDisasterSimulation()
    {
        if (timeOfDay == false) { //only occur at night
            if(rand.nextInt(30) == 0){
                if(rand.nextInt(1)==0){
                    wormhole();
                }
            }
        }
        if ((step == (rand.nextInt(700)+600))) {
            for (int i = 0; i <= (rand.nextInt(5)+2); i++){ //random amount of asteroids from 2-7
                asteroidShower();
            }
        }
        if (step == (rand.nextInt(300)+200)) {
            blackhole();
        }
        if (step == (rand.nextInt(1)+60)) {
            crater();
        }
    }
    
    /**
     * Randomly populate the field with Predators and Preys.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Predator_CREATION_PROBABILITY) {
                    Location location1 = new Location(row, col);
                    Bog bog = new Bog(true, field, location1);
                    organisms.add(bog);
                }else if(rand.nextDouble() <= Predator_CREATION_PROBABILITY) {
                    Location location2 = new Location(row, col);
                    Zog zog = new Zog(true, field, location2);
                    organisms.add(zog);
                }else if(rand.nextDouble() <= Prey_CREATION_PROBABILITY) {
                    Location location3 = new Location(row, col);
                    Twill twill = new Twill(true, field, location3);
                    organisms.add(twill);
                }else if(rand.nextDouble() <= Prey_CREATION_PROBABILITY) {
                    Location location4 = new Location(row, col);
                    Qwill qwill = new Qwill(true, field, location4);
                    organisms.add(qwill);
                }else if(rand.nextDouble() <= Prey_CREATION_PROBABILITY) {
                    Location location5 = new Location(row, col);
                    Zwill zwill = new Zwill(true, field, location5);
                    organisms.add(zwill);
                }else if(rand.nextDouble() <= Plant_CREATION_PROBABILITY) {
                    Location location6 = new Location(row, col);
                    Orchidnus orchidnus = new Orchidnus(field, location6);
                    organisms.add(orchidnus);
                }else if(rand.nextDouble() <= Plant_CREATION_PROBABILITY) {
                    Location location7 = new Location(row, col);
                    Dandinus dandinus = new Dandinus(field, location7);
                    organisms.add(dandinus);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
