import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Predator.
 * Predators age, move, breed, eat, and die.
 *
 * @version 2019.02.22
 */
public class Predator extends Organism
{
    // Characteristics shared by all Predators (class variables).
    // The age at which a Predator can start to breed.
    protected static final int BREEDING_AGE = 15;
    // The age to which a Predator can live.
    protected static final int MAX_AGE = 150;
    // The likelihood of a Predator breeding.
    protected static final double BREEDING_PROBABILITY = 0.10;
    // The maximum number of births.
    protected static final int MAX_LITTER_SIZE = 3;
    // The food value of a single Prey. In effect, this is the
    // number of steps a Predator can go before it has to eat again.
    protected static final int FOOD_VALUE = 10;
    //move this one to the plant
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Predator's age.
    protected int age;
    // The Predator's food level, which is increased by eating Preys.
    protected int foodLevel;

    /**
     * Create a Predator. A Predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Predator does most of the time: it hunts for
     * Preys/Plants. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newPredators A list to return newly born Predators.
     */
    protected void act(List<Organism> newPredators)
    {
        super.act(newPredators);
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveSexualBirth(newPredators);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }

    }

    /**
     * Increase the age. This could result in the Predator's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Predator more hungry. This could result in the Predator's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for Preys/Plants adjacent to the current location.
     * Only the first live Prey/Plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        super.findFood();
        foodLevel += FOOD_VALUE;
        return null;
    }
   
    /**
     * Checks if an object is edible for a specific organism.
     * Method enacted in Bog and Zog subclasses.
     * @return boolean if object is edible
     */
    protected boolean isEdible(Class toEat)
    {
        return true;
    }

    /**
     * Check whether or not this Predator is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPredators A list to return newly born Predators.
     * @return number of births as a result of reproduction.
     */
    protected int giveSexualBirth(List<Organism> newPredators)
    {
       Field field = getField();
       List<Location> adjacent = field.adjacentLocations(getLocation());
       ArrayList<Location> free = new ArrayList<>(field.getFreeAdjacentLocations(location));
       Object mate1 = field.getObjectAt(location);
       Iterator<Location> it = adjacent.iterator();
       int numBirths = 0;
       while(it.hasNext()) {
            Location where = it.next();
            Object mate2 = field.getObjectAt(where);
            // determines if mates are of the same species
            if (mate1.equals(mate2)){
                // determines if both mates are capable of breeding
                if (((Predator)mate1).canBreed() && ((Predator)mate2).canBreed()){ 
                    // determines if mates are of different genders
                    if (((Organism) mate1).getGender() != ((Organism) mate2).getGender()){
                        // only female prey can procreate
                        //prevents repeated reproduction by the same couple in same instance
                        if (((Organism) mate1).getGender() == false){
                            // if either are STD positive, they will not give birth
                            if (!(((Organism)mate1).getInfected() || ((Organism)mate2).getInfected())){
                                  int births = breed();
                                  for(int b = 0; b < births && free.size() > 0; b++) {
                                      if (Bog.class.isInstance(mate1)){
                                           Location loc = free.remove(0);
                                           Bog young = new Bog(false, field, loc);
                                           newPredators.add(young);}
                                       else if (Zog.class.isInstance(mate1)){
                                           Location loc = free.remove(0);
                                           Zog young = new Zog(false, field, loc);
                                           newPredators.add(young);}
                                  }
                            }
                        }
                    }
                }
            }
        }
       return numBirths;
    }
    
    /**
     * Overrides the equals method from the Object Class.
     */
    public boolean equals(Object object)
    {
        if((Predator.class).isInstance(object)){
            return true;
        }
        return false;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Predator can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
