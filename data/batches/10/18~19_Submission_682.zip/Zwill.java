import java.util.ArrayList;
/**
 * A model of the Zwill prey species.
 * Includes a list of items edible for the Zwill.
 *
 * @version 2019.02.22
 */
public class Zwill extends Prey
{
    // remember to look at above fields and change for this class
    private static final ArrayList<Class> edible = new ArrayList<>();
    /**
     * Constructor for objects of class Zog
     */
    public Zwill (boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location);
        edible.add(Dandinus.class);
        edible.add(Orchidnus.class);
    }
    
    /**
     * Overrides the equals method from the Object Class.
     */
    public boolean equals(Object object)
    {
        if((Zwill.class).isInstance(object)){
            return true;
        }
        return false;
    }
    
    /**
     * Checks if an object is edible for the Zwill.
     * @return boolean if object is edible to Zwill.
     */
    protected boolean isEdible(Class toEat)
    {
        return edible.contains(toEat);
    }
}