import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits, mice, birds, snakes, foxes and plants.
 *
 * @version 2021.03.17
 */

public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.02;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.02;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.08;
    // The probability that a bird will be created in any given grid position.
    private static final double BIRD_CREATION_PROBABILITY = 0.08;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.08;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.2;
   
    // Variables for required for the contents of the simulation
    // List of organisms in the field.
    private List<CellOrganism> organisms;
    // The current state of the time.
    private Time time;
    // The current state of the weather.
    private Weather weather;
    // A String that stores the current time.
    private String timeString;
    // A String that stores the current weather.
    private String weatherString;
    // An index that stores the current time.
    private int timeIndex;
    // An index that stores the current weather.
    private int weatherIndex;
    
    // Variables for required the simulation to run properly
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The total number of steps of the simulation
    private int totalStep;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    } 

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // Create the contents of the simulation
        organisms = new ArrayList<>();
        timeString = new String();
        String timeString = "Morning";
        weatherIndex = 0;

        //Create the field of simulation
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        // Setup the colors of the organisms in the field
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Bird.class, Color.PINK);
        view.setColor(Mouse.class, Color.YELLOW);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Snake.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (total number of steps can be initialised).
     */
    public void runLongSimulation()
    {
        totalStep = 4000;
        simulate(totalStep);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            simulateTimeOneStep();
            simulateWeather();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newly created organism.
        List<CellOrganism> newOrganisms = new ArrayList<>();

        for(Iterator<CellOrganism> it = organisms.iterator(); it.hasNext(); ) {
            CellOrganism organism = it.next();
            if (timeString.equals("Morning") || timeString.equals("Noon") ){
                
                if (organism instanceof Prey){ 
                    organism.hunt(newOrganisms);
                    organism.giveBirth(newOrganisms);
                    checkOrganismDead(organism, it);
                }

                if( (!weatherString.equals("Fog") || !weatherString.equals("Storm")) 
                && organism instanceof Snake){ 
                    organism.hunt(newOrganisms);
                    organism.giveBirth(newOrganisms);
                    checkOrganismDead(organism, it);
                } 

                if (organism instanceof Fox){
                    organism.giveBirth(newOrganisms);
                    checkOrganismDead(organism, it);
                }

            } else if ((timeString.equals("Evening") || timeString.equals("Night")) 
            && (!weatherString.equals("Fog") || !weatherString.equals("Storm")) 
            && organism instanceof Fox){
                organism.hunt(newOrganisms);
                checkOrganismDead(organism, it);
            }

            if(probabilityComparator(PLANT_CREATION_PROBABILITY)) {
                Plant plant = populatePlants(randomRowGenerator(), randomColumnGenerator());
            }
        }
        // Add the newly born foxes and rabbits to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field, timeString, weatherString);
    }
    
    /**
     * Check whether the organisms is alive or not 
     * within the list of organisms in the field.
     * @param organism an organism within the iterator.
     * @param it an iterator object that contains organisms.
     */
    public void checkOrganismDead(CellOrganism organism, Iterator<CellOrganism> it){
        if(! organism.isAlive()) {
            it.remove();
        } 
    }
    
    /**
     * Run a simulation of the time.
     * Each time this method is called, it will increase the time index.
     * This ensures that the time is simulated in order of the time of day. 
     * @ return String The time of the simulation.
     */
    public String simulateTimeOneStep()
    {
        time = new Time();

        List<String> timeArray = time.getTimeValues();
        timeString = new String();
        timeIndex++;

        if ( timeIndex >= 0 && timeIndex < timeArray.size()){
            timeString = timeArray.get(timeIndex);
            return timeString;
        } else {
            timeIndex = 0;
            return timeString = timeArray.get(0);
        }
    }
    
    /**
     * Run a simulation of the weather.
     * Each time this method is called, it will randomly choose 
     * one of the 5 different option for the weather.
     * When the whole simulation is run, the value  will change every 100 steps.
     * @ return String The weather of the simulation.
     */
    public String simulateWeather()
    {
        weather = new Weather();

        List<String> weatherArray = weather.getWeatherValues();
        weatherString = new String();

        if ((totalStep % step) == 100){
            Random rand = Randomizer.getRandom();
            weatherIndex = rand.nextInt(weatherArray.size());
            weatherIndex++;
        }

        if (weatherIndex >= 0 && weatherIndex < weatherArray.size()){
            weatherString = weatherArray.get(weatherIndex);
            return weatherString;
        } else {
            weatherIndex = 0;
            return weatherString = weatherArray.get(0);
        }
    }
    
    /**
     * Return the time of the simulation.
     * @return String The time of the simulation.
     */
    public String getTimeString(){
        return timeString;
    }
    
    /**
     * Return the weather of the simulation.
     * @return String The weather of the simulation.
     */
    public String getWeatherString(){
        return weatherString;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, timeString, weatherString);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(probabilityComparator(FOX_CREATION_PROBABILITY)){
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    organisms.add(fox);
                } else if(probabilityComparator(RABBIT_CREATION_PROBABILITY)){
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    organisms.add(rabbit);
                } else if(probabilityComparator(SNAKE_CREATION_PROBABILITY)){
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    organisms.add(snake);
                } else if(probabilityComparator(BIRD_CREATION_PROBABILITY)){
                    Location location = new Location(row, col);
                    Bird bird = new Bird(true, field, location);
                    organisms.add(bird);
                } else if(probabilityComparator(MOUSE_CREATION_PROBABILITY)){
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    organisms.add(mouse);
                } else if(probabilityComparator(PLANT_CREATION_PROBABILITY)){
                    Plant plant = populatePlants(row, col);
                    organisms.add(plant);
                }
            }
            // else leave the location empty.
        }
    }

    /**
     * Populate the field with plants.
     * @param row Row coordinate of the location.
     * @param col Column coordinate of the location.
     */
    private Plant populatePlants(int row, int col){
        Location location = new Location(row, col);
        Plant plant = new Plant(true, field, location);
        return plant;
    }
    
    /**
     * Check if a randomly generated number is less than 
     * the maximum number of probability value.
     * @param probability the maximum number of probability value.
     * @return true if randomly generated number is less than max probabilty.
     */
    private boolean probabilityComparator(double probability)
    {
        Random rand = Randomizer.getRandom();
        return rand.nextDouble() <= probability;
    }
    
    /**
     * Generate a random row within the field 
     * @return int a randomly generated row
     */
    private int randomRowGenerator(){
        Random rand = Randomizer.getRandom();
        return rand.nextInt(field.getDepth());
    }
    
    /**
     * Generate a random column within the field 
     * @return int a randomly generated column
     */
    private int randomColumnGenerator(){
        Random rand = Randomizer.getRandom();
        return rand.nextInt(field.getWidth());
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
