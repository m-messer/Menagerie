import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a fox.
 * Foxes age, move, eat, and die.
 *
 * @version 2021.03.17
 */ 
public class Fox extends Predator
{
    // Characteristics shared by all foxes (class variables).
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
   
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        maxAge = MAX_AGE;
        breedingProbability = BREEDING_PROBABILITY;
        maxLitterSize = MAX_LITTER_SIZE;
        breedingAge = BREEDING_AGE;

        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(PREY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PREY_FOOD_VALUE;
        }
    }

    /**
     * This method makes the fox hunt for food (one of the preys). 
     * In the process, it might die of hunger or die of old age.  
     * @param newFoxes A list to return newly born foxes.
     */
    public void hunt(List<CellOrganism> newFoxes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {           
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    public void giveBirth(List<CellOrganism> newFoxes)
    {
        // New foxes are born into adjacent locations.
        if(isAlive()) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            if(field.isMaleAdjacent(getLocation()) == true){
                int births = breed();
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    Fox young = new Fox(false, field, loc);
                    newFoxes.add(young);
                }
            }
        }
    }
}
