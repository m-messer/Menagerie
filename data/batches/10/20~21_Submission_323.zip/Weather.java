import java.util.List;
import java.util.ArrayList;
/**
 * Weather class containing the different types of weather 
 *
 * @version 2021.03.17
 */

public class Weather
{
    // List containing all possible values for the weather
    private List<String> weatherArray;
    
    /**
     * Represent a weather in the simulation.
     */
    public Weather(){
        weatherArray = new ArrayList<String>();
        
        weatherArray.add("Sun");
        weatherArray.add("Rain");
        weatherArray.add("Snow");
        weatherArray.add("Fog");
        weatherArray.add("Storm");
    }
    
    /**
     * @return an array with all the weather values.
     */
    public List<String> getWeatherValues() {
        return weatherArray;
    }
}
