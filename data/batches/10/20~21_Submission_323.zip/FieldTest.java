import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class FieldTest.
 *
 * @version (a version number or a date)
 */
public class FieldTest
{
    /**
     * Default constructor for test class FieldTest
     */
    public FieldTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void maleAdjacentTest()
    {
        Field field1 = new Field(500, 500);
        Location location1 = new Location(49, 49);
        Location location2 = new Location(49, 50);
        Location location3 = new Location(49, 51);
        Location location4 = new Location(50, 49);
        Location location5 = new Location(50, 50);
        Location location6 = new Location(50, 51);
        Location location7 = new Location(51, 49);
        Location location8 = new Location(51, 50);
        Location location9 = new Location(51, 51);
        Bird bird1 = new Bird(true, field1, location1);
        Bird bird2 = new Bird(true, field1, location2);
        Bird bird3 = new Bird(true, field1, location3);
        Bird bird4 = new Bird(true, field1, location4);
        Bird bird5 = new Bird(true, field1, location5);
        Bird bird6 = new Bird(true, field1, location6);
        Bird bird7 = new Bird(true, field1, location7);
        Bird bird8 = new Bird(true, field1, location8);
        Bird bird9 = new Bird(true, field1, location9);
        assertNotNull(field1.getMaleAdjacentLocations(location5));
    }
    
    @Test
    public void infectedAdjacentTest()
    {
        Field field1 = new Field(500, 500);
        Location location1 = new Location(49, 49);
        Location location2 = new Location(49, 50);
        Location location3 = new Location(49, 51);
        Location location4 = new Location(50, 49);
        Location location5 = new Location(50, 50);
        Location location6 = new Location(50, 51);
        Location location7 = new Location(51, 49);
        Location location8 = new Location(51, 50);
        Location location9 = new Location(51, 51);
        Bird bird1 = new Bird(true, field1, location1);
        Bird bird2 = new Bird(true, field1, location2);
        Bird bird3 = new Bird(true, field1, location3);
        Bird bird4 = new Bird(true, field1, location4);
        Bird bird5 = new Bird(true, field1, location5);
        Bird bird6 = new Bird(true, field1, location6);
        Bird bird7 = new Bird(true, field1, location7);
        Bird bird8 = new Bird(true, field1, location8);
        Bird bird9 = new Bird(true, field1, location9);
        assertNotNull(field1.getInfectedAdjacentLocations(location5));
    }
}

