import java.util.List;
import java.util.ArrayList;
/**
 * Time class containing the different times of the day
 *
 * @version 2021.03.17
 */

public class Time
{
    // List containing all possible values for time
    private List<String> timeArray;
    
    /**
     * Represent a time in the simulation.
     */
    public Time(){
        timeArray = new ArrayList<String>();
        
        timeArray.add("Morning");
        timeArray.add("Noon");
        timeArray.add("Evening");
        timeArray.add("Night");
    }
    
    /**
     * @return an array with all the time values.
     */
    public List<String> getTimeValues() {
        return timeArray;
    }
}
