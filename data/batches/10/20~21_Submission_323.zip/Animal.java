import java.util.List;
import java.util.Random;
/**
 * An abstract class representing shared characteristics of animals.
 *
 * @version 2021.03.17
 */
public abstract class Animal extends CellOrganism
{
    // List of variables that would be constants 
    //in the animals' individual class (class variables).
    protected static double breedingProbability;
    protected static int maxLitterSize;
    protected static int breedingAge;
    protected int infectionProbability;
    
    //List of variables that characterise the animal (instance fields).
    protected boolean isMale;
    protected boolean isInfected;
    protected int foodLevel;
    protected int infectionLevel;
    
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        isMale = rand.nextBoolean();
        isInfected = false;
    }
    
    /**
     * Check the animal's gender.
     * @return true if the animal is male.
     */
    public boolean getGender()
    {
        return isMale;
    }

    /**
     * Check whether the animal is infected or not.
     * @return true if the animal is infected.
     */
    public boolean getInfected()
    {
        return isInfected;
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * If the animal is infected, their health will decrease. 
     * This could result in the animal's death.
     */
    protected void incrementDisease()
    {
        if (isInfected = true){
            infectionLevel--;
            isInfected = false;
            if(infectionLevel <= 0){
                setDead();
                //System.out.println("The Animal Has Died"); 
                //(Uncomment above to check if animal has died from disease)
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && probabilityComparator(breedingProbability)) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age and is female.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        if (isMale == false && age >= breedingAge){
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * An animal can get infected if a disease enters its body 
     * or if it comes close to another infected animal.
     * The disease entering its body is represented by 
     * a random probabilty generator.
     */
    protected void infect(){
        Field field = getField();
        if(probabilityComparator(infectionProbability)){
          isInfected = true;
        } else if(field.isInfectedAdjacent(getLocation()) == true){
          isInfected = true;
        } else {
          isInfected = false;
        }
    }
    
    /**
     * Check if a randomly generated number is less than 
     * the maximum number of probability value.
     * @param double the maximum number of probability value.
     * @return true if randomly generated number is less than max probabilty.
     */
    private boolean probabilityComparator(double probability)
    {
        Random rand = Randomizer.getRandom();
        return rand.nextDouble() <= probability;
    }
}
