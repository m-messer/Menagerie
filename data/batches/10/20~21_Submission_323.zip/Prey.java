import java.util.List;
import java.util.Iterator;
/**
 * An abstract class representing shared characteristics of preys.
 *
 * @version 2021.03.17
 */
public abstract class Prey extends Animal
{
    // The food value of a single plant. In effect, this is the
    // number of steps a prey can go before it has to eat again.
    protected static final int PLANT_FOOD_VALUE = 5;

    /**
     * Create a new prey at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location)
    {
        super(field, location);
    } 
    
    /**
     * Make the prey find food. 
     * The preys are herbivores and can only eat plants.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Plant) {
                Plant plant = (Plant) organism;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}