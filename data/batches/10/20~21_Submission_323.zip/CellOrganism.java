import java.util.List;
import java.util.Random;
/**
 * An abstract class representing shared characteristics of organisms.
 *
 * @version 2021.03.17
 */
public abstract class CellOrganism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // The organism's age
    protected int age;
    // The organism's maximum age
    protected static int maxAge;
    // A shared random number generator.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public CellOrganism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * An abstract method for the animals to hunt.
     * @param newOrganisms A list to receive new organisms.
     */
    abstract protected void hunt(List<CellOrganism> newOrganisms);
    
    /**
     * An abstract method for the animals to give birth.
     * @param newOrganisms A list to receive new organisms.
     */
    abstract protected void giveBirth(List<CellOrganism> newOrganisms);
    
    /**
     * An abstract method to obtain the animal's gender.
     */
    abstract protected boolean getGender();
    
    /**
     * An abstract method to determine if an animal is infected.
     */
    abstract protected boolean getInfected();
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Increase the age.
     * This could result in the animals's death.
     */ 
    protected void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }
}
