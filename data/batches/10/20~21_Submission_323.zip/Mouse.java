import java.util.List;
import java.util.Random;
/**
 * A simple model of a mouse.
 * Mice age, move, breed, get sick and die.
 *
 * @version 2021.03.17
 */
public class Mouse extends Prey
{
    // Characteristics shared by all rabbits (class variables).
    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The likelihood of a mouse getting infected.
    private static final double INFECTION_PROBABILITY = 0.001;
    // The maximum health of the mouse.
    private static final int INFECTION_LEVEL = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Mouse. A mouse can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * @param randomAge If true, the mouse will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        maxAge = MAX_AGE;
        breedingProbability = BREEDING_PROBABILITY;
        maxLitterSize = MAX_LITTER_SIZE;
        breedingAge = BREEDING_AGE;
        infectionLevel = INFECTION_LEVEL;

        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }

    /**
     * This method makes the bird hunt for food (plants). 
     * In the process, it might die of hunger, die of disease 
     * or die of old age. 
     * @param newMice A list to return newly born mice.
     */
    public void hunt(List<CellOrganism> newMice)
    {
        incrementAge();
        incrementHunger();
        incrementDisease();
        if(isAlive()) {
            // Infect animal if within probability 
            // or adjacent to another infected.
            infect();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this mouse is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born rabbits.
     */
    public void giveBirth(List<CellOrganism> newMice)
    {
        // New mice are born into adjacent locations.
        if(isAlive()) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            if(field.isMaleAdjacent(getLocation()) == true){
                int births = breed();
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    Mouse young = new Mouse(false, field, loc);
                    newMice.add(young);
                }
            }
        }
    }
}
