import java.util.List;
import java.util.Iterator;
/**
 * An abstract class representing shared characteristics of predators.
 *
 * @version 2021.03.17
 */
 
public abstract class Predator extends Animal
{
    // The food value of a single prey. In effect, this is the
    // number of steps a predator can go before it has to eat again.
    protected static final int PREY_FOOD_VALUE = 5;

    /**
     * Create a new predator at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(Field field, Location location)
    {
        super(field, location);
    } 

    /**
     * Make the predator find food. 
     * The predators are carnivores and can only eat "prey" animals.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
