import java.util.List;
import java.util.Random;
/**
 * A simple model of a plant.
 *
 * @version 2021.03.17
 */

public class Plant extends CellOrganism
{
    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant (boolean randomAge, Field field, Location location){
        super(field, location);
    }
    
    /**
     * The following method is here to ensure 
     * that the overall code works with inheritance.
     * They are not used in any way within the simulation.
     */
    protected void hunt(List<CellOrganism> newOrganisms){
    }
    
    /**
     * The following method is here to ensure 
     * that the overall code works with inheritance.
     * They are not used in any way within the simulation.
     */
    protected void giveBirth(List<CellOrganism> newOrganisms){
    }
    
    /**
     * The following method is here to ensure 
     * that the overall code works with inheritance.
     * They are not used in any way within the simulation.
     */
    protected boolean getGender(){
        return true;
    }
    
    /**
     * The following method is here to ensure 
     * that the overall code works with inheritance.
     * They are not used in any way within the simulation.
     */
    protected boolean getInfected(){
        return true;
    }
}
