import java.util.List;
import java.util.Random;

/**
 * A model of a Fire.
 * Fire ages, spreads, acts, has an effect on Organisms and deactivates.
 * 
 * @version 2020.02.23
 */
public class Fire extends Weather
{
    // Characteristics shared by all Fire (class variables).
    // The age to which a Fire can be active.
    private static final int MAX_AGE = 3;
    // The likelihood of a Fire spreading.
    private static final double SPREADING_PROBABILITY = 1;
    // The maximum number of spread.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control spreading.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Fire's age.
    private int age;

    /**
     * Create a new Fire. A Fire is created with age zero.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fire(Field field, Location location)
    {
        super(field, location);
        age = 0;
    }
    
    /**
     * This is what the Fire does most of the time. 
     * It spreads and burns Organisms which are in the same location as Fire. 
     * It will become inactive after it reaches MAX_AGE.
     * 
     * @param newFire A list to return newly created Fire.
     */
    public void act(List<Weather> newFire)
    {
        incrementAge();
        if(isActive()) {
            burn();
            spread(newFire);            
        }
    }

    /**
     * Increase the age.
     * This could result in the Rain's deactivation.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setInactive();
        }
    }
    
    /**
     * Burns Organisms which are in the same location as Fire.
     * If there is an Organism in the same location as Fire
     * an Organism will be set to dead.
     */
    private void burn()
    {
        Field field = getField();
        Location search = this.getWeatherLocation();
        Object object = field.getObjectAt(search);
        if(object != null && object instanceof Organism){
            Organism organism = (Organism) object;
            if(organism.isAlive()){
                organism.setDead();
            }
        }
        Object object1 = field.getPlantObjectAt(search);
        if(object1 != null && object1 instanceof Plant){
            Organism plant = (Organism) object1;
            if(plant.isAlive()){
                plant.setPlantDead();
            }
        }
    }
    
    /**
     * Sets age to a given value.
     * @param age A integer to which the current age value will be set to.
     */
    protected void setAge(int age)
    {
       this.age = age; 
    }
    
    /**
     * Check whether or not this Fire is to spread at this step.
     * New Fire will be made into free adjacent locations.
     * @param newFire A list to return newly created Fire.
     */
    protected void spread(List<Weather> newFire)
    {
        // New Rains are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentWeatherLocations(getWeatherLocation());
        int births = spread();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fire young = new Fire(field, loc);
            young.setAge(age++);
            newFire.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of new Fire,
     * if it can spread.
     * @return The number of new Fire (may be zero).
     */
    private int spread()
    {
        int births = 0;
        if(rand.nextDouble()<= SPREADING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
