import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a alien
 * (like the acid spitting, nightmare inducing aliens from ALIEN the movie).
 * Alien age, move, eat, breed, become diseased, sick or die of old age.
 *
 * @version 2016.02.29 (2)
 */
public class Alien extends Organism
{
    // Characteristics shared by all Alien (class variables).
    
    // The age at which a alien can start to breed.
    private static final int BREEDING_AGE = 0;
    // The age to which a alien can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a alien breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // number of steps a alien can go before it has to eat again.
    private static final int FOOD_VALUE = 20;
    //The food value of a new born
    private static final int INITIAL_FOOD_VALUE = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The alien's age.
    private int age;
    // The alien's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a alien. A alien can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the alien will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Alien(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = INITIAL_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the alien does most of the time: it hunts for
     * prey In the process, it might breed, die of hunger,
     * or die of old age.
     * @param day check whether is is day.
     * @param newAlien A list to return newly born Alien.
     */
    public void act(List<Organism> newAlien,boolean day)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() ) {            
            // Move towards a source of food if found.
            Location newLocation = hunt(newAlien);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation !=null && checkIfDiseased(newLocation)){
                    //checks if the new location is diseased
                    //if so they become diseased
                    becomeDiseased(newAlien, newLocation);
                }
            else if(newLocation !=null){
                    setLocation(newLocation);
                }
            
            else {
                // Overcrowding.
                setDead();
            }
        }
        hydrated=false;
    }

    /**
     * Increase the age.
     * This could result in the alien's death.
     * When sick aging is accelerated.
     */
    private void incrementAge()
    {
        if(isSick()){
            age += SICK_INCREMENT_AGE;
        }
        else{
            age++;
        }
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this alien more hungry. This could result in the alien's death.
     */ 
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for prey near the current location.
     * Only the first live animal is killed.
     * @return Where food was found, or null if it wasn't.
     */
    private Location hunt(List<Organism> newAlien)
    {
        Field field = getField();
        List<Location> adjacent = field.surroundingLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Human) {
                Human organism = (Human) Organism; //if a human is found they are killed and used as a host for the new alien
                if(organism.isAlive()) { 
                    getSick(organism);  //get sick if what they ate was sick  
                    organism.setDead();        
                    giveBirth(newAlien);
                    return where;
                }
            }
            if(Organism instanceof Deer || Organism instanceof Chicken) {
                Organism organism = (Organism) Organism;
                if(organism.isAlive()) { 
                    getSick(organism);   //get sick if what they ate was sick 
                    organism.setDead();        
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * The Alien becomes diseased and a diseased Alien takes its place
     * @param newAlien A list to return the newly added DAlien.
     * @param newLocation A location to place the DPredator.
     */
    private void becomeDiseased(List<Organism> newDAlien,Location newLocation)
    {
        Field field = getField();
        setDead();
        Location loc = newLocation;
        DAlien ill = new DAlien(true, field, loc);
        newDAlien.add(ill);
    }
    
    /**
     * Check whether or not this alien is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAlien A list to return newly born Alien.
     */
    private void giveBirth(List<Organism> newAlien)
    {
        // New Alien are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Alien young = new Alien(false, field, loc);
            newAlien.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A alien can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
