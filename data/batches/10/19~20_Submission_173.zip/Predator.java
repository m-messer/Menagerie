import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a predator (like the movie Predator).
 * Predators can age, move, hunt, call other predators, become diseased, sick or die of old age.
 * They hunt aliens and humans but do not eat them.
 *
 * @version 2016.02.29 (2)
 */
public class Predator extends Organism
{
    // Characteristics shared by all Predator (class variables).
    
    // The age at which a predator can start to call reinforcements.
    private static final int CALLING_AGE = 3;
    // The age to which a predator can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a predator breeding.
    private static final double CALLING_PROBABILITY = 1;
    // The maximum number of allies.
    private static final int MAX_ALLIES = 1;
    // A shared random number generator to control calling.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The predator's age.
    private int age;

    /**
     * Create a predator with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(Field field, Location location)
    {
        super(field, location);
        age = rand.nextInt(MAX_AGE);
    }
    
    /**
     * This is what the predator does most of the time: it hunts humans and aliens. In the process, it might call reinforcements 
     * become sick or diseased or die of old age.
     * @param day check whether is is day.
     * @param newPredator A list to return newly born Predator.
     */
    public void act(List<Organism> newPredator, boolean day)
    {
        incrementAge();
        if(isAlive()) {
            // The Predator searches for prey.
            Location newLocation = hunt(newPredator);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
           
            if(newLocation !=null && checkIfDiseased(newLocation)){ //check if the new loaction is diseased
                    becomeDiseased(newPredator, newLocation);
                }
            else if(newLocation !=null){
                    setLocation(newLocation);
                }
            
            else {
                // Overcrowding.
                setDead();
            }
        }
        hydrated=false;
    }

    /**
     * Increase the age.
     * This could result in the Predator's death.
     * When sick aging is accelerated.
     */
    private void incrementAge()
    {
        if(isSick()){
            age += SICK_INCREMENT_AGE;
        }
        else{
            age++;
        }
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * The Predator becomes diseased and a diseased Predator takes its place
     * @param newPredator A list to return the newly added DPredator.
     * @param newLocation A location to place the DPredator.
     */
    private void becomeDiseased(List<Organism> newDPredator,Location newLocation)
    {
        Field field = getField();
        setDead();
        Location loc = newLocation;
        DPredator ill = new DPredator(field, loc);
        newDPredator.add(ill);
    }
    
    /**
     * The predator hunts for aliens and humans.
     * The predators kills humans and aliens.
     * Also if an alien is found reinforcements can be called
     * @return Where prey was found, or null if it wasn't.
     */
    private Location hunt(List<Organism> newPredator)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Alien ) {;
                Alien organism = (Alien) Organism;
                if(organism.isAlive()) { 
                    organism.setDead();
                     //The predators calls on reinforcements
                    callReinforcements(newPredator);
                    return where;
                }
            }
            
            if(Organism instanceof Human) {;
                Organism organism = (Organism) Organism;
                if(organism.isAlive()) { 
                    organism.setDead();        
                    return where;
                }
            }
        }
        return null; 
    }
    
    /**
     * Check whether or not this predator is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPredator A list to return newly born Predator.
     */
    private void callReinforcements(List<Organism> newPredator)
    {
        // New Predator are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int allies = call();
        for(int b = 0; b < allies && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Predator ally = new Predator(field, loc);
            newPredator.add(ally);
        }
    }
        
    /**
     * Generate a number representing the number of reinforcements,
     * @return The number of reinforcements (may be zero).
     */
    private int call()
    {
        int allies = 0;
        if(canCall() && rand.nextDouble() <= CALLING_PROBABILITY) {
            allies = rand.nextInt(MAX_ALLIES) + 1;
        }
        return allies;
    }

    /**
     * A predator can call for others if it has reached a certain age.
     */
    private boolean canCall()
    {
        return age >= CALLING_AGE;
    }
}
