import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A model of a Rain.
 * Rain ages, spreads, acts, has an effect on Organisms and deactivates.
 * 
 * @version 2020.02.23
 */
public class Rain extends Weather
{
    // Characteristics shared by all Rain (class variables).
    // The age to which a Rain can active.
    private static final int MAX_AGE = 4;
    // The likelihood of a Rain spreading.
    private static final double SPREADING_PROBABILITY = 1;
    // The maximum number of new Rain.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control spreading.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Rain's age.
    private int age;

    /**
     * Create a new Fire. A Fire is created with age zero.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rain(Field field, Location location)
    {
        super(field, location);
        age = 0;
    }
    
    /**
     * This is what the Rain does most of the time. 
     * It spreads, puts out Fire and hydrates Organisms 
     * which are in the same location. 
     * It will become inactive after it reaches MAX_AGE.
     * 
     * @param newRain A list to return newly created Rain.
     */
    public void act(List<Weather> newRain)
    {
        incrementAge();
        if(isActive()) {
            hydrate();
            putOutFire();
            spread(newRain);            
        }
    }
    
    /**
     * Puts out Fire which is in adjacent locations.
     */
    private void putOutFire()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getWeatherLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object weather = field.getWeatherObjectAt(where);
            if(weather instanceof Fire) {
                Fire fire = (Fire) weather;
                if(fire.isActive()) {
                    fire.setInactive();        
                }
            }
        }
    }
    
    /**
     * Increase the age.
     * This could result in the Rain's deactivation.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setInactive();
        }
    }
    
    /**
     * Hydrates Organisms which are in the same location
     * as Rain.
     */
    private void hydrate()
    {
        Field field = getField();
        Location search = this.getWeatherLocation();
        Object object = field.getObjectAt(search);
        if(object != null && object instanceof Organism){
            Organism organism = (Organism) object;
            if(organism.isAlive()){
                organism.setHydrated();
            }
        }
        Object object1 = field.getPlantObjectAt(search);
        if(object1 != null && object1 instanceof Plant){
            Organism plant = (Organism) object1;
            if(plant.isAlive()){
                plant.setHydrated();
            }
        }
    }
    
    /**
     * Sets age to a given value.
     * @param age A integer to which the current age is set to.
     */
    protected void setAge(int age)
    {
       this.age = age; 
    }
    
    /**
     * Check whether or not this Rain is to spread at this step.
     * New Rain will be made into free adjacent locations.
     * @param newRain A list to return newly created Rain.
     */
    protected void spread(List<Weather> newRain)
    {
        // New Rains are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentWeatherLocations(getWeatherLocation());
        int births = spread();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rain young = new Rain(field, loc);
            young.setAge(age++);
            newRain.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of new Rain,
     * if it can spread.
     * @return The number of new Rain (may be zero).
     */
    private int spread()
    {
        int births = 0;
        if(rand.nextDouble()<= SPREADING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
