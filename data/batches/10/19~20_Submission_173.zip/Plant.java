import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a plant.
 * Plants can age, breed, become sick, diseased and die.
 *
 * @version 2016.02.29 (2)
 */
public class Plant extends Organism
{
    // Characteristics shared by all Plant (class variables).

    
    // The age to which a plant can live.
    private static final int MAX_AGE = 36;
    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    
    // The plant's age.
    private int age;

    /**
     * Create a new plant.
     * 
     * @param randomAge If true, the plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
        age = 0;
    }
    
    /**
     * This is what the plant does most of the time. Sometimes it will hunt,breed, become diseased, sick or die of old age.
     * @param newPlant A list to return newly born Plant.
     * @param day check whether is is day.
     */
    public void act(List<Organism> newPlant,boolean day)
    {
        incrementAge();
        if(isAlive()) {
           whenHydrated(); //check if the plant is hydrated
           if(day == true){//plants only spread in the day
            spread(newPlant);            
           }   
           if(findDisease()) //checks if the plant has been exposed to disease
           {
                becomeDiseased(newPlant);
           }
        }
        hydrated=false;
    }

    /**
     * Increase the age.
     * This could result in the plant's death.
     * When sick aging is accelerated.
     */
    private void incrementAge()
    {
        if(isSick()){
            age += SICK_INCREMENT_AGE;
        }
        else{
            age++;
        }
        if(age > MAX_AGE) {
            setPlantDead();
        }
    }
    
    /**
     * Turns back the clock on the plant as it is hydrated
     */
    private void whenHydrated()
    {
        if(hydrated)
        {
            age= age/2;
        }
    }
    
    /**
     * Look for disease that affects plants adjacent to the current location.
     */
    private boolean findDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        int counter = 0;
        while(it.hasNext()) {
            Location where = it.next();
            if(checkIfDiseased(where)){
                return true;
            }
        }
        return false;
    }
    
    /**
     * The plant becomes diseased and a diseased plant takes its place
     * @param newplant A list to return newly added Dplant.
     * @param newLocation A location to place the Dplant.
     */
    protected void becomeDiseased(List<Organism> newDPlant)
    {
        Field field = getField();
        Location loc = this.getLocation();
        setPlantDead();
        DPlant ill = new DPlant(field, loc);
        newDPlant.add(ill);
    }
    
    /**
     * Check whether or not this plant is to spread at this step.
     * New births will be made into free adjacent locations.
     * @param newPlant A list to return newly born Plant.
     */
    private void spread(List<Organism> newPlant)
    {
        // New Plant are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentPlantLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(field, loc);
            newPlant.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

}
