import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A simple weather simulator, based on a rectangular field
 * 
 * @version 2020.02.23
 */
public class WeatherControl
{
    // The probability that rain will be created
    private static final double RAIN_PROBABILITY = 0.05;
    // The probability that fire will be created
    private static final double FIRE_PROBABILITY = 0.01;
    // The probability that rain will be created in any given grid position.
    private static final double RAIN_CREATION_PROBABILITY = 0.03;
    // The probability that fire will be created in any given grid position.
    private static final double FIRE_CREATION_PROBABILITY = 0.02;
    
    // The WeatherControl's field.
    private static Field field;
    // List of Weather in the field.
    private List<Weather> Weather;
    
    /**
     * Constructor for objects of class WeatherControl
     * 
     * @param field The field currently occupied.
     */
    public WeatherControl(Field field)
    {
        this.field = field;
        Weather = new ArrayList<Weather>();
    }
    
    /**
     * 
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * weather subclasses: fire and rain.
     */
    public void actWeather()
    {
        getWeather();
        List<Weather> newWeather = new ArrayList<>();
        for(Iterator<Weather> it = Weather.iterator(); it.hasNext(); ) {
            Weather Weather = it.next();
            Weather.act(newWeather);
            if(! Weather.isActive()) {
                it.remove();
            }
        }
        Weather.addAll(newWeather);
    }
    
    /**
     * Randomly call methods which populate weather
     */
    private void getWeather()
    {
        Random rand = new Random();
        if(rand.nextDouble()<= RAIN_PROBABILITY){
            createRain();
        }
        if(rand.nextDouble()<= FIRE_PROBABILITY){
            createFire();
        }
    }
        
    /**
     * Randomly populate the field with rain.
     */
    public void createRain()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= RAIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rain rain = new Rain(field, location);
                    Weather.add(rain);
                    rain.spread(Weather);
                }
                // else leave the location empty.
            }
        }
        
    }
    
    /**
     * Randomly populate the field with fire.
     */
    public void createFire()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FIRE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fire fire = new Fire(field, location);
                    Weather.add(fire);
                    fire.spread(Weather);
                }
                // else leave the location empty.
            }
        }
    }
    
}
