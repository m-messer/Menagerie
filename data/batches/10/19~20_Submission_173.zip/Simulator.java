import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing many organisms as well as weather.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 130;
    // The probability that an alien will be created in any given grid position.
    private static final double ALIEN_CREATION_PROBABILITY = 0.015;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.03;   
    // The probability that a human will be created in any given grid position.
    private static final double HUMAN_CREATION_PROBABILITY = 0.055;
    // The probability that a predator will be created in any given grid position.
    private static final double PREDATOR_CREATION_PROBABILITY = 0.005;  
    // The probability that a chicken will be created in any given grid position.
    private static final double CHICKEN_CREATION_PROBABILITY = 0.03;
    // The probability that disease will be created in any given grid position.
    private static final double DISEASE_CREATION_PROBABILITY = 0.05;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.3;
    // The probability that plants will spread seeds.
    private static final double SEED_CREATION_PROBABILITY = 0.07;
    // The probability that a seed will grow a plant in any given grid loaction.
    private static final double SEED_AMOUNT = 0.007;
    //The step at which aliens appears
    private static final int APPEAR_ALIEN = 12;
    //The step at which deer appears
    private static final int APPEAR_DEER = 3;
    //The step at which humans appears
    private static final int APPEAR_HUMAN = 7;
    //The step at which predators appears
    private static final int APPEAR_PREDATOR = 16;
    //The step at which chickens appears
    private static final int APPEAR_CHICKEN = 5;
    //The step at which disease appears
    private static final int APPEAR_DISEASE =0;
    //The step at which plants grow in
    private static final int APPEAR_PLANT = 0;
    //The number of hours passed per step
    private static final int ONE_STEP_HOURS = 4;
    
    //Whether is it day or night
    private static boolean day = false;
    
    //The time
    private int time;
    //The number of days passed
    private int dayCount;
    // List of Organisms in the field.
    private List<Organism> Organisms;
    //Controls the state of the weather
    private WeatherControl weatherControl;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        Organisms = new ArrayList<>();
        field = new Field(depth, width);
        weatherControl = new WeatherControl(field);
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Chicken.class, Color.ORANGE);
        view.setColor(DChicken.class, Color.ORANGE.darker());
        view.setColor(Alien.class, Color.CYAN.brighter());
        view.setColor(DAlien.class, Color.CYAN.darker().darker());
        view.setColor(Deer.class, Color.GRAY);
        view.setColor(DDeer.class, Color.GRAY.darker());
        view.setColor(Human.class, Color.YELLOW);
        view.setColor(DHuman.class, Color.YELLOW.darker());
        view.setColor(Predator.class, Color.PINK);
        view.setColor(DPredator.class, Color.PINK.darker());
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(DPlant.class, Color.GREEN.darker().darker());
        view.setColor(Disease.class, Color.BLACK.darker());
        view.setColor(Rain.class, Color.BLUE.brighter());
        view.setColor(Fire.class, Color.RED.brighter());
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps ; step++) {//&& view.isViable(field)
            simulateOneStep();
            delay(500);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * object and instance of weather
     */
    public void simulateOneStep()
    {
        step++;
        addOrganisms();
        addExtraOrganisms();
        setTime();
        weatherControl.actWeather();
        // Provide space for newborn Organisms.
        List<Organism> newOrganisms = new ArrayList<>(); 
        // Let all organisms act.
        for(Iterator<Organism> it = Organisms.iterator(); it.hasNext(); ) {
            Organism Organism = it.next();
            Organism.act(newOrganisms,this.day);
            if(! Organism.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born organisms to the main lists.
        Organisms.addAll(newOrganisms);
        view.showStatus(step, field,this.day, dayCount, time);
    }
    
    /**
     * Populates specific organisms at specific steps
     */
    private void addOrganisms()
    { 
        if(step == APPEAR_PREDATOR){
            populatePredator();
        }
        if(step == APPEAR_HUMAN){
            populateHuman();
        }
        if(step == APPEAR_PLANT){
            populatePlant();
        }
        if(step == APPEAR_ALIEN){
            populateAlien();
        }
        if(step == APPEAR_DEER){
            populateDeer();
        }
        if(step == APPEAR_CHICKEN){
            populateChicken();
        }
    }
    
    /**
     * Randomly populates the field with new disease and newly grown plants
     */
    private void addExtraOrganisms()
    {
        Random rand = Randomizer.getRandom();
        if(rand.nextDouble() <= DISEASE_CREATION_PROBABILITY){
            populateDisease();
        }
        if(rand.nextDouble() <= SEED_CREATION_PROBABILITY){
            spreadSeeds();
        }
    }
    
    /**
     * Calculates the current time and determines whether it is day or night
     */
    private void setTime()
    {
        time = (time + ONE_STEP_HOURS) % 24;
        if(time == 0){
            dayCount++;
        }
        if(8 <= time && time <= 20){
            day = true;
        } 
        else{
            day = false;
        }
     }
    
    /** 
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        Organisms.clear();
        field.clear();
        //populate();
        addOrganisms();
        // Show the starting state in the view.
        view.showStatus(step, field,this.day, dayCount, time);
    }
    
    /**
     * Randomly populates the field with predators
     */
    private void populatePredator()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PREDATOR_CREATION_PROBABILITY && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Predator predator = new Predator(field, location);
                    Organisms.add(predator);
                }
            }
        }
    }
    
    /**
     * Randomly populates the field with plants
     */
    private void populatePlant()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    Organisms.add(plant);
                }
            }
        }
    }
    
    /**
     * Randomly populates the field with new plants
     */
    private void spreadSeeds()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SEED_AMOUNT && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    Organisms.add(plant);
                }
            }
        }
    }
    
    /**
     * Randomly populates the field with Aliens
     */
    private void populateAlien()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= ALIEN_CREATION_PROBABILITY && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Alien alien = new Alien(true, field, location);
                    Organisms.add(alien);
                }
            }
        }
    }
    
    /**
     * Randomly populates the field with humans
     */
    private void populateHuman()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HUMAN_CREATION_PROBABILITY && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Human human = new Human(true, field, location);
                    Organisms.add(human);
                }
            }
        }
    }
    
    /**
     * Randomly populates the field with chickens
     */
    private void populateChicken()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= CHICKEN_CREATION_PROBABILITY && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Chicken chicken = new Chicken(true, field, location);
                    Organisms.add(chicken); 
                }
            }
        }
    }
    
    /**
     * Randomly populates the field with deer
     */
    private void populateDeer()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= DEER_CREATION_PROBABILITY && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    Organisms.add(deer);
                }
            }
        }
    }
    
    /**
     * Randomly populates the field with disease
     */
    private void populateDisease()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= DISEASE_CREATION_PROBABILITY && field.getObjectAt(row,col)==null) {
                    Location location = new Location(row, col);
                    Disease disease = new Disease(false, field, location);
                    Organisms.add(disease);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
