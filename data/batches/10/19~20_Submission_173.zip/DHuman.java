import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A model of a diseased Human (DHuman).
 * Diseased Human (DHuman) age, convert other Humans to Hippies (DHumans), eat and die.
 * 
 * Diseased Human (DHuman) is like a Hippie.
 * They only move during the night when it is raining.
 * They do not breed, but convert Humans to DHumans.
 * They eat plants.
 * 
 * @version 2020.02.23
 */
public class DHuman extends Human
{
    // Characteristics shared by all diseased Human (DHuman) (class variables).
    // The age at which a diseased Human (DHuman) can start to breed.
    private static final int LOVING_AGE = 0;
    // The age to which a diseased Human (DHuman) can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a diseased Human (DHuman) breeding.
    private static final double LOVING_PROBABILITY = 0.35;
    // The food value. Number of steps a diseased Human (DHuman) can go before it has to eat again.
    private static final int FOOD_VALUE = 20;
    // The initial food value. Number of steps a new born diseased Human (DHuman) can go before it has to eat again.
    private static final int INITIAL_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The diseased Human's (DHuman) age.
    private int age;
    // The diseased Human's (DHuman) food level, which is increased by eating plants.
    private int foodLevel;

    /**
     * Create a diseased Human (DHuman). A diseased Human (DHuman) can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the diseased Human (DHuman) will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public DHuman(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }
    
    /**
     * This is what the diseased Human (DHuman) does most of the time - it 
     * converts Humans to DHumans and eats plants. In the process,
     * get sick, might move in the night time when hydrated, die of hunger, or die of old age.
     * Behaviour is different for the day and night.
     * After the step boolean field hydrated is set to false.
     * 
     * @param newDHuman A list to return newly born diseased Human (DHuman).
     * @param day A boolean value which indicates whether it is a day or night
     */
    public void act(List<Organism> newDHuman, boolean day)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(day == true) {
                spreadLove(newDHuman);
                findFood();
            }
            else {
                whenHydrated();
            }
        }
        hydrated = false;
    }

    /**
     * Check if sick. When sick increase the age by sick age
     * else increase the age normally. 
     * This could result in the Human's death.
     */
    private void incrementAge()
    {
        if(isSick()) {
            age += SICK_INCREMENT_AGE;
        }
        else {
            age++;
        }
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check if hydrated (if Rain was in the same location)
     * When hydrated move to a different location.
     * If there is no free space to move, become sick.
     */
    private void whenHydrated(){
        if(hydrated){
            Location newLocation = getField().freeAdjacentLocation(getLocation());// See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setSick();
            }
       }
    }
    
    /**
     * Make this diseased Human(DHuman) more hungry. This could result in the diseased Human's(DHuman) death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * If the eaten plant is sick, then DHuman gets sick.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    private void findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getPlantObjectAt(where);
            if(Organism instanceof Plant) {
                Plant plant = (Plant) Organism;
                if(plant.isAlive()) { 
                    getSick(plant);    
                    plant.setPlantDead();        
                    foodLevel = FOOD_VALUE;
                }
            }
        }
    }
    
    /**
     * Check whether or not this Hippie is to spread the movement.
     * Check the surrounding locations. If there is a Human, but not a DHuman
     * set the Human to a hippy.
     * New DHuman will be created in the Human's location
     * 
     * @param newDHuman A list to return newly born DHuman.
     */
    private void spreadLove(List<Organism> newDHuman)
    {
        // New DHuman are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.surroundingLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Human) {
                Human organism = (Human) Organism;
                if(!(organism instanceof DHuman)) {
                    if(organism.isAlive() && canSpread()) { 
                        organism.becomeDiseased(newDHuman, organism.getLocation());
                    }
                }
            }
        }
    }

    /**
     * A diseased Hippie can spread the love if they have reached a certain age.
     * 
     * @return true if the hippy can spread the movement, false otherwise.
     */
    private boolean canSpread()
    {
        if(age >= LOVING_AGE && rand.nextDouble() <= LOVING_PROBABILITY){
             return true;
        }
        return false;
    }
}
