import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A model of a diseased Deer (DDeer).
 * A ravenous diseased deer that hungers for chicken
 * Deer age, move, breed, eat and die.
 * 
 * @version 2020.02.23
 */
public class DDeer extends Deer
{
    // Characteristics shared by all diseased Deer (DDeer) (class variables).

    // The age at which a diseased Deer (DDeer) can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a diseased Deer (DDeer) can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a diseased Deer (DDeer) breeding.   
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value. Number of steps a diseased Deer (DDeer) can go before it has to eat again.
    private static final int FOOD_VALUE = 18;
    // The initial food value. Number of steps a new born diseased Deer (DDeer) can go before it has to eat again.
    private static final int INITIAL_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The diseased diseased Deer (DDeer) age.
    private int age;
    // The diseased diseased Deer (DDeer) food level, which is increased by eating Chickens.
    private int foodLevel;

    /**
     * Create a new diseased Deer (DDeer). A diseased Deer (DDeer) may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the diseased Deer (DDeer) will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public DDeer(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = INITIAL_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the diseased Deer (DDeer) does most of the time - it runs 
     * around and eats Chickens. In the process, it might breed, 
     * get sick, die of hunger, or die of old age.
     * Behaviour is different for the day and night.
     * After the step boolean field hydrated is set to false.
     * After the step boolean field bred set to false.
     * 
     * @param newDDeer A list to return newly born diseased Deer (DDeer).
     * @param day A boolean value which indicates whether it is a day or night
     */
    public void act(List<Organism> newDDeer, boolean day)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            Location newLocation = null;
            giveBirth(newDDeer);
            if(day == false){
                // Move towards a source of food if found
                newLocation = findFood();
            }
            else{
                // Stay in the same location
                newLocation = this.getLocation();
            }
            if(newLocation == null) { 
                // Try to move to a free location
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                // Move to new location
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
           
        }
        hydrated = false;
        bred = false;
    }

    /**
     * Check if sick. When sick increase the age by sick age
     * else increase the age normally. 
     * This could result in the diseased Deer's (DDeer) death.
     */
    private void incrementAge()
    {
        if(isSick()) {
            age += SICK_INCREMENT_AGE;
        }
        else {
            age++;
        }
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this diseased Deer (DDeer) more hungry. 
     * This could result in the diseased Deer's (DDeer) death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for Chickens adjacent to the current location.
     * Only the first live Chicken is eaten.
     * If the eaten Chicken is sick, then diseased Deer (DDeer) gets sick.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Chicken) {
                Organism organism = (Organism) Organism;
                if(organism.isAlive()) { 
                    getSick(organism);    
                    organism.setDead();        
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Deer is to give birth at this step.
     * Check whether there is a Deer with opposite sex in surrounding locations.
     * If there is, diseased Deer (DDeer) gives birth.
     * New births will be made into free adjacent locations.
     * The boolean field bred of opposite sex diseased Deer (DDeer) is set to true.
     * 
     * @param newDeer A list to return newly born diseased Deer (DDeer).
     */
    private void giveBirth(List<Organism> newDDeer)
    {
        // New diseased Deer (DDeer) are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.surroundingLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Deer) {
                Deer organism = (Deer) Organism;
                if(isMale!=organism.getGender()) {
                    if(organism.isAlive()) { 
                        organism.setBred();
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            DDeer young = new DDeer(false, field, loc);
                            newDDeer.add(young);
                        }
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A diseased Deer (DDeer) can breed if it has reached the breeding age
     * and if a diseased Deer (DDeer) did not breed before.
     * 
     * @return true if the diseased Deer (DDeer) can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && bred == false;
    }
}
