import java.util.Random;
/**
 * A class representing shared characteristics of GenderOrganisms.
 * 
 * @version 2020.02.23
 */
public abstract class GenderOrganism extends Organism
{
    // Organism's gender. Either Male or Female
    protected boolean isMale;
    // Shows whether Organism has bred or not
    protected boolean bred;

    /**
     * Create a new Organism at location in field.
     * Sets gender of this organism.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public GenderOrganism(Field field, Location location)
    {
        super(field, location);
        Random rd = new Random();
        this.isMale = rd.nextBoolean();
        bred = false;
    }
    
    /**
     * Return the Organism's gender.
     * @return The Organism's gender.
     */
    protected boolean getGender()
    {
        return isMale;
    }
    
    /**
     * Set bred value to true.
     * Means that Organism has bred.
     */
    protected void setBred()
    {
        bred = true;
    }
}
