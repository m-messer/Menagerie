import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of disease
 * The disease and spread, age, infect others and die out.
 *
 * @version 2016.02.29 (2)
 */
public class Disease extends Organism
{
    // Characteristics shared by all Disease (class variables).

    // The age to which a Disease can live.
    private static final int MAX_AGE = 15;
    // The likelihood of a Disease spreading
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of new disease.
    private static final int MAX_SPREAD_SIZE = 1;
    
    //these booleans determine the strain of the diease thus determining what they affect
    private boolean mammal = false;
    private boolean alien = false;
    private boolean plant = false;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Disease's age.
    private int age;
    // The Disease's food level, which is increased by eating rabbits.

    /**
     * Create a new Disease. It may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, it will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Disease(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        mutate();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }
    
    /**
     * check of the disease affects mammals
     */
    public boolean getMammalDisease()
    {
        return mammal;
    }
    
    /**
     * check of the disease affects plants
     */
    public boolean getPlantDisease()
    {
        return plant;
    }
    
    /**
     * check of the disease affects extraterrestrials
     */
    public boolean getAlienDisease()
    {
        return alien;
    }
    
    /**
     * mutates the disease to affect one of the three factions
     */
    private void mutate()
    {
        Random random = new Random();
        int r = random.nextInt(3);
        if(r==0) {
            alien=true;
        }
        else if(r==1) {
            mammal=true;
        }
        else if(r==2) {
            plant=true;
        }
    }
    
    /**
     * This is what the disease does
     * @param newDisease A list to return newly born Disease.
     */
    public void act(List<Organism> newDisease,boolean day)
    {
        incrementAge();
        if(isAlive() && day == true) {
            giveBirth(newDisease);
        }
    }

    /**
     * Increase the age.
     * This could result in the diseases's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this disease is ready to spread
     * @param newDisease A list to return newly born Disease.
     */
    private void giveBirth(List<Organism> newDisease)
    {
        // New Disease are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeDiseaseLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Disease young = new Disease(false, field, loc);
            newDisease.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_SPREAD_SIZE) + 1;
        }
        return births;
    }

}
