import java.util.List;
/**
 * A class representing shared characteristics of Organisms.
 * 
 * @version 2020/02/23 (2)
 */
public abstract class Organism
{
    // Whether the Organism is alive or not.
    private boolean alive;
    // The Organism's field.
    private Field field;
    // The Organism's position in the field.
    private Location location;
    //the accelerated ageing process due to sickness
    protected final int SICK_INCREMENT_AGE = 3;
    //to check if the organism has been hydrated 
    protected boolean hydrated;
    //check if organism sick
    private boolean sick;
    
    
    /**
     * Create a new Organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * if the organism is a plant they are added to the plant layer of the field
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        if (this instanceof Plant){
        setPlantLocation(location);
       }
       else{
            setLocation(location);
        }
    }
    
    //sets organisms hydration to true
    protected void setHydrated()
    {
        hydrated = true;
    }
    
    /**
     * Make this Organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born Organisms.
     */
    abstract public void act(List<Organism> newOrganisms, boolean day);

    /**
     * Check whether the Organism is alive or not.
     * @return true if the Organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    //makes the organism sick
    protected void setSick()
    {
        sick = true;
    }
    
    /**
     * Indicate that the Organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null){
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Indicate that the Plant is no longer alive.
     * It is removed from the Plant field.
     */
    protected void setPlantDead()
    {
        alive = false;
        if(location != null){
            field.clearPlant(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * checks the area for disease
    * @param newLocation where there could be disease
     */
    protected boolean checkIfDiseased(Location newLocation)
    {
        Field field = getField();
        Object obj = field.getObjectAt(newLocation);
        if(obj!=null){
            if(field.getObjectAt(newLocation) instanceof Disease){
                Disease disease = (Disease) obj;
                if(checkDisease(this, disease)){//checks if this disease affects the organism
                    disease.setDead();
                    return true;
                }
                disease.setDead();
            }
        }
        return false;
    }
    
    /**
     * Checks of the disease present is a strain that affects the organism.
     * @param organism The Organism being checked for disease.
     * @param disease The disease being checked for.
     */
    protected boolean checkDisease(Organism organism, Disease disease)
    {
        if(disease instanceof Disease){
            Disease tempDisease = (Disease) disease;
            if(organism instanceof Chicken || organism instanceof Human || organism instanceof Deer){
                return tempDisease.getMammalDisease();
            }
            if(organism instanceof Alien || organism instanceof Predator){
                return tempDisease.getAlienDisease();
            }
            if(organism instanceof Plant){
                return tempDisease.getPlantDisease();
            }
        }
        return false;
    }
    
    /**
     * Place the PLant at the new location in the given Plant field.
     * @param newLocation The PLant's new location.
     */
    protected void setPlantLocation(Location newLocation)
    {
        if(location != null){
            field.clearPlant(location);
        }
        location = newLocation;
        field.placePlant(this, newLocation);
    }
    
    /**
     * Return the Organism's health status
     */
    protected boolean isSick()
    {
        return sick;
    }
    
    protected void getSick(Organism maybeSick)
    {
        if(maybeSick.isSick()){
            sick = true;
        }
    }
    
    /**
     * Return the Organism's location.
     * @return The Organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the Organism at the new location in the given field.
     * @param newLocation The Organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null){
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the Organism's field.
     * @return The Organism's field.
     */
    protected Field getField()
    {
        return field;
    }
}
