import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a diseased alien.
 * They are much like the aliens of the Alien class
 * except the disease has turned them rabid, 
 * they kill and breed using any animals as hosts
 * DAlien age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class DAlien extends Alien
{
    // Characteristics shared by all DAlien (class variables).
    
    // The age at which a Dalien can start to breed.
    private static final int BREEDING_AGE = 0;
    // The age to which a Dalien can live.
    private static final int MAX_AGE = 7;
    // The likelihood of a Dalien breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // number of steps a Dalien can go before it has to eat again.
    private static final int FOOD_VALUE = 10;
    //The food value of a new born
    private static final int INITIAL_FOOD_VALUE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The alien's age.
    private int age;
    // The alien's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a alien. A alien can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the alien will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public DAlien(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = INITIAL_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the alien does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param day check whether is is day.
     * @param newAlien A list to return newly born DAlien.
     */
    public void act(List<Organism> newDAlien,boolean day)
    {
        incrementAge();
        incrementHunger();
        whenWet();//rain is lethal to them
        if(isAlive()) {            
            // Move towards a source of food if found.
            Location newLocation = findFood(newDAlien);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        } 
    }
    
    /**
     * Checks if the DAlien is wet from rain.
     * If this is the case the DAlien dies as rain is lethal to it.
     */
    private void whenWet()
    {
        if(hydrated){
            setDead();
        }
    }
    
    /**
     * Increase the age.
     * This could result in the DAlien's death.
     * When sick aging is accelerated.
     */
    private void incrementAge()
    {
        if(isSick()){
            age += SICK_INCREMENT_AGE;
        }
        else{
            age++;
        }
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this alien more hungry. This could result in the alien's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(List<Organism> newDAlien)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Organism && !(Organism instanceof Predator)) { //They cannot beat predators
                Organism organism = (Organism) Organism;
                if(organism.isAlive()) { 
                    getSick(organism);    //get sick if what they ate was sick
                    organism.setDead();        
                    giveBirth(newDAlien);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Dalien is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDAlien A list to return newly born DAlien.
     */
    private void giveBirth(List<Organism> newDAlien)
    {
        // New DAlien are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            DAlien young = new DAlien(false, field, loc);
            newDAlien.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A alien can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
