import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A model of a Human.
 * Human age, move, breed, eat and die.
 * 
 * 
 * @version 2020.02.23
 */
public class Human extends GenderOrganism
{
    // Characteristics shared by all Human (class variables).
    // The age at which a Human can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a Human can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a Human breeding.
    private static final double BREEDING_PROBABILITY = 0.75;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value. Number of steps a alien can go before it has to eat again.
    private static final int FOOD_VALUE = 18;
    // The initial food value. Number of steps a new born Human can go before it has to eat again.
    private static final int INITIAL_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Human's age.
    private int age;
    // The Human's food level, which is increased by eating.
    private int foodLevel;

    /**
     * Create a Human. A Human can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Human will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Human(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = INITIAL_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Human does most of the time - it runs 
     * around and eats Organisms. In the process, it might breed, 
     * get sick, become diseased, die of hunger, or die of old age.
     * Behaviour is different for the day and night.
     * After the step boolean field hydrated is set to false.
     * After the step boolean field bred set to false.
     * 
     * @param newHuman A list to return newly born Human.
     * @param day A boolean value which indicates whether it is a day or night
     */
    public void act(List<Organism> newHuman, boolean day)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            Location newLocation;
            if(day == true) {
                // Move towards a source of food if found.
                newLocation = findFood();
            }
            else {
                // Try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
                // Give birth if possible
                giveBirth(newHuman);
            }
            // See if it was possible to move.
            // Check whether new location has disease in it
            if(newLocation !=null && checkIfDiseased(newLocation)) {
                    // Check whether this disease has an effect
                    becomeDiseased(newHuman, newLocation);
                }
            else if(newLocation !=null) {
                // Move to new location
                    setLocation(newLocation);
                }
            
            else {
                // Overcrowding.
                setDead();
            }
        }
        hydrated = false;
        bred = false;
    }

    /**
     * Check if sick. When sick increase the age by sick age
     * else increase the age normally. 
     * This could result in the Human's death.
     */
    private void incrementAge()
    {
        if(isSick()) {
            age += SICK_INCREMENT_AGE;
        }
        else {
            age++;
        }
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Become diseased. Set Human to dead
     * and create a subclass of current Human
     * which is diseased Human(DHuman).
     * 
     * @param newDHuman A list to return newly born diseased Human.
     * @param newLocation A location to which new diseased Human should be born.
     */
    protected void becomeDiseased(List<Organism> newDHuman, Location newLocation)
    {
        Field field = getField();
        setDead();
        Location loc = newLocation;
        DHuman ill = new DHuman(true, field, loc);
        newDHuman.add(ill);
    }
    
    /**
     * Make this Human more hungry. This could result in the Human's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for specific Organisms adjacent to the current location.
     * Only the first live Organism is eaten.
     * If the eaten Organism is sick, then Human gets sick.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.surroundingLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Deer ||Organism instanceof Alien|| Organism instanceof Chicken) {
                Organism organism = (Organism) Organism;
                if(organism.isAlive()) { 
                    getSick(organism);    
                    organism.setDead();        
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
            
        }
        return null;
    }
    
    /**
     * Check whether or not this Human is to give birth at this step.
     * Check whether there is a Human with opposite sex in surrounding locations.
     * If there is, Human gives birth.
     * New births will be made into free adjacent locations.
     * The boolean field bred of opposite sex Human is set to true.
     * 
     * @param newHuman A list to return newly born Human.
     */
    private void giveBirth(List<Organism> newHuman)
    {
        // New Human are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.surroundingLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        List<Location> free = field.surroundingLocations(getLocation());
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Human) {
                Human organism = (Human) Organism;
                if(isMale!=organism.getGender()) {
                    if(organism.isAlive()) { 
                        organism.setBred(); //means this organism cannot breed twice
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Human young = new Human(false, field, loc);
                            newHuman.add(young);
                        }
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Human can breed if it has reached the breeding age
     * and if a Human did not breed before.
     * 
     * @return true if the Human can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && bred == false;
    }
}
