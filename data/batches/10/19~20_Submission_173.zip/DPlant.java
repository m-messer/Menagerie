import java.util.List;
import java.util.Random;
import java.util.Iterator; 

/**
 * A simple model of a Diseased plant.
 * Plants can age, breed, become sick, diseased and die.
 *
 * @version 2016.02.29 (2)
 */
public class DPlant extends Plant
{
    // Characteristics shared by all DPLant (class variables).

    // The age to which a Dplant can live.
    private static final int MAX_AGE = 15;
    // The likelihood of a Dplant breeding.
    private static final double BREEDING_PROBABILITY = 0.0002; 
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Dplant's age.
    private int age;

    /** 
     * Create a new Dplant
     * 
     * @param randomAge If true, the Dplant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public DPlant(Field field, Location location)
    {
        super(field, location);
        age = 0;
        setSick();
    }
    
    /**
     * This is what the Dplant does most of the time . Sometimes it will hunt,breed, become diseased, sick or die of old age.
     * @param newPlant A list to return newly born DPLant.
     * @param day check whether is is day.
     */
    public void act(List<Organism> newPlant, boolean day)
    {
        incrementAge();
        if(isAlive()) {
            whenHydrated();
            if(day == true && rand.nextDouble() < BREEDING_PROBABILITY){
             spread(newPlant);   
           }         
        }
        hydrated = false;
    }
    
    /**
     * Turns back the clock on the plant as it is hydrated
     */
    private void whenHydrated()
    {
        if(hydrated)
        {
           age -= SICK_INCREMENT_AGE;
        }
    }
    
    /**
     * Increase the age.
     * This could result in the Dplant's death.
     * When sick aging is accelerated.
     */
    private void incrementAge()
    {
        if(isSick())
        {
            age += SICK_INCREMENT_AGE;
        }
        else
        {
            age++;
        }
        if(age > MAX_AGE) {
            setPlantDead();
        }
    }
    
    /**
     * Check whether or not this Dplant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlant A list to return newly born DPLant.
     */
    private void spread(List<Organism> newDPlant)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getPlantObjectAt(where);
            if(Organism instanceof Plant) {
                Plant organism = (Plant) Organism;
                if(!(organism instanceof DPlant)) {
                    if(organism.isAlive()) { 
                        organism.becomeDiseased(newDPlant);
                    }
                }
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
 }
