    import java.util.List;

/**
 * A class representing shared characteristics of Weather.
 * 
 * @version 2020.02.23
 */
public abstract class Weather
{
    // Whether the Weather is alive or not.
    private boolean active;
    // The Weather's field.
    private Field field;
    // The Weather's position in the field.
    private Location location;
    
    /**
     * Create a new Weather at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Weather(Field field, Location location)
    {
        active = true;
        this.field = field;
        setWeatherLocation(location);
    }
    
    /**
     * Make this Weather act - that is: make it do
     * whatever it wants/needs to do.
     * @param newWeather A list to receive newly born Weather.
     */
    abstract public void act(List<Weather> newWeather);

    /**
     * Check whether the Weather is active or not.
     * @return true if the Weather is still active.
     */
    protected boolean isActive()
    {
        return active;
    }

    /**
     * Indicate that the Weather is no longer active.
     * It is removed from the field.
     */
    protected void setInactive()
    {
        active = false;
        if(location != null) {
            field.clearWeather(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the Weather's location.
     * @return The Weather's location.
     */
    protected Location getWeatherLocation()
    {
        return location;
    }
    
    /**
     * Place the Weather at the new location in the given field.
     * @param newLocation The Weather's new location.
     */
    protected void setWeatherLocation(Location newLocation)
    {
        if(location != null) {
            field.clearWeather(location);
        }
        location = newLocation;
        field.placeWeather(this, newLocation);
    }
    
    /**
     * Return the Weather's field.
     * @return The Weather's field.
     */
    protected Field getField()
    {
        return field;
    }
}
