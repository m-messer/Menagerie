import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Diseased predator.
 * Dpredator age, move, hunt, and die.
 * These DPredators are much like predators
 * Except from the fact the disease has rendered them psychotic and now they only hunt their brethren
 *
 * @version 2016.02.29 (2)
 */
public class DPredator extends Predator   
{
    // Characteristics shared by all DDpredator (class variables).
    
    // The age at which a Dpredator can start to call in others.
    private static final int CALLING_AGE = 1;
    // The age to which a Dpredator can live.
    private static final int MAX_AGE = 15;
    // The likelihood of a Dpredator breeding.
    private static final double CALLING_PROBABILITY = 1;
    // The maximum number of vicitms it can call in.
    private static final int MAX_VICTIMS = 2;
    // A shared random number generator to control calling.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Dpredator's age. 
    private int age; 

    /**
     * Create a Dpredator with a random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public DPredator(Field field, Location location)
    {
        super(field, location);
        age = rand.nextInt(MAX_AGE);
    }
    
    /**
     * This is what the dpredator does most of the time: it hunts Predators.It might call in new predators
     * become sick or diseased or die of old age.
     * @param day check whether is is day.
     * @param newDPredator A list to return newly called Predator.
     */
    public void act(List<Organism> newDpredator, boolean day)
    {
        incrementAge();
        if(isAlive()) {
            callVictims(newDpredator); //Dpredator calls victims
            // The DDpredator searches for prey.
            Location newLocation = hunt(newDpredator);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        hydrated=false;
    }

    /**
     * Increase the age.
     * This could result in the Dpredator's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    
    /** 
     * The Dpredator looks for aliens and humans.
     * The Dpredators hunts other predators
     * @return Where food was found, or null if it wasn't.
     */
    private Location hunt(List<Organism> newDDpredator)
    {
        
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Predator ) {;
                Predator organism = (Predator) Organism;
                if(organism.isAlive()) { 
                    getSick(organism);    //get sick if what they ate was sick
                    organism.setDead();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Dpredator is able to call in other predators to hunt.
     * new arrivals will occupy free adjacent locations.
     * @param newPredator A list to return newly called predator.
     */
    private void callVictims(List<Organism> newPredator)
    {
        // New DDpredator are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int victims = call();
        for(int b = 0; b < victims && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Predator rookie = new Predator(field, loc);
            newPredator.add(rookie);
        }
    }
        
    /**
     * Generate a number of victims.
     */
    private int call()
    {
        int victims = 0;
        if(canCall() && rand.nextDouble() <= CALLING_PROBABILITY) {
            victims = rand.nextInt(MAX_VICTIMS) + 1;
        }
        return victims;
    }

    /**
     * A Dpredator can call others if it has reached a certain age.
     */
    private boolean canCall()
    {
        return age >= CALLING_AGE;
    }
}
