
/**
 * Enumeration class Disease - write a description of the enum class here
 *
 * @version (02/22/2020)
 */
public enum Disease
{
    FLU, RABIES, NOTHING;
}
