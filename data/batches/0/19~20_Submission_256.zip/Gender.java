
/**
 * Enumeration class Gender - write a description of the enum class here
 *
 * @version (version number or date here)
 */
public enum Gender
{
    MALE, FEMALE
}
