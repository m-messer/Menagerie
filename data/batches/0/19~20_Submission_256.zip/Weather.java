
/**
 * Enumeration class Weather - write a description of the enum class here
 *
 * @version (02/22/2020)
 */
public enum Weather
{
    SUNNY, WINDY, RAINY, CLOUDY, SNOWY;
}
