public class Sunny extends Weather
{
}
