public class Foggy extends Weather
{
}
