import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * Write a description of class Disease here.
 *
 * @version (a version number or a date)
 */
abstract class Disease
{
    private static final Random rand = Randomizer.getRandom();
    
    private final List<Class> potentialHosts;
    
    private Organism host;
    
    private int time;

    public Disease(List<Class> potentialHosts) {
        this.potentialHosts = potentialHosts;
    }
    
    /**
     * @return the chance of the disease to spread to an adjacent organism
     */
    protected abstract double getInfectivity();
    
    /**
     * @return the chance of this disease to kill the host
     */
    protected abstract double getLethality();
    
    /**
     * @return the chance for the host to get better
     */
    protected abstract double getRecoveryChance();
    
    /**
     * @return a new instance of the disease
     */
    protected abstract Disease getNewInstance();
    
    /**
     * Must be called in each iteration.
     */
    public void act() {
        incrementTime();
        transmit();
        kill();
        recover();
    }
    
    /**
     * Sets the host of the disease. Does nothing if the host is invalid
     */
    public void setHost(Organism organism) {
        if (isValidHost(organism))
            host = organism;
    }
    
    /**
     * Removes the reference to the host of the disease. Removes the reference to this 
     * disease from the host.
     */
    public void removeHost() {
        if (host != null) {
            host.removeDisease(this);
            host = null;
        }
    }
    
    /**
     * Checks if an organism is a valid host for a disease
     * 
     * @return true if the organism is a valid host
     */
    public boolean isValidHost(Organism organism) {
        boolean isValidHost = false;
        for (Class host : potentialHosts)
            if (host.isInstance(organism))
                isValidHost = true;
        return isValidHost;
    }
    
    /**
     * @return true if the disease has the same actual class as another instance
     */
    @Override
    public boolean equals(Object object) {
        return (getClass() == object.getClass());
    }
    
    /**
     * Used for HashSets
     * @return the hashCode of the class rather than the instance
     */
    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
     
    protected void transmit() {
        Field field = host.getField();
        List<Location> adjacentLocations = field.adjacentLocations(host.getLocation());
        List<Organism> adjacentOrganisms = new ArrayList<>();
        Iterator<Location> it = adjacentLocations.iterator();
        while (it.hasNext()) {
            Location location = it.next();
            Object object = field.getObjectAt(location);
            if (object != null && object instanceof Organism) {
                adjacentOrganisms.add((Organism) object);
            }
        }
        
        Iterator<Organism> orgIter = adjacentOrganisms.iterator();
        while (orgIter.hasNext()) {
            if (!isValidHost(orgIter.next())) {
                orgIter.remove();
            }
        }
        
        for (Organism organism : adjacentOrganisms) {
            if (rand.nextDouble() < getInfectivity()) {
                if (!organism.hasDisease(this)) {
                    organism.addDisease(getNewInstance());
                }
            }
        }
    }

    protected void kill() {
        if (rand.nextDouble() < getLethality()) {
            host.setDead();
        }
    }
    
    protected void recover() {
        if (rand.nextDouble() < getInfectivity()) {
            removeHost();
        }
    }
    
    /**
     * @return the host organism of the disease.
     */
    protected Organism getHost() {
        return host;
    }
    
    /**
     * Increases the internal counter of the disease
     */
    protected void incrementTime() {
        time++;
    }
    
    /**
     * @return the internal time of the disease
     */
    protected int getTime() {
        return time;
    }
}
