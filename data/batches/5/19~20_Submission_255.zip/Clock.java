
/**
 * A class that keeps track of a simple day of integer length.
 * Time is between 0 (inclusive) and the length of day (exclusive).
 * Time rolls around to 0 when it exceeds the length of day.
 *
 * @version 2020-02-23
 */
public class Clock
{
    private int time;
    private int dayLength;

    /**
     * Constructor for objects of class Clock
     * @param dayLength
     */
    public Clock(int dayLength)
    {
        time = 0;
        this.dayLength = dayLength;
    }

    /**
     * Simulates one tick in time. Increments the internal time counter.
     * Rolls it around to 0 when the length of day has been reached
     */
    public void timeTick() {
        if (++time >= dayLength)
            time = 0;
    }
    
    /**
     * Sets a new length of day. Also resets the time of day
     */
    public void setDayLength(int newDayLength) {
        dayLength = newDayLength;
        time = 0;
    }
    
    public int getDayLength() {
        return dayLength;
    }
    
    /**
     * @return The time as an integer from 0 to daylength - 1
     */    
    public int getTime() {
        return time;
    }
    
    /**
     * Resets the internal time counter to 0
     */
    public void reset() {
        time = 0;
    }
}
