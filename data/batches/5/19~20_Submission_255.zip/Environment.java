import java.awt.Color;
import java.util.Random;
/**
 * This class represents the environment of an organism.
 * That is: the time of day and the weather.
 *
 * @version 2020-02-23
 */
public class Environment
{
    /**
     * Represents all types of possible weather
     */
    public enum Weather {
        SUN("sun"),
        FOG("fog"),
        RAIN("rain"),
        WEATHER_COUNT("");
        
        // The weather type as an all-lowercase string
        private final String weatherString;
        
        private Weather(String s) {
            weatherString = s;
        }
        
        /**
         * @return an all-lowercase string of the weather type
         */
        public String getWeatherString() {
            return weatherString;
        }
    }
    
    //random
    private static final Random rand = Randomizer.getRandom();
    // a clock to keep track of the time of day
    private Clock clock;
    // the current weather
    private Weather weather;
    
    /**
     * Creates a new environment.
     * @param dayLength The length of day in ticks
     */
    public Environment(int dayLength) {
        clock = new Clock(dayLength);
        weather = Weather.SUN;
    }
     
    /**
     * Simulates a tick of time
     */
    public void timeTick() {
        clock.timeTick();
        if (rand.nextDouble() < 0.1) {
            int x = rand.nextInt(Weather.WEATHER_COUNT.ordinal());
            weather = Weather.values()[x];
        }
    }
    
    /**
     * Resets the weather and time of day
     */
    public void reset() {
        weather = Weather.SUN;
        clock.reset();
    }
    
    /**
     * By default changes the daytime every dayLength/2
     * @return true if it is daytime, false if it is night
     */
    public boolean isDaytime() {
        return clock.getTime() < clock.getDayLength()/2;
    }
    
    /**
     * @param newDayLength The new length of day as a number of ticks
     */
    public void setDayLength(int newDayLength) {
        clock.setDayLength(newDayLength);
    }
    
    /**
     * @return The length of day as an integer of ticks
     */
    public int getDayLength() {
        return clock.getDayLength();   
    }   
    
    /**
     * @return The current time as an integer betwen 0 (inclusive) and the length of day (exclusive)
     */
    public int getTime() {
        return clock.getTime();
    }
    
    /**
     * @return The current weather
     */
    public Weather getWeather() {
        return weather;
    }
}
