import java.util.Random;
import java.util.Set;
import java.util.HashSet;

/**
 * A class representing shared characteristics of all organisms.
 * Organisms have an age, diseases, and can die.
 *
 * @version 2020-02-23
 */
public abstract class Organism extends Actor
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The age of the organism
    private int age;
    // The diseases that the Organism has
    private Set<Disease> diseases;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Creates an organism with the specified parameters
     * @param randomAge If true, the organism will start
     *                  with a random age between 0 and its
     *                  maximum
     * @param field     The field in which to place the organism
     * @param location  The location of the newly created organism
     *                  on the field
     */
    public Organism(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
        }
        else {
            age = 0;
        }
        alive = true;
        diseases = new HashSet<>();
    }

    /**
     * Returns a new instance of Organism
     * @param randomAge Whether the organism should have a random age
     * @param field The field in which the organism should be placed
     * @param location The specific location in which the organism should be placed
     */
    abstract protected Organism getNewInstance(boolean randomAge, Field field, 
        Location location);
        
    /**
     * @return The chance of an organism performing voluntary functions given its current state
     */
    abstract double getActivity();

    /**
     * @return The food that this provides
     */
    abstract protected int getFoodValue();

    /**
     * @return The maximum age of this organism
     */
    abstract protected int getMaxAge();

    /**
     * @return The minimum age for reproduction of this organism
     */
    abstract protected int getReproductiveAge();

    /**
     * @return The probability of this organism reproducing during a step/tick
     */
    abstract protected double getReproductiveProbability();

    /**
     * @return The maximum number of new instances that an organism can produce in one step/tick
     */
    abstract protected int getMaxNewInstances();

    /**
     * Increase the age.
     * This could result in the organism's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age >= getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * @return the age of the organism
     */
    public int getAge()
    {
        return age;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    @Override
    public boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        for (Disease disease : diseases) {
            disease.removeHost();
        }
        super.removeSelf();
    }
    
    /**
     * Makes all diseases, that this organism has, act.
     */
    protected void handleDiseases() {
        for (Disease disease : diseases) {
            disease.act();
        }
    }
    
    /**
     * @param disease Checks if the organism has this disease.
     * @return true if the organism has a disease of the same dynamic type.
     */
    protected boolean hasDisease(Disease disease) {
        return diseases.contains(disease);
    }
    
    /**
     * @param diseaseClass Checks if the organism has a disease of this class
     * @return true if the organism has a disease of the specified class
     */
    public boolean hasDisease(Class diseaseClass) {
        for (Disease disease : diseases){
            if (disease.getClass() == diseaseClass) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adds a disease to this organism.
     * @return true if the disease was successfully added
     */
    protected boolean addDisease(Disease disease) {
        if (!disease.isValidHost(this)) {
            disease.setHost(this);
            diseases.add(disease);
            return true;
        }
        return false;
    }
    
    /**
     * Removes a disease from this organism
     * @param disease The disease to remove
     */
    public void removeDisease(Disease disease) {
        diseases.remove(disease);
    }
    
}
