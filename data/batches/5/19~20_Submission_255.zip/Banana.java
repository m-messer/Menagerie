
/**
 * Plant that spreads very quickly and provides a low amount of food.
 * Spreads more slowly in the rain and fog.
 *
 * @version 2020-02-23
 */
public class Banana extends Plant
{

    // The age at which a banana can start to reproduce
    private static final int REPRODUCTIVE_AGE = 1;
    // The age to which a fox can live.
    private static final int MAX_AGE = 45;
    // The likelihood of a fox breeding.
    private static final double SPREADING_PROBABILITY = 0.58;
    // The maximum number of births.
    private static final int MAX_NEW_PLANTS = 5;
    // The food value of a fox
    private static final int FOOD_VALUE = 4;

    /**
     * Constructor for objects of class Banana
     */
    public Banana(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    protected Organism getNewInstance(boolean randomAge, Field field, Location location) {
        return new Banana(randomAge, field, location);
    }

    /**
     * {@inheritDoc}
     */
    protected double getActivity() {
        double activity = 1.0;

        Environment environment = getEnvironment();
        Environment.Weather weather = environment.getWeather();
        switch (weather) {
            case SUN:
                break;
            case FOG:
                activity *= 0.5;
                break;
            case RAIN:
                activity *= 0.5;
                break;
            default:
                break;
        }
        
        if (!environment.isDaytime()) {
            activity *= 0.7;
        }
        
        return activity;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int getFoodValue(){
        return FOOD_VALUE;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected int getMaxNewInstances(){
        return MAX_NEW_PLANTS;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getReproductiveAge(){
        return REPRODUCTIVE_AGE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected double getReproductiveProbability(){
        return SPREADING_PROBABILITY;
    }

}
