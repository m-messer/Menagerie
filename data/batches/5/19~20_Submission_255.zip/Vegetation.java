
/**
 * Just general vegetation, spreads quickly and provides a medium amount
 * of food. Spreads more slowly in rain and fog.
 *
 * @version 2020-02-23
 */
public class Vegetation extends Plant
{
    
    // The age at which a fox can start to breed.
    private static final int REPRODUCTIVE_AGE = 1;
    // The age to which a fox can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a fox breeding.
    private static final double SPREADING_PROBABILITY = 0.48;
    // The maximum number of births.
    private static final int MAX_NEW_PLANTS = 6;
    // The food value of a fox
    private static final int FOOD_VALUE = 7;

    /**
     * Constructor for objects of class Grass
     */
    public Vegetation(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    protected Organism getNewInstance(boolean randomAge, Field field, Location location) {
        return new Vegetation(randomAge, field, location);
    }
    
    /**
     * {@inheritDoc}
     */
    protected double getActivity() {
        double activity = 1.0;

        Environment environment = getEnvironment();
        Environment.Weather weather = environment.getWeather();
        switch (weather) {
            case SUN:
                break;
            case FOG:
                activity *= 0.4;
                break;
            case RAIN:
                activity *= 0.5;
                break;
            default:
                break;
        }
        
        if (!environment.isDaytime()) {
            activity *= 0.7;
        }
        
        return activity;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int getFoodValue(){
        return FOOD_VALUE;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected int getMaxNewInstances(){
        return MAX_NEW_PLANTS;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getReproductiveAge(){
        return REPRODUCTIVE_AGE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected double getReproductiveProbability(){
        return SPREADING_PROBABILITY;
    }
}
