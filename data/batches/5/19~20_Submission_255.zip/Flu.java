import java.util.List;
import java.util.ArrayList;

/**
 * The flu has a small chance of killing the host and 
 * a medium chance to spread to nearby animals
 *
 * @version 2020-02-23
 */
public class Flu extends Disease
{
    // instance variables - replace the example below with your own
    private static final double infectivity = 0.01;
    
    private static final double lethality = 0.001;
    
    private static final double recoveryChance = 0.1;
    
    private static final List<Class> hosts;
    
    static {
        hosts = new ArrayList<>();
        hosts.add(Animal.class);
    }

    /**
     * Constructor for objects of class Flu
     */
    public Flu()
    {
        super(hosts);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected Disease getNewInstance() {
        return new Flu();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected double getInfectivity() {
        return infectivity;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected double getLethality() {
        return lethality;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected double getRecoveryChance() {
        return recoveryChance;
    }
}
