import java.util.List;
/**
 * Actors are objects that are part of the simulation.
 * They keep track of their location and the field they
 * belong to.
 *
 * @version 2020-02-23
 */
abstract class Actor
{
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    private Location location;

    public Actor(Field field, Location location) {
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly created actors.
     */
    abstract void act(List<Actor> newActors);
    
    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }
      
    /**
     * @return the evironment of the actor
     */
    protected Environment getEnvironment()
    {
        return field.getEnvironment();
    }
    
    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Removes the actor from the field and removes references to 
     * the former field and location.
     */
    public void removeSelf() 
    {
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * @return true by default because not every actor must be able to die
     */
    public boolean isAlive()
    {
        return true;
    }
}
