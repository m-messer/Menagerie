import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 * Includes moving, handling disease, feeding, dying, and breeding.
 *
 * @version 2020-02-23
 */
public abstract class Animal extends Organism
{
    // chacne of acquiring cancer each iteration
    private static final double CANCER_CHANCE = 0.005;
    // random
    private static final Random rand = Randomizer.getRandom();
    
    // potential food
    private final List<Class> food;
    // the animal's food level -- the opposite of hunger
    private int foodLevel;
    // sex of animal
    private boolean isMale;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location, List<Class> food)
    {
        super(randomAge, field, location);
        this.food = food;
        foodLevel = (int)((getReproductiveAge() < Math.round(getMaxFoodStore() * 0.8)) ? 
                            (getReproductiveAge()) : Math.round(getMaxFoodStore() * 0.8));
        if (rand.nextDouble() < 0.4) {
            isMale = true;
        } else {
            isMale = false;
        }
    }
    
    /**
     * @returns The maximum food that this animal can store
     */
    abstract protected int getMaxFoodStore();
       
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Actor> newActors) 
    {
        incrementAge();
        handleDiseases();
        
        if(isAlive() && rand.nextDouble() < getActivity()) {
            incrementHunger();
            if (isAlive()) {
                giveBirth(newActors);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a traversible location
                    newLocation = getField().traversibleAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    Object object = getField().getObjectAt(newLocation);
                    if (object != null) {
                        if (object instanceof Organism) {
                            ((Organism) object).setDead();
                        }
                    }
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * @return true if the animal is male
     */
    public boolean isMale() {
        return isMale;
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    private void giveBirth(List<Actor> newActors)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent locations that are traversible.
        Field field = getField();
        List<Location> traversible = field.getTraversibleAdjacentLocations(getLocation());
        
        int births = breed();
        while (births-- > 0 && traversible.size() > 0) {
            Location loc = traversible.remove(0);
            Object object = field.getObjectAt(loc);
            if (object != null) {
                if (object instanceof Organism) {
                    ((Organism)object).setDead();
                }
            }
            Actor young = getNewInstance(false, field, loc);
            newActors.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getReproductiveProbability()) {
            births = rand.nextInt(getMaxNewInstances()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age and is next to another animal
     * of the same species and opposite sex.
     * @return true if it can breed
     */
    private boolean canBreed()
    {
        if (getAge() >= getReproductiveAge() && !this.isMale()) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while (it.hasNext()) {
                Location where = it.next();
                Object object = field.getObjectAt(where);
                if (object != null && object.getClass() == this.getClass()) {
                    Animal animal = (Animal) object;
                    if (animal.isMale() && animal.getAge() >= animal.getReproductiveAge()){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for food adjacent to the current location.
     * Only the first live food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if(object != null && food.contains(object.getClass())) {
                if (object instanceof Organism) {
                    Organism organism = (Organism) object;
                    if (organism.isAlive()) {
                        if ((foodLevel += organism.getFoodValue()) > getMaxFoodStore())
                            foodLevel = getMaxFoodStore();
                        organism.setDead();
                        return organism.getLocation();
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Makes the diseases that this animal has act.
     */
    protected void handleDiseases() {
        // give this animal cancer
        if (rand.nextDouble() < CANCER_CHANCE) {
            addDisease(new Cancer());
        }
        super.handleDiseases();
    }
}
    
