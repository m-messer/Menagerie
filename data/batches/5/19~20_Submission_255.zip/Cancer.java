import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * Cancer has an increasing chance of killing the host, depending
 * on the time since they have had it and their maximum age.
 *
 * @version 2020-02-23
 */
public class Cancer extends Disease
{
    // animals that can get cancer
    private static final List<Class> HOSTS;
    // random
    private static final Random rand = Randomizer.getRandom();
    
    private Integer maxTime;
    
    static {
        HOSTS = new ArrayList<>();
        HOSTS.add(Animal.class);
    }
    
    /** 
     * @param maxTime The maximum iterations that the animal will survive with cancer
     */
    public Cancer() {
        super(HOSTS);
        maxTime = null;
    }
    
    /**
     * {@inheritDoc}
     * Also sets the maximum time before an organism dies of this disease
     */
    public void act() {
        if (maxTime == null && getHost() != null) 
            maxTime = (getHost().getMaxAge() - getHost().getAge())/4;
        super.act();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected Disease getNewInstance() {
        return new Cancer();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected double getInfectivity() {
        return 0.0;
    }
    
    /**
     * @return an increasing chance of killing the host, depending on
     *          how long they've had this disease
     */
    @Override
    protected double getLethality() {
        if (getTime() >= maxTime) {
            return 1.0;
        }
        return 1.0 - rand.nextInt(maxTime - getTime())/(maxTime);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected double getRecoveryChance() {
        return 0.75;
    }
}
