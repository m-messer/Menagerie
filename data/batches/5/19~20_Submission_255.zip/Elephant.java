import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * A simple model of a elephant.
 * Elephants age, move, breed, and die.
 *
 * @version 2020-02-23
 */
public class Elephant extends Animal
{
    // Characteristics shared by all elephants (class variables).
    
    // The age at which a elephant can start to breed.
    private static final int REPRODUCTIVE_AGE = 100;
    // The age to which a elephant can live.
    private static final int MAX_AGE = 1000;
    // The likelihood of a elephant breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The maximum amount of food that the animal can store
    private static final int MAX_FOOD_STORE = 100;
    // The food value -- how much food it provides to a predator
    private static final int FOOD_VALUE = 200;
    // the classes of potential food
    private static final List<Class> FOOD;

    // initialising food
    static {
         FOOD = new ArrayList<>();
         FOOD.add(Banana.class);
         FOOD.add(Vegetation.class);
    }

    /**
     * Create a new elephant. A elephant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the elephant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Elephant(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, FOOD);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected Animal getNewInstance(boolean randomAge, Field field, 
            Location location) 
    {
        return new Elephant(randomAge, field, location);
    }
    
    /**
     * {@inheritDoc}
     */
    protected double getActivity() {
        double activity = 1.0;
        
        Environment environment = getEnvironment();
        Environment.Weather weather = environment.getWeather();
        switch (weather) {
            case SUN:
                break;
            case FOG:
                activity *= 0.7;
                break;
            case RAIN:
                activity *= 0.7;
                break;
            default:
                break;
        }
        
        if (hasDisease(Flu.class)) {
            activity *= 0.5;
        }
        
        if (!environment.isDaytime()) {
            activity *= 0.4;
        }
        return activity;
    }
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getMaxFoodStore()
    {
        return MAX_FOOD_STORE;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getMaxNewInstances()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected int getReproductiveAge()
    {
        return REPRODUCTIVE_AGE;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected double getReproductiveProbability()
    {
        return BREEDING_PROBABILITY;
    }
}
