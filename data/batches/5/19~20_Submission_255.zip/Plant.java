import java.util.List;
import java.util.Random;
/**
 * Simple model of a plant. Plants will reproduce, age,
 * and die.
 *
 * @version 2020-02-23
 */
abstract class Plant extends Organism
{
    Random rand = Randomizer.getRandom();
    
    /**
     * Constructor for objects of class Plant
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Plants age, reproduce and die.
     * @param newActors a list representing all new actors on the field.
     */
    public void act(List<Actor> newActors) 
    {
        incrementAge();
        if(isAlive() && rand.nextDouble() <= getActivity()) {
            spread(newActors);
        }
    }
      
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int numOfNewPlants()
    {
        int n = 0;
        if(rand.nextDouble() <= getReproductiveProbability() && getAge() >= getReproductiveAge()) {
            n = rand.nextInt(getMaxNewInstances()) + 1;
        }
        return n;
    }
  
    /**
     * Makes the plant reproduce
     * @param newActors A list of new actors 
     */
    private void spread(List<Actor> newActors)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int n = numOfNewPlants();
        // a chance to spread to non-adjacent locations
        if (n > free.size()) {
            free.addAll(field.getRandomFreeLocations(rand.nextInt(n-free.size())));
        }
        while (free.size() > 0 && n-- > 0) {
            Location loc = free.remove(0);
            Actor newPlant = getNewInstance(false, field, loc);
            newActors.add(newPlant);
        }
        
    }
}
