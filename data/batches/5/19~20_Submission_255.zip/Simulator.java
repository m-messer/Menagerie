import java.awt.Color;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants from a jungle. 
 *
 * @version 2016.02.29 (2)
 * @version 2020-02-23
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;
    // The probabilities that a certain organism will be created in any given grid position.
    // Can also be seen as the fraction of all organisms on the field that will be of a certain type
    private static final double JAGUAR_CREATION_PROBABILITY = 0.035;
    private static final double MONKEY_CREATION_PROBABILITY = 0.12; 
    private static final double SNAKE_CREATION_PROBABILITY = 0.07;
    private static final double RAT_CREATION_PROBABILITY = 0.2;
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.02;
    private static final double BANANA_CREATION_PROBABILITY = 0.25;
    private static final double VEGETATION_CREATION_PROBABILITY = 0.25;
    
    // probability of an animal starting the simulation with the flu
    private static final double INITIAL_FLU_PROBABILITY = 0.02;
    
    // The length of day in steps 
    private static final int DAY_LENGTH = 24;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // the environment of the simulation
    private Environment environment;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // create a new environment
        environment = new Environment(DAY_LENGTH);
        
        actors = new ArrayList<>();
        field = new Field(depth, width, environment);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width); 
        view.setColor(Monkey.class, Color.CYAN);
        view.setColor(Jaguar.class, Color.ORANGE);
        view.setColor(Rat.class, Color.BLUE);
        view.setColor(Snake.class, Color.RED);
        view.setColor(Elephant.class, Color.DARK_GRAY);
        view.setColor(Vegetation.class, Color.GREEN);
        view.setColor(Banana.class, Color.YELLOW);
        view.setColor(null, Color.WHITE);
        
        view.setEnvironment(environment);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(100);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * jaguar and monkey.
     */
    public void simulateOneStep()
    {
        step++;
        environment.timeTick();

        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all actors
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            if(actor.isAlive()) {
                actor.act(newActors);
            }
            if(!actor.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly created actors
        actors.addAll(newActors);
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        environment.reset();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with actors
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        
        ArrayList<Location> locations = new ArrayList<>();
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                locations.add(new Location(row, col));
            }
        }
        // The order in which locations are populated is randomized
        Collections.shuffle(locations);
        
        // This is 
        int fieldSize = field.getDepth() * field.getWidth();
        
        // the number of each actor to create
        HashMap<Class, Integer> actorCounts = new HashMap<>();
            actorCounts.put(Jaguar.class, (int)(fieldSize * JAGUAR_CREATION_PROBABILITY));
            actorCounts.put(Monkey.class, (int)(fieldSize * MONKEY_CREATION_PROBABILITY));
            actorCounts.put(Rat.class, (int)(fieldSize * RAT_CREATION_PROBABILITY));
            actorCounts.put(Snake.class, (int)(fieldSize * SNAKE_CREATION_PROBABILITY));
            actorCounts.put(Elephant.class, (int)(fieldSize * ELEPHANT_CREATION_PROBABILITY));
            actorCounts.put(Banana.class, (int)(fieldSize * BANANA_CREATION_PROBABILITY));
            actorCounts.put(Vegetation.class, (int)(fieldSize * VEGETATION_CREATION_PROBABILITY));
            actorCounts.put(null, (int)(fieldSize * (1 - (JAGUAR_CREATION_PROBABILITY 
                                        + MONKEY_CREATION_PROBABILITY
                                        + RAT_CREATION_PROBABILITY
                                        + SNAKE_CREATION_PROBABILITY
                                        + ELEPHANT_CREATION_PROBABILITY
                                        + BANANA_CREATION_PROBABILITY
                                        + VEGETATION_CREATION_PROBABILITY)
                            )));
        // used to randomize which actor is created at at each location
        ArrayList<Class> actorClasses = new ArrayList<Class>(actorCounts.keySet());
        
        
        Iterator<Location> locationIt = locations.iterator();
        while(locationIt.hasNext() && actorClasses.size() > 0) {
            Location location = locationIt.next();
            Actor actor = null;
            
            Class actorClass = actorClasses.get(rand.nextInt(actorClasses.size()));
            Constructor actorConstructor = null;
            try {
                if (actorClass != null) {
                    // attempts to get a constructor for the actor
                    actorConstructor = 
                        actorClass.getConstructor(Boolean.class, Field.class, Location.class);
                }
            } catch (NoSuchMethodException e) {
                System.out.println(actorClass + 
                    " requires a constructor that takes (Boolean, Field, Location)");
            }
            
            try {
                if (actorConstructor != null) {
                    // if the randomly chosen class was not null
                    actor = (Actor) actorConstructor.newInstance(true, field, location);
                }
            } catch (InstantiationException e) {
                System.out.println(e);
            } catch (IllegalAccessException e) {
                System.out.println(actorClass + 
                    " requires a PUBLIC constructor that takes (boolean, Field, Location");
            } catch (InvocationTargetException e) {
                System.out.println(actorClass + 
                    " requires a PUBLIC constructor that takes (boolean, Field, Location");
            } 
            
            // reduces the remaining count of the actor type
            actorCounts.put(actorClass, actorCounts.get(actorClass) - 1);
            if (actorCounts.get(actorClass) == 0) {
                actorClasses.remove(actorClass);
            }
            
            if (actor instanceof Animal) {
                if (rand.nextDouble() <= INITIAL_FLU_PROBABILITY) {
                    ((Organism) actor).addDisease(new Flu());
                }
            }
            
            if (actor != null)
                actors.add(actor);
        }
        
        Collections.shuffle(actors);
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
