 

/**
 * A simple model of a unicorn.
 * unicorns age, move, breed, and die.
 *
 * @version 01.03.2022
 */
public class Unicorn extends Predator
{
    // Characteristics shared by all unicorns (class variables).

    // The age at which a unicorn can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a unicorn can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a unicorn breeding.
    private static final double BREEDING_PROBABILITY = 0.274;
    //probability of winning a duel with a dragon.
    private static final double DRAGON_WIN_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    //food value of a rat
    private static final int RAT_FOOD_VALUE = 12;
    //food value of a cat
    private static final int CAT_FOOD_VALUE = 17;
    //food value of a beetle
    private static final int BEETLE_FOOD_VALUE = 8;
    //food value of a dragon
    private static final int DRAGON_FOOD_VALUE = 25;
    //maximum food capacity 
    private static final int MAX_FOOD_LEVEL = 100;

    
    /**
     * Create a new unicorn. A unicorn may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the unicorn will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Unicorn(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL);
    }
    
    /**
     * create a new breeded unicorn
     */
    protected Actor newActor(boolean randomAge, Field field, Location location)
    {
        return new Unicorn(randomAge, field, location);
    }
    
    /**
     * @return food value of a rat
     */
    protected int getRAT_FOOD_VALUE()
    {
        return RAT_FOOD_VALUE;
    }
    
    /**
     * @return food value of a cat
     */
    protected int getCAT_FOOD_VALUE()
    {
        return CAT_FOOD_VALUE;
    }
    
    /**
     * @return food value of a beetle
     */
    protected int getBEETLE_FOOD_VALUE()
    {
        return BEETLE_FOOD_VALUE;
    }
    
    /**
     * @return food value of a dragon
     */
    protected int getDRAGON_FOOD_VALUE()
    {
        return DRAGON_FOOD_VALUE;
    }
    
    /**
     * @return food value of a unicorn
     */
    protected int getUNICORN_FOOD_VALUE()
    {
        return 0;
    }
    
    /**
     * @return the probability of winning against a dragon
     */
    protected double getDRAGON_WIN_PROBABILITY()
    {
        return DRAGON_WIN_PROBABILITY;
    }
    
    /**
     * @return whether the animal is a unicorn or not, in this case it is,
     * so return true
     */
    protected boolean isUnicorn()
    {
        return true;
    }
}