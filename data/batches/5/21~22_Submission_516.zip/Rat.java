 

/**
 * A simple model of a rat.
 * rats age, move, breed, and die.
 *
 * @version 01.03.2022
 */
public class Rat extends Prey
{
    // Characteristics shared by all rats (class variables).

    // The age at which a rat can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a rat can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a rat breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 25;
    //food value of a plant
    private static final int PLANT_FOOD_VALUE = 15;
    //max food value
    private static final int MAX_FOOD_LEVEL = 20;
    //setting night time
    private boolean night;
    
    /**
     * Create a new rat. A rat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rat(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL);
        night = false;
    }
    
    /**
     * A rat can breed if it has reached the breeding age, and if it is night time.
     * @return true if the rat can breed, false otherwise.
     */
    protected boolean canProduce() 
    {
        if (night) { //only breeds at night
            night = false;
            return super.canProduce();
        }
        else {
            return false;
        }
    }
    
    /**
     * sets the time of day to be night
     * set night as true if it is night time
     */
    protected void setNight()
    {
        night = true;
    }
    
    /**
     * creates a new breeded rat
     */
    protected Actor newActor(boolean randomAge, Field field, Location location)
    {
        return new Rat(randomAge, field, location);
    }
    
    /**
     * @return the food value of a plant
     */
    protected int getPLANT_FOOD_VALUE()
    {
        return PLANT_FOOD_VALUE;
    }
}
