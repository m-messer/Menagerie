 

import java.util.Random;

/**
 * Weather class for drought, shows effects of drought
 *
 * @version 01.03.2022
 */
public class Drought extends Weather
{
    //probability of plants dying from drought
    private static final double DROUGHT_DEATH_PROBABILITY = 0.5;
    /**
     * Constructor for objects of class Drought
     */
    public Drought()
    {

    }

    /**
     * Effects on actors due to drought 
     * @param actor being affected
     */
    public void weatherEffects(Actor actor)
    {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= DROUGHT_DEATH_PROBABILITY) {
            if (actor instanceof Plant) {
                Plant plant = (Plant) actor;
                plant.setInactive(); //plants die from drought 
            }
        }
    }
}
