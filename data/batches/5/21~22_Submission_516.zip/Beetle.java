 

/**
 * A simple model of a beetle.
 * beetles age, move, breed, and die.
 *
 * @version 01.03.2022
 */
public class Beetle extends Prey
{
    // Characteristics shared by all beetles (class variables).

    // The age at which a beetle can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a beetle can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a beetle breeding.
    private static final double BREEDING_PROBABILITY = 0.37;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    //food value of a plant
    private static final int PLANT_FOOD_VALUE = 5;
    //maximum food value
    private static final int MAX_FOOD_LEVEL = 13;

    /**
     * Create a new beetle. A beetle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the beetle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Beetle(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL);
    }
    
    /**
     * create a new breeded beetle
     */
    protected Actor newActor(boolean randomAge, Field field, Location location)
    {
        return new Beetle(randomAge, field, location);
    }
    
    /**
     * return the food value for a plant
     */
    protected int getPLANT_FOOD_VALUE()
    {
        return PLANT_FOOD_VALUE;
    }
    }