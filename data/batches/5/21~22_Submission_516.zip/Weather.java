 

/**
 * Class to set the weather effects in action
 *
 * @version 01.03.2022
 */
public abstract class Weather 
{
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        
    }
    
    /**
     * creating the weather effects in the simulation
     */
    public abstract void weatherEffects(Actor actor);
}