 

/**
 * A simple model of a dragon.
 * dragons age, move, breed, and die.
 *
 * @version 01.03.2022
 */
public class Dragon extends Predator
{
    // Characteristics shared by all dragons (class variables).

    // The age at which a dragon can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a dragon can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a dragon breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    
    private static final double DRAGON_WIN_PROBABILITY = 0.148;
    
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    private static final int RAT_FOOD_VALUE = 7;
    
    private static final int CAT_FOOD_VALUE = 11;
    
    private static final int BEETLE_FOOD_VALUE = 5;

    private static final int MAX_FOOD_LEVEL = 40;
    
    private static final int UNICORN_FOOD_VALUE = 15;
    
    private static final int DRAGON_FOOD_VALUE = 20;

    /**
     * Create a new Dragon. A dragon may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the dragon will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Dragon(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL);
    }
    
    /**
     * Creation of a new breeded dragon
     */
    protected Actor newActor(boolean randomAge, Field field, Location location)
    {
        return new Dragon(randomAge, field, location);
    }
    
    /**
     * @return rats food value
     */
    protected int getRAT_FOOD_VALUE()
    {
        return RAT_FOOD_VALUE;
    }
    
    /**
     * @return cats food value
     */
    protected int getCAT_FOOD_VALUE()
    {
        return CAT_FOOD_VALUE;
    }
    
    /**
     * @return beetle food value
     */
    protected int getBEETLE_FOOD_VALUE()
    {
        return BEETLE_FOOD_VALUE;
    }
    
    protected int getDRAGON_FOOD_VALUE()
    {
        return DRAGON_FOOD_VALUE;
    }
    
    /**
     * @return unicorns food value
     */
    protected int getUNICORN_FOOD_VALUE()
    {
        return UNICORN_FOOD_VALUE;
    }
    
    /**
     * @return the probability of a dragon winning a duel
     */
    protected double getDRAGON_WIN_PROBABILITY()
    {
        return DRAGON_WIN_PROBABILITY;
    }
    
    /**
     * @return false as a dragon is not a unicorn.
     */
    protected boolean isUnicorn()
    {
        return false;
    }
}