 

import java.util.ArrayList;
import java.util.Random;

/**
 * The class that generates the weather
 *
 * @version 01.03.2022
 */
public class WeatherGenerator
{
    //probabilities of all weather effects
    private static final double DROUGHT_PROBABILITY = 0.1;
    private static final double SNOW_PROBABILITY = 0.15;
    private static final double FOG_PROBABILITY = 0.45;
    private static final double RAIN_PROBABILITY = 0.8;
    
    private Drought drought;
    private Snow snow;
    private Fog fog;
    private Rain rain;    
    /**
     * Constructor for objects of class WeatherGenerator
     * initialising the weather
     */
    public WeatherGenerator()
    {
        drought = new Drought();
        snow = new Snow();
        fog = new Fog();
        rain = new Rain();
    }

    /**
     * Generator of the weather, randomizer checks a value against probabilities
     * @return Weather if above the probability of the weather effect, null otherwise
     */
    public Weather generate()
    {
        Random rand = Randomizer.getRandom();
        
        if (rand.nextDouble() <= DROUGHT_PROBABILITY) {
            return drought;
        }
        else if (rand.nextDouble() <= SNOW_PROBABILITY) {
            return snow;
        }
        else if (rand.nextDouble() <= FOG_PROBABILITY) {
            return fog;
        }
        else if (rand.nextDouble() <= RAIN_PROBABILITY) {
            return rain;
        }
        return null; //value not above threshold
    }
}
