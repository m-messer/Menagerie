
/**
 * A simple model of a Cat
 * Cats age, move, eat, and die.
 *
 * @version 01.03.2022
 */
public class Cat extends Animal
{
    // Characteristics shared by all Cats (class variables).

    // The age at which a cat can start to breed.
    private static final int BREEDING_AGE = 11;
    // The age to which a cat can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a cat breeding.
    private static final double BREEDING_PROBABILITY = 0.47;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single rat. In effect, this is the
    // number of steps a cat can go before it has to eat again.
    private static final int RAT_FOOD_VALUE = 17;
    //maximum food value of a cat
    private static final int MAX_FOOD_LEVEL = 25;
    
    /**
     * Create a cat. A cat can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cat will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cat(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL);
    }
    
    /**
     * Called during night time, stops cat from moving and makes it more hungry
     */
    protected void isSleeping()
    {
        incrementHunger();
        setHibernate(); // sleep
    }
    
    /**
     * creation of a breeded cat
     */
    protected Actor newActor(boolean randomAge, Field field, Location location)
    {
        return new Cat(randomAge, field, location);
    }
    
    /**
     * The animals that can be eaten by the cat
     * Cats can eat rats
     * @param actor ( species of the animal nearby )
     */
    protected boolean animalFood(Object actor)
    {
        if(actor instanceof Rat) {
            Rat rat = (Rat) actor;
            if(rat.isActive()) { 
                rat.setInactive();
                if (getFoodLevel() < MAX_FOOD_LEVEL - RAT_FOOD_VALUE) {
                    setFoodLevel(RAT_FOOD_VALUE);
                }
                return true;
            }
        }
        else if(actor instanceof Plant) {
            Plant plant = (Plant) actor;
            if (plant.isActive()) {
                plant.setInactive();
                return true;
            }
        }
        return false;
    }
    }
