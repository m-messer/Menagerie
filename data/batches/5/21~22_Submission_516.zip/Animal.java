

import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 01.03.2022
 */
public abstract class Animal extends Actor
{
    //foodlevel of the animal
    private int foodLevel;
    //sleep
    private boolean hibernate;
    //weather
    private boolean fog;
    
    private boolean disease;
    //recovery from disease
    private boolean recovered;
    
    //disease variables
    private static final double DISEASE_PROBABILITY = 0.3;
    private static final double MORTALITY_RATE = 0.05;
    private static final double RECOVERY_PROBABILITY = 0.4;
    
    private final int MAX_FOOD_LEVEL;
    
    //gender of animal
    private boolean female;

    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location, int MAX_AGE, int PRODUCTION_AGE, double PRODUCTION_PROBABILITY, int MAX_YOUNG_SIZE, int MAX_FOOD_LEVEL)
    {
        super(field,location,MAX_AGE,PRODUCTION_AGE, PRODUCTION_PROBABILITY,MAX_YOUNG_SIZE);
        this.MAX_FOOD_LEVEL = MAX_FOOD_LEVEL;
        if(randomAge) {
            setAge(rand.nextInt(getMAX_AGE()));
            foodLevel = rand.nextInt(getMAX_FOOD_LEVEL());
        }
        else {
            foodLevel = getMAX_FOOD_LEVEL();
        }
        randomDisease(); //simulates disease
        setFemale(); //creates male and female species
    }

    /**
     * This is what the animals do most of the time.
     * In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newActors A list to return newly born animals.
     */
    public void act(List<Actor> newAnimal)
    {
        setEffects(); //effects of disease
        
        //cannot move when hibernating
        if (hibernate) {
            incrementAge();
            hibernate = false;
            return;
        }

        incrementAge();
        incrementHunger();
        
        if(isActive()) {
            newProduction(newAnimal);            
            // Move towards a source of food if found.
            Location newLocation = null;
            if (fog) {
                fog = false; //stops fog
            }
            else {
                newLocation = findFood();
            }

            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                randomDisease(); //disease occurs
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setInactive();
            }
        }
    }
    
    /**
     * returns the maximum food level for the animal
     */
    protected int getMAX_FOOD_LEVEL()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Make the animals more hungry. This could result in the animals' death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setInactive(); //dies if no food
        }
    }
    
    /**
     * returns the foodlevel
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * increments the food level by an amount
     */
    protected void setFoodLevel(int newFoodLevel)
    {
        foodLevel += newFoodLevel;
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        //list of all free spaces
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            boolean check = animalFood(actor);
            spreadDisease(actor);//if disease has been caught,
            //it spreads onto the surrounding animal
            if (check) {
                return where;
            }
        }
        return null;
    }

    abstract protected boolean animalFood(Object actor);
    
    /**
     * 50/50 chance of an animal being male or female.
     */
    protected void setFemale()
    {
       female = rand.nextDouble() <= 0.5;
    }
    
    /**
     * returns true if an animal is a female
     */
    protected boolean isFemale()
    {
        return female;
    }
    
    /**
     * Animals can breed if it has reached the breeding age and if there is an adjacent animal of the same species and opposite
     * gender.
     * @return true if the animals can breed, false otherwise.
     */
    protected boolean canProduce()
    {
        Field field = getField(); 
        //creating a list of free spaces
        List<Location> spaces = field.adjacentLocations(getLocation());
        
        for (Location space: spaces){
            Object occupied = field.getObjectAt(space); //gets the animal in the space
            if (occupied!=null && this.getClass() == occupied.getClass()){//checks if same type of animal
                Animal mate = (Animal) occupied;
                if (this.isFemale() && !mate.isFemale()){//checks if opposing gender
                    if (getAge() >= getPRODUCTION_AGE()){//checks if can breed
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * sleep due to snow and time of day
     */
    protected void setHibernate()
    {
        hibernate = true;
    }

    /**
     * sets a foggy weather
     */
    protected void setFog()
    {
        fog = true;
    }
    
    /**
     * method that is called when disease is being spread
     * @param actor
     */
    protected void spreadDisease(Object actor)
    {
        if (actor instanceof Animal) {
            Animal animal = (Animal) actor;
            if (animal.haveDisease() && !haveDisease() && !isRecovered()) {
                setDisease(); //gives an animal disease 
            }
            else if (!animal.haveDisease() && haveDisease() && !animal.isRecovered()) {
                animal.setDisease(); //spreading of disease
            }
        }
    }
    
    /**
     * returns true if animal has disease
     */
    protected boolean haveDisease()
    {
        return disease;
    }

    /**
     * sets true for animal with disease
     */
    protected void setDisease()
    {
        disease = true;
    }
    
    /**
     * creates a random disease
     */
    protected void randomDisease()
    {
        Random rand = Randomizer.getRandom();
        if(rand.nextDouble() <= DISEASE_PROBABILITY) { //matches against probability
            if (!isRecovered()) { //checks if recovered or not
                disease = true;
            }
        }
    }
    
    /**
     * returns true if animal is recovered from disease
     */
    protected boolean isRecovered()
    {
        return recovered;
    }
    
    /**
     * implementation of the effects of disease
     */
    protected void setEffects()
    {
        if (disease) {
            hibernate = true; //sleeps due to disease
            incrementHunger(); //more hungry
            Random rand = Randomizer.getRandom();
            if(rand.nextDouble() <= MORTALITY_RATE) {
                setInactive(); //dies if above mortality rate
            }

            if(rand.nextDouble() <= RECOVERY_PROBABILITY) {
                recovered = true;
                disease = false;
            }
        }
    }
}