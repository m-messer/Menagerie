 

import java.util.Random;

/**
 * Foggy weather class, shows effects on fog on actors
 *
 * @version 01.03.2022
 */
public class Fog extends Weather
{
    //probability of fog affecting vision
    private static final double LOW_VISIBILITY_PROBABILITY = 0.7;
    /**
     * Constructor for objects of class Fog
     */
    public Fog()
    {
        
    }
    
    /**
     * Implementatioon of the effect of fog on actors
     * @param the actor beign affected
     */
    public void weatherEffects(Actor actor)
    {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= LOW_VISIBILITY_PROBABILITY) {
            if (actor instanceof Animal) {
                Animal animal = (Animal) actor;
                animal.setFog(); //Animals are unable to hunt for food since they cannot see their prey
            }
        }
    }
}
