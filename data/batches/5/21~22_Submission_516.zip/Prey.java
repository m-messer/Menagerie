 

/**
 * Animals that can be eaten are called Prey
 *
 * @version 01.03.2022
 */
public abstract class Prey extends Animal
{
     /**
     * Constructor for objects of class Prey
     */
    public Prey(boolean randomAge, Field field, Location location, int MAX_AGE, int PRODUCTION_AGE, double PRODUCTION_PROBABILITY, int MAX_YOUNG_SIZE, int MAX_FOOD_LEVEL)
    {
        // initialise instance variables
        super(randomAge, field, location, MAX_AGE,PRODUCTION_AGE, PRODUCTION_PROBABILITY,MAX_YOUNG_SIZE, MAX_FOOD_LEVEL);
    }

    /**
     * Method for eating other actors, includes setting the actor dead when eaten, and increasing
     * food value of the animal that has ate.
     * prey can only eat plants
     * @param actor - type of species
     */
    protected boolean animalFood(Object actor)
    {
        if(actor instanceof Plant) {
            Plant plant = (Plant) actor;
            if(plant.isActive() && plant.isEdible()) { 
                plant.setInactive();
                if (getFoodLevel() < getMAX_FOOD_LEVEL() - getPLANT_FOOD_VALUE()) {
                    setFoodLevel(getPLANT_FOOD_VALUE());
                }
                return true;
            }
        }
        return false;
    }
    
    /**
     * @returns food value of plant
     */
    protected abstract int getPLANT_FOOD_VALUE();
    
}
