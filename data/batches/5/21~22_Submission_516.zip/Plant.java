 

import java.util.List;
import java.util.Random;

/**
 * Plant class
 *
 * @version 01.03.2022
 */
public class Plant extends Actor
{
    //max age of the plant
    private static final int MAX_AGE = 300;
    //age which plants can be eaten
    private static final int EDIBLE_AGE = 3;
    //age which plants can produce new seedlings
    private static final int PRODUCE_SEEDS_AGE = 3;
    //probability of new seeds being grown
    private static final double SEED_PROBABILITY = 0.7;
    //max seedlings per plant
    private static final int MAX_SEEDLINGS = 15;
    //weather
    private boolean raining;


    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Plant
     * @params boolean random age, field and location of the plant
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE, PRODUCE_SEEDS_AGE, SEED_PROBABILITY, MAX_SEEDLINGS);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        }
    }

    /**
     * the actions of the plants, production of new plants 
     */
    public void act(List<Actor> newPlants)
    {
        incrementAge();
        if (isActive()) {
            newProduction(newPlants);
        }
    }

    /**
     * production probability if it is raining or not
     */
    protected double getPRODUCTION_PROBABILITY()
    {
        if (raining) {
            raining = false;
            return SEED_PROBABILITY;
        }
        return 0; //cant grow if not raining
    }
    
    /**
     * creation of a new plant from a seed
     */
    protected Actor newActor(boolean randomAge, Field field, Location location)
    {
        return new Plant(randomAge, field, location);
    }
    
    /**
     * gets the age at which a plant is edible. If edible then
     * @return true
     */
    protected boolean isEdible()
    {
        return getAge() >= EDIBLE_AGE;
    }
    
    /**
     * sets the raining variable to true
     */
    protected void isRaining()
    {
        raining = true;
    }
}
