 

import java.util.List;
import java.util.Random;

/**
 * Superclass inherited by animals and plants
 * Class holding all details of the living things in the simulation
 *
 * @version 01.03.2022
 */
public abstract class Actor
{
    // Whether the actor is active or not.
    private boolean active;
    // The actor's field.
    private Field field;
    // The actors's position in the field.
    private Location location;
    //age of actor
    private int age;
    
    //max age of an actor
    private final int MAX_AGE;
    //age which they are produced
    private final int PRODUCTION_AGE;
    //probability of them being produced
    private final double PRODUCTION_PROBABILITY;
    //max litter size for all actors
    private final int MAX_YOUNG_SIZE;

    private static final Random rand = Randomizer.getRandom();
    
    /**
     * constructor for actors
     * creates a new actor
     * @params where they are placed (field and location), maximum age, age which they can reproduce
     * , probability of being made and max litter size.
     */
    public Actor(Field field, Location location, int MAX_AGE, int PRODUCTION_AGE, double PRODUCTION_PROBABILITY, int MAX_YOUNG_SIZE)
    {
        //initial variables
        active = true;
        this.field = field;
        setLocation(location);
        age = 0;
        
        this.MAX_AGE = MAX_AGE;
        this.PRODUCTION_AGE = PRODUCTION_AGE;
        this.PRODUCTION_PROBABILITY = PRODUCTION_PROBABILITY;
        this.MAX_YOUNG_SIZE = MAX_YOUNG_SIZE;
    }
    
    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive new actors.
     */
    public abstract void act(List<Actor> newActors);
    
    /**
     * Check whether the actor is active or not.
     * @return true if the actor is still active.
     */
    protected boolean isActive()
    {
        return active;
    }
    
    /**
     * Indicate that the actor is no longer active.
     * It is removed from the field.
     */
    protected void setInactive()
    {
        active = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * sets a new age for the actors
     * @param integer number for age
     */
    protected void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * @return age of the actor
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Increase the age. This could result in the actor's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMAX_AGE()) {
            setInactive();
        }
    }
    
    /**
     * Actors can breed if it has reached the breeding age.
     * @return true if the actor can breed, false otherwise.
     */
    protected boolean canProduce()
    {
        return age >= getPRODUCTION_AGE();
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int produce()
    {
        int newSpecies = 0;
        if(canProduce() && rand.nextDouble() <= getPRODUCTION_PROBABILITY()) {
            newSpecies = rand.nextInt(getMAX_YOUNG_SIZE()) + 1;
        }
        return newSpecies;
    }

    /**
     * Check whether or not this actor is to give birth at this step.
     * New actor will be made into free adjacent locations.
     * @param newActor A list to return newly born actors.
     */
    protected void newProduction(List<Actor> newActor)
    {
        // New actors are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int newSpecies = produce();
        for(int b = 0; b < newSpecies && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Actor young = newActor(false, field, loc);
            newActor.add(young);
        }
    }

    /**
     * creation of newly breeded actors
     */
    abstract protected Actor newActor(boolean randomAge, Field field, Location location);
    
    /**
     * @return max age of actor
     */
    protected int getMAX_AGE()
    {
        return MAX_AGE;
    }
    
    /**
     * @return production age of actor
     */
    protected int getPRODUCTION_AGE()
    {
        return PRODUCTION_AGE;
    }

    /**
     * @return probability of actor being made
     */
    protected double getPRODUCTION_PROBABILITY()
    {
        return PRODUCTION_PROBABILITY;
    }
    
    /**
     * @return actors litter size
     */
    protected int getMAX_YOUNG_SIZE()
    {
        return MAX_YOUNG_SIZE;
    }
}
