 

import java.util.List;
import java.awt.Color;
import java.util.Random;

/**
 * Generates the population, that is the actors and plants in the simulation to be shown
 * on the field.
 *
 * @version 01.03.2022
 */
public class PopulationGenerator
{
    // The probability that a cat will be created in any given grid position.
    private static final double CAT_CREATION_PROBABILITY =0.055;
    // The probability that a rat will be created in any given grid position.
    private static final double RAT_CREATION_PROBABILITY =0.1;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY =0.3;
    // The probability that a beetle will be created in any given grid position.
    private static final double BEETLE_CREATION_PROBABILITY =0.1;
    // The probability that a dragon will be created in any given grid position.
    private static final double DRAGON_CREATION_PROBABILITY =0.035;
    // The probability that a unicorn will be created in any given grid position.
    private static final double UNICORN_CREATION_PROBABILITY =0.05;
    /**
     * Constructor for objects of class PopulationGenerator
     */
    public PopulationGenerator(SimulatorView view)
    {
        setColor(view); //sets colour for each actor
    }

    /**
     * Method that sets seperate colours for each animal on the field.
     * @param a simulatorview object
     */
    private void setColor(SimulatorView view)
    {
        view.setColor(Rat.class, Color.ORANGE);
        view.setColor(Cat.class, Color.BLUE);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Beetle.class, Color.BLACK);
        view.setColor(Dragon.class, Color.RED);
        view.setColor(Unicorn.class, Color.PINK);
    }
    
    /**
     * Randomly populate the field with actors.
     */
    public void populate(Field field, List<Actor> actors)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= CAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cat cat = new Cat(true, field, location);
                    actors.add(cat);
                }
                else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(true, field, location);
                    actors.add(rat);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    actors.add(plant);
                }
                else if(rand.nextDouble() <= BEETLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Beetle beetle = new Beetle(true, field, location);
                    actors.add(beetle);
                }
                else if(rand.nextDouble() <= DRAGON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dragon dragon = new Dragon(true, field, location);
                    actors.add(dragon);
                }
                else if(rand.nextDouble() <= UNICORN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Unicorn unicorn = new Unicorn(true, field, location);
                    actors.add(unicorn);
                } 
                // else leave the location empty.
            }
        }
    }
}
