import java.util.Random;

/**
 * A class including all shared attributes of predators
 *
 * @version 01.03.2022
 */
public abstract class Predator extends Animal
{

    /**
     * Constructor for objects of class Predator
     */
    public Predator(boolean randomAge, Field field, Location location, int MAX_AGE, int PRODUCTION_AGE, double PRODUCTION_PROBABILITY, int MAX_YOUNG_SIZE, int MAX_FOOD_LEVEL)
    {
        super(randomAge, field, location, MAX_AGE,PRODUCTION_AGE, PRODUCTION_PROBABILITY,MAX_YOUNG_SIZE, MAX_FOOD_LEVEL);
    }
    
    
    /**
     * Method for eating other animals, includes setting the animal dead when eaten, and increasing
     * food value of the animal that has ate.
     * @param actor - type of animal
     */
    protected boolean animalFood(Object actor)
    {
        if(actor instanceof Rat) {
            Rat rat = (Rat) actor;
            if(rat.isActive()) { 
                rat.setInactive(); //death
                if (getFoodLevel() < getMAX_FOOD_LEVEL() - getRAT_FOOD_VALUE()) {
                    setFoodLevel(getRAT_FOOD_VALUE()); //sets the food value of this animal
                }
                return true;
            }
        }
        else if(actor instanceof Cat) {
            Cat cat = (Cat) actor;
            if(cat.isActive()) { 
                cat.setInactive();
                if (getFoodLevel() < getMAX_FOOD_LEVEL() - getCAT_FOOD_VALUE()) {
                    setFoodLevel(getCAT_FOOD_VALUE());
                }
                return true;
            }
        }
        else if(actor instanceof Beetle) {
            Beetle beetle = (Beetle) actor;
            if(beetle.isActive()) { 
                beetle.setInactive();
                if (getFoodLevel() < getMAX_FOOD_LEVEL() - getBEETLE_FOOD_VALUE()) {
                    setFoodLevel(getBEETLE_FOOD_VALUE());
                }
                return true;
            }
        }
        else if(actor instanceof Plant) {
            Plant plant = (Plant) actor;
            if (plant.isActive()) {
                plant.setInactive();
                return true;
            }
        }
        else if (actor instanceof Dragon) {
            Dragon dragon = (Dragon) actor;
            if(dragon.isActive() && defeatDragon()) { 
                dragon.setInactive();
                if (getFoodLevel() < getMAX_FOOD_LEVEL() - getDRAGON_FOOD_VALUE()) {
                    setFoodLevel(getDRAGON_FOOD_VALUE());
                }
                return true;
            }
        }
        else if (actor instanceof Unicorn) {
            Unicorn unicorn = (Unicorn) actor;
            if(unicorn.isActive() && !isUnicorn()) { 
                unicorn.setInactive();
                if (getFoodLevel() < getMAX_FOOD_LEVEL() - getUNICORN_FOOD_VALUE()) {
                    setFoodLevel(getUNICORN_FOOD_VALUE());
                }
                return true;
            }
        }
        return false;
    }
    
    /**
     * @return true if the randomizer chooses a value that determines winning against the dragon.
     */
    protected boolean defeatDragon()
    {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= getDRAGON_WIN_PROBABILITY()) {
            return true;
        }
        return false;
    }

    protected abstract boolean isUnicorn();

    protected abstract int getRAT_FOOD_VALUE();

    protected abstract int getCAT_FOOD_VALUE();

    protected abstract int getBEETLE_FOOD_VALUE();

    protected abstract int getDRAGON_FOOD_VALUE();

    protected abstract int getUNICORN_FOOD_VALUE();

    protected abstract double getDRAGON_WIN_PROBABILITY();
}
