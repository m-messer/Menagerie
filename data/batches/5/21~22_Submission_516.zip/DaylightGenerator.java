 

/**
 * This class generates the time of day and changes the hours of the day.
 *
 * @version 01.03.2022
 */
public class DaylightGenerator
{
    // hour of the day, same as steps
    private int hour;
    
    /**
     * Initialises the hour to 0 at the beginning of the simulation
     */
    public DaylightGenerator()
    {
        hour = 0;
    }
    
    /**
     * increments the hour
     */
    public void increment()
    {
        hour++;
        if (hour > 24){ //resets every 24 hours to simulate a day
            hour = 0;
        }
    }
    
    /**
     * called when the entire simulation is reset
     */
    public void reset()
    {
        hour = 0;
    }
    
    /**
     * @returns the hour of the day
     */
    public int getHour()
    {
        return hour;
    }
    
    /**
     * checks if it is nighttime
     * @return true if night and false if not
     */
    public boolean isNight()
    {
        if (hour>=0 && hour<=6) { //nighttime is between 00;00 and 06;00
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Implementation of the effects of the time of day on certain animals
     * @param animal
     */
    public void effects(Actor animal)
    {
        if (animal instanceof Cat) {
            Cat cat = (Cat) animal;
            cat.isSleeping();//cat sleeps during night time
        }
        
        else if (animal instanceof Rat) {
            Rat rat = (Rat) animal;
            rat.setNight(); //rat breeds during night
        }
    }
}
