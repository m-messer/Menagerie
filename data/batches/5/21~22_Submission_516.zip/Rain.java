 

/**
 * Implementation of rainy weather
 *
 * @version 01.03.2022
 */
public class Rain extends Weather
{

    /**
     * Constructor for objects of class Rain
     */
    public Rain()
    {
        
    }
    
    /**
     * effects on actors from rain
     * @param actors
     */
    public void weatherEffects(Actor actor)
    {
        if (actor instanceof Plant) {
            Plant plant = (Plant) actor;
            plant.isRaining(); //plants only grow during rainy weather
        }
    }
}
