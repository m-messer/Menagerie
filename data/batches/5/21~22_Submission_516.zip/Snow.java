 

import java.util.Random;

/**
 * Weather class for snow, shows effects of snow
 *
 * @version 01.03.2022
 */
public class Snow extends Weather
{
    // probability of plants dying from snow
    private static final double SNOW_DEATH_PROBABILITY = 0.3;
    /**
     * Constructor for objects of class Snow
     */
    public Snow()
    {
    }

    /**
     * The effects of snow on the actors
     * @param actor (type of animal)
     */
    public void weatherEffects(Actor actor)
    {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= SNOW_DEATH_PROBABILITY) { 
            if (actor instanceof Plant) {
                Plant plant = (Plant) actor;
                plant.setInactive(); //plants die from snow
            }
        }
        if (actor instanceof Animal) {
            Animal animal = (Animal) actor;
            animal.setHibernate(); //all animals hibernate in snowy weather
        }
    }
}
