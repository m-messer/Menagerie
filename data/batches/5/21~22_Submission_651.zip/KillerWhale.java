import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a killer whale (also known as an orca).
 * Killer whales age, move, eat salmon or sea birds, and die.
 *
 * @version 2022.02.09
 */
public class KillerWhale extends Predator
{
    private static final int BREEDING_AGE = 8;
    // The age to which a whale can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a whale breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The food value of a single salmon
    private static final int FOOD_VALUE_SALMON = 9;
    // The food value of a single seabird
    private static final int FOOD_VALUE_BIRD = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private int age;
    // The number of steps the killer whale can take, which is increased by eating salmon or sea birds
    private int foodLevel;

    /**
     * Constructor for objects of class KillerWhale
     * 
     * @param randomAge If true, the whale will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public KillerWhale(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE_SALMON);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE_SALMON; // start the killer whale with a food value equivalent to eating a salmon
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location hunt()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Salmon) {
                Salmon salmon = (Salmon) animal;
                if(salmon.isAlive()) { 
                    salmon.setDead();
                    foodLevel = FOOD_VALUE_SALMON;
                    return where;
                }
            }
            if(animal instanceof SeaBird) {
                SeaBird seabird = (SeaBird) animal;
                if(seabird.isAlive()) { 
                    seabird.setDead();
                    foodLevel = FOOD_VALUE_BIRD;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * This is what the whale does most of the time: it hunts for
     * sardines. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWhales A list to return newly born whales.
     */
    public void act(List<Animal> newWhales)
    {
        incrementAge();
        incrementHunger();
        
        if (getInfectionStatus() == false)
        {
            tryAndInfectThisAnimal();
        }
        
        if(isAlive() && getInfectionStatus() == false) {
            giveBirth(newWhales);            
            // Move towards a source of food if found.
            Location newLocation = hunt();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        else if (isAlive() && getInfectionStatus() == true) {
            tryAndInfectNeighbours();
            Location newLocation = hunt();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age. This could result in the whale's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this fox more hungry. This could result in the whale's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this killer whale is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWhales A list to return newly born killer whales.
     */
    private void giveBirth(List<Animal> newWhales)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            KillerWhale young = new KillerWhale(false, field, loc);
            newWhales.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        List<Object> neighbours = new ArrayList<>();
        for (Location loc: adjacent) {
            Object animal = (Animal) field.getObjectAt(loc);
            if (animal != null)
            {
               neighbours.add(animal); // collecting all neighbouring animals 
            }
        }
        
        for (Object animal: neighbours) {
            Animal species = (Animal) animal;
            if (species instanceof KillerWhale) // we want to try and breed only if the animals are the same species
            {
                KillerWhale whale = (KillerWhale) species;
                boolean differentGender = whale.getGender() != this.getGender(); // have to be different genders to breed
                if (differentGender && canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)
                {
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                    return births;
                }
            }
        }
        
        return births;
    }
    
    /**
     * A killer whale can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
