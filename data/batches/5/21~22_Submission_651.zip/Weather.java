import java.util.Random;

/**
 * The Weather class is used to simulate the random weather conditions
 * in the ecosystem.
 *
 * @version 2022.02.17
 */
public class Weather
{
    
    private boolean isRaining;
    private boolean isSunny;
    private Random rand = Randomizer.getRandom();
    private int conditions;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        isRaining = false;
        isSunny = false;
    }
    
    /**
     * Generate random weather conditions, either sun or rain.
     */
    public void generateWeather()
    {
        conditions = rand.nextInt(3);
        if(conditions == 0)
        {
            setRain();
        }
        else if(conditions == 1)
        {
            setSun();
        }
        else {
            setClear();
        }
    }
    
    /**
     * Method that makes the weather conditions rainy.
     */
    public void setRain()
    {
        isRaining = true;
        isSunny = false;
    }

    /**
     * Method that makes the weather conditions sunny.
     */
    public void setSun()
    {
        isRaining = false;
        isSunny = true;
    }
    
    /**
     * 
     */
    public void setClear()
    {
        isRaining = false;
        isSunny = false;
    }

    /**
     * Method that returns the boolean value of whether it is raining or not.
     * 
     * @return true if raining
     */
    public boolean rainChecker()
    {
        return isRaining;
    }

    /**
     * Method that returns the boolean value of whether it is sunny or not.
     * 
     * @return true if sunny
     */
    public boolean sunChecker()
    {
        return isSunny;
    }
    
    /**
     * Returns the weather information as a String
     * 
     * @return The weather details formatted as a String object which can
     * be used to display this information.
     */
    public String toString()
    {
        String text = "";
        if(isSunny == true)
        {
            return text = text + "Sunny";
        }
        else if (isRaining == true) {
            return text = text + "Raining";
        }
        return text = text + "Clear";
    }
}