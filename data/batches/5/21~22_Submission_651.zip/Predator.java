import java.util.List;

/**
 * Predators hunt prey. This class represents shared characteristics
 * of predators.
 *
 * @version 2022.02.18
 */
public abstract class Predator extends Animal
{
    
    /**
     * Constructor for objects of class Predator
     */
    public Predator(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * The 'act' method is implemented by the subclasses of Predator.
     * Each child of Predator has different behaviour when acting.
     * 
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Predators differ from Animals in that they hunt for food.
     */
    abstract protected Location hunt();
}
