import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a sea bird.
 * Sea birds age, move, breed, and die.
 *
 * @version 2022.02.11
 */
public class SeaBird extends Animal
{
    // Characteristics shared by all sea birds (class variables).

    // The age at which a sea bird can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a sea bird can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a sea bird breeding.
    private static final double BREEDING_PROBABILITY = 0.85;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 18;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The sea bird's age.
    private int age;

    /**
     * Constructor for objects of class SeaBird
     */
    public SeaBird(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the sea bird does most of the time - it flies 
     * around. Sometimes it will breed or die of old age.
     * @param newSeaBirds A list to return newly born sea bird.
     */
    public void act(List<Animal> newSeaBirds)
    {
        incrementAge();
        
        if (getInfectionStatus() == false) 
        {
            tryAndInfectThisAnimal();
        }
        
        if(isAlive() && getInfectionStatus() == false) {
            giveBirth(newSeaBirds);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        else if (isAlive() && getInfectionStatus() == true) {
            tryAndInfectNeighbours(); // this occurs if the animal is alive and infected
            Location newLocation = getField().freeAdjacentLocation(getLocation()); // Infected animals do not breed, they just move and infect
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the sea bird's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this seabird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSeaBird A list to return newly born sea bird.
     */
    private void giveBirth(List<Animal> newSeaBirds)
    {
        // New sea birds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            SeaBird young = new SeaBird(false, field, loc);
            newSeaBirds.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        List<Object> neighbours = new ArrayList<>();
        for (Location loc: adjacent) {
            Object animal = (Animal) field.getObjectAt(loc);
            if (animal != null)
            {
                neighbours.add(animal); // collecting all neighbouring animals 
            }
        }

        for (Object animal: neighbours) {
            Animal species = (Animal) animal;
            if (species instanceof SeaBird) // we want to try and breed only if the animals are the same species
            {
                SeaBird seabird = (SeaBird) species;
                boolean differentGender = seabird.getGender() != this.getGender(); // have to be different genders to breed
                if (differentGender && canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)
                {
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                    return births;
                }
            }
        }

        return births;
    }
    
    /**
     * A sea bird can breed if it has reached the breeding age.
     * @return true if the sea bird can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
