import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sharks, salmon, killer whales, sea birds and sardines.
 *
 * @version 2022.02.09
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 170;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 130;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.03;
    // The probability that a salmon will be created in any given grid position.
    private static final double SALMON_CREATION_PROBABILITY = 0.04;
    // The probability that a whale will be created in any given grid position.
    private static final double WHALE_CREATION_PROBABILITY = 0.04;
    // The probability that a sardine will be created in any given grid position.
    private static final double SARDINE_CREATION_PROBABILITY = 0.02;
    // The probability that a sea bird will be created in any given grid position.
    private static final double BIRD_CREATION_PROBABILITY = 0.02;
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A clock which keeps track of the time
    private Time clock;
    // A random weather simulator
    private Weather weather;
    

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        clock = new Time(10); // start the simulation at 10am (10:00)
        weather = new Weather();
        view.showStatus(step, clock.toString(), weather.toString(), field);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();
        clock = new Time();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Salmon.class, Color.MAGENTA);
        view.setColor(Shark.class, Color.BLUE);
        view.setColor(KillerWhale.class, Color.BLACK);
        view.setColor(Sardine.class, Color.ORANGE);
        view.setColor(SeaBird.class, Color.red);

        // Setup a valid starting point.
        reset();
        view.showStatus(step, clock.toString(), weather.toString(), field);
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(30);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     */
    public void simulateOneStep()
    {
        step++;
        clock.incrementTime();
        if (clock.isDay()) {
            view.setFieldColor(Color.white);
        }
        else {
            view.setFieldColor(Color.lightGray);
        }
        
        if( step > 10 && step < 100)
        {
            weather.setSun(); // sunny between steps 11 to 99 to allow predators to hunt efficiently at the start
        }
        
        if( step % 100 == 0 )
        {
            weather.generateWeather();
        }

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        
        // Let all animals act in the daytime.
        if (clock.isDay()) {
          for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if (weather.rainChecker() && (!(animal instanceof Shark) || !(animal instanceof KillerWhale)))
            {
                animal.act(newAnimals); // predators find it harder to hunt in rain so prey move an extra step
            }
            if (weather.sunChecker() && ((animal instanceof Shark) || (animal instanceof KillerWhale)))
            {
                animal.act(newAnimals); // predators thrive in sunny conditions so move an extra step
            }
            if(! animal.isAlive()) {
                it.remove(); 
            }
        }
        }
        
        else {
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal instanceof KillerWhale || animal instanceof SeaBird) // these animals move at night
            {
                animal.act(newAnimals);
            }
            if(! animal.isAlive()) {
                it.remove();
            }
            }
        }

        // Add the newly animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, clock.toString(), weather.toString(), field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, clock.toString(), weather.toString(), field);
    }

    /**
     * Randomly populate the field with animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= SALMON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Salmon salmon = new Salmon(true, field, location);
                    animals.add(salmon);
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    KillerWhale whale = new KillerWhale(true, field, location);
                    animals.add(whale);
                }
                else if(rand.nextDouble() <= SARDINE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sardine sardine = new Sardine(true, field, location);
                    animals.add(sardine);
                }
                else if(rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    SeaBird seabird = new SeaBird(true, field, location);
                    animals.add(seabird);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
