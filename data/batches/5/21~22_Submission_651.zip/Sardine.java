import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a sardine.
 * Sardines age, move, breed, and die.
 * 
 * Sardines are only eaten by sharks
 *
 * @version 2022.02.09
 */
public class Sardine extends Animal
{
    // Characteristics shared by all sardines (class variables).

    // The age at which a sardine can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a sardine can live.
    private static final int MAX_AGE = 10;
    // The likelihood of a sardine breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 50;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The sardine's age.
    private int age;

    /**
     * Create a new sardine. A sardine may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the sardine will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sardine(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the sardine does most of the time - it swims 
     * around. Sometimes it will breed or die of old age.
     * @param newsardine A list to return newly born sardines.
     */
    public void act(List<Animal> newSardines)
    {
        incrementAge();
        
        if (getInfectionStatus() == false) 
        {
            tryAndInfectThisAnimal();
        }
        
        if(isAlive() && getInfectionStatus() == false) {
            giveBirth(newSardines);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        else if (isAlive() && getInfectionStatus() == true) {
            tryAndInfectNeighbours(); // this occurs if the animal is alive and infected
            Location newLocation = getField().freeAdjacentLocation(getLocation()); // Infected animals do not breed, they just move and infect
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the sardine's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this sardine is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newsardine A list to return newly born sardine.
     */
    private void giveBirth(List<Animal> newSardines)
    {
        // New sardine are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Sardine young = new Sardine(false, field, loc);
            newSardines.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        List<Object> neighbours = new ArrayList<>();
        for (Location loc: adjacent) {
            Object animal = (Animal) field.getObjectAt(loc);
            if (animal != null)
            {
                neighbours.add(animal); // collecting all neighbouring animals 
            }
        }

        for (Object animal: neighbours) {
            Animal species = (Animal) animal;
            if (species instanceof Sardine) // we want to try and breed only if the animals are the same species
            {
                Sardine sardine = (Sardine) species;
                boolean differentGender = sardine.getGender() != this.getGender(); // have to be different genders to breed
                if (differentGender && canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)
                {
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                    return births;
                }
            }
        }

        return births;
    }

    /**
     * A sardine can breed if it has reached the breeding age.
     * @return true if the sardine can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
