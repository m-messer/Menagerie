/**
 * The Time class is used as a clock to represent
 * the time of day in the predator-prey simulation.
 *
 * @version 2022.2.12
 */
public class Time
{
    private int time;
    
    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        time = 0;
    }
    
    /**
     * Constructor for objects of class Time
     * 
     * @param newTime The time to start the simulation at
     */
    public Time(int newTime)
    {
        if (isValidTime(newTime)) {
            time = newTime;
        }
        else {
            time = 0; // invalid, start at midnight
        }
    }

    /**
     * Returns the current hour
     * 
     * @return the hour
     */
    public int getHour()
    {
        return time;
    }
    
    /**
     * Increment the hour by one. If it is 11pm (23:00), then the time
     * is set to 12am (00:00)
     * 
     * @return the new hour
     */
    public int incrementTime()
    {
        if(time <= 22)
        {
            time = time + 1;
        }
        else
        {
            time = 0;
        }
        return time;
    }
    
    /**
     * Check if it is currently day time
     * 
     * @return true if it is day time, false otherwise
     */
    public boolean isDay()
    {
        return time >= 9 && time <= 21;
    }
    
    /**
     * Formats the time in a 24-hour clock format to
     * be displayed
     * 
     * @return the time formatted in the 24-hour style
     * as a String
     */
    public String toString()
    {
        String text = "" + time;
        if (time < 10)
        {
            text = "0" + time + ":00";
        }
        else
        {
            text = time + ":00";
        }
        
        if (isDay()) {
            text = text + " - Day Time";
        }
        else {
            text = text + " - Night Time";
        }
        return text;
    }
    
    /**
     * Check if a time is valid
     * 
     * @return if the time value is acceptable
     */
    private boolean isValidTime(int newTime)
    {
        return (newTime >= 0 ) && ( newTime <= 23);
    }
}
