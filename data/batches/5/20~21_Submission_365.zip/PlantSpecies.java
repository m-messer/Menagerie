import java.awt.*;

/**
 * A class representing shared characteristic within a plant species,
 * such as their pollination radius mean and standard deviation. Most
 * stats of plants follow a normal distribution.
 *
 * @version 2021.02.23
 */
public class PlantSpecies extends Species {

    // The pollination radius mean of this species.
    private final int pollinationRadiusMean;

    // The pollination radius standard deviation of this species.
    private final int pollinationRadiusStdDev;

    // The pollination chance mean of this species.
    private final double pollinationChanceMean;

    // The pollination chance standard deviation of this species.
    private final double pollinationChanceStdDev;

    /**
     * Create a plant species.
     *
     * @param name                    The name of the species.
     * @param spawnChance             The spawn chance of the species.
     * @param lifespanMean            The lifespan mean of the species.
     * @param lifespanStdDev          The lifespan standard deviation of the species.
     * @param pollinationRadiusMean   The pollination radius mean of the species.
     * @param pollinationRadiusStdDev The pollination radius standard deviation of the species.
     * @param pollinationChanceMean   The pollination chance mean of the species.
     * @param pollinationChanceStdDev The pollination chance standard deviation of the species.
     * @param maxHydrationMean        The max hydration mean of the species.
     * @param maxHydrationStdDev      The max hydration standard deviation of the species.
     */
    public PlantSpecies(String name, Color color, double spawnChance,
                        int lifespanMean, int lifespanStdDev,
                        int pollinationRadiusMean, int pollinationRadiusStdDev,
                        double pollinationChanceMean, double pollinationChanceStdDev,
                        int maxHydrationMean, int maxHydrationStdDev) {
        super(name, color, spawnChance,
                lifespanMean, lifespanStdDev,
                maxHydrationMean, maxHydrationStdDev);

        this.pollinationRadiusMean = pollinationRadiusMean;
        this.pollinationRadiusStdDev = pollinationRadiusStdDev;
        this.pollinationChanceMean = pollinationChanceMean;
        this.pollinationChanceStdDev = pollinationChanceStdDev;
    }

    /**
     * Generate a pseudorandom pollination radius following a normal distribution.
     *
     * @return A pseudorandom pollination radius.
     */
    public int getRandomPollinationRadius() {
        return (int) Math.round(Randomizer.getNormalDouble(pollinationRadiusMean, pollinationRadiusStdDev));
    }

    /**
     * Generate a pseudorandom pollination chance following a normal distribution.
     *
     * @return A pseudorandom pollination chance.
     */
    public double getRandomPollinationChance() {
        return Randomizer.getNormalDouble(pollinationChanceMean, pollinationChanceStdDev);
    }

}
