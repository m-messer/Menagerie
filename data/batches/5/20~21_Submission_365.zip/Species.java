import java.awt.*;
import java.util.function.Function;

/**
 * A class representing shared characteristic within a species, such as
 * their lifespan mean and standard deviation. Most stats of actors follow
 * a normal distribution.
 *
 * @version 2020.02.23
 */
public abstract class Species {
    // The name of the species.
    private final String name;

    // The colour of the species when displayed on the field.
    private final Color color;

    // The spawn chance of the species; this is how likely they spawn
    // when populating the field initially.
    private final double spawnChance;

    // The lifespan mean of the species.
    private final int lifespanMean;

    // The lifespan standard deviation of the species.
    private final int lifespanStdDev;

    // The max food level mean of the species.
    private final int maxFoodLevelMean;

    // The max food level standard deviation the species.
    private final int maxFoodLevelStdDev;

    // The food value equation of the species; this is how the food value
    // of the actor is calculated.
    private Function<Integer, Integer> foodValueEquation;

    /**
     * Create a species.
     *
     * @param name               The name of the species.
     * @param spawnChance        The spawn chance of the species.
     * @param lifespanMean       The lifespan mean of the species.
     * @param lifespanStdDev     The lifespan standard deviation of the species.
     * @param maxFoodLevelMean   The max food level mean of the species.
     * @param maxFoodLevelStdDev The max food level standard deviation of the species.
     */
    public Species(String name, Color color, double spawnChance,
                   int lifespanMean, int lifespanStdDev,
                   int maxFoodLevelMean, int maxFoodLevelStdDev) {
        this.name = name;
        this.color = color;
        this.spawnChance = spawnChance;
        this.lifespanMean = lifespanMean;
        this.lifespanStdDev = lifespanStdDev;
        this.maxFoodLevelMean = maxFoodLevelMean;
        this.maxFoodLevelStdDev = maxFoodLevelStdDev;
    }

    /**
     * Return the name of the species.
     *
     * @return The name of the species.
     */
    protected String getName() {
        return name;
    }

    /**
     * Return the colour of the species.
     *
     * @return The colour of the species.
     */
    protected Color getColor() {
        return color;
    }

    /**
     * Return the spawn chance of the species.
     *
     * @return The spawn chance of the species.
     */
    protected double getSpawnChance() {
        return spawnChance;
    }

    /**
     * Generate a pseudorandom lifespan following a normal distribution.
     *
     * @return A pseudorandom lifespan.
     */
    protected int getRandomLifespan() {
        return (int) Math.round(Randomizer.getNormalDouble(lifespanMean, lifespanStdDev));
    }

    /**
     * Generate a pseudorandom max food level following a normal distribution.
     *
     * @return A pseudorandom max food level.
     */
    protected int getRandomMaxFoodLevel() {
        return (int) Math.round(Randomizer.getNormalDouble(maxFoodLevelMean, maxFoodLevelStdDev));
    }

    /**
     * Set the food value equation of the species to the given function.
     *
     * @param foodValueEquation The food value equation to set to.
     */
    public void setFoodValueEquation(Function<Integer, Integer> foodValueEquation) {
        this.foodValueEquation = foodValueEquation;
    }

    /**
     * Calculate the food value of an actor based on its age and food level.
     *
     * @param age       The age of the actor.
     * @param foodLevel The food level of the actor.
     * @return The food value of the actor.
     */
    protected int calculateFoodValue(int age, int foodLevel) {
        return (int) Math.round(foodValueEquation.apply(age) + 0.2 * foodLevel);
    }
}
