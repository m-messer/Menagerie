/**
 * A simple model of a weather type.
 * <p>
 * A weather type can affect the movement range of animals,
 * the hydration of plants, and how much extra hunger it would
 * cost animals.
 * <p>
 * For example, in a rainy day, the animals would not able to
 * move nor see as far, and the plant would be hydrated.
 * <p>
 * Whereas in a snowy day, the animals would need to stay warm,
 * which means it requires more energy.
 *
 * @version 2021.02.25
 */
public class Weather {
    // The name of the weather.
    private final String name;

    // The value to decrease movement range of animals by.
    private final int slowness;

    // The value to increase the hydration of plants by.
    private final int hydration;

    // The value to increase the hunger cost of animals by.
    private final int coldness;

    /**
     * Create a weather type.
     *
     * @param slowness  The slowness of this weather type.
     * @param hydration How hydrating this weather type is.
     * @param coldness  How much extra hunger this weather type cost.
     */
    public Weather(String name, int slowness, int hydration, int coldness) {
        this.name = name;
        this.slowness = slowness;
        this.hydration = hydration;
        this.coldness = coldness;
    }

    /**
     * Return the name of this weather type.
     *
     * @return name The name of this weather type.
     */
    public String getName() {
        return name;
    }

    /**
     * Return the slowness of this weather type.
     *
     * @return The slowness of this weather type.
     */
    public int getSlowness() {
        return slowness;
    }

    /**
     * Return the hydration of this weather type.
     *
     * @return How hydration this weather type is.
     */
    public int getHydration() {
        return hydration;
    }

    /**
     * Return the coldness of this weather type.
     *
     * @return How much extra hunger this weather type cost.
     */
    public int getColdness() {
        return coldness;
    }
}
