import java.util.LinkedList;
import java.util.List;

/**
 * A simple model of an animal.
 * Animals will age, move, eat, breed and die. Some animals act during
 * the day while other act at night.
 * Animals can contract diseases, and their stats could be affected
 * by the weather and diseases they carry.
 *
 * @version 2021.02.22
 */
public class Animal extends Actor {

    // The animal's gender; true if female.
    private final boolean isFemale;
    // All diseases the animal is infected with.
    private final List<Disease> diseases = new LinkedList<>();
    // The age at which the animal can start to breed.
    private int breedingAge;
    // The likelihood of the animal breeding.
    private double breedingChance;

    /**
     * Create a animal. A animal can be created as a new born (age zero
     * and not hungry) or with a random age. The animal will have its
     * stats pseudo-randomly generated. Some of its stats such as its
     * breeding age, will follow a normal distribution, while others,
     * like its gender, will follow a uniform distribution instead.
     *
     * @param animalSpecies The species of the animal.
     * @param field         The field currently occupied.
     * @param location      The location within the field.
     * @param randomAge     If true, the animal will have random age and hunger level.
     */
    public Animal(AnimalSpecies animalSpecies, Field field, Location location, boolean randomAge) {
        super(field, location, animalSpecies, randomAge);

        // Assign a gender to the animal randomly.
        isFemale = Randomizer.getUniformInt(0, 2) == 0;

        // Generate a random breeding age. If below zero then try again.
        breedingAge = animalSpecies.getRandomBreedingAge();
        while (breedingAge < 0) breedingAge = animalSpecies.getRandomBreedingAge();

        // Generate a random breeding chance. If below zero the try again.
        breedingChance = animalSpecies.getRandomBreedingChance();
        while (breedingChance < 0) breedingChance = animalSpecies.getRandomBreedingChance();
    }

    /**
     * Create an animal that inherits attributes from its parents. Each attribute is
     * equally likely to be inherited from either of the parents. The animal will be
     * created as a new born (age zero and not hungry).
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param father   The father of this new born.
     * @param mother   The mother of this new born.
     */
    public Animal(Field field, Location location, Animal father, Animal mother) {
        super(field, location, father, mother);

        // Assign a gender to the animal randomly.
        isFemale = Randomizer.getUniformInt(0, 2) == 0;

        // Get the breeding age from one of its parents randomly.
        if (Randomizer.getUniformInt(0, 2) == 0) breedingAge = father.breedingAge;
        else breedingAge = mother.breedingAge;

        // Get the breeding chance from one of its parents randomly.
        if (Randomizer.getUniformInt(0, 2) == 0) breedingChance = father.breedingChance;
        else breedingChance = mother.breedingChance;
    }

    /**
     * This determines the animal's actions. Some animals act during day time while
     * others act during night time.
     * <p>
     * If the animal is alive, it will try and breed, then find food. If no food is
     * found, then it will try to move to a nearby empty location, ignoring plants.
     *
     * @param newActors A list to return newly born animals.
     * @param isDayTime Whether it is day time or not.
     * @param weather   The current weather of the day.
     */
    @Override
    public void act(List<Actor> newActors, boolean isDayTime, Weather weather) {
        incrementAge(); // increase the animals age

        // The minimal hunger cost of this step. The weather could affect this.
        int hungerCost = -1 - weather.getColdness();

        // The actual movement range of the animal at this point in time.
        // This could be affected by diseases and weather.
        int actualMovementRange = getMovementRange() - weather.getSlowness();

        Location newLocation = null;

        if (isAlive()) {
            // Diseases may be cured randomly
            cureDisease();

            // Diseases this animal carries may be spread to nearby animals
            // randomly. Some diseases can only be spread to the same species.
            spreadDisease(actualMovementRange);

            // Act if the animal is active during this time of the day.
            if (getAnimalSpecies().isActive(isDayTime)) {
                // Try to find a partner to breed with.
                Animal partner = findPartner(actualMovementRange);
                // If a partner is found.
                if (partner != null) {
                    // If successfully given birth.
                    if (giveBirth(newActors, actualMovementRange, partner)){
                        hungerCost -= 3;    // hunger cost to give birth
                    }
                }

                // If the hunger of the animal is below its max food level
                // then try to hunt for food.
                if (getFoodLevel() < getMaxFoodLevel()) {
                    // Move towards a source of food if found.
                    newLocation = findFood(actualMovementRange);
                }

                // If no food is found.
                if (newLocation == null) {
                    // Try to move to a free location, ignoring plants.
                    // This means that a location with a plant in it is viewed as empty.
                    newLocation = getField().getFreeLocationIgnoring(getLocation(), actualMovementRange, Plant.class);
                }

                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                    hungerCost -= 1;    // hunger cost to move
                }
            }
        }
        // Decrease the hunger of the animal; if below zero then it is dead.
        updateFoodLevel(hungerCost);
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first living prey is eaten.
     *
     * @param movementRange The movement range of the animal.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(int movementRange) {
        Field field = getField();

        // Get all nearby locations within range.
        List<Location> adjacent = field.adjacentLocations(getLocation(), movementRange);
        for (Location location : adjacent) {
            Actor actor = (Actor) field.getObjectAt(location);
            // If the actor found can be eaten (is a food type to this animal).
            if (actor != null && canEat(actor)) {
                // The actor is eaten and is dead.
                actor.setDead();
                // The hunger of the animal is restored by the food value of the eaten actor.
                updateFoodLevel(actor.getFoodValue());
                return location;
            }
        }
        return null;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newAnimals    A list to return newly born animals.
     * @param movementRange The movement range of the animal.
     * @param partner       The animal that this animal is breeding with.
     * @return True if given birth; otherwise false.
     */
    private boolean giveBirth(List<Actor> newAnimals, int movementRange, Animal partner) {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();

        // Generate a litter size.
        int births = breed(partner);

        // Get a list of free locations ignoring plants.
        List<Location> free = field.getAllFreeLocationsIgnoring(getLocation(), movementRange, Plant.class);
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location location = free.remove(0);
            // Create a new animal that inherits from its parents.
            Animal young = new Animal(field, location, partner, this);
            newAnimals.add(young);
        }
        return births != 0;
    }

    /**
     * Find an animal of the same species to breed with. Both animals
     * must be over the breeding age and are of opposite gender.
     *
     * @param movementRange The movement range of the animal.
     * @return The animal to breed with if found; otherwise null.
     */
    private Animal findPartner(int movementRange) {
        // Only female can find a partner as it will be the one giving birth,
        // easier to implement.
        if (isFemale) {
            Field field = getField();
            // Get a list of nearby locations.
            List<Location> nearbyObjects = field.adjacentLocations(getLocation(), movementRange);
            for (Location location : nearbyObjects) {
                Actor actor = (Actor) field.getObjectAt(location);
                // If the actor found can breed with this animal.
                if (actor != null && canBreedWith(actor)) {
                    return (Animal) actor;
                }
            }
        }
        return null;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @param partner The animal that this animal is breeding with.
     * @return The number of births (may be zero).
     */
    private int breed(Animal partner) {
        int births = 0;
        if (Randomizer.getDouble() <= combinedBreedingChance(partner)) {
            births = getAnimalSpecies().getRandomLitterSize();
        }
        return births;
    }

    /**
     * A animal can breed if it has reached the breeding age.
     *
     * @return True if this animal has reached its breeding age.
     */
    public boolean canBreed() {
        return getAge() >= breedingAge;
    }

    /**
     * Return whether if this animal is a female.
     *
     * @return True if female; otherwise false.
     */
    public boolean isFemale() {
        return isFemale;
    }

    /**
     * Check if this animal can breed with an actor.
     * An animal can only breed with an actor if they
     * are of the same species, have reached breeding age,
     * and are of opposite gender.
     *
     * @param actor The actor to breed with.
     * @return True if can breed with the actor.
     */
    public boolean canBreedWith(Actor actor) {
        return getSpecies().equals(actor.getSpecies())
                && canBreed() && ((Animal) actor).canBreed()
                && isFemale != ((Animal) actor).isFemale();
    }

    /**
     * The combined breeding chance of this animal and another.
     *
     * @param animal The animal to breed with.
     * @return The combined breeding chance.
     */
    public double combinedBreedingChance(Animal animal) {
        return getBreedingChance() + animal.getBreedingChance();
    }

    /**
     * Return the breeding chance after considering the effect of
     * diseases.
     *
     * @return The breeding chance.
     */
    public double getBreedingChance() {
        double fraction = 1;
        for (Disease disease : diseases) {
            fraction *= disease.getBreedingChanceFraction();
        }
        return (int) Math.round(breedingChance * fraction);
    }

    /**
     * Return the movement range after considering the effect of
     * diseases.
     *
     * @return The movement range.
     */
    public int getMovementRange() {
        double fraction = 1;
        for (Disease disease : diseases) {
            fraction *= disease.getMovementRangeFraction();
        }
        return (int) Math.round(getAnimalSpecies().getMovementRange() * fraction);
    }

    /**
     * Return the lifespan after considering the effect of diseases.
     *
     * @return The lifespan.
     */
    @Override
    public int getLifespan() {
        double fraction = 1;
        for (Disease disease : diseases) {
            fraction *= disease.getLifespanFraction();
        }
        return (int) Math.round(super.getLifespan() * fraction);
    }

    /**
     * Increment age. This overrides the method with the Actor superclass
     * as the lifespan of the animal could be affected by diseases.
     */
    @Override
    public void incrementAge() {
        super.incrementAge();
        if (getAge() > getLifespan()) setDead();
    }

    /**
     * Whether if this animal can eat an actor.
     * In other words, whether if the actor is a food source
     * of this animal.
     *
     * @param actor The actor to eat.
     * @return True if this animal can eat the actor.
     */
    public boolean canEat(Actor actor) {
        return getAnimalSpecies().getFoodSources().contains(actor.getSpecies())
                && actor.isAlive();
    }

    /**
     * Return the species of the animal as an AnimalSpecies.
     *
     * @return The AnimalSpecies of this animal.
     */
    public AnimalSpecies getAnimalSpecies() {
        return (AnimalSpecies) getSpecies();
    }

    /**
     * Infect this animal with the given disease.
     *
     * @param disease The disease that the animal is infected with.
     */
    public void infectedWith(Disease disease) {
        diseases.add(disease);
    }

    /**
     * See if this animal has cure itself of diseases. This depends on
     * the cure chance of each disease.
     */
    public void cureDisease() {
        diseases.removeIf(disease -> Randomizer.getDouble() <= disease.getCureChance());
    }

    /**
     * Spread diseases that this animal has to nearby by animals.
     * This depends on the infection chance of the disease.
     * Some disease can only spread to animals of the same species.
     *
     * @param movementRange The movement range of the animal.
     */
    public void spreadDisease(int movementRange) {
        Field field = getField();
        // Get a list of nearby objects.
        List<Location> nearbyObjects = field.adjacentLocations(getLocation(), movementRange);
        for (Location location : nearbyObjects) {
            Actor actor = (Actor) field.getObjectAt(location);
            // If the actor is an animal.
            if (actor != null & actor instanceof Animal) {
                // If this animal carries more than one diseases then multiple diseases may
                // be spread.
                for (Disease disease : diseases) {
                    // If the diseases is species specific then spread only to animals of the
                    // same species.
                    if (!disease.isSpeciesSpecific() ||
                            getAnimalSpecies().equals(((Animal) actor).getAnimalSpecies())) {

                        if (Randomizer.getDouble() <= disease.getInfectionChance()) {
                            ((Animal) actor).infectedWith(disease);
                        }
                    }
                }
            }
        }
    }
}
