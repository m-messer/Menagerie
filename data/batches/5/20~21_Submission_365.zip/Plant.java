import java.util.List;

/**
 * A simple model of a plant.
 * Plants will age, pollinate and die. They do not move nor find food.
 * Their survival depend on how hydrated they are. Some weather will
 * hydrate plants.
 *
 * @version 2021.02.23
 */
public class Plant extends Actor {

    // The radius that this plant pollinates.
    private int pollinationRadius;

    // The pollination chance of this plant.
    private double pollinationChance;

    /**
     * Create a plant. A plant can be created as a new born (age zero
     * and hydrated) or with a random age and hydration. The stats of
     * a plant are pseudo-randomly generated, and follow a normal
     * distributes.
     *
     * @param plantSpecies The species of this plant.
     * @param field        The field currently occupied.
     * @param location     The location within the field.
     * @param randomAge    If true, the plant will have random age and hydration.
     */
    public Plant(PlantSpecies plantSpecies, Field field, Location location, boolean randomAge) {
        super(field, location, plantSpecies, randomAge);

        // Generate a random pollination radius. If below zero then try again.
        pollinationRadius = plantSpecies.getRandomPollinationRadius();
        while (pollinationRadius < 0) pollinationRadius = plantSpecies.getRandomPollinationRadius();

        // Generate a random pollination chance. If below zero then try again.
        pollinationChance = plantSpecies.getRandomPollinationChance();
        while (pollinationChance < 0) pollinationChance = plantSpecies.getRandomPollinationChance();
    }

    /**
     * This determines the plant's actions.
     * <p>
     * The plant ages, and its hydration changes, depending upon the weather.
     * <p>
     * If the plant is alive, it will try to pollinate.
     *
     * @param newActors A list to receive newly born actors.
     * @param isDayTime Whether it is day time or not.
     * @param weather   The current weather type.
     */
    @Override
    public void act(List<Actor> newActors, boolean isDayTime, Weather weather) {
        incrementAge();
        int hydrationCost = -1 + weather.getHydration();

        if (isAlive()) {
            pollinate(newActors);
        }

        updateHydration(hydrationCost);
    }

    /**
     * Check whether if this plant is to pollinate in this step.
     * New seedling will be made into free adjacent locations.
     *
     * @param newPlants A list to return all new plants.
     */
    public void pollinate(List<Actor> newPlants) {
        Field field = getField();
        // Get all free locations nearby.
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), pollinationRadius);
        for (Location location : free) {
            if (Randomizer.getDouble() <= pollinationChance) {
                // Create a plant of the same species of age zero.
                Plant seedling = new Plant(getPlantSpecies(), field, location, false);
                newPlants.add(seedling);
            }
        }
    }

    /**
     * Return the plant species of this plant.
     *
     * @return The plant species of the plant.
     */
    public PlantSpecies getPlantSpecies() {
        return (PlantSpecies) getSpecies();
    }

    /**
     * Update the hydration level of the plant.
     * The plant dies if it is under or over hydrated.
     *
     * @param value The value to change the hydration level by.
     */
    public void updateHydration(int value) {
        updateFoodLevel(value);
        if (getFoodLevel() > getMaxFoodLevel() * 1.5) {
            setDead();
        }
    }
}
