import java.util.List;

/**
 * A class representing shared characteristics of actors, which are entities that
 * act in the simulation.
 *
 * @version 2021.02.22
 */
public abstract class Actor {
    // The actor's species.
    private final Species species;
    // Whether the actor is alive or not.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    private Location location;
    // The actor's current age.
    private int age;

    // The actor's lifespan.
    private int lifespan;

    // The actor's food level - hunger for animals, hydration for plants.
    private int foodLevel;

    // The actor's maximum food level; this has different meanings to different actors.
    // Animals will stop finding food if their food value exceed this.
    // Plants are over-hydrated if their food value exceed this.
    private int maxFoodLevel;

    /**
     * Create a new actor at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param species   The species of this actor.
     * @param randomAge Whether to create this actor with a random age or not.
     */
    public Actor(Field field, Location location, Species species, boolean randomAge) {
        alive = true;
        this.field = field;
        setLocation(location);
        this.species = species;

        // Generate a random lifespan. If below zero then try again.
        lifespan = species.getRandomLifespan();
        while (lifespan < 0) lifespan = species.getRandomLifespan();

        // Generate a random max food level. If below zero then try again.
        maxFoodLevel = species.getRandomMaxFoodLevel();
        while (maxFoodLevel < 0) maxFoodLevel = species.getRandomMaxFoodLevel();

        // If random age then generate a random age following a uniform distribution.
        if (randomAge) age = Randomizer.getUniformInt(0, lifespan);
            // Else set age to zero.
        else age = 0;

        // The actor will start with max food level.
        foodLevel = maxFoodLevel;
    }

    /**
     * Create an actor that inherits attributes from its parents. Each attribute is
     * equally likely to be inherited from either of the parents. The actor will be
     * created as a new born (age zero and not hungry).
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param father   The father of this new born.
     * @param mother   The mother of this new born.
     */
    public Actor(Field field, Location location, Actor father, Actor mother) {
        alive = true;
        this.field = field;
        setLocation(location);
        this.species = father.getSpecies();

        // Get the lifespan from one of its parents randomly.
        if (Randomizer.getUniformInt(0, 2) == 0) lifespan = father.lifespan;
        else lifespan = mother.lifespan;

        // Get the max food level from one of its parents randomly.
        if (Randomizer.getUniformInt(0, 2) == 0) maxFoodLevel = father.maxFoodLevel;
        else maxFoodLevel = mother.maxFoodLevel;

        // Set age to zero.
        age = 0;

        // Set food level to max.
        foodLevel = maxFoodLevel;
    }

    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newActors A list to receive newly born actors.
     * @param isDayTime Whether it is day time or not.
     * @param weather   The current weather type.
     */
    abstract public void act(List<Actor> newActors, boolean isDayTime, Weather weather);

    /**
     * Calculate the food value of this animal. This is variable and
     * depends on the age and the food level of the animal when it
     * is eaten.
     *
     * @return The food value of the animal.
     */
    public int getFoodValue() {
        return species.calculateFoodValue(age, foodLevel);
    }

    /**
     * Check whether the actor is alive or not.
     *
     * @return true if the actor is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the actor's location.
     *
     * @return The actor's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     *
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the actor's field.
     *
     * @return The actor's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Return the actor's species.
     *
     * @return The actor's species.
     */
    protected Species getSpecies() {
        return species;
    }

    /**
     * Return the actor's lifespan.
     *
     * @return The actor's lifespan.
     */
    protected int getLifespan() {
        return lifespan;
    }

    /**
     * Return the actor's age.
     *
     * @return The actor's age.
     */
    protected int getAge() {
        return age;
    }

    /**
     * Increment the actor's age. If the age exceeds the lifespan
     * then the actor is dead.
     */
    protected void incrementAge() {
        age++;
        if (age > lifespan) setDead();
    }

    /**
     * Return the food level of the actor.
     *
     * @return The food level of the actor.
     */
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Increase the food level.
     *
     * @param value The value to increase by.
     */
    protected void increaseFoodLevel(int value) {
        foodLevel += value;
    }

    /**
     * Decrease the food level of the actor. If below zero then
     * the actor is dead.
     *
     * @param value The value to change food level by.
     */
    protected void updateFoodLevel(int value) {
        foodLevel += value;
        if (foodLevel <= 0) setDead();
    }

    /**
     * Return the max food level of the actor.
     *
     * @return The max food level of the actor.
     */
    protected int getMaxFoodLevel() {
        return maxFoodLevel;
    }
}
