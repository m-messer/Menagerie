/**
 * A simple model of a disease.
 * <p>
 * Diseases have a infection chance and a cure chance.
 * <p>
 * Diseases may affect the lifespan, movement range, and breed chance
 * of the infected. Currently, only animals can contract diseases.
 * <p>
 * Some diseases are species-specific; this means that these diseases
 * can only spread within an animal species.
 *
 * @version 2021.02.25
 */
public class Disease {
    // The fraction to change the infected animal's lifespan by.
    private final double lifespanFraction;

    // The fraction to change the infected animal's movement range by.
    private final double movementRangeFraction;

    // The fraction to change the infected animal's breeding chance by.
    private final double breedingChanceFraction;

    // The infection chance of the disease.
    private final double infectionChance;

    // The cure chance of the disease; this is how likely it is for an
    // animal to naturally cure itself of this disease.
    private final double cureChance;

    // Whether if this disease is species specific.
    private final boolean speciesSpecific;

    /**
     * Create a new disease.
     *
     * @param lifespanFraction       The fraction to alter lifespan by.
     * @param movementRangeFraction  The fraction to alter movement range by.
     * @param breedingChanceFraction The fraction to alter breeding chance by.
     * @param infectionChance        The infection chance of the disease.
     * @param cureChance             The cure chance of the disease.
     * @param speciesSpecific        True if this disease is species-specific.
     */
    public Disease(double lifespanFraction, double movementRangeFraction,
                   double breedingChanceFraction, double infectionChance,
                   double cureChance, boolean speciesSpecific) {
        this.lifespanFraction = lifespanFraction;
        this.movementRangeFraction = movementRangeFraction;
        this.breedingChanceFraction = breedingChanceFraction;
        this.infectionChance = infectionChance;
        this.cureChance = cureChance;
        this.speciesSpecific = speciesSpecific;
    }

    /**
     * Return the lifespan fraction.
     *
     * @return The lifespan fraction.
     */
    public double getLifespanFraction() {
        return lifespanFraction;
    }

    /**
     * Return the movement range fraction.
     *
     * @return The movement range fraction.
     */
    public double getMovementRangeFraction() {
        return movementRangeFraction;
    }

    /**
     * Return the breeding chance fraction.
     *
     * @return The breeding chance fraction.
     */
    public double getBreedingChanceFraction() {
        return breedingChanceFraction;
    }

    /**
     * Return the infection chance.
     *
     * @return The infection chance.
     */
    public double getInfectionChance() {
        return infectionChance;
    }

    /**
     * Return the cure chance.
     *
     * @return The cure chance.
     */
    public double getCureChance() {
        return cureChance;
    }

    /**
     * Return true if this disease is species-specific.
     *
     * @return True if this disease is species-specific.
     */
    public boolean isSpeciesSpecific() {
        return speciesSpecific;
    }
}
