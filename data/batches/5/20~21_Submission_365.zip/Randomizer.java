import java.util.Random;

/**
 * Provide control over the randomization of the simulation. By using the shared, fixed-seed
 * randomizer, repeated runs will perform exactly the same (which helps with testing). Set
 * 'useShared' to false to get different random behaviour every time.
 *
 * @version 2020.02.23
 */
public class Randomizer {
    // The default seed for control of randomization.
    private static final int SEED = 1111;

    // A shared Random object, if required.
    private static final Random rand = new Random(SEED);

    // Determine whether a shared random generator is to be provided.
    private static final boolean useShared = true;

    /**
     * Constructor for objects of class Randomizer
     */
    public Randomizer() {
    }

    /**
     * Provide a random generator.
     *
     * @return A random object.
     */
    public static Random getRandom() {
        if (useShared) {
            return rand;
        } else {
            return new Random();
        }
    }

    /**
     * Generate a pseudorandom number following a normal distribution.
     *
     * @param mean   The mean of the normal distribution.
     * @param stdDev The standard deviation of the normal distribution.
     * @return A pseudorandom number within the normal distribution.
     */
    public static double getNormalDouble(double mean, double stdDev) {
        if (useShared) {
            return (rand.nextGaussian() * stdDev) + mean;
        } else {
            return (new Random().nextGaussian() * stdDev) + mean;
        }
    }

    /**
     * Generate a pseudorandom number following a uniform distribution
     * within the given range.
     *
     * @param min The lower bound of the range (inclusive).
     * @param max The upper bound of the range (excursive).
     * @return A pseudorandom number within the uniform distribution.
     */
    public static int getUniformInt(int min, int max) {
        if (useShared) {
            return rand.nextInt(max - min) + min;
        } else {
            return new Random().nextInt(max - min) + min;
        }
    }

    /**
     * Generate a pseudorandom number following a uniform distribution
     * between 0 and 1.
     */
    public static double getDouble() {
        if (useShared) {
            return rand.nextDouble();
        } else {
            return new Random().nextDouble();
        }
    }

    /**
     * Reset the randomization.
     * This will have no effect if randomization is not through
     * a shared Random generator.
     */
    public static void reset() {
        if (useShared) {
            rand.setSeed(SEED);
        }
    }
}
