import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants.
 *
 * @version 2020.02.22
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 220;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;

    // List of actors in the field.
    private final List<Actor> actors;
    // The current state of the field.
    private final Field field;
    // A graphical view of the simulation.
    private final SimulatorView view;
    // The current step of the simulation.
    private int step;

    // All species in the simulation.
    private List<Species> allSpecies;

    // All weather types in the simulation.
    private List<Weather> allWeather;

    // All diseases in the simulation.
    private List<Disease> allDiseases;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        initSpecies();  // initialise all species
        initWeather();  // initialise all weather types
        initDisease();  // initialise all diseases

        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        // Set the colour of each species in the view.
        for (Species s : allSpecies) {
            view.setColor(s, s.getColor());
        }

        // Setup a valid starting point.
        reset();
    }

    /**
     * Main method to run the simulation with the default depth and width
     * for two years (2880 steps).
     */
    public static void main(String[] args) {
        Simulator sim = new Simulator();
        sim.runLongSimulation();
    }

    /**
     * Run the simulation from its current state for two years (2880 steps).
     */
    public void runLongSimulation() {
        simulate(720);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param days The number of days to run the simulation for.
     */
    public void simulate(int days) {
        for (int step = 1; step <= days && view.isViable(field); step++) {
            simulateDay();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Set a random weather and run the simulation for a day (4 steps).
     */
    public void simulateDay() {
        Weather currentWeather = allWeather.get(Randomizer.getUniformInt(0, allWeather.size()));
        for (int step = 0; step < 4; step++) {
            simulateOneStep(currentWeather);
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actor.
     */
    public void simulateOneStep(Weather weather) {
        step++;

        // Check whether if it is day time.
        // A day is 4 steps.
        boolean isDayTime = step % 4 == 0 || step % 4 == 1;

        // Every 720 steps (half a year) spread diseases to all animals randomly.
        if (step % 720 == 1) spreadDiseasesRandomly();

        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();
        for (Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors, isDayTime, weather);
            if (!actor.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born actors to the main list.
        actors.addAll(newActors);

        // Display stats onto the GUI.
        view.showStatus(step, step / 4, isDayTime, weather, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        actors.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, step / 4, true, null, field);
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate() {
        field.clear();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                // Loop through each species.
                for (Species s : allSpecies) {
                    if (Randomizer.getDouble() <= s.getSpawnChance()) {
                        Location location = new Location(row, col);
                        Actor actor;
                        if (s instanceof AnimalSpecies) {   // the species is an animal species
                            actor = new Animal((AnimalSpecies) s, field, location, true);
                        } else {    // the species is a plant species
                            actor = new Plant((PlantSpecies) s, field, location, true);
                        }
                        actors.add(actor);
                        break;
                    }
                    // else leave the location empty.
                }
            }
        }
    }

    /**
     * Spread all diseases to animals randomly.
     */
    private void spreadDiseasesRandomly() {
        for (Disease disease : allDiseases) {
            for (Actor actor : actors) {
                if (actor instanceof Animal) {
                    if (Randomizer.getDouble() <= disease.getInfectionChance() * 0.1) {
                        ((Animal) actor).infectedWith(disease);
                    }
                }
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisecond The time to pause for, in milliseconds
     */
    private void delay(int millisecond) {
        try {
            Thread.sleep(millisecond);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Initialise all the acting species.
     */
    private void initSpecies() {
        // Initialise the species.
        AnimalSpecies eagle = new AnimalSpecies(
                "Eagle", Color.BLUE, 0.005,
                28800, 4320,
                false, 5,
                4320, 1440,
                0.002, 0.001,
                2, 1,
                120, 14);

        AnimalSpecies fox = new AnimalSpecies(
                "Fox", Color.ORANGE, 0.007,
                10080, 1440,
                true, 4,
                840, 120,
                0.003, 0.001,
                3, 1,
                100, 12);

        AnimalSpecies scorpion = new AnimalSpecies(
                "Scorpion", Color.BLACK, 0.03,
                5760, 720,
                true, 2,
                3600, 720,
                0.008, 0.005,
                5, 2,
                70, 7);

        AnimalSpecies squirrel = new AnimalSpecies(
                "Squirrel", Color.MAGENTA, 0.1,
                5040, 720,
                false, 3,
                1440, 240,
                0.005, 0.001,
                5, 1,
                90, 9);

        AnimalSpecies grasshopper = new AnimalSpecies(
                "Grasshopper", Color.GRAY, 0.2,
                1440, 360,
                false, 2,
                120, 10,
                0.08, 0.005,
                20, 2,
                50, 5);

        PlantSpecies grass = new PlantSpecies(
                "Grass", Color.GREEN, 0.8,
                7200, 1440,
                4, 1,
                0.001, 0.0001,
                20, 2);

        // Add the correct food sources to the corresponding animal
        eagle.addFoodSources(squirrel);
        fox.addFoodSources(scorpion, squirrel);
        scorpion.addFoodSources(grasshopper);
        squirrel.addFoodSources(grass);
        grasshopper.addFoodSources(grass);

        // Set the food value equation for species that would be eaten.
        // This is the food value that an actor is worth based on its age.
        eagle.setFoodValueEquation(null);
        fox.setFoodValueEquation(null);
        scorpion.setFoodValueEquation(
                x -> (int) Math.round((-0.000004 * x) * (x - 7500) + 20));
        squirrel.setFoodValueEquation(
                x -> (int) Math.round((-0.000005 * x) * (x - 6000) + 20));
        grasshopper.setFoodValueEquation(
                x -> (int) Math.round((-0.00003 * x) * (x - 2500) + 20));
        grass.setFoodValueEquation(
                x -> (int) Math.round((-0.000002 * x) * (x - 9000) + 30));

        // Add all species to a collection.
        allSpecies = Arrays.asList(eagle, fox, scorpion, squirrel, grasshopper, grass);
    }

    /**
     * Initialise all weather types within the simulation.
     * <p>
     * Slowness decreases the movement range of all animals during the weather.
     * Hydration is how much the food value of plants increases during the weather.
     * Coldness is how much extra hunger it would cost animals during the weather.
     */
    public void initWeather() {
        // Initialise the weather types.
        Weather sun = new Weather("Sun", 0, 0, 0);
        Weather rain = new Weather("Rain", 0, 2, 1);
        Weather fog = new Weather("Fog", 1, 1, 0);
        Weather snow = new Weather("Snow", 1, 0, 2);

        // Add all weather types to a collection.
        allWeather = Arrays.asList(sun, rain, fog, snow);
    }

    /**
     * Initialise all diseases within the simulation. Diseases decrease the stats
     * of the infected animals to a fraction of the original value, such as the
     * lifespan, the movement range, or the breeding chance.
     */
    public void initDisease() {
        // Initialise the diseases.
        Disease disease1 = new Disease(0.7, 1,
                0.5, 0.003,
                0.005, true);

        Disease disease2 = new Disease(0.4, 1,
                1, 0.001,
                0.001, false);

        Disease disease3 = new Disease(0.9, 0.5,
                0.9, 0.009,
                0.008, true);

        // Add all diseases to a collection.
        allDiseases = Arrays.asList(disease1, disease2, disease3);
    }
}
