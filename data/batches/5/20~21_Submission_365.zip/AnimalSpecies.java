import java.awt.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * A class representing shared characteristic within an animal species,
 * such as their breeding age mean and standard deviation. Most stats
 * of animals follow a normal distribution.
 *
 * @version 2021.02.23
 */
public class AnimalSpecies extends Species {
    // Whether this species is nocturnal or not.
    private final boolean nocturnal;

    // The movement range of the species.
    private final int movementRange;

    // The food sources that this species consumes.
    private final Set<Species> foodSources;

    // The breeding age mean of this species.
    private final int breedingAgeMean;

    // The breeding age standard deviation of this species.
    private final int breedingAgeStdDev;

    // The breeding chance mean of this species.
    private final double breedingChanceMean;

    // The breeding chance standard deviation of this species.
    private final double breedingChanceStdDev;

    // The litter size mean of this species.
    private final int litterSizeMean;

    // The litter size standard deviation of this species.
    private final int litterSizeStdDev;

    /**
     * Create an animal species.
     *
     * @param name                 The name of the species.
     * @param spawnChance          The spawnChance of the species.
     * @param lifespanMean         The lifespan mean of the species.
     * @param lifespanStdDev       The lifespan standard deviation of the species.
     * @param nocturnal            True if this species is nocturnal.
     * @param movementRange        The movement range of the species.
     * @param breedingAgeMean      The breeding age mean of the species.
     * @param breedingAgeStdDev    The breeding age standard deviation of the species.
     * @param breedingChanceMean   The breeding chance mean of the species.
     * @param breedingChanceStdDev The breeding chance standard deviation of the species.
     * @param litterSizeMean       The litter size mean of the species.
     * @param litterSizeStdDev     The litter size standard deviation of the species.
     * @param maxHungerMean        The max hunger mean of the species.
     * @param maxHungerStdDev      The max hunger standard deviation of the species.
     */
    public AnimalSpecies(String name, Color color, double spawnChance,
                         int lifespanMean, int lifespanStdDev,
                         boolean nocturnal, int movementRange,
                         int breedingAgeMean, int breedingAgeStdDev,
                         double breedingChanceMean, double breedingChanceStdDev,
                         int litterSizeMean, int litterSizeStdDev,
                         int maxHungerMean, int maxHungerStdDev) {
        super(name, color, spawnChance,
                lifespanMean, lifespanStdDev,
                maxHungerMean, maxHungerStdDev);

        this.nocturnal = nocturnal;
        this.movementRange = movementRange;
        this.breedingAgeMean = breedingAgeMean;
        this.breedingAgeStdDev = breedingAgeStdDev;
        this.breedingChanceMean = breedingChanceMean;
        this.breedingChanceStdDev = breedingChanceStdDev;
        this.litterSizeMean = litterSizeMean;
        this.litterSizeStdDev = litterSizeStdDev;

        foodSources = new HashSet<>();
    }

    /**
     * Set the given species as the food sources of this species.
     *
     * @param food The species that this species consume.
     */
    public void addFoodSources(Species... food) {
        foodSources.addAll(Arrays.asList(food));
    }

    /**
     * Generate a pseudorandom breeding age following a normal distribution.
     *
     * @return A pseudorandom breeding age.
     */
    public int getRandomBreedingAge() {
        return (int) Math.round(Randomizer.getNormalDouble(breedingAgeMean, breedingAgeStdDev));
    }

    /**
     * Generate a pseudorandom breeding chance following a normal distribution.
     *
     * @return A pseudorandom breeding chance.
     */
    public double getRandomBreedingChance() {
        return Randomizer.getNormalDouble(breedingChanceMean, breedingChanceStdDev);
    }

    /**
     * Generate a pseudorandom litter size following a normal distribution.
     *
     * @return A pseudorandom litter size.
     */
    public int getRandomLitterSize() {
        return (int) Math.round(Randomizer.getNormalDouble(litterSizeMean, litterSizeStdDev));
    }

    /**
     * Return a set containing all food sources of this species.
     *
     * @return A set containing all food sources.
     */
    public Set<Species> getFoodSources() {
        return foodSources;
    }

    /**
     * Return the base movement range of the species.
     *
     * @return The base movement range of the species.
     */
    public int getMovementRange() {
        return movementRange;
    }

    /**
     * Return if this species is active during the given time of the day.
     *
     * @param isDayTime True if it is day time; otherwise false.
     * @return True if thi species is active during the given time.
     */
    public boolean isActive(boolean isDayTime) {
        return isDayTime != nocturnal;
    }

}
