/**
 * Defines the different actions that can be effected by weather
 *
 * @version (28/02/2022)
 */
public enum WeatherEffectTypes {
    BREED, HUNT
}