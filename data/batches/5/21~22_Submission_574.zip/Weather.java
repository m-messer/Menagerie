/**
 * Defines the different weather conditions that can occur
 *
 * @version (28/02/2022)
 */
public enum Weather
{
    SUNNY, RAINY, FOGGY, SNOWY
}
