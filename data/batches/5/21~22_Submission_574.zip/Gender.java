
/**
 * Defines the different genders animals can have
 *
 * @version (28/02/2022)
 */
public enum Gender
{
    MALE, FEMALE
}
