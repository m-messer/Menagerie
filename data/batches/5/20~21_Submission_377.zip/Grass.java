 

import java.util.HashMap;
import  java.util.List;
import java.util.Random;
/**
 * A simple model representing grass.
 * grass can grow, propogate and die 
 *
 * @version 2021.3.03
 */
public class Grass extends Plant
{

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new grass at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location, HashMap<String,Integer> customVariables)
    {
        super(field, location,customVariables);
    }
    /**
     * This is what grass do most of the time: it grows
     * In the process, it might propogate or die of old age
     * @param newGrass A list to return newly born grass.
     */
    public void act(List<Actor> newGrass, int time) 
    {
        if(time > 6 && time < 18 && isAlive())
        {
            //if it is between 6am andd 6pm,
            this.incrementGrowthProgress(CustomGrowthSpeed);
            if(rand.nextDouble() <= ((double)CustomPropagationChance/100))
            {
                propagate(newGrass);
            }
        }
    }
}
