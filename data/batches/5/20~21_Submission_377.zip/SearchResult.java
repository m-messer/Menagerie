 

/**
 * Model of a search result, which is a location with a distance relative to the searcher.
 * @version 28.02.2021 (1)
 */
public class SearchResult 
{

    // the location of this search result
    Location location;

    int distance;
    //distance relative to the searcher
    /**
     * Create a search result
     * @param location the location of the target
     * @param distance the distance from target
     */
    public SearchResult(Location location, int distance)
    {

        this.location = location;
        this.distance = distance;
    }

    /**
     * Gets the location 
     * @return location the location
     */
    public Location getLocation() 
    {
        return location;
    }

    /**
     * Sets the location
     * @param location the location
     */
    public void setLocation(Location location)
    {
        this.location = location;
    }

    /**
     * Gets the distance
     * @return distance the distance
     */
    public int getDistance() 
    {
        return distance;
    }

    /**
     * Sets the distance
     * @param distance the distance
     */
    public void setDistance(int distance) 
    {
        this.distance = distance;
    }
}
