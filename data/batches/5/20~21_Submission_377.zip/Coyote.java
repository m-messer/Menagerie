 

import java.util.HashMap;
import java.util.List;

/**
 * A simple model of a coyote.
 * Coyotes age, move, eat Deer, squirrel and berries, and die.
 * Coyotes die when food level too low, when they can't move, or upon reaching dying age.
 * @version 2021.02.27 (2)
 */
public class Coyote extends Animal
{

    // array of edible objects that coyotes can eat
    private static final Class[] edibleArray = new Class[] { Deer.class, Squirrel.class, Berries.class };

    /**
     * Create a coyote. A coyote can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the coyote will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Coyote(boolean randomAge, Field field, Location location, boolean gender, HashMap<String,Integer> customVariables)
    {
        super(field, location, gender,customVariables,randomAge);
    }

    /**
     * This is what the coyote does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newCoyotes A list to return newly born coyotes.
     */
    public void act(List<Actor> newCoyotes, int time) 
    {
        super.act(CustomMaxAge);

        if (time < 4 || time > 20) {
            // if Coyotes are asleep, they cannot do anything
            actionsWhileAwake(newCoyotes,edibleArray);
        }
    }
}
