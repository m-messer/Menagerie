
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing: 
 * Lions, Cheetahs, Deer, Coyotes and Squirrels
 * Grass, berries and nuts
 * For this simulation, adjacent means any square next to the current one, diagonal or not.
 *
 * @version 2021.03.3 (6)
 */
public class Simulator 
{
    // Constants representing configuration information for the simulation.

    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;

    // The probability that an actor will be created in any given grid position. Customisable.
    private int CustomLionCreationProbability;
    private int CustomCheetahCreationProbability;
    private int CustomDeerCreationProbability;
    private int CustomSquirrelCreationProbability;
    private int CustomCoyoteCreationProbability;
    private int CustomGrassCreationProbability;
    private int CustomBerriesCreationProbability;
    private int CustomNutsCreationProbability;

    // list of all the animals in our simulation.
    private final String[] animals = {"Lion", "Cheetah", "Coyote", "Deer", "Squirrel"};
    // list of all the plants in our simulation
    private final String[] plants = {"Grass", "Nuts", "Berries"};
    // list of the SimpleName() of all the classes in our simulation that have custom variables
    private final String[] customisableClasses = {"Lion", "Cheetah", "Coyote", "Deer", "Squirrel","Grass", "Nuts", "Berries","Simulator"};
    // a storage array for the creation probabilities of animals.
    private static Double[] animalProbabilities;
    // a storage array for the creation probabilities of plants
    private static Double[] plantProbabilities;
    // have we been asked to stop the simulation by our gui?
    private boolean interrupt;
    // is the simulation currently running?
    private boolean isRunning;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    public Field field;
    // The current step of the simulation.
    private int step;
    // The current time of day on the 24 hour clock
    private int timeOfDay;
    // The current day of the simulation
    private int day;
    // A graphical view of the simulation.
    private SimulatorView view;
    // a HashMap that contains all our customisable classes as a key, and a hashmap of all the customisable variables of that class, and its values, as its value.
    private HashMap<String, HashMap<String,Integer>> allCustomVariables;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator() 
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) 
    {
        if (width <= 0 || depth <= 0) 
        {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        allCustomVariables = initialiseCustomVariables();
        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        // setting the colors of the actors in the simulation
        view.setColor(Deer.class, Color.BLUE);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Cheetah.class, Color.RED);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Squirrel.class, Color.GRAY);
        view.setColor(Nuts.class, Color.CYAN);
        view.setColor(Berries.class, Color.MAGENTA);
        view.setColor(Coyote.class, Color.BLACK);

        // Setup a valid starting point.
        reset();
        allCustomVariables.forEach((key, value) ->{
            System.out.println(key);
            value.forEach((key2,value2)->{
                System.out.println(key2 + " = " + value2);
            });
            System.out.println();
        });
    }

    /**
     * Initialises the custom variables of each species, storing them in a hashmap<String,Integer>(Key is variable name, Value is the value that variable should be), and then this is stored in an
     * overall HashMap<String, HashMap>, where the Key is the name of the Class and the value is the hashmap of the variables for that class.
     * @return overallHashmap of all the customVariables for each class.
     */
    private HashMap<String, HashMap<String, Integer>> initialiseCustomVariables() 
    {
        //overall hashmap to store other hashmaps
        HashMap<String,HashMap<String,Integer>> overallHashmap = new HashMap<>();
        HashMap<String, Integer> lionHashMap = new HashMap<>();

        lionHashMap.put("CustomViewDistance",5);
        lionHashMap.put("CustomBreedingDelay",11);
        lionHashMap.put("CustomMaxFoodLevel",260);
        lionHashMap.put("CustomMaxLitterSize",1);
        lionHashMap.put("CustomMaxAge",280);
        lionHashMap.put("CustomBreedingAge",16);
        lionHashMap.put("CustomNutritionValue",20);
        overallHashmap.put("Lion",lionHashMap);

        HashMap<String, Integer> cheetahHashMap = new HashMap<>();
        cheetahHashMap.put("CustomViewDistance",5);
        cheetahHashMap.put("CustomBreedingDelay",13);
        cheetahHashMap.put("CustomMaxFoodLevel",260);
        cheetahHashMap.put("CustomMaxLitterSize",1);
        cheetahHashMap.put("CustomMaxAge",148);
        cheetahHashMap.put("CustomBreedingAge",25);
        cheetahHashMap.put("CustomNutritionValue",20);
        overallHashmap.put("Cheetah",cheetahHashMap);

        HashMap<String, Integer> coyoteHashMap = new HashMap<>();
        coyoteHashMap.put("CustomViewDistance",5);
        coyoteHashMap.put("CustomBreedingDelay",13);
        coyoteHashMap.put("CustomMaxFoodLevel",260);
        coyoteHashMap.put("CustomMaxLitterSize",1);
        coyoteHashMap.put("CustomMaxAge",72);
        coyoteHashMap.put("CustomBreedingAge",17);
        coyoteHashMap.put("CustomNutritionValue",20);
        overallHashmap.put("Coyote",coyoteHashMap);

        HashMap<String, Integer> deerHashMap = new HashMap<>();
        deerHashMap.put("CustomViewDistance",5);
        deerHashMap.put("CustomBreedingDelay",9);
        deerHashMap.put("CustomMaxFoodLevel",60);
        deerHashMap.put("CustomMaxLitterSize",5);
        deerHashMap.put("CustomMaxAge",120);
        deerHashMap.put("CustomBreedingAge",4);
        deerHashMap.put("CustomNutritionValue",20);
        overallHashmap.put("Deer",deerHashMap);

        HashMap<String, Integer> squirrelHashMap = new HashMap<>();
        squirrelHashMap.put("CustomViewDistance",5);
        squirrelHashMap.put("CustomBreedingDelay",15);
        squirrelHashMap.put("CustomMaxFoodLevel",48);
        squirrelHashMap.put("CustomMaxLitterSize",4);
        squirrelHashMap.put("CustomMaxAge",48);
        squirrelHashMap.put("CustomBreedingAge",6);
        squirrelHashMap.put("CustomNutritionValue",10);
        overallHashmap.put("Squirrel",squirrelHashMap);

        HashMap<String, Integer> nutHashMap= new HashMap<>();
        nutHashMap.put("CustomGrowthSpeed",5);
        nutHashMap.put("CustomPropagationChance",3);
        nutHashMap.put("CustomMaxAge",480);
        nutHashMap.put("CustomNutritionValue",5);
        overallHashmap.put("Nuts",nutHashMap);

        HashMap<String, Integer> berriesHashMap = new HashMap<>();
        berriesHashMap.put("CustomGrowthSpeed",5);
        berriesHashMap.put("CustomPropagationChance",6);
        berriesHashMap.put("CustomMaxAge",480);
        berriesHashMap.put("CustomNutritionValue",5);
        overallHashmap.put("Berries",berriesHashMap);

        HashMap<String, Integer> grassHashMap = new HashMap<>();
        grassHashMap.put("CustomGrowthSpeed",5);
        grassHashMap.put("CustomPropagationChance",2);
        grassHashMap.put("CustomMaxAge",480);
        grassHashMap.put("CustomNutritionValue",7);
        overallHashmap.put("Grass",grassHashMap);

        HashMap<String,Integer> simulatorHashMap = new HashMap<>();
        simulatorHashMap.put("CustomBerriesCreationProbability", 10);
        simulatorHashMap.put("CustomNutsCreationProbability", 10);
        simulatorHashMap.put("CustomGrassCreationProbability", 10);
        simulatorHashMap.put("CustomLionCreationProbability", 4);
        simulatorHashMap.put("CustomCheetahCreationProbability", 10);
        simulatorHashMap.put("CustomCoyoteCreationProbability", 10);
        simulatorHashMap.put("CustomDeerCreationProbability", 20);
        simulatorHashMap.put("CustomSquirrelCreationProbability",15);
        overallHashmap.put("Simulator", simulatorHashMap);

        return overallHashmap;
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (500 steps).
     */
    public void runLongSimulation() 
    {
        simulate(500,0);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public int simulate(int numSteps, int delay) 
    {
        isRunning = true;
        for (int step = 1; step <= numSteps && view.isViable(field); step++) 
        {
            if(interrupt)
            {
                setInterrupt(false);
                break;
            }
            simulateOneStep();
            delay(delay);   // uncomment this to run more slowly
        }
        isRunning = false;
        return step;
    }

    /**
     * Update the stored custom variables of this class with the ones provided. used to update actor creation probabilities
     * @param customVariables list of custom variables and their values
     */
    private void applyCustomVariables(HashMap<String,Integer> customVariables){
        // for each key/value pair
        customVariables.forEach((key, value) ->
            {
                // create an empty class array and store the int class inside it, this is needed to allow us to find the right methods.
                Class[] arguments = new Class[1];
                arguments[0] = int.class;
                Method setter = null;
                // try to find the set method for this key/value pair
                try {
                    // get the setKey method with the arguments(integer)
                    setter = this.getClass().getMethod("set" + key, arguments);
                    // invoke this method on the actor, with the argument being the value of this key/value pair
                    setter.invoke(this, value);
                }
                catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e)
                {
                    e.printStackTrace();
                }
            });
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * actor
     */
    public void simulateOneStep() 
    {
        step++;
        timeOfDay = step % 24; // step modulo 24 gets us the hour of the day
        if (timeOfDay == 0 && step != 0) 
        {
            day++;
        } // if it is 12 am(0 on the 24 hour clock), increase day count by 1 as a day has passed.

        // Provide space for new actors
        List<Actor> newActors = new ArrayList<>();
        // Let all actors act.
        for (Iterator<Actor> it = actors.iterator(); it.hasNext(); ) 
        {
            Actor actor = it.next();
            actor.act(newActors, timeOfDay);
            if (!(actor.isAlive())) 
            {
                it.remove();
            }
            //removes any dead actors
        }
        // Add the new actors to the main lists.
        actors.addAll(newActors);
        // update our gui
        view.updateStatus(step, field, timeOfDay, day);
    }

    /**
     * Reset the simulation to a starting position. Update all the probabilities from our list of stored custom variables.
     */
    public void reset() 
    {
        interrupt = false;
        applyCustomVariables(allCustomVariables.get(this.getClass().getSimpleName()));
        updateStoredProbabilities();
        step = 0;
        day = 0;
        timeOfDay = 0;
        actors.clear();
        populate();
        // Show the starting state in the view.
        view.updateStatus(step, field, timeOfDay, day);
    }

    /**
     * converts our integer probabilities into doubles, by dividing the integer by 100 and casting to double, then storing in our probability arrays.
     */
    private void updateStoredProbabilities() 
    {
        animalProbabilities = new Double[]{(double) CustomLionCreationProbability / 100, (double) CustomCheetahCreationProbability / 100, (double) CustomCoyoteCreationProbability / 100, (double) CustomDeerCreationProbability / 100, (double) CustomSquirrelCreationProbability / 100};

        plantProbabilities = new Double[]{(double) CustomGrassCreationProbability / 100, (double) CustomNutsCreationProbability / 100, (double) CustomBerriesCreationProbability / 100};
    }

    /**
     * Randomly populate the field with actors.
     * Can leave spaces empty.
     */
    private void populate() 
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) 
        {
            for (int col = 0; col < field.getWidth(); col++) 
            {
                double animalGen = rand.nextDouble();
                double plantGen = rand.nextDouble();
                Location location = new Location(row, col);
                if (generateAnimal(animalGen, location) != null) 
                {
                    actors.add(generateAnimal(animalGen, location));
                }
                if (generatePlant(plantGen, location) != null) 
                {
                    actors.add(generatePlant(plantGen, location));
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Generate animal using actor factory
     * @param animalGen the probability for this square
     * @param location the location of this square
     * @return return which animal, if any, will spawn in this square.
     */
    private Actor generateAnimal(double animalGen, Location location) 
    {
        ActorFactory a = new ActorFactory();
        WeightedRandomHandler w = new WeightedRandomHandler(animals, animalProbabilities);
        String animalString = w.calculateGeneration(animalGen);
        return a.getAnimalOfRandomAge(field, location, animalString,allCustomVariables.get(animalString));
    }

    /**
     * Generate animal using actor factory
     * @param plantGen the probability for this square
     * @param location the location of this square
     * @return return which plant, if any, will spawn in this square.
     */
    private Actor generatePlant(double plantGen, Location location) 
    {
        ActorFactory a = new ActorFactory();
        WeightedRandomHandler w = new WeightedRandomHandler(plants, plantProbabilities);
        String plantString = w.calculateGeneration(plantGen);
        return a.getActor(field, location, plantString,allCustomVariables.get(plantString));
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) 
    {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) 
        {
            // wake up
        }
    }

    /**
     * @return field gets the field of the simulator
     */
    protected Field getField() {
        return this.field;
    }

    /**
     * @return int gets the custom creation probability of a lion
     */
    public int getCustomLionCreationProbability() 
    {
        return CustomLionCreationProbability;
    }

    /**
     * @param customLionCreationProbability sets the custom creation probability of lion
     */
    public void setCustomLionCreationProbability(int customLionCreationProbability) 
    {
        CustomLionCreationProbability = customLionCreationProbability;
    }

    /**
     * @return int gets the custom creation probability of cheetah
     */
    public int getCustomCheetahCreationProbability() {
        return CustomCheetahCreationProbability;
    }

    /**
     * @param customCheetahCreationProbability sets the custom creation probability of cheetah
     */
    public void setCustomCheetahCreationProbability(int customCheetahCreationProbability) 
    {
        CustomCheetahCreationProbability = customCheetahCreationProbability;
    }

    /**
     * @return int gets the custom creation probability of deer
     */
    public int getCustomDeerCreationProbability() 
    {
        return CustomDeerCreationProbability;
    }

    /**
     * @param customDeerCreationProbability sets the custom creation probability of deer
     */
    public void setCustomDeerCreationProbability(int customDeerCreationProbability) 
    {
        CustomDeerCreationProbability = customDeerCreationProbability;
    }

    /**
     * @return int gets the custom creation probability of a squirrel
     */
    public int getCustomSquirrelCreationProbability() 
    {
        return CustomSquirrelCreationProbability;
    }

    /**
     * @param customSquirrelCreationProbability sets the custom creation probability of a squirrel
     */
    public void setCustomSquirrelCreationProbability(int customSquirrelCreationProbability) 
    {
        CustomSquirrelCreationProbability = customSquirrelCreationProbability;
    }

    /**
     * @return int gets the custom creation probability of coyote
     */
    public int getCustomCoyoteCreationProbability() 
    {
        return CustomCoyoteCreationProbability;
    }

    /**
     * @param customLionCreationProbability sets the custom creation probability of grass
     */
    public void setCustomCoyoteCreationProbability(int customCoyoteCreationProbability) 
    {
        CustomCoyoteCreationProbability = customCoyoteCreationProbability;
    }

    /**
     * @return int gets the custom creation probability of grass
     */
    public int getCustomGrassCreationProbability() 
    {
        return CustomGrassCreationProbability;
    }

    /**
     * @param customLionCreationProbability sets the custom creation probability of squirrel
     */
    public void setCustomGrassCreationProbability(int customGrassCreationProbability) 
    {
        CustomGrassCreationProbability = customGrassCreationProbability;
    }

    /**
     * @return int gets the custom creation probability of berries
     */
    public int getCustomBerriesCreationProbability() 
    {
        return CustomBerriesCreationProbability;
    }

    /**
     * @param customBerriesCreationProbability sets the custom creation probability of berries
     */
    public void setCustomBerriesCreationProbability(int customBerriesCreationProbability) 
    {
        CustomBerriesCreationProbability = customBerriesCreationProbability;
    }

    /**
     * @return int gets the custom creation probability of nuts
     */
    public int getCustomNutsCreationProbability() 
    {
        return CustomNutsCreationProbability;
    }

    /**
     * @param customNutsCreationProbability sets the custom creation probability of nuts
     */
    public void setCustomNutsCreationProbability(int customNutsCreationProbability) 
    {
        CustomNutsCreationProbability = customNutsCreationProbability;
    }

    /**
     * Apply all the changes from the users input in advanced options. This input is stored in the newCustomFieldsAndValues hashmap which has been passed to us.
     * @param newCustomFieldsAndValues hashmap storing all updated custom variables for each customisable class.
     */
    public void applyChanges(HashMap<String, HashMap<String, Integer>> newCustomFieldsAndValues) 
    {
        // for each customisable, class, replace the stored custom variables hashmap with the one provided by the GUI
        allCustomVariables.forEach((key, value) -> allCustomVariables.replace(key,newCustomFieldsAndValues.get(key)));
        // reset the field to allow these changes to take effect
        this.reset();
    }

    /**
     * Sets the interrupt
     * @param interrupt whether there is an interrupt or not
     */
    public void setInterrupt(boolean interrupt)
    {
        this.interrupt = interrupt;
    }

    /**
     * Sets the isRunning
     * @param isRunning whether the simulator is running or not
     */
    public boolean isRunning() {
        return isRunning;
    }

    /**
     * @return String[] array of customisable classes
     */
    public String[] getCustomisableClasses() {
        return customisableClasses;
    }

    /**
     * Get the customisable fields and their values for the given class
     * @param clazz the class to get the values for
     * @return HashMap of the customisable fields(String key) and their Integer values.
     */
    public HashMap<String, Integer> getFieldsAndValues(String clazz) {
        return allCustomVariables.get(clazz);
    }

    /**
     * @return step gets the step
     */
    public int getStep(){
        return this.step;
    }
}
