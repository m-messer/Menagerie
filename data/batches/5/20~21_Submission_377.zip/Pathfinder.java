
import java.util.ArrayList;
/**
 * This class creates better pathing for animals in some situations.
 * @version 28.02.2021 (1)
 */
public class Pathfinder 
{

    // the field that the pathfinder should carry out is searches on
    private Field field;

    // the area that the pathfinder will search. It's width and height is the view distance + 1 of the animal doing the pathfinding. It is a single dimensional object array that stores 2 Object[][] 2d arrays
    // these are our animal and plant layers, accessed as searchArea[0] and searchArea[1] respectively.
    private Object[] searchArea;
    // the location of the animal doing the pathfinding
    Location currentLocation;

    // vision distance is how far the animal can see from where it is standing, in each direction(including diagonals);
    int visionDistance;

    // create our pathfinder, passing it the field, the view distance of the animal, and the location of the animal we are pathfinding for.

    /**
     * This constructor creates our pathfinder, and passes it the intial variables it needs. It then builds a list of all the spaces within viewing distance
     * of the currentLocation passed to it.
     * @param field the field of the simulation that we should pathfind on.
     * @param visionDistance how far the animal we are pathfinding can see in each direction, including diagonals. Does not include the space the animal is standing on.
     * @param currentLocation the location of the animal we are pathfinding for.
     */
    public Pathfinder(Field field, int visionDistance, Location currentLocation)
    {
        this.field = field;
        this.currentLocation = currentLocation;
        this.visionDistance = visionDistance;
        // build the searchArea array,
        buildSearchArea();
    }

    /**
     * Finds the closest object to the animal, that is on the list of targets passed to it.
     * @param targetList stores the targets we are looking for, as the Class reference of them.
     * @return returns the location of the closest target found by the searching algorithm. Null means no target was found.
     */
    public SearchResult findClosest(ArrayList<Class> targetList)
    {
        // initialise minDistance counter, which will track the distance of the most optimal search result so far.
        // initialise our optimalSearch result to null.
        int minDistance = 0;
        SearchResult optimalSearch = null;
        // for each type of target
        for(Class target: targetList){
            // curSearch will store the closest object of the specified target class
            SearchResult curSearch = findTarget(target);
            // if we found an object of the target type
            if(curSearch != null){
                // if we haven't found a target yet, our minDistance will be zero, so we can set curSearch as our optimal.
                if(minDistance == 0){
                    optimalSearch = curSearch;
                }
                // if the distance of the current "optimalSearch" is further than the distance of the target we just found, we replace
                // the optimal search with our newly found target.
                if(minDistance > curSearch.getDistance()){
                    minDistance = curSearch.getDistance();
                    optimalSearch = curSearch;
                }
            }
        }
        // return the closest object that is of a type on the target list.
        return optimalSearch;
    }

    /**
     * This method searches for the closest object in the search area, of the specified type.
     * @param target class of the object we are looking for
     * @return a SearchResult object, which consists of the Location of the target, and the distance to that target.
     */
    public SearchResult findTarget(Class target)
    {

        // searches from closest to furthest away, looking for objects of the target type
        for(int distance = 1; distance <= visionDistance; distance++)
        {
            int[] loc = searchSquare(distance,target);
            if(loc != null){
                return new SearchResult(calculateOffset(currentLocation, loc),distance);
            }
        }
        return null;
    }

    /**
     * Calculates the correct field location of the target object, by calculating the offset from the animal we are pathfinding for.
     * @param currentLocation the location of the animal we are pathfinding for
     * @param loc the location of the target in our restricted search area
     * @return the location of the target in the field grid.
     */
    private Location calculateOffset(Location currentLocation, int[] loc) {
        int centre = visionDistance;
        int rowOffset = loc[0] - centre;
        int colOffset = loc[1] - centre;
        return new Location(currentLocation.getRow()+rowOffset, currentLocation.getCol()+colOffset);
    }

    /**
     * Reads from the field grid, building the searchArea[] array. The animal we are pathfinding for is in the centre of this array.
     */
    private void buildSearchArea()
    {
        Animal[][] animalLayer = new Animal[(visionDistance*2)+1][(visionDistance*2)+1];
        Plant[][] plantLayer = new Plant[(visionDistance*2)+1][(visionDistance*2)+1];

        int baseWidth = currentLocation.getRow()-(visionDistance);
        int baseHeight = currentLocation.getCol()-(visionDistance);

        for(int row = 0; row <= (visionDistance*2); row++)
        {
            for(int col = 0; col <= (visionDistance*2); col++)
            {
                animalLayer[row][col] = field.getAnimalAt((baseWidth+row), (baseHeight+col));
                plantLayer[row][col] = field.getPlantAt((baseWidth+row), (baseHeight+col));
            }
        }
        // set our searchArea to be an Object[] array storing the animal and plant layers
        searchArea = new Object[] {animalLayer, plantLayer};
    }

    /**
     * Simplistic pathfinder that returns the next step in the shortest path to the target location.
     * @param location the location we are trying to reach
     * @return the next step in the shortest path to this target location.
     */
    public Location pathTowards(Location location) 
    {
        if (location == null) 
        {
            return null;
        }
        else
        {
            // calculate which grid is the least distance from our target
            int targetRow = location.getRow();
            int targetCol = location.getCol();
            int curRow = currentLocation.getRow();
            int curCol = currentLocation.getCol();
            int rowOffset= 0, colOffset = 0 ;
            if (targetRow > curRow) 
            {
                rowOffset = 1;
            } else if (targetRow == curRow) 
            {
                rowOffset = 0;
            } else if (targetRow < curRow) 
            {
                rowOffset = -1;
            }
            if (targetCol > curCol) 
            {
                colOffset = 1;
            } else if (targetCol == curCol) 
            {
                colOffset = 0;
            } else if (targetCol < curCol) 
            {
                colOffset = -1;
            }
            return new Location(curRow + rowOffset, curCol + colOffset);
        }
    }

    /**
     * Searches a square of distance+2 around the centre of the search area for our target. If a target is round, returns an int[]
     * array storing it's coordinates.
     * @param distance the maximum distance from the centre we can look
     * @param target the type of object we are looking for
     * @return null if we do not find a target, otherwise int[] storing the {row, column} of the target we found, in our search area. This needs converting before we return it to the simulator.
     */
    public int[] searchSquare(int distance, Class target) {

        Object[][] targetArea;
        if (Animal.class.isAssignableFrom(target)) {
            targetArea = (Animal[][]) searchArea[0];
        } else
            targetArea = (Plant[][]) searchArea[1];
        // boolean array that we use to store whether we have checked a location already. Helps to improve efficiency.
        boolean[][] checkedArray = new boolean[targetArea.length][targetArea.length];

        // the centre is the location of our animal, so we do not check it. Since our array starts from zero, the centre is also the vision distance value of the animal
        int centre = visionDistance;
        // for each row and column that is x distance away from the centre
        for (int row = centre - distance; row <= centre + distance; row++) {
            for (int col = centre - distance; col <= centre + distance; col++) {
                // if the area contains something
                if (targetArea[row][col] != null) {
                    // if the area has not already been checked
                    if (!checkedArray[row][col]) {
                        // set "checked" to true
                        checkedArray[row][col] = true;
                        // if the current square isn't the center, and there is the target in this square, return the location of the target.
                        if ((row != centre) && (col != centre) && isTarget(targetArea[row][col], target)) {
                            return new int[]{row, col};
                        }
                    }
                }
            }

        }
        return null;
    }

    /**
     * Returns whether the object passed is of the target type.
     * @param o Object we are checking
     * @param target the type we are looking for
     * @return return true if target is what we are looking for, else false.
     */
    private boolean isTarget(Object o, Class target) 
    {
        return (o.getClass().equals(target));
    }

    /**
     * Path finding for the purpose of mating means finding another animal of the same species but opposite gender.
     * @param target the target animal
     * @param thisAnimal the animal that is trying to breed
     */
    public SearchResult findTargetOfOppositeGender(Class<? extends Animal> target, Animal thisAnimal) 
    {
        // searches from closest to furthest away, looking for objects of the target type
        for(int distance = 1; distance <= visionDistance; distance++){
            int[] loc = searchSquareGender(distance,target,thisAnimal);
            if(loc != null){
                return new SearchResult(calculateOffset(currentLocation, loc),distance);
            }
        }
        return null;
    }

    /**
     * Same purpose searchSquare except that it has the additional condition of finding the closest target that is also of the opposite gender to the searching animal.
     * This allows for pathfinding to the nearest available mate. 
     * @param distance how far the pathfinder can see
     * @param target the type we are looking for
     * @param thisAnimal the animal we are pathfinding for.
     * @return null if we do not find a target, otherwise int[] storing the {row, column} of the target we found, in our search area. This needs converting before we return it to the simulator.
     */
    private int[] searchSquareGender(int distance, Class<? extends Animal> target, Animal thisAnimal) 
    {
        Animal[][] targetArea = (Animal[][]) searchArea[0];
        boolean[][] checkedArray = new boolean[targetArea.length][targetArea.length];
        int centre = visionDistance;
        for(int row = centre-distance; row <= centre+distance; row++) {
            for (int col = centre - distance; col <= centre + distance; col++) {
                if (targetArea[row][col] != null) {
                    if (!checkedArray[row][col]) {
                        checkedArray[row][col] = true;
                        if ((row != centre) && (col != centre) && isTarget(targetArea[row][col], target) && targetArea[row][col].isOppositeGender(thisAnimal)) {
                            return new int[]{row, col};
                        }
                    }
                }
            }
        }
        return null;
    }
    
}

