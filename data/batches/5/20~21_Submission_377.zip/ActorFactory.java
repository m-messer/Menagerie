 

import java.util.HashMap;

/**
 * @version 3.03.2021
 * This class is factory for actors.
 * It generates a random animal
 */
public class ActorFactory
{
    /**
     * Generates animal with random age.
     * Used to populate the animal field initially.
     * @param field the field
     * @param location the location
     * @param type the type of actor to create
     * @param customFieldsAndValues HashMap of the custom variables for this animal. Key is the String name of the variable, in the form CustomXYZ, value is an integer to set that variable to
     * @return Actor of type indicated in type. So if type "Lion", will return a new Lion object with a random age.
     */
    public Actor getAnimalOfRandomAge(Field field,Location location,String type, HashMap<String,Integer> customFieldsAndValues)
    {
        switch(type) 
        {
            case "Lion":
                return new Lion(true, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Cheetah":
                return new Cheetah(true, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Coyote":
                return new Coyote(true, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Deer":
                return new Deer(true, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);
                
            case "Squirrel":

                return new Squirrel(true, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);
            default:
                return null;
        }
    }

    /**
     * Generates new actors
     * Used in animal breeding, plant propogation and plant populating
     * @param field the field
     * @param location the location
     * @param type the type of actor to create
     * @param customFieldsAndValues HashMap of the custom variables for this actor. Key is the String name of the variable, in the form CustomXYZ, value is an integer to set that variable to
     * @return Actor of type indicated in type. So if type "Lion", will return a new Lion object with an age of zero.
     */
    public Actor getActor(Field field, Location location, String type,HashMap<String,Integer> customFieldsAndValues)
    {
        switch(type) 
        {
            // if the type is lion, create a new lion with a non-random age(0), on the given field, in the given location, with a random boolean value for its gender, and with the provided custom variables
            case "Lion":
                return new Lion(false, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Cheetah":
                return new Cheetah(false, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Coyote":
                return new Coyote(false, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Deer":
                return new Deer(false, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Squirrel":
                return new Squirrel(false, field, location, Randomizer.getRandom().nextBoolean(),customFieldsAndValues);

            case "Grass":
                return new Grass( field, location,customFieldsAndValues);

            case "Nuts":
                return new Nuts( field, location,customFieldsAndValues);

            case "Berries":
                return new Berries( field, location,customFieldsAndValues);

            default:
                return null;
        }
    }

}
