 

import java.util.HashMap;
import  java.util.List;
import java.util.Random;
/**
 * A simple model representing berries.
 * berries can grow, propogate and die 
 *
 * @version 2021.3.03
 */
public class Berries extends Plant
{
    // a Random object, from our shared randomizer class
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new berries object at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param customVariables the custom variables hashmap for this animal
     */
    public Berries(Field field, Location location, HashMap<String,Integer> customVariables)
    {
        super(field, location,customVariables);
    }

    /**
     * This is what berries do most of the time: it grows
     * In the process, it might propagate to a neighbouring grid square or die of old age
     * @param newBerries A list to return newly born berries.
     */
    public void act(List<Actor> newBerries, int time) 
    {
        // if it is after 4 am and before 6 pm this berry can act
        if(time > 4 && time < 18 && isAlive())
        {
            this.incrementGrowthProgress(CustomGrowthSpeed);
            if(rand.nextDouble() <= ((double) CustomPropagationChance/100))
            {
                // try to breed
                propagate(newBerries);
            }
        }
    }
}
