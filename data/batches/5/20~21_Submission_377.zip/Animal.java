import java.util.*;

/**
 * A class representing shared characteristics and actions of all the animals in our simulation.
 *
 * 
 * @version 2021.2.28 (4)
 */
public abstract class Animal extends Actor
{
    // The gender of the animal. True for a male, False for female.
    protected boolean isMale;

    // integer counter for how many steps since the animal was last involved in breeding
    protected int stepsSinceLastBred;

    // integer representing current food level of animal.
    // a value of 1 means they are 1 step from death unless they eat
    // a value of 10 means 10 steps etc etc
    protected int foodLevel;

    // the customisable variable representing the minimum age that this animal can breed at.
    protected int CustomBreedingAge;

    // the customisable variable representing the age to which an animal can live.
    protected int CustomMaxAge;

    // the customisable variable representing the maximum number of births this animal can have.
    protected int CustomMaxLitterSize;

    // the customisable variable representing the maximum food level that animal can have at any time
    protected int CustomMaxFoodLevel;

    // the customisable variable representing how many steps a animal must wait before breeding again.
    protected int CustomBreedingDelay;

    // the customisable variable representing how far this animal can see
    protected int CustomViewDistance;

    // a random object from the shared randomizer class.
    Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field, setting its gender, age, and any custom variables this animal has.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender (true for male, false for female)
     * @param customVariables the custom variables hashmap for this animal
     * @param randomAge whether this animal should have a random age or not
     * 
     */
    protected Animal(Field field, Location location, boolean gender, HashMap<String,Integer> customVariables, boolean randomAge)
    {
        super(field,location);
        applyCustomVariables(customVariables,this);
        this.isMale = gender;
        if (randomAge) 
        {
            //sets the animal's age and food level to random 
            this.setAge(rand.nextInt(this.getCustomMaxAge()));
            this.setFoodLevel(rand.nextInt(this.getCustomMaxFoodLevel()));
        }
        // in every other case, animal is just being born, set age to 0 and food level to a fraction of the max.
        else 
        {
            this.setAge(0);
            this.setFoodLevel(this.getCustomMaxFoodLevel()/4);

        }
    }

    /**
     * Make this animal act
     * decrease food level by 1
     * increase steps since last breeding by one
     * @param maxAge A list to receive new actors.
     */
    public void act(int maxAge)
    {
        super.act(maxAge);
        decreaseFoodLevel();
        incrementLastBred();
    }

    /**
     * Perform these actions while awake. Animal will attempt to breed, then attempt to find food if it is hungry enough
     * If it does not need food, it will try to walk towards a mate.
     * If it cannot find a mate or cannot find food, it will wander aimlessly.
     * If it cannot move, it will die from overcrowding.
     * @param newAnimals A list to receive new animals.
     * @param edibleArray Array of what the animal can eat. 
     */
    protected void actionsWhileAwake(List<Actor> newAnimals, Class[] edibleArray)
    {
        if (isAlive()) 
        {
            giveBirth(newAnimals);
            // Move towards a source of food if found.
            Location newLocation = null;
            //find food if needed
            if(foodLevel<10) 
            {
                newLocation = findFoodAdjacent(edibleArray);
                if(newLocation == null)
                {
                    newLocation = pathToFood(edibleArray);
                }
            }
            //otherwise find mate
            else if(getStepsSinceLastBred() > this.getCustomBreedingDelay())
            {
                newLocation = findMate();
            }
            if (newLocation == null) 
            {
                // pathfinding failed to find food or a mate - try to move to a random free location.
                newLocation = getField().freeAnimalAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) 
            {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Try to find a path to something we can eat.
     * @param edibleArray array of classes that this animal can eat
     * @return return an adjacent grid that is closer to food than we currently are. If none is found, return null.
     */
    protected Location pathToFood(Class[] edibleArray)
    {
        Pathfinder p = new Pathfinder(field,this.getCustomViewDistance(),this.getLocation());
        ArrayList<Class> targetList = new ArrayList<>(Arrays.asList(edibleArray));
        SearchResult searchResult = p.findClosest(targetList);
        if(searchResult!= null)
        {
            return p.pathTowards(searchResult.getLocation());
        }
        else 
        {
            return null;
        }
    }

    /**
     * Try to find a path to a mate.
     * @return return an adjacent grid that is closer to a mate than we currently are. If none is found, return null.
     */
    private Location findMate() 
    {
        Pathfinder p = new Pathfinder(field,this.getCustomViewDistance(),this.getLocation());
        SearchResult SearchResult = p.findTargetOfOppositeGender(this.getClass(),this);
        if(SearchResult!= null)
        {
            return p.pathTowards(SearchResult.getLocation());
        }
        else 
        {
            return null;
        }
    }

    /**
     * Checks if given animal is of the opposite gender
     * @param otherAnimal The other animal in question
     */
    protected boolean isOppositeGender(Animal otherAnimal)
    {
        //first case is male and the other animal is female
        //otherwise they are both the same gender
        if(getIsMale() && !otherAnimal.getIsMale())
        {
            return true;
        }
        //second case is female and the other animal is male
        else 
        {
            return !getIsMale() && otherAnimal.getIsMale();
        }
    }

    /**
     * Gets the gender
     * @return isMale 
     * true for male, false for female
     */
    protected boolean getIsMale()
    {
        return this.isMale;
    }

    /**
     * Sets alive to false. Clears the location in the animal field.
     * 
     */
    @Override
    protected void setDead()
    {
        alive = false;
        if(location != null) 
        {
            field.clearAnimal(location);
            location = null;
            field = null;
        }
    }

    /**
     * Checks if 2 animals can breed. The first animal is the one checking, the other animal is the target.
     * @param thisAnimal the target animal 
     * @return true if the pair of animals can breed
     * @return false if the pair of animals cannot breed
     */
    protected boolean canBreed(Animal thisAnimal)
    {
        // if this animal is old enough to breed

        if (thisAnimal.getAge() >= thisAnimal.getCustomBreedingAge())
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            //iterate through list of adjacent locations
            for (Location where : adjacent)
            {
                Animal animal = field.getAnimalAt(where);
                //check each location for object of type animal.
                if (animal!= null && animal.getClass().equals(thisAnimal.getClass()))
                {
                    // if the found animal is alive, and of the opposite gender to the animal that is checking, and is old enough to breed
                    if (animal.isAlive() && animal.isOppositeGender(this) && animal.getAge() >= thisAnimal.getCustomBreedingAge())
                    {
                        // now first check if this animal is male.
                        // If so, other animal is definitely female and we must check the other animal to see if it's breeding cooldown has elapsed.
                        if (this.getIsMale() && (animal.getStepsSinceLastBred() > thisAnimal.getCustomBreedingDelay()))
                        {
                            animal.resetStepsSinceLastBred();
                            return true;
                        }
                        // else, we know this animal is female, and we must check this animal to see if it's breeding cooldown has elapsed.
                        else if (!this.getIsMale() && thisAnimal.getStepsSinceLastBred() > thisAnimal.getCustomBreedingDelay())
                        {
                            //this animal's breeding delay is also reset but in breed() by setting breeding delay to 0.
                            return true;
                        }
                    }
                }

            }
        }
        //if all other checks fail, they cannot breed
        return false;
    }

    /**
     * Look for prey adjacent to the current location.
     * Checks the 8 tiles around itself
     * Only the first live prey is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFoodAdjacent(Class[] edibleArray)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) 
        {
            Location where = it.next();
            Object[] objects = field.getObjectsAt(where);
            for(Object prey : objects)
            {
                if (prey != null && Arrays.asList(edibleArray).contains(prey.getClass()) ) 
                {
                    return eatFood(prey, where);
                }
            }
        }

        return null;
    }

    /**
     * Eat the food at the given location, then return that location so we can move there. Return null if food is already dead.
     * @param prey the object at the location
     * @param where the location of the object
     * @return location if we can eat the object, otherwise null.
     */
    protected Location eatFood(Object prey, Location where)
    {
        Actor food = (Actor) prey;
        if (food.isAlive()) 
        {
            // if food is an animal
            if (food instanceof Animal) 
            {
                food.setDead();
                foodLevel = foodLevel + food.getCustomNutritionValue();

            }
            else // food is a plant
            {
                Plant plant = (Plant) food;
                foodLevel = foodLevel + food.getCustomNutritionValue();
                plant.decreaseGrowth();
                //instead of killing the plant, reduce its growth 
            }
            // return location, we will move there
            return where;

        }
        return null;
    }

    /**
     * Creates a new animal
     * @param newAnimals the list of all actors that we will add our animals to
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getAnimalFreeAdjacentLocations(getLocation());
        int births = breed();

        // create a new actor factory
        ActorFactory a = new ActorFactory();
        for (int b = 0; b < births && free.size() > 0; b++)
        {
            // for each free location, birth an animal of this type there.
            Location loc = free.remove(0);
            newAnimals.add(a.getActor(field, loc, this.getClass().getSimpleName(),this.getCustomVariables()));
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     * There can be multiple births.
     * No births if can't breed
     */
    protected int breed()
    {
        int births = 0;
        if (canBreed(this))
        {
            births = rand.nextInt(this.getCustomMaxLitterSize()) + 1;
            this.setStepsSinceLastBred(0);
        }
        return births;
    }

    /**
     * Sets the location of the animal to the new location.
     * @param newLocation
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null)
        {
            field.clearAnimal(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Get the minimum age this animal can breed at.
     * @return minimum age this animal can breed at.
     */
    public int getCustomBreedingAge() 
    {
        return CustomBreedingAge;
    }

    /**
     * Set the minimum age this animal can breed at
     * @param customBreedingAge integer we want to limit the animal to not breeding before
     */
    public void setCustomBreedingAge(int customBreedingAge) 
    {
        CustomBreedingAge = customBreedingAge;
    }

    /**
     * Get the maximum age this animal can be
     * @return max age
     */
    public int getCustomMaxAge() 
    {
        return CustomMaxAge;
    }

    /**
     * set the maximum age this animal can be
     * @param customMaxAge integer representing the maximum age this animal can be
     */
    public void setCustomMaxAge(int customMaxAge) 
    {
        CustomMaxAge = customMaxAge;
    }

    /**
     * get the maximum amount of young this animal can birth in one step.
     * @return max amount of children per step
     */
    public int getCustomMaxLitterSize() 
    {
        return CustomMaxLitterSize;
    }

    /**
     * set the maximum amount of young this animal can birth in one step.
     * @param customMaxLitterSize max amount of children per step
     */
    public void setCustomMaxLitterSize(int customMaxLitterSize) 
    {
        CustomMaxLitterSize = customMaxLitterSize;
    }

    /**
     * Get the "maxFoodLevel" of this animal, which is used when creating children.
     * @return maximum food level
     */
    public int getCustomMaxFoodLevel() 
    {
        return CustomMaxFoodLevel;
    }

    /**
     * set the "maxFoodLevel" of this animal, which is used when creating children.
     * @param customMaxFoodLevel
     */
    public void setCustomMaxFoodLevel(int customMaxFoodLevel) 
    {
        CustomMaxFoodLevel = customMaxFoodLevel;
    }

    /**
     * set the minimum number of steps this animal must wait between successful breeding attemps
     * @param customBreedingDelay minimum steps between breeding attempts
     */
    public void setCustomBreedingDelay(int customBreedingDelay) 
    {
        CustomBreedingDelay = customBreedingDelay;
    }

    /**
     * get the minimum number of steps this animal must wait between successful breeding attemps
     * @return minimum steps between breeding attempts
     */
    public int getCustomBreedingDelay()
    {
        return this.CustomBreedingDelay;
    }

    /**
     * Set how far this animal can see, used by pathfinder class.
     * @param customViewDistance maximum distance this animal can see
     */
    public void setCustomViewDistance(int customViewDistance) 
    {
        CustomViewDistance = customViewDistance;
    }

    /**
     * Get the maximum distance this animal can see. used by pathfinder class
     * @return maximum distance this animal can see
     */
    public int getCustomViewDistance()
    {
        return CustomViewDistance;
    }

    /**
     * Gets the food level of this animal
     * @return integer food level
     */
    protected int getFoodLevel()
    {
        return this.foodLevel;
    }

    /**
     * Sets the new food level
     * @param foodLevel
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }

    /**
     * Decreases food level of this animal by one. If it hits zero, the animal is set to dead.
     */
    protected void decreaseFoodLevel()
    {
        this.foodLevel--;
        if(this.foodLevel == 0)
        {
            setDead();
        }
    }

    /**
     * Gets the steps since last bred
     * @return stepsSinceLastBred
     */
    protected int getStepsSinceLastBred()
    {
        return stepsSinceLastBred;
    }

    /**
     * Resets the steps since last bred to 0, meaning they must wait to breed again
     */
    protected void resetStepsSinceLastBred()
    {
        stepsSinceLastBred = 0;
    }

    /**
     * Set the steps since we last bred
     * @param steps integer to set last bred to
     */
    protected void setStepsSinceLastBred(int steps)
    {
        this.stepsSinceLastBred = steps;
    }

    /**
     * Increments the steps since last bred by 1
     */
    protected void incrementLastBred()
    {
        stepsSinceLastBred++;
    }

}
