 

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;


/**
 * A class representing an Actor.
 * This class is the superclass of Animal and Plant, which are both abstract classes.
 *
 * @version 2021.02.15 (1)
 */
public abstract class Actor
{
    // Whether the actor is alive or not.
    protected boolean alive;
    
    // The actor's field.
    protected Field field;
    
    // The actor's position in the field.
    protected Location location;

    // the nutrition value of this actor when it is eaten. Customisable.
    protected int CustomNutritionValue;
    // The age of the actor.
    protected int age;

    // a HashMap that we use to store all the customVariables for this actor.
    // Key is the name of the variable( in the style CustomXYZ) and value is the integer value of that variable
    protected HashMap<String, Integer> customVariables;

    /**
     * Create a new actor at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Actor(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors a list for the actor to add to if it creates new animals
     * @param timeOfDay the time of day in the simulator
     */
    public abstract void act(List<Actor> newActors, int timeOfDay);

    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     * @param maxAge A list to receive newly born actors.
     */
    public void act(int maxAge){
        incrementAge(maxAge);
    }

    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected abstract void setDead();


    /**
     * Return the age 
     * @return the age
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Sets the age
     * @param age
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Increase the age of this actor by 1. maxAge is passed so that we set the actor to dead if they are too old.
     * @param maxAge maximum age this actor can be
     */
    protected void incrementAge(int maxAge)
    {
        this.age++;
        if(age == maxAge)
        {
            this.setDead();
        }
    }
    
    /**
     * Gets the CustomNutritionValue.
     * @return the nutrition value
     */
    public int getCustomNutritionValue()
    {
        return this.CustomNutritionValue;
    }

    /**
     * Set custom nutrition value to the value provided
     * @param CustomNutritionValue
     */
    public void setCustomNutritionValue(int CustomNutritionValue)
    {
        this.CustomNutritionValue = CustomNutritionValue;
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected abstract void setLocation(Location newLocation);


    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Intialises this actor with the custom variables provided. This method is flexible, it will
     * apply any valid variables with the naming scheme "setCustomXYZ". It will catch an errors and print them to the terminal, but will not crash the program.
     * @param customVariables HashMap of the custom variables for this actor. Key is the String name of the variable, in the form CustomXYZ, value is an integer to set that variable to
     * @param actor the actor to apply these values to.
     */
    protected void applyCustomVariables(HashMap<String,Integer> customVariables, Actor actor){
        // store the hashmap in this actor
        setCustomVariables(customVariables);
        // for each key/value pair
        customVariables.forEach((key, value) ->
        {
            // create an empty class array and store the int class inside it, this is needed to allow us to find the right methods.
            Class[] arguments = new Class[1];
            arguments[0] = int.class;
            Method setter = null;
            // try to find the set method for this key/value pair
            try {
                // get the setKey method with the arguments(integer)
                setter = actor.getClass().getMethod("set" + key, arguments);
                // invoke this method on the actor, with the argument being the value of this key/value pair
                setter.invoke(actor,value);
            } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Store the customVariables hashmap for this actor
     * @param customVariables HashMap of the custom variables for this actor. Key is the String name of the variable, in the form CustomXYZ, value is an integer to set that variable to
     */
    protected void setCustomVariables(HashMap<String, Integer> customVariables){
        this.customVariables = customVariables;
    }

    /**
     * Return the customVariables hashmap for this actor
     * @return HashMap of the custom variables for this actor. Key is the String name of the variable, in the form CustomXYZ, value is an integer to set that variable to
     */
    protected HashMap<String,Integer> getCustomVariables(){
        return this.customVariables;
    }
}
