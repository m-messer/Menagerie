 

import java.util.HashMap;
import  java.util.List;
import java.util.Random;
/**
 * A simple model representing nuts.
 * nuts can grow, propogate and die 
 *
 * @version 2021.3.03
 */
public class Nuts extends Plant
{
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new nuts at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Nuts(Field field, Location location, HashMap<String,Integer> customVariables)
    {
        super(field, location,customVariables);
    }

    /**
     * This is what nuts do most of the time: it grows
     * In the process, it might propogate or die of old age
     * @param newNuts A list to return newly born nuts.
     */
    public void act(List<Actor> newNuts, int time) 
    {
        if(time > 6 && time < 18 && isAlive())
        {
            this.incrementGrowthProgress(CustomGrowthSpeed);
            if(rand.nextDouble() <= ((double)CustomPropagationChance/100))
            {
                propagate(newNuts);
            }
        }
    }
}
