 

import java.util.*;
/**
 * A class representing the shared characteristics of a plant
 * Plants can be eaten, and will only die once growth reaches 0.
 * Plants can be eaten multiple times.
 *
 * @version 2021.2.15
 */
public abstract class Plant extends Actor
{
    // how large the plant is. As it is eaten by animals, growth progress goes down, 
    // when it reaches 0, plant dies
    private int growthProgress;

    public int getCustomGrowthSpeed() {
        return CustomGrowthSpeed;
    }
    

    public void setCustomGrowthSpeed(int customGrowthSpeed) {
        CustomGrowthSpeed = customGrowthSpeed;
    }

    public int getCustomPropagationChance() {
        return CustomPropagationChance;
    }

    public void setCustomPropagationChance(int customPropagationChance) {
        CustomPropagationChance = customPropagationChance;
    }

    public int getCustomMaxAge() {
        return CustomMaxAge;
    }

    public void setCustomMaxAge(int customMaxAge) {
        CustomMaxAge = customMaxAge;
    }

    protected int CustomGrowthSpeed = 1;

    protected int CustomPropagationChance = 1;

    protected int CustomMaxAge = 480;
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * 
     */
    Plant(Field field, Location location,HashMap<String,Integer> customVariables)
    {
        super(field, location);
        applyCustomVariables(customVariables, this);
    }

    /**
     * Gets the current growth of the plant
     * @return growthProgress
     */
    protected int getGrowthProgress()
    {
        return this.growthProgress;
    }

    /**
     * Reduces the growth progress by an amount
     * @param growthDecrease the amount to decrease growth by
     */
    protected void reduceGrowthProgress(int growthDecrease)
    {
        growthProgress -= growthDecrease;
    }

    /**
     * Increments the growth process by the growth increase
     * @param growthIncrease the amount of growth increase the plant has. 
     */
    protected void incrementGrowthProgress(int growthIncrease)
    {
        growthProgress += growthIncrease;
        if(growthProgress > 100)
        {
            growthProgress = 100;
        }
    }

    @Override
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clearPlant(location);
            location = null;
            field = null;
        }
    }

    protected void setLocation(Location newLocation)
    {
            if(location != null)
            {
                field.clearPlant(location);
            }
            location = newLocation;
            field.place(this, newLocation);
    }

    /**
     * Decreases the growth progress by the nutrition value. 
     * When plants get eaten they don't immediately die.
     */
    public void decreaseGrowth()
    {
        this.growthProgress -= this.getCustomNutritionValue();
        if(growthProgress < 0){
            this.setDead();
        }
    }

    protected void propagate(List<Actor> newPlants)
    {

        Field field = getField();
        List<Location> freeSpaces = field.getPlantFreeAdjacentLocations(getLocation());
        if (!(freeSpaces.isEmpty())) {
            ActorFactory a = new ActorFactory();
            Location loc = freeSpaces.remove(0);
            newPlants.add(a.getActor(field,loc,this.getClass().getSimpleName(), this.getCustomVariables()));
        }
    }
}
