
import java.util.HashMap;
import java.util.List;
/**
 * A simple model of a deer.
 * deers age, move, breed, and die.
 * deers die when they can't move or when they reach dying age. 
 *
 * @version 2021.02.27 (2)
 */
public class Deer extends Animal
{
    // array of edible objects that deer can eat
    private static final Class[] edibleArray = new Class[] { Grass.class };

    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location, boolean gender, HashMap<String,Integer> customVariables)
    {
        super(field, location, gender,customVariables,randomAge);
    }

    /**
     * This is what the deer does most of the time - it runs 
     * around between the times of 8 AM and 8 PM. Sometimes it will breed or die of old age.
     * @param newdeers A list to return newly born deers.
     */
    public void act(List<Actor> newdeers, int time)
    {
        super.act(CustomMaxAge);

        // If the time is between 8 AM and 8 PM, deers move around freely. 
        //Otherwise they are "asleep" and do not move. They can still be hunted and eaten.
        if(time > 8 && time < 20) 
        {
            actionsWhileAwake(newdeers, edibleArray);
        }

    }

}

