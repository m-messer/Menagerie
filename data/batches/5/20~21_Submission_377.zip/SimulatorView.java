
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 * There are 2 layers to the simulator view, animal layer and plant layer.
 *
 * 
 * @version 2021.03.3 (3)
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    // the simulator that this simulator view displays.
    private Simulator sim;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String TIME_PREFIX = "Time: ";
    private final String DAY_PREFIX = "Day: ";
    private JLabel stepLabel, population,dayLabel, timeLabel,layerLabel;
    private FieldView fieldView;

    // two extra windows we create later.
    private JFrame settingsMenuFrame;
    private JFrame variableFrame;

    // is the grid meant to be displaying the animal layer?
    // if this variable is false, display the plant layer.
    private boolean animalLayer = true;
    // has the settingsMenuFrame been created
    private boolean existsSettings = false;

    // hashmap of all the customisable classes, and the stored hashmap of the customisable variables and their values, for each class.
    private HashMap<String, HashMap<String,Integer>> allCustomFieldsAndValues;
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width, Simulator sim)
    {
        allCustomFieldsAndValues = new HashMap<>();
        this.sim = sim;
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Totally-Accurate-Animal-Simulator");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        timeLabel = new JLabel(TIME_PREFIX, JLabel.CENTER);
        dayLabel = new JLabel(DAY_PREFIX, JLabel.CENTER);

        setLocation(300, 50);

        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new FlowLayout());
        infoPane.add(stepLabel, BorderLayout.EAST);

        infoPane.add(timeLabel, BorderLayout.WEST);
        infoPane.add(dayLabel, BorderLayout.CENTER);

        JButton step1 = new JButton("Step 1");
        step1.setPreferredSize(new Dimension(80,50));

        JButton step12 = new JButton("Step 12");
        step12.setPreferredSize(new Dimension(80,50));

        JButton step24 = new JButton("Step 24");
        step24.setPreferredSize(new Dimension(80,50));

        JButton advancedOptions = new JButton("Advanced Options");
        advancedOptions.setPreferredSize(new Dimension(140,50));

        JButton pauseButton = new JButton("Stop");
        pauseButton.setPreferredSize(new Dimension(100,50));

        JButton resetButton = new JButton("Reset");
        resetButton.setPreferredSize(new Dimension(100,50));

        JButton layerButton = new JButton("Change Layer");
        layerButton.setPreferredSize(new Dimension(140,50));

        //adding on event button press to the buttons
        layerButton.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    // invert the value of animalLayer, and update view of the simulator to reflect this
                    animalLayer= !animalLayer;
                    updateStatus(sim.getField());
                    layerLabel.setText(updateLayer());

                }
            }
        );

        step1.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    // if the sim is not already running, run 1 step
                    if(!sim.isRunning()) {
                        sim.simulateOneStep();
                    }
                }
            }
        );

        step12.addActionListener(new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    // if the simulator is not already running, run 12 steps
                    if(!sim.isRunning()) {
                        sim.simulate(12, 0);
                    }
                }
            }
        );

        step24.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    // if the simulator is not already running, run 24 steps
                    if(!sim.isRunning()) {
                        sim.simulate(24, 0);
                    }
                }
            }
        );

        advancedOptions.addActionListener(new ActionListener()

            {
                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    // if the settings menu hasn't been created yet, create it
                    if(!existsSettings)
                    {
                        createSettingsMenu();
                    }
                    // interrupt the running of the sim, as we will be changing custom variable values soon
                    sim.setInterrupt(true);
                    showSettingsMenu();
                    //open new frame with options;
                }
            }
        );

        pauseButton.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    // stop the simulation from running
                    sim.setInterrupt(true);
                }
            }
        );

        resetButton.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    // reset the simulation
                    sim.setInterrupt(true);
                    sim.reset();
                }
            }
        );

        JPanel popPane = new JPanel(new BorderLayout());
        popPane.add(population);

        layerLabel = new JLabel("",JLabel.CENTER);
        layerLabel.setText(updateLayer());

        popPane.add(layerLabel,BorderLayout.SOUTH);

        JPanel bottomPane = new JPanel(new BorderLayout());
        JPanel controlPane = new JPanel(new FlowLayout());

        controlPane.add(step1);
        controlPane.add(step12);
        controlPane.add(step24);

        JPanel settingsPane = new JPanel(new FlowLayout());

        settingsPane.add(pauseButton);
        settingsPane.add(resetButton);
        settingsPane.add(advancedOptions);
        settingsPane.add(layerButton);

        bottomPane.add(popPane, BorderLayout.CENTER);
        bottomPane.add(controlPane , BorderLayout.WEST);
        bottomPane.add(settingsPane, BorderLayout.EAST);

        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(bottomPane, BorderLayout.SOUTH);

        SwingUtilities.updateComponentTreeUI(this);

        pack();
        this.setResizable(false);
        setVisible(true);

    }

    /**
     * Return the correct string to display to the user depending on whether we are displaying animal or plant layer
     * @return correct string to display to the user depending on whether we are displaying animal or plant layer
     */
    private String updateLayer() {
        if(animalLayer)
        {
            return  "Animal Layer";
        }
        else
        {
            return  "Plant Layer";
        }
    }

    /**
     * Create our settings menu, this has a list of all the customisable classes. User can push a button for each class to open up a new window with a list of all the
     * customisable variables and the values. The values are shown in a text field, which the user can modify, then apply.
     * This settins menu then has an "apply all changes" button that will apply all the changes to the simulation.
     */
    private void createSettingsMenu()
    {
        existsSettings = true;
        settingsMenuFrame = new JFrame();
        //Settings for initialising the frame
        settingsMenuFrame.setTitle("Totally-Accurate-Settings-Menu");
        settingsMenuFrame.setLocation(1500, 300);
        settingsMenuFrame.setSize(250,400);

        Container contents = settingsMenuFrame.getContentPane();
        contents.setSize(500, 500);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));

        updateAllCustomFieldsAndValues();
        // create a button for each class that says "Change CLASSNAME" and open a new window when it is pushed
        
        allCustomFieldsAndValues.forEach((key,value) ->
            {
                JButton button = new JButton("Change "+ key);

                button.setPreferredSize(new Dimension(1000,50));
                button.setMaximumSize(new Dimension(1000,50));
                mainPanel.add(button);
                button.addActionListener(new ActionListener()

                    {
                        @Override
                        public void actionPerformed(ActionEvent e) 
                        {
                            createVariables(key,value);
                        }
                    }
                );
            }
            );
        // add apply all changes that will send all the updated variables to the simulation and reset it.
        JButton applyAllChanges = new JButton("Apply all changes");
        applyAllChanges.setPreferredSize(new Dimension(1000,50));
        applyAllChanges.setMaximumSize(new Dimension(1000,50));
        applyAllChanges.addActionListener(new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    sim.applyChanges(allCustomFieldsAndValues);
                    settingsMenuFrame.setVisible(false);

                }
            }
        );

        mainPanel.add(applyAllChanges);

        contents.add(mainPanel);
        
        settingsMenuFrame.setResizable(false);
        settingsMenuFrame.setVisible(false);

    }

    /**
     * Set settings menu to visible.
     */
    private void showSettingsMenu()
    {
        settingsMenuFrame.setLocation(1500,300);
        settingsMenuFrame.setVisible(true);
    }

    /**
     * Get all the customisable classes and variables(and  their values) from the simulation class.
     */
    private void updateAllCustomFieldsAndValues(){
        String[] customisableClasses = sim.getCustomisableClasses();
        for (String actor : customisableClasses) {
            try {
                allCustomFieldsAndValues.put(actor, new HashMap<>(sim.getFieldsAndValues(actor)));
            } catch (Exception e) {
                System.out.println("Error");
                e.printStackTrace();
            }
        }
    }

    /**
     * Creates menu allowing user to change variables of the actor passed to it
     * @actor the string name of the class we are customising
     * @param customFieldsAndValues HashMap of the custom variables(String key) and their values(integer value);
     */
    private void createVariables(String actor, HashMap<String,Integer> customFieldsAndValues) {
        variableFrame = new JFrame();
        //Settings for initialising the frame
        variableFrame.setTitle("Totally-Accurate-variable-settings");
        variableFrame.setLocation(1500, 50);
        variableFrame.setSize(600,500);

        Container contents = variableFrame.getContentPane();
        contents.setSize(500, 500);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
        ArrayList<JTextField> textFields = new ArrayList<>();
        ArrayList<JLabel> labels = new ArrayList<>();
        // for each custom field, build a jlabel with the field name, and a textfield with its value.
        customFieldsAndValues.forEach((key,value) ->
            {
                JPanel panel = new JPanel(new FlowLayout());
                //need jbutton + jtextfield pair
                JLabel label = new JLabel();//parameter of field name
                label.setText(key);
                label.setPreferredSize(new Dimension(250, 50));
                label.setMaximumSize(new Dimension(250, 50));

                JTextField settingTextField = new JTextField();//parameter of current value (so that it can be changed)
                settingTextField.setText(String.valueOf(value));
                settingTextField.setPreferredSize(new Dimension(250, 50));
                settingTextField.setMaximumSize(new Dimension(250, 50));

                // add labels and textfields to an arraylist so they can be referenced later.
                labels.add(label);
                textFields.add(settingTextField);

                panel.add(label);
                panel.add(settingTextField);
                mainPanel.add(panel);
            }
            );
        // when this button is pushed, go through each custom field, get the value from the textfield, and update the hashmap with the value.
        // then replace the hashmap for this actor that is currently stored in the global allCustomFieldsAndValue variable with the new updated hashmap we have just created.
        JButton applyButton = new JButton("Apply changes");
        applyButton.addActionListener(new ActionListener()

            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    for(int i = 0; i < labels.size(); i++){
                        customFieldsAndValues.put(labels.get(i).getText(), Integer.parseInt(textFields.get(i).getText()));
                    }
                    allCustomFieldsAndValues.replace(actor,customFieldsAndValues);
                    variableFrame.dispose();
                }

            });
        mainPanel.add(applyButton);
        

        contents.add(mainPanel);
        
        variableFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        variableFrame.setResizable(false);
        variableFrame.setVisible(true);
    }

    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * @param actorClass
     * @return The color to be used for a given class of animal.
     * returns the default color otherwise.
     */
    private Color getColor(Class actorClass)
    {
        Color col = colors.get(actorClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void updateStatus(int step, Field field, int time, int day)
    {
        updateLabels(step, time, day);
        updateStatus(field);
    }

    /**
     * Show the current status of the field.
     * @param field The field whose status is to be displayed.
     */
    public void updateStatus(Field field)
    {
        if(!isVisible())
        {
            setVisible(true);
        }

        stats.resetCounters();

        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++)
        {
            for(int col = 0; col < field.getWidth(); col++)
            {
                stats.updateStats(field,row,col);
                Object actor;
                //Either the animal layer is shown or the plant layer is shown.
                if(animalLayer)
                {
                    actor = field.getAnimalAt(row, col);
                }
                else
                {
                    actor = field.getPlantAt(row, col);
                }
                if (actor != null)
                {
                    fieldView.drawMark(col, row, getColor(actor.getClass()));
                } else
                {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();
        layerLabel.setText(updateLayer());
        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field,animalLayer));
        fieldView.repaint();
    }

    /**
     * Update the step, time, and day labels
     * @param step current step
     * @param time current time
     * @param day current day
     */
    private void updateLabels(int step, int time, int day){
        stepLabel.setText(STEP_PREFIX + step);
        timeLabel.setText(TIME_PREFIX + time);
        dayLabel.setText(DAY_PREFIX + day);
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If all species are alive
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 5;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
