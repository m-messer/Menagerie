 

import java.util.HashMap;
import java.util.List;

/**
 * A simple model of a cheetah.
 * Cheetahs age, move, eat deers, and die.
 * Cheetahs die when food level too low, when they can't move, or upon reaching dying age.
 * @version 2021.02.27 (2)
 */
public class Cheetah extends Animal 
{
    // array of edible objects that cheetahs can eat
    private static final Class[] edibleArray = new Class[] { Deer.class, Squirrel.class };
    /**
     * Create a cheetah. A cheetah can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the cheetah will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param customVariables hashmap of the custom variables for this animal
     */
    public Cheetah(boolean randomAge, Field field, Location location, boolean gender, HashMap<String,Integer> customVariables)
    {
        super(field, location, gender,customVariables, randomAge);
    }

    /**
     * This is what the cheetah does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newCheetahs A list to return newly born cheetahs.
     */
    public void act(List<Actor> newCheetahs, int time) 
    {
        super.act(CustomMaxAge);
        //awake between 6pm to 6am
        if (time < 6 || time > 18) {
            // if Cheetahs are asleep, they cannot do anything
            actionsWhileAwake(newCheetahs,edibleArray);
        }
    }
}
