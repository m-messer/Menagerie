 

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
/**
 * This class handles the random probability for populating the field.
 * This class decides what actor is spawned.
 * @version 28/2/2021 (1)
 */
public class WeightedRandomHandler 
{

    // list of actors and their probablities
    private ArrayList<String> actors;
    private ArrayList<Double> probabilities;
    /**
     * Construct a handler with the actors and their creation probabilities. it is assumed that actors[0] is the actor with the probablity stored in weights[0]
     * @param actors String array of all the actors
     * @param weights String double of all the probabilities for these actors
     */
    public WeightedRandomHandler(String[] actors, Double[] weights)
    {
        this.actors = new ArrayList<>(Arrays.asList(actors));
        this.probabilities = new ArrayList<>(Arrays.asList(weights));
        sortLists();
    }

    /**
     * Sorts the list using an insertion sort variant.
     */
    private void sortLists() 
    {
        int j;
        int i = 1;
        double tempDouble;
        String tempString;
        while (i < probabilities.size())
        {
            j = i;
            while (j > 0 && probabilities.get(j-1) > probabilities.get(j))
            {
                tempDouble = probabilities.get(j);
                tempString = actors.get(j);

                probabilities.set(j,probabilities.get(j-1));
                actors.set(j,actors.get(j-1));

                probabilities.set(j-1,tempDouble);
                actors.set(j-1,tempString);
                j--;
            }
            i++;
        }
    }

    /**
     * This is where the actor spawned is decided
     * @param probability the generated probability
     * @return the actor that has been chosen. Can return an empty string if no actor is chosen.
     */
    public String calculateGeneration(double probability)
    {

        ArrayList<String> possibleActors = new ArrayList<>();
        for(int i = 0; i < actors.size(); i++)
        {
            if((i == 0) && (probability <= probabilities.get(i)))
            {
                possibleActors.add(actors.get(i));
            }
            else if(probability <= probabilities.get(i) && probabilities.get(i) >= probabilities.get(i-1))
            {
                possibleActors.add(actors.get(i));
            }
        }

        if(!possibleActors.isEmpty())
        {
            Random rand = Randomizer.getRandom();
            return possibleActors.get(rand.nextInt(possibleActors.size()));
        }
        else
        {
            return "";
        }
    }

}
