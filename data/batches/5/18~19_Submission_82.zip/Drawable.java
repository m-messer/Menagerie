import java.awt.Color;

/**
 * An interface for objects that can be drawn on the grid.
 * @version 1.0
 */

public interface Drawable {     
    public Color getDrawColor();
    public Location getLocation();
}
    