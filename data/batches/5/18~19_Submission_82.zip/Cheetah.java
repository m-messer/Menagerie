import java.util.List;
import java.util.Iterator;
import java.awt.Color;

/**
 * A class representing the shared characteristics of Cheetahs.
 * Cheetahs can move, breed, eat an die.
 *
 * @version 1.0
 */
public class Cheetah extends Animal
{
    // Characteristics shared by all Cheetahs (class variables)
    // Age at which a Cheetahs can star to breed.
    private static int BREEDING_AGE = 30;
    // Age to which a Cheetahs can live
    private static int MAX_AGE=400;
    // Likelihood of a Cheetahs breeding.
    private static double BREEDING_PROBABILITY = 0.001;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit.
    private static final int RABBIT_FOOD_VALUE = 15;
    // The food value of a single fox.
    private static final int FOX_FOOD_VALUE = 9;
    // The color the Cheetah will appear on the grid.
    private static final Color COLOR = Color.BLACK;

    /**
     * Construct a Lion. A lion can be created as a new born (age zero and zero hunger)
     * or with a random age and food level.
     */
    public Cheetah(boolean randomAge, Field field, Location location, boolean infected)
    {
        super(field, location, infected);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            setFoodLevel(getRandom().nextInt(RABBIT_FOOD_VALUE + FOX_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(RABBIT_FOOD_VALUE + FOX_FOOD_VALUE);
        }
    }
    
        /**
     * This is what the animal does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Actor> newAnimals, int step)
    {
        // Test if time is night or not.
        boolean nightTime = step % 24 < 5 || step % 24 > 20;
        incrementAge();
        incrementHunger();
        incrementInfection(); 
        // If the time is between 10pm and 5am, 
        if(isActive()) {          
           giveBirth(newAnimals);
            // Try to move into a free location.
           if (nightTime) {
               Location newLocation = findFood();
               if(newLocation == null) {
                    newLocation = getField().freeAdjacentLocation(getLocation());
               }
               // See if it was possible to move.
               if (newLocation != null) {
                   setLocation(newLocation);
               }
               else {
                    // Overcrowding.
                    setDead();
                    return;
               }
            }
        }
    }
    
    /**
     * All Cheetahs will share the same colour on the grid.
     * @return The color the Cheetahs will be drawn as.
     */
    public Color getDrawColor() {
        return COLOR;
    }
    
    /**
     * Look for only rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {        
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isActive()) {
                    rabbit.setDead();
                    setFoodLevel(RABBIT_FOOD_VALUE);
                    return where;
                }
            }
            if(animal instanceof Fox) {
                Fox fox = (Fox) animal;
                if(fox.isActive()) {
                    fox.setDead();
                    setFoodLevel(FOX_FOOD_VALUE);
                    return where;
                }
            }
        }  
        return null;
    }
    
    /**
     * Calls the Cheetah constructor to make a new Rabbit.
     * Implementation of createAnimal that is declared in the abstract Animal class.
     * This allows for findFood to be implemented in the abstract Animal class.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location) {
        return new Cheetah(randomAge, field, location, false);
    }
    
    /**
     * A cheetah has a certain chance of breeding every step.
     * @return The probability a cheetah will breed.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A cheetah give birth up to a certain amount of rabbits
     * on every turn.
     * @return The maximum number of cheetahs that can be birthed.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return The age at which the Lion can begin to breed.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * returns the max age of this class of animal
     * @return max age.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }
}