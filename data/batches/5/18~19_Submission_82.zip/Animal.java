import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * An abstract class representing shared characteristics of animals.
 *
 * @version 1.0
 */

public abstract class Animal extends Organism
{
    // The animal's gender
    private boolean isMale;
    // Animal's infection status
    private boolean isInfected;
    // Time the animal has been infected
    protected int timeInfected;
    // Time an animal can survive with infection
    protected static final int SURVIVAL_TIME_WITH_INFECTION = 10;
    // Animal's age
    private int age;
    // The animal's food level
    private int foodLevel;
    // Chance the disease will spread to neighbouring animals
    protected static final double SPREAD_DISEASE_PROBABILITY = 0.3;
                
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, boolean infected)
    {
        super(field, location);
        this.isMale = getRandom().nextBoolean();
        this.timeInfected = 0;
        this.isInfected = infected;
    }
        
    abstract protected Animal createAnimal(boolean randomAge, Field field, Location location);
    
    abstract protected int getBreedingAge();
    
    abstract protected double getBreedingProbability();
    
    abstract protected int getMaxAge();
    
    abstract protected int getMaxLitterSize();
    
    abstract protected Location findFood();
       
    /**
     * This is what the animal does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Actor> newAnimals, int step)
    {
        incrementAge();
        incrementHunger();
        if (isInfected()) {
            incrementInfection();
        }
        // If the time is between 10pm and 5am, 
        if(isActive()) {          
           giveBirth(newAnimals);
            // Try to move into a free location.
           Location newLocation = findFood();
           if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
           }
           // See if it was possible to move.
           if (newLocation != null) {
               setLocation(newLocation);
           }
           else {
                // Overcrowding.
                setDead();
                return;
           }
        }
    }
    
    /**
     * All animals share the behaviour of being able to give brith
     * to new animals in the free adjacent locations.
     * For animals to give birth they need to meet an animal
     * of the same species and opposite gender.
     */
    protected void giveBirth(List<Actor> newAnimals) {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal != null) {
                if(this.getClass().equals(animal.getClass())) {
                    if (genderCompatible(this, (Animal) animal)) {
                        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            newAnimals.add(createAnimal(false, field, loc));
                            // Rabbit can only give birth once per act
                            return;
                        }
                    }
                }
            }
        } 
    }
    
    /** 
     * Checks whether two animals are of the opposite gender.
     * @return Whether they can breed.
     * @param A first animal to be compared
     * @param B second animal to be compared
     */
    protected boolean genderCompatible(Animal A, Animal B)
    {
        if (A.isMale() != B.isMale()) {
            return true;
        }
        else {
            return false;
        }
    }
              
    /**
     * Increases the hunger of the animal (by lowering its food level by 1).
     * If its food level reaches 0, the bear animal die. :[
     */
    protected void incrementHunger()
    {
        setFoodLevel(getFoodLevel() - 1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }   
    
    /**
     * An animal can produce a certain number of births each time it acts,
     * depending on its maximum litter size and breeding probability.
     * @return The number of births the animal will produce.
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && getRandom().nextDouble() <= getBreedingProbability()) {
            births = getRandom().nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Animals are able to breed once they mature.
     * @return If current is valid for breeding.
     */
    private boolean canBreed() {
        return getAge() >= getBreedingAge();
    }
    
    /**
     * If an animal is infected, on each act it will have the potential to spread the infection.
     * If an animal carries the infection for a certain number of days, itw will die.
     */
    protected void incrementInfection() {
        ++timeInfected;
        if (timeInfected > SURVIVAL_TIME_WITH_INFECTION) {
            setDead();
        }
        else if (getRandom().nextDouble() <= getSpreadDiseaseProbability() && timeInfected > 1) {
            spreadInfection();
        }            
    }
    
    /**
     * Sets the food level of the animal to a user-specified value.
     * @param The new food level.
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }
    
    /**
     * @return The animal's current food level.
     */
    protected int getFoodLevel() {
        return foodLevel;
    }
    
    protected double getSpreadDiseaseProbability() {
        return SPREAD_DISEASE_PROBABILITY;
    }
    
    /**
     * Infects the animal.
     */
    protected void infect() {
        isInfected = true;
    }
    
    /**
     * An animal with an infection may die or spread the infection.
     * @returns Whether this animal is infected.
     */
    public boolean isInfected() { 
        return isInfected; 
    }
    
    /**
     * @returns Whether this animal is Male.
     */
    public boolean isMale() { 
        return isMale; 
    }
    
    /**
     * On each act, an animal with the infection has the potential to spread the infection.
     * Adjacent locations are checked for objects, if that object is an animal
     * it is infected.
     */
    protected void spreadInfection() {
        if (isActive()) {
            getField().adjacentLocations(getLocation());
            if (getField().adjacentLocations(getLocation()) != null) {
                List<Location> adjacent = getField().adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object obj = getField().getObjectAt(where);
                    if(obj instanceof Animal) {
                        Animal animal = (Animal) obj;
                        if(animal.isActive()) {
                            animal.infect();
                        }
                    }
                }
            }
        }
    }
}
