import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.awt.Color;

/**
 * A class representing shared characteristics of Rabbits.
 * Rabbits can age, move, breed, and die.
 *
 * @version 1.0
 */

    public class Rabbit extends Animal {
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a rabbit breeding
    private static final double BREEDING_PROBABILITY = 0.42;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // food value received from grass
    private static final int GRASS_FOOD_VALUE = 7;
    // The color the Rabbit will appear on the grid.
    private static final Color COLOR = Color.ORANGE;
            
    
    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location, boolean infected)
    {
        super(field, location, infected);
        setAge(0);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
        }
        setFoodLevel(GRASS_FOOD_VALUE);
        field.adjacentLocations(getLocation());
    }
    
    /**
     * All Rabbits will share the same colour on the grid.
     * @return The color the Rabbits will be drawn as.
     */
    public Color getDrawColor() {
        return COLOR;
    }
    
    /**
     * Calls the Rabbit constructor to make a new Rabbit.
     * Implementation of createAnimal that is declared in the abstract Animal class.
     * This allows for findFood to be implemented in the abstract Animal class.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location) {
        return new Rabbit(randomAge, field, location, false);
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */    
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Grass) {
                Grass grass = (Grass) actor;
                if(grass.isActive()) {
                    grass.setDead();
                    setFoodLevel(GRASS_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= BREEDING_PROBABILITY) {
            births = getRandom().nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    protected boolean canBreed() { 
        return getAge() >= BREEDING_AGE; 
    }
    
    /**
     * A rabbit give birth up to a certain amount of rabbits
     * on every turn.
     * @return The maximum number of Rabbits that can be birthed.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * A rabbit has a certain chance of breeding every step.
     * @return The probability a rabbit will breed.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * When Rabbits hit a certain age, they will die.
     * @return The maximum age a Rabbit can live to.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }
    /**
     * @return The minimum age before which a rabbit can breed.
     */
    protected int getBreedingAge() { 
        return BREEDING_AGE; 
    }
}
