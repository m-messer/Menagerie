import java.util.List;


/**
 * A class representing the main characteristics of a Rainstorm.
 *
 * @version 1.0
 */
public class Rainstorm extends Weather
{
    private static final int LENGTH = 300;

    /**
     * Constructor for objects of class Rainstorm
     */
    public Rainstorm(Field field, List<Location> affectedLocations)
    {
        super(field, affectedLocations); 
    }
    
    /**
     * What the Rainstorm does on every turn, sets the rain status
     * of objects at its affected locations to true.
     * @param newActors Actors in the sim passed by reference to be updated.
     * @param nightTime Indicates the time of day.
     */
    public void act(List<Actor> newActors, int step) {
        Field field = getField();
        for (Location location : getAffectedLocations()) {
            Object object = field.getObjectAt(location);
            if (object instanceof Plant) {
                ((Plant)object).setRain(true);
            }
        }
    }
  
}
