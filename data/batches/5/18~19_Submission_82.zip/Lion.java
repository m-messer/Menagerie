import java.util.Random;
import java.util.List;
import java.util.Iterator;
import java.awt.Color;

/**
 * A class representing shared characteristics of Lions.
 * Lions can age, move, breed, and die.
 *
 * @version 1.0
 */
public class Lion extends Animal
{
    // Characteristics shared by all Lion (class variables)
    
    // Age at which a Lion can star to breed.
    private static int BREEDING_AGE = 30;
    // Age to which a Lion can live
    private static int MAX_AGE=400;
    // Likelihood of a Lion breeding.
    private static double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 4;
    // The food value of a single Rabbit
    private static final int RABBIT_FOOD_VALUE = 40;
    // The food value of a single Hunter
    private static final int HUNTER_FOOD_VALUE = 80;
    // The color the Lion will appear on the grid.
    private static final Color COLOR = Color.CYAN;

    /**
     * Construct a Lion. A lion can be created as a new born (age zero and zero hunger)
     * or with a random age and food level.
     */
    public Lion(boolean randomAge, Field field, Location location, boolean infected)
    {
        super(field, location, infected);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            setFoodLevel(getRandom().nextInt(RABBIT_FOOD_VALUE + RABBIT_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(RABBIT_FOOD_VALUE + HUNTER_FOOD_VALUE);
        }
    }
    
    /**
     * All Cheetahs will share the same colour on the grid.
     * @return The color the Cheetahs will be drawn as.
     */
    public Color getDrawColor() {
        return COLOR;
    }
    
    /**
     * Looks for Rabbits and Hunters in the adjacent locations.
     * A Hunter is only eaten if another Lion exists in an adjacent position to the Hunter,
     * In other words it takes 2 Lions surrounding a Hunter to eat a Lion.
     * @return Location where food was found or null if it wasn't.       
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Rabbit)
            {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isActive()) {
                    rabbit.setDead();
                    setFoodLevel(RABBIT_FOOD_VALUE);
                    return where;
                }
            }
            else if (animal instanceof Hunter)
            {
                Hunter hunter = (Hunter) animal;
                Location location = hunter.getLocation();
                List<Location> adjacentLocations = field.adjacentLocations(location);
                adjacentLocations.remove(where);
                for (Location loc : adjacentLocations) {
                    Object animal2 = field.getObjectAt(loc);
                    if (animal2 instanceof Lion) {
                       // check this is a different lion
                       if (animal2 != this) {
                           Lion lion2 = (Lion) animal2;
                           if (lion2.isActive()) {
                               hunter.setDead();
                               setFoodLevel(HUNTER_FOOD_VALUE);
                               return where;
                           }
                       }
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Calls the Lion constructor to make a new Rabbit.
     * Implementation of createAnimal that is declared in the abstract Animal class.
     * This allows for findFood to be implemented in the abstract Animal class.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location) {
        return new Lion(randomAge, field, location, false);
    }
    
    /**
     * A lion has a certain chance of breeding every step.
     * @return The probability a lion will breed.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
        
    /**
     * A Lion give birth up to a certain amount of rabbits
     * on every turn.
     * @return The maximum number of lions that can be birthed.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
        
    /**
     * @return The age at which the Lion can begin to breed.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * When Rabbits hit a certain age, they will die.
     * @return The maximum age a Rabbit can live to.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }
}
