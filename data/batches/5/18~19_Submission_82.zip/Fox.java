import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.awt.Color;

/**
 * A class representing shared characteristics of Foxes.
 * Foxes can age, move, breed, and die.
 *
 * @version 1.0
 */
public class Fox extends Animal
{
    // Characteristics shared by all foxes (class variables).
    
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.04;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 25;
    // The color the Fox will appear on the grid.
    private static final Color COLOR = Color.BLACK;
   
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location, boolean infected)
    {
        super(field, location, infected);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            setFoodLevel(getRandom().nextInt(RABBIT_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(RABBIT_FOOD_VALUE);
        }
    }
    
    /**
     * All foxes will share the same colour on the grid.
     * @return The color the Foxes will be drawn as.
     */
    public Color getDrawColor() {
        return COLOR;
    }
   
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isActive()) { 
                    rabbit.setDead();
                    setFoodLevel(RABBIT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Foxes can only live to only a certain age.
     * @return The maximum age before the fox dies.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }
    
    /** 
     * Rabbits can breed after reaching a certain age.
     * @return The minimum age before which a rabbit can breed.
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Calls the Fox constructor to make a new Rabbit.
     * Implementation of createAnimal that is declared in the abstract Animal class.
     * This allows for findFood to be implemented in the abstract Animal class.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location) {
        return new Fox(randomAge, field, location, false);
    }
    
    /**
     * A Fox has a certain chance of breeding every step.
     * @return The probability a fox will breed. 
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A rabbit give birth up to a certain amount of rabbits
     * on every turn.
     * @return The maximum number of Rabbits that can be birthed.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
}
