import java.util.ArrayList;
import java.util.Random;
import java.util.List;
import java.awt.Color;

/**
 * A class that is used to generate the actors to be be placed on a field
 * for a simulation.
 *
 * @version 1.0
 */
public class MapGenerator
{
    // Constants representing configuration information for the simulation.
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.001; // 0.05
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.82; // 0.35
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.001; // 0.02
    // The probability that a cheetah will be created in any given grid position.
    private static final double CHEETAH_CREATION_PROBABILITY = 0.001; // 0.01
    // The probability that grass will be created at any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.3; // 0.5
    // The probability that a hunter will be created at any given grid position.
    private static final double HUNTER_CREATION_PROBABILITY = 0.008; // 0.001
    // The probability that a newly created animal will carry the infection.
    private static final double ANIMAL_INFECTION_PROBABILITY = 0.0001;
    // The probability a Fog object will be created at any given grid position.
    private static final double FOG_PROBABILITY = 0.0001;
    // The probability a Weather object will be created at any given grid position.
    private static final double RAINSTORM_PROBABILITY = 0.0001;
    // The maximum number of Locations a single Rainstorm object can affect
    private static final int MAX_RAINSTORM_SIZE = 10;
    // The maximum number of Locations a single Fog object can affect
    private static final int MAX_FOG_SIZE = 10;
    // Holds the actors
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // Used to generate random values creation probabilities.
    Random rand;

    /**
     * Constructor for objects of class mapGenerator
     */
    public MapGenerator(Field field, SimulatorView view)
    {
        rand = Randomizer.getRandom();
        actors = new ArrayList<>();
        this.field = field;
        // Create a view of the state of each location in the field.        
    }
    
    /**
     * Try to infect animal according to infection probability
     * @boolean Whether animal should be infected.
     */
    public boolean tryInfectAnimal() {
        return rand.nextDouble() <= ANIMAL_INFECTION_PROBABILITY;
    }
    
    /**
     * Creates the actors according to the static probablity constants and 
     * adds them to the List holding the actors.
     * @return List of the actors created.
     */
    public List<Actor> populate() {        
        actors.clear();
        
        // Iterate through all the positions on the field and check
        // if we should add an animal at this location.
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location, tryInfectAnimal());
                    actors.add(fox);
                    // drawables.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location, tryInfectAnimal());
                    actors.add(rabbit);
                    // drawables.add(rabbit);
                }
                else if (rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location, tryInfectAnimal());
                    actors.add(lion);
                    // drawables.add(lion);
                }
                else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah = new Cheetah(true, field, location, tryInfectAnimal());
                    actors.add(cheetah);
                    // drawables.add(cheetah);
                }
                else if(rand.nextDouble() <= HUNTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hunter hunter = new Hunter(true, field, location);
                    actors.add(hunter);
                    // drawables.add(hunter);
                }
                
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    actors.add(grass);
                }
                // else leave the location empty.            
            }
        }        
        return actors;
    }
    
    /**
     * Generates a map designed for testing the spread of disease.
     * @return The actors generated.
     */
    public List<Actor> populateDiseaseTest()
    {
        actors.clear();
 
        for (int i = 50; i < 60; ++i) {
            for (int j = 50; j < 60; ++j) {
                Rabbit rabbit = new Rabbit(true, field, new Location(i, j), false);
                Fox fox = new Fox(true, field, new Location(i+10, j+10), false);
               if (j==50 && i==50) {
                    fox.infect();
                }
                actors.add(rabbit);
                actors.add(fox);
            }
        }
        
        Rabbit rabbit = new Rabbit(true, field, new Location(4, 4), true);
        actors.add(rabbit);

        return actors;
    }
    
    /**
     * Generates a map designed for testing fog weather and hunters.
     * @return The actors generated.
     */
    public List<Actor> populateFogHunterTest() {
        actors.clear();
        List<Location> affectedLocations = new ArrayList<>();
        for (int i = 5; i < 25; ++i) {
            for (int j = 5; j < 25; ++ j) {
                affectedLocations.add(new Location(i, j));
            }
        }
        Fog fog = new Fog(field, affectedLocations);
        Hunter hunter = new Hunter(true, field, new Location(10, 10));
        Hunter hunter2 = new Hunter(true, field, new Location(50, 50));
        Hunter hunter3 = new Hunter(true, field, new Location(10, 50));
        Hunter hunter4 = new Hunter(true, field, new Location(50, 10));
        Lion lion1 = new Lion(true, field, new Location(13, 13), false);
        Lion lion2 = new Lion(true, field, new Location(53, 53), false);
        Lion lion3 = new Lion(true, field, new Location(10, 51), false);
        Lion lion4 = new Lion(true, field, new Location(50, 11), false);
        Lion lion5 = new Lion(true, field, new Location(50, 9), false);
        
        actors.add(0, fog);
        actors.add(lion1);
        actors.add(lion2);
        actors.add(lion3);
        actors.add(lion4);
        actors.add(lion5);
        actors.add(hunter);
        actors.add(hunter2);
        actors.add(hunter3);
        actors.add(hunter4);
        
        return actors;
    }
    
    /**
     * Generates a map designed for testing the growth of grass with and without the rain..
     * @return The actors generated.
     */
    public List<Actor> populateGrassRainTest() {
        actors.clear();
        List<Location> affectedLocations = new ArrayList<>();
        for (int i = 0; i < 50; ++i) {
            for (int j = 0; j < 50; ++j) {
                affectedLocations.add(new Location(i, j));
            }
        }
        Rainstorm rainstorm = new Rainstorm(field, affectedLocations);
        actors.add(0, rainstorm);
        for (int i = 20; i < 30; ++i) {
            for (int j = 20; j < 30; ++j) {
                if (rand.nextBoolean()) {
                    Grass grass = new Grass(true, field, new Location(i, j));
                    Grass grass2 = new Grass(true, field, new Location(30+i, 55+j));
                    actors.add(grass);
                    actors.add(grass2);
                }
            }
        }

        return actors;
    }
    
    /**
     * Generates a map designed for grass and cheetah behavior in night and day.
     * @return The actors generated.
     */
    public List<Actor> populateTestNightDay() {
        actors.clear();
        for (int i = 20; i < 50; ++i) {
            for (int j = 20; j < 50; ++j) {
                if (rand.nextBoolean()) {
                   if(rand.nextBoolean()) {
                       Grass grass = new Grass(true, field, new Location(i, j));
                       actors.add(grass);
                    }
                    else {
                        Cheetah cheetah = new Cheetah(true, field, new Location(i, j+60), false);
                        actors.add(cheetah);
                    }
                }
            }
        }
        return actors;
    }
    
    /**
     * Adds random weather affects to the actors of a map based on their probabailities
     * @param actors The list of actors to be updated.
     */
    /**
    public void addRandomWeather(List<Actor> actors) {
        if (rand.nextDouble() <= FOG_PROBABILITY) {
            int col = (rand.nextInt(field.getWidth() - MAX_RAINSTORM_SIZE + 1));
            int row = (rand.nextInt(field.getDepth() - MAX_RAINSTORM_SIZE + 1));
            List<Location> affectedLocations = new ArrayList<>();
            for (int i = row; i < row+MAX_RAINSTORM_SIZE; ++i) {
                for (int j = col; j < col+MAX_RAINSTORM_SIZE; ++j) {
                    affectedLocations.add(new Location(i, j));
                }
            Fog fog = new Fog(field, affectedLocations);
            actors.add(0, fog);
            }
        }
    }
    */
    
}
