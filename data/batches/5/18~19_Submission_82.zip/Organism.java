import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of organism.
 *
 * @version 1.0
 */
public abstract class Organism implements Drawable, Actor
{
    // The field the Organism resides in
    private Field field;
    // The location the organism resides in the field
    private Location location;
    // If the animal in the simulation.
    private boolean isActive;
    // How many steps the organism has existed
    private int age;
    // Wheter the organism is affected by the fog Weather effect
    private boolean underFog;

    // Number generator for controlling breeding
    private static final Random randomGen = Randomizer.getRandom();    
    
    // public constructor for organism
    public Organism(Field field, Location location) {
        isActive = true;
        this.field = field;
        setLocation(location);
    }
    
    abstract protected int getMaxAge();
    
    /**
    * @return Whether organism is under fog.
    */
    public boolean isUnderFog() {
        return underFog;
    }
    
    /**
     * If the organism is under fog its behavior may change.
     * @param fog New fog status.
     */
    public void setFog(boolean fog) {
        underFog = fog;
    }   
        
    /**
    * Check whether the animal is alive or not.
    * @return true if the animal is still alive.
    */
    public boolean isActive(){
        return isActive;
    }
    
    /**
    * Organism may use random numbers to determine breeding probabilities.
    * @return Random number generator
    */
    protected Random getRandom()
    {
        return randomGen;
    }
    
    /**
     * Places the organism at a new location in the field it resides in.
     * @param NewLocation The organism' new location.
     */
    public void setLocation(Location newLocation) {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * @return The organism' location.
     */
    public Location getLocation() { return location; }
    
    /**
     * @return The organism' field.
     */
    protected Field getField() { return field; }
    
    /**
    * Returns an animal's current age
    * @return age The current age of an animal
    */    
    protected int getAge() { return age; }
    
    /**
     * @param age Set the current age
     */
    protected void setAge(int age) { this.age = age; }    
    
    /**
     * Increase the age. This could result in death.
     */    
    protected void incrementAge()
    {
        setAge(getAge() + 1);
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */    
    protected void setDead()
    {
        isActive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
}
