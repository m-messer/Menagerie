import java.util.Random;
import java.util.List;
import java.awt.Color;

/**
 * A class representing shared characteristics of Grass.
 * Grass can age, breed and die.
 *
 * @version 1.0
 */
public class Grass extends Plant
{
    // Age after grass can start to breed
    private static final int BREEDING_AGE = 1;
    // How long grass can survive
    private static final int MAX_AGE = 12;
    // The probability that grass will breed
    private static final double BREEDING_PROBABILITY = 0.14; // 0.3
    // The probability that grass will breed under rain
    private static final double BREEDING_PROBABILITY_RAIN = 1;
    // The maximum number of grass births
    private static final int MAX_LITTER_SIZE = 8;
    // The color the Grass will appear on the grid.
    private static final Color COLOR = Color.GREEN;
    
    /**
     * Constructor for objects of class Grass
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setAge(0);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
        }
    }
    
    public Color getDrawColor() {
        return COLOR;
    }
    
    /**
     * What the grass does on each step.
     * If there is rain, the grass will give birth to new grass.
     * @param newGrass A list to return new grass objects
     * @param time Current time of day
     * @param isRaining The current status of rain rain weather
     * @param isFoggy The current status of fog weather
     */
    public void act(List<Actor> newGrass, int step) {
        incrementAge();
        // Test if time is night or not.
        boolean nightTime = step % 24 < 5 || step % 24 > 20;
        if(isActive() && !nightTime) {
            giveBirth(newGrass);
        }
        setRain(false);
    }

    /**
     * Check whether or not the grass is to birth new grass on this step. 
     * New births will be made in free adjacent locations.
     * @param newGrass A list to return newly born grass.
     */
    private void giveBirth(List<Actor> newGrass) {        
        // New grass are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
        
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;        
        if(canBreed() && getRandom().nextDouble() <= getBreedingProbability()) {
            births = getRandom().nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * On each act the grass has a probability of breeding, which differs
     * depending on whether the grass is under rain or not.
     * @return The probability the grass will breed on this act.
     */
    protected double getBreedingProbability() {
        if (isUnderRain()) {
            return BREEDING_PROBABILITY_RAIN;
        }
        else {
            return BREEDING_PROBABILITY;
        }
    }
    
    /**
     * A grass can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    protected boolean canBreed() { return getAge() >= BREEDING_AGE; }
    
    /**
     * @return int The maximum age that grass can live
     */
    protected int getMaxAge() { return MAX_AGE; }
}
