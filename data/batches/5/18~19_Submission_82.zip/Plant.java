/**
 * A class representing shared characteristics of Plants.
 * Plants can age, breed, die and have their behaviour changed by rain.
 *
 * @version 1.0
 */

public abstract class Plant extends Organism
{
    private boolean underRain;
       
    public Plant(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * If the Plant is under rain its behavior may change.
     * @param rain New rain status.
     */
    public void setRain(boolean rain) {
        underRain = rain;
    }
    
    /**
    * @return Whether a plant is under rain.
    */
    public boolean isUnderRain() {
        return underRain;
    }
    
    
}
