import java.util.List;
import java.util.Iterator;
import java.awt.Color;

/**
 * An abstract class representing shared characteristics of a Hunter.
 *
 * @version 1.0
 */
public class Hunter extends Organism
{
    // The age to which a Hunter can live
    private static final int MAX_AGE = 9999;
    // Maximum distance a target can be for a Hunter to kill
    private static final int NORMAL_RANGE = 4;
    // Maximum distance a target can be for a Hunter to kill whilst under fog
    private static final int FOG_RANGE = 1;
    
    private static final Color COLOR = Color.MAGENTA;

    /**
     * Constructor for objects of class Hunter
     */
    public Hunter(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setAge(0);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
        }
    }
    
    /**
     * All hunters will share the same colour on the grid.
     * @return The color the hunters will be drawn as.
     */
    public Color getDrawColor() {
        return COLOR;
    }
    
    /**
     * This is what the Hunter does most of the time - it runs 
     * around. Sometimes it will attack or die of old age.
     * @param newActors A list to return any new actors
     */
    public void act(List<Actor> newActors, int step) {
        incrementAge();
        if (isActive()) {
            Location newLocation;
            
            if (isUnderFog()) {
                findTarget(FOG_RANGE);
            }
            else {
                findTarget(NORMAL_RANGE);
            }
            
            newLocation = getField().freeAdjacentLocation(getLocation());
            
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            }
            
        }
        setFog(false);
    }
    
    /**
     * The Hunters carry rifles and can shoot any animal that is a given range away.
     * 
     */
    public void findTarget(int range) {
        Field field = getField();
        List<Location> adjacent = field.getNearbyLocations(getLocation(), range, range);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if (actor instanceof Animal)
            {
                Animal animal = (Animal) actor;
                if (animal.isActive()) {
                    animal.setDead();
                }
            }
        }    
    }   
    
    /**
     * When Rabbits hit a certain age, they will die.
     * @return The maximum age a Rabbit can live to.
     */
    public int getMaxAge() { return MAX_AGE; }

}
    
    
    
    

