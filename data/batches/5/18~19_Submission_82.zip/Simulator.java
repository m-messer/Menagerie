import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that it will start raining
    private static final double RAIN_PROBABILITY = 0.4;
    // The probability that it will become foggy
    private static final double FOG_PROBABILITY = 0.3;
    // The amount of time fog will last
    private static final int FOG_LENGTH = 100;
    // The amount of time rain will last
    private static final int RAIN_LENGTH = 200;
    
    // used to fill field with actors
    MapGenerator mapGen;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Track the time of day
    private int time;
    // Track the simulation
    private int sim;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }    
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // Create a view of the state of each location in the field and set simulation
        field = new Field(depth, width);                
        view = new SimulatorView(depth, width);
        mapGen = new MapGenerator(field, view);
        // for reset
        sim = 5;
              
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Constructor for test simulations
     * @param n Integer for which test simulation to use.
     */
    public Simulator(int n)
    {
        // Create a view of the state of each location in the field.
        field = new Field(DEFAULT_DEPTH, DEFAULT_WIDTH);                
        view = new SimulatorView(DEFAULT_DEPTH, DEFAULT_WIDTH);
        mapGen = new MapGenerator(field, view);
        sim = n;
        // Choose one of the test simulations
        actors = selectSimulation(n);           
        view.act(actors, step);
        view.showStatus(step, field);
    }
    
    /**
     * Choose which simulation we want
     * @return List of actors to return after generating map
     */
    private List<Actor> selectSimulation(int n) {
        switch (n) {
            case 1: actors = mapGen.populateDiseaseTest();
                    break;
            case 2: actors = mapGen.populateFogHunterTest();
                    break;
            case 3: actors = mapGen.populateGrassRainTest();
                    break;
            case 4: actors = mapGen.populateTestNightDay();
                    break;
            case 5: actors = mapGen.populate();
                    break;
        }
        return actors;
    }  
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        //  && view.isViable(field)
        for(int step = 1; step <= numSteps; step++) {
            simulateOneStep();
            delay(30);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * actor.
     */
    public void simulateOneStep()
    {        
        step++;
        time++;
        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<Actor>();

        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors, step);
            if(!actor.isActive()) {
                it.remove();
            }
        }
                
        actors.addAll(newActors);        
        view.act(actors, step);        
        view.showStatus(step, field);
    }
                   
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        time = 0;
        actors = selectSimulation(sim);
        
        // Show the starting state in the view.
        view.act(actors, 0);
        view.showStatus(step, field);
    }
            
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
