import java.util.List;
import java.util.Random;

/**
 * An interface for objects that have an action every step.
 * @version 1.0
 */
public interface Actor
{
    /**
    * Make this actor act - that is: make it do
    * whatever it wants/needs to do.
    * @param newActors A list to receive newly born animals.
    */
    public void act(List<Actor> newActors, int step);
    
    public boolean isActive();
}
