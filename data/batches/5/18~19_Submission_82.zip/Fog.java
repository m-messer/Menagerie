import java.util.List;

/**
 * A class representing the main characteristics of Fog.
 *
 * @version 1.0
 */
public class Fog extends Weather
{
    /**
     * Constructor for objects of class Fog
     */
    public Fog(Field field, List<Location> affectedLocations)
    {
        super(field, affectedLocations); 
    }

    /**
     * What the Fog does on every turn, sets the rain status
     * of objects at its affected locations to true.
     * @param newActors Actors in the sim passed by reference to be updated.
     * @param nightTime Indicates the time of day.
     */
    public void act(List<Actor> newActors, int step) {
        Field field = getField();
        for (Location location : getAffectedLocations()) {
            Object object = field.getObjectAt(location);
            if (object instanceof Organism) {
                ((Organism)object).setFog(true);
            }
        }
    }
}
