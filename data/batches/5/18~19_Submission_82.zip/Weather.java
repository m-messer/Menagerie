import java.util.List;


/**
 * An abstract class representing shared characteristics of weather objects.
 *
 * @version 1.0
 */
abstract public class Weather implements Actor
{
    private Field field;
    private List<Location> affectedLocations;
    private int day;
    private boolean active;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather(Field field, List<Location> affectedLocations)
    {
        this.field = field;
        this.affectedLocations = affectedLocations;
        this.active = true;
    }
    
    /**
     * @return The weather's field
     */
    protected Field getField() {
        return field;
    }
    
    /**
     * @return The weather's affeccted locations
     */
    protected List<Location> getAffectedLocations() {
        return affectedLocations;
    }
    
    /**
     * @return Whether the weather effect is active
     */
    public boolean isActive() {
        return active;
    }
}
