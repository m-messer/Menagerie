import java.util.List;
import java.util.Random;

public class Plant extends Animal {

    // The age at which a plant can start to breed.
    private static final int BREEDING_AGE = Integer.valueOf(Configurations.getInstance().get("plant.breeding_age"));
    // The age to which a plant can live.
    private static final int MAX_AGE = Integer.valueOf(Configurations.getInstance().get("plant.max_age"));
    // The likelihood of a plant breeding(spreading).
    private static final double BREEDING_PROBABILITY = Double.valueOf(Configurations.getInstance().get("plant.breeding_probability"));
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = Integer.valueOf(Configurations.getInstance().get("plant.max_litter_size"));

    private static final Random rand = Randomizer.getRandom();

    //Determines whether the plant has spread yet
    private boolean hasSpread;

    public Plant(boolean randomAge, Field field, Location location, boolean gender) {
        super(field, location, BREEDING_AGE, MAX_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY, gender, randomAge);
    }

    @Override
    public void act(List<Animal> newAnimals) {
        incrementAge();
        if (isAlive()) {

            //Checks whether a specific plant object as spread yet. If so then it stops making new ones
            if (!hasSpread) {
                giveBirth(newAnimals);
                //The plants spread doubly as fast in the sun
                if (getField().getCurrentWeather() == Field.Weather.SUN) giveBirth(newAnimals);
            }

            //plants dont move or eat

        }
    }

    protected void giveBirth(List<Animal> newPlants) {
        // Animal class' giveBirth is overriden to change the implementation to one which does not check for mates
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        //if (!suitableMate()) return; Not needed because plants do not need a mate to grow
        int births = breed();

        for (int b = 0; b < births && free.size() > 0; b++) {

            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc, rand.nextBoolean());
            newPlants.add(young);
        }
        hasSpread = true;
    }
}
