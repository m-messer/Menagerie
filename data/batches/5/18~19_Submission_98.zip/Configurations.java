import java.io.*;
import java.util.Properties;

public class Configurations {

    public static final String CONFIG_FILE_NAME = "config.properties";
    //Stores a map of a properties file
    public static final Properties properties = new Properties();
    //Class designed for singleton model. Only one instance of Configuration allowed so the same Simulator can't have
    //multiple configurations if the file is changed.
    private static Configurations instance;

    /**
     * Constructor is private so the Configuration instance can only be made with getInstance()
     * Opens the file to load the properties into memory
     */
    private Configurations() {
        InputStream inputStream;
        try {
            inputStream = new FileInputStream(CONFIG_FILE_NAME);
            properties.load(inputStream);
            inputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Creates an instance if it does not exist
     *
     * @return the current instance of the properties class
     */
    public static Configurations getInstance() {
        if (instance == null) {
            instance = new Configurations();
        }
        return instance;
    }

    /**
     * A getter to access the internal properties map
     *
     * @param key
     * @return the value in the properties map for the specified key
     */
    public String get(String key) {
        return properties.getProperty(key);

    }

    /**
     * Opens the properties file to be edited and adds or replaces the key value pair that is specified
     *
     * @param key
     * @param value
     */
    public void set(String key, String value) {

        properties.setProperty(key, value);

        OutputStream outputStream;
        try {
            outputStream = new FileOutputStream(CONFIG_FILE_NAME);
            properties.store(outputStream, null);
            outputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
