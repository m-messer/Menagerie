import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Fish extends InfectableAnimal {

    // The age at which a fish can start to breed.
    private static final int BREEDING_AGE = Integer.valueOf(Configurations.getInstance().get("fish.breeding_age"));
    // The age to which a fish can live.
    private static final int MAX_AGE = Integer.valueOf(Configurations.getInstance().get("fish.max_age"));
    // The likelihood of a fish breeding.
    private static final double BREEDING_PROBABILITY = Double.valueOf(Configurations.getInstance().get("fish.breeding_probability"));
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = Integer.valueOf(Configurations.getInstance().get("fish.max_litter_size"));
    private static final Random rand = Randomizer.getRandom();

    //The map of what animals this animal can eat and what food value is attributed to that food
    private static final HashMap<Class, Integer> FISH_PREY = new HashMap<Class, Integer>() {{
        put(Krill.class, 10);

    }};

    public Fish(boolean randomAge, Field field, Location location, boolean gender) {
        super(field, location, BREEDING_AGE, MAX_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY, gender, randomAge);
        setPrey(FISH_PREY);
        setFoodLevel(5);
    }

    @Override
    public void act(List<Animal> newAnimals) {

        //As an infectable animal, they need to spread the infection and get closer to dying each step
        if (isInfected() && isAlive()) {
            spread();
            decrementTimer();
        }

        incrementAge();
        incrementHunger();

        if (isAlive()) {
            //Fish are an infectable animal so they have a random chance to infect other animals. This chance
            //is also doubled in a storm
            if ((rand.nextDouble() <= INFECTION_PROBABILITY * (getField().getCurrentWeather() == Field.Weather.STORM ? 2 : 1))) {
                infect();
            }
            if (!isInfected()) giveBirth(newAnimals);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location

                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);

            } else {
                // Overcrowding.
                setDead();
            }
        }
    }


}
