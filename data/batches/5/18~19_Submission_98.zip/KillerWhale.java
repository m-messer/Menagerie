import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class KillerWhale extends Animal {

    // The age at which a killer whale can start to breed.
    private static final int BREEDING_AGE = Integer.valueOf(Configurations.getInstance().get("killerwhale.breeding_age"));
    // The age to which a killer whale can live.
    private static final int MAX_AGE = Integer.valueOf(Configurations.getInstance().get("killerwhale.max_age"));
    // The likelihood of a killer whale breeding.
    private static final double BREEDING_PROBABILITY = Double.valueOf(Configurations.getInstance().get("killerwhale.breeding_probability"));
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = Integer.valueOf(Configurations.getInstance().get("killerwhale.max_litter_size"));

    //The map of what animals this animal can eat and what food value is attributed to that food
    private static final HashMap<Class, Integer> WHALE_PREY = new HashMap<Class, Integer>() {{
        put(Fish.class, 10);
        put(Penguin.class, 20);
    }};

    public KillerWhale(boolean randomAge, Field field, Location location, boolean gender) {
        super(field, location, BREEDING_AGE, MAX_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY, gender, randomAge);
        setPrey(WHALE_PREY);
        setFoodLevel(5);
    }

    @Override
    public void act(List<Animal> newAnimals) {
        incrementAge();
        //Killer Whales do not get hungry after 18:00
        if (isAlive()) {
            if (!(getField().getSimulator().getTime() > 18)) {
                incrementHunger();
            }
        }
        //Separate if statements as isAlive() may have changed
        if (isAlive()) {
            giveBirth(newAnimals);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }


}
