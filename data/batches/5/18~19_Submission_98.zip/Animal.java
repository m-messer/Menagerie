import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal {
    private static final Random rand = Randomizer.getRandom();

    // The animals's food level, which is increased by eating its prey.
    private int foodLevel;
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's age.
    private int age;
    // The age at which a fox can start to breed.
    private final int breedingAge;
    // The age to which a fox can live.
    private final int maxAge;
    // The likelihood of a fox breeding.
    private final double breedingProbability;
    // The maximum number of births.
    private final int maxLitterSize;
    // Gender of animal - true for male, false for female
    private final boolean gender;
    //List containing all prey for each animal
    private Map<Class, Integer> prey;
    /**
     * Create a new animal at location in field.
     *
     * @param field               The field currently occupied.
     * @param location            The location within the field.
     * @param breedingAge         The minimum age of breeding
     * @param maxAge              The max age before the animal dies
     * @param maxLitterSize       The max number of births per step
     * @param breedingProbability The probability of breeding
     * @param gender              The gender male - true, female - false
     * @param randomAge           whether the animal created starts with a random age or not
     */
    public Animal(Field field, Location location, int breedingAge, int maxAge, int maxLitterSize, double breedingProbability, boolean gender, boolean randomAge) {
        alive = true;
        this.field = field;
        setLocation(location);
        this.breedingAge = breedingAge;
        this.maxAge = maxAge;
        this.breedingProbability = breedingProbability;
        this.maxLitterSize = maxLitterSize;
        this.gender = gender;
        this.prey = new HashMap<>();
        this.age = randomAge ? rand.nextInt(maxAge-10) : 0;

    }



    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getFoodLevel() {
        return foodLevel;
    }

    public void setFoodLevel(int foodLevel) {
        this.foodLevel = foodLevel;
    }

    /**
     * Increase the age. This could result in the fox's death.
     */
    protected void incrementAge() {
        age++;
        if (age > maxAge) {
            setDead();
        }
    }

    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     *
     * @return true if the animal is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     *
     * @return The animal's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     *
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's gender.
     *
     * @return The animal's gender.
     */
    protected boolean getGender() {
        return gender;
    }

    /**
     * Return the animal's field.
     *
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Checks adjacent locations for animal objects and if these are prey for this object then kill the prey
     * and set the new food value depending on the prey and move to the prey's location
     *
     * @return location to move to
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Animal) {
                Animal prey = (Animal) animal;
                int foodValue = canEat(prey);
                //If the returned foodValue is 0 then no valid prey was found
                if (foodValue != 0) {
                    if (prey.isAlive()) {
                        prey.setDead();
                        foodLevel = foodValue;
                        return where;
                    }
                }

            }
        }
        return null;
    }


    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && (rand.nextDouble() <= breedingProbability)) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     */
    private boolean canBreed() {
        return age >= breedingAge;
    }

    /**
     * Check adjacent locations for Animal objects
     *
     * @return A list of adjacent animals
     */
    protected List<Animal> getAdjacentAnimals() {
        List<Animal> animals = new ArrayList<>();
        for (Location l : getField().adjacentLocations(location)) {
            Object animal = getField().getObjectAt(l);
            if (animal == null) break;
            if (animal instanceof Animal) {
                animals.add((Animal) animal);
            }
        }
        return animals;
    }

    /**
     * Checks whether any adjacent animals are the same species and opposite genders
     *
     * @return a boolean represent whether there is a mate or not
     */
    protected boolean suitableMate() {
        for (Animal animal : getAdjacentAnimals()) {
            if ((this.getClass().equals(animal.getClass())) && (this.getGender() != animal.getGender())) {
                return true;
            }
        }
        return false;
    }


    /**
     * Checks against the current Animal objects prey Hashmap to see if the adjacent prey can be eaten by this animal
     *
     * @param prey the possible prey animal object
     * @return the foodValue of the animal
     */
    protected int canEat(Animal prey) {

        for (Map.Entry<Class, Integer> entry : getPrey().entrySet()) {
            if (entry.getKey().equals(prey.getClass())) {
                //System.out.println(this.getClass() + " eats " + prey.getClass());
                return entry.getValue();
            }
        }
        return 0;
    }

    /**
     * Getter for the prey map
     *
     * @return the instances prey map
     */
    public Map<Class, Integer> getPrey() {
        return prey;
    }

    /**
     * Sets the Animals prey. Must be used in subclasses constuctor
     *
     * @param prey the map of prey to food value
     */
    public void setPrey(Map<Class, Integer> prey) {
        this.prey = prey;
    }

    /**
     * Checks for free adjacent locations and then if possible breeds and creates new Animals of the same species
     * and puts them in adjacent locations.
     *
     * @param newAnimals the list to put the new Animal objects in
     */
    protected void giveBirth(List<Animal> newAnimals) {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        int births = breed();
        if (!suitableMate()) return;
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = null;
            try {
                //Dynamically gets the constructor for the current animal and creates the object
                young = this.getClass()
                        .getConstructor(boolean.class, Field.class, Location.class, boolean.class)
                        .newInstance(false, field, loc, rand.nextBoolean());
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
                System.err.println("Exception in constructor");
                e.getCause().printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
                System.err.println(this.getClass() + " constructor not defined properly");
            }
            newAnimals.add(young);
        }
    }
}
