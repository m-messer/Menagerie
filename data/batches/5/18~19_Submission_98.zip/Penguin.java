import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Penguin extends Animal {

    // The age at which a penguin can start to breed.
    private static final int BREEDING_AGE = Integer.valueOf(Configurations.getInstance().get("penguin.breeding_age"));
    // The age to which a penguin can live.
    private static final int MAX_AGE = Integer.valueOf(Configurations.getInstance().get("penguin.max_age"));
    // The likelihood of a penguin breeding.
    private static final double BREEDING_PROBABILITY = Double.valueOf(Configurations.getInstance().get("penguin.breeding_probability"));
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = Integer.valueOf(Configurations.getInstance().get("penguin.max_litter_size"));

    //The map of what animals this animal can eat and what food value is attributed to that food
    private static final HashMap<Class, Integer> PENGUIN_PREY = new HashMap<Class, Integer>() {{
        put(Fish.class, 10);
        put(Crab.class, 20);
    }};

    public Penguin(boolean randomAge, Field field, Location location, boolean gender) {
        super(field, location, BREEDING_AGE, MAX_AGE, MAX_LITTER_SIZE, BREEDING_PROBABILITY, gender, randomAge);
        setPrey(PENGUIN_PREY);
        setFoodLevel(5);

    }

    @Override
    public void act(List<Animal> newAnimals) {
        incrementAge();
        incrementHunger();

        if (isAlive()) {

            giveBirth(newAnimals);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
                //Penguins get doubly as hungry when its sunny
                if (getField().getCurrentWeather() == Field.Weather.SUN) incrementHunger();
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

}
