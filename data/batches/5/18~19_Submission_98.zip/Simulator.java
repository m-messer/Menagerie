import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.*;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing underwater creatures
 *
 * @version 2016.02.29 (2)
 */

public class Simulator {
    // Constants representing configuration information for the simulation.
    //The length of a day
    public static final int DAY_LENGTH = Integer.valueOf(Configurations.getInstance().get("day_length"));
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 250;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    //Map holding the probabilties for each animal to be in the initial population
    private static final HashMap<Class, Double> CREATION_PROBABILTIES = new HashMap<Class, Double>() {{
        put(Plant.class, Double.valueOf(Configurations.getInstance().get("plant.creation_probability")));
        put(KillerWhale.class, Double.valueOf(Configurations.getInstance().get("killerwhale.creation_probability")));
        put(Penguin.class, Double.valueOf(Configurations.getInstance().get("penguin.creation_probability")));
        put(Fish.class, Double.valueOf(Configurations.getInstance().get("fish.creation_probability")));
        put(Crab.class, Double.valueOf(Configurations.getInstance().get("crab.creation_probability")));
        put(Krill.class, Double.valueOf(Configurations.getInstance().get("krill.creation_probability")));

    }};
    //Random object for random chance effects
    private static final Random rand = Randomizer.getRandom();
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;


    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {

        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width, this);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        //view.setColor(Rabbit.class, Color.ORANGE);
        //view.setColor(Fox.class, Color.BLUE);
        view.setColor(KillerWhale.class, Color.BLUE);
        view.setColor(Crab.class, Color.ORANGE);
        view.setColor(Fish.class, Color.CYAN);
        view.setColor(Krill.class, Color.PINK);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Penguin.class, Color.BLACK);


        // Setup a valid starting point.
        reset();
    }

    public static void main(String[] args) {
        Simulator simulator = new Simulator();
        System.out.println(simulator.simulateTillFinish());

    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();

            //delay(500);   // uncomment this to run more slowly
        }

        //Closes the window for the simulation and ends the program after the simulation is no longer viable

        /*if(!view.isViable(field)){
            view.setVisible(false);
            view.dispose();
        }*/
    }

    /**
     * Runs the simulation from its current step until the simulation is no longer viable
     *
     * @return number of steps that have occured
     */
    public int simulateTillFinish() {
        while (view.isViable(field)) {
            simulateOneStep();
            delay(500);              //Uncomment to run slowly
        }
        if(!view.isViable(field)){
            view.setVisible(false);
            view.dispose();
        }
        return step;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep() {
        step++;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Let all animals act.
        for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if (!animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals
        animals.addAll(newAnimals);
        simulateWeather();

        //Updates the simulator view
        view.showStatus(step, getTime(), field);
    }

    /**
     * Simulates the random chances for weather to occur in
     */
    private void simulateWeather() {
        field.decrementWeatherTimer();
        //Random chance for a weather effect to be set
        if (rand.nextDouble() <= 0.005) {
            field.setWeatherEffect(Field.Weather.SUN, 50);
        } else if (rand.nextDouble() <= 0.05) {
            field.setWeatherEffect(Field.Weather.STORM, 50);
        }
        //Sets weather back to normal after the weather timer is 0
        if (field.getWeatherTimer() <= 0) {
            field.setCurrentWeather(Field.Weather.NONE);
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, getTime(), field);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                //For each location the CREATION_PROBABILITIES map is iterated over to check for the random chance to populate the current location with a specific animal
                for (Map.Entry<Class, Double> entry : CREATION_PROBABILTIES.entrySet()) {
                    if (rand.nextDouble() <= entry.getValue()) {
                        Location location = new Location(row, col);

                        try {
                            //Dynamically gets the constructor for the current animal and creates the object
                            Animal animal = (Animal) entry.getKey()
                                    .getConstructor(boolean.class, Field.class, Location.class, boolean.class)
                                    .newInstance(true, field, location, rand.nextBoolean());
                            animals.add(animal);
                            break;
                        } catch (InstantiationException e) {
                            e.printStackTrace();
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        } catch (InvocationTargetException e) {
                            e.printStackTrace();
                            System.err.println("Exception in constructor");
                            e.getCause().printStackTrace();
                        } catch (NoSuchMethodException e) {
                            e.printStackTrace();
                            System.err.println(entry.getKey() + " constructor not defined properly");
                        }
                    }
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Formats current step to a 24 hour time
     *
     * @return The current hour as an int
     */
    public int getTime() {
        double time = ((((double) step % DAY_LENGTH)) / DAY_LENGTH) * 24;
        return (int) time;
    }

    /**
     * Gets the current day
     *
     * @return The current day as an int
     */
    public int getDay() {
        return step / DAY_LENGTH;
    }


}
