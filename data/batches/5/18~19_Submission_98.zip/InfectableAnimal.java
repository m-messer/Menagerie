import java.util.Random;


public abstract class InfectableAnimal extends Animal {
    private static final Random rand = Randomizer.getRandom();
    //Probabilities of spreading and infection
    static final double INFECTION_PROBABILITY = Double.valueOf(Configurations.getInstance().get("infection_probability"));
    static final double SPREAD_PROBABILITY = Double.valueOf(Configurations.getInstance().get("spread_probability"));
    //timer till death
    private int infectionTimer = 0;
    //boolean representing whether the animal is infected or not
    private boolean infected = false;

    /**
     * Create a new infectable animal at location in field.
     *
     * @param field               The field currently occupied.
     * @param location            The location within the field.
     * @param breedingAge         The minimum age of breeding
     * @param maxAge              The max age before the animal dies
     * @param maxLitterSize       The max number of births per step
     * @param breedingProbability The probability of breeding
     * @param gender              The gender male - true, female - false
     * @param randomAge           whether the animal created starts with a random age or not
     */
    public InfectableAnimal(Field field, Location location, int breedingAge, int maxAge, int maxLitterSize, double breedingProbability, boolean gender, boolean randomAge) {
        super(field, location, breedingAge, maxAge, maxLitterSize, breedingProbability, gender, randomAge);
    }


    /**
     * Set this animal to have the infection
     */
    public void infect() {
        infectionTimer = 5;
        infected = true;

    }


    /**
     * decrements the timer every step pushing it closer to death
     */
    protected void decrementTimer() {
        if (infectionTimer > 0) {
            infectionTimer -= 1;
        }
        if (infectionTimer == 0) {
            setDead();
        }
    }

    /**
     * checks for adjacent animals and then infects them
     */
    protected void spread() {
        for (Animal animal : getAdjacentAnimals()) {
            if (animal instanceof InfectableAnimal) {
                if (rand.nextDouble() <= SPREAD_PROBABILITY) {
                    ((InfectableAnimal) animal).infect();
                }
            }
        }
    }

    /**
     * @return current infection state of animal
     */
    public boolean isInfected() {
        return infected;
    }


}
