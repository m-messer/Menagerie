import java.util.HashMap;
import java.util.List;

/**
 * Write a description of class Predator here.
 *
 * @version 1.0.0
 */
public abstract class Predator extends Animal
{

    /**
     * Constructor for objects of class Predator
     */
    public Predator(boolean randomAge,Field field, Location location, TimeOfDay clock, Weather weather)
    {
        super(randomAge, field, location, clock, weather);
    }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), range);
        for (Location cell: adjacent){
            Animal animal = field.getAnimalAt(cell);
            
            if (animal != null){
                for (Class key: getPrey().keySet()) {
                    if (animal.getAge() > animal.getBreedingAge() + 5 && key.equals(animal.getClass())) {
                        if(animal.isAlive()) {
                            animal.setDead();
                            setFoodLevel(getPrey().get(animal.getClass()));
                            return cell;
                        }
                    }
                }
            }
            
        }
        return null;
    }

    abstract protected HashMap<Class, Integer> getPrey();

}
