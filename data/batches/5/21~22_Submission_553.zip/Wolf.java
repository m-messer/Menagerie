import java.util.HashMap;


/**
 * A simple model of a wolf.
 * Wolves age, move, eat rabbits and pigs, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Predator
{
    // Characteristics shared by all wolves (class variables).
    
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a fox can live.
    private static final int MAX_AGE = 180;
    // The default likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // List of animals that the hawk eats
    private static HashMap<Class, Integer> preyList = new HashMap<>();
    // List of times when the animal will be awake
    private static final String[] AWAKE_TIMES = {"Night", "Evening"};


    
    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location, TimeOfDay clock, Weather weather)
    {
        super(randomAge, field, location, clock, weather);
        preyList.put(Rabbit.class, 9);
        preyList.put(Pig.class, 15);
    }
    
    /**
     * Determines if the wolf is awake at the current time of day.
     */
    @Override
    protected void calcAwake()
    {
        if(clock.getTime().equals("Night") || clock.getTime().equals("Evening")) //Wolves are nocturnal, so are most active during evening and night.
        {
            isAwake = true;
        }
        else
        {
            isAwake = false;
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A wolf can breed if it has reached the breeding age.
     * @return True if the wolf is of breeding age
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Getter method that returns BRREDING_AGE
     * @return BREEDING_AGE
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Getter method that returns BRREDING_PROBABILITY
     * @return BREEDING_PROBABILITY
     */
    @Override
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Getter method that returns MAX_AGE
     * @return MAX_AGE
     */
    @Override
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Getter method that returns MAX_LITTER_SIZE
     * @return MAX_LITTER_SIZE
     */
    @Override
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Creates a new instance of the animal and returns it
     * @return Wolf
     */
    @Override
    protected Animal getNewAnimal(Field field, Location location) {
        return new Wolf(true, field, location, clock, weather);
    }
    
    /**
     * @return a hash map of the wolf's prey and the food value gained from that prey
     */
    @Override
    protected HashMap<Class, Integer> getPrey() {
        return preyList;
    }
    
    /**
     * @return the times the wolf is awake
     */
    @Override
    protected String[] getAwakeTimes() {
        return AWAKE_TIMES;
    }

}