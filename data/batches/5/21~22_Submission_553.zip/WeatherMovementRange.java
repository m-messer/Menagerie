import java.util.HashMap;
/**
 * Documents different animals' movement ranges in different weather types.
 *
 * @version 27/02/2022
 */
public class WeatherMovementRange
{
    private HashMap<Class, HashMap<String, Integer>> data;
    private HashMap<String, Integer> wolfData;
    private HashMap<String, Integer> rabbitData;
    private HashMap<String, Integer> foxData;
    private HashMap<String, Integer> hawkData;
    private HashMap<String, Integer> pigData;
    
    /**
     * Constructor for objects of class WeatherMovementRange
     */
    public WeatherMovementRange()
    {
        // initialise instance variables
        data = new HashMap<>();
        init();
    }
    
    /**
     * Initialises the data for animals in different weather types
     */
    private void init()
    {
        wolfData = new HashMap<>();
        rabbitData = new HashMap<>();
        foxData = new HashMap<>();
        hawkData = new HashMap<>();
        pigData = new HashMap<>();
        
        wolfData.put("Sunny", 3);
        wolfData.put("Raining", 2);
        wolfData.put("Foggy", 2);
        wolfData.put("Snowing", 1);
        
        rabbitData.put("Sunny", 3);
        rabbitData.put("Raining", 1);
        rabbitData.put("Foggy", 1);
        rabbitData.put("Snowing", 0);
        
        foxData.put("Sunny", 3);
        foxData.put("Raining", 2);
        foxData.put("Foggy", 2);
        foxData.put("Snowing", 1);
        
        hawkData.put("Sunny", 5);
        hawkData.put("Raining", 1);
        hawkData.put("Foggy", 3);
        hawkData.put("Snowing", 1);
        
        pigData.put("Sunny", 2);
        pigData.put("Raining", 1);
        pigData.put("Foggy", 2);
        pigData.put("Snowing", 1);
        
        data.put(Wolf.class, wolfData);
        data.put(Rabbit.class, rabbitData);
        data.put(Fox.class, foxData);
        data.put(Hawk.class, hawkData);
        data.put(Pig.class, pigData);
    }
    
    /**
     * Returns the movement range of a given animal in given weather.
     * 
     * @param The species of animal to check
     * @param The type of weather to check
     * @return The movement range of the given animal in the given weather
     */
    public int getRange(Class animal, String weather)
    {
        HashMap<String, Integer> animalData = data.get(animal);
        return animalData.get(weather);
    }
}
