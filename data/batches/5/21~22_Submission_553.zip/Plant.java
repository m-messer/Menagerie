import java.util.Random;

/**
 * A class that represents the plants that herbivores will eat
 * Each cell will have a plant class. Each plant object will have
 * a some patches of plants. Each time an animal eats a patch, the number
 * of patches decreases. If there are no patches, the animal cannot eat
 * A patch will grow after a number of steps.
 *
 * @version 1.0.0
 */
public class Plant implements Organism
{
    // Number of steps in the simulation to grow a patch
    public static final int STEPS_TO_GROW_PATCH = 3;
    // Maximum number of patches that a single plant object can contain
    public static final int MAX_PATCHES = 5;
    //The number of patches that a plant object currently has
    private int numberOfPatches;
    //Number of steps the simulation has taken, will only increment if number of patches is less than 3.
    //If steps == 5, numberOfPatches will increment, and steps will be reset to 0.
    private int steps;

    // A shared random number generator to control breeding.
    public static final Random rand = Randomizer.getRandom();

    /**
     * Creates a plant object, these will be initialised everywhere at the beginning
     * If we don't want to randomise it, then the numberOfPatches will be set to the max
     * and number of steps will be set to 0
     */
    public Plant(Boolean isRandom)
    {
        //if we want to randomise the stepsUntil new patch growth and number of patches
        if (isRandom) {

            numberOfPatches = rand.nextInt(MAX_PATCHES);
            steps = rand.nextInt(STEPS_TO_GROW_PATCH);
        }
        else {
            numberOfPatches = MAX_PATCHES;
            steps = 0;
        }

    }

    /**
     * If the maximum number of patches has not been reached, the plant will grow
     * It grows by incrementing the step counter after each step
     * If the step counter has reached the number of steps needed for a patch to grow
     * the number of patches will increase and the step counter will be reset to 0
     *
     */
    public void grow()
    {
        if (numberOfPatches < MAX_PATCHES) {
            steps++;
            if (steps == STEPS_TO_GROW_PATCH) {
                numberOfPatches++;
                steps = 0;
            }

        }
    }


    /**
     * Checks whether the patches is more than 0
     * @return boolean Number of patches is more than 0
     */    
    public boolean hasPatches() 
    {
        return (numberOfPatches > 0);
    }

    /**
     * Decrements the number of patches, signifying that
     * an animal has eaten a patch of plants
     */
    public void decrementPatches () {
        numberOfPatches -= 1;
    }

}
