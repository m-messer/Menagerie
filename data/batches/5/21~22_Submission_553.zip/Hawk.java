import java.util.HashMap;


/**
 * A model of a Hawk
 *
 * @version 1.0.0
 */
public class Hawk extends Predator
{
    // Characteristics shared by all Hawks (class variables).
    
    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a hawk can live.
    private static final int MAX_AGE = 120;
    // The default likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The list of prey's that the Hawk eats
    private static HashMap<Class, Integer> preyList = new HashMap<>();
    // The times that a hawk is awake
    private static final String[] AWAKE_TIMES = {"Morning", "Noon"};




    /**
     * Create a hawk. A hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hawk will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hawk(boolean randomAge, Field field, Location location, TimeOfDay clock, Weather weather)
    {
        super(randomAge, field, location, clock, weather);
        preyList.put(Rabbit.class, 16);

        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(10);
        }
        else {
            age = 0;
            foodLevel = 10;
        }
    }
    

    /**
     * Getter method that returns BRREDING_AGE
     * @return BREEDING_AGE
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Getter method that returns BRREDING_PROBABILITY
     * @return BREEDING_PROBABILITY
     */
    @Override
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Getter method that returns MAX_AGE
     * @return MAX_AGE
     */
    @Override
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Getter method that returns MAX_LITTER_SIZE
     * @return MAX_LITTER_SIZE
     */
    @Override
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Creates a new instance of the animal and returns it
     * @return Hawk
     */
    @Override
    protected Animal getNewAnimal(Field field, Location location) {
        return new Hawk(true, field, location, clock, weather);
    }

    @Override
    protected HashMap<Class, Integer> getPrey() {
        return preyList;
    }

    @Override
    protected String[] getAwakeTimes()
    {
        return AWAKE_TIMES;
    }
}  

