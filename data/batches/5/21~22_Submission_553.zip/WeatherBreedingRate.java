import java.util.HashMap;
/**
 * Tracks how different weather types affect breeding rates.
 *
 * @version 27/02/2022
 */
public class WeatherBreedingRate
{
    private HashMap<String, Double> data;

    /**
     * Constructor for objects of class WeatherBreedingRate
     */
    public WeatherBreedingRate()
    {
        // initialise instance variables
        data = new HashMap<>();
        init();
    }

    /**
     * Initialises the data
     */
    public void init()
    {
        data.put("Sunny", 1.0);
        data.put("Raining", 1.1);
        data.put("Foggy", 0.8);
        data.put("Snowing", 1.2);
    }
    
    /**
     * Returns the effect a given weather type has on breeding rates.
     * @param The current weather
     * @return The effect had on the breeding rate
     */
    public Double getBreedingRate(String weather)
    {
        return data.get(weather);
    }
}
