
/**
 * A disease that has a lower chance of the animal dying,
 * but a higher chance of the disease spreading 
 *
 * @version 1.0.0
 */

public class MildDisease extends Disease
{
    public static final double CHANCE_OF_SPREADING = 0.05;
    public static final double CHANCE_OF_DYING = 0.0005;
    public static final double CHANCE_OF_CURED = 0.1;

    public MildDisease (Field field, Animal animal) 
    {   
        super(field, animal);

    }

    /**
     * Returns the chance of an animal dying from the disease
     */
    @Override
    public double getChanceOfDeath() {
        return CHANCE_OF_DYING;
    }

    /**
     * Returns the chance of an animal getting cured from the disease
     */
    @Override
    public double getChanceOfCured() {
        return CHANCE_OF_CURED;
    }

    /**
     * Returns the chance of the disease spreading
     */
    @Override
    public double getChanceOfSpreading() {
        return CHANCE_OF_SPREADING;
    }


    /**
     * Returns a new MildDisease object
     */
    @Override
    public Disease getDisease(Animal animal) {
        return new MildDisease(animal.getField(), animal);

    }}
