import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DiseaseList {
    //A list of all subclasses of the abstract Disease class.
    public static List<Disease> diseaseList;
    //Shared randomiser
    public static final Random rand = Randomizer.getRandom();

    /**
     * Creates a list of all diseases
     */
    public DiseaseList ()
    {
        diseaseList = new ArrayList<>();

        diseaseList.add(new MildDisease(null, null));
        diseaseList.add(new DeadlyDisease(null, null));
    }

    /**
     * Returns a new instance of a random disease
     * @param animal The animal that is to be infected by the disease
     * @return disease An instance of a disease subClass.
     */
    public Disease getRandomDisease(Animal animal) 
    {
        return diseaseList.get(rand.nextInt(diseaseList.size())).getDisease(animal);
    } 
    
}
