import java.util.HashMap;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Fox extends Predator
{
    // Characteristics shared by all foxes (class variables).
    
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The default likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.14;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // HashMap of prey
    private static HashMap<Class, Integer> preyList = new HashMap<>();
    // Times when the fox is awake
    private static final String[] AWAKE_TIMES = {"Evening", "Night"};
    // A shared random number generator to control breeding.

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location, TimeOfDay clock, Weather weather)
    {
        super(randomAge, field, location, clock, weather);
        preyList.put(Rabbit.class, 14);
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     * 
     * @return True if the animal is of breeding age
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Getter method that returns BRREDING_AGE
     * @return BREEDING_AGE
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Getter method that returns BRREDING_PROBABILITY
     * @return BREEDING_PROBABILITY
     */
    @Override
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Getter method that returns MAX_AGE
     * @return MAX_AGE
     */
    @Override
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Getter method that returns MAX_LITTER_SIZE
     * @return MAX_LITTER_SIZE
     */
    @Override
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Creates a new instance of the animal and returns it
     * @return Fox
     */
    @Override
    protected Animal getNewAnimal(Field field, Location location) {
        return new Fox(true, field, location, clock, weather);
    }

    @Override
    protected HashMap<Class, Integer> getPrey() {
        return preyList;
    }

    @Override
    protected String[] getAwakeTimes() {
        return AWAKE_TIMES;
    }
}
