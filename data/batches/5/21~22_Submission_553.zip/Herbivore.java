import java.util.List;

/**
 * An abstract class that contains method for animals that only 
 * eats plants.
 *
 * @version 1.0.0
 */
public abstract class Herbivore extends Animal
{

    public Herbivore(boolean randomAge,Field field, Location location, TimeOfDay clock, Weather weather)
    {
        super(randomAge, field, location, clock, weather);

    }

    /**
     * Herbivore's (the Prey) will look for cells where there are no animals
     * And the plants have patches
     */
    @Override
    protected Location findFood() {

    
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), range);
        for (Location cell: adjacent){
            
            Animal animal = field.getAnimalAt(cell);
            Plant plant = field.getPlantAt(cell);

            if (animal == null && plant.hasPatches()){
                plant.decrementPatches();
                setFoodLevel(getPlantFoodValue());
                return cell;
            }

        }

        return null;
    }
    
    abstract protected int getPlantFoodValue();
}
