import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.05;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.1;    
    // The probabiltity that a hawk will be created in any given grid position.
    private static final double HAWK_CREATION_PROBABILITY = 0.05;
    // The probability that a pig will be created in any given grid position.
    private static final double PIG_CREATION_PROBABILITY = 0.03;
    // The probability that a wolf will be created in any give grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.03;

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A tracker for the current time of day.
    private TimeOfDay clock;
    // The current weather in the simulation.
    private Weather weather;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    public static void main(String[] args) {
        Simulator sim = new Simulator();
        sim.simulate(200);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
            }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        clock = new TimeOfDay();
        weather = new Weather();
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Hawk.class, Color.RED);
        view.setColor(Pig.class, Color.PINK);
        view.setColor(Wolf.class, Color.BLACK);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(5);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all Animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        
        // Lets all plants grow
        for(Plant plant: plants) {
            plant.grow();
            if(weather.getWeather().equals("Raining")){
                plant.grow(); //If it is raining, plants will grow faster.
            }
        }

        // One step has been completed, so the clock is ticked
        clock.tick();
        
        // One step has been completed, so we get new weather
        weather.newWeather();
        
        //Updates the simulation display
        view.showStatus(step, field, clock.getTime(), weather.getWeather());
        //delay(300);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        clock.reset();
        
        // Show the starting state in the view.
        view.showStatus(step, field, clock.getTime(), weather.getWeather());
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {

                Location location = new Location(row, col);
                Plant plant = new Plant(true);
                plants.add(plant);
                field.place(plant, location);

                Animal animal = null;
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    animal = new Fox(true, field, location, clock, weather);
                }
                
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    animal = new Rabbit(true, field, location, clock, weather);
                } 
                
                else if (rand.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    animal = new Hawk(true, field, location, clock, weather);
                }

                else if(rand.nextDouble() <= PIG_CREATION_PROBABILITY) {
                    animal = new Pig(true, field, location, clock, weather);
                }

                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    animal = new Wolf(true, field, location, clock, weather);
                }
                
                // else leave the location empty.
                //Placing animal on the field
                if (animal != null){
                    animals.add(animal);
                    field.place(animal, location);
                }
            }
        }

    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
