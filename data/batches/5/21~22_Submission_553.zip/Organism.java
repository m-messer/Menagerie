
/**
 * Has no purpose except to give both animal and plant a common
 * Type so that they can be placed in the same list in the field class
 *
 * @version 1.0.0
 */
public interface Organism
{
}
