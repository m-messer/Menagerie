import java.util.ArrayList;
/**
 * Serves to track the time of day - some animals behave differently at different times.
 *
 * @version 25/02/2022
 */
public class TimeOfDay
{
    private ArrayList<String> timesOfDay; //Stores the possible values for time of day.
    private int currentTimeIndex; //Stores the position in the array the of the current time of day.

    /**
     * Constructor for objects of class TimeOfDay
     */
    public TimeOfDay()
    {
        // initialise instance variables
        timesOfDay = new ArrayList<>();
        initTimesOfDay();
        currentTimeIndex = 0;
    }
    
    /**
     * Initialises the timesOfDay array with values
     */
    private void initTimesOfDay()
    {
        timesOfDay.add("Morning");
        timesOfDay.add("Noon");
        timesOfDay.add("Evening");
        timesOfDay.add("Night");
    }
    
    /**
     * Simulates time passing - currentTimeIndex is iterated.
     *
     */
    public void tick()
    {
        // put your code here
        if(currentTimeIndex >= 3)
        {
            currentTimeIndex = 0;
        }
        else
        {
            currentTimeIndex ++;
        }
    }
    
    /**
     * Resets the time of day to morning.
     */
    public void reset()
    {
        currentTimeIndex = 0;
    }
    
    /**
     * Returns current time of day
     * 
     * @return The current time of day
     */
    public String getTime()
    {
        return timesOfDay.get(currentTimeIndex);
    }
}
