

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Rabbit extends Herbivore
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 40;
    // The default likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.6; //INCREASE THIS SINCE RABBITS HAVE 3 PREDATORS
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of eating a plant
    private static final int PLANT_FOOD_VALUE = 12;
    // The times that the rabbit is awake
    private static final String[] AWAKE_TIMES = {"Morning", "Evening"};
    
    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location, TimeOfDay clock, Weather weather)
    {
        super(randomAge, field, location, clock, weather);
        if(randomAge)
        {
            age = rand.nextInt(MAX_AGE);
        }
        else
        {
            range = 0;
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Getter method that returns BRREDING_AGE
     * @return BREEDING_AGE
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Getter method that returns BRREDING_PROBABILITY
     * @return BREEDING_PROBABILITY
     */
    @Override
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Getter method that returns MAX_AGE
     * @return MAX_AGE
     */
    @Override
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Getter method that returns MAX_LITTER_SIZE
     * @return MAX_LITTER_SIZE
     */
    @Override
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Creates a new instance of the animal and returns it
     * @return Hawk
     */
    @Override
    protected Animal getNewAnimal(Field field, Location location) {
        return new Rabbit(true, field, location, clock, weather);
    }

    @Override
    protected int getPlantFoodValue() {
        return PLANT_FOOD_VALUE;
    }  


    @Override
    protected String[] getAwakeTimes() {
        return AWAKE_TIMES;
    }
}
