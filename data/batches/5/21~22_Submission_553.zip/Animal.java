import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal implements Organism
{
    //The chance that an animal will randomly catch a disease
    private static double CHANCE_OF_GETTING_DISEASE = 0.001;

    //The disease that the animal has
    private Disease disease;

    // Whether the animal is alive or not.
    private boolean alive;

    // The animal's field.
    private Field field;

    // The animal's position in the field.
    private Location location;

    // The animal's gender
    private boolean isFemale;

    //The animal's hunger
    protected int foodLevel;

    //A shared random number generator to control breeding
    public static final Random rand = Randomizer.getRandom();

    //The animal's age
    protected int age;
    
    // The simulation's current time of day
    protected TimeOfDay clock;
    
    // The simulation's current weather
    protected Weather weather;
    
    // Whether the animal is awake at the current time of day
    protected boolean isAwake;
    
    // The movement range of the animal (may vary depending on weather & disease etc.)
    protected int range;

    private static final DiseaseList diseaseList = new DiseaseList();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param clock The tracker for time of day within the field.
     * @param weather The weather within the field
     */
    public Animal(boolean randomAge, Field field, Location location, TimeOfDay clock, Weather weather)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        isFemale = generateGender();
        isAwake = true;
        this.clock = clock;
        this.weather = weather;


        disease = null;
        if(randomAge) {
            age = rand.nextInt(getMaxAge() / 2);
            foodLevel = rand.nextInt(15) + 2;
        }
        else {
            age = 0;
            foodLevel = 15;
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newAnimal)
    {
        incrementAge();
        incrementHunger();
        calcAwake();

        //The disease still acts even if the animal is not moving. If the animal is dead, it cannot be infected.
        if(alive && getIsInfected()) {
            disease.diseaseAct();
        }
        else {
            infectByChance();
        }
        
        if(alive && isAwake) {
            
            Location newLocation;
            giveBirth(newAnimal);
            calcMovementRange();          

            
            //If the animal isn't hungry, it tries to move towards a mate
            if(foodLevel > 6) {
                newLocation = adjLocationTowardsMate();
                move(newLocation);
            }
            
            //If the animal is hungry, it looks for food.
            else {
                newLocation = findFood(); 
                move(newLocation);
            }
        }


    }  
    
    /**
     * Returns whether the animal is female.
     * @return true if animal is female, false if male.
     */
    public boolean getIsFemale()
    {
        return isFemale;
    }
    
    /**
     * @return Age animal's age
     */
    public int getAge() 
    {
        return age;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */

    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
    * Returns a random boolean value for gender.
    * @return A random boolean for gender
    */
    private boolean generateGender() 
    {
        Random rand = new Random();
        return rand.nextBoolean();
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     *
     */
    protected void incrementHunger()
    {
        this.foodLevel --;
        if(foodLevel <= 0) {
            setDead();
        }
    }


    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    
    protected void giveBirth(List<Animal> newAnimals)
    {
        //Checks if this animal is female and adjacent to a male. If not, does not give birth.
        if (isMaleAdjacent())
        {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(location, range);
            int births = breed();

            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                newAnimals.add(getNewAnimal(field, loc));
            }
        }
    }

    
    
    /**
    * Checks if there are adjacent males of the same species.
    * @return true if the animal is female, and there is an adjacent male of the same gender. Otherwise, returns false.
    */
    protected boolean isMaleAdjacent()
    {
        if(isFemale)
        {
            List<Location> adjLocations = getField().adjacentLocations(location, range);
            for (Location cell: adjLocations)
            {
                Animal animalInCell = (Animal) getField().getAnimalAt(cell); 
                if(animalInCell != null && this.getClass().equals(animalInCell.getClass())) 
                { 
                    return true;
                }
            }
        }
        return false;
    }

    
    /**
     * Returns the animal's food level
     * @return the animal's food level
     */
    protected int getFoodLevel() 
    {
        return foodLevel;
    }

    /**
     * Sets the animal's food level
     * @param foodLevel
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }

    /**
     * Increase the age. This could result in the fox's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();


        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        Random rand = new Random();
        int births = 0;
        if(canBreed() && rand.nextDouble() <= calcBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     * @return true if the fox is of breeding age - false if not.
     */
    private boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Determines if the animal is awake at the current time of day.
     */
    protected void calcAwake()
    {
        isAwake = false;

        for (String time: getAwakeTimes()){

            if(clock.getTime().equals(time)) {
                isAwake = true;
                return;
            }
        }
    }
    
    /**
     * Returns true if the animal is infected.
     * @return true if animal is infected - false if not
     */
    public boolean getIsInfected() {
        return (disease != null);
    }
    
    /**
     * Infects an animal with a new disease
     */
    public void infect()
    {
        disease = diseaseList.getRandomDisease(this);
    }
    
    public void cure() 
    {
        this.disease = null;
    }

    /**
     * Checks if the animal will be randomly infected i.e. not through contact with an infected animal
     * 
     */
    private void infectByChance() {
        if (rand.nextDouble() <= CHANCE_OF_GETTING_DISEASE) {
            infect();
        }
    }
    
    

    abstract protected Animal getNewAnimal(Field field, Location location);

    /**
    * Both herbivorous and carnivorous animals will have a find food method but it will be different for both
    * @return
    */
   abstract protected Location findFood();

   /**
    * Accessor methods for constants in each animal class
    */

    abstract public int getBreedingAge();
    
    abstract protected double getBreedingProbability();
    
    abstract protected int getMaxLitterSize();
    
    abstract protected int getMaxAge();

    abstract protected String[] getAwakeTimes();
    
    /**
     * Determines the animal's movement range, based on the current weather, and whether or not it is infected with a disease.
     */
    protected void calcMovementRange()
    {
        range = weather.getMovement(this.getClass());
        if(getIsInfected())
        {
            range --;
        }
        if(range < 0)
        {
            range = 0;
        }
    }
    
    /**
     * Calculates the current breeding probability of the animal - this varies on the animal, the current weather, and 
     * whether the animal is infected with a disease
     */
    protected double calcBreedingProbability()
    {
        double breedingProbability = getBreedingProbability();
        if(getIsInfected())
        {
            breedingProbability *= 0.8;
        }
        breedingProbability *= weather.getBreedingRate();
        return breedingProbability;
    }

    /*
        Additional extension: Animals will try to find the closest animal of their species
        of the opposite gender and will travel in the direction of their 
    */

    /**
     * Checks the surrounding cells for another animal of the same species that is
     * The opposite gender, if there is one, it will return its location
     * 
     * @return potentialMate the location of the nearest animal of the same species but opposite gender 
     */
    private Location nearestMate() 
    {
        //Returns a list of location within a 5 cell radius
        List<Location> nearbyCells = field.adjacentLocations(location, 5);

        Location potentialMate = null;
        for (Location cell: nearbyCells) {
            Animal animalInCell = field.getAnimalAt(cell);
            //Checks that the cell has an animal in it, that the animal is the same spieces as this one, and that it is the opposite gender
            if (animalInCell != null && this.getClass().equals(animalInCell.getClass()) && animalInCell.getIsFemale() != this.getIsFemale()) {

                if(potentialMate == null) {
                    potentialMate = animalInCell.getLocation();
                }
                else if (getDisplacement(cell) < getDisplacement(potentialMate)) {
                    potentialMate = cell;
                }

            }
        }

        return potentialMate;
    }
    
    /**
     * Finds the nearest animal of the same species but different gender
     * And finds the direct that it is in from the current location
     * then checks each of the cells adjacent to it 
     * @return
     */
    protected Location adjLocationTowardsMate() 
    {
        Location nearestMate = nearestMate();
        Location bestLocation = null;

        if (nearestMate != null) {

            List<Location> adjLocations = field.adjacentLocations(location, range);
            
            for(Location cell: adjLocations) {
                
                if (field.getAnimalAt(cell) == null){ 
                    if (bestLocation == null) {
                        bestLocation = cell;
                    }
                    else {
                        if(getDisplacement(bestLocation, nearestMate) > getDisplacement(cell, nearestMate)) {

                            bestLocation = cell;
                        }
                    }
                }
            } 
        }   
        return bestLocation;
        
    }   

    private double getDisplacement (Location loc1, Location loc2) 
    {
        return Math.sqrt(
            Math.pow((loc1.getRow() - loc2.getRow()), 2) + 
            Math.pow((loc1.getCol() - loc2.getRow()), 2)
            );
    }

    /**
     * Calculates the displacement between the object and a given location and returns it
     * @param location
     * @return displacement
     */
    private double getDisplacement(Location location)
    {
        Location loc = getLocation(); //Gets the location of this animal

        return Math.sqrt(
            Math.pow((loc.getRow() - location.getRow()), 2) + 
            Math.pow((loc.getCol() - location.getRow()), 2)
            );
    } 

    /**
     * Animal moves to a new space
     * @param newLocation the location the animal will move to
     */
    private void move(Location newLocation) {
        if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(location, range);
        }

        // See if it was possible to move.  
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }
}

