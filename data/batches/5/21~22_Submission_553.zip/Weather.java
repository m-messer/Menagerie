import java.util.Random;
import java.util.ArrayList;
/**
 * The current weather in the simulation. Affects the breeding rate & movement range of different animals.
 *
 * @version 28/02/2022
 */
public class Weather
{
    private WeatherMovementRange movementData;
    private WeatherBreedingRate breedingData;
    private Random rand;
    private ArrayList<String> weatherTypes;
    private String currentWeather;
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        // initialise instance variables
        movementData = new WeatherMovementRange();
        breedingData = new WeatherBreedingRate();
        rand = new Random();
        weatherTypes = new ArrayList<>();
        init();
        newWeather();
    }
    
    /**
     * Initialises the weather data
     */
    private void init()
    {
        weatherTypes.add("Sunny");
        weatherTypes.add("Raining");
        weatherTypes.add("Foggy");
        weatherTypes.add("Snowing");
    }
    
    /**
     * Generates a new random weather
     */
    public void newWeather()
    {
        currentWeather = weatherTypes.get(rand.nextInt(4));
    }
    
    /**
     * Returns the movement range of a given species in the current weather
     * @param A species of animal
     * @return The movement range of the animal in the current weather
     */
    public int getMovement(Class animal)
    {
        return movementData.getRange(animal, currentWeather);
    }
    
    /**
     * @return The current weather
     */
    public String getWeather()
    {
        return currentWeather;
    }
    
    /**
     * Returns the effect that the current weather has on the breeding rate.
     */
    public Double getBreedingRate()
    {
        return breedingData.getBreedingRate(currentWeather);
    }
}
