
/**
 * A diseaes that has a higher chance of killing the animal
 * but a higher chance of the animal curing from the disease
 * and a lower chance of the disease spreading
 *
 * @version 1.0.0
 */

public class DeadlyDisease extends Disease
{
    public static final double CHANCE_OF_SPREADING = 0.005;
    public static final double CHANCE_OF_DYING = 0.005;
    public static final double CHANCE_OF_CURED = 0.15;

    public DeadlyDisease(Field field, Animal animal) 
    {
        super(field, animal);
    }


    @Override
    public double getChanceOfDeath() {
        return CHANCE_OF_DYING;
    }

    @Override
    public double getChanceOfCured() {
        return CHANCE_OF_CURED;
    }

    @Override
    public double getChanceOfSpreading() {
        return CHANCE_OF_SPREADING;
    }

    @Override
    public Disease getDisease(Animal animal) {
        return new DeadlyDisease(animal.getField(), animal);
    }
}
