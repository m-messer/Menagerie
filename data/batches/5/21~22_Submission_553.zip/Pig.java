/**
 * A simple model of a pig.
 * Pigs age, move, breed, and die.
 *
 * @version 25/02/2022
 */
public class Pig extends Herbivore
{
    // Characteristics shared by all pigs (class variables).

    // The age at which a pig can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a pig can live.
    private static final int MAX_AGE = 100;
    // The default likelihood of a pig breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // Food value from eating a plant
    private static final int PLANT_FOOD_VALUE = 7;
    // The times that the pig is awake
    private static final String[] AWAKE_TIMES = {"Morning", "Noon"};
    

    
    /**
     * Create a new pig. A pig may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the pig will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Pig(boolean randomAge, Field field, Location location, TimeOfDay clock, Weather weather)
    {
        super(randomAge, field, location, clock, weather);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * Getter method that returns BRREDING_AGE
     * @return BREEDING_AGE
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Getter method that returns BRREDING_PROBABILITY
     * @return BREEDING_PROBABILITY
     */
    @Override
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Getter method that returns MAX_AGE
     * @return MAX_AGE
     */
    @Override
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Getter method that returns MAX_LITTER_SIZE
     * @return MAX_LITTER_SIZE
     */
    @Override
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Creates a new instance of the animal and returns it
     * @return Pig
     */
    @Override
    protected Animal getNewAnimal(Field field, Location location) {
        return new Pig(true, field, location, clock, weather);
    }

    @Override
    protected int getPlantFoodValue() {
        return PLANT_FOOD_VALUE;
    }

    @Override
    protected String[] getAwakeTimes() {
        return AWAKE_TIMES;
    }
}
