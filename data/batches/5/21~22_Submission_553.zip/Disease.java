import java.util.List;
import java.util.Random;

/**
 * Will represent a disease that animals can catch, spread
 * and potentially die from.
 *
 * @version 1.0.0
 */
public abstract class Disease
{

    private Field field;
    private Animal infectedAnimal;

    //Shared randomiser
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Disease
     */
    public Disease(Field field, Animal animal)
    {
        this.field = field;
        infectedAnimal = animal;
    }

    /**
     * The disease is able to spread.
     * This method will spread it to surrounding animals
     */
    public void infectAdjacentAnimals() 
    {
        List<Location> adjLocation = field.adjacentLocations(infectedAnimal.getLocation(), 1);
        for(Location cell: adjLocation) {

            Animal animal = field.getAnimalAt(cell);
            if(animal != null && rand.nextDouble() <= getChanceOfSpreading()) {
                animal.infect(); //This will be a method in the Animal class that will 
            }

        }

    }

    /**
     * What happens to the diseased animal when it acts - it can be cured, die, or infect other animals
     */
    public void diseaseAct() {
        if (rand.nextDouble() <= getChanceOfCured()) {
            infectedAnimal.cure(); 
        }
        else if (rand.nextDouble() <= getChanceOfDeath()) {
            infectedAnimal.setDead();
        }
        else {
            infectAdjacentAnimals();
        }
    }
    
    /**
     * @return Chance of death from the disease
     */
    abstract public double getChanceOfDeath();
    
    /**
     * @return Chance of recovering from the disease
     */
    abstract public double getChanceOfCured();

    /**
     * @return Chance of a disease spreading
     */
    abstract public double getChanceOfSpreading();

    /**
     * @param animal Animal to be infected by the disease
     * @return disease An instance of a disease subclass
     */
    abstract public Disease getDisease(Animal animal);

}
