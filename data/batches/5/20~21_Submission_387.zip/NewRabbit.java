import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Rabbit.
 * Rabbits age, move, eat Grass, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class NewRabbit extends NewAnimal
{
    /**
     * Create a Rabbit. A Rabbit can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Rabbit will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public NewRabbit(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        super.MAX_LITTER_SIZE = 5;
        super.FOOD_VALUE = 20;
    }

    /**
     * This is what the Rabbit does most of the time: it hunts for
     * Grass. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newRabbits A list to return newly born Rabbits.
     */
    public void act(List<NewAnimal> newRabbits) {
        incrementAge();
        incrementHunger();
        if (isAlive()) {
            if (getField().getDay()) {
                try {
                    giveBirth(newRabbits);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for Grass adjacent to the current location.
     * Only the first live Grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    @Override
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Grass) {
                Grass grass = (Grass) obj;
                if(grass.isAlive()) {
                    grass.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}