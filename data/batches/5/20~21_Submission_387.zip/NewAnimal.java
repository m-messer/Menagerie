import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A refactored class representing shared characteristics of animals.
 *
 * @version 2021.2.27
 */
public abstract class NewAnimal extends Actor<NewAnimal> {
    Class clazz = this.getClass();
    // Characteristics shared by all animals (class variables).

    // The age at which a animal can start to breed.
    protected int BREEDING_AGE = 10;
    // The age to which a animal can live.
    protected int MAX_AGE = 100;
    // The likelihood of a animal breeding.
    protected double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    protected int MAX_LITTER_SIZE = 3;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a animal can go before it has to eat again.
    protected int FOOD_VALUE = 25;
    // The chance of been infected.
    private static final double INFECTION_RATE = 0.1;
    // The chance of born with disease
    private static final double BORN_WITH_DISEASE_RATE = 0.0005;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The animal's age.
    protected int age;
    // The animal's food level, which is increased by eating rabbits.
    protected int foodLevel;
    // whether the animal is infected or not.
    protected boolean isInfected;
    // The animal's gender
    protected boolean isFemale = rand.nextBoolean();

    /**
     * Create a new animal at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public NewAnimal(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
        ;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newAnimals A list to receive newly born animals.
     */
    public abstract void act(List<NewAnimal> newAnimals);

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first live rabbit is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    abstract Location findFood();

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<NewAnimal> newAnimals) throws IllegalAccessException, InstantiationException {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if (obj != null) {
                if (obj.getClass() == this.getClass()) {
                    infectAnimal((NewAnimal) obj);
                    if (((NewAnimal) obj).isFemale != this.isFemale && this.isFemale) {
                        // New animals are born into adjacent locations.
                        // Get a list of adjacent free locations.
                        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                        int births = breed();
                        for (int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            NewAnimal young = null;
                            try {
                                young = (NewAnimal) makeObject(clazz, false, field, loc);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            bornWithDiease(young);
                            newAnimals.add(young);
                        }
                    }
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     */
    protected boolean canBreed() {
        return age >= BREEDING_AGE;
    }


    /**
     * create a class using the constructor of the class
     *
     * @param clazz the class of the new instance
     */
    static <T> T makeObject(Class<T> clazz, boolean randomAge, Field field, Location location) throws Exception {
        return clazz.getConstructor(boolean.class, Field.class, Location.class).newInstance(randomAge, field, location);
    }

    /**
     * make newly born animal ill
     *
     * @param animal the newly born animal
     */
    private void bornWithDiease(NewAnimal animal){
        if(rand.nextDouble() < BORN_WITH_DISEASE_RATE){
            animal.isInfected = true;
            animal.makeAnimalIll();
        }
    }

    /**
     * reduce Max Age
     * the disease won't kill the animal instantly, it
     * will make the animal earlier to die.
     */
    private void makeAnimalIll() {
        try{
            MAX_AGE = age + rand.nextInt(MAX_AGE - age);
        } catch (Exception e){

        }
    }


    /**
     * let the animal  try to infect another animal
     *
     * @param animal the animal been influenced
     */
    protected void infectAnimal(NewAnimal animal) {
        if (this.isInfected == true) {
            if (animal.isInfected == false) {
                if (rand.nextDouble() < INFECTION_RATE) {
                    animal.isInfected = true;
                    animal.makeAnimalIll();
                }
            }
        }
    }
}
