import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a groundhog.
 * groundhogs age, move, eat Grass, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class NewGroundhog extends NewAnimal
{
    /**
     * Create a Groundhog. A Groundhog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Groundhog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    //The groundhog is in the cave
    private boolean isInCave = rand.nextBoolean();
    
    public NewGroundhog(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        super.FOOD_VALUE = 15;
        super.BREEDING_PROBABILITY = 1;
        super.MAX_LITTER_SIZE = 5;
    }

    /**
     * This is what the Groundhog does most of the time: it hunts for
     * Grass. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newGroundhogs A list to return newly born groundhogs.
     */
    public void act(List<NewAnimal> newGroundhogs) {
        incrementAge();
        incrementHunger();
        alterIsInCave();
        if (isAlive()) {
            if (getField().getDay() ) {
                try {
                    giveBirth(newGroundhogs);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for Grasss adjacent to the current location.
     * Only the first live Grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    @Override
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Grass) {
                Grass grass = (Grass) obj;
                if(grass.isAlive()) {
                    grass.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
    * A groundhog must have a cave to live
    * It could be in the cave or not
    * @return true if the Groundhog is currently in the cave, false otherwise.
    */
    public boolean getIsInCave()
    {
        return isInCave;
    }
    
    /**
    * Alter the status of whether the
    * groundhog is in the cave
    */
   public void alterIsInCave()
    {
        if(rand.nextDouble() >= 0.5){
            isInCave = true;
        } else{
            isInCave = false;
        }

    }
    
   
   @Override
   public void giveBirth(List<NewAnimal> newAnimals) throws IllegalAccessException, InstantiationException {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if (obj != null) {
                if (obj.getClass() == this.getClass()) {
                    if (((NewGroundhog) obj).isFemale != this.isFemale && this.isFemale && ((NewGroundhog) obj).isInCave && this.isInCave) {
                        // New animals are born into adjacent locations.
                        // Get a list of adjacent free locations.
                        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                        int births = breed();
                        for (int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            NewAnimal young = null;
                            try {
                                young = (NewAnimal) makeObject(clazz, false, field, loc);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            newAnimals.add(young);
                        }
                    }
                }
            }
        }
    }
}