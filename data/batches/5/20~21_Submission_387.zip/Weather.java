/**
 * A class representing shared characteristics of weathers.
 *
 * @version 26.02.2020
 */
public abstract class Weather {

}
