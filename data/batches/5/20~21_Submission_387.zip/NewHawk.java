import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a hawk.
 * Rabbits age, move, eat snake and groundhog, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class NewHawk extends NewAnimal
{
    /**
     * Create a Hawk. A Hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Hawk will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */

    public NewHawk(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        super.FOOD_VALUE = 7;
        super.MAX_AGE = 50;
    }

    /**
     * This is what the Hawk does most of the time: it hunts for
     * Rabbits and Snakes. In the process, it might breed, die of hunger
     * or die of old age.
     * @param newHawks A list to return newly born hawks.
     */
    public void act(List<NewAnimal> newHawks) {
        incrementAge();
        incrementHunger();
        if (isAlive()) {
            if (!getField().getDay()) {
                try {
                    giveBirth(newHawks);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for Groundhogs or Snakes adjacent to the current location.
     * Only the first live Rabbit or Groundhog is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    @Override
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof NewGroundhog) {
                NewGroundhog groundhog = (NewGroundhog) animal;
                if(groundhog.isAlive()&& !groundhog.getIsInCave()) {
                    groundhog.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
               
            }
            if(animal instanceof NewSnake) {
                NewSnake snake = (NewSnake) animal;
                if(snake.isAlive()) {
                    snake.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
               
            }
        }
        return null;
    }
}