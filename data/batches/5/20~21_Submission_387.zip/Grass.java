import java.util.List;
import java.util.Random;

/**
 * A simple model of grass
 *
 * @version 26.02.2021
 */
public class Grass extends Plant {

    // The age at which the grass can reproduce
    private static final int BREEDING_AGE = 1;
    // The age to which the grass can live.
    private static final int MAX_AGE = 100;
    // The likelihood of grass to reproduce.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The grass's age.
    private int age;

    public Grass(Field field, Location location) {
        super(field, location);
    }

    /**
     * This is what the grass does most of the time.
     * In the process, it might reproduce, or die of old age.
     * @param newPlants A list to return newly reproduced grass.
     */
    public void act(List<Plant> newPlants)
    {
        incrementAge();
        if(isAlive()) {
            if(getField().getCurrentWeather().equals(Field.Weather.RAIN)){
                giveBirth(newPlants);
            }
        } else {
            // Overcrowding.
            setDead();
            }
        }

    /**
     * Increase the age. This could result in the grass's withered.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this grass is to reproduce at this step.
     * New grass will be made into free adjacent locations.
     * @param newGrass A list to return newly born grass.
     */
    private void giveBirth(List<Plant> newGrass)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(field, loc);
            newGrass.add(young);
        }
    }

    /**
     * Generate a number representing the number of new grass,
     * if it can reproduce.
     * @return The number of new grass (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A grass can reproduce if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
