import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class NewFox extends NewAnimal {
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public NewFox(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        super.MAX_AGE = 100;
        super.MAX_LITTER_SIZE = 3;
        super.FOOD_VALUE = 20;
        super.BREEDING_AGE = 23;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newFoxes A list to receive newly born animals.
     */
    public void act(List<NewAnimal> newFoxes) {
        incrementAge();
        incrementHunger();
        if (isAlive()) {
            try {
                giveBirth(newFoxes);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            }
            if(getField().getDay() == true){
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    @Override
    public Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof NewRabbit) {
                NewRabbit rabbit = (NewRabbit) obj;
                if(rabbit.isAlive()) {
                    rabbit.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}