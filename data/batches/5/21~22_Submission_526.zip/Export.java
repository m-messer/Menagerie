import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.ArrayList;
import actors.Actor;
/**
 * Exports data to an external csv
 *
 * @version (a version number or a date)
 */
public class Export
{
    private FileWriter writer;
    private FileWriter finalWriter;
    /**
     * Constructor for objects of class Export
     */
    public Export()
    {
        initFile("data.txt");
        initFile("finalReport.txt");
        try{ 
            writer = new FileWriter("data.txt", true);
            finalWriter = new FileWriter("finalReport.txt", true);
        }
        catch (IOException exception){}
        
    }
    
    private void initFile(String fileName)
    {
        try{
            File file = new File(fileName);
            file.createNewFile();
            FileWriter clear = new FileWriter(fileName);
            clear.close();
        }
        catch (IOException exception) {}
    }
    
    public void exportData(ArrayList<Actor> actors, String time, int steps)
    {
        try {
            for (Actor actor : actors){
                HashMap<String, Integer> death = actor.getDeath();
                if (!death.isEmpty()){ 
                    writer.write(">> \r\n");
                    writer.write("TimeStamp: " + time + "(" + steps + " steps) \r\n");
                    writer.write("Actor: " + actor.toString() + "\r\n");
                    writer.write("======Reasons and Counts of Death====== \r\n");
                    for (String reason : death.keySet()){
                        writer.write(reason + ": " + death.get(reason).toString() +"\r\n");
                    }
                    writer.write(">> \r\n");
                    writer.write("\r\n");
                }
            }
        }
        catch (IOException exception) {}
        
    }
    
    
    public void closeWriter()
    {
        try{
           writer.close();
           finalWriter.close();
        }
        catch (IOException exception) {}
    }
    
    public void finalReport(ArrayList<Actor> actors, ArrayList<String> weather)
    {
        try{
            finalWriter.write("WEATHER REPORT \r\n");
            finalWriter.write("--------------------------- \r\n");
            for (String line : weather){
                finalWriter.write(line + "\r\n");
            }
            finalWriter.write("\r\n \r\n \r\n");
            finalWriter.write("DEATHS REPORT \r\n");
            finalWriter.write("--------------------------- \r\n");
            for (Actor actor : actors){
                HashMap<String, Integer> death = actor.getDeath();
                if (!death.isEmpty()){ 
                    writer.write(">> \r\n");
                    finalWriter.write("Actor: " + actor.toString() + "\r\n");
                    finalWriter.write("======Reasons and Counts of Death====== \r\n");
                    for (String reason : death.keySet()){
                        finalWriter.write(reason + ": " + death.get(reason).toString() +"\r\n");
                    }
                    writer.write(">> \r\n");
                    finalWriter.write("\r\n");
                }
            }

        }
        catch (IOException exception) {}
        
    }
}
