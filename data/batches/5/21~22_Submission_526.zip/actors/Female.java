package actors;

import java.util.Random;
/**
 * Females can do everything a Male can as well as breed.
 * Females control which Male they mate with.
 *
 * @version 1.0
 */
public class Female extends Gender
{
    private final int maxOffspring;
    private final double pChance;
    private final int pPeriod;
    // Pregnancy counter
    private int pCounter;
    private Random rand;
    private boolean pregnant;
    
    /**
     * Create a new female.
     * 
     * @param matingDistance The maximum distance a male and female can mate
     * @param minMatingAge The female is infertile when younger than this age
     * @param maxMatingAge The female is infertile when older than this age
     * @param maxOffspring The maximum number of children a female can birth
     * @param pregnancyPeriod The amount of time between preganancy and giving birth
     * @param pregnancyChance The probability of the female successfully mating with a male and getting pregnant
     */
    public Female(int matingDistance, int minMatingAge, int maxMatingAge,
    int maxOffspring, int pregnancyPeriod, double pregnancyChance)
    {
        super(matingDistance, minMatingAge, maxMatingAge);
        this.maxOffspring = maxOffspring;
        pPeriod = pregnancyPeriod;
        pChance = pregnancyChance;
        pCounter = 0;
        rand = new Random();
        pregnant = false;
    }
    
    /**
     * @return the gender type: female
     */
    @Override
    public String toString()
    {
        return "Female";
    }
    
    /**
     * Increment the pregnancy counter. If the counter exceeds its maximum value
     * (the female is pregnant) reset back to zero.
     */
    public void incrementPCounter()
    {
        pCounter = (++pCounter)%pPeriod;
    }
    
    /**
     * Randomly generate the number of children the female births
     * @return The number of children the female births
     */
    public int breed()
    {
        return rand.nextInt(maxOffspring)+1;
    }
    
    /**
     * Track the female's progress in its pregnancy
     * @return The pregnancy counter
     */
    public int getPCounter()
    {
        return pCounter;
    }
    
}
