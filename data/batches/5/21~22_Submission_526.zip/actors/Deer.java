package actors;

import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.HashMap;
import fieldProperties.*;

/**
 * A simple model of a deer.
 * deers age, move, breed, and die.
 *
 * @version 3.0
 */
public class Deer extends Animal
{
    // The age to which a deer can live
    private static final int MAX_AGE = 80;
    // A shared random number generator to control breeding
    private static final Random rand = Randomizer.getRandom();
    
    // Fields relating to reproduction that will be parsed to the gender object
    private static final int BIRTHING_RADIUS = 1;
    private static final int MATING_RADIUS = 6;
    private static final int MIN_MATING_AGE = 20; //inclusive
    private static final int MAX_MATING_AGE = 70; //inclusive
    private static final int MAX_OFFSRPING = 4;        
    private static final double PREGNANCY_CHANCE = 0.2;
    private static final int PREGNANCY_PERIOD = 9;
    private static final int[] AWAKE_TIME = {11*60 + 15, 22*60};
    
    // One food allows for one step/movement in the simulation
    // How much food the deer gives if it is eaten
    private static final int FOOD_VALUE = 18;
    // How much food a deer can eat
    private static final int MAX_FOOD_LEVEL = 8;
    
    // The ghostField is the invisible field where plants exist
    // The deer eats plants from ghostField
    private Field ghostField;
    
    // The dummy location is not actually on the grid
    private static final Location dummyLocation = new Location(-1,-1);
    // Add new foods to this array
    private final Actor[] foods = {new Grass(getField(), dummyLocation)};
    
    private static HashMap<String, Integer> death = new HashMap<>();
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ghostFIeld The field that plants exist in.
     */
    // All herbivores or omnivores (animals that consume plants) need to be parsed the ghost field
    // This may be a reason to split up the hierarchy into even more classes
    public Deer(boolean randomAge, Field field, Location location, Field ghostField)
    {
        super(field, location, ghostField, MAX_AGE, MATING_RADIUS, MIN_MATING_AGE, MAX_MATING_AGE,
        MAX_OFFSRPING, PREGNANCY_PERIOD, PREGNANCY_CHANCE, BIRTHING_RADIUS,
        MAX_FOOD_LEVEL, FOOD_VALUE,
        AWAKE_TIME, death);
        
        setFoodSource(foods);   //set food source after creating the Animal object as it's not static
        this.ghostField = ghostField;
        
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(MAX_FOOD_LEVEL));
        }
        else {
            setAge(0);
            setFoodLevel(MAX_FOOD_LEVEL);
            // All animals start with being fertile, but a newborn is not fertile
            getGender().toggleFertility();
        }
    }
    
    /**
     * @return The name of the animal: deer
     */
    @Override
    public String toString()
    {
        return "deer";
    }
    
    /**
     * Deer is a herbivore so call the herbivoreFindFood method from Animal class
     * @return Where food was found, or null if it wasn't.
     */
    // This method only works for eating plants, for omnivors you would need to rewrite this method
    protected Location findFood()
    {
        return herbivoresFindFood();
    }
    
    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free nearby locations.
     * @param newdeers A list to return newly born deers.
     */
    public void giveBirth(List<Actor> newDeers)
    {
        // The animal can only give birth when their pregnancy counter is at its maximum
        Gender gender = getGender();
        if (gender.getPCounter() != PREGNANCY_PERIOD-1) return;
        // New deers are born into adjacent locations.
        // Get a list of nearby free locations.
        Field field = getField();
        List<Location> free = field.getFreeNearbyLocations(getLocation(), BIRTHING_RADIUS);
        int births = gender.breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc, ghostField);
            newDeers.add(young);
        }
        gender.incrementPCounter();
    }
    
}
