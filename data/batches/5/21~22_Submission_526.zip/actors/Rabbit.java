package actors;

import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.HashMap;
import fieldProperties.*;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 3.0
 */
public class Rabbit extends Animal
{
    // The age to which a rabbit can live
    private static final int MAX_AGE = 40;
    // A shared random number generator to control breeding
    private static final Random rand = Randomizer.getRandom();
    
    // Fields relating to reproduction that will be parsed to the gender object
    private static final int BIRTHING_RADIUS = 4;
    private static final int MATING_RADIUS = 3;
    private static final int MIN_MATING_AGE = 5; //inclusive
    private static final int MAX_MATING_AGE = 30; //inclusive
    private static final int MAX_OFFSRPING = 8;        
    private static final double PREGNANCY_CHANCE = 0.2;
    private static final int PREGNANCY_PERIOD = 4;
    private static final int[] AWAKE_TIME = {8*60 + 30, 20*60};
    // One food allows for one step/movement in the simulation
    // How much food the rabbit gives if it is eaten
    private static final int FOOD_VALUE = 9;
    // How much food a rabbit can eat
    private static final int MAX_FOOD_LEVEL = 4;
    
    // The ghostField is the invisible field where plants exist
    // The rabbit eats plants from ghostField
    private Field ghostField;
    
    // The dummy location is not actually on the grid
    private static final Location dummyLocation = new Location(-1,-1);
    // Add new foods to this array
    private final Actor[] foods = {new Grass(getField(), dummyLocation)};
    
    private static HashMap<String, Integer> death = new HashMap<>() ;
    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param ghostFIeld The field that plants exist in.
     */
    // All herbivores or omnivores (animals that consume plants) need to be parsed the ghost field
    // This may be a reason to split up the hierarchy into even more classes
    public Rabbit(boolean randomAge, Field field, Location location, Field ghostField)
    {
        super(field, location, ghostField, MAX_AGE, MATING_RADIUS, MIN_MATING_AGE, MAX_MATING_AGE,
        MAX_OFFSRPING, PREGNANCY_PERIOD, PREGNANCY_CHANCE, BIRTHING_RADIUS,
        MAX_FOOD_LEVEL, FOOD_VALUE,
        AWAKE_TIME, death);
        
        setFoodSource(foods);   //set food source after creating the Animal object as it's not static
        this.ghostField = ghostField;
        
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(MAX_FOOD_LEVEL));
        }
        else {
            setAge(0);
            setFoodLevel(MAX_FOOD_LEVEL);
            // All animals start with being fertile, but a newborn is not fertile
            getGender().toggleFertility();
        }
    }
    
    /**
     * @return The name of the animal: rabbit
     */
    @Override
    public String toString()
    {
        return "rabbit";
    }
    
    /**
     * Rabbit is a herbivore so call the herbivoreFindFood method from Animal class
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        return herbivoresFindFood();
    }
    
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free nearby locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void giveBirth(List<Actor> newRabbits)
    {
        // The animal can only give birth when their pregnancy counter is at its maximum
        Gender gender = getGender();
        if (gender.getPCounter() != PREGNANCY_PERIOD-1) return;
        // New rabbits are born into adjacent locations.
        // Get a list of nearby free locations.
        Field field = getField();
        List<Location> free = field.getFreeNearbyLocations(getLocation(), BIRTHING_RADIUS);
        int births = gender.breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rabbit young = new Rabbit(false, field, loc, ghostField);
            newRabbits.add(young);
        }
        gender.incrementPCounter();
    }
}
