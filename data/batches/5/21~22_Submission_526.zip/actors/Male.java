package actors;

/**
 * Males can be on the revieving end of Females wanting to mate.
 * They have the necessary properties to accomodate this.
 *
 * @version 1.0
 */
public class Male extends Gender
{
    /**
     * Create a new male.
     * 
     * @param matingDistance The maximum distance a male and female can mate
     * @param minMatingAge The male is infertile when younger than this age
     * @param maxMatingAge The male is infertile when older than this age
     */
    public Male(int matingDistance, int minMatingAge, int maxMatingAge)
    {
        super(matingDistance, minMatingAge, maxMatingAge);
    }
    
    /**
     * @return the gender type: male
     */
    @Override
    public String toString()
    {
        return "Male";
    }
    
    /**
     * Exists for polymorphism
     */
    public void incrementPCounter()
    {
        
    }
    
    /**
     * Exists for polymorphism
     * @return Males cannot breed
     */
    public int breed()
    {
        return 0;
    }
    
    /**
     * Exists for polymorphism
     * @return Males can never get pregnant
     */
    public int getPCounter()
    {
        return 0;
    }
}
