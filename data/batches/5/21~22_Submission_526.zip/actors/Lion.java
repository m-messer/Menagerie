package actors;

import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
import fieldProperties.*;
/**
 * A simple model of a lion.
 * Lions age, reproduce, move, eat rabbits and foxes, and die.
 *
 * @version 2.0
 */
public class Lion extends Animal
{
    // Characteristics shared by all lions (class variables).
    
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Fields relating to reproduction that will be parsed to the gender object
    private static final int BIRTHING_RADIUS = 1;
    private static final int MATING_RADIUS = 4;
    private static final int MIN_MATING_AGE = 15; //inclusive
    private static final int MAX_MATING_AGE = 150; //inclusive
    private static final int MAX_OFFSRPING = 1;
    private static final double PREGNANCY_CHANCE = 0.7;
    private static final int PREGNANCY_PERIOD = 7;
    private static final int[] AWAKE_TIME = {15*60 + 30, 19*60};
    
    // one food allows for one step/movement in the simulation
    // How much food the lion gives if it is eaten
    private static final int FOOD_VALUE = 0;    //set to 0 to satisfy abstract method
    // How much food a lion can eat
    private static final int MAX_FOOD_LEVEL = 18;
    
    // The ghostField is the invisible field where plants exist
    // Foxes eat rabbits and rabbits are initialised with a ghostField so a fox needs this field
    private static Field ghostField;
    
    // The dummy location is not actually on the grid
    private static final Location dummyLocation = new Location(-1,-1);
    // Because of the dummy location this instance of food is not placed on the field
    // If the lion gets more prey in the future add it to this array
    private final Actor[] foods = {new Rabbit(true, getField(), dummyLocation, ghostField), 
                                    new Deer(true, getField(), dummyLocation, ghostField),
                                    new Fox(true, getField(), dummyLocation, ghostField)};
    
    private static HashMap<String, Integer> death = new HashMap<>();

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location, Field ghostField)
    {
        super(field, location, ghostField, MAX_AGE, MATING_RADIUS, MIN_MATING_AGE, MAX_MATING_AGE,
        MAX_OFFSRPING, PREGNANCY_PERIOD, PREGNANCY_CHANCE, BIRTHING_RADIUS,
        MAX_FOOD_LEVEL, FOOD_VALUE,
        AWAKE_TIME, death);
        
        setFoodSource(foods);   //set food source after creating the Animal object as it's not static
        this.ghostField = ghostField;
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(MAX_FOOD_LEVEL));
        }
        else {
            setAge(0);
            setFoodLevel(MAX_FOOD_LEVEL);
            // All animals start with being fertile, but a newborn is not fertile
            getGender().toggleFertility();
        }
    }
    
    /**
     * @return The name of the animal: lion
     */
    @Override
    public String toString()
    {
        return "lion";
    }
    
    /**
     * Lion is a carnivore so call the carnivoreFindFood method from Animal class
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        return carnivoresFindFood();
    } 

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free nearby locations.
     * @param newLions A list to return newly born lions.
     */
    public void giveBirth(List<Actor> newLions)
    {
        // The animal can only give birth when their pregnancy counter is at its maximum
        Gender gender = getGender();
        if (gender.getPCounter() != PREGNANCY_PERIOD-1) return;
        // New lions are born into adjacent locations.
        // Get a list of nearby free locations.
        Field field = getField();
        List<Location> free = field.getFreeNearbyLocations(getLocation(), BIRTHING_RADIUS);
        int births = gender.breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc, ghostField);
            newLions.add(young);
        }
        gender.incrementPCounter();
    }
    
    
}
