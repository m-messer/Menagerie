package actors;

import java.util.List;
import java.util.HashMap;
import fieldProperties.*;

/**
 * Grass is a fast spreading, not very filling.
 *
 * @version 1.0
 */
public class Grass extends Plant
{
    private static final int GROWTH_RADIUS = 1;
    private static final double GROWTH_PROBABILITY = 0.2;
    
    private static final int FOOD_VALUE = 4;
    
    private static HashMap<String, Integer> death = new HashMap<>();
    
    /**
     * Create some grass. Grass does not age nor get hungry.
     * @param ghostField The field plants do their thing.
     * @param locaiton Where the plant is in the ghostField.
     */
    public Grass(Field ghostField, Location location)
    {
        super(ghostField, location, GROWTH_RADIUS, GROWTH_PROBABILITY, death);
    }

    /**
     * @return The name of the plant: grass.
     */
    @Override
    public String toString()
    {
        return "grass";
    }
    
    /**
     * Grass repoduces by spreading.
     * @param newGrass THe patches of grass created after the spread.
     */
    public void spread(List<Actor> newGrass)
    {
        Field ghostField = getField();
        
        if (getLocation() == null) {
            return;
        }
        List<Location> free = ghostField.getFreeNearbyLocations(true, getLocation(), GROWTH_RADIUS);
        int spawn = multiply(free.size());
         
        for(int s = 0; s < spawn && free.size() > 0; s++) {
            Location loc = free.remove(0);
            Grass young = new Grass(ghostField, loc);
            newGrass.add(young);
        }
         
    }
    
    /**
     * @return The grass's food value
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
}
