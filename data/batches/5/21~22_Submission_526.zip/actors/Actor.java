package actors;

import java.util.List;
import java.util.HashMap;
import fieldProperties.*;

/**
 * An actor is something that takes up grid space in the field
 * and interacts with other Actors. Everything that is in the grid is an actor.
 *
 * @version 1.0
 */
public abstract class Actor
{
    private boolean alive;
    private Field field;
    private Location location;
    //stores the numbers of deaths caused by being eaten or other reasons
    private HashMap<String, Integer> death; //Key contains the reason
    
    /**
     * Create a new actor in the field 
     * @param field The grid the actor exists on
     * @param location The coordinates of the cell that the actor occupies in the grid
     */
    public Actor(Field field, Location location, HashMap<String, Integer> death)
    {
        this.field = field;
        alive = true;
        this.location = location;
        this.death = death;
        setLocation(location);
    }
    
    /**
     * Every Actor can act
     * Pass in current hour for animals
     * @param object The object that is modified by the process of acting
     */
    abstract public void act(List<Actor> object, int min);
    
    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    public Field getField()
    {
        return field;
    }
    
    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    public Location getLocation()
    {
        return location;
    }
    
    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    public void setDead(String reason)
    {
        death.merge(reason, 1, Integer::sum);
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        // This check allows my to create an instance of an Actor that is not on the grid
        if (location.getRow()<0 || location.getCol()<0) {
            return;
        }
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    
    }
    
    /**
     * The actor food value determines how far another actor can move if it eats it.
     * @return The actor's food value.
     */
    abstract public int getFoodValue();
    
    public HashMap<String,Integer> getDeath()
    {
        return death;
    }
}
