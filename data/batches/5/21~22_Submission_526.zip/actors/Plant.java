package actors;

import java.util.List;
import java.util.Random;
import java.util.HashMap;
import fieldProperties.*;

/**
 * Plants spawn randomly and spread.
 *
 * @version 1.0
 */
public abstract class Plant extends Actor
{
    private int maxGrowthDistance;
    private double growthProb;
    private Random rand;
    private static HashMap<String, Integer> death;
    // A plant can spread if it is spreadable
    // Static so if one plant is declared as spreadable then all the others are, wastes less time looping
    private boolean spreadable;
    
    /**
     * Create a new plant in a field that exists underneath the animal field.
     * 
     * @param maxGrowthDistance The maximum number of grid cells a plant can grow to in one step.
     * @param growthProbability The chance that the plant grows in a cell it can grow.
     */
    public Plant(Field field, Location location, int maxGrowthDistance, double growthProbability, HashMap<String, Integer> death)
    {
        super(field, location, death);
        this.maxGrowthDistance = maxGrowthDistance;
        growthProb = growthProbability;
        rand = new Random();
        spreadable = false;
    }
    
    /**
     * At the moment plants can only spread.
     * @param newPlant The new plants that are generated after the plant has spread.
     * @param min Current minute of the day
     */
    public void act(List<Actor> newPlant, int min)
    {
        if (!spreadable) return;
        spread(newPlant);
    }
    
    /**
     * The plant version of repodruction - does not require a mate.
     * @param newPlants The new plants that are created after the original plant spreads.
     */
    abstract public void spread(List<Actor> newPlants);
    
    /**
     * Generate the number of new plants depending on the number of nearby free locations
     * and the growth probability.
     * @return The number of new plants.
     */
    protected int multiply(int nearbySize)
    {
        int count = 0;
        for (int i=0; i<nearbySize; i++) {
            if (rand.nextDouble()<growthProb) {
                count++;
            }
        }
        return count;
    }
    
    public boolean isSpreadable()
    {
        return spreadable;
    }
    
    public void toggleSpreadable()
    {
        spreadable = !spreadable;
        //spreadable = true;
    }
}
