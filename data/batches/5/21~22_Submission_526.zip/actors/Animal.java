package actors;

import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.HashMap;
import fieldProperties.*;
import events.Disease;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2.0
 */
public abstract class Animal extends Actor
{   
    private Gender gender;
    
    // Fog can reduce the mating radius of animals
    private int mDistance;
    private final int backupMDistance;
    private final int minMAge;
    private final int maxMAge;
    private final int maxOffspring;
    private final double pChance;
    private final int pPeriod;
    private final int bDistance;
    private final int maxFoodLevel;
    private final int foodValue;
    private final int maxAge;
    private final int[] awakeTime; //wake and sleep time at index 0 and 1 respectively; in minute format (0-23*60+59)   
    
    private Field ghostField;
    private Actor[] foodSource;
    
    private int age;
    private int foodLevel;
    
    // Fields related to disease
    private Disease disease;
    private boolean infected;
    private boolean immune;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, Field ghostField, int maxAge,
    int matingDistance, int minMatingAge, int maxMatingAge, int maxOffspring, int pregnancyPeriod, double pregnancyChance, int birthDistance,
    int maxFoodLevel, int foodValue, int[] wake, HashMap<String, Integer> death)
    {
        super(field, location, death);
        
        this.ghostField = ghostField;
        
        this.maxAge = maxAge;
        
        mDistance = matingDistance;
        backupMDistance = matingDistance;
        minMAge = minMatingAge;
        maxMAge = maxMatingAge;
        this.maxOffspring = maxOffspring;
        pChance = pregnancyChance;
        pPeriod = pregnancyPeriod;
        bDistance = birthDistance;
        
        foodSource = null;
        this.maxFoodLevel = maxFoodLevel;
        this.foodValue = foodValue;
        
        awakeTime = wake;
        chooseGender();
        
        disease = new Disease();
        infected = false;
        immune = false;
    }
    
    /**
     * Run the routine that deals with all scenarios related to disease and infections.
     */
    private void diseaseRoutine()
    {
        if (immune) return;
        
        Random rand  = new Random();
    
        if (disease.isInEffect()) {
            spreadInfection(rand);
            if (rand.nextDouble()<Disease.DEATH_CHANCE) {
                setDead("Disease");
                return;
            }
            disease.incrementDurationCounter();
            // If the animal has passed the duration of the disease then it can never get the disease again
            if (disease.getDurationCounter()==0) {
                infected = false;
                immune = true;
            }
            return;
        }
        // Every animal has a base chance of randomly becoming infected
        if (rand.nextDouble()<Disease.PASSIVE_INFECTION_CHANCE) {
            becomeInfected();
        }
    }
    
    /**
     * If the animal is infected then there is a chance it could spread it to other animals in the nearby area.
     */
    private void spreadInfection(Random rand)
    {
        if (getLocation()==null) return;
        ArrayList<Animal> nearbyAnimals = getField().anyNearbyAnimal(getLocation(), Disease.SPREAD_RADIUS);
        for (Animal animal: nearbyAnimals) {
            if (rand.nextDouble()<Disease.SPREAD_CHANCE) {
                if (!animal.isImmune() && !animal.isInfected()) {
                    animal.becomeInfected();
                }
            }
        }
    }
    
    /**
     * @return Whether the animal is immune.
     */
    public boolean isImmune()
    {
        return immune;
    }
    
    /**
     * @return Whether the animal is infected.
     */
    public boolean isInfected()
    {
        return infected;
    }
    
    /**
     * The animal enters an infected state
     */
    public void becomeInfected()
    {
        infected = true;
        disease.incrementDurationCounter();
    }
    
    /**
     * @param newDistance Is the distance which fog will limit mating for all animals.
     */
    public void changeMatingDistance(int newDistance)
    {
        mDistance = newDistance;
    }
    
    /**
     * If the mating distance was changed then we can revert the mating distance to
     * what it was originally defined as.
     */
    public void revertMatingDistance()
    {
        mDistance = backupMDistance;
    }
    
    /**
     * @param fd Array of food source of animal
     */
    protected void setFoodSource(Actor[] fd)
    {
        foodSource = fd;
    }
        
    /**
     * This is what the animal does most of the time: it hunts for food
     * In the process, it might breed, die of hunger, or die of old age
     * @param newAnimals A list to return newly born animals.
     * @param min current minute of the day
     */
    public void act(List<Actor> newAnimals, int min)
    {
        // Disease cares little for sleep
        diseaseRoutine();
        if (checkAwake(min)) {
            //only act if the animal is awake
            incrementAge();
            incrementHunger();
            if(isAlive()) {
                // If the animal isn't fertile but in the fertile age range then toggle
                Gender gender = getGender();
                if (!gender.isFertile() && age>=minMAge && age<=maxMAge) {
                    gender.toggleFertility();
                }
                
                // If the animal is fertile but outside the fertile age range then toggle
                if (gender.isFertile() && (age<minMAge || age>maxMAge)) {
                    gender.toggleFertility();
                }
                
                // If the animal is already pregnant increment its pregnancy counter
                if (gender.getPCounter()>0) {
                    gender.incrementPCounter();
                }
                // I don't need to distinguish between male and female
                // since male animals can never get pregant nor give birth
                getPregnant();
                giveBirth(newAnimals);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead("Overcrowding");
                }
            }
        }
    }
    
    /**
     * Randomly generate a zero or a one
     * @return A zero or one
     */
    private int randBinary()
    {
        // zero is male and one is female
        Random binary = new Random();
        return binary.nextInt(2);
    }
    
    /**
     * If a zero was generated then choose male.
     * If a one was generated then choose female.
     */
    private void chooseGender()
    {
        if (randBinary()==0) {
            gender = new Male(mDistance, minMAge, maxMAge);
            return;
        }
        gender = new Female(mDistance, minMAge, maxMAge, maxOffspring, pPeriod, pChance);
    }
    
    /**
     * @return The animal's gender
     */
    public Gender getGender()
    {
        return gender;
    }

    
    /**
     * After the female's pregnancy counter reaches its maximum it gives birth
     * @param newAnimals The female's offspring
     */
    abstract public void giveBirth(List<Actor> newAnimals);
    
    /**
     * Check whether the fox can get pregnant. If it can scan the nearby area for mates.
     * If the female fox mates with a male fox it becomes pregnant.
     */
    public void getPregnant()
    {
        // If pCounter is not zero then the animal is pregnant
        Gender gender = getGender();
        if (!gender.isFertile() || gender.getPCounter() > 0) return;

        // Get the number of males in the nearby area
        int maleCount  = getField().nearbyAnimalCount(getLocation(), mDistance, this);
        Random currentRand = new Random();
        
        // When the female succeeds in mating with a male exit the loop
        for (int i = 0; i < maleCount; i++) {
            if (currentRand.nextDouble() <= pChance) {
                gender.incrementPCounter();
            }
            break;
        }
    }

    /**
     * set the age for the animal
     */
    protected void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * @return age of animal
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead("Aging");
        }
    }
    
    /**
     * Set food level
     */
    protected void setFoodLevel(int level)
    {
        foodLevel = level;
    }
    
    /**
     * Make animal more hungry. This could result in animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead("Hunger");
        }
    }
    
    /**
     * Abstract class for finding food as animal may eat plants/animals
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood();
    
    /**
     * find food method for carnivores
     */
    protected Location carnivoresFindFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Actor actor = (Actor) field.getObjectAt(where);
            // Modified to sweep through all the potential foods of the animal
            // If a food is found return its location
            if(actor != null && actor.isAlive()) {
                for (int i = 0; i < foodSource.length; i++) {
                    Actor food = foodSource[i];
                    if(food.toString().equals(actor.toString())) {
                        //check if the animal would be too full after eating
                        if (foodLevel + actor.getFoodValue() < maxFoodLevel * 1.5){
                            Animal animal = (Animal) actor;
                            actor.setDead(this.toString());
                            foodLevel += actor.getFoodValue();
                            return where;
                        }
                    }
                }
            }
        }
        return null;
    }
    
    /** 
     * Find food method for herbivores
     */
    protected Location herbivoresFindFood()
    {
        Field field = getField();
        List<Location> adjacent = ghostField.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Actor actor = (Actor) ghostField.getObjectAt(where);
            // If there is an animal ontop of the plant then the rabbit can't eat it since it wont't be
            // able to move to the food's location because it is occupied by another animal
            if (field.getObjectAt(where) instanceof Plant) {
                // Modified to sweep through all the potential foods of the animal
                // If a food is found return its location and make that food dead
                if(actor != null && actor.isAlive()) {
                    for (int i = 0; i<foodSource.length; i++) {
                        Actor food = foodSource[i];
                        if(food.toString().equals(actor.toString())) {
                            if (foodLevel + actor.getFoodValue() <= maxFoodLevel * 2) {
                                //check if animal would be too full after eating
                                actor.setDead(this.toString());
                                foodLevel += actor.getFoodValue();
                                return where;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Each Actor has a food value, if another actor eats this actor then
     * it will be given an amount of food specified by the food value.
     * @return The food's food value.
     */
    public int getFoodValue()
    {
        return foodValue;
    }
    
    
    /**
     * aniamls may sometimes be awake at night
     * @return whether the animal is awake
     */
    private Boolean getRandomAwake()
    {
        Random rand = new Random();
        return (rand.nextDouble() <= 0.01);
    }
    
    /**
     * Checking if animal is awake by seeing if current minute since 00:00 is 
     * in the awake time range or if the animal is acting randomly 
     * @return whether animal is awake
     */
    private Boolean checkAwake(int currentMin)
    {
        return ((awakeTime[0] <= currentMin && currentMin <= awakeTime[1]) || getRandomAwake());
    }
}
