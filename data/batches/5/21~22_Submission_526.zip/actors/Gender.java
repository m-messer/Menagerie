package actors;

/**
 * Every animal must have a Gender.
 *
 * @version 1.0
 */
public abstract class Gender
{
    private final int mDistance;
    private final int minMAge;
    private final int maxMAge;
    private boolean fertile;
    
    /**
     * Construct a Gender
     * @param matingDistance The maximum distance a male and female can mate
     * @param minMatingAge The animal is infertile when younger than this age
     * @param maxMatingAge The animal is infertile when older than this age
     */
    protected Gender(int matingDistance, int minMatingAge, int maxMatingAge)
    {
        mDistance = matingDistance;
        minMAge = minMatingAge;
        maxMAge = maxMatingAge;
        fertile = true;
    }
    /**
     * @return the animal's mating distance
     */
    protected int getMatingDistance()
    {
        return mDistance;
    }
    
    /**
     * @return The minimum age an animal is fertile
     */
    protected int getMinMatingAge()
    {
        return minMAge;
    }
    
    /**
     * @return The maximum age an animal is fertile
     */
    protected int getMaxMatingAge()
    {
        return maxMAge;
    }
    
    /**
     * @return Whether the animal is fertile
     */
    protected boolean isFertile()
    {
        return fertile;
    }
    
    /**
     * Toggle the animal's fertility
     */
    protected void toggleFertility()
    {
        fertile = !fertile;
    }
    
    /**
     * Increment the counter that tracks the animal's pregnancy
     */
    abstract void incrementPCounter();
    
    /**
     * @return The number of children the animal births
     */
    abstract int breed();
    
    /**
     * @return the counter that tracks the animal's pregnancy
     */
    abstract int getPCounter();
}
