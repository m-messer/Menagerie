/**
 * Deal with time during simulation depending on the steps
 *
 * @version 1.0
 */
public class Time
{
    int hour;
    int min;
    /**
     * @param step The time interval
     */
    public Time(int step)
    {
        hour = (step / 60) % 24;
        min = step % 60;
    }
    
    /**
     * @return Return the time in HH:mm format
     */
    public String getTime()
    {
        String hourString = Integer.toString(hour);
        String minString = Integer.toString(min);
        if (hour < 10) {
            hourString = "0" + hourString;
        }
        
        if (min < 10) {
            minString = "0" + minString;
        }
        
        return hourString + ":" + minString;
    }
    
    /**
     * @return current minute since 00:00
     */
    public int getMin()
    {
        return hour * 60 + min;
    }
    
}