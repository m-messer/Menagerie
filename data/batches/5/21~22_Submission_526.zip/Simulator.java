import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.Collections;
import java.util.stream.Stream;

import events.*;
import fieldProperties.*;
import actors.*;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 3.0
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.05;
    // The probability that a rabbit will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.12;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.2;
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.5;
    // The probability that grass will spawn randomly in any given grid position.
    private static final double GRASS_SPAWN_PROBABILITY = 0.2;
    
    // The probabilities for certain types of weather ocurring
    private static final double STANDARD_WEATHER_PROBABILITY = 0.5;
    private static final double RAIN_PROBABILITY = 0.5;
    private static final double FOG_PROBABILITY = 0.1;
    private static final double SNOW_PROBABILITY = 0.1;
    private static final double WEATHER_FACTOR = 1000;
    
    private static final int FOG_MATING_DISTANCE = 2;
    private static final double FREEZE_CHANCE = 0.05;
    
    // Where the weighted weather types are stored
    private ArrayList<WeatherTypes> weather;
    
    // Keep track of the current weather phenomena
    // There can only be one type of weather phenomena at a time
    // The current weather enum
    private WeatherTypes currentWNum;
    // Everytime a weather phenomena occurs its added to this list
    private ArrayList<Weather> recordedWeather;
    
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    
    // A graphical view of the simulation.
    private SimulatorView view;
    
    // An invisible field underneath the main field where plants exist
    private Field ghostField;
    // List of actors that exist in the ghost field and visible field
    private List<Actor> actors;
    //List of distinct types of actors that exists
    private ArrayList<Actor> actorTypes;
    //for exporting data to external file
    private Export external;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);
        ghostField = new Field(depth, width);
        
        weather = new ArrayList();
        weightWeatherProbabilities();
        currentWNum = WeatherTypes.STANDARD;
        recordedWeather = new ArrayList<>();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Deer.class, Color.PINK);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Disease.class, Color.BLACK);
        
        external = new Export();
        actorTypes = new ArrayList<>();
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Create a list of weather enums that simulates the different weather phenomena having weighted probabilities
     */
    private void weightWeatherProbabilities()
    {
        // Convert the decimal weather probabilities to whole numbers.
        int standardNum = (int) (STANDARD_WEATHER_PROBABILITY*WEATHER_FACTOR);
        int rainNum = (int) (RAIN_PROBABILITY*WEATHER_FACTOR);
        int fogNum = (int) (FOG_PROBABILITY*WEATHER_FACTOR);
        int snowNum = (int) (SNOW_PROBABILITY*WEATHER_FACTOR);
        
        // Add an instance of each the weather enum to the weather list for each whole number that corresponds to that type.
        for (int i = 0; i < standardNum; i++) {
            weather.add(WeatherTypes.STANDARD);
        }
        for (int i = 0; i < rainNum; i++) {
            weather.add(WeatherTypes.RAIN);
        }
        for (int i = 0; i < fogNum; i++) {
            weather.add(WeatherTypes.FOG);
        }
        for (int i = 0; i < snowNum; i++) {
            weather.add(WeatherTypes.SNOW);
        }
    }
    
    /**
     * A weather phenoma is randomly picked and executed
     */
    private void pickWeather()
    {
        Collections.shuffle(weather);
        currentWNum = weather.get(0);
        Weather currentWeather = currentWNum.getWeatherType();
        switch (currentWNum) {
            case STANDARD:
                break;
                
            case RAIN:
                currentWeather.effect();
                recordedWeather.add(currentWeather);
                // Plants can only grow when it rains
                for (Actor actor: actors) {
                    if (actor instanceof Plant) {
                        Plant plant = (Plant) actor;
                        if (!plant.isSpreadable()) {
                            plant.toggleSpreadable();
                        }
                    }
                }
                break;
                
            case FOG:
                currentWeather.effect();
                recordedWeather.add(currentWeather);
                // Fog reduces all animals' mating distances
                for (Actor actor: actors) {
                    if (actor instanceof Animal) {
                        Animal animal = (Animal) actor;
                        animal.changeMatingDistance(FOG_MATING_DISTANCE);
                    }
                }
                break;
                
            case SNOW:
                Random rand = new Random();
                currentWeather.effect();
                recordedWeather.add(currentWeather);
                // When it snows there is a chance that any actor can freeze and die
                for (Actor actor: actors) {
                    if (rand.nextDouble()<FREEZE_CHANCE) actor.setDead("Freeze");
                }
        }
    }
    
    /**
     * Checks whether the current weather phenomena's time is up
     */
    private boolean IsCurrentWeatherInEffect()
    {
        // Standard weather returns null
        if (currentWNum.getWeatherType()==null) return false;
        return currentWNum.getWeatherType().isInEffect();
    }
    
    /**
     * Reverts mating distance back to normal for animals.
     * Reverts plants' spreadability back to false so they can't spread.
     */
    private void weatherRevert()
    {
        if (currentWNum == WeatherTypes.FOG) {
            for (Actor actor: actors) {
                if (actor instanceof Animal) {
                    Animal animal = (Animal) actor;
                    animal.revertMatingDistance();
                }
                if (actor instanceof Plant) {
                    Plant plant = (Plant) actor;
                    if (plant.isSpreadable()) {
                        plant.toggleSpreadable();
                    }
                }
            }
        }
    }
    
    /**
     * Increment the current weather phenomena's duration counter.
     * If the counter is zero perform a fog revert and pick a new weather phenomena to replace the current one.
     */
    private void executeWeather()
    {
        
        if (IsCurrentWeatherInEffect()) {
            currentWNum.getWeatherType().incrementDurationCounter(1000);
        }
        else {
            // If the fog has ended then restore the proper mating distances of the animals
            // before picking a new weather phenomena
            weatherRevert();
            pickWeather();
        }
        
    }
    
    /**
     * @return The weather report as a list of Strings.
     */
    private ArrayList<String> generateWeatherReport()
    {
        Weather rain = WeatherTypes.RAIN.getWeatherType();
        Weather fog = WeatherTypes.FOG.getWeatherType();
        Weather snow  = WeatherTypes.SNOW.getWeatherType();
        
        int rainCount = calculateNoOccurrences(rain);
        int fogCount = calculateNoOccurrences(fog);
        int snowCount = calculateNoOccurrences(snow);
        
        ArrayList<String> report = new ArrayList<>();
        String rainString = "Rain: "+rainCount+" occasions.";
        String fogString = "Fog: "+fogCount+" occasions.";
        String snowString = "Snow: "+snowCount+" occasions.";
        report.add(rainString);
        report.add(fogString);
        report.add(snowString);
        return report;
    }
    
    /**
     * @param phenomena The type of weather phenoma the method will sum.
     * @return The sum of occasions a certain type of weather phenomena occurred.
     */
    private int calculateNoOccurrences(Weather phenomena)
    {
        return recordedWeather.stream().filter(w -> w == phenomena)
        .map(w -> 1).reduce(0, (total, count) -> total + count);
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(2400);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
         
        external.finalReport(actorTypes, generateWeatherReport());
        external.closeWriter();     //close the file writer
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    // Every plant refers to the ghost field and not the visible field so I can use both animals and plants
    // under the disguise of actors becuase they reference different fields
    public void simulateOneStep()
    {
        step++;
        //to get current time to determine if the animal is awake
        Time currentTime = new Time(step);
        int min = currentTime.getMin();
        // Provide space for new actors.
        List<Actor> newActors = new ArrayList<>();
        // Update the weather by either decreasing the current weather's duration or choosing a new weather phenomena
        executeWeather();
        int count = 0;
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            count = diseaseChecker(actor, count);
            actor.act(newActors, min);
            if(! actor.isAlive()) {
                it.remove();
            }
            addActorTypes(actor);
        }
        //Update log every 30 minutes
        if (step % 30 == 0){
            external.exportData(actorTypes, currentTime.getTime(), step);
        } 
        
        Disease.setInfectedCount(count);      
        // Add the newly born actors to the main lists.
        actors.addAll(newActors);
        // Add more plants randomly
        addMorePlants();
        overlayFields();
        view.showStatus(step, field);
    }
    
    /**
     * If the animal is infected then increment the counter that tracks infections.
     * @actor The actor we are checking.
     * @count The count that tracks infections within one step of the simulation.
     */
    private int diseaseChecker(Actor actor, int count)
    {
        if (actor instanceof Animal) {
            Animal animal = (Animal) actor;
            if (animal.isInfected()) count++;
        }
        return count;
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        recordedWeather.clear();
        populate();
        populateGhostField();
        Disease.setInfectedCount(0);
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * To check if the type of actor has already exists in the array
     * @param actor the actor to be checked and added
     */
    private void addActorTypes(Actor actor)
    {
        for (Actor actorType : actorTypes) {
            if (actorType.toString().equals(actor.toString())) {
                return;
            }
        }
        actorTypes.add(actor);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                double prob = rand.nextDouble();        // Ken: store as variable to prevent rabbit benefitting too much from this)
                if (prob <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location, ghostField);
                    actors.add(lion);
                }
                else if(prob <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location, ghostField);
                    actors.add(fox);
                }
                else if (prob <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location, ghostField);
                    actors.add(deer);
                }
                else if(prob <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location, ghostField);
                    actors.add(rabbit);
                }
                // else leave the location empty.
            }
        }
    }
        
    /**
     * Randomly populate the ghost field with plants
     */
    private void populateGhostField()
    {
        Random rand = Randomizer.getRandom();
        ghostField.clear();
        for(int row = 0; row < ghostField.getDepth(); row++) {
            for(int col = 0; col < ghostField.getWidth(); col++) {
                
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location loc = new Location(row, col);
                    Grass grass = new Grass(ghostField, loc);
                    actors.add(grass);
                }
                // else leave the location empty.
            }
        }
        overlayFields();
    }
    
    /**
     * This allows grass to randomly spawn midway through the simulation.
     * Alongside it growing.
     * It simulates the effect of plants' roots and seeds.
     */
    private void addMorePlants()
    {
        Random rand = Randomizer.getRandom();
        ArrayList<Location> free = ghostField.anyFreeSpace();
        for (Location space: free) {
            if (rand.nextDouble()<GRASS_SPAWN_PROBABILITY) {
                Grass grass = new Grass(ghostField, space);
                actors.add(grass);
            }
        }
    }
    
    /**
     * Diplay a plant in the visible field if there is not animal in its location and it exists
     * in the ghost field. If the plant exists in the visible field at a certain location but does not
     * in the ghost field then remove it from the visible field.
     */
    private void overlayFields()
    {
        for(int row = 0; row < ghostField.getDepth(); row++) {
            for(int col = 0; col < ghostField.getWidth(); col++) {
                Location loc = new Location(row, col);
                if (field.getObjectAt(loc) == null) {
                    field.place(ghostField.getObjectAt(loc), loc);
                }
                
                else if (field.getObjectAt(loc) instanceof Plant && 
                ghostField.getObjectAt(loc) == null) {
                    field.clear(loc);
                }
            }
        }        
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}

