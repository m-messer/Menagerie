package events;

/**
 * As of now there is only one type of disease and it can only affect animals.
 * An infected animal gives birth to animal that is not infected.
 * Any animals nearby an infected animal have a chance of being infected.
 *
 * @version 1.0
 */
public class Disease
{
    public static final int DURATION = 5;
    public static final double DEATH_CHANCE = 0.2;
    public static final double SPREAD_CHANCE = 0.04;
    public static final int SPREAD_RADIUS = 2;
    public static final double PASSIVE_INFECTION_CHANCE = 0.01;
    private int durationCounter;
    private boolean inEffect;
    public static int infectedCounter = 0;
    
    /**
     * Contructor for disease.
     */
    public Disease()
    {
        durationCounter = 0;
        inEffect = false;
    }
    
    /**
     * Increment the counter that tracks the disease's duration.
     * If the counter is not zero then the disease is in effect.
     */
    public void incrementDurationCounter()
    {
        durationCounter = (durationCounter+1)%DURATION;
        inEffect = true;
        if (durationCounter == 0) {
            inEffect = false;
        }
    }
    
    /**
     * @return The counter that tracks the disease's duration.
     */
    public int getDurationCounter()
    {
        return durationCounter;
    }
    
    /**
     * @retrun Whether the disasese is currently in effect.
     */
    public boolean isInEffect()
    {
        return inEffect;
    }
    
    /**
     * @return The total number of animals currently infected.
     */
    public static int getNumberInfected()
    {
        return infectedCounter;
    }
    
    /**
     * @param count The number of animals that are currently infected in the grid.
     */
    public static void setInfectedCount(int count)
    {
        infectedCounter = count;
    }
}
