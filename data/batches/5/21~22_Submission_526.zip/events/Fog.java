package events;

import fieldProperties.*;
import actors.*;
/**
 * When its foggy the mating distance of all animals is reduced.
 *
 * @version 2.0
 */
public class Fog extends Weather<Actor>
{
    private static final Field dummyField = new Field(1,1);
    private static final Location dummyLocation = new Location(-1,-1);
    private static final Actor[] AFFECTED= {new Lion(true, dummyField, dummyLocation, dummyField),
    new Fox(true, dummyField, dummyLocation, dummyField),
    new Rabbit(true, dummyField, dummyLocation, dummyField),
    new Deer(true, dummyField, dummyLocation, dummyField)};
    private static final int[] POSSIBLE_DURATIONS = {10,30,50};
    
    /**
     * Constructor for objects of class Fog
     */
    public Fog()
    {
        super(AFFECTED, POSSIBLE_DURATIONS);
    }
    
    /**
     * @return The name of the weather: 'fog'
     */
    @Override
    public String toString()
    {
        return "fog";
    }
}
