package events;

/**
 * This class acts as a bank containing an instance of each weather phenomena for the simulation to use.
 *
 * @version 2.0 
 */
public enum WeatherTypes
{
    RAIN(new Rain()), FOG(new Fog()), SNOW(new Snow()), STANDARD(null);
    
    private Weather weatherType;
    
    /**
     * @return The type of weather that is associated with its enum.
     */
    public Weather getWeatherType()
    {
        return this.weatherType;
    }
    
    /**
     * @param weatherType The weather phenomena that is assoicated with its enum.
     */
    private WeatherTypes(Weather weatherType)
    {
        this.weatherType = weatherType;
    }
}
