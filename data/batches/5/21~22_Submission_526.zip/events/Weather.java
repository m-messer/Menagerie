package events;
import java.util.Random;
/**
 * Weather can vary a lot but all types of weather last for a certain amount of time,
 * have an effect and a demographic that are affected by their effect.
 *
 * @version 2.0
 */
public class Weather<T>
{
    private T[] affected;
    private int[] possibleDurations;
    private static final Random rand = new Random();
    private boolean inEffect;
    private int counter;
    private int currentDuration;
    private int totalDuration;
    private int latestStep;
    
    /**
     * @param affected The actors that are affected by this weather.
     * @param possibleDurations The different number of steps the weather phenomena can potentially last.
     */
    public Weather(T[] affected, int[] possibleDurations)
    {
        this.affected = affected;
        this.possibleDurations = possibleDurations;
        inEffect = false;
        counter = 0;
        currentDuration = calculateDuration();
        totalDuration = currentDuration;
    }
    
    /**
     * @return The actors that are affected by this weather.
     */
    public T[] getThoseAffected()
    {
       return affected;
    }
    
    /**
     * The weather is now in effect.
     */
    public void effect()
    {
        counter = 1;
        inEffect = true;
    }
    
    /**
     * @return The duration that is picked from the array of possible durations.
     */
    public int calculateDuration()
    {
        int noDurations = possibleDurations.length;
        int pick = rand.nextInt(noDurations);
        
        return possibleDurations[pick];
    }
    
    /**
     * @return Whether this weather phenomena is currently affecting actors on the grid.
     */
    public boolean isInEffect()
    {
        return inEffect;
    }
    
    /**
     * @param finalStep The supposed final step of the simulation.
     */
    public void incrementDurationCounter(int finalStep)
    {
        counter = (counter + 1)%currentDuration;
        if (counter == 0) {
            inEffect = false;   
            currentDuration = calculateDuration();
            // This stops the last weather phenomena from reporting a duration that's longer
            // how long it actually lasted
            if (finalStep-totalDuration<currentDuration) {
                totalDuration += finalStep-totalDuration;
                return;
            }
            totalDuration += currentDuration;
        }
    }
    
    /**
     * @return The total number of steps this weather phenomena has occurred for.
     */
    public int getTotalDuration()
    {
        return totalDuration;
    }
    
}
