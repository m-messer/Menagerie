package events;

import fieldProperties.*;
import actors.*;
/**
 * Rain allows plants to grow
 *
 * @version 1.0
 */
public class Rain extends Weather<Actor>
{
    private static final Field dummyField = new Field(1,1);
    private static final Location dummyLocation = new Location(-1,-1);
    private static final Actor[] AFFECTED= {new Grass(dummyField, dummyLocation)};
    private static final int[] POSSIBLE_DURATIONS = {20,40,60};
    
    /**
     * Constructor for objects of class Rain
     */
    public Rain()
    {
        super(AFFECTED, POSSIBLE_DURATIONS);
    }
    
    /**
     * @return The name of the weather: 'rain'
     */
    @Override
    public String toString()
    {
        return "rain";
    }
}
