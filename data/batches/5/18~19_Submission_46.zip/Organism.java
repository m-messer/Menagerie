import java.util.List;
import java.util.Random;
import java.util.LinkedList;

/**
 * A class representing shared characteristics and methods 
 * of organisms (which includes plants and animals).
 *
 * @version 2019.02.21
 */
public abstract class Organism
{   
    // Whether the organism is alive or not.
    protected boolean alive;
    // The organism's field.
    protected Field field;
    // The organism's position in the field.
    protected Location location;
    // The organism's age.
    private int age;
    // The current Simulator object.
    protected Simulator currentSimulation;

    /**
     * Create a new organism at a location in the field.
     * 
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current simulator object.
     */
    public Organism(Boolean randomAge, Field field, Location location, Simulator simulator)
    {
        alive = true; // the new organism is alive
        this.field = field; // they are in the current field
        setLocation(location); // they are at the specified location
        age = 0; // they are aged 0
        Random rand = Randomizer.getRandom();
        if(randomAge) {  // if the organism should have a random age       
            age = rand.nextInt(getMaxAge()); // set their age to a random value 
        }
        currentSimulation = simulator; // set the current Simulator object
    }

    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * This method will be overriden by the individual species.
     * @param neworganisms A list to receive newly born organisms.
     */
    abstract public void act(List<Organism> newOrganisms);

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Increment the organism's age.
     */
    public void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Check whether or not this organism is to give birth at this step.
     * New births will be made into free adjacent locations.
     * This will be overriden by individual species.
     * @param newOrganisms A list to return newly born organisms.
     */
    abstract public List<Organism> giveBirth(List<Organism> newOrganisms, Simulator currentSimulation, Organism parent);

    /**
     * An organism can breed if it has reached the breeding age.
     * @return true if the organism can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Get the maximum age for an individual species.
     * @return The maximum age.
     */
    abstract protected int getMaxAge();

    /**
     * Get the breeding age for an individual species.
     * @return The breeding age.
     */
    abstract protected int getBreedingAge();

    /**
     * Get the breeding probability for an individual species.
     * @return The breeding probability.
     */
    abstract protected double getBreedingProbability();

    /**
     * Get the maximum litter size for an individual species.
     * @return The maximum litter size.
     */
    abstract protected int getMaxLitterSize();
}
