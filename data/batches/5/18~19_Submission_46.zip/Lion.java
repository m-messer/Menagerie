import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat all prey, breed, infect others with disease and die.
 * They are also affected by time of day and weather.
 *
 * @version 2019.02.21
 */
public class Lion extends Animal
{
    // Characteristics shared by all Lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single animal. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int ANIMAL_FOOD_VALUE = 25;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Lion. A Lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current Simulator object.
     */
    public Lion(boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(randomAge,field, location, simulator); // uses the Animal constructor
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * antelopes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.
     */
    public void act(List<Organism> newLions)
    {
        incrementAge(); // age the lion
        incrementHunger(); // make the lion more hungry
        if (5<=currentSimulation.getHour() && currentSimulation.getHour()<=21) // if it is daytime
        {
            if(isAlive()) {
                infectOthers(); // pass disease to other animals
                newLions = super.giveBirth(newLions, currentSimulation, this); 
                if (currentSimulation.getWeather().equals("Fire")){
                    // If there is a fire, randomly kill some lions.
                    if(rand.nextFloat() < 0.30){
                        setDead();
                    }
                }
                else if(!currentSimulation.getWeather().equals("Rain")){
                    // Move towards a source of food if found and if it is not raining.
                    Location newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Look for antelopes, zebras, giraffes or elephants adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        // Get nearby locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            // Check what is in each neighbouring cell.
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) { // if there is an antelope nearby
                Antelope antelope = (Antelope) animal;
                if(antelope.isAlive()) { 
                    antelope.setDead();
                    foodLevel = ANIMAL_FOOD_VALUE; // eat the antelope
                    return where;
                }
            }
            if(animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if(zebra.isAlive()) { 
                    zebra.setDead();
                    foodLevel = ANIMAL_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Giraffe) {
                Giraffe giraffe = (Giraffe) animal;
                if(giraffe.isAlive()) { 
                    giraffe.setDead();
                    foodLevel = ANIMAL_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Elephant) {
                Elephant elephant = (Elephant) animal;
                if(elephant.isAlive()) { 
                    elephant.setDead();
                    foodLevel = ANIMAL_FOOD_VALUE;
                    return where;
                }
            }
    }
        return null;
    }

    /**
     * Get the maximum age for a lion.
     * @return The maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Get the breeding age for a lion.
     * @return The breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the breeding probability for a lion.
     * @return The breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Get the maximum litter size for a lion.
     * @return The maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
