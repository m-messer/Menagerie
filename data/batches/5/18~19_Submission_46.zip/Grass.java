import java.util.List;
import java.util.Random;

/**
 * A simple model of a block of grass.
 * Grass ages, breeds, and dies.
 * Grass is affected by fire (a weather type).
 *
 * @version 2019.02.21
 */
public class Grass extends Plant
{
    // Characteristics shared by all grass (class variables).

    // The age at which grass can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which grass can live.
    private static final int MAX_AGE = 40;
    // The likelihood of grass breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create new grass. Grass may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current Simulator object.
     */
    public Grass(boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(randomAge,field, location, simulator);
    }

    /**
     * This is what the grass does most of the time.
     * Sometimes it will breed or die of old age.
     * @param newGrass A list to return newly born grass.
     */
    public void act(List<Organism> newGrass){
        incrementAge();
        if(isAlive()) {
            newGrass = super.giveBirth(newGrass, currentSimulation, this);
            if (currentSimulation.getWeather().equals("Fire")){
                if(rand.nextFloat() < 0.40){
                    setDead();
                }
            }
        }
    }

    /**
     * Get the maximum age for grass.
     * @return The maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Get the breeding age for grass.
     * @return The breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the breeding probability for grass.
     * @return The breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Get the maximum litter size for grass.
     * @return The maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
