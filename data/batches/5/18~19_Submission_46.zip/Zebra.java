import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a zebra.
 * Zebras age, move, eat grass, breed, infect others with disease and die.
 * They are also affected by time of day and weather.
 *
 * @version 2019.02.21
 */
public class Zebra extends Animal
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of grass. In effect, this is the
    // number of steps a zebra can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 10;
    
    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current Simulator object.
     */
    public Zebra(boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(randomAge,field, location, simulator); // uses the Animal constructor
    }

    /**
     * This is what the zebra does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born zebras.
     */
    public void act(List<Organism> newZebras)
    {
        incrementAge(); // age the zebra
        incrementHunger(); // make the zebra more hungry
        if (5<=currentSimulation.getHour() && currentSimulation.getHour()<=21) // if it is daytime
        {
            if(isAlive()) {
                infectOthers(); // pass disease to other animals
                newZebras = super.giveBirth(newZebras, currentSimulation, this); 
                if (currentSimulation.getWeather().equals("Fire")){
                    // If there is a fire, randomly kill some zebras.
                    if(rand.nextFloat() < 0.30){
                        setDead();
                    }
                }
                else if(currentSimulation.getWeather().equals("Heatwave")){
                    // If there is a heatwave, only move every other hour.
                    if(currentSimulation.getHour()%2 != 0){
                        return;
                    }
                }
                
                // Try to find food.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

        /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if(foodLevel<5){
        Field field = getField();
        // Get nearby locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            // Check what is in each neighbouring cell.
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) { // if there is grass nearby
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE; // eat the grass
                    return where;
                }
            }
        }
    }
        return null;
    }
    
    /**
     * Get the maximum age for a zebra.
     * @return The maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Get the breeding age for a zebra.
     * @return The breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the breeding probability for a zebra.
     * @return The breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Get the maximum litter size for a zebra.
     * @return The maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
