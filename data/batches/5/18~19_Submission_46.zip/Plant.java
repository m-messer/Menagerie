import java.util.List;
import java.util.Random;

/**
 * A class representing shared methods and attributes of plants.
 *
 * @version 2019.02.21
 */
public abstract class Plant extends Organism
{
    /**
     * Create a new plant at a location in the field.
     * 
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current simulator object.
     */
    public Plant(Boolean randomAge, Field field, Location location, Simulator simulator)
    {
        // Use the Organism constructor.
        super(randomAge, field, location, simulator);    
    }

    /**
     * Check whether or not this plant is to "give birth" at this step.
     * New "births" will be made into free adjacent locations.
     * @param newPlants A list to return newly "born" plants.
     */
    public List<Organism> giveBirth(List<Organism> newPlants, Simulator currentSimulation, Organism parent){ 
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation()); // find free neighbouring cells
        int births = breed(); // get the number of new plants to create
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if(parent instanceof Grass){ // if the "parent", the current plant, is grass
                Grass young = new Grass(false, field, loc, currentSimulation); // create new grass
                newPlants.add(young);
            }
            else if(parent instanceof Tree){
                Tree young = new Tree(false, field, loc, currentSimulation);
                newPlants.add(young);
            }
        }
        return newPlants;
    }

    /**
     * Generate a number representing the number of births,
     * if the plant can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        Random rand = Randomizer.getRandom();
        int births = 0;
        // Compare a random number between 0 and 1 to the plant's breeding probability.
        if(canBreed() && rand.nextDouble() <= getBreedingProbability() ) {
            // Generate a number between 0 and the maximum number of births for the plant.
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * This is what the plant does during the steps of the simulation.
     * It will be overriden by individual species.
     * @param newPlants A list to return newly "born" plants.
     */
    abstract public void act(List<Organism> newPlants);

}
