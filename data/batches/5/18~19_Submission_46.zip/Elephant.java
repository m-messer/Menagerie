import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an elephant.
 * Elephants age, move, eat grass and trees, breed, infect others with disease and die.
 * They are also affected by time of day and weather.
 *
 * @version 2019.02.21
 */
public class Elephant extends Animal
{
    // Characteristics shared by all elephants (class variables).

    // The age at which an elephant can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which an elephant can live.
    private static final int MAX_AGE = 40;
    // The likelihood of an elephant breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of grass. In effect, this is the
    // number of steps an elephant can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 5;
    // The food value of a single tree.
    private static final int TREE_FOOD_VALUE = 10;

    /**
     * Create a new elephant. an elephant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the elephant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current Simulator object.
     */
    public Elephant(boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(randomAge,field, location, simulator); // uses the Animal constructor
    }

    /**
     * This is what the elephant does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newElephants A list to return newly born elephants.
     */
    public void act(List<Organism> newElephants)
    {
        incrementAge(); // age the elephant
        incrementHunger(); // make the elephant more hungry
        if (5<=currentSimulation.getHour() && currentSimulation.getHour()<=21) // if it is daytime
        {
            if(isAlive()) {
                infectOthers(); // pass disease to other animals
                newElephants = super.giveBirth(newElephants, currentSimulation, this);
                if (currentSimulation.getWeather().equals("Fire")){
                    // If there is a fire, randomly kill some elephants.
                    if(rand.nextFloat() < 0.30){
                        setDead();
                    }
                }
                // Try to find food.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for grass or trees adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if(foodLevel<5){
            Field field = getField();
            // Get nearby locations.
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                // Check what is in each neighbouring cell.
                Object plant = field.getObjectAt(where);
                if(plant instanceof Grass) { // if there is grass nearby
                    Grass grass = (Grass) plant;
                    if(grass.isAlive()) { 
                        grass.setDead();
                        foodLevel = GRASS_FOOD_VALUE; // eat the grass
                        return where;
                    }
                }
                else if(plant instanceof Tree){
                    Tree tree = (Tree) plant;
                    if(tree.isAlive()) { 
                        tree.setDead();
                        foodLevel = TREE_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Get the maximum age for an elephant.
     * @return The maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Get the breeding age for an elephant.
     * @return The breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the breeding probability for an elephant.
     * @return The breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Get the maximum litter size for an elephant.
     * @return The maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
