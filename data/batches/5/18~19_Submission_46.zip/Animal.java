import java.util.List;
import java.util.Random;
import java.util.LinkedList;

/**
 * A class representing shared methods and attributes of animals.
 *
 * @version 2019.02.21
 */
public abstract class Animal extends Organism
{
    // The gender of the animal.
    private boolean isFemale;
    // The disease status of the animal.
    private boolean infected;
    // The time in steps the animal has left before dying from disease.
    private int timeLeft;
    // The current food level (hunger) of the animal.
    protected int foodLevel;

    /**
     * Create a new animal at a location in the field.
     * 
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current simulator object.
     */
    public Animal(Boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(randomAge, field, location, simulator);
        Random rand = Randomizer.getRandom();
        if(randomAge) {
            foodLevel = rand.nextInt(25); // randomize the animal's food level
        }
        else {
            foodLevel = 25;
        }
        isFemale = rand.nextBoolean(); // randomly determine the animal's gender
        infected = (rand.nextFloat() < 0.02); // infect a percentage of new animals created
        timeLeft = 15;
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Get whether or not the animal is infected with disease.
     * @return Whether or not the animal is infected.
     */    
    protected boolean isInfected()
    {
        return infected;
    }

    /**
     * Set the animal to being infected with disease.
     */
    protected void setInfected()
    {
        infected = true;
    }

    /**
     * Infect other neighbouring animals with disease.
     */
    protected void infectOthers()
    {
        if (infected){ // if the current animal is infected
            Random rand = Randomizer.getRandom();
            Object temp;
            // Get the nearby locations
            List<Location> nearby = new LinkedList<>();
            nearby = getField().adjacentLocations(getLocation());
            for(int num=0; num<nearby.size(); num++){
                // Get the species at each neighbouring location
                temp = getField().getObjectAt(nearby.get(num));
                if (temp instanceof Animal){  // if there is an animal nearby              
                    Animal victim =(Animal)temp;
                    // randomly decide whether to infect the animal
                    if(rand.nextFloat() < 0.1)
                    {
                        victim.setInfected();
                    }
                }
            }
        }
    }

    /**
     * Get the animal's gender.
     * @return Whether the animal is female.
     */
    private boolean isFemale()
    {
        return isFemale;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    public List<Organism> giveBirth(List<Organism> newAnimals, Simulator currentSimulation, Organism parent)
    {
        // New animal are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        if(parent instanceof Animal){
            Animal temp = (Animal) parent;
            int births = breed(temp); // get the number of animals to be born
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                if(parent instanceof Antelope){ // if the parent animal is an antelope
                    // Create a new antelope baby.
                    Antelope young = new Antelope(false, field, loc, currentSimulation);
                    newAnimals.add(young);
                }
                else if(parent instanceof Giraffe){
                    Giraffe young = new Giraffe(false, field, loc, currentSimulation);
                    newAnimals.add(young);
                }
                else if(parent instanceof Elephant){
                    Elephant young = new Elephant(false, field, loc, currentSimulation);
                    newAnimals.add(young);
                }
                else if(parent instanceof Zebra){
                    Zebra young = new Zebra(false, field, loc, currentSimulation);
                    newAnimals.add(young);
                }
                else if(parent instanceof Cheetah){
                    Cheetah young = new Cheetah(false, field, loc, currentSimulation);
                    newAnimals.add(young);
                }
                else if(parent instanceof Lion){
                    Lion young = new Lion(false, field, loc, currentSimulation);
                    newAnimals.add(young);
                }
            }
        }
        return newAnimals;
    }

    /**
     * Generate a number representing the number of births,
     * if the animal can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(Animal parent)
    {
        Random rand = Randomizer.getRandom();
        int births = 0;
        // Determine if the animal is an appropriate age and there is an eligible mate in a neighbouring cell.
        if(canBreed() && rand.nextDouble() <= getBreedingProbability() && mateNearby(parent)) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Determine if there is an animal of the same species, 
     * opposite gender and appropriate age in a neighbouring cell.
     * @return Whether or not there is a mate nearby.
     */
    private boolean mateNearby(Animal parent)
    {
        boolean mateNearby = false;
        Object temp;
        // Get the locations of the neighbouring cells.
        List<Location> nearby = new LinkedList<>();
        nearby = getField().adjacentLocations(getLocation());
        for(int num=0; num<nearby.size(); num++){
            // Get whatever is in the neighbouring cells.
            temp = getField().getObjectAt(nearby.get(num));
            // If there is an animal of the same species... 
            if (temp!= null && temp.getClass().equals(parent.getClass())){ 
                Animal mate =(Animal)temp;
                // If the animal is the opposite gender and can breed...
                if(mate.isFemale()!=this.isFemale() && mate.canBreed() == true){
                    mateNearby = true; // there is an eligible mate nearby
                }
            }
        }
        return mateNearby;
    }
}