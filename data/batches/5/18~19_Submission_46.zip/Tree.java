import java.util.List;
import java.util.Random;

/**
 * A simple model of a tree.
 * Trees age, breed, and die.
 *
 * @version 2019.02.21
 */
public class Tree extends Plant
{
    // Characteristics shared by all trees (class variables).

    // The age at which a tree can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a tree can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a tree breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new tree. A tree may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the tree will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current Simulator object.
     */
    public Tree(boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(randomAge,field, location, simulator);
    }
    
    /**
     * This is what the tree does most of the time.
     * Sometimes it will breed or die of old age.
     * @param newTrees A list to return newly born trees.
     */
    public void act(List<Organism> newTrees){
        incrementAge();
        if(isAlive()) {
            newTrees = super.giveBirth(newTrees, currentSimulation, this);
        }
    }

    /**
     * Get the maximum age for a tree.
     * @return The maximum age.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Get the breeding age for a tree.
     * @return The breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the breeding probability for a tree.
     * @return The breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Get the maximum litter size for a tree species.
     * @return The maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
