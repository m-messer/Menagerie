import java.util.List;
/**
 * Abstract class Actor - The main superclass where other sublasses inherited from.
 * 
 * @version 2020.02.20 
 */
public abstract class Actor
{
    // instance variables - replace the example below with your own
    // These are the values of each animal. 
    // When a particularanimal is eaten by another this is the food value ot gains
    protected static final int RABBIT_FOOD_VALUE = 20;
    protected static final int ZEBRA_FOOD_VALUE = 25;
    protected static final int FOX_FOOD_VALUE = 26;
    protected static final int CHEETAH_FOOD_VALUE = 30;
    protected static final int ALLIGATOR_FOOD_VALUE = 25;
    // These are the values of each vegetation. 
    // When a particular vegetable is eaten by another this is the food value of gains.
    protected static final int GRASS_FOOD_VALUE = 15;
    protected static final int MUSHROOM_FOOD_VALUE = 10;
    protected static final int TREE_FOOD_VALUE = 15;
    protected static final int EGGPLANT_FOOD_VALUE = 15;

    private Field field;
    // The animal's position in the field.
    private Location location;
    //each actor can either be dead or alive and has a specific foodvalue
    private boolean alive;
    protected int actorfoodval;

    /**
     * Constructor for objects of class Actor
     */
    public Actor(Field field, Location location){

        this.field = field;
        this.location = location;
        this.alive = true;
        setLocation(location);

    }
    /**
     * This method is for value of individual food.
     * @return the foodvalue
     */
    protected int individualFoodValue()
    {
        return actorfoodval;
    }

    /**
     * An abstract method for each actor acts differentrly to days and weather
     */
    abstract public void act(List<Actor> newActor, boolean day, int weather);

    /**
     * This method is for the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation( Location newLocation)
    {

        if(location != null) {
            field.clear(location);
        }
        location = newLocation;

        field.place(this,newLocation);
    }

    /**
     * This method is for the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * This method is for clearing animal from field
     */
    protected void clearFromField(){
        location = null;
        field = null;
    }

    /**
     * This method is to learn whether alive or not.
     * @return alive or not
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * This method sets the animal as dead.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            clearFromField();

        }
    }
}
