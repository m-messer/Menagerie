import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 * Write a description of class Weather here.
 * This class gives the weather and day time.
 * Weather has a numerical assignment and returns a string when the number is called.
 * 
 * @version 2020.02.20 
 */
public class Weather
{
    // instance variables - replace the example below with your own
    private List<Integer> numericalMapping;
    private List<String> stringMapping;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        // initialise instance variables
        numericalMapping = new ArrayList<>();
        stringMapping = new ArrayList<>();
        for(int i = 0; i<4; i++){
            numericalMapping.add(i);
        }
        stringMapping.add(0, "Sun");
        stringMapping.add(1, "Rain");
        stringMapping.add(2, "Cloudy");
        stringMapping.add(3, "Hoobadong");

    }

    /**
     *This method generates a random number.
     *This number is the array index therefore 4 is excluded
     *@return a random number
     */
    public int getWeather()
    {
        // put your code here
        return rand.nextInt(4);
    }

    /**
     * @return the weather.
     */
    public String getStringWeather(int w){
        return stringMapping.get(w);
    }

    /**
     * A boolean method for whether the day is between 6am to 6pm.
     * A day is implemented as 24 steps.
     */
    public boolean isDay(int step){
        // day is from 6am to 6pm
        // a day is 24 steps
        if(step % 24 >= 6 && step % 24 <= 18 ){
            return true;
        }
        return false;
    }
}
