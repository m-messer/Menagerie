import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Cheetah.
 * Cheetahs age, move,have gender, eat rabbits,grass,alligator,fox,muhsroom and eggplant, and die.
 * 
 * @version 2020.02.20 
 */
public class Cheetah extends Animal
{
    // Characteristics shared by all cheetahs (class variables).

    // The age at which a cheetah can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a cheetah can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a cheetah breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a cheetah. A cheetah can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * Cheetah competes with foxes for the most of the food sources.
     * 
     * @param randomAge If true, the cheetah will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the cheetah.
     */
    public Cheetah(boolean randomAge, Field field, Location location, int gender)
    {
        super(field, location, gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;           
        }
        foodLevel = ZEBRA_FOOD_VALUE;
        animalFood.add(Alligator.class);
        animalFood.add(Zebra.class);
        animalFood.add(Grass.class);
        animalFood.add(Rabbit.class);
        animalFood.add(Fox.class);

        actorfoodval = CHEETAH_FOOD_VALUE;
    }

    /**
     * This is what the cheetah does most of the time.
     * Feeds during the day.
     * In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param day The daytime cheetah gives birth.
     * @param newCheetah A list to return newly born cheetahs.
     * @param weather , as a condition to track the day.
     */
    public void act(List<Actor> newCheetah, boolean day, int weather)
    {

        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive() && day) {
            giveBirth(newCheetah, BREEDING_PROBABILITY, MAX_LITTER_SIZE, BREEDING_AGE);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * over here this is called from field class
     * the Parameter is the Animal we are comparing this animal with
     * we check if the animal in the adjacent block is of the same class and is an opp gender
     * by overriding the equals method.
     * 
     * @param 'o' The Object clas's instance.
     */
    public boolean genderandequals(Object o){        
        if(o == this){ //check if we are checking with itself
            return false;
        }

        if(!(o instanceof Cheetah)){//if it is not an instance of fox then return false, we cant check true coz
            //we need the below thigs
            return false;
        }

        Cheetah c = (Cheetah) o; // typecast to fox
        if(this.getGender() == c.getGender()){ // if the gender is the same then they cant make babies
            return false;
        }
        return true;
    }
}
