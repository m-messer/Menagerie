/**
 * Starts the long simulation.
 *
 * @version 2020.02.19
 */
public class StartSimulation
{
    public static void main (String[] args)
    {
        Simulator sim = new Simulator();
        sim.runLongSimulation();
    }
}
