
/**
 * This class represents a Snake
 *
 * @version Version 1.0 - 07/02/2019
 */
public class Sheep extends Prey
{
    
    /**
     * Create a new snake at location in field.
     * 
     * @param randomAge Check if we want a random age
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sheep(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, AnimalType.SHEEP);
    }
    
}
