
/**
 * This interface defines all of the required properties and methods
 * that each object in the simulation will have
 *
 * @version Version 1.0 - 14/02/2019
 */
public interface SimulatorObject
{
    /**
     * Return the object's location.
     * @return The object's location.
     */
    Location getLocation();
    
    /**
     * Place the object at the new location in the given field.
     * @param newLocation The object's new location.
     */
    void setLocation(Location location);
    
    /**
     * Return the object's field.
     * @return The object's field.
     */
    Field getField();
    
}
