import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sheeps and wolfes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.04;
    
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;
    
    // The probability that a sheep will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.20;    
    
    
    // The probability that a ZEBRA will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.04;
    
    // The probability that a GRASS will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.04;   
    
    private static final double VIRUS_CREATION_PROBABILITY = 0.03;
    
    
    // List of animals in the field.
    private List<Actor> actors;

    
    //the instance to choose ramdom weather
    private Weather weather;
    
    //the specific weather
    private String currentWeather;
    
    //the boolean to check day or night
    private boolean isDaytime;
    
    // use to count the day
    private int day;
    //the field to store actor
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // animals = new ArrayList<>();
        // plants = new ArrayList<>();
        // viruses = new ArrayList<>();
        actors = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();
        currentWeather = weather.getWeather();
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor("Sheep", Color.BLUE.brighter()); //Ã§ÂÂÃ¦Â¯ÂÃ¥ÂºÂÃ¨Â¯Â¥Ã¤Â¸ÂºÃ¤Â¸ÂÃ§Â±Â»
        view.setColor("Wolf", Color.BLACK.brighter());
        view.setColor("Lion", Color.ORANGE);
        view.setColor("Zebra", Color.RED.brighter());
        view.setColor("Virus Infected Sheep", Color.BLUE.darker()); //Ã§ÂÂÃ¦Â¯ÂÃ¥ÂºÂÃ¨Â¯Â¥Ã¤Â¸ÂºÃ¤Â¸ÂÃ§Â±Â»
        view.setColor("Virus Infected Wolf", Color.BLACK.darker());
        view.setColor("Virus Infected Lion", Color.ORANGE.darker());
        view.setColor("Virus Infected Zebra", Color.RED.darker());
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            
            simulateOneStep();// 

            // delay(60);   // uncomment this to run more slowly Ã§ÂÂ¡Ã§ÂÂ 
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * wolf and sheep.
     */
    public void simulateOneStep()
    {
        step++;
        day++;
        currentWeather = weather.getWeather();
        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>();
        
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors,currentWeather,time()); 

            if(! actor.isAlive()) {
                it.remove();//delete dead animal
            }

        }
       
        actors.addAll(newActors);
        view.showStatus(step, field,day,currentWeather);

    }
    public boolean time(){
   
       if(step%2==0){
       isDaytime = true;//days is even number ,it's daytime
       return isDaytime;
       }else{
       isDaytime = false;//days is odd number,it's night
       return isDaytime;
       }

    }
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        // animals.clear();
        // plants.clear();
        // viruses.clear();
        actors.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step,field,day,currentWeather);
    }
    
    /**
     * Randomly populate the field with wolfes and sheeps.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);//Ã©ÂÂÃ¦ÂÂºÃ¥ÂÂÃ¥Â»ÂºÃ§ÂÂÃ§ÂÂ¸
                    Wolf wolf = new Wolf(true, field, location);
                    actors.add(wolf);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);//Ã©ÂÂÃ¦ÂÂºÃ¥ÂÂÃ¥Â»ÂºÃ¥ÂÂÃ¥Â­Â
                    Sheep sheep = new Sheep(true, field, location);
                    actors.add(sheep);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);//Ã©ÂÂÃ¦ÂÂºÃ¥ÂÂÃ¥Â»ÂºÃ¨ÂÂÃ¨ÂÂ
                    Lion lion = new Lion(true, field, location);
                    actors.add(lion);
                }
                  
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);//Ã©ÂÂÃ¦ÂÂºÃ¥ÂÂÃ¥Â»ÂºÃ¦ÂÂÃ©Â©Â¬
                    Zebra zebra = new Zebra(true, field, location);
                    actors.add(zebra);
                }
                
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);//Ã©ÂÂÃ¦ÂÂºÃ¥ÂÂÃ¥Â»ÂºÃ¦ÂÂÃ©Â©Â¬
                    Grass grass = new Grass(true, field, location);
                    actors.add(grass);
                }
                
                else if(rand.nextDouble() <= VIRUS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);//Ã©ÂÂÃ¦ÂÂºÃ¥ÂÂÃ¥Â»Âºvirus
                    Virus virus = new Virus(field, location);
                    actors.add(virus);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     * Ã¥Â»Â¶Ã¨Â¿Â
     * 
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}