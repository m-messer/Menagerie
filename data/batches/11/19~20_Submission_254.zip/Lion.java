import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
/**
 * A simple model of a lion.
 * Liones age, move, eat sheeps, and die.
 * 
 * 
 * 
 * 
 *
 * @version 2020.02.22 (2)
 * 
 * 
 */
public class Lion extends Animal
{
    // Characteristics shared by all liones (class variables).
    
    // The age at which a lion can start to breed.
    protected static final int BREEDING_AGE = 25;
    // The age to which a lion can live.
    protected static final int MAX_AGE = 200;
    // The likelihood of a lion breeding.
    protected static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    protected static final int MAX_LITTER_SIZE = 3;

    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    

    /**
     * Create a new Lion. A Lion may be created with age and sex, and foodlevel
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(15);
        }
        else {
            age = 0;}
        foodLevel = 15;
        sex = getSex();
        }
    
    
    /**
     * This is what the lion does most of the time: it hunts for
     * sheeps. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLiones A list to return newly born liones.
     */
    public void act(List<Actor> newLions,String weather, boolean isdaytime)
    {
        super.act(newLions,weather,isdaytime);
        if(isAlive()) {
            if (!isdaytime && weather != "fog"){
            giveBirth(newLions);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
               
                setDead();
            }
        }
        }
    }

    /**
     * return Lion's breeding age;
     */
    @Override
    protected int getBREEDING_AGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * return Lion's MAX_LITTER_SIZE;
     */
    @Override
    protected int getMAX_LITTER_SIZE()
    {
        return MAX_LITTER_SIZE;
    
    }
    
    /**
     * return Lion's BREEDING_PROBABILITY;
     */
    @Override
    protected double getBREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    /**
     * return Lion's MAX_AGE;
     */
    @Override
    protected int getMAX_AGE()
    {
        return MAX_AGE;
    }
    
    /**
     * return Lion's foodValue;
     */
    @Override
    public int returnFoodValue(){
        int foodValue = 6;
        return foodValue;
    }
    /**
     * return Lion's dietList;
     */
    @Override
    public List<String> getDietList(){
        List<String> dietList = new ArrayList<String>();
        dietList.add("Sheep");
        dietList.add("Zebra");
        return dietList;
    }
    /**
     * return Lion's new instance;
     */
    @Override
    protected Animal getChild(Field field, Location location){

        return new Lion(false, field, location);
    
    }
}
        
    


