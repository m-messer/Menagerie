import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
/**
 * A simple model of a Sheep.
 * Sheeps age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 *
 * @version 2020.02.22 (2)
 * 
 */
public class Sheep extends Animal
{
    // Characteristics shared by all Sheeps (class variables).

    // The age at which a Sheep can start to breed.
    protected static final int BREEDING_AGE = 5;
    // The age to which a Sheep can live.
    protected static final int MAX_AGE = 40;
    // The likelihood of a Sheep breeding.
    protected static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    protected static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    



    /**
     * Create a new Sheep. A Sheep may be created with age and sex, and foodlevel
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sheep(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        sex = getSex();
        foodLevel = 10;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the Sheep does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newSheeps A list to return newly born Sheeps.
     */
    public void act(List<Actor> newSheeps,String weather, boolean isdaytime)
    {
        super.act(newSheeps,weather,isdaytime);
        
        if(isAlive()) {
            
            if (isdaytime  ){
            giveBirth(newSheeps);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                setDead();
            }
        }
    }
    }
  
    /**
     * return Sheep's breeding age;
     * 
     */
    
    @Override
    protected int getBREEDING_AGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * return Sheep's MAX_LITTER_SIZE;
     * 
     */
    @Override
    protected int getMAX_LITTER_SIZE()
    {
        return MAX_LITTER_SIZE;
    
    }
    
    /**
     * return Sheep's BREEDING_PROBABILITY
     */
    @Override
    protected double getBREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * return Sheep's MAX_AGE
     * 
     */
    
    @Override
    protected int getMAX_AGE()
    {
        return MAX_AGE;
    }
    /**
     * return Sheep's foodValue
     * 
     */
    @Override
    public int returnFoodValue(){
        int foodValue = 6;
        return foodValue;
    }
    
    /**
     * return Sheep's DietList
     * 
     */
    @Override
    public List<String> getDietList(){
        List<String> dietList = new ArrayList<String>();
        dietList.add("Grass");
        return dietList;
    }
    /**
     * return a new Sheep instance
     * 
     */
    @Override
    protected Animal getChild(Field field, Location location){

        return new Sheep(false, field, location);
    
    }

}
