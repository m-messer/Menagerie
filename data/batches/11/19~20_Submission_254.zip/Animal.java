import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{
    // The animal's age
    // The animal's food level
    protected int foodLevel;
    // The animal's sex
    protected String sex;

    // The animal's microOrganismsList is for stroing the microOrganisms to act 
    protected List<MicroOrganisms> microOrganismsList;
    // The animal's infectList is for checking it have the type of microOrganisms or not
    protected List<Class> infectList;
    // The animal's dietList 
    protected List<String> dietList;
    /**
     * Create a new animal at location in field.
     * setting the microOrganismsList,infectList,dietList
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);

        setLocation(location);
        this.microOrganismsList = new ArrayList<MicroOrganisms>(0);
        this.infectList = new ArrayList<Class>(0);
        this.dietList = getDietList();
    }
    
    /**
     * Create a new animal at location in field.
     * setting the microOrganismsList,infectList,dietList
     * @param String The weather is the condition that will influence some actor.
     * @param boolean The isdaytime use a boolean to clearify the day and night.
     */
    @Override
    public void act(List<Actor> newActor,String weather, boolean isdaytime){
        moAct(newActor);
        incrementHunger();
        incrementAge();
        
    
    
    }
    /**
     * Look for the alive aimal and which in the dietList 
     * Only the first qualified actor is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Actor actor = field.getActorAt(where);
               
            if(actor!= null){
                String Classname = actor.getClass().getName(); 
            if(actor.isAlive() && dietList.contains(Classname)) {
                    actor.setDead();
                    foodLevel += actor.returnFoodValue();
                    return where;
                
            }
        }
    }
        return null;
    }
    /**
     * make all MicroOrganisms in the animal's list to act
     * @param List<Actor> and animal are passed to interact with MicroOrganisms.
     * .
     */
    protected void moAct(List<Actor> newAnimals){
        for(int n = 0; n < microOrganismsList.size();n++){
            MicroOrganisms m = microOrganismsList.get(n);
                if(m.isAlive()){

                m.internalact(newAnimals,this);

            }
        }
    }
    
    /**
     * to check the Infectlist have this MicroOrganisms or not
     * 
     */
    public boolean infectedOrNot(MicroOrganisms m){
            return !infectList.contains(m.getClass());
    }
    
    /**
     * to put the MicroOrganisms instance in the microOrganismsList.
     * so it can act in the next SimulateOneStep
     */
    public void TakinMicro(MicroOrganisms m){
            infectList.add(m.getClass());
            microOrganismsList.add(m);
            
    }
    

    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born Animals.
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        // New Sheeps are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        if (havePartner() && canBreed() ){
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = getChild(field,loc);
            newAnimals.add(young);
        }
    }
    
    }
 
    /**
     * Check whether or not this animal is to find another alive same kind animal with different sex.
     * the another animal's breeding age will also be checked. 
     */
    protected boolean havePartner()
     {
        
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Actor object = field.getActorAt(where);
            if (object instanceof Animal){
                Animal animal = (Animal)object;
                if(animal.getClass().equals(this.getClass()) && animal.isAlive() && differentSex(animal) && animal.canBreed()) {
                    return true;
    
            }
        }
    }
        return false;
    }
    /**
     * Check whether the sex of another animal is different to this animalÃ¢ÂÂs sex or not
     * 
     */
    protected boolean differentSex(Animal another_Animal){
        return !(this.sex == another_Animal.sex);
    
    }
    /**
     * return a random sex to this animal
     * it is call when an animal is birth.
     */
    protected String getSex() //use a sex with random number to return a sex
    {
        Random r = new Random();
        String[] sexlist =  new String[]{"Male","Female"};
        sex = sexlist[r.nextInt(2)];
        return sex;
    }
    /**
     * return a sex, when need to be check 
     * 
     */
    protected String returnSex(){
    
        return sex;
    
    }
    /**
     * return a sex, when need to be check 
     * 
     */
    protected int returnAge(){
    
        return age;
    
    }
    /**
     * return a sex, when need to be check 
     * 
     */
    protected int returnFoodLevel(){
    
        return foodLevel;
        
    }
  
    /**
     * adding the foodlevel 
     * when the foodlevel to be zero
     * this animal will be setDead
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    /**
     * adding the age when it is over the Max_age ,it will set dead
     * 
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMAX_AGE()) {
            setDead();
        }
    }
    /**
     * to check the age is over than BREEDING_AGE or not
     * 
     */
    protected boolean canBreed()
    {
        return age >= getBREEDING_AGE();
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBREEDING_PROBABILITY()) {
            births = rand.nextInt(getMAX_LITTER_SIZE()) + 1;
        }
        return births;
    }
    /**
     * it will return a certain kinds of animal.
     * @param field and location is passed to determined the place of new animal
     * 
     */
    
    abstract protected Animal getChild(Field field, Location location);
    /**
     * it will get a DietList when an animal is being created
     * 
     */
    abstract protected List<String> getDietList();

    
    /**
     * it will get a BREEDING_AGE when an animal is being created
     * 
     */
    abstract protected int getBREEDING_AGE();


}
