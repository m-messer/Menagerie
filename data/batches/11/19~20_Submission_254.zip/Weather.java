import java.util.Random;
import java.util.ArrayList;
/**
 * Write a description of class weather here.
 *
 * @version (a version number or a date)
 */
public class Weather
{
    // instance variables - replace the example below with your own
    private Simulator simulator;
    private ArrayList<String>weatherList;
    private String currentWeather ;
    /**
     * Constructor for objects of class weather
     */
    public Weather()
    {
        weatherList= new ArrayList<>();
        weatherList.add("sunny");
        weatherList.add("rain");
        weatherList.add("fog");// fog predators cant hunt
        
        //ystem.out.println(weather);
    }
    
   
    /**
      * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
      public  String getWeather()
      {
      // put your code here
         Random generator = new Random();
         //System.out.println(weatherList);
         currentWeather=weatherList.get(generator.nextInt(weatherList.size()));
         
         return currentWeather; 
         
     }
     
     
    }
