import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of actors.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Actor
{
    // Whether the actors is alive or not.
    protected boolean alive = true;
    // The actors's field.
    protected Field field;
    // The actors's age.
    protected int age;
    
    // The actors's position in the field.
    protected Location location;
    // The actors's kind.
    protected String kind;
    protected static final Random rand = Randomizer.getRandom();

    /**
     * Create a new actors at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Actor(Field field, Location location)
    {
        
        this.field = field;
        this.kind = this.getClass().getName();
        setLocation(location);
    }
    
    /**
     * Make this actors act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born actors.
     */
    
    abstract public void act(List<Actor> newActor,String weather, boolean isdaytime);

    /**
     * Check whether the actors is alive or not.
     * @return true if the actors is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the actors is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the actors's location.
     * @return The actors's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the actors at the new location in the given field.
     * @param newLocation The actors's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the actors's field.
     * @return The actors's field.
     */
    protected Field getField()
    {
        return field;
    }
    /**
     * Return the Kind.
     * @return The Kind
     */
    protected String returnKind()
    {
        return kind;    
    }
    /**
     * rechange the name adding the MicroOrganisms's name
     */
    public void getInfected(String moName){
    
        kind = moName + " Infected " + this.getClass().getName();
    
    }
    
    /**
     * adding the age when it is over the Max_age ,it will set dead
     * 
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMAX_AGE()) {
            setDead();
        }
    }
    
    /**
     * return the number of birth of new actor
     * 
     */
    protected int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= getBREEDING_PROBABILITY()) {
            births = rand.nextInt(getMAX_LITTER_SIZE()) + 1;
        }
        return births;
    }
    
    
    
    /**
     * Return the actors's FoodValue. when it is being eat,it will applied
     * it will be overiding in the subclass of actor
     */
    abstract protected int returnFoodValue();
    
    /**
     * it will get a Max_age when an actor is being created
     * 
     */
    abstract protected int getMAX_AGE();
    
    /**
     * it will get a MAX_LITTER_SIZE when an actor is being created
     * 
     */
    abstract protected int getMAX_LITTER_SIZE();
    /**
     * it will get a BREEDING_PROBABILITY when an actor is being created
     * 
     */
    abstract protected double getBREEDING_PROBABILITY();
}
    




