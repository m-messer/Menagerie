import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
/**
 * A simple model of a Zebra.
 * Zebras age, move, breed, and die.
 * 
 *
 * @version 2020.02.22 (2)
 */
public class Zebra extends Animal
{
    // Characteristics shared by all Zebras (class variables).

    // The age at which a Zebra can start to breed.
    protected static final int BREEDING_AGE = 5;
    // The age to which a Zebra can live.
    protected static final int MAX_AGE = 40;
    // The likelihood of a Zebra breeding.
    protected static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    protected static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    

    
    /**
     * Create a new Zebra. A Zebra may be created with age and sex, and foodlevel
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        sex = getSex();
        foodLevel = 10;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the Zebra does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born Zebras.
     */
    public void act(List<Actor> newZebras,String weather, boolean isdaytime)
    {
        super.act(newZebras,weather,isdaytime);
        if(isAlive()) {
            giveBirth(newZebras);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
          
                setDead();
            }
        }
    }

    /**
     * return Zebra's BREEDING_AGE;
     */
    @Override
    protected int getBREEDING_AGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * 
     * return Zebra's MAX_LITTER_SIZE;
     * 
     */
    
    @Override
    protected int getMAX_LITTER_SIZE()
    {
        return MAX_LITTER_SIZE;
    
    }
    
    /**
     * 
     * return Zebra's BREEDING_PROBABILITY;
     * 
     */
    @Override
    protected double getBREEDING_PROBABILITY(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * 
     * return Zebra's MAX_AGE;
     * 
     */
    @Override
    protected int getMAX_AGE()
    {
        return MAX_AGE;
    }
    /**
     * 
     * return Zebra's foodValue;
     * 
     */
    @Override
    public int returnFoodValue(){
        int foodValue = 6;
        return foodValue;
    }
    /**
     * 
     * return Zebra's dietList;
     * 
     */
    @Override
    public List<String> getDietList(){
        List<String> dietList = new ArrayList<String>();
        dietList.add("Grass");
        return dietList;
    }
    /**
     * 
     * return Zebra's new instance;
     * 
     */
    @Override
    protected Animal getChild(Field field, Location location){

        return new Zebra(false, field, location);
    
    }
    
}