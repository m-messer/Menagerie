import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Abstract class MicroOrganisms - write a description of the class here
 *
 * @version (version number or date here)
 */
public abstract class MicroOrganisms extends Actor
{

    
    /**
     * internalact is for the Virus act
     * 
     * @List<Actor> newActors The field whose status is to be displayed.
     */
    public MicroOrganisms(Field field, Location location)
    {
        super(field,location);
    }
    
    /**
     * Internalact is for the microOrganismses which in the animal's microOrganismsList to act
     * since it will not influence by the day and night, or the weather,it only need the newActors and animal as parameters.
     * @List<Actor> newActors is the list of actors which it may influenced    
     */
    
    public void internalact(List<Actor> newActors,Animal animal){
        Field field = getField();
        incrementAge();
        if(isAlive()) {
            giveBirth(newActors);
            Infected(newActors);
            symptom(animal);
            Location newLocation = field.microOrganismsesFreeAdjacentLocation(location);
            if(newLocation != null) {
                //do nothing;
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    protected void giveBirth(List<Actor> MicroOrganisms)
    {
        Field field = getField();
        if(!this.isAlive())
            return;
        List<Location> free = field.getMicroOrganismsesFreeAdjacentLocations(location);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            MicroOrganisms.add(getChild(field,loc));

        }
    }
    
    
    /**
     * Infect is to put the microOrganismses in the animal's microOrganismsList
     * 
     * @List<Actor> newActors is the list of actors which it may influenced
     * 
     */
    protected void Infected(List<Actor> newViruses){
        if(this.isAlive())
        {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Actor actor = field.getActorAt(where);
            if(actor instanceof Animal && actor.isAlive() ) {
               Animal animal = (Animal)actor;
               animal.getInfected(this.getClass().getName());
               if(animal.infectedOrNot(this)){
               animal.TakinMicro(new Virus(field, where));
            }
               
            }
            }
        }
    }
    

    /**
     * Place the actors at the new location in the given field.
     * @param newLocation The actors's new location.
     */
    @Override
    protected void setLocation(Location newLocation)
    {
        
        if(location != null) {
            field.microOrganismsClear(location);
        }
        location = newLocation;
        field.placeMicroOrganisms(this, newLocation);
    }
    
 
    /**
     * Place the actors at the new location in the given field.
     * @param animal The actors's new location.
     */
    abstract public void symptom(Animal animal);
    /**
     * to received a MicroOrganisms instance from subclass
     * 
     */
    abstract protected MicroOrganisms getChild(Field field, Location location);

    /**
     * Every MicroOrganisms should have an act when it haven't in the list.
     * it will be influence by the weather or daytime
     * 
     */
    @Override
    abstract public void act(List<Actor> newActor,String weather, boolean isdaytime);
    /**
     * received the Max_AGE
     */
    @Override
    abstract protected int getMAX_AGE();
    /**
     * received the Max litter size it could have 
     */
    @Override
    abstract protected int getMAX_LITTER_SIZE();
    /**
     * received the BREEDING_PROBABILITY
     */
    @Override
    abstract protected double getBREEDING_PROBABILITY();
}
