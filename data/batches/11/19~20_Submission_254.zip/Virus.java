import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
public class Virus extends MicroOrganisms
{

    
    private static final int VIRUS_MAX_AGE = 10;
    private static final double VIRUS_BREEDING_PROBABILITY = 0.02;
    private static final int VIRUS_MAX_LITTER_SIZE = 5;

    /**
     * Create a new Virus at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Virus(Field Fields, Location location)
    {
        super(Fields,location);
        setLocation(location);
    }
    
    /**
     * Make this Virus grow - that is: make it do
     * only make new Virus on the empty field, when it is not  
     * infected other animals
     * @param newViruss A list to receive newly born Viruss. Also the placed in the microOrganismsfield
     */
    @Override
    public void act(List<Actor> newActors,String weather, boolean isdaytime){
        incrementAge();
        if(isAlive() && !weather.equals("sunny")) {
            giveBirth(newActors);
            Infected(newActors);
            Location newLocation = field.microOrganismsesFreeAdjacentLocation(location);
            if(newLocation != null) {
                //do nothing;
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * return a new Sheep instance
     * 
     */
    @Override
    protected MicroOrganisms getChild(Field field, Location location){

        return new Virus(field, location);
    
    }

    /**
     * return Virus's MAX_LITTER_SIZE;
     * 
     */

    @Override
    protected int getMAX_LITTER_SIZE()
    {
        return VIRUS_MAX_LITTER_SIZE;
    
    }
    
    /**
     * return Virus's breeding probability;
     * 
     */
    @Override
    protected double getBREEDING_PROBABILITY(){
        return VIRUS_BREEDING_PROBABILITY;
    }
    /**
     * return Virus's max age;
     * 
     */
    @Override
    protected int getMAX_AGE()
    {
        return VIRUS_MAX_AGE;
    }
    /**
     * return Virus's MAX_LITTER_SIZE;
     * 
     */
    @Override
    public int returnFoodValue(){
        int foodvalue = 0;
        return foodvalue;
    }
    
    /**
     * the symptom of the Virus will make animal aging faster
     * 
     */
    @Override
    public void symptom(Animal animal){
        
        animal.incrementAge();
    }

}
