
import java.util.List;

/**
 * A class representing shared characteristics of Plantss.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Plants extends Actor
{

    
    /**
     * Create a new Plants at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(Field field, Location location)
    {
        super(field,location);

    }


    /**
     * Indicate that the actors is no longer alive.
     * It is removed from the Plantsfield.
     */
    @Override
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field = getField();
            field.plantsClear(location);
            location = null;
            field = null;
        }
    }

    
    /**
     * Place the actors at the new location in the Plantsfield.
     * @param newLocation The actors's new location.
     */
    @Override
    protected void setLocation(Location newLocation)
    {
        //field = getField(); 
        if(location != null) {
            field.plantsClear(location);
        }
        location = newLocation;
        //System.out.println("field in setLocation: " + field);
        field.placePlants(this, newLocation);
    }
    
    
    
    

}
