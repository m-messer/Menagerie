import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a SeaLion.
 * SeaLiones age, move, eat Penguins and Krills, and die.
 * 
 * They can suffer from diseases, and if they do, their offspring also have the disease.
 *
 * @version 2016.02.29 (2)
 */
public class SeaLion extends Predator
{
    private static final Random rand = Randomizer.getRandom();  // A shared random number generator to control breeding.
    
    // Characteristics shared by all SeaLions (class variables).
    
    private static final int BREEDING_AGE = 10; // The age at which the SeaLion can breed.

    private static final int MAX_AGE = 150; // The maximum age to which the SeaLion can live.

    private static final double BREEDING_PROBABILITY = 0.01; // The likelihood of the SeaLion breeding.

    private static final int MAX_LITTER_SIZE = 2; // The maximum number of SeaLion births.

    private static final int MAX_INITIAL_FOOD_VALUE = 30; // The maximum food value that the SeaLion can start with.
    
    // Specific food values.
    
    private static final int Penguin_FOOD_VALUE = 30;
    
    private static final int Krill_FOOD_VALUE = 30;
    
    private static final int Salmon_FOOD_VALUE = 30;
    

    
    // Individual characteristics (instance fields).

    // The SeaLion's food level, which is increased by eating Penguins.
    private int foodLevel;
    
    /**
     * Create a SeaLion. A SeaLion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the SeaLion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public SeaLion(boolean diseased, boolean randomAge, Field field, Location location)
    {
        super(diseased, randomAge, field, location, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
        
        foodLevel = MAX_INITIAL_FOOD_VALUE;
        
    }
    
    /**
     * Look for Penguins and Krill adjacent to the current location.
     * Only the first live Penguin or Krill is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();    // get a list of the adjacent locations and start to iterate through them.
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Penguin) {
                Penguin Penguin = (Penguin) animal;
                if(Penguin.isAlive()) {     // if, in the location being observed, the object is an alive penguin, kill it and set Sealion food value.
                    Penguin.setDead();
                    foodLevel = Penguin_FOOD_VALUE;
                    return where;
                }
            }
           
            if(animal instanceof Krill) {
                Krill Krill = (Krill) animal;
                if(Krill.isAlive()) {   // if, in the location being observed, the object is an alive Krill, kill it and set Sealion food value.
                    Krill.setDead();
                    foodLevel = Krill_FOOD_VALUE;
                    return where;
                }
            }
            
        }
        return null;
    }
    
    /**
     * Make this Sea Lion more hungry. This could result in the Sea Lions's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this SeaLion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * If the predator has a disease, then all offspring will be born diseased.
     * @param newSeaLiones A list to return newly born SeaLions.
     */
    protected void giveBirth(List<Actor> newSeaLions)
    {
        // New SeaLions are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = super.breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            
            SeaLion young;
            
            if(getDiseased()) // create a new Sealion. If the current SeaLion is diseased, then the offspring will also be diseased.
            young = new SeaLion(true, false, field, loc);   
            
            else
            young = new SeaLion(false, false, field, loc);
            
            newSeaLions.add(young);
        }
    }
        
}
