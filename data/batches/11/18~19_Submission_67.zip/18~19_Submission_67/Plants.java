import java.util.List;
import java.util.Random;
/**
 * Plants are another element of this simulation.
 * 
 * They do not move, but gradually grow on the spot that they start in, and are not affected by the time of day.
 * 
 * However, their growth is effected by temperature level. If it gets too high, their growth probability is halved.
 *
 * 
 */
public class Plants extends Actor
{ 
    private static final Random rand = Randomizer.getRandom();  // Random number generator
    
    boolean tempIsHigh = false; // Determines if the temperature is above 20 degrees.
    
    double GROWING_PROBABILITY;
    
    
    /**
     * Constructor for objects of class Plants
     */
    public Plants(Field field, Location location)
    {
        super(field, location);
        this.GROWING_PROBABILITY = 0.002;
    }

    /**
     * This method is called for every plant at every new step of the simulation.
     * 
     * It currently only calls the grow method, given it is alive.
     * 
     */
    public void act(List<Actor> newPlants)
    {
        if(isAlive()) {
            grow(newPlants);            
        }
    }

    /**
     * 
     * This method calls the growth probability to be calculated and then, using that, creates a new plant and adds it to the array of plants.
     * 
     */
    protected void grow(List<Actor> newPlants)
    {
        calcGrowthProb();
                  
        // New Sharks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        if(rand.nextDouble() <= GROWING_PROBABILITY){   // If the random number that is generated is below the probability, then carry out the below code.
        for(int b = 0;free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plants young = new Plants(field, loc);
            newPlants.add(young);
        }
        }

    }
    
    /**
     * 
     * If the temperature is above 20 degrees, then the probability of a new branch growing from the plant is halved.
     * 
     * If the temperature has been halved, then when it goes under 20 degrees, it will be doubled.
     * 
     */
    private void calcGrowthProb()
    {
        int temp = Simulator.getTemp(); // gets the temperature from the simulator.
        if (temp>=20 && tempIsHigh == false){   // if it is above 20 degrees and the temperature was low, cut the growth probability in half.
            GROWING_PROBABILITY = GROWING_PROBABILITY/2;
            tempIsHigh = true;
        }
        
        if (temp<20 && tempIsHigh == true){ // if it is below 20 degrees and the temperature was high, double the growth probability.
            GROWING_PROBABILITY = GROWING_PROBABILITY*2;
            tempIsHigh = false;
        }
    }
}
