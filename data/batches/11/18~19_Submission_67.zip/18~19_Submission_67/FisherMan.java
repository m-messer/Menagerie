
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * The Fisherman is the most special class in the simulation.
 * They move in a calculated diagonal pattern, unlike the fish and plants who move and grow in random directions. If it is about to move out of the field, then it rebounds off of the boundary and travels in the opposite direction.
 * As the fishermen's boats are only so big, they have a certain capacity, or a 'max load'.
 * They collect any object, aside from other fishermen, from all adjacent cells when they move.
 * For every object they collect, this is added to their current load.
 * When they run out of space, they move directly to the left until they reach the edge of the field.
 * The fisherman object is removed from the field as they 'dock' into the port and unload their goods.
 * When the next change in time occurs, i.e. day to night or night to day, all of the boats in the dock reappear in random locations in the leftmost column and start fishing for goods again.
 *
 *
 * 
 */
public class FisherMan extends Actor
{

    private static final Random rand = Randomizer.getRandom(); // A shared random number generator.
    
    // Field and location variables.
    
    private Field field;
    
    private Location location;
    
    private int currentX;
    
    private int currentY;
    
    private int timeOfDay;
   
    
    // Load variables.
    
    private static final int maxLoad = 10; // Determines the shared maximum load that a boat can hold.
    
    private int currentLoad; // Determines how much load the boat currently has.
    
    
    // Docked Variables
    
    private static int boatsDocked; // Holds the number of boats that have docked in the bay.
    
    private boolean docked; // Determines if the boat is docked or not.
    
    
    // Direction Values
    
    private boolean goingUp; // If it is not going up, then it is going down.
    
    private boolean goingLeft; // If it is not going left, then it is going right.
    

    
    
    
    
    /**
     * Constructor for objects of class FisherMan
     * 
     * Also decides on the starting random directions that the boat will travel in, i.e. will it travel up or down, left or right.
     * 
     */
    public FisherMan(Field field, Location location)
    {
        super(field, location);
        
        this.location = location;
        this.field = field;
        
        timeOfDay = 0;
        currentLoad = 0;
        docked = false;
        
        currentX = location.getCol();
        currentY = location.getRow();

        int up = rand.nextInt(2);   // Generates a random integer betwen 0 and 1.
        if (up == 0){   // If it generates 0, then the boolean value 'goingUp' becomes true. Else, it is set to false.
            goingUp = true;
        }
        
        else{
            goingUp = false;
        }
        
        int left = rand.nextInt(2); // Genreates another random integer between 0 and 1.
        if (left == 0){     // If it generates 0, then the boolean value 'goingLeft' becomes true. Else, it is set to false.
            goingLeft = true;
        }
        
        else{
            goingLeft = false;
        }
        
        // The above can be extended so the boat can stand still. You would have to add another if statement.
        
    }

    
    /**
     * 
     * Calls the operations needed to generate the activities of the fisherman.
     * 
     * If it is not docked and its load is not full, it should find food and move about.
     * 
     * If its load is full, then it should move to the left.
     * 
     * Otherwise, as it will be docked, launch the boat back into the water.
     * 
     */
    public void act(List<Actor> newFisherman)
    {
        boolean timeChanged = decideIfTimeHasChanged(); // Get if the time of day has changed or not.
        
        currentX = location.getCol();
        currentY = location.getRow();
        
        if (currentLoad < maxLoad && docked == false){  // If it has space and is not docked, then find food and move about.
            findFood();
            calculateNewFishingLocation();
            setLocation(location);
        }

        else if (currentLoad >= maxLoad && docked == false){    // If it's storage is full and it is not docked, calculate the location it should move to.
            calculateNewReturningToPortLocation();
        }
            
        if(docked == true && timeChanged == true){  // If the boat is docked and the time of day has changed, launch the boat.
            launchBoat();
        }

    }

    /**
     *
     * Calculates a new location to fish in when the boat's load is not full and it is not returning to the port.
     * 
     */
    private void calculateNewFishingLocation(){
        
        calculateDirectionAdjustment();
        
        // Update the location to the next location along in the path depending on the direction it is travelling.
        
        if (goingUp && goingLeft){
            location = new Location(currentY-1, currentX-1);
        }
        
        if (goingUp && goingLeft == false){
            location = new Location(currentY-1, currentX+1);
        }
        
        if (goingUp == false && goingLeft){
            location = new Location(currentY+1, currentX-1);
        }
        
        if (goingUp == false && goingLeft == false){
            location = new Location(currentY+1, currentX+1);
        }
    }
    
    /**
     *
     * Calculates if the boat is about to hit the field boundary. If it is, then this method adjusts the travel direction of the boat so it does not go out of bounds.
     * 
     * We have to subtract 1 from the width and the depth as they are indexed from 0, and thus end one less than they are defined.
     * 
     */
    private void calculateDirectionAdjustment(){ 
        
        if (currentX+1>field.getWidth()-1){ // If the next X position will take you further than the width of the field, go left, away from the right edge.
            goingLeft = true;   
        }
        
        if (currentX-1<0){ // If the next X position will take you less than the width of the field, go right, away from the left edge.
            goingLeft = false;
        }
        
        if (currentY+1>field.getDepth()-1){ // If the next Y position will take you deeper than the depth of the field, then go up, away from the bottom.
            goingUp = true;
        }
        
        if (currentY-1<0){ // If the next Y position will take you higher than the depth of the field, then go down, away from the top.
            goingUp = false;
        }
    }
    
    /**
     *
     * When the load of the boat is full, the boat travels directly left until it hits the edge of the field. This is when it reaches the 'port'. The object is removed from the field temporarily.
     * 
     * This method calculates the location one to the left of the current location, and sets all of the values to represent a docked ship.
     * 
     */
    private void calculateNewReturningToPortLocation(){
        
        if (currentX>0){ //If the X position of the ship is not at the left edge, move closer by one.
            location = new Location(currentY, currentX-1);
            setLocation(location);
        }

        else{ // If it has hit the left edge, leave the field, unload, add it to the dock and set the dock boolean value to true.
            leaveField();
            currentLoad = 0;
            boatsDocked += 1;
            docked = true;
        }
        
    }
    
    /**
     *
     * After the boat has docked, it has to launch back into the sea again.
     * 
     * The ship starts in a random position on the leftmost column. It cannot be ontop of another ship.
     * 
     */
    private void launchBoat(){
        
        int randomYStartPosition = rand.nextInt(field.getDepth());  // Generate a random positon in the leftmost column.
        Location spawnLoc = new Location(randomYStartPosition, 0);
        
        while (field.getObjectAt(spawnLoc) == this.getClass()){ // If the object in the randomly generated position is a boat, generate another random position in the leftmost column. Keep going until this is the case.
            randomYStartPosition = rand.nextInt(field.getDepth());
            spawnLoc = new Location(randomYStartPosition, 0);
        }
        
        location = new Location(randomYStartPosition, 0);   // As there is not a boat in the same location, set the location to that location and spawn it in.
        
        setLocation(location);

        boatsDocked -= 1;   // There is now one less boat docked.
        
        docked = false;
        
    }
    
    /**
     * 
     * This checks to see if there are any objects for the fishing boat to pick up.
     * 
     * If there are, then set them to dead and increase the boat's load by one for each object.
     * 
     */
    private void findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {   // While there are still objects in the adjacent location, if is not null and it is not another boat, catch it and increase your load.
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            
            if(actor != null && actor.getClass() != getClass()) {
                Actor adjActor = (Actor) actor;              
                adjActor.setDead();
                currentLoad+=1;
            }
            
        }

        }
    
        
    /**
     * 
     * @return Returns if the time has changed, i.e. from day to night or from night ot day.
     * 
     */    
    private boolean decideIfTimeHasChanged(){
        
        int currentTime = timeOfDay;
        timeOfDay = Simulator.getTimeOfDay();
        
        boolean timeChanged = false;
        
        if(currentTime != timeOfDay){
            timeChanged = true;
        }
        
        return timeChanged;
    }        
}
