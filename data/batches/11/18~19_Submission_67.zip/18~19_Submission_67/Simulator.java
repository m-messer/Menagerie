import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Penguins and Sharkes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Shark will be created in any given grid position.
    private static final double Shark_CREATION_PROBABILITY = 0.003;
    // The probability that a SeaLion will be created in any given grid position.
    private static final double SeaLion_CREATION_PROBABILITY = 0.003;
    // The probability that a Krill will be created in any given grid position.
    private static final double Krill_CREATION_PROBABILITY = 0.089;
    // The probability that a Salmon will be created in any given grid position.
    private static final double Salmon_CREATION_PROBABILITY = 0.07;
    // The probability that a Penguin will be created in any given grid position.
    private static final double Penguin_CREATION_PROBABILITY = 0.055;   
    // The probability that a Plant will be created in any given grid position.
    private static final double Plant_CREATION_PROBABILITY = 0.025;
    // The probability that a Fisherman will be created in any given grid position.
    private static final double Fisher_Man_CREATION_PROBABILITY = 0.0005;
    
    private static int temp = 5;
    
    private static Time time = new Time();
    private static Weather weather = new Weather(temp);
    
    // List of animals in the field.
    private List<Actor> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private static int timeOfDay;
    // The current time of day in the simulation.
    private int step;

    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Shark.class, Color.BLUE);
        view.setColor(SeaLion.class, Color.CYAN);
        view.setColor(Penguin.class, Color.BLACK);
        view.setColor(Salmon.class, Color.ORANGE);
        view.setColor(Krill.class, Color.RED);
        view.setColor(Plants.class, Color.GREEN);
        view.setColor(FisherMan.class, Color.GRAY);
        
   
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            weather.changeTemp();
            temp = weather.getTemp();
            
            simulateOneStep(); 
            
            
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Shark and Penguin.
     */
    public void simulateOneStep()
    {
        step++;
        
        timeOfDay = time.getTimeOfDay(step);
             
        // Provide space for newborn animals.
        List<Actor> newAnimals = new ArrayList<>();        
        // Let all Penguins act.
        for(Iterator<Actor> it = animals.iterator(); it.hasNext(); ) {
            Actor animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born Sharkes and Penguins to the main lists.
        animals.addAll(newAnimals);

        String stringTimeOfDay = time.convertToString();
        view.showStatus(step, stringTimeOfDay, temp, field);
    }
      
    /**
     * @return Returns the time of day that the simulator is currently in.
     */
    public static int getTimeOfDay(){
        return timeOfDay;
    }
   
    /**
     * @return Returns the temperature that the water is currently at.
     */
    public static int getTemp(){
        return temp;
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step,"Day", temp, field);
    }
    
    /**
     * Randomly populate the field with Sharkes and Penguins.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Shark_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark Shark = new Shark(false, true, field, location);
                    animals.add(Shark);
                }
                if(rand.nextDouble() <= SeaLion_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    SeaLion seaLion = new SeaLion(false, true, field, location);
                    animals.add(seaLion);
                }
                if(rand.nextDouble() <= Penguin_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Penguin Penguin = new Penguin(true, field, location);
                    animals.add(Penguin);
                }
                if(rand.nextDouble() <= Salmon_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Salmon salmon = new Salmon(true, field, location);
                    animals.add(salmon);
                }
                if(rand.nextDouble() <= Krill_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Krill krill = new Krill(true, field, location);
                    animals.add(krill);
                }
                if(rand.nextDouble() <= Plant_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plants plant = new Plants(field, location);
                    animals.add(plant);
                }
                if(rand.nextDouble() <= Fisher_Man_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    FisherMan fisherMan = new FisherMan(field, location);
                    animals.add(fisherMan);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
