import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Abstract class Prey - Superclass for all Prey species.
 * 
 * Prey move, age and die.
 *
 */
public abstract class Prey extends Animal
{
    private static final Random rand = Randomizer.getRandom();  // A shared random number generator to control breeding.
    
    private int BREEDING_AGE;   // The age to which a Prey can start breeding.
    
    private int MAX_AGE;    // The maximum age to which a Prey can live.    

    private double BREEDING_PROBABILITY;    // The likelihood of a Prey breeding.        

    private int MAX_LITTER_SIZE;    // The maximum number of Prey births.
    
    private int random_Gender;  // The random gender of the Prey.

    // Individual characteristics (instance fields).
    
    private int age;    // The Prey's age.
    
    private boolean tempIsHigh;
    
    
    public Prey(boolean randomAge, Field field, Location location, int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE)
    {
        super(field, location);
        
        random_Gender = rand.nextInt(2);
        // 0 is male, 1 is female.
        
        this.BREEDING_AGE = BREEDING_AGE;
        
        this.MAX_AGE = MAX_AGE;
        
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        
        this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the Prey does most of the time - it swims 
     * around. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born Prey.
     */
    public void act(List<Actor> newPrey)
    {
        if(Simulator.getTimeOfDay() == 0){
        incrementAge();
        if(isAlive()) {
            if (random_Gender == 1){    // if the Prey is female, try to give birth.
            giveBirth(newPrey); 
            }
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        
        int temp = Simulator.getTemp(); // Alters the breeding probability based on the temperature of the water.
        if (temp<=-10 && tempIsHigh == false){
            BREEDING_PROBABILITY = BREEDING_PROBABILITY/2;
            tempIsHigh = true;
        }
        
        if (temp>-10 && tempIsHigh == true){
            BREEDING_PROBABILITY = BREEDING_PROBABILITY*2;
            tempIsHigh = false;
        }
        
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Increase the age.
     * This could result in the Prey's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * A Prey can breed if it has reached the breeding age.
     * @return true if the Prey can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Returns the gender of the animal.
     */
    protected int returnGender(){
        return random_Gender;
    }
    
    protected abstract void giveBirth(List<Actor> newPrey);
    
    protected abstract boolean checkGenderForBreeding();
    
}
