
/**
 /**
 * This class allows us to track the time for when the animals will be active or inactive. 
 * During the day, the sea animals will be active, where as during the night, the sea animals will be sleeping
 * The sleeping behaviour will be simulated with an abrupt stop to their mobility. 
 *
 * 
 */
public class Time
{
    
    private int timeOfDay;
    // A value of 0 indicates day, a value of 1 indicates night.

    /**
     * Constructor for objects of class Time
     * The time of the day will start from zero.
     */
    public Time()
    {
        timeOfDay = 0;
    }

    /**
     * This method calculates the time of day using the modulo operator.
     * If the remainder from the modulo is equal to zero, then the method to change the time will be called.
     * 
     * This means that both day and night last for 200 ticks.
     *
     * @param the integer value of the tick
     */
    public void calculateTimeOfDay(int tick)
    {
        if(tick%200 == 0){
            switchTimeOfDay();
        }
    }
    
    /**
     * This method changes the time of the simulation
     * If the time of the simulation is day, change it to night.
     * If it is day change to night. 
     */
    public void switchTimeOfDay(){
        if (timeOfDay == 0){
            timeOfDay = 1;
        }
        
        else if(timeOfDay == 1){
            timeOfDay = 0;
        }
    }
    
    /**
     * This method allows the time of the simulation to be retrieved.
     * @param the return type is integer
     */
    public int getTimeOfDay(int tick){
        
        calculateTimeOfDay(tick);
        
        return timeOfDay;
    }
    
    /**
     * This method allows us to know whether it is night or day.
     * There are two values for the time of the day. If the time equals 0, then we know that it is day.
     * If the time equals 1, then we know that it is night.
     */
    public String convertToString(){
        if(timeOfDay == 0){
            return "Day";   //indicating that the animals are active
        }
        
        else if(timeOfDay == 1){
            return "Night"; //indicating that the animals are asleep
        }
        
        return "Day";
    }
    
}
