import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Krill.
 * Krills age, move, breed, and die.
 * 
 * They also have to eat plants to stay alive.
 *
 * @version 2016.02.29 (2)
 */
public class Krill extends Prey
{
    private static final Random rand = Randomizer.getRandom();  // A shared random number generator to control breeding.
    
    // Characteristics shared by all Krills (class variables).

    private static final int BREEDING_AGE = 1;  // The age at which a Krill can start to breed.

    private static final int MAX_AGE = 200;  // The maximum age to which a Krill can live.

    private static final double BREEDING_PROBABILITY = 0.9; // The likelihood of a Krill breeding.

    private static final int MAX_LITTER_SIZE = 180;  // The maximum number of Krill births.
    
    private static final int MAX_INITIAL_FOOD_LEVEL = 80;  // The maximum number of Krill births.
    
    // Specific vood values.
    
    private static final int Plant_FOOD_VALUE = 80;
    
    // Individual characteristics (instance fields).
 
    private int foodLevel;

    /**
     * Create a new Krill. A Krill may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Krill will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Krill(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
        
        foodLevel = MAX_INITIAL_FOOD_LEVEL;
    }
    
    /**
     * Overrides the act method in the superclass.
     * 
     * Krills get hungry, so hunger is called to increment. Also, if they are alive, they muist give brith and move into the location they have just eaten.
     */
    public void act(List<Actor> newKrill)
    {
        
        if(Simulator.getTimeOfDay() == 0){
        incrementHunger();
    
        if(isAlive()) {
            giveBirth(newKrill);
            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        
        }
        }
    }
    
    /**
     * Check whether or not this Krill is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newKrills A list to return newly born Krills.
     */
    protected void giveBirth(List<Actor> newKrill)
    {
        boolean breed = checkGenderForBreeding();
        // New Krills are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(breed){
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Krill young = new Krill(false, field, loc); // create a new Krill and add it to newKrill.
            newKrill.add(young);
        }
        }
    }
      
    /**
     * Look for Penguins adjacent to the current location.
     * Only the first live Penguin is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());   // gets all  adjacent locations and iterates through them.
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {   // if there is a next adjacent location, then get the object at that location. 
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            
            if(actor instanceof Plants) {
                Plants plant = (Plants) actor;
                if(plant.isAlive()) { // If it is a plant, then set the krill food level and kill the plant.
                    plant.setDead();
                    foodLevel = Plant_FOOD_VALUE;
                    return where;
                }
            }
            
        }
        return null;
    }
    
    /**
     * 
     * Decrements the hunger level by one each time it is called.
     * 
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * This checks if, in an adjacent location, there is a member of the opposite sex of the same Prey subclass. 
     * 
     * Returns true if the adjacent object is male. This method is only called if the prey is female.
     */
    protected boolean checkGenderForBreeding(){
        
        List<Location> adjacentLocations = getField().adjacentLocations(getLocation());
        
        for(Location location:adjacentLocations){
                
            Object objectAtLoc = getField().getObjectAt(location);
            
            if (objectAtLoc != null){
            if (objectAtLoc.getClass() == this.getClass()){
                
                Prey objectAtLoca = (Prey) objectAtLoc;
                
                if(objectAtLoca.returnGender() != this.returnGender()){
                    return true;
                }
                
                // get the object at the adjacent location
                // get its class
                // if the class is Prey
                // check if it is the opposite sex
                // if it is, return true
                
            }
        }
        
        }
        return false;
    }
    
}
