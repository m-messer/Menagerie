import java.util.List;

/**
 * A class representing shared characteristics of animals. 
 * 
 * Can be extended in the future to add behaviour exclusive to Animals, but not other Actors.
 *
 * 
 */
public abstract class Animal extends Actor
{ 
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
    }
    
}
