import java.util.List;
import java.util.Random;

/**
 * A simple model of a Penguin.
 * Penguins age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Penguin extends Prey
{
    private static final Random rand = Randomizer.getRandom();  // A shared random number generator to control breeding.
    
    // Characteristics shared by all Penguin (class variables).

    private static final int BREEDING_AGE = 2;  // The age at which a Penguin can start to breed.

    private static final int MAX_AGE = 150;  // The age to which a Penguin can live.

    private static final double BREEDING_PROBABILITY = 0.9;    // The likelihood of a Penguin breeding.

    private static final int MAX_LITTER_SIZE = 40;  // The maximum number of Penguin births.



    /**
     * Create a new Penguin. A Penguin may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Penguin will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Penguin(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
    }

   
    /**
     * Check whether or not this Penguin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPenguins A list to return newly born Penguins.
     */
    protected void giveBirth(List<Actor> newPenguin)
    {
        boolean breed = checkGenderForBreeding();
        // New Penguins are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(breed){
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Penguin young = new Penguin(false, field, loc); // create a new penguin and add it to newPenguin.
            newPenguin.add(young);
        }
    }
    }

    /**
     * This checks if, in an adjacent location, there is a member of the opposite sex of the same Prey subclass. 
     * 
     * Returns true if the adjacent object is male. This method is only called if the prey is female.
     */
    protected boolean checkGenderForBreeding(){
        
        List<Location> adjacentLocations = getField().adjacentLocations(getLocation());
        
        for(Location location:adjacentLocations){
                
            Object objectAtLoc = getField().getObjectAt(location);
            
            if (objectAtLoc != null){
            if (objectAtLoc.getClass() == this.getClass()){
                
                Prey objectAtLoca = (Prey) objectAtLoc;
                
                if(objectAtLoca.returnGender() != this.returnGender()){
                    return true;
                }
                
                // get the object at the adjacent location
                // get its class
                // if the class is Prey
                // check if it is the opposite sex
                // if it is, return true
                
            }
            }
        
        }
        return false;
    }
}
