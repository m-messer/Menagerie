
import java.util.Random;

/**
 * The Weather Class influences the temperature of the water. 
 * As the weather changes, it will increase or decrease the temperature in the water
 * which will affect the growth rate of the plants and the birth rate of prey.
 *
 *
 * 
 */
public class Weather
{
    
    private static final Random rand = Randomizer.getRandom();  // A shared random number generator to control breeding.
    
    // instance variables - replace the example below with your own
    private int temp;

    /**
     * Constructor for objects of class Weather.
     * This will initialise the temperature of the water.
     */
    public Weather(int startTemp)
    {
        temp = startTemp;
    }

    /**
     * This method changes the temperature underwater, which in turn will affect the behaviour of plants.
     * If the random integer is 1, then temperature will increment by 1.
     * If the random integer is 2, then temperature will decrement by 1.
     */
    public void changeTemp()
    {
         int randomInt = rand.nextInt(3);
         
         if (randomInt == 1){
             temp+=1;
            }
            
         if (randomInt == 2){
             temp-=1;
            }
            
    }
    
    /**
     * This method returns the integer value of the temperature.
     */
    public int getTemp(){
        return temp;
    }
}
