
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Abstract class Predator - Superclass for all Predator species.
 * 
 * Predators have to hunt for specific prey. If they do not get prey in time, they will die.
 * 
 * They also, move, age and die.
 *
 */
public abstract class Predator extends Animal implements Disease
{
    private static final Random rand = Randomizer.getRandom(); // A shared random number generator to control breeding.
    
    private final int BREEDING_AGE; // The age at which the predator can breed.
    
    private final int MAX_AGE; // The maximum age to which the predator can live.
    
    private double BREEDING_PROBABILITY; // The likelihood of the predator breeding.

    private int MAX_LITTER_SIZE; // The maximum number of births.
    
    // Individual characteristics (instance fields).

    private int age;  // The Predator's age.
    
    private boolean diseased; // If the Predator is diseased or not.
    
    public Predator(boolean diseased, boolean randomAge, Field field, Location location, int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE)
    {
        super(field, location);

        this.BREEDING_AGE = BREEDING_AGE;
        
        this.MAX_AGE = MAX_AGE;
        
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        
        this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
  
        if (diseased == false){
            diseased = Disease.super.decideIfWillDisease();
        }
       
        this.diseased = diseased;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the Predator does most of the time: it hunts for
     * Prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param newPredators A list to return newly born Predators.
     */
    public void act(List<Actor> newPredators)
    {
        if(Simulator.getTimeOfDay() == 0){
        incrementAge(); // increment age and hunger.
        incrementHunger();
    
        if(isAlive()) {
            giveBirth(newPredators);
            
            if(diseased){   // if the current predator is disaesed, then try to pass it on to a predator of the same class.
                passOnDisease();    
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        
        }
        }
    }
    
    /**
     * 
     * Get a random adjacent location, and if there is another Predator in that location, make it diseased.
     * 
     */
    private void passOnDisease()
    {
        Object objectInAdjacentLocation = getField().randomAdjacentLocation(getLocation());
        
        if (objectInAdjacentLocation != null){  // if in the random adjacent location is a member of the same class, then make them diseased.
            if (objectInAdjacentLocation.getClass()==this.getClass()){
                Predator pred = (Predator) objectInAdjacentLocation;
                pred.setDisease();
            }
        }
    }
                
    /**
     * Increase the age. This could result in the Predator's death.
     * 
     * If the predator is diseased, then they should age twice as fast.
     * 
     */
    private void incrementAge()
    {
        if (diseased == false){ 
        age++;
        }
    
        else if (diseased == true){
        age+=2;
        }
    
        if(age > MAX_AGE) {
            setDead();
        }
        
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A Predator can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Sets the diseased status to true.
     */
    private void setDisease()
    {
        diseased = true;
    }
    
    /**
     * Returns if the Predator is diseased or not.
     */
    protected boolean getDiseased(){
        return diseased;
    }
    
    protected abstract void giveBirth(List<Actor> newPredators);
    
    protected abstract Location findFood();
    
    protected abstract void incrementHunger();
}
