import java.util.Random;
/**
 * 
 * If a mutation has occured in the predator,
 * then the disease can be passed on to other animals of the same Predator subclass species.
 *
 *
 */
public interface Disease
{
    
    static final Random rand = Randomizer.getRandom();
    
    /**
     * Using the random class, this method will determine whether the animal has been infected with the disease or not.
     * It will randomly infect the predator at birth.
     * @return The return type is a boolean value indicating whether the mutation has occured or not.
     */
    public default boolean decideIfWillDisease(){
        
        boolean mutationOccured = false;
        double mutationProbability = rand.nextDouble();
        
        if (mutationProbability <= 0.005){
            mutationOccured = true;
        }
        
        return mutationOccured;
    }
}
