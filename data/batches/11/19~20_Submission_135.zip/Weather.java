import java.util.Random;
/**
 * A Class representing the weather in the simulation.
 *
 * @version 1.0
 */
public class Weather
{
    //Contains all possible weather states.
    private static final String[] possibleWeather = {"sun", "storm", "fog", "rain"};
    //Contains the current state of the weather.
    private String currentWeather;
    //Variable to store a Random object that generates random numbers.
    private Random rand;
    /**
     * Creates a new weather object with start state "Sun".
     */
    public Weather()
    {
        currentWeather = possibleWeather[3];
        rand = new Random();
    }
    
    /**
     * Method to get the current weather.
     * @return Returns current weather.
     */
    public String getCurrentWeather() {
        return currentWeather;
    }
    /**
     * Method to generate random weather.
     * Changes currentWeather to one of the options in the Array.
     */
    public void generateWeather() {
        currentWeather = possibleWeather[rand.nextInt(4)];
    }
    
}
