import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 1.0
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 300;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;
    // The probability that a fox will be created in any given grid position.
    private static final double PREDATOR_CREATION_PROBABILITY = 0.02;
    // The probability that a rabbit will be created in any given grid position.
    private static final double PREY_CREATION_PROBABILITY = 0.09;
    // The probabilty that a animal is sick when populating the field.
    private static final double SICK = 0.02;
    // The probabilty that an animal is born sick.
    private static final double BORN_SICK = 0.04;

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    
    // The current state of the field.
    private Field field;
    // The current state of the field that holds the plants.
    private Field plantField;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A graphical view of the simulation containing the plants.
    private SimulatorView plantView;

    private Clock clock;
    
    private Weather weather;
    //A new disease in the simulation.
    private Disease fever;
    
    boolean moved = false;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        int depth = DEFAULT_DEPTH;
        int width = DEFAULT_WIDTH;
        
        weather = new Weather();
        clock = new Clock(weather);
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        fever = new Disease();
        
        field = new Field(depth, width);
        plantField = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Cheeta.class, Color.RED);
        view.setColor(Lion.class, Color.MAGENTA);
        view.setColor(Giraffe.class, Color.YELLOW);
        view.setColor(Gazelle.class, Color.GREEN);
        view.setColor(Zebra.class, Color.CYAN);
        
        plantView = new SimulatorView(depth, width);
        plantView.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal. If its night the animals only move every second step.
     * 
     * Iterates over every plant as well.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        // Let all rabbits act.
        boolean day = clock.count();
        Random rand = new Random();
        view.changeColor(day);
        moved =! moved;
        if(day) {
            actorsAct(newAnimals);
        } else if(!day && !moved) {
            actorsAct(newAnimals);
        }
           
        
        if(plants.size() != 0) {
            for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
                    Plant plant = it.next();
                    plant.act(newPlants, weather.getCurrentWeather());
                    if(! plant.isAlive()) {
                        it.remove();
                    }
                }
        } else {
            for(int row = 0; row < plantField.getDepth(); row++) {
                for(int col = 0; col < plantField.getWidth(); col++) {
                    if(rand.nextDouble() < 0.05) {
                        Location location = new Location(row, col);
                        Plant plant = new Plant(plantField, location);
                        plants.add(plant);
                    }
                }
        }
        }
            
        infectNewborns(newAnimals);
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);
        // Add all new plants to the main list.
        plants.addAll(newPlants);
        
        //Update the views that display the animal field and plant field.
        view.showStatus(step, field, weather.getCurrentWeather());
        plantView.showStatus(step, plantField, weather.getCurrentWeather());
    }
        
    /**
     * Makes all animals perform their act method.
     * @param newAnimals List for all newborn animals.
     */
    private void actorsAct(List<Animal> newAnimals) {
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
             Animal animal = it.next();
             animal.act(newAnimals, plantField);
             if(! animal.isAlive()) {
                 it.remove();
             }
        }
    }
    
    /**
     * Iterates over every newborn animal and might make it sick.
     * @param newActors List of all newborn animals.
     */
    private void infectNewborns(List<Animal> newActors) {
        Random rand = new Random();
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(!animal.isSick()) {
                if(rand.nextDouble() < BORN_SICK) {
                    animal.makeSick(fever);
                }
            }
        }
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, weather.getCurrentWeather());
        plantView.showStatus(step, plantField, weather.getCurrentWeather());
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        //populate the animal field and make random animals sick.
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PREDATOR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheeta cheeta = new Cheeta(field, location);
                    if(rand.nextDouble() <= SICK)
                        cheeta.makeSick(fever);
                    animals.add(cheeta);
                }
                else if(rand.nextDouble() <= PREDATOR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(field, location);
                    if(rand.nextDouble() <= SICK)
                        lion.makeSick(fever);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= PREY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(field, location);
                    if(rand.nextDouble() <= SICK)
                        zebra.makeSick(fever);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= PREY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Gazelle gazelle = new Gazelle(field, location);
                    if(rand.nextDouble() <= SICK)
                        gazelle.makeSick(fever);
                    animals.add(gazelle);
                }
                else if(rand.nextDouble() <= PREY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Giraffe giraffe = new Giraffe(field, location);
                    if(rand.nextDouble() <= SICK)
                        giraffe.makeSick(fever);
                    animals.add(giraffe);
                }
                
                // else leave the location empty.
            }
        }
        //Populate the plant field.
        plantField.clear();
        for(int row = 0; row < plantField.getDepth(); row++) {
            for(int col = 0; col < plantField.getWidth(); col++) {
                if(rand.nextDouble() < 0.2) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(plantField, location);
                    plants.add(plant);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
