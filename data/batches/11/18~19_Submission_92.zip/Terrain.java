import java.awt.*;

/**
 * The abstract class that is used to create a new terrain type
 *
 * @version 2019.02.20
 */
public abstract class Terrain
{
    /**
     * Returns wheather or not the terrain can be stood on by living creatures
     * @return true if tile it can be stood on
     */
    public boolean canWalkOn() {
        return true;
    }

    /**
     * A method that does nothing but is used by sub classes to do something 
     */
    public void update(){}

    /**
     * Returns the colour of the tile based on type 
     * @return the colour of a plant tile
     */
    abstract public Color getColor();
}