import java.awt.*;
import java.util.List;

/**
 * The class that state3s all the effects and behavours of humans.
 *
 * @version 2019.02.20
 */
public class Human extends Predator {

    // The generic vaules of a human being
    protected int getBreedingAge() {return 18;}
    protected int getMaxAge() {return 1000;}
    protected double getBreedingProbability() {return 0.8;}
    protected int getFoodLevel() {return 50;}
    protected int getMaxLitterSize() {return 3;}
    protected int getMoveDistance() {return 2;}
    protected int getMinHuntHunger() {return 30;}

    // The default colour and infected colour of humans
    private static final Color DEFAULT_COLOR = new Color(0xf728ff);
    private static final Color DISEASE_COLOR = new Color(0xe520c4);
    // The initial hunger of a human being
    private static final int STARTING_HUNGER_VALUE = 40;

    /**
     * Create a human at the location newFiled, newLocation and weather or not
     * it has random values.
     *
     * @param randomAge If true, the human will have random age and hunger level.
     * @param newField The field currently occupied.
     * @param newLocation The location within the field.
     */
    public Human(boolean randomAge, Field newField, Location newLocation)
    {
        super();
        field = newField;
        setLocation(newLocation);
        foodSources.add(Rabbit.class);
        foodSources.add(Cat.class);
        foodSources.add(Rat.class);
        foodSources.add(Fox.class);
        if(randomAge) {
            age = rnd.nextInt(getMaxAge());
            foodLevel = rnd.nextInt(STARTING_HUNGER_VALUE);
        }
        else {
            age = 0;
            foodLevel = STARTING_HUNGER_VALUE;
        }
    }

    /**
     * This is how the human acts, it ages, hungers, moves and breeds 
     * unrealistically followed by moving to a new location or killing a 
     * creature and moving to it's location. If there is no-where to move 
     * it will die.
     */
    public void act()
    {
        incrementAge();
        incrementHunger();
        if(alive && Timer.isDay()) {
            giveBirth();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
                spreadDisease();
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    public Color getColor() {
        if (diseases.size() > 0) {
            return DISEASE_COLOR;
        } else {
            return DEFAULT_COLOR;
        }
    }

    /**
     * Check whether or not this person is to give birth at this step.
     * New births will be made into free adjacent locations.
     */
    protected void giveBirth()
    {
        if (age < getBreedingAge()) return;

        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            new Human(false, field, loc);
        }
    }
}
