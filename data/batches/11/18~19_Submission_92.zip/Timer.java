import java.util.Random;
import java.awt.Color;
import java.util.HashMap;

/**
 * Represents the time of day in the simulation.
 *
 * @version 2019.02.20
 */
public class Timer
{
    private static Random rnd = Randomizer.getRandom();
    private static int step = 0;
    private static int time = 0;
    // half the number of steps for each day
    private static final int DAY_NIGHT_LENGTH = 3;
    private static final double WEATHER_CHANGE_CHANCE = 0.15; 
    private static Weather currentWeather = Weather.SUNNY;

    public static int getStep() {return step;}

    /**
     * Move time forward by a set amount. Randomly change the weather between 
     * a nice sunny day/clear night and a rainy day.
     */
    public static void increment() {
        step += 1;
        time += 1;
        time %= DAY_NIGHT_LENGTH * 2;
        if(rnd.nextDouble() <= WEATHER_CHANGE_CHANCE){
            switch (currentWeather) {
                case SUNNY:
                    currentWeather = Weather.RAINING;
                    break;
                case RAINING:
                    currentWeather = Weather.SUNNY;
                    break;
            }
        }
    }
    
    /**
     * Return if it's currently daytime.
     * @return true if the time is day
     */
    public static boolean isDay() {
        return time < DAY_NIGHT_LENGTH;
    }

    /**
     * Returns the colour of an empty tile based on the weather.
     * @return the colour of a tile
     */
    public static Color nightColor(){
        return Weather.nightColours.get(currentWeather);
    }

    /**
     * Returns the current weather on the board.
     * @return the current weather
     */
    public static Weather getCurrentWeather() {return currentWeather;}

    /**
     * Sets the step to 0
     */
    public static void resetStep() {step = 0; time = 0;}
}
