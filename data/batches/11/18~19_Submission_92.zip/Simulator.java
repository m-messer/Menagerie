import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2019.02.20
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.1;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.3;
    private static final double RAT_CREATION_PROBABILITY = 0.5;
    private static final double CAT_CREATION_PROBABILITY = 0.1;
    private static final double HUMAN_CREATION_PROBABILITY = 0.05;
    private static final double COLD_INFECTANCE_PROBABILITY = 0.1;
    private static final double FLU_INFECTANCE_PROBABILITY = 0.15;
    private static final double BD_INFECTANCE_PROBABILITY = 0.05;

    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay((Integer)(1000/3));
            // comment/uncomment this to run faster/slower
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        Timer.increment();

        // Provide space for newborn animals.
        for (int i = 0; i < field.getDepth(); i++) {
            for (int j = 0; j < field.getWidth(); j++) {
                Tile tile = field.getTileAt(i, j);
                tile.update();
            }
        }

        view.showStatus(Timer.getStep(), field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        Timer.resetStep();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(Timer.getStep(), field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Animal animal;
                Location location = new Location(row, col);
                if(field.getTileAt(location).canWalkOn()){
                    if(rand.nextDouble() <= HUMAN_CREATION_PROBABILITY) {
                        animal = new Human(true, field, location);
                        if (rand.nextDouble() <= COLD_INFECTANCE_PROBABILITY) {
                            animal.addDisease(new Cold());
                        }
                    } else if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                        animal = new Fox(true, field, location);
                    } else if(rand.nextDouble() <= CAT_CREATION_PROBABILITY) {
                        animal = new Cat(true, field, location);
                        if (rand.nextDouble() <= FLU_INFECTANCE_PROBABILITY) {
                            animal.addDisease(new CatFlu());
                        }
                    } else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                        animal = new Rabbit(true, field, location);
                    } else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                        animal = new Rat(true, field, location);
                        if (rand.nextDouble() <= BD_INFECTANCE_PROBABILITY) {
                            animal.addDisease(new BlackDeath());
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    public static void main(String[] args) {
        Simulator s = new Simulator();
        s.runLongSimulation();
    }
}
