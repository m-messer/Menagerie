import java.awt.Color;

/**
 * Defines the grass class and the interactions it is able to do.
 *
 * @version 2019.02.20
 */
public class Tree extends Terrain {
    // The current food and colours of the tile
    private static final Color THIS_COLOR = new Color(0x505600);

    /**
     * Returns wheather or not the terrain can be stood on by living creatures
     * @return true if tile it can be stood on
     */
    public boolean canWalkOn() {
        return false;
    }

    /**
     * Returns the colour of the tile.
     * @return healty or dying colour of plant
     */
    public Color getColor() {
        return THIS_COLOR;
    }
}
