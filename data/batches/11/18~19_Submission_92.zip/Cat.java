import java.awt.*;
import java.util.List;

/**
 * The class for the cat object used in the simulation and dictates its actions
 * and characteristics.
 *
 * @version 2019.02.20
 */
public class Cat extends Predator {

    // The general data about the creature defined in parent class
    protected int getBreedingAge() {return 10;}
    protected int getMaxAge() {return 400;}
    protected double getBreedingProbability() {return 0.8;}
    protected int getFoodLevel() {return 15;}
    protected int getMaxLitterSize() {return 5;}
    protected int getMoveDistance() {return 2;}
    protected int getMinHuntHunger() {return 10;}

    // The colours of the creature
    private static final Color DEFAULT_COLOR = new Color(0x9793c1);
    private static final Color DISEASE_COLOR = new Color(0x9b46b5);
    private static final int STARTING_HUNGER_VALUE = 30;


    /**
     * Intitialise the cat with a random age, its field and the 
     * location of the field.
     */
    public Cat(boolean randomAge, Field newField, Location newLocation)
    {
        super();
        field = newField;
        setLocation(newLocation);
        foodSources.add(Rat.class);
        foodSources.add(Fox.class);
        if(randomAge) {
            age = rnd.nextInt(getMaxAge());
            foodLevel = rnd.nextInt(STARTING_HUNGER_VALUE);
        }
        else {
            age = 0;
            foodLevel = STARTING_HUNGER_VALUE;
        }
    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     */
    public void act()
    {
        incrementAge();
        incrementHunger();
        if(alive && !Timer.isDay()) {
            giveBirth();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
                spreadDisease();
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Returns the colour of the cat based on if it is ill or not.
     * @return the colour of the cat
     */
    public Color getColor() {
        if (diseases.size() > 0) {
            return DISEASE_COLOR;
        } else {
            return DEFAULT_COLOR;
        }
    }

    /**
     * Check whether or not this cat is to give birth at this step.
     * New births will be made into free adjacent locations.
     */
    protected void giveBirth()
    {
        if (age < getBreedingAge()) return;

        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            new Cat(false, field, loc);
        }
    }

}