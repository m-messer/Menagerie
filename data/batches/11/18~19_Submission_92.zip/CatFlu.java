/**
 * The cat flu disease, affects cats and foxes and can be spread by other creatures.
 *
 * @version 2019.02.20
 */
public class CatFlu extends Disease
{
    /**
     * Initialises the cat flu class.
     */
    public CatFlu(){
        super(0.0f, 0.0f, 0.075f);
        specialCreatures.put(Fox.class, new DiseaseEffect(5.0f, 0.0f, 0.1f));
        specialCreatures.put(Cat.class, new DiseaseEffect(7.0f, 0.0f, 0.1f));
    }
    
    /**
     * Returns a new instance of this disease.
     * @return a new instance of the disease
     */
    public Disease getNewDisease(){
        return new CatFlu();
    }
}
