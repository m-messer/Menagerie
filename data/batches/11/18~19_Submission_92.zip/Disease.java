import java.util.Map;
import java.util.Random;
import java.util.HashMap;

/**
 * Abstract class Disease - write a description of the class here
 *
 * @version 2019.02.20
 */
public abstract class Disease
{
    // a randomiser item to be used by sub classes
    protected static Random rnd = Randomizer.getRandom();

    // The main effect of the disease: food loss, age rate and infection rate
    protected DiseaseEffect mainEffect;
    // Allows different animals to have different effects from a single disease.
    protected Map<Class<? extends Animal>, DiseaseEffect> specialCreatures;

    /**
     * Intitialises the base values of the disease.
     * @param newAgeRate the increase of rate at which a creature ages
     * @param newFoodLossRate the increase of rate at which a creature grows hungry
     * @param newSpreadRate the rate at which the disease spreads between animals
     */
    public Disease(float newAgeRate, float newFoodLossRate, float newSpreadRate){
        mainEffect = new DiseaseEffect(newAgeRate, newFoodLossRate, newSpreadRate);
        specialCreatures = new HashMap();
    }

    /**
     * Returns rate at which aging is affected
     * @return Rate to affect aging
     */
    public float getAgeRate(Class<? extends Animal> animal) {
        DiseaseEffect temp = specialCreatures.get(animal);
        if(temp == null){
            return mainEffect.getAgeRate();
        }
        return temp.getAgeRate();
    }

    /**
     * Returns rate at which food loss is affect
     * @return Rate to affect food loss
     */
    public float getFoodLossRate(Class<? extends Animal> animal) {
        DiseaseEffect temp = specialCreatures.get(animal);
        if(temp == null){
            return mainEffect.getFoodLossRate();
        }
        return mainEffect.getFoodLossRate();
    }

    /**
     * Returns probability that the disease will spread to another animal
     * @return Probability of spread
     */
    public float getSpreadRate(Class<? extends Animal> animal) {
        DiseaseEffect temp = specialCreatures.get(animal);
        if(temp == null){
            return mainEffect.getFoodLossRate();
        }
        return mainEffect.getSpreadRate();
    }

    abstract public Disease getNewDisease();
}
