import java.awt.Color;

/**
 * Defines the grass class and the interactions it is able to do.
 *
 * @version 2019.02.20
 */
public class Bush extends Terrain {
    // the maximum  food any grass can have
    private static final int MAX_FOOD_VALUE = 25;

    // The current food and colours of the tile
    private int foodValue = MAX_FOOD_VALUE;
    private static final Color HEALTHY_COLOR = Color.yellow;
    private static final Color DYING_COLOR = Color.white;

    /**
     * Returns the colour of the tile.
     * @return healty or dying colour of plant
     */
    public Color getColor() {
        if (foodValue >= (MAX_FOOD_VALUE/2)) {
            return HEALTHY_COLOR;
        } else {
            return DYING_COLOR;
        }
    }

    /**
     * Caled every step, increases food value and increases more if it is 
     * raining.
     */
    public void update() {
        if(foodValue < MAX_FOOD_VALUE){
            if ( Timer.getCurrentWeather() == Weather.RAINING) {
                foodValue += 3;
            }
            else
            {
                foodValue += 1;
            }
        }
    }

    /**
     * Returns the current value of food in this tile.
     * @return the ammount of food in the tile
     */
    public int getFoodValue() {
        return foodValue;
    }

    /**
     * sets the food value to the one defined
     * @param value the new food value
     */
    public void setFoodValue(int value) {
        foodValue = value;
        if (foodValue < 0) {
            foodValue = 0;
        }
    }
}
