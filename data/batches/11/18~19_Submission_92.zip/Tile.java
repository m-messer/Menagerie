import java.awt.*;
import java.util.Random;

/**
 * Tile to represent a square in the field.
 *
 * @version 2019.02.20
 */
public class Tile {
    // randomiser used for 
    private static final Random rnd = Randomizer.getRandom();

    // chances that a bush or tree spawns
    private static final double BUSH_CREATION_PROBABILITY = 0.15;
    private static final double TREE_CREATION_PROBABILITY = 0.05;

    // the animal on this tile
    private Animal animal;

    // The type of terrain in this tile
    protected Terrain terrain;

    /**
     * Initiialise the tile with a random terrain type: grass, bush or Tree.
     */
    public Tile(){
        if(rnd.nextDouble() <= BUSH_CREATION_PROBABILITY){
            terrain = new Bush();
        }
        else if(rnd.nextDouble() <= TREE_CREATION_PROBABILITY){
            terrain = new Tree();
        }
        else {
            terrain = new Grass();
        }
    }

    /**
     * Returns the animal currently on the tile.
     * @return animal on tile
     */
    public Animal getAnimal() {
        return animal;
    }

    /**
     * Assigns an animal to a tile
     * @param animal the new animal
     */
    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    /**
     * Returns the current terrain type of this tile
     * @return the terrtain of the tile
     */
    public Terrain getTerrain() {
        return terrain;
    }

    /**
     * Remove the animal currently on this tile.
     */
    public void clear() {
        this.animal = null;
    }

    /**
     * Returns the colour of the tile based on if there is an animal on it, the 
     * time and terrain type.
     * @return the colour of the tile
     */
    public Color getColor() {
        if (animal != null) {
            Color temp = animal.getColor();
            if (temp != null) {
                return animal.getColor();
            }
        }
        if (Timer.isDay()) {
            return terrain.getColor();
        } else {
            return Timer.nightColor();
        }
    }

    /**
     * Returns if the tile can be walked on
     * @return true if an animal can walk on it
     */
    public boolean canWalkOn() {
        return terrain.canWalkOn();
    }

    /**
     * updates the animal and terrain on this tile
     */
    public void update() {
        if (animal != null) {
            animal.act();
        }
        terrain.update();
    }
}
