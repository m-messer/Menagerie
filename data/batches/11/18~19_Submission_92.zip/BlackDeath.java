/**
 * The black death disease in the simulation.
 *
 * @version 2019.02.20
 */
public class BlackDeath extends Disease
{
    /**
     * The constructor for the disease, initialises to be damaging to
     * all creatures but dangerous to humans and rats.
     */
    public BlackDeath(){
        super(1.0f, 1.0f, 0.3f);
        specialCreatures.put(Human.class, new DiseaseEffect(10.0f, 10.0f, 0.6f));
        specialCreatures.put(Rat.class, new DiseaseEffect(4.0f, 3.0f, 0.5f));
    }
    
    /**
     * Returns a new instance of this disease to be applied to a new creature
     * @return a new instance of this disease
     */
    public Disease getNewDisease(){
        return new BlackDeath();
    }
}
