/**
 * Gender used by al creatures to dictate which creatures can breed with
 */
public enum Gender
{
    MALE, FEMALE
}
