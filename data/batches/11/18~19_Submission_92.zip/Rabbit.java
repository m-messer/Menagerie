import java.awt.*;
import java.util.List;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Rabbit extends Animal
{
    // Constant haracteristics shared by all rabbits
    protected int getBreedingAge() {return 5;}
    protected int getMaxAge() {return 50;}
    protected double getBreedingProbability() {return 0.8;}
    protected int getFoodLevel() {return 12;}
    protected int getMaxLitterSize() {return 4;}
    protected int getMoveDistance() {return 2;}

    // Some constants, initial food and colours of the creature
    private static final int STARTING_FOOD_LEVEL = 10;
    private static final int GRASS_FEED_VALUE = 5;
    private static final Color DEFAULT_COLOR = Color.orange;
    private static final Color DISEASE_COLOR = Color.red;

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param newField The field currently occupied.
     * @param newLocation The location within the field.
     */
    public Rabbit(boolean randomAge, Field newField, Location newLocation)
    {
        super(newField, newLocation);
        if(randomAge) {
            age = rnd.nextInt(getMaxAge());
        }
        else {
            age = 0;
        }
        foodLevel = STARTING_FOOD_LEVEL;
    }
    
    /**
     * This is what the rabbit does most of the time - it runs 
     * around, eat and sometimes it will breed or die of old age.
     */
    public void act()
    {
        incrementAge();
        incrementHunger();
        if(alive && Timer.isDay()) {
            giveBirth();
            if (foodLevel < STARTING_FOOD_LEVEL - GRASS_FEED_VALUE) {
                Terrain terrain = field.getTileAt(location).getTerrain();
                if (terrain instanceof Grass) {
                    Grass grass = (Grass) terrain;
                    if (grass.getFoodValue() >= GRASS_FEED_VALUE) {
                        grass.setFoodValue(grass.getFoodValue() - GRASS_FEED_VALUE);
                        foodLevel += GRASS_FEED_VALUE;
                    }
                }
            }
            // Try to move into a free location.
            Location newLocation = getNewLocation();
            if(newLocation != null) {
                setLocation(newLocation);
                spreadDisease();
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increases the value of hunger by 1 and the total of all the diseases 
     * effecting this creature
     */
    protected void incrementHunger()
    {
        foodLevel -= calculateFoodLossRate();
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     */
    protected void giveBirth()
    {
        if (age < getBreedingAge()) return;

        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            new Rabbit(false, field, loc);
        }
    }

    /**
     * Returns the colours of the animal based on if it is ill.
     * @return colour of the rabbit based on it's health
     */
    public Color getColor() {
        if (diseases.size() > 0) {
            return DISEASE_COLOR;
        } else {
            return DEFAULT_COLOR;
        }
    }
}
