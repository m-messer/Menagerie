/**
 * Stores the values of what what the diseases do.
 *
 * @version 2019.02.20
 */
public class DiseaseEffect
{
    // The increase in a creatures rate of aging
    protected float ageRate;
    // The rate at which a creature with the diesease loses food
    protected float foodLossRate;
    // The rate at which the diesease spreads
    protected float spreadRate;

    /**
     * Initialise the stats that the effect.
     * @param newAgeRate the value added to the rate of a creature ages
     * @param newFoodLossRate the value added to the rate of a creature starves
     * @param newSpreadRate the value of how quickly the disease spreads
     */
    public DiseaseEffect(float newAgeRate, float newFoodLossRate, 
        float newSpreadRate){
        ageRate = newAgeRate;
        foodLossRate = newFoodLossRate;
        spreadRate = newSpreadRate;
    }
    
    /**
     * Returns the amount a creature ages
     * @return a float that dictates the increase in rate of ageing
     */
    public float getAgeRate(){
        return ageRate;
    }

    /**
     * Returns the amount a creature loses food/starves
     * @return a float that dictates the increase in rate of losing food/starves
     */
    public float getFoodLossRate(){
        return foodLossRate;
    }

    /**
     * Returns the amount a disease spreads
     * @return a float that dictates the rate a disease spreads
     */
    public float getSpreadRate(){
        return spreadRate;
    }
}
