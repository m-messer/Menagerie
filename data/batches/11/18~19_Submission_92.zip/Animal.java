import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.20
 */
public abstract class Animal
{
    protected static final Random rnd = Randomizer.getRandom();

    // Whether the animal is alive or not.
    protected boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;
    
    // The age and gender of the animal
    protected float age;
    protected Gender gender;

    // A list of all the diseases that have infected the creature
    protected List<Disease> diseases;
    
    // The maount of food insider an animal
    protected float foodLevel;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        this();
        this.field = field;
        setLocation(location);
        field.placeAnimal(this, location);
    }

    /**
     * Create a new animal
     */
    public Animal()
    {
        createGender();
        alive = true;
        diseases = new ArrayList<>();
    }

    // A list of functions called to get the corresponding values of the animal
    /**
     * Return the minimum integer age which an animal can breed.
     * @return the minimum age the creature can breed.
     */
    abstract protected int getBreedingAge();
    /**
     * Returns the maximum age an animal can live to.
     * @return the oldest age an an animal can live to.
     */
    abstract protected int getMaxAge();
    /**
     * Returns the chance that a male and female of a species can breed.
     * @return the chance an animal breeds.
     */
    abstract protected double getBreedingProbability();
    /**
     * Returns the current food of an animal.
     * @return the amount of food an animal has.
     */
    abstract protected int getFoodLevel();
    /**
     * Retuns the maximum number of creatures that can be born at once.
     * @return the maximum  number of creatures that can be birthed at once.
     */
    abstract protected int getMaxLitterSize();
    /**
     * Returns the maximum distance a creature can move in one turn.
     * @return the amount a creature moves in a turn.
     */
    abstract protected int getMoveDistance();
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     */
    abstract public void act();

    /**
     * Returns the colour of the creature based on if it is alive/ill.
     * @return the color of the animal to be displayed.
     */
    abstract public Color getColor();

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.placeAnimal(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Returns the gender of the animal.
     * @return the gender.
     */
    public Gender getGender(){
        return gender;
    }
    
    /**
     * Default assignment of gender, can be overridden in child
     * classes to create different gender imbalances
     */
    protected void createGender(){
        if(rnd.nextDouble() <= 0.5){
            gender = Gender.MALE;
        }
        else
        {
            gender = Gender.FEMALE;
        }
    }

    /**
     * Adds a disease to the animal
     * @param disease Disease to add
     */
    protected void addDisease(Disease disease) {
        diseases.add(disease);
    }

    public List<Disease> getDiseases() {return diseases;}
    
    protected void spreadDisease(){
        if(diseases.size() == 0) return;

        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        for (Location where : adjacentLocations) {
            Animal creature = field.getTileAt(where).getAnimal();
            if (creature != null) {
                for (Disease disease : diseases) {
                    if (
                        (Randomizer.getRandom().nextFloat() 
                            <= disease.getSpreadRate(this.getClass())) &&
                        (creature.getDiseases().stream().filter(
                                d -> d.getClass() == disease.getClass()
                            ).count() == 0)
                    ){
                        creature.addDisease(disease.getNewDisease());
                    }
                }
            }
        }
    }

    /**
     * Calculate total aging rate caused by diseases
     * @return Sum of disease age rates
     */
    protected float calculateAgeRate() {
        float ret = 1.0f;
        for (Disease d : diseases) {
            ret += d.getAgeRate(this.getClass());
        }
        return ret;
    }

    /**
     * Calculate total food loss rate caused by diseases
     * @return Sum of disease food loss rates
     */
    protected float calculateFoodLossRate() {
        float ret = 1.0f;
        for (Disease d : diseases) {
            ret += d.getFoodLossRate(this.getClass());
        }
        return ret;
    }

    /**
     * Returns weather the animal is olde enough to breed.
     * @return if the animal is able to breed.
     */
    protected boolean canBreed()
    {
        return age >= getMaxAge();
    }

    /**
     * Returns true when the animal is next to a creature that is capable
     * of breeding with this one.
     * @return if the creature is next to a suitable partner.
     */
    protected boolean isNextToBreedable(){
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Animal animal = field.getTileAt(where).getAnimal();
            if (this.getClass().isInstance(animal) && animal.getGender() != gender) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the new location a creature can move to.
     * Returns null if no suitable ocation is available.
     * @return the new location a creature can move to.
     */
    protected Location getNewLocation() {
        Location ret = getLocation();
        int moveDistance = getMoveDistance();
        for (int i = 0; i < moveDistance; i++) {
            ret = field.freeAdjacentLocation(ret);
            if (ret == null) {
                return null;
            }
        }
        return ret;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rnd.nextDouble() <= getBreedingProbability() && isNextToBreedable()) {
            births = rnd.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Increase the age of an animal and kill it of old age using
     * it's own maximum age
     */
    protected void incrementAge()
    {
        age += calculateAgeRate();
        if(age > getMaxAge()) {
            setDead();
        }
    }
}
