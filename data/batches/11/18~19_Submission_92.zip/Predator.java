import java.util.ArrayList;
import java.util.List;

/**
 * Creates a basic predator class with data related to eating other animals.
 *
 * @version 2019.02.20
 */
public abstract class Predator extends Animal
{
    // A list of the things an animal can eat.
    public List<Class<? extends Animal>> foodSources;
    // The food level, which is increased by eating.
    abstract protected int getMinHuntHunger();

    /**
     * Constructor for objects of class Predator, sets hunger to 0 and 
     * initialises the array.
     */
    public Predator()
    {
        super();
        foodLevel = 0;
        foodSources = new ArrayList<Class<? extends Animal>>();
    }

    /**
     * Returns the location of a suitable food source.
     * Returns null if there is none.
     * @return location if a suitable food source is located.
     */
    protected Location findFood()
    {
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Animal animal = field.getTileAt(where).getAnimal();
            if(
                (foodLevel <= getMinHuntHunger()) &&
                (animal != null) &&
                (foodSources.contains(animal.getClass())) &&
                (animal.isAlive())
            ) {
                List<Disease> diseaseCheck = animal.getDiseases();
                if(diseaseCheck.size() > 0){
                    for(Disease temp : diseaseCheck){
                        boolean canBeAdded = true;
                        for(Disease check : diseases){
                            if(check.getClass() == temp.getClass()){
                                canBeAdded = false;
                                break;
                            }
                        }
                        if(canBeAdded){
                            diseases.add(temp);
                        }
                    }
                }
                animal.setDead();
                foodLevel += animal.getFoodLevel();
                return where;
            }
        }
        return null;
    }
    
    /**
     * Make this creature more hungry. This could result in their death.
     */
    protected void incrementHunger()
    {
        foodLevel -= calculateFoodLossRate();
        if(foodLevel <= 0) {
            setDead();
        }
    }
}
