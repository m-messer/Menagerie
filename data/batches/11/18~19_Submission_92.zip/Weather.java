import java.util.Map;
import java.util.HashMap;
import java.awt.Color;

/**
 * An enumeration that stores wether as well as the colour of the weather 
 * during the night.
 *
 * @version 2019.02.20
 */
public enum Weather
{
    SUNNY, RAINING;

    // Stores the Weather: Colour relationship dor displaying tiles at night
    public static final Map<Weather, Color> nightColours =
        new HashMap<Weather, Color>(){
            {
                put(SUNNY, Color.black);
                put(RAINING, Color.lightGray);
            }
        };
}