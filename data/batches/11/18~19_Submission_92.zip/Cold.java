/**
 * The common cold, affects humans and can be spread by other creatures.
 *
 * @version 2019.02.20
 */
public class Cold extends Disease
{
    /**
     * Initialises the class.
     */
    public Cold(){
        super(0.0f, 0.0f, 0.0075f);
        specialCreatures.put(Human.class, new DiseaseEffect(0.75f, 0.0f, 0.1f));
    }
    
    /**
     * Returns a new instance of the Cold class.
     * @return a new instance of cold.
     */
    public Disease getNewDisease(){
        return new Cold();
    }
}
