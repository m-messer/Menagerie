import java.awt.*;
import java.util.List;

/**
 * The Rat creature in the simulation, it will efgfect the behavour and details
 * of the animal.
 *
 * @version 2019.02.20
 */
public class Rat extends Predator {

    // Some constants used by the Rat
    protected int getBreedingAge() {return 1;}
    protected int getMaxAge() {return 30;}
    protected double getBreedingProbability() {return 0.9;}
    protected int getFoodLevel() {return 6;}
    protected int getMaxLitterSize() {return 6;}
    protected int getMoveDistance() {return 3;}
    protected int getMinHuntHunger() {return 3;}

    private static final Color DEFAULT_COLOR = new Color(0x8fe8c4);
    private static final Color DISEASE_COLOR = new Color(0xa5db85);

    // The default hunger value a rat starts with
    private static final int STARTING_HUNGER_VALUE = 5;

    /**
     * Create a new rat. States if the creature should start with randomised 
     * values and its intial Field and Location.
     *
     * @param randomAge If true, the rat will have a random age.
     * @param newField The field currently occupied.
     * @param newLocation The location within the field.
     */
    public Rat(boolean randomAge, Field newField, Location newLocation)
    {
        super();
        field = newField;
        setLocation(newLocation);
        if(randomAge) {
            age = rnd.nextInt(getMaxAge());
        }
        else {
            age = 0;
        }
        foodSources.add(Fox.class);
        foodSources.add(Rabbit.class);
        foodSources.add(Human.class);
    }

    /**
     * The creature grows older,  hungeras and tries to give birth.
     */
    public void act()
    {
        incrementAge();
        incrementHunger();
        if(alive) {
            giveBirth();
            if (foodLevel < getMinHuntHunger()) {
                Terrain terrain = field.getTileAt(location).getTerrain();
                if (terrain instanceof Grass) {
                    Grass grass = (Grass) terrain;
                    if (grass.getFoodValue() >= getMinHuntHunger()) {
                        grass.setFoodValue(grass.getFoodValue() - getMinHuntHunger());
                        foodLevel += getMinHuntHunger();
                    }
                }
            }
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
                spreadDisease();
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     */
    protected void giveBirth()
    {
        if (age < getBreedingAge()) return;

        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            new Rat(false, field, loc);
        }
    }

    /**
     * Returns the colour of a creature based on if it is ill or healthy.
     * @return the colour of the creature
     */
    public Color getColor() {
        if (diseases.size() > 0) {
            return DISEASE_COLOR;
        } else {
            return DEFAULT_COLOR;
        }
    }
}