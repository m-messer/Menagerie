import java.util.Random;
/**
 * Weather simulation
 */
public class Weather
{
    // instance variables
    private static final Random rand = Randomizer.getRandom();
    private static final double RAIN_CHANCE = 0.8;
    private boolean isRaining;
    /**
     * Constructor for objects of class Weather.
     * Resets the weather to normal.
     */
    public Weather()
    {
        // initialise instance variables
        reset();
    }

    /**
     * Decides whether its raining or not through a randomizer.
     */
    public void simulateOneStep(){
        isRaining = rand.nextDouble() <= RAIN_CHANCE;
    }

    /**
     * Returns where if it is raining.
     * @return true if it is raining.
     */
    public boolean isRaining(){
        return isRaining;
    }

    /**
     * Resets the weather to initial values.
     */
    public void reset(){
        isRaining=true;
    }

}
