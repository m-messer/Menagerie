import java.util.List;
import java.util.Random;
/**
 * Model of Grass
 */
public class Grass extends Plant
{
    // Class variables
    // Random generator with a set sed.
    private static final Random rand = Randomizer.getRandom();
    private static final double GRASS_SPREAD_CHANCE =0.1;
    // The maximum amount of grass to spawn nearby.
    private static final int MAX_SEED = 4;

    /**
     * Constructor for objects of class Grass
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * If the grass exists, it attempts to spawn grass.
     */
    public void act(List<Food> newGrass){
        if (isAlive()){
            if(canSpread()){
                spawnGrass(newGrass);
            }

        }
    }

    /**
     * This is what the Grass does most of the time: it spreads
     * and feeds animals
     * @param newGrass The list of new grass that will be spawned.
     */
    private void spawnGrass(List<Food> newGrass)
    {
        // New Grass is spawned into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int numberOfGrassToSpawn = numberOfSeeds();
        for(int b = 0; b < numberOfGrassToSpawn && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Object food = field.getObjectAt(loc);
            if(!(food instanceof Grass)) {
                Grass sapling = new Grass(field, loc);
                newGrass.add(sapling);
            }
        }
    }

    /**
     * Generate a number representing the number of seeds,
     * if it can breed.
     * @return The number of seeds (may be zero).
     */
    private int numberOfSeeds()
    {
        int seed = 0;
        if (rand.nextDouble() <= GRASS_SPREAD_CHANCE){
            seed = rand.nextInt(MAX_SEED) + 1;
        }
        return seed;
    }
}

