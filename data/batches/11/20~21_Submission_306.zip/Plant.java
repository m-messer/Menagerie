import java.util.List;
/**
 *  Creating a Plant class. New plants can extend from this class.
 */
public abstract class Plant extends Food
{
    // Class variables.
    protected static final Weather WEATHER = World.getWeather();
    protected static final Time TIME = World.getTime();

    /**
     * Abstract class to create other plants.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);

    }

    /**
     * Checks whether the plant is able to grow.
     * @return True if raining and is day.
     */
    protected boolean canSpread(){
        return (WEATHER.isRaining() && TIME.isDay());
    }

    /**
     * Make this object act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlant A list to receive newly grown plants.
     */
    abstract public void act(List<Food> newPlant);
}