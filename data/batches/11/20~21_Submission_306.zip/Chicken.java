import java.util.List;
import java.util.Iterator;

/**
 * Model of Chicken
 */
public class Chicken extends Animal
{
    // Characteristics shared by all Chickens (class variables).

    // The age at which a Chicken can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a Chicken can live.
    private static final int MAX_AGE = 800;
    // The likelihood of a Chicken breeding.
    private static final double BREEDING_PROBABILITY = 0.99;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // Grass food value
    private static final int GRASS_FOOD_VALUE = 50;

    // Disease spread chance
    private static final double DISEASE_SPREAD_CHANCE = 0.2;
    // Disease survive chance once infected.
    private static final double DISEASE_SURVIVE_CHANCE = 0.96;

    // Individual characteristics (instance fields).
    // The Chicken's age.
    private int age;
    // The Chicken's food level, which is increased by eating Grass.
    private int foodLevel;

    /**
     * Create a Chicken. A Chicken can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Chicken will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Chicken(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = Animal.RAND.nextInt(MAX_AGE);
            foodLevel = Animal.RAND.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * Checks whether the animal is infected. If so
     * it tries to spread the disease to nearby animals.
     */
    private void attemptSpreadDisease() {
        if (isInfected()) {
            if (RAND.nextDouble() > DISEASE_SPREAD_CHANCE) {
                return;
            }
            spreadDiseaseNearby();
        }
    }

    /**
     * This is what the Chicken does most of the time: searches for grass.
     * In the process, it might breed, die of hunger,
     * or die of old age.
     */
    public void act(List<Food> newChicken)
    {
        incrementAge();
        if (isNight()){
            return;
        }
        if(isInfected()){
            if (RAND.nextDouble() > DISEASE_SURVIVE_CHANCE){
                this.setDead();
            }
        }
        incrementHunger();
        if(isAlive()) {
            attemptSpreadDisease();
            giveBirth(newChicken);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the Chicken's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Chicken more hungry. This could result in the Chicken's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Chickens adjacent to the current location.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Grass) {
                Grass grass = (Grass) food;
                if(grass.isAlive()) {
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Enabling Chicken to reproduce or eat grass instead
     */
    private void giveBirth(List<Food> newChickens)
    {
        // New Chickens are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        if (getGender().equals("female")){
            List<Location> nearbyAnimals = field.adjacentLocations(getLocation());
            Iterator<Location> it = nearbyAnimals.iterator();
            while(it.hasNext()){
                Object animal = field.getObjectAt(it.next());
                if(animal instanceof Chicken){
                    Chicken nearbyChicken = (Chicken) animal;
                    if(nearbyChicken.getGender().equals("male")){
                        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Object food = field.getObjectAt(loc);
                            if(food instanceof Grass) {
                                Grass grass = (Grass) food;
                                grass.setDead();
                            }
                            Chicken young = new Chicken(false, field,loc);
                            newChickens.add(young);
                        }
                        return;
                    }
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && Animal.RAND.nextDouble() <= BREEDING_PROBABILITY) {
            births = Animal.RAND.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Chicken can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
