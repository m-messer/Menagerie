import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Creating an Animal class
 */
public abstract class Animal extends Food
{
    /**
     * Generating gender, age, location, disease for animals
     */
    // Class variables

    // Chance of an animal having a disease.
    private static final double DISEASE = 0.001;
    protected static final Random RAND = Randomizer.getRandom();
    private static final Time TIME = World.getTime();

    // Instance variables
    private String gender;
    private boolean infected;

    /**
     * Create a new object at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        gender = generateGender();
        infected = generateInitialDisease();
    }

    private boolean generateInitialDisease()
    {
        return RAND.nextDouble() < DISEASE;
    }

    /**
     * Randomly generates a gender male or female
     */
    private String generateGender()
    {
        if (RAND.nextInt(2) == 1){
            return "Male";
        }
        else{
            return "Female";
        }
    }

    /**
     * Checks whether the time is day or night
     * @return true if night.
     */
    protected boolean isNight()
    {
        return !(TIME.isDay());
    }

    /**
     * Retrieves the gender of the animal.
     * @return The gender "male" or "female"
     */
    protected String getGender()
    {
        return gender;
    }

    /**
     * Sets the disease status of Animal to parameter specified.
     * @param newInfected the new state to set the animals infection variable to.
     */
    protected void setDisease(boolean newInfected)
    {
        infected = newInfected;
    }

    /**
     * Retrieves the animals infection status.
     * @return true if the current animal is infected.
     */
    protected boolean isInfected()
    {
        return infected;
    }

    /**
     * Implementing spread of disease to other animals
     */
    protected void spreadDiseaseNearby()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if (food instanceof Animal) {
                Animal animal = (Animal) food;
                animal.setDisease(true);
            }
        }
    }

}
