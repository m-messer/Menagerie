import java.util.List;

/**
 * A class representing objects classified as food (animals or plants).
 */
public abstract class Food
{
    // Whether the object is alive or not.
    private boolean alive;
    // The object's field.
    private Field field;
    // The object's position in the field.
    private Location location;

    /**
     * Create a new object at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Food(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this object act - that is: make it do
     * whatever it wants/needs to do.
     * @param newFoods A list to receive newly created objects.
     */
    abstract public void act(List<Food> newFoods);

    /**
     * Check whether the object is alive or not.
     * @return true if the object is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the object is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the object's location.
     * @return The object's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the object at the new location in the given field.
     * @param newLocation The object's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the object's field.
     * @return The object's field.
     */
    protected Field getField()
    {
        return field;
    }
}
