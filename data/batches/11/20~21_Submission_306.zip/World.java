/**
 * Class containing the World's parameters for Time and Weather
 */
public class World {
    // Class variables.
    private static final Weather WEATHER = new Weather();
    private static final Time TIME = new Time();

    /**
     * World class constructor.
     */
    public World(){
    }

    /**
     * Retrieves the time object.
     * @return the time object.
     */
    public static Time getTime(){
        return TIME;
    }

    /**
     * Retrieves the weather object.
     * @return the weather object.
     */
    public static Weather getWeather()
    {
        return WEATHER;
    }

    /**A
     * Simulates one step for both weather and time.
     */
    public static void simulateOneStep(){
        WEATHER.simulateOneStep();
        TIME.simulateOneStep();
    }

    /**
     * Resets the values for the weather and time
     * objects to initial values.
     */
    public static void reset(){
        WEATHER.reset();
        TIME.reset();
    }

}
