import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Animals and Plants.
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probabilities the animals will spawn on the field.
    private static final double MOUNTAIN_LION_CREATION_PROBABILITY = 0.005;
    private static final double CHICKEN_CREATION_PROBABILITY =  0.2;
    private static final double BEAR_CREATION_PROBABILITY = 0.005;
    private static final double SHEEP_CREATION_PROBABILITY = 0.10;
    private static final double GRASS_CREATION_PROBABILITY = 0.4;
    private static final double WOLF_CREATION_PROBABILITY = 0.02;
    // The probability a natural disaster will happen at each step.
    private static final double NATURAL_DISASTER_CHANCE = 0.0001;
    // The Probability an animal will survive this natural disaster.
    private static final double NATURAL_DISASTER_SURVIVE_CHANCE = 0.02;

    // A randomizer with a set seed.
    protected static final Random rand = Randomizer.getRandom();
    // List of animals in the field.
    private List<Food> foods;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        foods = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field. with the foods colour on the field.
        view = new SimulatorView(depth, width);
        view.setColor(Chicken.class, Color.BLUE);
        view.setColor(MountainLion.class, Color.ORANGE);
        view.setColor(Bear.class, Color.RED);
        view.setColor(Sheep.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Wolf.class, Color.MAGENTA);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {

            simulateOneStep();
            // delay(10);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Food object.
     */
    public void simulateOneStep()
    {
        step++;
        World.simulateOneStep();
        if (rand.nextDouble() < NATURAL_DISASTER_CHANCE) {
            simulateNaturalDisaster();
        }
        // Provide space for newly generated  food objects.
        List<Food> newFoods = new ArrayList<>();
        // Let all food objects act.
        for(Iterator<Food> it = foods.iterator(); it.hasNext(); ) {
            Food food = it.next();
            food.act(newFoods);
            if(! food.isAlive()) {
                it.remove();
            }
        }

        // Add the newly generated food to the main lists.
        foods.addAll(newFoods);
        // System.out.println(""+newFoods.size()); // Displays number of new food
        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        view.setInfoText("");
        step = 0;
        World.reset();
        Randomizer.reset();
        foods.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with Animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= MOUNTAIN_LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    MountainLion MountainLion = new MountainLion(true, field, location);
                    foods.add(MountainLion);
                }
                else if(rand.nextDouble() <= CHICKEN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Chicken Chicken = new Chicken(true, field, location);
                    foods.add(Chicken);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass( field, location);
                    foods.add(grass);
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, field, location);
                    foods.add(bear);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sheep sheep = new Sheep(true, field, location);
                    foods.add(sheep);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    foods.add(wolf);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * This method iterates through every food object on the field
     * and remove it if the randomizer is above a certain value.
     */
    private void simulateNaturalDisaster(){
        System.out.print("Natural disaster");
        for(Iterator<Food> it = foods.iterator(); it.hasNext(); ) {
            Food food = it.next();
            if (rand.nextDouble() > NATURAL_DISASTER_SURVIVE_CHANCE){
                food.setDead();
            }
        }
        view.setInfoText("Natural disaster happened");
    }

    /**
     * Pause for a given time.
     * @param millisecond  The time to pause for, in milliseconds
     */
    private void delay(int millisecond)
    {
        try {
            Thread.sleep(millisecond);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Testing code
     */
    public static void main( String[] args) {
        Simulator sim = new Simulator(120,200);
        int num = 2000;

        sim.simulate(num);
    }
}
