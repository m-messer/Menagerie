import java.util.List;
import java.util.Iterator;

/**
 *  Model of Wolf
 */
public class Wolf extends Animal
{
    // Characteristics shared by all Wolves (class variables).

    // The age at which a Wolf can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Wolf can live.
    private static final int MAX_AGE = 600;
    // The likelihood of a Wolf breeding.
    private static final double BREEDING_PROBABILITY =0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single Chicken. In effect, this is the
    // number of steps a Wolf can go before it has to eat again.
    private static final int CHICKEN_FOOD_VALUE = 10;
    // Sheep food value
    private static final int SHEEP_FOOD_VALUE = 20;
    // Disease spread chance
    private static final double DISEASE_SPREAD_CHANCE = 0.2;
    // Disease survive chance once infected.
    private static final double DISEASE_SURVIVE_CHANCE = 0.99;

    // Individual characteristics (instance fields).
    // The Wolf's age.
    private int age;
    // The Wolf's food level, which is increased by eating Chickens and Sheep.
    private int foodLevel;

    /**
     * Create a Wolf. A Wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = Animal.RAND.nextInt(MAX_AGE);
            foodLevel = Animal.RAND.nextInt(SHEEP_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SHEEP_FOOD_VALUE;
        }
    }

    /**
     * Checks whether the animal is infected. If so
     * it tries to spread the disease to nearby animals.
     */
    private void attemptSpreadDisease() {
        if (isInfected()) {
            if (RAND.nextDouble() > DISEASE_SPREAD_CHANCE) {
                return;
            }
            spreadDiseaseNearby();
        }
    }

    /**
     * This is what the Wolf does most of the time: it hunts for sheep, chickens.
     * In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newWolf A list to return newly born Wolfs.
     */
    public void act(List<Food> newWolf)
    {
        incrementAge();
        incrementHunger();
        if(isInfected()){
            if (RAND.nextDouble() > DISEASE_SURVIVE_CHANCE){
                this.setDead();
            }
        }
        if(isAlive()){
            attemptSpreadDisease();
            giveBirth(newWolf);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the Wolf's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Wolf more hungry. This could result in the Wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Food adjacent to the current location.
     * Only the first live Animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Sheep) {
                Sheep sheep = (Sheep) food;
                if(sheep.isAlive()) {
                    sheep.setDead();
                    foodLevel = SHEEP_FOOD_VALUE;
                    return where;
                }
            }
            if(food instanceof Chicken) {
                Chicken chicken = (Chicken) food;
                if(chicken.isAlive()) {
                    chicken.setDead();
                    foodLevel = CHICKEN_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolfs A list to return newly born Wolves.
     */
    private void giveBirth(List<Food> newWolfs)
    {
        // New Wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        if (getGender().equals("female")){
            List<Location> nearbyAnimals = field.adjacentLocations(getLocation());
            Iterator<Location> it = nearbyAnimals.iterator();
            while(it.hasNext()){
                Object animal = field.getObjectAt(it.next());
                if(animal instanceof Wolf){
                    Wolf nearbyWolf = (Wolf) animal;
                    if(nearbyWolf.getGender().equals("male")){
                        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Object food = field.getObjectAt(loc);
                            if(food instanceof Grass) {
                                Grass grass = (Grass) food;
                                grass.setDead();
                            }
                            Wolf young = new Wolf(false, field,loc);
                            newWolfs.add(young);
                        }
                        return;
                    }
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && Animal.RAND.nextDouble() <= BREEDING_PROBABILITY) {
            births = Animal.RAND.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Wolf can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
