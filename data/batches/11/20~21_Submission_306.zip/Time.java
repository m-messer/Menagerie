/**
 * Creating a Time simulator
 */
public class Time {

    // Instance variables
    private int time;

    /**
     * The constructor for time.
     * Resets the time to initial values.
     */
    public Time(){
        reset();
    }

    /**
     * Increases time by 1.
     */
    public void simulateOneStep(){
        time++;
    }

    /**
     * Calculates the "corrected" time and returns the value.
     * @return Returns the time within the ranges of 0 to 23.
     */
    public int getHour(){
        return time%24;
    }

    /**
     * Returns true time is between 6 and 20 inclusive.
     * @return true if day.
     */
    public boolean isDay(){
        int adjustedTime = getHour();
        return adjustedTime <= 20 && adjustedTime >= 6;
    }

    /**
     * Resets time to initial values.
     */
    public void reset(){
        time = 0;
    }
}
