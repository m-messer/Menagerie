/**
 * A class to simulate time change.
 * 
 * @16/02/2020
 */
public class Time
{
    private int hour;
    private boolean isDaytime;
    
    /**
     * Set the initial time as 0.
     */
    public Time(){
        hour = 0;
        isDaytime = true;
        
    }
    
    /**
     * When the daytime past, update one day.
     */
    public void updateTime(int step)
    {
        isDaytime = !isDaytime;
        updateDay();
    }
    
    /**
     * Get the hour.
     */
    public int getHour(){
        return hour;
    }
    
    /**
     * Determine daytime.
     */
    public boolean isDaytime(){
        return isDaytime;
    }
    
    /**
     * Define a day
     */
    public void updateDay(){
            
            hour++;
            hour = hour%24;
            setDay();
        
    }
    
    /**
     * Set from 6 to 21 hours is daytime for a day.
     */
    public void setDay(){
        if(hour>=6 && hour<21){
            isDaytime = true;
        }
        else{
            isDaytime = false;
        }
    }
    
}
