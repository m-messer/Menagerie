import java.util.Random;
/**
 * A class representing the change and behavior of the weather.
 *  
 * @16/02/2020
 */
public class Weather
{
    private String weather;
    
    private static final Random rand = Randomizer.getRandom();
    
    private String[] weathers = {"sunny","rain"};
    
    private Weather(){
        
    }
    
    /**
     * Return the string of weather.
     */
    public String getWeather(){
        return weather;
    } 
    
    /**
     * Set the weather change to sunny and rain randomly.
     */
    public void setWeather(){
        if(rand.nextDouble()<=0.5){
            weather = "sunny";
        }
        else if(rand.nextDouble()<=1.0){
            weather = "rain";
        }
    }
}
