import java.util.Random;
import java.util.List;
/**
 * A simple model of a Plant.
 * Plants age, breed, and die.
 * 
 */

public class Plant
{
    // Characteristics shared by all Plants (class variables).
    
    private int age;
    private boolean alive;
    private Location location;
    private Field field;
    private Random random = new Random();
    
    // The age at which a Plant can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a Plant can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a Plant breeding.
    private static double BREEDING_PROBABILITY = 0.99;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 200;
    
    private Weather weather;
    /**
     * Create a new Plant.
     */
    public Plant(Field field, Location location){
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Increase the age.
     * This could result in the Plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Plants randomly growth but it will die if there are no sufficient area.
     */
    public void act(List<Plant> newPlants)
    {
        incrementAge();
        updateRate();
        if(isAlive()) {
            giveBirth(newPlants);
        }
        else{
            setDead();
        }
    }
    
    /**
     * Set the position of a plant.
     */
    private void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Retrun the field of plants.
     */
    private Field getField()
    {
        return field;
    }
    
    /**
     * Whether the plant alive or not.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Set the plant's death.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Select the random location of a plant.
     */
    private Location selectRandomLocation(){
        Field field = getField();
        
        if (getField() != null){
            Location randomLocation;
            
            int row = random.nextInt(field.getDepth());
            int column = random.nextInt(field.getWidth());
            
            randomLocation = new Location (row, column);
            
            return randomLocation;
        }
        else{
            return null;
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && random.nextDouble() <= BREEDING_PROBABILITY) {
            births = random.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Sheep can breed if it has reached the breeding age.
     * @return true if the Sheep can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Check whether or not this Sheep is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSheeps A list to return newly born Sheeps.
     */
    private void giveBirth(List<Plant> newPlants)
    {
        // New Sheeps are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(field, loc);
            newPlants.add(young);
        }
    }
    
    /**
     * The plant update rate will change as weather change.
     */
    private void updateRate(){
        if(weather.getWeather().equals("sunny")){
            BREEDING_PROBABILITY = 0.20;
        }
        else if(weather.getWeather().equals("rain")){
            BREEDING_PROBABILITY = 0.25;
        }
    }
    
}
