/**
 * The types of weather possible in the simulation (clear, cloudy, rain, fog).
 *
 * @version 2021.03.01
 */
public enum Weather
{
    CLEAR, CLOUDY, RAINING, FOG;

    @Override
    public String toString()
    {
        // Convert the ordinary toString() output to title case
        // (so that it displays nicely in the GUI)
        String value = super.toString();
        return Character.toTitleCase(value.charAt(0)) + value.substring(1).toLowerCase();
    }
}
