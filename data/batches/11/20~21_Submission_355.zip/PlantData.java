import java.awt.Color;

/**
 * Stores data common to each type of plant and provides a way to create new
 * plants of this type. This currently does not provide any fields/methods
 * beyond those already provided by SpeciesData, but is structured this way for
 * potential future expansion.
 *
 * @version 2021.03.01
 */
public class PlantData extends SpeciesData
{
    /**
     * Creates a PlantData instance with the supplied parameters.
     *
     * @param name                    The name of the plant.
     * @param isNocturnal             Whether the plant grows at night or day.
     * @param reproductionAge         The age at which the plant can start to
     *                                reproduce.
     * @param maxAge                  The age to which the plant can live.
     * @param reproductionProbability The likelihood of the plant breeding.
     * @param maxOffspring            The maximum number of births.
     * @param creationProbability     The probability that this plant will be
     *                                created in any given grid position.
     * @param color                   The color the plant will appear in the GUI.
     * @param constructor             A reference to the plant class constructor.
     */
    public PlantData(String name, boolean isNocturnal, int reproductionAge, int maxAge, double reproductionProbability,
            int maxOffspring, double creationProbability, Color color, Constructor constructor)
    {
        super(name, isNocturnal, reproductionAge, maxAge, reproductionProbability, maxOffspring, creationProbability,
                color, constructor);
    }
}