import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * A graphical view of the simulation grid. The view displays a colored
 * rectangle for each location representing its contents. It uses a default
 * background color. Colors for each type of species are determined by the color
 * field of SpeciesData.
 *
 * @version 2021.03.01
 */
public class SimulatorView extends JFrame
{
    private static final long serialVersionUID = 7804363830179880628L;

    // The color used for empty locations.
    private static final Color EMPTY_COLOR = Color.WHITE;

    // The format of the text at the top left of the window.
    // The %s are substituted with their actual values.
    private static final String HEADER_FORMAT = "Seed: %s  Step: %s  Time: %s  Weather: %s";
    private static final String POPULATION_PREFIX = "Population: ";
    private JLabel stepLabel, population, infoLabel;
    protected FieldView fieldView;

    // A statistics object computing and storing simulation information
    private FieldStats stats;

    /**
     * Create a view of the given width and height.
     *
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();

        setTitle("Animal and Plant Simulation");
        stepLabel = new JLabel("", SwingConstants.CENTER);
        infoLabel = new JLabel("", SwingConstants.CENTER);
        population = new JLabel(POPULATION_PREFIX, SwingConstants.CENTER);

        setLocation(100, 50);

        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new BorderLayout());
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(infoLabel, BorderLayout.CENTER);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);
        pack();
        setVisible(true);
    }

    /**
     * Display a short information label at the top of the window.
     *
     * @param text The text to display.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * Show the current status of the field.
     *
     * @param step    Which iteration step it is.
     * @param time    The current simulation time (in minutes past midnight format).
     * @param weather The current weather.
     * @param field   The field whose status is to be displayed.
     */
    public void showStatus(int step, int time, Weather weather, Field field)
    {
        if (!isVisible()) {
            setVisible(true);
        }

        stepLabel.setText(String.format(HEADER_FORMAT, Randomizer.getSeed(), step, formatTime(time), weather));
        stats.reset();

        fieldView.preparePaint();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int column = 0; column < field.getWidth(); column++) {
                Species species = field.getSpeciesAt(row, column);
                if (species != null) {
                    stats.incrementCount(species.getData());
                    fieldView.drawMark(column, row, species.getData().COLOR);
                }
                else {
                    fieldView.drawMark(column, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     *
     * @param field The field state.
     * @return true if there is more than one type of species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * Convert a time integer to a string suitable for display.
     *
     * @param time The time of day (in minutes past midnight format).
     * @return The formatted time string (in the format HH:MM using 24hr clock).
     */
    private static String formatTime(int time)
    {
        return String.format("%02d:%02d", time / 60, time % 60);
    }

    /**
     * Provide a graphical view of a rectangular field. This is a nested class which
     * defines a custom component that displays the field. It draws the field
     * centered and rounded to an integer multiple of pixels per row/column.
     *
     * @version 2021.03.01
     */
    private class FieldView extends JPanel
    {
        private static final long serialVersionUID = -5639320443455245917L;

        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         *
         * @param height The height of the field.
         * @param width  The width of the field.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        @Override
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR, gridHeight * GRID_VIEW_SCALING_FACTOR + 16);
        }

        /**
         * Prepare for a new round of painting. Since the component may be resized,
         * compute the scaling factor again.
         */
        public void preparePaint()
        {
            // Do nothing if the size should stay the same
            if (getWidth() / gridWidth != xScale || getHeight() / gridHeight != yScale) {

                xScale = getWidth() / gridWidth;
                if (xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = getHeight() / gridHeight;
                if (yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }

                fieldImage = fieldView.createImage(xScale * gridWidth, yScale * gridHeight);
                g = fieldImage.getGraphics();
            }
        }

        /**
         * Paint a grid location on this field in a given color.
         *
         * @param column The column of the location.
         * @param row    The row of the location.
         * @param color  The color to paint the location.
         */
        public void drawMark(int column, int row, Color color)
        {
            g.setColor(color);
            g.fillRect(column * xScale, row * yScale, xScale - 1, yScale - 1);
        }

        @Override
        public void paintComponent(Graphics graphics)
        {
            // The field view component needs to be redisplayed.
            // Copy the internal image to the screen.
            if (fieldImage != null) {
                Dimension currentSize = getSize();
                if (currentSize != size) {
                    size = currentSize;
                    graphics.clearRect(0, 0, currentSize.width, currentSize.height);
                }
                // Draw the image centered within the component bounds
                graphics.drawImage(fieldImage, (currentSize.width - xScale * gridWidth) / 2,
                        (currentSize.height - yScale * gridHeight) / 2, null);
            }
        }
    }
}
