/**
 * The base class of all plant types, representing shared characteristics and
 * provides common functionality that plants use.
 *
 * @version 2021.03.01
 */
public abstract class Plant extends Species
{
    // The amount of time after rainfall that plant growth is increased for.
    private static final int RAIN_GROWTH_BOOST_DURATION = 100;

    /**
     * Create a new plant. The plant can be created as a new seedling (with age
     * zero) or with a random age.
     *
     * @param random   If true, the plant will have a random age.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean random, Field field, Location location)
    {
        super(random, field, location);
    }

    @Override
    protected void act(SimulationContext context)
    {
        // Currently nothing changes when a plant reaches the maximum age.
        if (age < getData().MAX_AGE) {
            age++;
        }
        updateDisease();
        // Plants always use probability-based breeding, there is a chance of
        // reproducing if it is old enough (depending on the weather).
        if (isAlive() && age >= getData().REPRODUCTION_AGE
                && RAND.nextDouble() <= getData().REPRODUCTION_PROBABILITY * getWeatherFactor(context)) {
            giveBirth(context);
        }
    }

    /**
     * Gets the probability multiplier for reproducing based on the simulation
     * weather.
     *
     * @param context Information about the current simulation state.
     * @return The probability multiplying factor.
     */
    private static double getWeatherFactor(SimulationContext context)
    {
        double baseMultiplier = context.getWeather() == Weather.CLEAR ? 1 : 0.5;
        // Increase reproduction rate while raining
        // and for 100 steps after it has rained.
        if (context.getTimeSinceRain() < RAIN_GROWTH_BOOST_DURATION) {
            // Cast to double so division doesn't truncate
            return baseMultiplier + 1 - (double) context.getTimeSinceRain() / RAIN_GROWTH_BOOST_DURATION;
        }
        return baseMultiplier;
    }

    /**
     * Get the data corresponding to this plant.
     *
     * @return The PlantData instance.
     */
    @Override
    public abstract PlantData getData();
}
