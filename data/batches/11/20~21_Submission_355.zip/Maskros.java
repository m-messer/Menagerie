import java.awt.Color;

/**
 * One of the simulated plants (maskros)
 *
 * @version 2021.03.01
 */
public class Maskros extends Plant
{
    public static final PlantData DATA = new PlantData("Maskros", false, 12, 40, 0.12, 3, 0.04, Color.CYAN,
            Maskros::new);

    /**
     * Create a new plant. The plant can be created as a new seedling (with age
     * zero) or with a random age.
     *
     * @param random   If true, the plant will have a random age.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Maskros(boolean random, Field field, Location location)
    {
        super(random, field, location);
    }

    @Override
    public PlantData getData()
    {
        return DATA;
    }
}
