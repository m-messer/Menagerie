import java.awt.Color;

/**
 * Stores data common to each type of species and provides a way to create new
 * species objects of that type. The fields of this class replace constants in
 * the individual species classes and are effectively constants themselves, so
 * they are public and capitalised accordingly. This allows inheritance to be
 * used with the constant data, avoiding the need to hardcode constants or
 * duplicate lots of code in the species classes.
 *
 * @version 2021.03.01
 */
public abstract class SpeciesData
{
    // The name of the species.
    public final String NAME;
    // Whether the species is active at night or day.
    // True if it is active during the night and false if active during the day.
    public final boolean IS_NOCTURNAL;
    // The age at which the species can start to breed.
    public final int REPRODUCTION_AGE;
    // The age to which the species can live.
    public final int MAX_AGE;
    // The likelihood of the species breeding.
    // If it is 0 then use female-male breeding.
    // If it is not 0 then use probability-based breeding.
    public final double REPRODUCTION_PROBABILITY;
    // The maximum number of births.
    public final int MAX_OFFSPRING;
    // The probability that this species will be created in any given grid position.
    public final double CREATION_PROBABILITY;
    // The color the species will appear in the GUI.
    public final Color COLOR;
    // A reference to the species class constructor.
    private final Constructor constructor;

    /**
     * Creates a SpeciesData instance with the supplied parameters.
     *
     * @param name                    The name of the species.
     * @param isNocturnal             Whether the species is active at night or day.
     * @param reproductionAge         The age at which the species can start to
     *                                breed.
     * @param maxAge                  The age to which the species can live.
     * @param reproductionProbability The likelihood of the species breeding.
     * @param maxOffspring            The maximum number of births.
     * @param creationProbability     The probability that this species will be
     *                                created in any given grid position.
     * @param color                   The color the species will appear in the GUI.
     * @param constructor             A reference to the species class constructor.
     */
    public SpeciesData(String name, boolean isNocturnal, int reproductionAge, int maxAge,
            double reproductionProbability, int maxOffspring, double creationProbability, Color color,
            Constructor constructor)
    {
        NAME = name;
        IS_NOCTURNAL = isNocturnal;
        REPRODUCTION_AGE = reproductionAge;
        MAX_AGE = maxAge;
        REPRODUCTION_PROBABILITY = reproductionProbability;
        MAX_OFFSPRING = maxOffspring;
        CREATION_PROBABILITY = creationProbability;
        COLOR = color;
        this.constructor = constructor;
    }

    /**
     * Create a species with the specified parameters.
     *
     * @param random   If true, the species will be created with random parameters
     *                 (age and hunger level).
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @return A species instance of this type.
     */
    public Species create(boolean random, Field field, Location location)
    {
        return constructor.create(random, field, location);
    }

    /**
     * A functional interface that represents the constructors of species types and
     * allows new species instances of the types to be created without hardcoding a
     * reference to the type constructor.
     *
     * @version 2021.03.01
     */
    @FunctionalInterface
    public interface Constructor
    {
        /**
         * Calls the species constructor with the specified parameters.
         *
         * @param random   If true, the species will be created with random parameters
         *                 (age and hunger level).
         * @param field    The field currently occupied.
         * @param location The location within the field.
         * @return A species instance of this type.
         */
        Species create(boolean random, Field field, Location location);
    }
}
