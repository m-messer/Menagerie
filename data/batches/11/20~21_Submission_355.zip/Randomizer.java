import java.util.Random;

/**
 * Provide control over the randomization of the simulation. By using a shared
 * randomizer, repeated runs with the same seed will perform exactly the same
 * (which helps with testing). Call useRandomSeed() to get different random
 * behaviour every time.
 *
 *         Originally created by David J. Barnes and Michael KÃ¶lling
 * @version 2021.03.01
 */
public class Randomizer
{
    // The default seed for control of randomization.
    // Used when a fixed seed is required.
    private static final long DEFAULT_SEED = 70L;
    // The current randomization seed.
    private static long seed = DEFAULT_SEED;
    // The shared random generator.
    private static final Random rand = new Random(seed);

    /**
     * Get the shared random generator.
     *
     * @return The random generator.
     */
    public static Random getRandom()
    {
        return rand;
    }

    /**
     * Get the current seed used by the simulation.
     *
     * @return The current seed.
     */
    public static long getSeed()
    {
        return seed;
    }

    /**
     * Set the seed used by the random generator to a specific value.
     *
     * @param newSeed The seed to use.
     */
    public static void useSeed(long newSeed)
    {
        rand.setSeed(seed = newSeed);
    }

    /**
     * Reset the seed used by the random generator to the default value.
     */
    public static void useDefaultSeed()
    {
        rand.setSeed(seed = DEFAULT_SEED);
    }

    /**
     * Set the seed used by the random generator to a randomly generated value.
     */
    public static void useRandomSeed()
    {
        rand.setSeed(seed = new Random().nextLong());
    }
}
