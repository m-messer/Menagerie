import java.util.List;
import java.util.Random;

/**
 * The base class of all species types, representing shared characteristics and
 * provides common functionality that both plants and animals use.
 *
 * @version 2021.03.01
 */
public abstract class Species
{
    // The age of the species.
    protected int age;
    // Whether the species is alive or not.
    private boolean alive;
    // The field the species is in.
    private Field field;
    // The position of the species in the field.
    private Location location;
    // The amount of time until the species dies from a disease.
    // If it is 0, the species is not diseased.
    protected int diseaseTime;

    // A shared random number generator to control breeding and other
    // random processes.
    protected static final Random RAND = Randomizer.getRandom();

    /**
     * Create a new species at a given location in the field.
     *
     * @param random   If true, the species will be created with a random age.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Species(boolean random, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        if (random) {
            // Choose random ages between 0 and half the maximum age.
            age = RAND.nextInt(getData().MAX_AGE / 2);
        }
    }

    /**
     * Perform actions for this species (make it do whatever it wants/needs to do).
     *
     * @param context Information about the current simulation state.
     */
    protected abstract void act(SimulationContext context);

    /**
     * Make this species act if it is the correct time of day, otherwise do nothing.
     *
     * @param context Information about the current simulation state.
     */
    public void tryAct(SimulationContext context)
    {
        // Nocturnal species only act at night, all others only act at day.
        if (context.getTime() < convertTime(6, 00) || context.getTime() > convertTime(21, 00)) {
            if (getData().IS_NOCTURNAL) {
                act(context);
            }
        }
        else if (!getData().IS_NOCTURNAL) {
            act(context);
        }
    }

    /**
     * Convert a time in hours and minutes to minutes past midnight format.
     *
     * @param hours   The hour part of the time.
     * @param minutes The minute part of the time.
     * @return The time in minutes past midnight format.
     */
    private static int convertTime(int hours, int minutes)
    {
        return hours * 60 + minutes;
    }

    /**
     * Get the data corresponding to this species.
     *
     * @return The SpeciesData instance.
     */
    public abstract SpeciesData getData();

    /**
     * Called when an animal eats this species. This always returns true by default,
     * but can be overridden by subclasses to customise behaviour.
     *
     * @param predator The animal trying to eat this species.
     * @return true if the species is eaten, false if not.
     */
    protected boolean onEaten(Species predator)
    {
        return true;
    }

    /**
     * Check whether the species is alive or not.
     *
     * @return true if the species is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the species is no longer alive. It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Set the number of steps until this species dies.
     *
     * @param time The number of steps before the species will die.
     */
    protected void setDiseased(int time)
    {
        if (diseaseTime == 0 || diseaseTime > time) {
            diseaseTime = time;
        }
    }

    /**
     * Make the species more diseased. This could result in the animal's death.
     */
    protected void updateDisease()
    {
        if (diseaseTime > 0) {
            diseaseTime--;
            if (diseaseTime <= 0) {
                setDead();
            }
        }
    }

    /**
     * Give birth to children. New births will be made into free adjacent locations.
     *
     * @param context Information about the current simulation state.
     */
    protected void giveBirth(SimulationContext context)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = RAND.nextInt(getData().MAX_OFFSPRING) + 1;
        for (int b = 0; b < births && free.size() > 0; b++) {
            context.add(getData().create(false, field, free.remove(0)));
        }
    }

    /**
     * Get the position of the species in the field.
     *
     * @return The location of the species.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the species at the new location in the given field.
     *
     * @param newLocation The new location of the species.
     */
    protected void setLocation(Location newLocation)
    {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Get the field the species is in.
     *
     * @return The field.
     */
    protected Field getField()
    {
        return field;
    }
}
