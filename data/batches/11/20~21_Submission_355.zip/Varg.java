import java.awt.Color;
import java.util.Map;

/**
 * One of the simulated animals (varg)
 *
 * @version 2021.03.01
 */
public class Varg extends Animal
{
    public static final AnimalData DATA = new AnimalData("Varg", true, 15, 150, 0.05, 2, 10, 0.02, Color.MAGENTA,
            Varg::new, Map.of(Fjallrav.DATA, 8, Lodjur.DATA, 8, Ren.DATA, 8));

    /**
     * Create a new animal. The animal can be created as a new born (age zero and
     * not hungry) or with a random age and food level.
     *
     * @param random   If true, the animal will have a random age and hunger level.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Varg(boolean random, Field field, Location location)
    {
        super(random, field, location);
    }

    @Override
    public AnimalData getData()
    {
        return DATA;
    }
}
