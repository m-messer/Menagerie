import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.Scanner;
import java.util.function.Consumer;

/**
 * A simple predator-prey simulator, based on a rectangular field containing
 * plants and animals.
 *
 * @version 2021.03.01
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // List of animals that can be generated.
    private static final List<SpeciesData> speciesTypes = List.of(Fjallrav.DATA, Lodjur.DATA, Ren.DATA, Varg.DATA,
            Brunbjorn.DATA, Druvflader.DATA, Maskros.DATA);

    // List of species in the field.
    private List<Species> speciesList;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The current time of day in the simulation
    // (this is stored as the number of minutes past midnight).
    protected int time;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The delay to add between simulation steps.
    private int delayTime = 20;
    // The current weather in the simulation.
    protected Weather weather = Weather.CLEAR;
    // The number of steps since it has last rained.
    protected int timeSinceRain;
    // The number of steps until the weather next changes.
    private int weatherChangeTime;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if (width <= 0 || depth <= 0) {
            throw new IllegalArgumentException("The dimensions must be greater than zero.");
        }

        speciesList = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Change the delay to add between simulation steps.
     *
     * @param delay The delay to add between simulation steps in milliseconds. If
     *              the value is 0 or less, do not add delay. If the value is
     *              negative, also skip drawing intermediate steps.
     */
    public void setDelay(int delay)
    {
        delayTime = delay;
    }

    /**
     * Run the simulation from its current state for a reasonably long period (2000
     * steps).
     */
    public void runLongSimulation()
    {
        simulate(2000);
    }

    /**
     * Run the simulation from its current state for the given number of steps. Stop
     * before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        Context context = new Context();
        for (int currentStep = 1; currentStep <= numSteps && view.isViable(field); currentStep++) {
            simulateStep(context);
            // if negative delay, skip redrawing output
            if (delayTime >= 0) {
                view.showStatus(step, time, weather, field);
                if (delayTime > 0) {
                    delay(delayTime);
                }
            }
        }
        // Show status again in case we weren't during the loop
        view.showStatus(step, time, weather, field);
    }

    /**
     * Run the simulation from its current state for a single step.
     */
    public void simulateOneStep()
    {
        Context context = new Context();
        simulateStep(context);
        view.showStatus(step, time, weather, field);
    }

    /**
     * Perform the core simulation logic for each step. Iterate over the whole field
     * updating the state of each species.
     *
     * @param context A Context object encapsulating the simulation state.
     */
    private void simulateStep(Context context)
    {
        step++;
        // Each step corresponds to 15 minutes of time.
        // Use modulo operator to wrap back to 0 after one day.
        time = (time + 15) % (24 * 60);
        updateWeather();

        ListIterator<Species> it = speciesList.listIterator();
        context.setAdd(it::add);

        while (it.hasNext()) {
            Species species = it.next();
            species.tryAct(context);
            if (!species.isAlive()) {
                it.remove();
            }
        }
    }

    /**
     * Changes the weather at random intervals.
     */
    private void updateWeather()
    {
        weatherChangeTime--;
        if (weatherChangeTime <= 0) {
            // Pick a random type of weather.
            Random rand = Randomizer.getRandom();
            Weather[] weatherChoices = Weather.values();
            weather = weatherChoices[rand.nextInt(weatherChoices.length)];
            // Change the weather again after a random number of steps between 10 and 99.
            weatherChangeTime = rand.nextInt(90) + 10;
        }
        if (weather == Weather.RAINING) {
            timeSinceRain = 0;
        }
        else {
            timeSinceRain++;
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        speciesList.clear();

        // Reset weather parameters
        weather = Weather.CLEAR;
        weatherChangeTime = 0;
        timeSinceRain = 0;

        populate();

        // Show the starting state in the view.
        view.showStatus(step, time, weather, field);
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        // Set the time to a random multiple of 15 minutes.
        time = rand.nextInt(24 * 4) * 15;
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int column = 0; column < field.getWidth(); column++) {
                for (SpeciesData data : speciesTypes) {
                    if (rand.nextDouble() <= data.CREATION_PROBABILITY) {
                        Location location = new Location(row, column);
                        Species newSpecies = data.create(true, field, location);
                        speciesList.add(newSpecies);
                    }
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for in milliseconds.
     */
    private static void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * A main method to allow the program to be run outside BlueJ. Implements a
     * basic shell that can control the simulator from the command line.
     *
     * @param args The program arguments (unused)
     */
    public static void main(String[] args)
    {
        Simulator simulator = new Simulator();
        // Add a handler to exit the program when the GUI is closed.
        simulator.view.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });

        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                String command = scanner.nextLine().toUpperCase();
                if (command == null || command.isBlank() || command.startsWith("Q")) {
                    // Q - close the GUI and exit
                    // This also happens if the command is blank
                    simulator.view.dispose();
                    return;
                }
                try {
                    if (command.startsWith("D")) {
                        // D - Set the delay to the following number.
                        simulator.setDelay(Integer.parseInt(command.substring(1)));
                    }
                    else if (command.startsWith("F")) {
                        // F - Reset the seed to the default (fixed) value.
                        Randomizer.useDefaultSeed();
                        simulator.reset();
                    }
                    else if (command.startsWith("R")) {
                        // R - Reset the simulation.
                        simulator.reset();
                    }
                    else if (command.startsWith("A")) {
                        // A - Set the seed to a random value.
                        Randomizer.useRandomSeed();
                        simulator.reset();
                    }
                    else if (command.startsWith("S")) {
                        // S - Set the seed to the following number.
                        Randomizer.useSeed(Long.parseLong(command.substring(1)));
                        simulator.reset();
                    }
                    else {
                        // Try to interpret as an integer.
                        // If that fails, catch the exception and do nothing.
                        simulator.simulate(Integer.parseInt(command));
                    }
                }
                catch (NumberFormatException e) {
                    // Ignore all number parsing errors.
                }
            }
        }
    }

    /**
     * The SimulationContext implementation used by Simulator to provide access to
     * the simulation state. Since this is a nested class, it has access to the
     * fields of the Simulator instance.
     *
     * @version 2021.03.01
     */
    private class Context implements SimulationContext
    {
        // A reference to the method that will be called to add each new
        // species to the simulation.
        private Consumer<Species> consumer;

        /**
         * Create a new Context instance.
         */
        public Context()
        {
        }

        @Override
        public int getTime()
        {
            return time;
        }

        @Override
        public int getTimeSinceRain()
        {
            return timeSinceRain;
        }

        @Override
        public Weather getWeather()
        {
            return weather;
        }

        @Override
        public void add(Species species)
        {
            consumer.accept(species);
        }

        /**
         * Set the method that will add new species to the simulation.
         *
         * @param consumer A reference to a method that will be called to add each new
         *                 species to the simulation.
         */
        public void setAdd(Consumer<Species> consumer)
        {
            this.consumer = consumer;
        }
    }
}
