/**
 * Represent a location in a rectangular grid.
 *
 * @version 2021.03.01
 */
public class Location
{
    // The row position.
    private int row;
    // The column position.
    private int column;

    /**
     * Represent a row and column.
     *
     * @param row    The row.
     * @param column The column.
     */
    public Location(int row, int column)
    {
        this.row = row;
        this.column = column;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Location) {
            Location other = (Location) obj;
            return row == other.getRow() && column == other.getColumn();
        }
        return false;
    }

    @Override
    public String toString()
    {
        // Return a string of the form row,column
        return row + "," + column;
    }

    @Override
    public int hashCode()
    {
        // Use the top 16 bits for the row value and the bottom for the column. Except
        // for very big grids, this should give a unique hash code for each
        // (row, column) pair.
        return (row << 16) + column;
    }

    /**
     * Get the row index of this location.
     *
     * @return The row index.
     */
    public int getRow()
    {
        return row;
    }

    /**
     * Get the column index of this location.
     *
     * @return The column index.
     */
    public int getColumn()
    {
        return column;
    }
}
