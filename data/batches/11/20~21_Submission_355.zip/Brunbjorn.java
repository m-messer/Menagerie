import java.awt.Color;
import java.util.Map;

/**
 * One of the simulated animals (brunbjÃ¶rn)
 *
 * @version 2021.03.01
 */
public class Brunbjorn extends Animal
{
    public static final AnimalData DATA = new AnimalData("BrunbjÃ¶rn", true, 12, 100, 0.05, 2, 9, 0.02, Color.BLUE,
            Brunbjorn::new, Map.of(Fjallrav.DATA, 9, Lodjur.DATA, 9, Ren.DATA, 9));

    /**
     * Create a new animal. The animal can be created as a new born (age zero and
     * not hungry) or with a random age and food level.
     *
     * @param random   If true, the animal will have a random age and hunger level.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Brunbjorn(boolean random, Field field, Location location)
    {
        super(random, field, location);
    }

    @Override
    public AnimalData getData()
    {
        return DATA;
    }
}
