/**
 * An interface encapsulating the state of the simulation. This is used to avoid
 * the species classes having a hardcoded dependency on the simulator
 * implementation.
 *
 * @version 2021.03.01
 */
public interface SimulationContext
{
    /**
     * Get the current simulation time.
     *
     * @return The current time of day (in minutes past midnight format).
     */
    int getTime();

    /**
     * Get the amount of time since it has last rained.
     *
     * @return The number of steps since it has last rained.
     */
    int getTimeSinceRain();

    /**
     * Get the current weather.
     *
     * @return The current weather state.
     */
    Weather getWeather();

    /**
     * Add a new species to the simulation.
     *
     * @param species The species to add.
     */
    void add(Species species);
}
