import java.awt.Color;

/**
 * One of the simulated plants (druvflÃ¤der)
 *
 * @version 2021.03.01
 */
public class Druvflader extends Plant
{
    public static final PlantData DATA = new PlantData("DruvflÃ¤der", false, 10, 50, 0.1, 4, 0.04, Color.GREEN,
            Druvflader::new);

    // The chance of an animal becoming infected when it eats this.
    private static final double INFECTION_CHANCE = 0.01;
    // The time until the animal dies after being infected.
    private static final int DISEASE_DURATION = 10;

    /**
     * Create a new plant. The plant can be created as a new seedling (with age
     * zero) or with a random age.
     *
     * @param random   If true, the plant will have a random age.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Druvflader(boolean random, Field field, Location location)
    {
        super(random, field, location);
    }

    @Override
    public PlantData getData()
    {
        return DATA;
    }

    @Override
    protected boolean onEaten(Species predator)
    {
        // Chance of infecting the animal that eats this.
        if (RAND.nextDouble() <= INFECTION_CHANCE) {
            predator.setDiseased(DISEASE_DURATION);
        }
        return true;
    }
}
