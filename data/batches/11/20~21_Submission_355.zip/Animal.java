import java.util.Iterator;
import java.util.List;

/**
 * The base class of all animal types, representing shared characteristics and
 * provides common functionality that animals use.
 *
 * @version 2021.03.01
 */
public abstract class Animal extends Species
{
    // The chance of an animal passing a disease on to another.
    private static final double DISEASE_SPREADING_CHANCE = 0.15;
    // The time until the animal dies after being infected by another.
    private static final int DISEASE_DURATION = 10;
    // The chance of an animal being unable to see during fog.
    private static final double FOG_BLINDNESS_CHANCE = 0.5;
    // The amount of steps after breeding until an animal can breed again.
    // Only used by female-male breeding.
    private static final int BREEDING_COOLDOWN_DURATION = 5;
    // The animal's food level, which is increased by eating food.
    private int foodLevel;
    // The gender of the animal.
    private Gender gender;
    // Whether the animal should reproduce this step.
    private boolean shouldReproduce;
    // The amount of steps until this animal can breed again.
    // Only used by female-male breeding.
    private int breedingCooldown;

    /**
     * Create a new animal. The animal can be created as a new born (age zero and
     * not hungry) or with a random age and food level.
     *
     * @param random   If true, the animal will have a random age and hunger level.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean random, Field field, Location location)
    {
        super(random, field, location);
        gender = RAND.nextBoolean() ? Gender.FEMALE : Gender.MALE;
        if (random) {
            foodLevel = RAND.nextInt(getData().MAX_FOOD_LEVEL) + 1;
        }
        else {
            foodLevel = getData().MAX_FOOD_LEVEL;
        }

    }

    @Override
    protected void act(SimulationContext context)
    {
        incrementAge();
        incrementHunger();
        updateDisease();
        if (isAlive()) {
            if (breedingCooldown > 0) {
                // Decrease the cooldown. When it reaches 0 the animal can breed again.
                // Note that this only applies to animals using the female-male breeding logic.
                breedingCooldown--;
            }
            if (context.getWeather() == Weather.FOG && RAND.nextDouble() <= FOG_BLINDNESS_CHANCE) {
                // Chance of being unable to see during fog:
                // if this happens, skip the rest of the logic and don't move.
                return;
            }
            // If using probability-based breeding, there is a chance of breeding if old
            // enough.
            if (getData().REPRODUCTION_PROBABILITY > 0 && age >= getData().REPRODUCTION_AGE
                    && RAND.nextDouble() <= getData().REPRODUCTION_PROBABILITY) {
                shouldReproduce = true;
            }
            // Move towards a source of food if found.
            Location newLocation = findAdjacent();
            if (newLocation == null) {
                // No food found, try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if (newLocation != null) {
                setLocation(newLocation);
                if (shouldReproduce) {
                    shouldReproduce = false;
                    giveBirth(context);
                }
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for animals to eat or mate with adjacent to the current location.
     * Returns when an animal is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    private Location findAdjacent()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Species species = field.getSpeciesAt(where);
            if (species != null) {
                // If using female-male breeding, attempt to breed.
                if (breedingCooldown <= 0 && getData().REPRODUCTION_PROBABILITY == 0) {
                    tryReproduce(species);
                }
                // If diseased, chance of spreading it to other animals of the same type.
                if (diseaseTime > 0 && species.getData() == getData()
                        && RAND.nextDouble() <= DISEASE_SPREADING_CHANCE) {
                    species.setDiseased(DISEASE_DURATION);
                }
                // Only eat if less than half full.
                if (foodLevel <= getData().MAX_FOOD_LEVEL / 2 && tryEat(species)) {
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check if two species can breed (same species, different genders, both old
     * enough). If they can then the female will give birth.
     *
     * @param species The species to attempt to breed with.
     */
    private void tryReproduce(Species species)
    {
        if (species.getData() == getData() && age >= getData().REPRODUCTION_AGE
                && species.age >= getData().REPRODUCTION_AGE) {
            // if getData() is the same, we know this is also an animal and can safely cast.
            Animal animal = (Animal) species;
            if (gender == Gender.MALE && animal.gender == Gender.FEMALE) {
                animal.shouldReproduce = true;
                animal.breedingCooldown = breedingCooldown = BREEDING_COOLDOWN_DURATION;
            }
            else if (gender == Gender.FEMALE && animal.gender == Gender.MALE) {
                shouldReproduce = true;
                animal.breedingCooldown = breedingCooldown = BREEDING_COOLDOWN_DURATION;
            }
        }
    }

    /**
     * Attempt to eat a particular species, if this animal is able to.
     *
     * @param species The species to attempt to eat.
     * @return true if the animal was eaten, false if not.
     */
    private boolean tryEat(Species species)
    {
        Integer foodValue = getData().canEat(species.getData());
        // If null, this animal cannot eat the species
        if (foodValue != null) {
            if (species.isAlive() && species.onEaten(this)) {
                species.setDead();
                // Add to the animal's food level, but don't exceed the maximum.
                foodLevel += foodValue;
                if (foodLevel > getData().MAX_FOOD_LEVEL) {
                    foodLevel = getData().MAX_FOOD_LEVEL;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Increment the age, this may result in the animal's death.
     */
    private void incrementAge()
    {
        age++;
        if (age > getData().MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Get the data corresponding to this animal.
     *
     * @return The AnimalData instance.
     */
    @Override
    public abstract AnimalData getData();

    /**
     * The possible genders for an animal (female or male)
     *
     * @version 2021.03.01
     */
    private enum Gender
    {
        FEMALE, MALE
    }
}
