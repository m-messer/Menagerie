import java.awt.Color;
import java.util.Map;

/**
 * Stores data common to each type of animal and provides a way to create new
 * animals of this type and check if it can eat another species.
 *
 * @version 2021.03.01
 */
public class AnimalData extends SpeciesData
{
    // The maximum food level the animal can have. In effect, this is the
    // maximum number of steps the animal can go before it has to eat again.
    public final int MAX_FOOD_LEVEL;
    // A map containing the species types this animal can eat and their food values.
    private final Map<SpeciesData, Integer> foodValues;

    /**
     * Creates an AnimalData instance with the supplied parameters.
     *
     * @param name                    The name of the animal.
     * @param isNocturnal             Whether the animal is active at night or day.
     * @param reproductionAge         The age at which the animal can start to
     *                                breed.
     * @param maxAge                  The age to which the animal can live.
     * @param reproductionProbability The likelihood of the animal breeding. If it
     *                                is 0 then the animal breeds when a male and
     *                                female meet.
     * @param maxOffspring            The maximum number of births.
     * @param maxFoodLevel            The maximum food level the animal can have.
     * @param creationProbability     The probability that this animal will be
     *                                created in any given grid position.
     * @param color                   The color the animal will appear in the GUI.
     * @param constructor             A reference to the animal class constructor.
     * @param foodValues              A map containing the species types this animal
     *                                can eat and their food values.
     */
    public AnimalData(String name, boolean isNocturnal, int reproductionAge, int maxAge, double reproductionProbability,
            int maxOffspring, int maxFoodLevel, double creationProbability, Color color, Constructor constructor,
            Map<SpeciesData, Integer> foodValues)
    {
        super(name, isNocturnal, reproductionAge, maxAge, reproductionProbability, maxOffspring, creationProbability,
                color, constructor);
        MAX_FOOD_LEVEL = maxFoodLevel;
        this.foodValues = foodValues;
    }

    /**
     * Checks if this species can eat another species of the specified type. If it
     * can be eaten, returns the food value, and if not, returns null.
     *
     * @param species The species to check.
     * @return The food value of the species, or null if it cannot be eaten.
     */
    public Integer canEat(SpeciesData species)
    {
        return foodValues.get(species);
    }
}
