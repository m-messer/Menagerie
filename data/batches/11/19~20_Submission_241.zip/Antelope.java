import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a antelope, which makes up one of the five
 * species in the ecosystem - one of the two prey.
 * Antelopes age, move, breed, and die.
 * Antelopes also eat grass.
 *
 *  
 * @version 22.02.2020, version 8
 */
public class Antelope extends Animal
{
    // Characteristics shared by all Antelopes (class variables).

    // The age at which a antelope can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a antelope can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a antelope breeding.
    private static final double BREEDING_PROBABILITY = 0.21;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 50;
    // The food value of a single bit of grass. In effect, this is the
    // number of steps an antelope can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 15;
    // A shared random number generator to control breeding, diseases, and gender.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // Counter for how many turns since the animal has been infected with the plague.
    private int TURNS_UNTIL_DEATH = 0;
    
    // The Antelope's age.
    private int age;
    // The antelope's food level, which is increased by eating grass.
    private int foodLevel;
    // Boolean to track the gender of the animal.
    // Used when checking if 2 animals are eligible to breed.
    private boolean isMale;
    // Boolean to track whether the animal has been infected with the plague.
    public boolean hasDisease;

    /**
     * Create a new antelope. A antelope may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Antelope(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        // Creates a random integer (either 1 or 0), which determines what gender
        // the animal is.
        int GENDER_GENERATOR = rand.nextInt(1);
        if(GENDER_GENERATOR == 1){
            isMale = true;
        } else{
            isMale = false;
        }

        // Creates a random integer (from 0 to 99), which determines if the animal
        // spawns in with the disease.
        int CHANCE_OF_MUTATION = rand.nextInt(100);
        if(CHANCE_OF_MUTATION == 99){
            hasDisease = true;
        } else{
            hasDisease = false;
        }

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the antelope does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newAntelopes A list to return newly born Antelopes.
     */
    public void act(List<Animal> newAntelopes)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive()) {
            giveBirth(newAntelopes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
            // Check if animal is diseased, if so then return true and check
            // whether or not disease spreads & if the animal will die.
            if(checkDisease()){
                setDead();
            }
        }
    }
    
    /**
     * Checks whether or not the animal has been infected.
     * If it has, then it ticks up a counter to track how many turns
     * it has been since initial infection - so how long the animal
     * has left to live.
     * Also has a 5% chance of spreading the infection.
     */
    private boolean checkDisease()
    {
        if(hasDisease){
            TURNS_UNTIL_DEATH++; //Counter integer that tracks the number of turns since infection.
            int CHANCE_OF_SPREAD = rand.nextInt(20);
            if(CHANCE_OF_SPREAD == 20){
                Iterator<Location> it = findAnimalLocation().iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Antelope) {
                        Antelope antelope = (Antelope) animal;
                        antelope.gotDisease();
                    } else if(animal instanceof Wildebeest) {
                        Wildebeest wildebeest = (Wildebeest) animal;
                        wildebeest.gotDisease();
                    } else if(animal instanceof Snake) {
                        Snake snake = (Snake) animal;
                        snake.gotDisease();
                    } else if(animal instanceof Hyena) {
                        Hyena hyena = (Hyena) animal;
                        hyena.gotDisease();
                    } else if(animal instanceof Lion) {
                        Lion lion = (Lion) animal;
                        lion.gotDisease();
                    }
                }
            }
            if(TURNS_UNTIL_DEATH == 30){
                return true;
            } else{
                return false;
            }
        } else{
            return false;
        }
    }

    /**
     * Increase the age. This could result in the antelope's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Antelope more hungry. This could result in the antelope's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for grass adjacent to the current location.
     * Only the first live piece of grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Iterator<Location> it = findAnimalLocation().iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Grass) {
                Grass grass = (Grass) animal;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this antelope is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAntelopes A list to return newly born Antelopes.
     */
    private void giveBirth(List<Animal> newAntelopes)
    {
        // New Antelopes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Antelope young = new Antelope(false, field, loc);
            newAntelopes.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A antelope can breed if it has reached the breeding age.
     * @return true if the antelope can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Checking if the animal is a male or female
     * If it returns true, then the animal is male.
     * If false is returned, then the animal is female.
     */
    public boolean isMale()
    {
        return isMale;
    }
    
    /**
     * Checking if there's both an animal adjacent to the current animal
     * and that it's a different gender.
     */
    public boolean eligibleAnimals()
    {
        Iterator<Location> it = findAnimalLocation().iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) {
                Antelope antelope = (Antelope) animal;
                if(antelope.isMale() != isMale()) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Method to flip the status of whether or not the animal has been infected.
     */
    public void gotDisease()
    {
        hasDisease = true;
    }
}
