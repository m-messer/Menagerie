import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a hyena, which makes up one of the five
 * main species of the ecosystem - and one of the three predators.
 * Hyenas age, move, eat food, and die.
 *
 *  
 * @version 22.02.2020, version 8
 */
public class Hyena extends Animal
{
    // Characteristics shared by all hyenas (class variables).
    
    // The age at which a hyena can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a hyena can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a hyena breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Hyena can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 8;
    // The food value of a single antelope. In effect, this is the
    // number of steps a Hyena can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 15;
    // A shared random number generator to control breeding, diseases, and gender.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // Counter for how many turns since the animal has been infected with the plague.
    private int TURNS_UNTIL_DEATH = 0;
    
    // The hyena's age.
    public int age;
    // The hyena's food level, which is increased by eating other animals.
    public int foodLevel;
    // Boolean to track the gender of the animal.
    // Used when checking if 2 animals are eligible to breed.
    private boolean isMale;
    // Boolean to track whether the animal has been infected with the plague.
    public boolean hasDisease;

    /**
     * Create a hyena. A hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hyena will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        // Creates a random integer (either 1 or 0), which determines what gender
        // the animal is.
        int GENDER_GENERATOR = rand.nextInt(1);
        if(GENDER_GENERATOR == 1){
            isMale = true;
        } else{
            isMale = false;
        }

        // Creates a random integer (from 0 to 99), which determines if the animal
        // spawns in with the disease.
        int CHANCE_OF_MUTATION = rand.nextInt(100);
        if(CHANCE_OF_MUTATION == 99){
            hasDisease = true;
        } else{
            hasDisease = false;
        }

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the hyena does most of the time: it hunts for
     * hyenas. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newHyenas A list to return newly born hyenas.
     */
    public void act(List<Animal> newHyenas)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive()) {
            giveBirth(newHyenas);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            // Check if animal is diseased, if so then return true and check
            // whether or not disease spreads & if the animal will die.
            if(checkDisease()){
                setDead();
            }
        }
    }
    
    /**
     * Checks whether or not the animal has been infected.
     * If it has, then it ticks up a counter to track how many turns
     * it has been since initial infection - so how long the animal
     * has left to live.
     * Also has a 5% chance of spreading the infection.
     */
    private boolean checkDisease()
    {
        if(hasDisease){
            TURNS_UNTIL_DEATH++; //Counter integer that tracks the number of turns since infection.
            int CHANCE_OF_SPREAD = rand.nextInt(20);
            if(CHANCE_OF_SPREAD == 20){
                Iterator<Location> it = findAnimalLocation().iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Antelope) {
                        Antelope antelope = (Antelope) animal;
                        antelope.gotDisease();
                    } else if(animal instanceof Wildebeest) {
                        Wildebeest wildebeest = (Wildebeest) animal;
                        wildebeest.gotDisease();
                    } else if(animal instanceof Snake) {
                        Snake snake = (Snake) animal;
                        snake.gotDisease();
                    } else if(animal instanceof Hyena) {
                        Hyena hyena = (Hyena) animal;
                        hyena.gotDisease();
                    } else if(animal instanceof Lion) {
                        Lion lion = (Lion) animal;
                        lion.gotDisease();
                    }
                }
            }
            if(TURNS_UNTIL_DEATH >= 10){
                return true;
            } else{
                return false;
            }
        } else{
            return false;
        }
    }

    /**
     * Increase the age. This could result in the hyena's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this hyena more hungry. This could result in the hyena's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for animals the Hyena will eat adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Iterator<Location> it = findAnimalLocation().iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wildebeest) {
                Wildebeest wildebeest = (Wildebeest) animal;
                if(wildebeest.isAlive()) { 
                    wildebeest.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            } 
            if(animal instanceof Antelope){
                Antelope antelope = (Antelope) animal;
                if(antelope.isAlive()){
                    antelope.setDead();
                    foodLevel = ANTELOPE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this hyena is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHyenas A list to return newly born hyenas.
     */
    private void giveBirth(List<Animal> newHyenas)
    {
        // New hyenas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hyena young = new Hyena(false, field, loc);
            newHyenas.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && eligibleAnimals()) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hyena can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Checking if the animal is a male or female
     * If it returns true, then the animal is male.
     * If false is returned, then the animal is female.
     */
    public boolean isMale()
    {
        return isMale;
    }
    
    /**
     * Checking if there's both an animal adjacent to the current animal
     * and that it's a different gender.
     */
    public boolean eligibleAnimals()
    {
        Iterator<Location> it = findAnimalLocation().iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hyena) {
                Hyena hyena = (Hyena) animal;
                if(hyena.isMale() != isMale()) { 
                    return true;
                }
            }   
        }
        return false;
    }
    
    /**
     * Method to flip the status of whether or not the animal has been infected.
     */
    public void gotDisease()
    {
        hasDisease = true;
    }
}
