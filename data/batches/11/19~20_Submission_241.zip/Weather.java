import java.util.Random;

/**
 * The weather class is used to determine weather conditions in the ecosystem.
 * Used to randomly generate weather.
 *
 * @version 22.02.2020, version 8
 */
public class Weather
{
    // instance variables - replace the example below with your own
    
    private boolean isRaining;
    private boolean isSunny = true;
    private boolean isFoggy;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        //nothing will happen here
    }
    
    /**
     * Method that generates a number between 0 and 4.
     * If the integer returns a 0 or 1, it sets the boolean 'isRaining' to true.
     * If the integer returns a 2, it sets the boolean 'isFoggy' to true.
     * Otherwise, if 3 or 4 is returned then 'isSunny' is set to true.
     */
    public void setWeather()
    {
        Random rand = Randomizer.getRandom();
        int WEATHER_GENERATOR = rand.nextInt(5);
        if(WEATHER_GENERATOR <= 1){
            isRaining = true;
            isSunny = false;
            isFoggy = false;
        } else if(WEATHER_GENERATOR > 2){
            isSunny = true;
            isRaining = false;
            isFoggy = false;
        } else if(WEATHER_GENERATOR == 2){
            isFoggy = true;
            isRaining = false;
            isSunny = false;
        }
    }

    /**
     * Returns whether or not it's raining.
     * Used in simulator to get current weather conditions.
     */
    public boolean rain()
    {
        return isRaining;
    }
    
    /**
     * Returns whether or not it's sunny.
     * Used in simulator to get current weather conditions.
     */
    public boolean sun()
    {
        return isSunny;
    }
    
    /**
     * Returns whether or not there's fog.
     * Used in simulator to get current weather conditions.
     */
    public boolean fog()
    {
        return isFoggy;
    }
}
