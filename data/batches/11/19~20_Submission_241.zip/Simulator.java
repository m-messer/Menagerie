import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing antelopes, wildebeest, snakes, hyenas, and lions.
 *
 *  
 * @version 22.02.2020, version 8
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.04;
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.03;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.01;
    // The probability that a rabbit will be created in any given grid position.
    private static final double WILDEBEEST_CREATION_PROBABILITY = 0.08;
    // The probability that a antelope will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.05;   
    // The probability that a antelope will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.25;  
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Weather class. Generates weather.
    private Weather weather;

    // boolean tracks time of day
    private boolean isDayTime = true;
    // boolean tracks whether or not it's raining
    private boolean rain;
    // boolean tracks if it's sunny. This is the default weather condition
    private boolean sun = true;
    // boolean tracks whether or not it's foggy
    private boolean fog;
    
    // Counter for how many turns it will take until the animals move.
    // This is used in night time and in adverse weather conditions
    private int TURNS_UNTIL_MOVEMENT = 0;
    // Counter for how long it will be until it flips between
    // night and day time.
    private int TIME_GENERATOR = 0;
    // Counter for how long it will be until weather changes
    private int WEATHER_GENERATOR = 0;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Wildebeest.class, Color.ORANGE);
        view.setColor(Snake.class, Color.BLUE);
        view.setColor(Hyena.class, Color.PINK);
        view.setColor(Antelope.class, Color.CYAN);
        view.setColor(Lion.class, Color.YELLOW);
        view.setColor(Grass.class, Color.GREEN);
        getWeatherStatus();

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        WEATHER_GENERATOR++;
        countTime();
        getWeatherStatus();
        
        // Provide space for newborn animals.    
        List<Animal> newAnimals = new ArrayList<>();  
        
        if(WEATHER_GENERATOR == 10){
            generateWeather();
            WEATHER_GENERATOR = 0;
        }
        
        if(!isDayTime){
            view.changeBackground(Color.BLACK);
            TURNS_UNTIL_MOVEMENT++;
            
            // Let all animals act.
            if(sun){
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    //animal.incrementAge();
                    if(TURNS_UNTIL_MOVEMENT % 2 == 0){
                        animal.act(newAnimals);
                        TURNS_UNTIL_MOVEMENT = 0;
                    }
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }   
            } else if(rain){
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    //animal.incrementAge();
                    if(TURNS_UNTIL_MOVEMENT % 6 == 0){
                        animal.act(newAnimals);
                        TURNS_UNTIL_MOVEMENT = 0;
                    }
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }   
            } else if(fog){
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    //animal.incrementAge();
                    if(TURNS_UNTIL_MOVEMENT % 8 == 0){
                        animal.act(newAnimals);
                        TURNS_UNTIL_MOVEMENT = 0;
                    }
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }   
            }

            // Add the newly born animals to the main lists.
            animals.addAll(newAnimals);
            
            view.showStatus(step, field);
        } else{
            view.changeBackground(Color.WHITE);
            TURNS_UNTIL_MOVEMENT++;
            
            // Let all animals act.
            if(sun){
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    animal.act(newAnimals);
                    TURNS_UNTIL_MOVEMENT = 0;
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }   
            } else if(rain){
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    animal.incrementAge();
                    if(TURNS_UNTIL_MOVEMENT % 3 == 0){
                        animal.act(newAnimals);
                        TURNS_UNTIL_MOVEMENT = 0;
                    }
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }   
            } else if(fog){
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    animal.incrementAge();
                    if(TURNS_UNTIL_MOVEMENT % 5 == 0){
                        animal.act(newAnimals);
                        TURNS_UNTIL_MOVEMENT = 0;
                    }
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }   
            }

            // Add the newly born animals to the main lists.
            animals.addAll(newAnimals);

            view.showStatus(step, field);
        }
    }

    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                } else if(rand.nextDouble() <= WILDEBEEST_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wildebeest wildebeest = new Wildebeest(true, field, location);
                    animals.add(wildebeest);
                } else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row,col);
                    Hyena hyena = new Hyena(true, field, location);
                    animals.add(hyena);
                } else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Antelope antelope = new Antelope(true, field, location);
                    animals.add(antelope);
                } else if(rand.nextDouble() <= LION_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                } else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Grass grass = new Grass(true, field, location);
                    animals.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Toggles between daytime and nighttime.
     */
    private void toggleDaytime()
    {
        isDayTime = !isDayTime;
    }
    
    /**
     * Every 50 turns, the time will change between day and night time
     * This is represented by true or false in the boolean 'isDayTime'.
     */
    private void countTime()
    {
        TIME_GENERATOR++;
        if(TIME_GENERATOR == 50){
            toggleDaytime(); //Toggling between daytime and nighttime every 50 turns/steps
            TIME_GENERATOR = 0;
        }
    }
    
    /**
     * Returns current steps.
     */
    private int getCurrentSteps()
    {
        return step;
    }
    
    /**
     * Method to generate the weather and set the booleans of weather
     * stored in this class to true or false
     */
    private void generateWeather()
    {
        weather.setWeather();
        rain = false;
        sun = false;
        fog = false;
        if(weather.rain()){
            rain = true;
        } else if(weather.sun()){
            sun = true;
        } else if(weather.fog()){
            fog = true;
        }
    }
    
    /**
     * This method acts as a setter method for the simulator viewer class
     * It just returns if there's a current weather status, and so displays
     * accurate weather status
     */
    public void getWeatherStatus()
    {
        if(rain){
            view.weatherStatus("rain");
        } else if(sun){
            view.weatherStatus("sun");
        } else if(fog){
            view.weatherStatus("fog");
        } else{
            view.weatherStatus("none");
        }
    }
}
