import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing cheetahs, hyenas, lions, zebras and antelopes.
 *
 * @version 02/03/2022 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.05;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.15;    
    // The probability that a antelope will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.6;
    // The probability that a cheetah will be created in any given grid position.
    private static final double CHEETAH_CREATION_PROBABILITY = 0.06; 
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.06;

    // List of animals in the field.
    private List<Animal> animals;
    
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    public int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //the current statistics of the field
    private FieldStats stats;
    //the current time of the field
    private Time time;
    //a long varianle to hold the time
    private long timestamp;
    //a boolean variable to hold whether the animals are sleeping or not
    private boolean sleeping;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();

 
        field = new Field(depth, width);
        time = new Time();
        timestamp = time.getTime();
        sleeping = false;
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Lion.class, Color.BLUE);
        view.setColor(Antelope.class, Color.RED);
        view.setColor(Hyena.class, Color.YELLOW);
        view.setColor(Cheetah.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
        
    }
    

    public int getStep() 
    {
        return step;
    }
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * cheetah, hyena, lion, zebra and antelope.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();    
        if(timestamp % 60 <= 0) //makes the animals sleep whenever the time hits 60
        {
            sleeping = true;
        }
        else {
            sleeping = false;
        }
        // Let all animals act.
        
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                if(sleeping == false){
                    animal.act(newAnimals);
                    if(! animal.isAlive()) {
                        it.remove();
                    }
            
                }
            }    
           
        // Add the newly born cheetahs, lions, zebras, antelopes and hyenas to the main lists.
        animals.addAll(newAnimals);
        
        
        timestamp = time.incrementTime(step); 

        view.showStatus(step, field, timestamp);
        
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, timestamp);
    }
    
    /**
     * Randomly populate the field with lions, hyenas, zebras, antelopes and cheetahs.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                    }
                else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope = new Antelope(true, field, location);
                    animals.add(antelope);    
                }

                else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah = new Cheetah(true, field, location);
                    animals.add(cheetah); 
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(true, field, location);
                    animals.add(hyena);    
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
