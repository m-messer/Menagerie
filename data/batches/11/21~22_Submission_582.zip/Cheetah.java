import java.util.List;
import java.util.Iterator;
import java.util.Random;


/**
 * Write a description of class Cheetah here.
 * The cheetah class is a subclass of the Animal class. It is a predator in this simulation. It eats antelopes, breeds, moves, dies.
 *
 * @version 02/03/2022 (2)
 */
public class Cheetah extends Animal
{
    // Characteristics shared by all cheetahs (class variables).
    
    // The age at which a cheetah can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a cheetah can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a cheetah breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single antelope. In effect, this is the
    // number of steps a cheetah can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 17;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The cheetah's gender
    private boolean isMale;
    // The cheetah's age.
    private int age;
    // The cheetah's food level, which is increased by eating antelopes.
    private int foodLevel;
    

    /**
     * Create a cheetah. A cheetah can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cheetah will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cheetah(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        isMale = rand.nextBoolean(); //random boolean variable to decide whether the cheetah is male or female
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ANTELOPE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ANTELOPE_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the cheetah does most of the time: it hunts for
     * antelopes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newCheetahs A list to return newly born cheetahs.
     */
    public void act(List<Animal> newCheetahs)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive()) {
            giveBirth(newCheetahs);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null){
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
        }    
    }
    
    /**
     * Increase the age. This could result in the cheetah's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this cheetah more hungry. This could result in the cheetah's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for antelopes adjacent to the current location.
     * Only the first live antelope is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) {
                Antelope antelope = (Antelope) animal;
                if(antelope.isAlive()) { 
                    antelope.setDead();
                    foodLevel = ANTELOPE_FOOD_VALUE;
                    return where;
                }

            }
            
        }
        return null;
    }
    
    
    /**
     * Look for cheetahs adjacent to the current location.
     * Checks whether they are the opposite gender
     * Returns true or false depending on the gender
     */
    private boolean meet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cheetah) {
                Cheetah cheetah = (Cheetah) animal;
                if(!isMale) { 
                    return true;
                } 
                else{
                    return false;
                }
            }
        }
        return false;
    }
    /**
     * Check whether or not this cheetah is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCheetahs A list to return newly born cheetahs.
     */
    private void giveBirth(List<Animal> newCheetahs)
    {
        // New cheetahes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cheetah young = new Cheetah(false, field, loc);
            newCheetahs.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed and if gender of cheetah is opposite
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if((canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)&& meet()) {   
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A cheetah can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

}
