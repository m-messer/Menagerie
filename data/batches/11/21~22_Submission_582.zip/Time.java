/**
 * Write a description of class Time here.
 * Time class returns the time and increments it.
 *
 * @version 02/03/2022 (2)
 */
public class Time
{
    // long variable used to store the current time
    public long timestamp;
    

    /**
     * Initialise the time so it starts at 0
     */
    public Time()
    {
        timestamp = 0;
        
    }

    /**
     * Returns current time of the simulation
     */
    public long getTime()
    {
        return timestamp;
    }
    
    /**
     * Increments the time depending on the number of steps taken
     * parameter is the number of steps
     * returns the time after being incremented
     */
    public long incrementTime(int step)
    {
        timestamp = step * 10;
        return timestamp;
    }
}
