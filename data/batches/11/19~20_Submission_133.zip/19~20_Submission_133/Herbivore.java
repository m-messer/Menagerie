/**
 * The interface Herbivore defines the eat method for all animals that are herbivores.
 * Herbivores eat plants in the location they are at.
 *
 * @version 2020.02.12
 */
public interface Herbivore
{
    public static final int AT_LEAST = 9;
    /**
     * Make the animal eat plants if there any in the given location.
     * @param animal The animal that is supposed to eat.
     * @param plantsField The field that stores the plants.
     * @param location the location of the animal.
     * @param maxFoodLevel The maximum food level of the animal.
     */
    public default void eat(Animal animal, PlantsField plantsField, Location location, int maxFoodLevel) {
        Plant plantToEat = (Plant) plantsField.getObjectAt(location);
        if(plantToEat != null) {
            int foodValue = plantToEat.getFoodValue();
            if(((foodValue + animal.getFoodLevel()) <= maxFoodLevel) && (foodValue >= AT_LEAST)){
                animal.increaseFoodLevel(foodValue);
            }
            else {
                animal.setFoodLevel(maxFoodLevel);
            }

            if(plantToEat.isInfected()) {
                // If the animal eats a plant which is already infected, the animal itself gets infected by disease as well
                animal.setIsInfected(true);
            }
            
            plantToEat.plantEaten();
        }
    }
}
