import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants.
 *
 * @version 2020.12.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 100;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The defauld number of steps for running a long simulation.
    private static final int LONG_SIMULATION_DURATION = 6000;
    /// The probability that a fox will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.08;
    // The probability that a rabbit will be created in any given grid position.
    private static final double CROCODILE_CREATION_PROBABILITY = 0.009;
    // The probability that a fox will be created in any given grid position.
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.035;
    // The probability that a rabbit will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.016;
    // The probability that a fox will be created in any given grid position.
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.04;
    // The probability that the animal will be created male. 
    // This can be set to have a larger or smaller chance to generate males during population stage.
    private static final double PROBABILITY_OF_MALE = 0.5;
    // The probability that a plant will be infected by a disease when it is created
    private static final double PLANT_INFECTED_PROBABILITY = 0.01;
    // The probability that an animal will die by disease
    private static final double CHANCE_OF_ANIMAL_DYING = 0.005;
    // The number of parts of the day.
    private static final int PARTS_OF_DAY = 4;

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private AnimalField animalField;
    // The current state of the field for plants.
    private PlantsField plantField;
    // The current step of the simulation.
    private int step;
    // The current step of the simulation.
    private int partOfDay;
    // The weather in the simulation.
    private Weather weather;
    // A graphical view of the simulation.
    private List<SimulatorView> views;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {   
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        animalField = new AnimalField(depth, width);
        plantField = new PlantsField(depth, width);
        weather = new Weather();

        views = new ArrayList<>();

        // Create the grid view for the simulation.
        SimulatorView view = new GridView(this, depth, width);
        view.setColor(Antelope.class, Color.GREEN);
        view.setColor(Lion.class, Color.YELLOW);
        view.setColor(Elephant.class, Color.BLUE);
        view.setColor(Crocodile.class, Color.RED);
        view.setColor(Giraffe.class, Color.DARK_GRAY);
        views.add(view);

        // Create the graph view for the simulation.
        view = new GraphView(800, 300, 600);
        view.setColor(Antelope.class, Color.GREEN);
        view.setColor(Lion.class, Color.YELLOW);
        view.setColor(Elephant.class, Color.BLUE);
        view.setColor(Crocodile.class, Color.RED);
        view.setColor(Giraffe.class, Color.DARK_GRAY);
        views.add(view);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period 
     * (for the number of steps defined by LONG_SIMULATION_DURATION).
     */
    public void runLongSimulation()
    {
        simulate(LONG_SIMULATION_DURATION);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int s = 1; s <= numSteps && views.get(0).isViable(animalField); s++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant
     */
    public void simulateOneStep()
    {
        int newWeather = weather.newWeather();
        partOfDay = step%PARTS_OF_DAY;
        step++;
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.grow(newWeather, plantField);
        } 

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, partOfDay, CHANCE_OF_ANIMAL_DYING, newWeather);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born lions, crocodiles, antelopes, giraffes, and elephants to the main lists.
        animals.addAll(newAnimals);

        updateViews();

    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        partOfDay = 0;
        animals.clear();
        for (SimulatorView view : views) {
            view.reset();
        }

        populatePlants();
        populateAnimals();
        updateViews();
    }

    /**
     * Update all existing views.
     */
    private void updateViews()
    {
        for (SimulatorView view : views) {
            view.showStatus(step, getPartOfDay(), weather.getWeatherName(), animalField); 
        }
    }

    /** 
     * Get the name of the time of the day.
     * @return The name of the time of the day.
     */
    private String getPartOfDay() {
        switch(partOfDay) {
            case 0:
            return "Morning";
            case 1:
            return "Afternoon";
            case 2:
            return "Evening";
            case 3:
            return "Night";
            default:
            return "Unknown";
        }
    }

    /**
     * Randomly populate the field with plants.
     */
    private void populatePlants(){
        Random rand = Randomizer.getRandom();

        plantField.clear();
        for(int row = 0; row < plantField.getDepth(); row++) {
            for(int col = 0; col < plantField.getWidth(); col++) {
                Location location = new Location(row, col);
                // When a plant is created, it may have disease
                Plant plant;
                if(rand.nextDouble() <= PLANT_INFECTED_PROBABILITY){
                    plant = new Plant(location, true);
                    plantField.place(plant,plant.getLocation());
                }
                else{
                    plant = new Plant(location, false);
                    plantField.place(plant,plant.getLocation());
                }
                plants.add(plant);
            }
        }

    }

    /**
     * Randomly populate the field with antelopes, giraffes, elephants, lions and crocodiles.
     */
    private void populateAnimals()
    {
        Random rand = Randomizer.getRandom();

        animalField.clear();
        for(int row = 0; row < animalField.getDepth(); row++) {
            for(int col = 0; col < animalField.getWidth(); col++) {
                if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope;
                    if(rand.nextDouble() < PROBABILITY_OF_MALE){
                        antelope = new Antelope(true, true, animalField, location, plantField);
                    }
                    else{
                        antelope = new Antelope(true, false, animalField, location, plantField);
                    }
                    animals.add(antelope);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion;
                    if(rand.nextDouble() < PROBABILITY_OF_MALE){
                        lion = new Lion(true, true, animalField, location);
                    }
                    else{
                        lion = new Lion(true, false, animalField, location);
                    }
                    animals.add(lion);
                }

                else if(rand.nextDouble() <= ELEPHANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Elephant elephant;
                    if(rand.nextDouble() < PROBABILITY_OF_MALE){
                        elephant = new Elephant(true, true, animalField, location, plantField);
                    }
                    else{
                        elephant = new Elephant(true, false, animalField, location, plantField);
                    }
                    animals.add(elephant);
                }
                else if(rand.nextDouble() <= CROCODILE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Crocodile crocodile;
                    if(rand.nextDouble() < PROBABILITY_OF_MALE){
                        crocodile = new Crocodile(true, true, animalField, location);
                    }
                    else{
                        crocodile = new Crocodile(true, false, animalField, location);
                    }
                    animals.add(crocodile);
                }
                else if(rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Giraffe giraffe;
                    if(rand.nextDouble() < PROBABILITY_OF_MALE){
                        giraffe = new Giraffe(true, true, animalField, location, plantField);   
                    }
                    else{
                        giraffe = new Giraffe(true, false, animalField, location, plantField);
                    }
                    animals.add(giraffe);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Get the the number of steps for running a long simulation.
     * @return LONG_SIMULATION_DURATION.
     */
    public int getLongSimulationDuration() {
        return LONG_SIMULATION_DURATION;
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable() {
        return views.get(0).isViable(animalField);
    }

}
