import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model for elephants in the simulation.
 * This class stores the breeding age, max age, breeding probability, max litter size
 * max food level, and food value for the whole species.
 * This class defines how the elephants behave and act in the simulation.
 *
 * @version 2020.02.17
 */
public class Elephant extends Animal implements  Herbivore
{
    // The age at which an elephant can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which an elephant can live.
    private static final int MAX_AGE = 70;
    // The likelihood of an elephant breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum food level.
    private static final int MAX_FOOD_LEVEL = 30;
    // The food value of elephants.
    private static final int FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The field that stores plants.
    private PlantsField plantsField;
    /**
     * Constructor for objects of class Elephant with given gender.
     * @param random Whether to set the age and food level to random values.
     * @param isMale Whether the animal is male or female.
     * @param animalField The field that stores the animals.
     * @param location The location of the animal.
     * @param plantsField The field that stores plants.
     */
    public Elephant(boolean random, boolean isMale, AnimalField animalField, Location location, PlantsField plantsField)
    {
        super(animalField, location);
        setIsMale(isMale);
        this.plantsField = plantsField;
        this.setFoodValue(FOOD_VALUE);
        // age = 0 by default. Set in the Animal class.
        // foodLevel = 5 by default. Set in the Animal class.
        if(random) {
            setRandomAge(MAX_AGE);
            setFoodLevel(rand.nextInt(MAX_FOOD_LEVEL) + 1);
        }
    }

    /**
     * Elephant acts differently depending on the time of the day and the weather.
     * @param newElephants The list of new born elephants.
     * @param timeOfDay The time of the day.
     * @param chanceOfDying The probability of animal dying if it is infected.
     * @param weather The weather type.
     */
    public void act(List<Animal> newElephants, int timeOfDay, double chanceOfDying, int weather) {        
        if(timeOfDay == 0) {
            increaseAge(MAX_AGE);
        }

        checkDisease(chanceOfDying);

        if(isAlive()) {
            switch(weather) {
                case 1:
                // The weather is rainy, Elephant's food level decreases by less
                switch(timeOfDay) {
                    case 0:
                    // Morning, Elephant gives birth, eats, moves, food level decreases
                    if(!isAnimalMale()) {
                        giveBirth(newElephants);
                    }   
                    eat(this,plantsField, getLocation(), MAX_FOOD_LEVEL);
                    moveToInAreaLocation(1);
                    decreaseFoodLevel(3);
                    break;

                    case 1:
                    // Afternoon, Elephant gives birth, eats, moves
                    if(!isAnimalMale()) { 
                        giveBirth(newElephants);
                    }  
                    eat(this,plantsField, getLocation(), MAX_FOOD_LEVEL);
                    moveToInAreaLocation(2);
                    break;

                    case 2:
                    // Evening, Elephant gives birth, eats, moves, food level decreases 
                    if(!isAnimalMale()) {
                        giveBirth(newElephants);
                    }                     
                    eat(this,plantsField, getLocation(), MAX_FOOD_LEVEL);
                    moveToInAreaLocation(1);
                    decreaseFoodLevel(2);
                    break;

                    case 3:
                    // Night, Elphant sleeps, food level decreases 
                    decreaseFoodLevel(2);
                    break;

                }
                break;

                default:
                switch(timeOfDay) {
                    case 0:
                    // Morning, Elephant gives birth, eats, moves, food level decreases 
                    if(!isAnimalMale()) {
                        giveBirth(newElephants);
                    }                   
                    eat(this,plantsField, getLocation(), MAX_FOOD_LEVEL);
                    moveToInAreaLocation(1);
                    decreaseFoodLevel(4);
                    break;

                    case 1:
                    // Afternoon, Elephant gives birth, eats, moves, food level decreases 
                    if(!isAnimalMale()) {
                        giveBirth(newElephants);
                    }                    
                    eat(this,plantsField, getLocation(), MAX_FOOD_LEVEL);
                    moveToInAreaLocation(2);
                    decreaseFoodLevel(1);
                    break;

                    case 2:
                    // Evening, Elephant gives birth, eats, moves, food level decreases ]
                    if(!isAnimalMale()) {
                        giveBirth(newElephants);
                    }  
                    eat(this,plantsField, getLocation(), MAX_FOOD_LEVEL);
                    moveToInAreaLocation(1);
                    decreaseFoodLevel(3);
                    break;

                    case 3:
                    // Night, Elphant sleeps, food level decreases 
                    decreaseFoodLevel(2);
                    break;

                }
                break;

            }
        }
    }

    /**
     * Check whether or not this elephant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newElephants A list to return newly born elephants.
     */
    protected void giveBirth(List<Animal> newElephants)
    {
        AnimalField animalField = getField();
        List<Location> free = animalField.getFreeInAreaLocations(getLocation(),1);
        int births = breed(BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Elephant young = new Elephant(false, rand.nextBoolean(), animalField, loc, plantsField);
            newElephants.add(young);
        }
    }

    /**
     * Look for male partner in specified distance to the current location.
     * @return elephant The male elephant if found, null otherwise.
     */
    protected Animal findMale()
    {
        AnimalField animalField = getField();
        List<Location> inArea = animalField.inAreaLocations(getLocation(), 1);
        Iterator<Location> it = inArea.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = animalField.getObjectAt(where);
            if(animal instanceof Elephant) {
                Elephant elephant = (Elephant) animal;
                if(elephant.isAnimalMale()) { 
                    return elephant;
                }
            }
        }
        return null;
    }
}
