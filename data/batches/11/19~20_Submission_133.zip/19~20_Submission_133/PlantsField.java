import java.util.LinkedList;
import java.util.List;
import java.util.Collections;
import java.util.Random;

/**
 * The class PlantsField is a subclass of the class Field.
 * It specifies the methods for the field that stores Plants in it.
 * (Currently, it is only used to provide a clear seperation between 
 * the field for plants and the field for animals. 
 * This class could be extended in the future if more functionality
 * to the plants is added.)
 *
 * @version 2020.02.12
 */
public class PlantsField extends Field
{
    /**
     * Constructor for objects of class PlantsField
     */
    public PlantsField(int depth, int width)
    {
        super(depth,width);
    }
    
    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    protected List<Location> adjacentLocations(Location location)
    {
        Random rand = Randomizer.getRandom();
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        if(location != null) {
            int row = location.getRow();
            int col = location.getCol();
            for(int roffset = -1; roffset <= 1; roffset++) {
                int nextRow = row + roffset;
                if(nextRow >= 0 && nextRow < getDepth()) {
                    for(int coffset = -1; coffset <= 1; coffset++) {
                        int nextCol = col + coffset;
                        // Exclude invalid locations and the original location.
                        if(nextCol >= 0 && nextCol < getWidth() && (roffset != 0 || coffset != 0)) {
                            locations.add(new Location(nextRow, nextCol));
                        }
                    }
                }
            }

            // Shuffle the list. Several other methods rely on the list
            // being in a random order.

            Collections.shuffle(locations, rand);
        }
        return locations;
    }

}