import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.12
 */
public abstract class Animal
{
    //The probability the disease spreads to other animals.
    private static final double PROBABILITY_OF_DISEASE_SPREAD = 0.3;
    // Whether the animal is alive or not.
    private boolean alive;
    // Whether the animal is infected by diseases or not
    private boolean isInfected;
    // The animal's field. 
    private AnimalField animalField;
    // The animal's position in the field.
    private Location location;
    // The animal's gender, whethter the animal is male or female.
    private boolean isMale;
    // The amimal's age
    private int age;
    // The animal's foodlevel, which is increased by eating food (other animlas or plants)
    private int foodLevel;
    // The animal's food value if eaten by other animals.
    private int foodValue;
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(AnimalField animalField, Location location)
    {
        alive = true;
        age = 0;
        foodLevel = 5;
        this.animalField = animalField;
        setLocation(location);
        animalField.place(this, location);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, int time, double chanceOfDying, int weather);

    /**
     * gives birth
     */
    protected abstract void giveBirth(List<Animal> newAnimals);

    /**
     * checks if there is any male animal nearby
     */
    protected abstract Animal findMale();

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            animalField.clear(location);
            location = null;
            animalField = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            animalField.clear(location);
        }
        location = newLocation;
        animalField.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected AnimalField getField()
    {
        return animalField;
    }

    /**
     * Increase the food level of the animal.
     * @param foodAmount The amount to increase the food level by.
     */
    protected void increaseFoodLevel(int foodAmount) {
        foodLevel += foodAmount;
    }

    /**
     * Decrease the food level of the animal.
     * Set the animal to dead if the food level falls below 1.
     * @param foodAmount The amount to decrease the food level by.
     */
    protected void decreaseFoodLevel(int foodAmount) {
        foodLevel -= foodAmount;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Set the food level of the animal.
     * @param foodAmount The amount the food level to be set to.
     */
    protected void setFoodLevel(int foodAmount) {
        foodLevel = foodAmount;
    }

    /**
     * Get the food level of an animal
     * @return foodLevel The animal's food level.
     */
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Set the food value of the animal.
     * @param value The value to set the food value to.
     */
    protected void setFoodValue(int value) {
        foodValue = value;
    }

    /**
     * Get the food value of an animal
     * @return foodValue The animal's food value.
     */
    protected int getFoodValue() {
        return foodValue;
    }

    /**
     * Set a random age for the animal. 
     * @param maxAge Maximum age of the given animal.
     */
    protected void setRandomAge(int maxAge) {
        age = rand.nextInt(maxAge);
    }

    /**
     * Increase the age of the animal. 
     * This could result in the animal's death if the age is above the max age.
     * @param maxAge Maximum age of the given animal.
     */
    protected void increaseAge(int maxAge) {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }

    /**
     * Get the age of the animal. 
     * @return age The animal's age.
     */
    protected int getAge() {
        return age;
    }

    /**
     * A female animal can breed if it has reached the breeding age.
     * The animal itself must also be female and must have at least one male in its
     * adjacent or in an area locaiton. 
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed(int breedingAge, double breedingProbability, Animal male)
    {
        return (male != null) && (age >= breedingAge) && (rand.nextDouble() <= breedingProbability);
    }

    /**
     * Get whether the animal is male.
     * @return isMale True if the animal is male, false otherwise.
     */
    protected boolean isAnimalMale() {
        return isMale;
    }

    /**
     * Set whether the animal is male.
     * @param isMale Is the animal male or female.
     */
    protected void setIsMale(boolean isMale) {
        this.isMale = isMale;
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     * @param breedingAge The breeding age of the animal.
     * @param breedingProbability The breeding probability of the animal.
     * @param maxLitterSize The max litter size of the animal.
     * @return births The number of births.
     */
    protected int breed(int breedingAge, double breedingProbability, int maxLitterSize) 
    {
        int births = 0;
        Animal male = findMale();
        if(canBreed(breedingAge,breedingProbability, male)) {
            births = rand.nextInt(maxLitterSize) + 1;
            spreadDisease(male);
        }
        return births;
    }

    /**
     * Try to spread the the disease between the animals.
     * @param male The male animal that is breeding with the female.
     */
    private void spreadDisease(Animal male)
    {
        if(isInfected && rand.nextDouble() <= PROBABILITY_OF_DISEASE_SPREAD) {
            // A chance the male gets infected if the female is infected.
            male.setIsInfected(true);
        }
        else if(male.getIsInfected() && rand.nextDouble() <= PROBABILITY_OF_DISEASE_SPREAD) {
            // A chance the female gets infected if the male is infected
            isInfected  = true;
        }
    }

    /**
     * Move the animal into a location in a specified area from the initial location.
     * @param distance The maximum distance from the initial location the animal can move to.
     */
    protected void moveToInAreaLocation(int distance) {
        Location newLocation = animalField.freeInAreaLocation(getLocation(), distance);
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Get whether the animal is infected by the disease.
     * @return isInfected True if the animal is infected, false otherwise.
     */
    protected boolean getIsInfected(){
        return isInfected;
    }

    /**
     * Set whether the animal is infected or not.
     * @param setInfected Whether the animal is infected or not.
     */
    protected void setIsInfected(boolean setInfected){
        isInfected = setInfected;
    }
    
    /**
     * Check whether the animal dies from the disease.
     * @param chanceOfDying The probability that an infected animal dies.
     */
    protected void checkDisease(double chanceOfDying) {
        if(getIsInfected() && rand.nextDouble() < chanceOfDying){
            setDead();
        }
    }

}
