import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
/**
 * The class AnimalField is a subclass of the class Field.
 * It specifies the methods for the field that stores Animals in it.
 *
 * @version 2020.02.12
 */
public class AnimalField extends Field
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class AnimalField
     */
    public AnimalField(int depth, int width)
    {
        super(depth,width);
    }

    /**
     * Return a shuffled list of locations in the specified distance to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @param distance The distance from the given location.
     * @return A list of locations adjacent to that given.
     */
    public List<Location> inAreaLocations(Location location, int distance)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        if(location != null) {
            int row = location.getRow();
            int col = location.getCol();
            for(int roffset = -distance; roffset <= distance; roffset++) {
                int nextRow = row + roffset;
                if(nextRow >= 0 && nextRow < getDepth()) {
                    for(int coffset = -distance; coffset <= distance; coffset++) {
                        int nextCol = col + coffset;
                        // Exclude invalid locations and the original location.
                        if(nextCol >= 0 && nextCol < getWidth() && (roffset != 0 || coffset != 0)) {
                            locations.add(new Location(nextRow, nextCol));
                        }
                    }
                }
            }

            // Shuffle the list. Several other methods rely on the list
            // being in a random order.

            Collections.shuffle(locations, rand);
        }
        return locations;
    }

    /**
     * Try to find a free location in the specified distance to the given one. 
     * If there is none, return null.
     * The returned location will be within the valid bounds of the field.
     * @param location The location from which to generate a free location.
     * @param distance The distance from the given location.
     * @return A valid location within the grid area.
     */
    public Location freeInAreaLocation(Location location, int distance)
    {
        // The available free ones.
        List<Location> free = getFreeInAreaLocations(location, distance);
        if(free.size() > 0) {
            return free.get(0);
        }
        else {
            return null;
        }
    }

    /**
     * Get a shuffled list of the free adjacent locations.
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */
    public List<Location> getFreeInAreaLocations(Location location, int distance)
    {
        List<Location> free = new LinkedList<>();
        List<Location> inArea = inAreaLocations(location, distance);
        for(Location next : inArea) {
            if(getObjectAt(next) == null) {
                free.add(next);
            }
        }
        return free;
    }
}
