import java.util.List;
import java.util.Iterator;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
/**
 * The interface Carnivore defines the eat method for all animals that are carnivores.
 * Carnivores eat other animals that are their prey in a specfied radius from the canrnivore's location.
 *
 * @version 2020.02.12
 */
public interface Carnivore
{
    /**
     * Make the animal hunt for its prey in the specified radius from its location.
     * @param animal The animal that is supposed to eat.
     * @param animalField The field that stores the animals.
     * @param location the location of the animal.
     * @param maxFoodLevel The maximum food level of the animal.
     * @param canEatAnimals The array of the animals that the carnivore can eat.
     * @param huntProbability The probability of the animal successfuly hunting its prey.
     * @param distance The distance from the animal's location that it can hunt in.
     */
    public default void hunt(Animal animal, AnimalField animalField, int maxFoodLevel, Class[] canEatAnimals, double huntProbability, int distance) {
        Location location = animal.getLocation();
        if(location != null) {
            Random rand = Randomizer.getRandom(); 
            // Get the array of prey as a list to shuffel it, so the carnivore does not always start looking for the same species of animal.
            List<Class> shuffledArray = Arrays.asList(canEatAnimals);
            Collections.shuffle(shuffledArray, rand);
            List<Location> inArea = animalField.inAreaLocations(location, distance); 
            Iterator<Location> it = inArea.iterator();
            Animal animalToEat = null;
            while(it.hasNext()) {
                Location where = it.next();
                Object animalFound = animalField.getObjectAt(where);
                for(int i = 0; i < shuffledArray.size(); i++) {
                    if(shuffledArray.get(i).isInstance(animalFound) ) {
                        animalToEat = (Animal) animalFound;
                        if(animalToEat.isAlive()) {
                            break;
                        }
                        else {
                            animalToEat = null;
                        }
                    }
                }
                // Make the predator eat the prey and move to its location.
                if(animalToEat != null) {
                    if(rand.nextDouble() < huntProbability) {
                        int foodValue = animalToEat.getFoodValue(); 
                        if((foodValue + animal.getFoodLevel()) <= maxFoodLevel) {
                            animal.increaseFoodLevel(foodValue);
                        }
                        else {               
                            animal.setFoodLevel(maxFoodLevel);
                        }

                        if(animalToEat.getIsInfected()) {
                            // If the animal eats an animal which is already infected by disease, itself gets infected by disease as well.
                            animal.setIsInfected(true);
                        }                
                        animalToEat.setDead();
                        animal.setLocation(where);
                        break;
                    }
                } 
            }
            
            // If no prey is found try to move to a free location.
            if(animalToEat == null) {
                animal.moveToInAreaLocation(distance);
            }
        }
    }
}
