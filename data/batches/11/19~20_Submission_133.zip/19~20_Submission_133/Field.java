import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Represent a rectangular grid of field positions.
 * Each position is able to store a single object.
 *
 * @version 2020.02.12
 */
public abstract class Field
{
     // The depth and width of the field.
    private int depth,width;
    // Storage for the objects.
    private Object[][] field;
    
    /**
     * Represent a field of the given dimensions.
     * @param depth The depth of the field.
     * @param width The width of the field.
     */
    public Field(int depth, int width){
        this.depth = depth;
        this.width = width;
        field = new Object[depth][width];
    }

    /**
     * Return the depth of the field.
     * @return The depth of the field.
     */
    protected int getDepth(){
        return depth;
    }

    /**
     * Return the width of the field.
     * @return The width of the field.
     */
    protected int getWidth(){
        return width;
    }

    /**
     * Empty the field.
     */
    protected void clear(){
        for(int row = 0; row < getDepth(); row++) {
            for(int col = 0; col < getWidth(); col++) {
                field[row][col] = null;
            }
        }
    }

    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    protected void clear(Location location){
         field[location.getRow()][location.getCol()] = null;
    }

    /**
     * Place an object at the given location.
     * If there is already an object at the location it will
     * be lost.
     * @param object The object to be placed.
     * @param row Row coordinate of the location.
     * @param col Column coordinate of the location.
     */
    protected void place(Object object, int row, int col){
        place(object, new Location(row, col));
    }

    /**
     * Place an object at the given location.
     * If there is already an object at the location it will
     * be lost.
     * @param object The object to be object.
     * @param location Where to place the object.
     */
    protected void place(Object object, Location location){
        field[location.getRow()][location.getCol()] = object;
    }
    

    /**
     * Return the object at the given location, if any.
     * @param location Where in the field.
     * @return The object at the given location, or null if there is none.
     */
    protected Object getObjectAt(Location location){
        return getObjectAt(location.getRow(), location.getCol());
    }

    /**
     * Return the animal at the given location, if any.
     * @param row The desired row.
     * @param col The desired column.
     * @return The animal at the given location, or null if there is none.
     */
    protected Object getObjectAt(int row, int col){
        return field[row][col];
    }
}

