import java.util.Random;
import java.util.List;
/**
 *  A simple simulation of the weather.
 *  The object of the class is supposed to randomly return 
 *  a weather type (an integer), which have different effect
 *  on different animals and plants.
 *
 * @version 2020.02.12
 */
public class Weather 
{   
    // The number of weather types. 0 for rainy, 1 for sunny, 2 for foggy.
    private static final int NUMBER_OF_WEATHER_TYPES = 3; 
    // The weather's type. 
    int weatherType;

    /**
     * Constructor for objects of class Weather.
     */
    public Weather() {
    }

    /**
     * Generate a random weather type.
     * @return weatherType A random integer indicating the weather type.
     */
    public int newWeather() {
        Random rand = Randomizer.getRandom();
        weatherType = rand.nextInt(NUMBER_OF_WEATHER_TYPES);
        return weatherType;
    }
    
    /**
     * Get the name of the weather type.
     * @return The name of the current weather. 
     */
    public String getWeatherName() {
        switch(weatherType) {
            case 0:
            return "Rainy";
            case 1:
            return "Sunny";
            case 2:
            return "Foggy";
            default:
            return "Unknown";
        }
    }
}
