import java.util.*;
/**
 * A simple model for lions in the simulation.
 * This class stores the breeding age, max age, breeding probability, max litter size,
 * max food level, and the preys that can be eaten for the whole species.
 * This class defines how the lions behave and act in the simulation.
 *
 * @version 2020.02.17
 */
public class Lion extends Animal implements Carnivore
{
    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 14;
    // The age to which a lion can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum food level of lion
    private static final int MAX_FOOD_LEVEL = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // list of animals that lion can eat
    private static final Class[] CAN_EAT = {Giraffe.class, Antelope.class};
    /**
     * Constructor for objects of class Lion with given gender.
     * @param random Whether to set the age and food level to random values.
     * @param isMale Whether the animal is male or female.
     * @param animalField The field that stores the animals.
     * @param location The location of the animal.
     */
    public Lion(boolean random, boolean isMale, AnimalField animalField, Location location)
    {
        super(animalField, location);
        setIsMale(isMale);
        // age = 0 by default. Set in the Animal class.
        // foodLevel = 5 by default. Set in the Animal class.
        if(random) {
            setRandomAge(MAX_AGE);
            setFoodLevel(rand.nextInt(MAX_FOOD_LEVEL) + 1);
        }
    }

    /**
     * Lion acts differently depending on the time of the day and the weather.
     * @param newLions The list of new born lions.
     * @param timeOfDay The time of the day.
     * @param chanceOfDying The probability of animal dying if it is infected.
     * @param weather The weather type.
     */
    public void act(List<Animal> newLions, int timeOfDay, double chanceOfDying, int weather) {        
        if(timeOfDay == 0) {
            increaseAge(MAX_AGE);
        }

        checkDisease(chanceOfDying);
        
        double huntProbability;

        if(isAlive()) {
            //If the weather is foggy, the hunting probability for lions is lower.
            if(weather == 2) {
                huntProbability = 0.85;
            }
            else{
                huntProbability = 1;
            }

            switch(timeOfDay) {

                case 0:
                // Morning, Lion sleeps
                break;

                case 1:
                // Afternoon, Lion gives births, hunts, food level decreases 
                if(!isAnimalMale()) {
                    giveBirth(newLions);
                }              
                hunt(this, getField(), MAX_FOOD_LEVEL, CAN_EAT, huntProbability, 1);
                decreaseFoodLevel(2);
                break; 

                case 2:
                // Evening, Lion gives birth, hunts, food level decreases 
                if(!isAnimalMale()) {
                    giveBirth(newLions);
                }         
                hunt(this, getField(), MAX_FOOD_LEVEL, CAN_EAT, huntProbability, 1);
                decreaseFoodLevel(2);
                break;

                case 3:
                // Night, Lion gives birth, hunts, food level decreases 
                if(!isAnimalMale()) {
                    giveBirth(newLions);
                }   
                hunt(this, getField(), MAX_FOOD_LEVEL, CAN_EAT, huntProbability, 1);
                decreaseFoodLevel(3);
                break;
            }
        }
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLion A list to return newly born lions.
     */
    protected void giveBirth(List<Animal> newLion)
    {
        AnimalField animalField = getField();
        List<Location> free = animalField.getFreeInAreaLocations(getLocation(),1);
        int births = breed(BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, rand.nextBoolean(), animalField, loc);
            newLion.add(young);
        }
    }

    /**
     * Look for male partner in specified distance to the current location.
     * @return lion The male lion if found, null otherwise.
     */
    protected Animal findMale()
    {
        AnimalField animalField = getField();
        List<Location> inArea = animalField.inAreaLocations(getLocation(), 3);
        Iterator<Location> it = inArea.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = animalField.getObjectAt(where);
            if(animal instanceof Lion) {
                Lion lion = (Lion) animal;
                if(lion.isAnimalMale()) { 
                    return lion;
                }
            }
        }
        return null;
    }

}
