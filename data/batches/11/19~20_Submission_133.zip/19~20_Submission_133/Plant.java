import java.util.Random;
import java.util.List;
/**
 * A simple model for plants.
 * Plants grow and have a food value, location, they may be infected
 * and they have a probability to spread disease among themself.
 * 
 * @version 2020.02.12
 */
public class Plant
{
    // The maximum food value for plants at created initialy.
    private static final int MAX_FOOD_VALUE = 10;
    //The probability the disease spreads to other plants.
    private static final double PROBABILITY_OF_DISEASE_SPREAD = 0.3;
    // The current food value of the plants.
    private int foodValue;
    // The probability of plant being infected by disease.
    private boolean isInfected;
    // The plant's position in the field.
    private Location location;
    // A shared random number generator to control food value.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Plant.
     * Each plant has a location, can be infected, and have a food value.
     * @param location The location of the Plant in the PlantField
     * @param isInfected Are the plants infected.
     */
    public Plant(Location location, Boolean isInfected)
    {
        this.location = location;
        this.isInfected = isInfected;
        foodValue = rand.nextInt(MAX_FOOD_VALUE);

    }

    /**
     * Reset the food value to 0, because the plant was eaten by animal.
     */
    public void plantEaten() {
        foodValue = 0;
    }

    /**
     * Make the plants grow.
     * @param newWeather The current weather in the simulation.
     * @param plantsField The field that stores the plants.
     */
    public void grow(int newWeather, PlantsField plantsField) {
        // Find adjacent location and see if other plants have got disease
        // If there is more than 4 plants then get infected as well
        switch(newWeather) {
            case 0:
                // Rainy waether. Plants grow more.
                foodValue += 7;
                break;
            case 1:
                // Sunny weather. The infection may spread between plants.
                foodValue += 5;
                spreadDisease(plantsField, 4);
            case 2: 
                // Foggy weather. Plants grow less.
                foodValue += 4;
                break;
            default:
                foodValue += 5;
                break;
        }
    }

    /**
     * Get the number of infected plants adjacent to the current ones.
     * @param plantField The field that stores the plants.
     * @return counts The number of adjacent infected plants.
     */
    private int findInfectedPlants(PlantsField plantsField) {
        int counts = 0;
        List<Location> adjacentLocations = plantsField.adjacentLocations(location);
        for(Location loc:adjacentLocations) {
            Plant neighbor = (Plant) plantsField.getObjectAt(loc);
            if(neighbor.isInfected()){
                counts ++;
            }
        }
        return counts;
    } 

    /**
     * Try to spread the the disease between the plants.
     * @param plantField The field that stores the plants.
     * @infectedCount The number of infeced adjacent to the plant for the disease to have a chance to spread.
     */
    private void spreadDisease(PlantsField plantsField, int infectedCount)
    {
        if(findInfectedPlants(plantsField) >= infectedCount && rand.nextDouble() <= PROBABILITY_OF_DISEASE_SPREAD) {
            isInfected = true;
        }
    }
    
    /**
     * Get the food value of the plant.
     *
     * @return foodValue The food value of the plant.
     */
    public int getFoodValue() {
        return foodValue;
    }

    /**
     * Get whether the plant is infected or not.
     * @return isInfected True if the plant is infected, false otherwise
     */
    public boolean isInfected() {
        return isInfected;
    }

    /**
     * Get the location of the plant.
     * @return location The location of the plant.
     */
    public Location getLocation() {
        return location;
    }
}
