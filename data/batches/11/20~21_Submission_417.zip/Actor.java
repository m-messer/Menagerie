import java.util.List;
/**
 * A class representing shared characteristics of actors:
 * their field, location on the field and if they are living.
 * @version 2021.03.03
 */

public abstract class Actor 
{
    // Whether or not the actor is alive.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    private Location location;
    
    /**
     * Create a new actor at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Actor(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation() {
        return location;
    }
    
    /**
     * How the actor acts every step; abstract to be
     * implemented in each animal or plant.
     * @param newActors A list of new actors.
     */
    public abstract void act(List<Actor> newActors);

    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    public boolean isAlive() {
        return alive;
    }
    
    /**
     * Set the actor to dead.
     * Clear the actors location and field.
     */
    protected void setDead() {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }
}
    
