import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of plants: their 
 * location in the field and the likelihood and amount that they
 * reproduce.
 *
 * @version 2021.03.03
 */
public abstract class Plant extends Actor 
{
    // A random number generator.
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public abstract void act(List<Actor> newPlants);
    
    protected int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
   
    /** 
     * The likelihood of the plant reproducing.
     */
    protected abstract double getBreedingProbability();

    /** 
     * Get the maximum number of births this plant can do.
     */
    protected abstract int getMaxLitterSize();
}
