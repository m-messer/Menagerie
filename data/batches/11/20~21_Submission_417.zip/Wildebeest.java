import java.util.List;
import java.util.Random;
import java.util.ArrayList;
/**
 * A type of animal: Wildebeest. They age and die, and when they move they decide
 * based on what other actors are around them to mate or eat grass.
 *
 * @version 2021.03.03
 */
public class Wildebeest extends Animal
{
    // Characteristics shared by all Wildebeests (class variables):

    // The age at which a Wildebeest can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Wildebeest can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a Wildebeest breeding.
    private static final double BREEDING_PROBABILITY = 0.94;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of grass. In effect, this is the
    // number of steps a Wildebeest can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 3;
    // The mate level of a Wildebeest. This is used to determine when 
    // a Wildebeest will favour a mate in its proximity.
    private static final int WILDEBEEST_MATE_LEVEL = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new Wildebeest. A Wildebeest may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Wildebeest will have a random age, food level and mate level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wildebeest(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if (randomAge) {
        changeAge(rand.nextInt(MAX_AGE));
        addFoodLevel(rand.nextInt(GRASS_FOOD_VALUE));
        changeMateLevel(rand.nextInt(BREEDING_AGE));
        }
        else {
            changeAge(0);
            addFoodLevel(GRASS_FOOD_VALUE);
            changeMateLevel(BREEDING_AGE);
        }
    }
    
    /**
     * This is what the Wildebeest does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newWildebeests A list of newly born Wildebeests.
     */
    public void act(List<Actor> newWildebeests)
    {
        super.act(newWildebeests);
        if(isAlive() && getField().isDay()) {    // Hunger is only incremented if the animal is moving  
            incrementHunger();
            decrementMateLevel();
        }
        if(isAlive() && getField().isDay()) {   // WIldebeests only move during the day. 
            // Move towards grass or a Wildebeest.
            Location newLocation = move(newWildebeests);
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }   
            else {
                setDead();
            }
        }
    }

    /**
     * Look for Wildebeests adjacent to the current location if the mate level
     * is low enough, otherwise choose to eat grass.
     * @param newWildebeests A list of newly born Wildebeests.
     * @return A free location adjacent to the mate Wildebeest.
     * @return The location of the grass eaten. 
     */
    protected Location move(List<Actor> newWildebeests)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        ArrayList<Actor> visibleActors = new ArrayList<>();
        for(Location location : adjacent) {
            visibleActors.add((Actor)getField().getObjectAt(location));
        }
        for(Actor actor : visibleActors) {    // Searches for any members of the same sex in adjacent locations first.
            if(actor instanceof Wildebeest && getMateLevel() < WILDEBEEST_MATE_LEVEL) {
                Wildebeest wildebeest = (Wildebeest) actor;
                if (this.isFemale() && !wildebeest.isFemale() || !this.isFemale() && wildebeest.isFemale()) {    // Checks if the mating Wildebeests are of opposite sex.
                addFoodLevel(-2);  // Giving birth uses food as a resource.
                giveBirth(newWildebeests);
                changeMateLevel(5);  // Mating satisfies the Wildebeest for a while; preventing constant mating.
                if (wildebeest.isDiseased()) {
                    catchChance();   // The chance of catching a disease from mating.
                }
                return getField().freeAdjacentLocation(wildebeest.getLocation()); 
                }
            }
        }
        for(Actor actor : visibleActors) {         // Then searches for grass. 
            if(actor instanceof Grass) {
                Grass grass = (Grass) actor;
                Location loc = grass.getLocation();
                if(grass.isAlive()) { 
                    grass.setDead();
                    addFoodLevel(GRASS_FOOD_VALUE);
                    return loc;
                }
            }
        }
        return null;
    }


    /**
     * Check whether or not this Wildebeest is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWildbeests A list to return newly born wildebeests.
     */
    private void giveBirth(List<Actor> newWildebeests)
    {
        // New Wildebeests are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wildebeest young = new Wildebeest(false, field, loc);
            newWildebeests.add(young);
        }
    }

    /**
     * A Wildebeest can breed if it has reached the breeding age.
     * @return true if the Wildebeest can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * A Wildebeest will die if it has reached the max age.
     * @return true if the Wildebeest has reached the max age, false otherwise.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * A Wildebeests maximum litter size is the maximum number of Wildebeest that can be 
     * born every time it gives birth.
     * @return the maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * A Wildebeests breeding probability is the chance that  it will give birth when
     * encountering a member of the opposite sex.
     * @return a double set somewhere from 0 to 1.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A Wildebeest's breeding age is the age it must reach before it can breed
     * @return an int representing age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}
