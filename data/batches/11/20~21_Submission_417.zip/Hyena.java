import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A type of animal: Hyena. They age and die, and when they move they decide
 * based on what other actors are around them to mate, eat Wildebeest or
 * WaterBuffalo (their prey), and they may be eaten by Lions.
 *
 * @version 2021.03.03
 */
public class Hyena extends Animal
{
    // Characteristics shared by all Hyena (class variables).
    
    // The age at which a Hyena can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a Hyena can live.
    private static final int MAX_AGE = 280;
    // The likelihood of a Hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.84;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single Wildebeest. In effect, this is the
    // number of steps a Hyena can go before it has to eat again.
    private static final int WILDEBEEST_FOOD_VALUE = 12;
    // The food value of a single Water Buffalo. In effect, this is the
    // number of steps a Hyena can go before it has to eat again.
    private static final int WATERBUFFALO_FOOD_VALUE = 18;
    // The mate level of a Hyena. This is used to determine when 
    // a Hyena will favour a mate in its proximity.
    private static final int HYENA_MATE_LEVEL= 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Hyena. A Hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Hyena will have a random age, food level and mate level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            changeAge(rand.nextInt(MAX_AGE));
            addFoodLevel(rand.nextInt(WILDEBEEST_FOOD_VALUE));
            changeMateLevel(rand.nextInt(BREEDING_AGE));
        }
        else {
            changeAge(0);
            addFoodLevel(WILDEBEEST_FOOD_VALUE);
            changeMateLevel(BREEDING_AGE);
        }
    }
    
    /**
     * This is what the Hyena does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newHyenas A list to return newly born Hyenas.
     */
    public void act(List<Actor> newHyenas)
    {
        super.act(newHyenas);
        if(isAlive() && !getField().isDay()) {   // Hunger is only incremented if the animal is moving.
            incrementHunger();
            decrementMateLevel();
        }
        if(isAlive() && !getField().isDay()) {   //The hyena only moves/hunts at night.   
            // Move towards a source of food or mate.
            Location newLocation = move(newHyenas);
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }   
            else {
                setDead();
            }
        }
    }
    
    
    /**
     * Look for Hyenas adjacent to the current location if the mate level
     * is low enough, otherwise choose to eat prey animals.
     * @param newHyenas A list of newly born Hyenas.
     * @return A free location adjacent to the mate Hyena.
     * @return The location of the prey eaten or grass.
     */
    protected Location move(List<Actor> newHyenas)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        ArrayList<Actor> visibleActors = new ArrayList<>();
        for(Location location : adjacent) {
            visibleActors.add((Actor)getField().getObjectAt(location));
        }
        for(Actor actor : visibleActors) {      // Searches for any members of the same sex in adjacent locations first.
            if(actor instanceof Hyena && getMateLevel() < HYENA_MATE_LEVEL) {
                Hyena hyena = (Hyena) actor;
                if (this.isFemale() && !hyena.isFemale() || !this.isFemale() && hyena.isFemale()) {   // Checks if the mating Hyenas are of opposite sex.
                addFoodLevel(-5);  // Giving birth uses food as a resource.
                giveBirth(newHyenas);   
                changeMateLevel(14);   // Mating satisfies the Hyena for a while; preventing constant mating.
                if (hyena.isDiseased()) {
                    catchChance();      // The chance of catching a disease from mating.
                }
                return getField().freeAdjacentLocation(hyena.getLocation()); 
                }
            }
        }
        for(Actor actor : visibleActors) {   // Then searches for any prey animals.
            if(actor instanceof Wildebeest) {
                Wildebeest wildebeest = (Wildebeest) actor;
                Location loc = wildebeest.getLocation();
                if(wildebeest.isAlive()) { 
                    if (wildebeest.isDiseased()) {
                        catchChance();
                    }
                    wildebeest.setDead();
                    addFoodLevel(WILDEBEEST_FOOD_VALUE);
                    return loc;
                }
            }
        }     
            for(Actor actor : visibleActors) {
            if(actor instanceof WaterBuffalo) {
                WaterBuffalo waterbuffalo = (WaterBuffalo) actor;
                Location loc = waterbuffalo.getLocation();
                if(waterbuffalo.isAlive()) { 
                    waterbuffalo.setDead();
                    addFoodLevel(WATERBUFFALO_FOOD_VALUE);
                    return loc;
                }
            }
        }
            for(Actor actor : visibleActors) {
            if(actor instanceof Grass) {
                Grass grass = (Grass) actor;
                Location loc = grass.getLocation();
                if(grass.isAlive()) { 
                    grass.setDead();
                    return loc;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Hyena is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHyenas A list to return newly born Hyena.
     */
    private void giveBirth(List<Actor> newHyenas)
    {
        // New Hyena are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hyena young = new Hyena(false, field, loc);
            newHyenas.add(young);
        }
    }

     /**
     * A Hyena can breed if it has reached the breeding age.
     * @return true if the Hyena can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * A Hyena's breeding probability is the chance that  it will give birth when
     * encountering a member of the opposite sex.
     * @return a double set somewhere from 0 to 1.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * A Hyena's maximum litter size is the maximum number of Hyenas that can be 
     * born every time it gives birth.
     * @return the maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * A Hyena will die if it has reached the max age.
     * @return true if the Hyena has reached the max age, false otherwise.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

     /**
     * A Hyena's breeding age is the age it must reach before it can breed
     * @return an int representing age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
}
