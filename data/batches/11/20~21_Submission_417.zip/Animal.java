import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals: food needs,
 * mating needs, age, gender and if the animal is infected.
 *
 * @version 2021.03.03
 */
public abstract class Animal extends Actor 
{
    // A random number generator.
    private static final Random rand = Randomizer.getRandom();
    // The probabilty of catching and dying from a disease.
    private static final double DISEASE_PROBABILITY = 0.12;
    // The probability of male and female
    private static final double SEX_PROBABILITY = 0.50;

    // The animal's age.
    protected int age;
    // The animal's food level.
    protected int foodLevel;
    // The animal's mate level. 
    protected int mateLevel;
    // The sex of the animal.
    private boolean isFemale;
    // If the animal is infected.
    private boolean isDiseased;

    /**
     * Create a new animal at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {   
        super(field, location);
        age = 0;
        foodLevel = 4;   // The base food level.
        mateLevel = 0;
        if(rand.nextDouble() <= SEX_PROBABILITY){   // Determines sex of animal (50/50).
            isFemale = true;
        } else{
            isFemale = false;
        }
        if(rand.nextDouble() <= DISEASE_PROBABILITY){  // Determines animals that begin infected. 
            isDiseased = true;
        } else{
            isDiseased = false;
        }
    }
    
    /**
     * How the animal acts every step; abstract to be
     * implemented in each animal.
     * @param newAnimals A list of newly born animals.
     */
    public void act(List<Actor> newAnimals) {
        incrementAge();
        diseaseDeathChance();         // At every step there is a chance of death from the disease the animal is infected with.
    }
    
    /**
     * Return the sex of the animal; used in to determine if meeting
     * animals are of the opposite sex in breeding.
     * @return true if the animal is female, false otherwise.
     */
    public boolean isFemale(){
        return isFemale;
    }
    
    /**
     * Return the age of the animal; used to determine if the 
     * animal has surpassed its max age and should die.
     * @return the current age of the animal.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Change the age of an animal.
     * @param newAge the new age of the animal.
     */
    protected void changeAge(int newAge) {
        age = newAge;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }
    
    /**
     * The breeding age of the animal.
     * Implemented to return each individual breeding
     * age of each animal.
     * @return the breeding age.
     */
    protected abstract int getBreedingAge();
    
    /**
     * Increase the age by 1; called at each step.
     * This could result in the animals death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Decrease the mate level by 1; called at 
     * each step. This will cause the animal
     * to want to mate if lower than each
     * individual animals mate level. 
     */
    protected void decrementMateLevel()
    {
        mateLevel--;
        if (mateLevel < 0) {
            mateLevel = 0;
        }
    }
    
    /**
     * Return the mate level of the animal.
     * @return the current mate level of the animal. 
     */
    protected int getMateLevel() 
    {
        return mateLevel;
    }
    
    /**
     * Change the mate level of the animal.
     * @param newMateLevel the new mate level of the animal.
     */
    protected void changeMateLevel(int newMateLevel)
    {
        mateLevel += newMateLevel;
        if (mateLevel < 0) {   // Mate level can only be a minimum of 0.
            mateLevel = 0;
        }
    }
    
    /**
     * The max age of the animal.
     * Implemented to return each individual max
     * age of each animal.
     * @return the max age.
     */
    protected abstract int getMaxAge();
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Return the food level of the animal.
     * @return the current food level of the animal. 
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Add to the food level of the animal.
     * @param newFoodLevel the food level to be added to the animal.
     */
    protected void addFoodLevel(int newFoodLevel) {
        foodLevel += newFoodLevel;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * The breeding probability of the animal.
     * Implemented to return each individual breeding
     * probability of each animal.
     * @return the breeding probability.
     */
    protected abstract double getBreedingProbability();
    
    /**
     * The max litter size of the animal.
     * Implemented to return each individual max
     * litter size of each animal.
     * @return the litter size.
     */
    protected abstract int getMaxLitterSize();
    
    /**
     * The chance of infection when breeding or
     * eating some prey animals.
     */
    protected void catchChance() {
        if(!isDiseased && rand.nextDouble() <= DISEASE_PROBABILITY) {
            isDiseased = true;
        }
    }
    
    /**
     * Whether or not the animal is infected.
     * @return true if the animal is infected, false otherwise.
     */
    protected boolean isDiseased() {
        
            return isDiseased;
    }
    
    /**
     * A chance of death if the animal is infected 
     * with a disease at every step.
     */
    protected void diseaseDeathChance() {
        if(isDiseased == true && rand.nextDouble() <= DISEASE_PROBABILITY) {
            setDead();
        }
    }
}
