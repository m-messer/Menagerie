import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A type of animal: Lion. They age and die, and when they move they decide
 * based on what other actors are around them to mate or eat Wildebeests,
 * WaterBuffalo and Hyenas (their prey).
 *
 * @version 2021.03.03
 */
public class Lion extends Animal
{
    // Characteristics shared by all Lions (class variables).
    
    // The age at which a Lion can start to breed.
    private static final int BREEDING_AGE = 25;
    // The age to which a Lion can live.
    private static final int MAX_AGE = 400;
    // The likelihood of a Lion breeding.
    private static final double BREEDING_PROBABILITY = 0.74;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single Wildebeest. In effect, this is the
    // number of steps a Lion can go before it has to eat again.
    private static final int WILDEBEEST_FOOD_VALUE = 6;
    // The food value of a single Water Buffalo. In effect, this is the
    // number of steps a Lion can go before it has to eat again.
    private static final int WATERBUFFALO_FOOD_VALUE = 10;
    // The food value of a single Hyena. In effect, this is the
    // number of steps a Lion can go before it has to eat again.
    private static final int HYENA_FOOD_VALUE = 4;
    // The mate level of a Lion. This is used to determine when 
    // a Lion will favour a mate in its proximity.
    private static final int LION_MATE_LEVEL= 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a Lion. A Lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Wildebeest will have a random age, food level and mate level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            changeAge(rand.nextInt(MAX_AGE));
            addFoodLevel(rand.nextInt(WILDEBEEST_FOOD_VALUE));
            changeMateLevel(rand.nextInt(BREEDING_AGE));
        }
        else {
            changeAge(0);
            addFoodLevel(WILDEBEEST_FOOD_VALUE);
            changeMateLevel(BREEDING_AGE);
        }
    }
    
    /**
     * This is what the Lion does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born Lions.
     */
    public void act(List<Actor> newLions)
    {
        super.act(newLions);
        if(isAlive() && !getField().isDay()) {    // Hunger is only incremented if the animal is moving.
            incrementHunger();
            decrementMateLevel();
        }
        if(isAlive() && !getField().isDay()) {    //The Lion only moves/hunts at night.       
            // Move towards a source of food or mate.
            Location newLocation = move(newLions);
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }   
            else {
                setDead();
            }
        }
    }
    
    /**
     * Look for Lions adjacent to the current location if the mate level
     * is low enough, otherwise choose to eat prey animals.
     * @param newLions A list of newly born Lions.
     * @return A free location adjacent to the mate Lion.
     * @return The location of the prey eaten or grass.
     */
     protected Location move(List<Actor> newLions)
    {
        Field field = getField();
        List<Location> adjacent = field.lionLocations(getLocation());
        ArrayList<Actor> visibleActors = new ArrayList<>();
        for(Location location : adjacent) {
            visibleActors.add((Actor)getField().getObjectAt(location));
        }
        for(Actor actor : visibleActors) {      // Searches for any members of the same sex in adjacent locations first.
            if(actor instanceof Lion && getMateLevel() < LION_MATE_LEVEL) {
                Lion lion = (Lion) actor;
                if (this.isFemale() && !lion.isFemale() || !this.isFemale() && lion.isFemale()) { // Checks if the mating lions are of opposite sex.
                addFoodLevel(-4);          // Giving birth uses food as a resource.
                giveBirth(newLions);
                changeMateLevel(16);       // Mating satisfies the Lion for a while; preventing constant mating.
                if (lion.isDiseased()) {
                    catchChance();        // The chance of catching a disease from mating.
                }
                return getField().freeAdjacentLocation(lion.getLocation()); 
                }
            }
        }
        for(Actor actor : visibleActors) {      // Then searches for any prey animals.
            if(actor instanceof Wildebeest) {
                Wildebeest wildebeest = (Wildebeest) actor;
                Location loc = wildebeest.getLocation();
                if(wildebeest.isAlive()) { 
                    if (wildebeest.isDiseased()) {
                        catchChance();
                    }
                    wildebeest.setDead();
                    addFoodLevel(WILDEBEEST_FOOD_VALUE);
                    return loc;
                }
            }
        } 
        for(Actor actor : visibleActors){
            if(actor instanceof Hyena) {
                Hyena hyena = (Hyena) actor;
                Location loc = hyena.getLocation();
                if(hyena.isAlive()) { 
                    hyena.setDead();
                    addFoodLevel(HYENA_FOOD_VALUE);
                    return loc;
                }
            }
        }    
        for(Actor actor : visibleActors) {
            if(actor instanceof WaterBuffalo) {
                WaterBuffalo waterbuffalo = (WaterBuffalo) actor;
                Location loc = waterbuffalo.getLocation();
                if(waterbuffalo.isAlive()) { 
                    waterbuffalo.setDead();
                    addFoodLevel(WATERBUFFALO_FOOD_VALUE);
                    return loc;
                }
            }
        }
        for(Actor actor : visibleActors) {
            if(actor instanceof Grass) {
                Grass grass = (Grass) actor;
                Location loc = grass.getLocation();
                if(grass.isAlive()) { 
                    grass.setDead();
                    return loc;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born Lion.
     */
    private void giveBirth(List<Actor> newLions)
    {
        // New Lion are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }

     /**
     * A Lion can breed if it has reached the breeding age.
     * @return true if the Lion can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * A Lion's breeding probability is the chance that  it will give birth when
     * encountering a member of the opposite sex.
     * @return a double set somewhere from 0 to 1.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * A Lion's maximum litter size is the maximum number of Lions that can be 
     * born every time it gives birth.
     * @return the maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * A Lion will die if it has reached the max age.
     * @return true if the Lion has reached the max age, false otherwise.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

     /**
     * A Lion's breeding age is the age it must reach before it can breed
     * @return an int representing age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
}
