import java.util.List;
/**
 * A type of plant: Grass. They breed and die if they are eaten, and do not move. They are a
 * source of food for Wildebeest and Water Buffalo.
 *
 * @version 2021.03.03
 */
public class Grass extends Plant
{
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The likelihood of Grass reproducing.
    private static final double GRASS_BREEDING_PROBABILITY = 0.30;
    /**
     * Create new Grass at a location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * This is what the Grass does most of the time: it tries
     * to breed. In the process it may be eaten.
     * @param newHyenas A list to return newly born Hyenas.
     */
    public void act(List<Actor> newGrass){
        if(isAlive() && getField().isRain()) {
            giveBirth(newGrass);
        }
    }

    /**
     * Check whether or not this Grass is to produce offspring at this step.
     * New births will be made into free adjacent locations.
     * @param newHyenas A list to return newly born Grass.
     */
    private void giveBirth(List<Actor> newGrass){
        // New Grass spawn into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(field, loc);
            newGrass.add(young);
        }
    }

    /**
     * The Grass's breeding probability is the chance that it will give birth
     * at any step.
     * @return a double set somewhere from 0 to 1.
     */
    protected double getBreedingProbability(){
        return GRASS_BREEDING_PROBABILITY;
    }
    
     /**
     * The Grass's maximum litter size is the maximum number of Grass that can spawn
     * every time it gives birth.
     * @return the maximum litter size.
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
}
