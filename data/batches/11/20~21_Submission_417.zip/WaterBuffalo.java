import java.util.List;
import java.util.Random;
import java.util.ArrayList;
/**
 * A type of animal: WaterBuffalo. They age and die, and when they move they decide
 * based on what other actors are around them to mate or eat grass.
 *
 * @version 2021.03.03
 */
public class WaterBuffalo extends Animal
{
    // Characteristics shared by all Water Buffalo (class variables).

    // The age at which a Water Buffalo can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Water Buffalo can live.
    private static final int MAX_AGE = 300;
    // The likelihood of a Water Buffalo breeding.
    private static final double BREEDING_PROBABILITY = 0.94;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of grass. In effect, this is the
    // number of steps a Water Buffalo can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 3;
    // The mate level of a Water Buffalo. This is used to determine when 
    // a Water Buffalo will favour a mate in its proximity.
    private static final int WATERBUFFALO_MATE_LEVEL = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new Water Buffalo. A Water Buffalo may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Water Buffalo will have a random age, food level and mate level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public WaterBuffalo(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if (randomAge) {
        changeAge(rand.nextInt(MAX_AGE));
        addFoodLevel(rand.nextInt(GRASS_FOOD_VALUE));
        changeMateLevel(rand.nextInt(BREEDING_AGE));
        }
        else {
            changeAge(0);
            addFoodLevel(GRASS_FOOD_VALUE);
            changeMateLevel(BREEDING_AGE);
        }
    }
    
    /**
     * This is what the Water Buffalo does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newWaterBuffalo A list of newly born WaterBuffalo.
     */
    public void act(List<Actor> newWaterBuffalo)
    {
        super.act(newWaterBuffalo);
        if(isAlive() && getField().isDay()) {   // Hunger is only incremented if the animal is moving
            incrementHunger();
            decrementMateLevel();
        }
        if(isAlive() && getField().isDay()) {     // Water Buffalo only move during the day. 
            // Move towards grass or a Water Buffalo.
            Location newLocation = move(newWaterBuffalo);
            if(newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }   
            else {
                setDead();
            }
        }
    }

    /**
     * Look for Water Buffalo adjacent to the current location if the mate level
     * is low enough, otherwise choose to eat grass.
     * @param WaterBuffalo  A list of newly born Water Buffalo.
     * @return A free location adjacent to the mate Water Buffalo.
     * @return The location of the grass eaten. 
     */
    protected Location move(List<Actor> newWaterBuffalo)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        ArrayList<Actor> visibleActors = new ArrayList<>();
        for(Location location : adjacent) {
            visibleActors.add((Actor)getField().getObjectAt(location));
        }
        for(Actor actor : visibleActors) {     // Searches for any members of the same sex in adjacent locations first.
            if(actor instanceof WaterBuffalo && getMateLevel() < WATERBUFFALO_MATE_LEVEL) {
                WaterBuffalo waterbuffalo = (WaterBuffalo) actor;
                if (this.isFemale() && !waterbuffalo.isFemale() || !this.isFemale() && waterbuffalo.isFemale()) {  // Checks if the mating Water Buffalo are of opposite sex.
                addFoodLevel(-2);             // Giving birth uses food as a resource.
                giveBirth(newWaterBuffalo);
                changeMateLevel(6);         // Mating satisfies the Water Buffalo for a while; preventing constant mating.
                if (waterbuffalo.isDiseased()) {
                    catchChance();        // The chance of catching a disease from mating.
                }
                return getField().freeAdjacentLocation(waterbuffalo.getLocation()); 
                }
            }
        }
        for(Actor actor : visibleActors) {          // Then searches for grass. 
            if(actor instanceof Grass) {
                Grass grass = (Grass) actor;
                Location loc = grass.getLocation();
                if(grass.isAlive()) { 
                    grass.setDead();
                    addFoodLevel(GRASS_FOOD_VALUE);
                    return loc;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Water Buffalo is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWaterBuffalo A list to return newly born Water Buffalo.
     */
    private void giveBirth(List<Actor> newWaterBuffalo)
    {
        // New Water Buffalo are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            WaterBuffalo young = new WaterBuffalo(false, field, loc);
            newWaterBuffalo.add(young);
        }
    }

    /**
     * A Water Buffalo can breed if it has reached the breeding age.
     * @return true if the Water Buffalo can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * A Water Buffalo will die if it has reached the max age.
     * @return true if the Water Buffalo has reached the max age, false otherwise.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * A Water Buffalo's maximum litter size is the maximum number of Water Buffalo that can be 
     * born every time it gives birth.
     * @return the maximum litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * A Water Buffalo's breeding probability is the chance that  it will give birth when
     * encountering a member of the opposite sex.
     * @return a double set somewhere from 0 to 1.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A Water Buffalo's breeding age is the age it must reach before it can breed
     * @return an int representing age.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}
