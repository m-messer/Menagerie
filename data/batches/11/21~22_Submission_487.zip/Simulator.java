import java.util.Random;
import java.util.List;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
//import java.awt.Color;

/**
 * Predator prey simulator,
 * with all the animal and plant creation probabilities,
 * and random virus generation
 *
 * @version 2022.03.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
  //berryplant creation probability
    private static final double BERRYPLANT_CREATION_PROBABILITY = 0.2; 
    //mountain flower probability
    private static final double MOUNTAINFLOWER_CREATION_PROBABILITY = 0.4; 
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.023;
    // The probability that a warthog will be created in any given grid position.
    private static final double WARTHOG_CREATION_PROBABILITY = 0.08;
    // The probability that a rabbit will be created in any given grid position
    private static final double LION_CREATION_PROBABILITY = 0.02;
    // The probability that a warthog will be created in any given grid position.
    private static final double MEERKAT_CREATION_PROBABILITY = 0.07;
    // The probability that a warthog will be created in any given grid position.
    private static final double INSECT_CREATION_PROBABILITY = 0.09;


    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plants> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    //private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     * @throws IOException
     */
    public Simulator() 
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * @throws IOException
     */
    public Simulator(int depth, int width)
    {
     /**    if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }*/
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        //view = new SimulatorView(depth, width,this);
        //view.setColor(Rabbit.class, Color.ORANGE);
        //view.setColor(Fox.class, Color.BLUE);
        
        // Setup a valid starting point.
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    /**public void runLongSimulation()
    {
        simulate(4000);
    }*/
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
  /**   public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(500);   // uncomment this to run more slowly
        }
    }*/
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant
     */
    public Field simulateOneStep()
    {

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            generateVirus(animal);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Provide space for newborn plants
        List<Plants> newPlants = new ArrayList<>();        
         // Let all plants act.
        for(Iterator<Plants> it = plants.iterator(); it.hasNext(); ) {
            Plants plant = it.next();
            plant.grow(newPlants);
            if(! plant.isAlive()) {
                 it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        //add new plants
        plants.addAll(newPlants);


        //update terrain atrributes
        field.FieldUpdate();

        //view.showStatus(step, field);
        return field;
        
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public Field reset()
    {
        //step = 0;
        animals.clear();
        plants.clear();
        populate();
        // reset back to spring
        field.FieldUpdate(0,0);
        
        // Show the starting state in the view.
        //view.showStatus(step, field);
        return field;
    }
    
    /**
     * Randomly populate the field with the animals and plants
     */
    private void populate()
    {

        // plants
        BerryPlant plant1 = new BerryPlant();
        MountainFlower plant2 = new MountainFlower();


        Random rand = Randomizer.getRandom();
        
        field.clear();
        //reset terrain
        field.setTerrain();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(field, location);
                    animals.add(hyena);
                }
                else if(rand.nextDouble() <= WARTHOG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Warthog warthog = new Warthog(field, location);
                    animals.add(warthog);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= MEERKAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Meerkat meerkat = new Meerkat(field, location);
                    animals.add(meerkat);
                }
                else if(rand.nextDouble() <= INSECT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Insect insect = new Insect(field, location);
                    animals.add(insect);
                }
                if(plant1.canGrow(new Location(row,col), field) && rand.nextDouble()<=BERRYPLANT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    BerryPlant plant = new BerryPlant(location, field);
                    plant.setToEat();
                    plants.add(plant);
                }
                if(plant2.canGrow(new Location(row,col), field) && rand.nextDouble()<=MOUNTAINFLOWER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    MountainFlower plant = new MountainFlower(location, field);
                    plant.setToEat();
                    plants.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    public void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            System.err.println("Issue here");
        }
    }

/**
 * randomly gives an animal a new virus
 * very low probability each step
 * @param animal animal that gets the virus
 */
    private void generateVirus(Animal animal)
    {
        double random = Math.random();
        if(random < 0.000005)
        {
            Virus virus = new Virus();
            animal.addVirus(virus);
        }
    }
}
