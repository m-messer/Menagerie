import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.awt.*;


/**
 * Majority of the non-changing data during simulation,
 * that can be accessed easily
 *
 * @version 2022.03.01
 */
public class Config {

    //plants

    // amount of steps to fully grow decrement every step.
    // when grown to eat is true and stop growing
    private static HashMap<Class<?extends Plants>, double[]>PlantStuff = new HashMap<Class<?extends Plants>, double[]>();
    private static HashMap<Class<?extends Plants>, String>PlantNames= new HashMap<Class<?extends Plants>, String>();


    //animal
    private static HashMap<Class<?extends Animal>, double[]>AnimalStuff= new HashMap<Class<?extends Animal>, double[]>();
    private static HashMap<Class<?extends Animal>, String>AnimalNames= new HashMap<Class<?extends Animal>, String>();

    //colours
    private static HashMap<Class<?>, Color> colors = new HashMap<Class<?>,Color>();
    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    //earth data
    private static double[] Earth = new double[5];


    //profiles so if the data is to be changes. its stored here then changed
    private  HashMap<Class<?extends Plants>, double[]>PlantStuffProfile1;
    //animal
    private  HashMap<Class<?extends Animal>, double[]>AnimalStuffProfile1;
    //coulurs
    private HashMap<Class<?>, Color> colorsProfile1;
    //earth
    private double[] EarthProfile1;




    public Config(){
        PlantStuffProfile1 = PlantStuff;
        AnimalStuffProfile1 = AnimalStuff;
        colorsProfile1 = colors;
        EarthProfile1 = Earth;
    }


    public static void ConfigSet(){

        //plants stuff goes in order::     

        // amount of steps to fully grow decrement every step.
        // when grown to eat is true and stop growing
        //private int Growth_steps;

        // the min height the plant can grow at
        //private int MinElevation;

        // the max height the plant can grow at
        //private int MaxElevation;

        // the min light it needs to grow
        //private int Light_to_grow;

        // the min amount of water for plant to grow
        //private int Water_to_grow;

        // the min amount of animals that can trample on it before death
        //private int resiliencePoints;

        // max area to spread seeds
        //private int radius;

        //chance to grow


        //private double chance_to_grow;
        

        //value gained when eaten
        //private static final int PLANT_FOOD_VALUE = 5;


        PlantStuff.put(BerryPlant.class,new double[] {2,1,1,3,0,4,3,0.5,10});
        PlantNames.put(BerryPlant.class,"BerryPlant");
        PlantStuff.put(MountainFlower.class,new double[] {3,2,3,4,0,6,4,0.8,15});
        PlantNames.put(MountainFlower.class,"MountainFlower");



        //animals, stuff in this order

        // The age at which the animal can start to breed.
        // private static Integer BREEDING_AGE;

        // The age to which the animal can live.
        //private static Integer MAX_AGE;

        // The likelihood of the animal breeding.
        // private static Double BREEDING_PROBABILITY;

        // The maximum number of births.
        // private static  Integer MAX_LITTER_SIZE;

        //The time at which the animal sleeps
        //private static Integer SLEEP_TIME;

        //The value gained when another animal eats
        //public static final int foodvalue

        //The value till animal is full
        //public static final int hunger value


        AnimalStuff.put(Warthog.class,new double[] {3,60,0.09,4,3,40,50});
        AnimalNames.put(Warthog.class,"Warthog");
        AnimalStuff.put(Meerkat.class,new double[] {4,60,0.1,2,3,40,60});
        AnimalNames.put(Meerkat.class,"Meerkat");
        AnimalStuff.put(Hyena.class,new double[] {6,70,0.13,2,3,25,100});
        AnimalNames.put(Hyena.class,"Hyena");
        AnimalStuff.put(Insect.class,new double[] {3,80,0.1,2,3,20,50});
        AnimalNames.put(Insect.class,"Insect");
        AnimalStuff.put(Lion.class,new double[] {8,100,0.15,2,3,30,100});
        AnimalNames.put(Lion.class,"Lion");




     //colors
        colors.put(BerryPlant.class, Color.MAGENTA);
        colors.put(MountainFlower.class, Color.BLUE);

        colors.put(Meerkat.class, Color.GREEN);
        colors.put(Warthog.class, Color.ORANGE);
        colors.put(Hyena.class, Color.RED);
        colors.put(Lion.class, Color.BLACK);
        colors.put(Insect.class, Color.pink);

     //Earth
     Earth[0] = 5.0;
     Earth[1] = 0.1;   
     Earth[2] = 3.0;   
     Earth[3] =0.06;
     Earth[4] =0.02;      
      
     
     




    }
    
    // get methods for each element in the hashmaps

    public static int getGrowthSteps(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[0];
    }
    public static int getMinElevation(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[1];
    }
    public static int getMaxElevation(Class<? extends Plants> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[2];
    }
    public static int getLightToGrow(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[3];
    }
    public static int getWaterToGrow(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[4];
    }
    public static int getResiliencePoints(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[5];
    }
    public static int getRadius(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[6];
    }
    public static double getChanceToGrow(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return temp[7];
    }

    public static int getPlantFoodValue(Class<?> classToGet){
        double[] temp;
        temp = PlantStuff.get(classToGet);
        return (int)temp[8];
    }

    public static int getBreedingAge(Class<?> classToGet){

        double[] temp;
        temp = AnimalStuff.get(classToGet);
        return (int)temp[0];

    }

    public static int getMaxAge(Class<?> classToGet){

        double[] temp;
        temp = AnimalStuff.get(classToGet);
        return (int)temp[1];
        
    }

    public static double getBreedingProability(Class<?> classToGet){

        double[] temp;
        temp = AnimalStuff.get(classToGet);
        return temp[2];
        
    }

    public static int getMaxLitterSize(Class<?> classToGet){

        double[] temp;
        temp = AnimalStuff.get(classToGet);
        return (int)temp[3];
        
    }

    public static int getSleepTime(Class<?> classToGet){

        double[] temp;
        temp = AnimalStuff.get(classToGet);
        return (int)temp[4];
        
    }

    public static int getAnimalFoodValue(Class<?> classToGet){

        double[] temp;
        temp = AnimalStuff.get(classToGet);
        return (int)temp[5];
        
    }

    public static int getHungerValue(Class<?> classToGet){

        double[] temp;
        temp = AnimalStuff.get(classToGet);
        return (int)temp[6];
        
    }

    public static List<Class<?extends Animal>> getAnimalClasses(){

        List<Class<?extends Animal>> temp = new ArrayList<Class<?extends Animal>>();
        for(Class<?extends Animal> key:AnimalNames.keySet()){
            temp.add(key);
        }

        return temp;

    }

    public static List<Class<?extends Plants>> getPlantClasses(){

        List<Class<?extends Plants>> temp = new ArrayList<Class<?extends Plants>>();
        for(Class<?extends Plants> key:PlantNames.keySet()){
            temp.add(key);
        }

        return temp;

    }

    public static String getPlantNames(Class x){

        return PlantNames.get(x);

    }

    public static String getAnimalNames(Class x){
        return AnimalNames.get(x);
    }

        //colours
    /**
     * @return The color to be used for a given class of animal/plant.
     */
    public static Color getColor(Class subjectClass)
    {
        Color col = colors.get(subjectClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    //earth

    /**
     *  @return the Days in a season.
     */
    public static int getDaysPerSeaoson(){

        return (int)Earth[0];
    }

    /**
     * @return The chance for snowfall
     */
    public static double getSnowChance(){

        return Earth[1];
    }

    /**
     * @return The maximum elevation
     */
    public static int getGetMaxEarthElevation(){

        return (int)Earth[2];
    }

    /**
     * @return The double value for the probability of a cliff
     */
    public static double getMaxCliffChance(){

        return Earth[3];
    }

    
    /**
     * @return The double value for the probability of water
     */
    public static double getWaterChance(){
        return Earth[4];
    }



    // changing the values in the hashmap

    public void animalChange(Class<? extends Animal> classToGet, double[] changes){
        AnimalStuffProfile1.remove(classToGet);
        AnimalStuffProfile1.put(classToGet,changes);
    }

    public void plantChange(Class classToGet, double[] changes){
        PlantStuffProfile1.remove(classToGet);
        PlantStuffProfile1.put(classToGet,changes);
    }

    public void earthChange( double[] changes){
        EarthProfile1 = changes;
    }

    /**
     * Define a color to be used for a given class of animal.
     * @param class animal or plant Class object.
     * @param color The color to be used for the given class.
     */
    public void colorChange(Class object, Color color)
    {
        colorsProfile1.remove(object);
        colorsProfile1.put(object, color);
        
    }

    public void commit(){
        AnimalStuff = AnimalStuffProfile1;
        PlantStuff = PlantStuffProfile1;
        Earth = EarthProfile1;
        colors = colorsProfile1;
    }




}



