//imports
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of Plants
 *
 * @version 2022.03.01
 */
public abstract class Plants {

    //random variable 
    private Random rand = new Random();
    // check if plant alive
    private boolean Alive = true;
    // the field that the plant can be put in
    private Field field;
    // The plants position in the field.
    private Location location;
    // the resilience to trampling and weather integer
    private int Resilience_points;
    // if plant ready to eat
    private boolean canEat;
    //steps remaining before fully grown
    private int growthSteps;
    // class so can get data from config
    Class<? extends Plants> PlantType;  

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */

    public Plants(Field field_m,Location location_m, Class<? extends Plants>PlantType_m){



        this.field = field_m; 
        this.location = location_m;
        this.PlantType = PlantType_m;
        Resilience_points = Config.getResiliencePoints(PlantType);
        growthSteps = Config.getGrowthSteps(PlantType);;
        canEat = false;

        if (field != null){
        setLocation(location);// plants dont move
        }

    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The animal's new location.
     * @return if the plant was placed if not cant be placed there
     */
    protected boolean setLocation(Location newLocation)
    {
        if(location == null) {
            return false;
        }
        field.placePlant(this, newLocation);
        return true;
    }


    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        Alive = false;
        if(location != null) {
            field.clearPlant(location);
            location = null;
            field = null;
        }
    }

    //set classes

    /** 
     * this function will randomly set if the plant is ready to be eaten
     * 
    */
    public void setToEat(){
        int x = rand.nextInt(10);
        if(x>4){
            canEat = true;
        } 
        else{
            canEat = false;
        }
       
    }

    /**
     * checks if the plant is alive
     * @return true if plant is alive
     */
    public boolean isAlive(){
        return Alive;
    }

    // get and increment functions classes
    // getting the information for the particular plant from config

    public int getMinElevation(){

        return Config.getMinElevation(PlantType);
    }

    public int getMaxElevation(){

        return Config.getMaxElevation(PlantType);
    }

    public int getLight_to_grow(){

        return Config.getLightToGrow(PlantType);
    }

    public int getWater_to_grow(){

        return Config.getWaterToGrow(PlantType);
    }

    /**
     * @return resilience points of plant
     */
    public int getResiliancePoints(){

        return Resilience_points;
    }

    /**
     * decreases resilience by 1
     */
    private void decreaseResiliencePoints(){

        Resilience_points--;
    }

    /**
     * @return if it can be eaten
     */
    public boolean canEat(){

        return canEat;
    }

    /**
     * @return steps to fully grow
     */
    public int getGrowthSteps(){

        return growthSteps;
    }

    public int getFoodValue(){
        return Config.getPlantFoodValue(PlantType);
    }

    public double getChanceToGrow(){
        return Config.getChanceToGrow(PlantType);
    }

    public int getLightToGrow(){
        return Config.getLightToGrow(PlantType);
    }

    public int getRadius(){
        return Config.getRadius(PlantType);
    }


    /**
     * Checks if the plant can grow in this location
     * @param location the location to check
     * @param field the field that is checked
     * @return true if the plant can grow here
     */
    public boolean canGrow(Location location, Field field){

        Terrain earth = field.getTerrainAt(location);

        if(earth.getElevation() <= getMaxElevation() && earth.getElevation() >= getMinElevation() && earth.getWaterToGrow() >= getWater_to_grow()){

            return true;
        }

        return false;
    }

    /**
     * growth common to all plants
     * if it grown, it has a chance to spread seeds
     * if it is not grown, it grows
     * snow and trampling decrease resilience
     * if resilience is 0, it dies
     * @param newPlants list of new plants added to the field
     */
    public void commonGrowth(List<Plants> newPlants){

        if(Alive)
        {
            if(canEat){
                if(rand.nextDouble() <= getChanceToGrow()){
                    seed(newPlants);
                }
            }
            else{
                if (field.getTerrainAt(location).getElevation() < getLightToGrow()){
                    growthSteps--;
                    if (growthSteps<=0){
                        canEat = true;
                    }
                }
            }

            if(field.getAnimalAt(location) != null || field.getTerrainAt(location).getSnow()){
            
                decreaseResiliencePoints();

            }

            if(Resilience_points < 0){
                setDead();
            }
        }
    }

    /**
     * spreading seeds to the surrounding
     * seeds are spread randomly in a radius
     * if the space is empty and environment suitable
     * the seeds may grow
     * @param newPlants the list of new plants to be added to field
     */
    public void seed(List<Plants> newPlants){

        int x = location.getCol();
        int y = location.getRow();

        x = x-getRadius();
        y = y-getRadius();


        // this random is how many boxes the seed will spread in the area
        int rand1 = rand.nextInt((getRadius()*2)^2);
        int rand2 = rand.nextInt(getRadius()*2);
        int rand3 = rand.nextInt(getRadius()*2);

        // check if plant in that area and place

        for (int i = 0; i<rand1;i++){

            while((x+rand2) < 0 || (x+rand2) > (field.getWidth()-1)){

                rand2 = rand.nextInt(getRadius()*2);
            }

            while((y+rand3) < 0 || (y+rand3) > (field.getDepth()-1)){
                rand3 = rand.nextInt(getRadius()*2);
            }


            Location location = new Location(rand3+y,rand2+x);
            // checks if plant is in that area and if it can grow
            if(field.getPlantAt(rand3+y,rand2+x) == null && canGrow(location,field)){
                Plants temp = MakeNewPlant(location,field);
                field.placePlant(temp, location);

                newPlants.add(temp);
            }
            else{}

            // re random int
            rand2 = rand.nextInt(getRadius()*2);
            rand3 = rand.nextInt(getRadius()*2);
        }
    }

    // abstract classes

    public abstract void grow(List<Plants> newPlants);

    public abstract void Eaten();

    public abstract Plants MakeNewPlant(Location location_m,Field field_m);


    
    
}
