import java.util.ArrayList;

/**
 * Model of a Lion
 * They can move, eat, reproduce, get infected, and die
 * they eat warthogs and meerkats
 * they all share one genetic value : 3
 *
 * @version 2022.03.01
 */
public class Lion extends Animal
{

    //An array of classes that the animal eats
    private static ArrayList<Class<?>> ANIMAL_EATS = new ArrayList<Class<?>>();
    static{
        ArrayList<Class<?>> tmp = new ArrayList<Class<?>>();
        tmp.add(Warthog.class);
        tmp.add(Meerkat.class);
        ANIMAL_EATS = tmp;
    }

    // The animals own genetic values
    // always contains one value specific to this particular animal
    private ArrayList<Integer> genetics = new ArrayList<>();

    /**
     * Constructor
     * Creates a lion with random values
     * adds genetic code 3
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(Field field, Location location)
    {
        super(field, location,Lion.class);
        genetics.add(3);
        super.populateGenetics();
    }

    /**
     * second Constructor: needed as it takes
     * parents as parameters
     * Creates a lion as offspring
     * adds genetic code 3
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    public Lion(Field field, Location location, Animal parent1, Animal parent2)
    {
        super(field, location,Lion.class, parent1, parent2);
        genetics.add(3);
        super.populateGenetics();
    }

    /**
     * Creates and returns lion as offspring
     * needed to create specific animals in Animal class
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    protected Animal newAnimal(Field field,Location loc, Animal parent1, Animal parent2)
    {
        return new Lion(field, loc, parent1, parent2);
    }

    /**
     * gets the arraylist of classes the Lion eats
     * @return arraylist of type class
     */
    protected ArrayList<Class<?>> getEats()
    {
        return ANIMAL_EATS;
    }
    
    /**
     * adds inputted number into genetics list
     * @param number the value that is added
     */
    protected void addGenetics(int number)
    {
        genetics.add(number);
    }
    
    /**
     * gets the arraylist of genetics for this animal
     * each value in genetics is an integer
     */
    protected ArrayList<Integer> getGenetics()
    {
        return genetics;
    }
}
