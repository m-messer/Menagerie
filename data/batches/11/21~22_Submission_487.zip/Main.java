
/**
 * this class is just to start the simulation
 * without blueJ
 *
 * @version 2022.03.01
 */
public class Main {
    

    public static void main(String[] args){

        App test = new App(100);

    }
} 
