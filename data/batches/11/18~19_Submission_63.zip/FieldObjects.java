import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Class for ALL objects which can exist on the field.
 * It contains age, weather it has a disease, steps before death,
 * weather it's alive, it's current field and location
 *
 * @version 2018.02.19
 */
public abstract class FieldObjects
{
    // Whether the fieldobject is alive or not.
    private boolean alive;
    // The fieldobject's field.
    private Field field;
    // The fieldobject's position in the field.
    private Location location;
    // The probabilty of an fieldobject catchinga disease
    private static final double DISEASE_PROBABILITY = 0.01;
    // The probability of the disease spreadding to nearby fieldobjects
    private static final double DISEASE_SPREADING_PROBABILITY = 0.01;
    // The number of steps left befire dying of a disease
    private int stepsLeft;
    // Whether the fieldobject has the disease or not
    private boolean hasDisease;
    //age of each object
    private int age;

    /**
     * Constructor for objects of class FieldObjects
     */
    public FieldObjects(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        stepsLeft = 250;
        
        Random rand= new Random();
        // The probability of the fieldobject getting a disease      
        if(rand.nextDouble() < DISEASE_PROBABILITY) {
            hasDisease = true;
        }
        else {
            hasDisease = false;
        }
    }

    /**
     * Make this fieldobject act - that is: make it do
     * whatever it wants/needs to do.
     * @param newfieldobjects A list to receive newly born fieldobjects.
     */
    abstract public void act(List<FieldObjects> newObjects,int timeOfDay);

    /**
     * Check whether the fieldobject is alive or not.
     * @return true if the fieldobject is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the fieldobject is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the fieldobject's location.
     * @return The fieldobject's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the fieldobject at the new location in the given field.
     * @param newLocation The fieldobject's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Returns if the fieldobject has the disease
     * @return hasDisease True if the fieldobject has the disease
     */
    public boolean getHasDisease()
    {
        return hasDisease;
    }

    /**
     * Sets the disease  of the fieldobject
     * @param disease Set to true if the fieldobject has disease
     */
    private void setHasDisease(boolean disease)
    {
        hasDisease=disease;
    }

    /**
     * Return the fieldobject's field.
     * @return The fieldobject's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * An infected fieldobject spreads the disease to all the
     * fieldobjects nearby.
     */
    protected void spreadDisease()
    {
        Random rand = new Random();
        if(hasDisease && rand.nextDouble() < DISEASE_SPREADING_PROBABILITY && isAlive())
        {
            //list of all the free locations near the fieldobject
            List<Location> nearLocations = this.field.adjacentLocations(getLocation());
            //list of all the free locations
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            //removing all the free locations from the nearby locations
            nearLocations.removeAll(free);
            //list of all the objects at those locations
            List<FieldObjects> fieldObjects = new ArrayList<FieldObjects>();
            for(int i=0; i < nearLocations.size(); i++){
                fieldObjects.add((FieldObjects)field.getObjectAt(nearLocations.get(i)));
            }
            // if the nearby object does not have the disease, the disease is spread
            for(FieldObjects fieldObject:fieldObjects){
                if(!fieldObject.getHasDisease())
                {
                    fieldObject.setHasDisease(true);
                    return;
                }
            }
        }
    }

    /**
     * Decreases the number of steps left before it
     * dies of disease and if it reaches 0, it kills the organism
     */
    protected void checkIfDeathByDisease()
    {
        if(hasDisease)
        {
            stepsLeft--;
        }

        if(stepsLeft <= 0)
        {
            this.setDead();
        }
    }

        
    /**
     * Returns the age of the fieldobject
     * @return age of the fieldobject
     */
    protected int getAge() {
        return age;
    }

    /**
     * sets the age of the fieldobject
     * @param age the age of the fieldobject
     */
    protected void setAge(int age) {
        this.age = age;
    }

    /**
     * Increase the age. This could result in the orca's death.
     */
    protected void incrementAge() {
        age++;
    }
    

    
}
