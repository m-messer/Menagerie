import java.util.List;
import java.util.Iterator;
/**
 * A simple model of a class of all the plant 
 * eaters in the ocean. Plant eaters look for
 * plants nearby.
 *
 * @version 19.02.2019
 */
public abstract class PlantEater extends Eater
{
    /**
     *Constructor for objects of class PlantEater
     */ 
    public PlantEater(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Look for plants animals can eat and is adjacent to the current location.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);

            if(object instanceof Plant) {
                Plant plant = (Plant)object;
                if(plant.isAlive()) { 
                    plant.setDead();
                    return where;
                }
            }
        }

        return null;
    }
}
