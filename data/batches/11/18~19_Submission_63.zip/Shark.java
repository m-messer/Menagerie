
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a shark.
 * Sharks age, breed, catch disease, move, eat nemos,dory and dolphin, and can die.
 *
 * @version 2019.02.08
 */
public class Shark extends Eater{
    // Characteristics shared by all sharkes (class variables).

    // The age at which a shark can start to breed.
    private static final int BREEDING_AGE = 1000;
    // The age to which a shark can live.
    private static final int MAX_AGE = 219000;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The amount it's food level increases by when it eats a nemo
    private static final int NEMO_FOOD_VALUE = 5;
    // The amount it's food level increases by when it eats a dory
    private static final int DORY_FOOD_VALUE = 5;
    // The amount it's food level increases by when it eats a dolphin
    private static final int DOLPHIN_FOOD_VALUE = 9;
    // The maximum health of the shark
    private static final int MAX_HEALTH = 4000;
    //The default probabilty of fieldobjects breeding
    private static double defaultBreedingProbability ;
    // Current breeding probability of the animal
    private static double breedingProbability;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Create a Shark. A shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the shark will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shark(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(MAX_HEALTH));
        }
        else {
            setAge(0);
            setFoodLevel( MAX_HEALTH);
        }
        
       setBreedingProbability(getDefaultBreedingProbability());
    }

    /**
     * This is what the shark does most of the time: it hunts for
     * nemos. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSharkes A list to return newly born sharkes.
     */
    public void act(List<FieldObjects> newSharkes, int timeOfDay)
    {
        incrementAge();
        if(getFoodLevel() == MAX_HEALTH) { setBreedingProbability(getBreedingProbability()*2); }
        if(getAge() > MAX_AGE) {setDead();}
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSharkes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
        }
    }

    /**
     * Look for animals the shark can eat and is adjacent to the current location.
     * Finds the biggest animal first then eats them.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);

            if(animal instanceof Dolphin) {
                Dolphin dolphin = (Dolphin) animal;
                if(dolphin.isAlive()) { 
                    dolphin.setDead();
                    setFoodLevel (getFoodLevel() + DOLPHIN_FOOD_VALUE);
                    if(getFoodLevel() > MAX_HEALTH)
                    {
                        setFoodLevel (MAX_HEALTH);
                    }
                    return where;
                }
            }
            else if(animal instanceof Nemo) {
                Nemo nemo = (Nemo) animal;
                if(nemo.isAlive()) { 
                    nemo.setDead();
                    setFoodLevel (getFoodLevel() + NEMO_FOOD_VALUE);
                    if(getFoodLevel() > MAX_HEALTH)
                    {
                        setFoodLevel (MAX_HEALTH);
                    }
                    return where;
                }
            }
            else if(animal instanceof Dory) {
                Dory dory= (Dory) animal;
                if(dory.isAlive()) { 
                    dory.setDead();
                    setFoodLevel (getFoodLevel() + DORY_FOOD_VALUE);
                    if(getFoodLevel() > MAX_HEALTH)
                    {
                        setFoodLevel (MAX_HEALTH);
                    }
                    return where;
                }
            }
        }

        return null;
    }

    /**
     * Check whether or not this shark is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSharkes A list to return newly born sharkes.
     */
    private void giveBirth(List<FieldObjects> newSharkes)
    {
        // New sharkes are born into adjacent locations.
        // Get a list of adjacent free locations
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Shark young = new Shark(false, field, loc);
            newSharkes.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A shark can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }

    /**
     * Return the breeding probability of the fieldobjects
     * @return the probabilty of the fieldobject breeding
     */
    public static double getBreedingProbability() 
    {
        return breedingProbability;
    }

    /**
     * Change the breeding probability of a fieldobject
     * @param newProbabilty The new breeding probabilty
     */
    public static void setBreedingProbability(double newProbability)
    {
        breedingProbability = newProbability;
    }

    /**
     * Return te default breeding probability
     * @return defaultBreedingProbability returns the probability
     */
    public static double getDefaultBreedingProbability()
    {
        return defaultBreedingProbability;
    }

    /**
     * Change the default breeding probability of a fieldobject
     * @param newDefaultProbabilty The new default breeding probabilty
     */
    public static void setDefaultBreedingProbability(double newDefaultProbability)
    {
        defaultBreedingProbability = newDefaultProbability;
    }
    
}
