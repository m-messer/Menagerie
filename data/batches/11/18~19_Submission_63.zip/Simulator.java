import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing nemos, dorys, dolphins, blue whales, orcas, sharks and plants.
 *
 * @version 2019.02.08
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a shark will be created in any given grid position.
    private static final double DEFAULT_SHARK_CREATION_PROBABILITY = 0.0005;

    // The probability that a orca will be created in any given grid position.
    private static final double DEFAULT_ORCA_CREATION_PROBABILITY = 0.001;

    // The probability that a nemo will be created in any given grid position.
    private static final double DEFAULT_NEMO_CREATION_PROBABILITY = 0.01;

    // The probability that a dory will be created in any given grid position.
    private static final double DEFAULT_DORY_CREATION_PROBABILITY = 0.01;

    // The probability that a dolphin will be created in any given grid position.
    private static final double DEFAULT_DOLPHIN_CREATION_PROBABILITY = 0.005;

    // The probability that a blue whale will be created in any given grid position.
    private static final double DEFAULT_BLUEWHALE_CREATION_PROBABILITY = 0.00125;

    // The probability that a plant will be created in any given grid position.
    private static final double DEFAULT_PLANT_CREATION_PROBABILITY = 0.04;

    // The weather characteristics for the simulator
    private static boolean highTemperature, highCurrent, highGarbage;
    // List of fieldObjects in the field.
    private List<FieldObjects> fieldObjects;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with the default size and with pre-determined breeding probabilities
     */

    public Simulator() {

        this(0.6,0.6, 0.0015, 0.00075, 0.003, 0.0025, 0.15);
    }

    /**
     * Construct a simulation field with default size and with the parsed in breeding probability values
     */
    public Simulator(double nemoBreedingProb, double doryBreedingProb, double dolphinBreedingProb, double blueWhaleBreedingProb, double orcaBreedingProb, double sharkBreedingProb, double plantBreedingProb) {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH, nemoBreedingProb,  doryBreedingProb, dolphinBreedingProb,  blueWhaleBreedingProb, orcaBreedingProb, sharkBreedingProb, plantBreedingProb);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width, double nemoBreedingProb,  double doryBreedingProb, double dolphinBreedingProb,  double blueWhaleBreedingProb, double orcaBreedingProb, double sharkBreedingProb, double plantBreedingProb)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        fieldObjects = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        Nemo.setDefaultBreedingProbability(nemoBreedingProb);
        Dory.setDefaultBreedingProbability(doryBreedingProb);
        Dolphin.setDefaultBreedingProbability(dolphinBreedingProb);
        BlueWhale.setDefaultBreedingProbability(blueWhaleBreedingProb);
        Orca.setDefaultBreedingProbability(orcaBreedingProb);
        Shark.setDefaultBreedingProbability(sharkBreedingProb);
        Plant.setDefaultBreedingProbability(plantBreedingProb);

        view.setColor(Nemo.class, new Color(255, 165, 0), Color.RED);
        view.setColor(Shark.class, new Color(215, 216, 224), Color.RED);
        view.setColor(Dory.class, new Color(153, 181, 255), Color.RED);
        view.setColor(Dolphin.class, new Color(249, 154, 216), Color.RED);
        view.setColor(Orca.class, Color.BLACK, Color.RED);
        view.setColor(BlueWhale.class, new Color(124, 249, 243), Color.RED);
        view.setColor(Plant.class, new Color(103, 239, 125), Color.RED);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state until
     * one of the species dies out.
     *
     *  The method will return the organism that died.
     *  It returns 0 for plant, 1 for nemo, 2 for dory, 3 for dolphin, 4 for blue whale
     *  5 for orca, and 6 for shark
     *
     * @return the numerical value for the animal that died first in the simulation
     */
    public int runLongSimulation()
    {
        int returnInt = -1;

        while(returnInt == -1) {
            returnInt = simulateOneStep();
        }
        
        return returnInt;      
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     *
     * If the step is a multiple of 500, then the weather is randomised
     *
     * The method will return the organism that died.
     * It returns 0 for plant, 1 for nemo, 2 for dory, 3 for dolphin, 4 for blue whale
     * 5 for orca, and 6 for shark
     *
     * @return the numerical value for the animal that died first in the simulation
     */
    public int simulateOneStep()
    {   step++;

        int timeOfDay=step%24;
        //It is night time
        if(timeOfDay<6 || timeOfDay>18) {
            view.changeColorForDay(false);
        }
        else {
            view.changeColorForDay(true);
        }

        // Provide space for newborn fieldObjects.
        List<FieldObjects> newFieldObjects = new ArrayList<>();        
        // Let all fieldObjects act.
        for(Iterator<FieldObjects> it = fieldObjects.iterator(); it.hasNext(); ) {
            FieldObjects fieldObject = it.next();
            fieldObject.act(newFieldObjects, timeOfDay);
            // check if the animal has the disease and spreads the disease
            // Kills the organism if needed and spreads the disease if to other organism if it still have disease
            fieldObject.checkIfDeathByDisease();
            fieldObject.spreadDisease();
            //Removes all dead animals from field
            if(! fieldObject.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born fieldObjects to the main lists.
        fieldObjects.addAll(newFieldObjects);

        view.showStatus(step, field);

        // Every 500 steps, the weather is evaluated
        if(step%500 == 0)
        {
            Random randomWeatherGenerator = new Random();

            // Randomise weather
            highCurrent = randomWeatherGenerator.nextBoolean();
            highTemperature = randomWeatherGenerator.nextBoolean();
            highGarbage = randomWeatherGenerator.nextBoolean();

            //Reset all probabilites to be correctly evaluated
            Shark.setBreedingProbability(Shark.getDefaultBreedingProbability());
            Orca.setBreedingProbability(Orca.getDefaultBreedingProbability());
            Dolphin.setBreedingProbability(Dolphin.getDefaultBreedingProbability());
            Nemo.setBreedingProbability(Nemo.getDefaultBreedingProbability());
            Dory.setBreedingProbability(Dory.getDefaultBreedingProbability());
            BlueWhale.setBreedingProbability(BlueWhale.getDefaultBreedingProbability());
            Plant.setBreedingProbability(Plant.getDefaultBreedingProbability());

            //Add effects of weather
            if(highCurrent)
            {
                Nemo.setBreedingProbability(Nemo.getBreedingProbability()/2);
                Dory.setBreedingProbability(Dory.getBreedingProbability()/2);
                Plant.setBreedingProbability(Plant.getBreedingProbability()/2.5);
            }
            if(highTemperature)
            {
                Orca.setBreedingProbability(Orca.getBreedingProbability()*1.5);
                Plant.setBreedingProbability(Plant.getBreedingProbability()*2);
                Dolphin.setBreedingProbability(Dolphin.getBreedingProbability()*1.5);
            }
            if(highGarbage)
            {
                Shark.setBreedingProbability(Shark.getBreedingProbability()/5);
                Dolphin.setBreedingProbability(Dolphin.getBreedingProbability()/5);
                Orca.setBreedingProbability(Orca.getBreedingProbability()/5);
                Nemo.setBreedingProbability(Nemo.getBreedingProbability()/5);
                Dory.setBreedingProbability(Dory.getBreedingProbability()/5);
                BlueWhale.setBreedingProbability(BlueWhale.getBreedingProbability()/5);
                Plant.setBreedingProbability(Plant.getBreedingProbability()/5);
            }

            System.out.println("-----Weather report -----\nHigh currents sweeping away Nemo, Dory and uprooting plants: " + highCurrent + "\nHigh temperatures of water encouraging Orca, dolphin and plant growth: " + highTemperature + "\nHigh garbage in the ocean making all animals breed less: " + highGarbage);
            
        }
        if(view.getStats().getCountOf("Plant") <= 0) {
            System.out.println("Plant is low!");
            return 0;
        }
        else if (view.getStats().getCountOf("Nemo") <= 0){
            System.out.println("Nemo is low!");
            return 1;
        }
        else if ( view.getStats().getCountOf("Dory") <= 0){
            System.out.println("Dory is low!");
            return 2;
        }
        else if ( view.getStats().getCountOf("Dolphin") <= 0){
            System.out.println("Dolphin is low!");
            return 3;
        }
        else if ( view.getStats().getCountOf("BlueWhale") <= 0){
            System.out.println("Blue Whale is low!");
            return 4;
        }
        else if ( view.getStats().getCountOf("Orca") <= 0){
            System.out.println("Orca is low!");
            return 5;
        }
        else if ( view.getStats().getCountOf("Shark") <= 0){
            System.out.println("Shark is low!");
            return 6;
        }
        else {return -1;}

        
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        fieldObjects.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with fieldObjects.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= DEFAULT_NEMO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Nemo nemo = new Nemo(true, field, location);
                    fieldObjects.add(nemo);
                }
                else if(rand.nextDouble() <= DEFAULT_DORY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dory dory = new Dory(true, field, location);
                    fieldObjects.add(dory);
                }
                else if(rand.nextDouble() <= DEFAULT_DOLPHIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dolphin dolphin = new Dolphin(true, field, location);
                    fieldObjects.add(dolphin);
                }
                else if(rand.nextDouble() <= DEFAULT_BLUEWHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    BlueWhale blueWhale = new BlueWhale(true, field, location);
                    fieldObjects.add((FieldObjects)blueWhale);
                }
                else if(rand.nextDouble() <= DEFAULT_SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    fieldObjects.add(shark);
                }
                else if(rand.nextDouble() <= DEFAULT_ORCA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Orca orca = new Orca(true, field, location);
                    fieldObjects.add(orca);
                }
                else if(rand.nextDouble() <= DEFAULT_PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    fieldObjects.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    public int getStep() {
        return step;
    }
}

