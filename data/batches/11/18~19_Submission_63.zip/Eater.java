
/**
 * 
 * This ia a class of all the animals
 * that feed on other animals or plants. This 
 * class allows them to look for food and increases their 
 * food level every time they feed on something.
 *
 * @version 2019.02.19
 */
public abstract class Eater extends FieldObjects
{
    private int foodLevel;

    /**
     * Constructor for objects of class Eater.
     */
    public Eater(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Return the foodlevel of the animal
     * @return foodLevel the foof value of the animal
     */
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Sets the food level of the animal
     * @param foodLevel the new food level of the animal
     */
     protected void setFoodLevel(int foodLevel) {
     this.foodLevel = foodLevel;
    }
    
    /**
     * An abstarct clas to find food
     */
    abstract protected Location findFood();

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        int foodLevel = getFoodLevel();
        setFoodLevel(foodLevel -1);
        if(foodLevel <= 0) {
            setDead();
        }
    }

}
