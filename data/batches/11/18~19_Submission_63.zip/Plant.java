import java.util.List;
import java.util.Random;

/**
 * A simple model of a plant.
 * Plants  age, catch disease, breed, and die.
 *
 * @version 2019.02.19
 */
public class Plant extends FieldObjects
{

    // The age to which a dory can live.
    private static final int MAX_AGE = 50;

    //The default probabilty of fieldobjects breeding
    private static double defaultBreedingProbability ;

    private static double breedingProbability;

    //The amount of energy gained by eating a plant
    private static final int PLANT_VALUE = 5;

    /**
     * Constructor for objects of class Plants
     */
    public Plant(Field field, Location location)
    {
        super(field , location);

        setBreedingProbability(getDefaultBreedingProbability());
    }

    /**
     *  This is what the plant does most of the time -Plants 
     *  cannot move. Sometimes it will breed or die of old age
     *  or a disease.
     *  It exhibits different behaviour during different during 
     *  day and night.
     *  @param newPlants A list of the newly born plants
     *  @param timeOfDay the current time 
     */
    public void act(List<FieldObjects> newPlants,int timeOfDay)
    {
        incrementAge();
        if(getAge() > MAX_AGE || getHasDisease()) {
            setDead();
        }
        // different behaviour at different times of the day
        if(isAlive() && timeOfDay>6 && timeOfDay<18) {
            giveBirth(newPlants);
        }
    }

    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born Plants.
     */
    private void giveBirth(List<FieldObjects> newPlants)
    {
        // New Plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant youngPlants = new Plant(field, loc);
            newPlants.add(youngPlants);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        Random rand = new Random();

        int births = 0;
        if(rand.nextDouble() <= getBreedingProbability() && !getHasDisease()) {
            births = rand.nextInt(9) + 1;
        }
        return births;
    }

    /**
     * Return the plant food value
     * @return food value of the plant
     */
    public static int getPlantFoodValue()
    {
        return PLANT_VALUE;
    }

    /**
     * Return the breeding probability of the fieldobjects
     * @return the probabilty of the fieldobject breeding
     */
    public static double getBreedingProbability() 
    {
        return breedingProbability;
    }

    /**
     * Change the breeding probability of a fieldobject
     * @param newProbabilty The new breeding probabilty
     */
    public static void setBreedingProbability(double newProbability)
    {
        breedingProbability = newProbability;
    }

    /**
     * Return te default breeding probability
     * @return defaultBreedingProbability returns the probability
     */
    public static double getDefaultBreedingProbability()
    {
        return defaultBreedingProbability;
    }

    /**
     * Change the default breeding probability of a fieldobject
     * @param newDefaultProbabilty The new default breeding probabilty
     */
    public static void setDefaultBreedingProbability(double newDefaultProbability)
    {
        defaultBreedingProbability = newDefaultProbability;
    }

}
