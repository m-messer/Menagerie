import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.Random;

/**
 * Builder is a genetic algorithm. It searches for the best range of probabilities.
 *
 * The health variable it aims to increase is the number of steps the algorithm surviced.
 * The probabilities are changed at each iterations.
 * The simulator stops when any of the species die out.
 *
 * @version 2019.02.20
 */
public class Builder
{
    private  double nemoBreedingProb, doryBreedingProb, dolphinBreedingProb, blueWhaleBreedingProb, orcaBreedingProb, sharkBreedingProb, plantBreedingProb;
    private  float multiplier;
    private  float decreaseBy;
    private  static int repeatTimes;
    private  static int bestNumberOfSteps;
    private int currentNumberOfSteps;

    /**
     * Consturctor for builder class. It creates a builder which will be the initial values parsed
     * through the parameter.
     *
     * @param nemoBreedingProb The best nemo breeding probability
     * @param doryBreedingProb The best dory breeding probability
     * @param dolphinBreedingProb The best dolphin breeding probability
     * @param blueWhaleBreedingProb The best blue whale breeding probability
     * @param orcaBreedingProb The best orca breeding probability
     * @param sharkBreedingProb The best shark breeding probability
     * @param plantBreedingProb The best plant breeding probability
     * @param bestNumberOfSteps The best number of steps the simulator survived for
     */
    private Builder(double nemoBreedingProb, double doryBreedingProb, double dolphinBreedingProb, double blueWhaleBreedingProb, double orcaBreedingProb, double sharkBreedingProb, double plantBreedingProb, int bestNumberOfSteps) {
        this.nemoBreedingProb = nemoBreedingProb;
        this.doryBreedingProb = doryBreedingProb;
        this.dolphinBreedingProb = dolphinBreedingProb;
        this.blueWhaleBreedingProb = blueWhaleBreedingProb;
        this.orcaBreedingProb = orcaBreedingProb;
        this.sharkBreedingProb = sharkBreedingProb;
        this.plantBreedingProb = plantBreedingProb;

        run(nemoBreedingProb, doryBreedingProb, dolphinBreedingProb, blueWhaleBreedingProb, orcaBreedingProb, sharkBreedingProb, plantBreedingProb, bestNumberOfSteps);
    }

    /**
     * Initialise the simulator. It reades the "MostCurrentData.txt" file to search
     * for most effective probabilities. Then, it parses it's data into the Builder
     * Constructor.
     *
     * @param iterations The number of iterations the builder must simulate through
     */
    public static void builderInitialise(int iterations) {
        repeatTimes = iterations;
        String contents = "";
        try{
            contents = new String(Files.readAllBytes(Paths.get("MostCurrentData.txt")));
        }
        catch(Exception ex) 
        {
            System.out.println("Failed to find MostCurrentData.txt in folder or unable to read correctly. Using default initial values");
        }

        if(!contents.equals("")){
            String[] arrayOfElements = contents.split(" ");
            bestNumberOfSteps = Integer.valueOf(arrayOfElements[15]);
            Builder initialBuilder = new Builder(Double.parseDouble(arrayOfElements[1]), Double.parseDouble(arrayOfElements[3]), Double.parseDouble(arrayOfElements[5]), Double.parseDouble(arrayOfElements[7]), Double.parseDouble(arrayOfElements[9]), Double.parseDouble(arrayOfElements[11]), Double.parseDouble(arrayOfElements[13]), Integer.valueOf(arrayOfElements[15]));
        }
        else       
        {
            Builder initialBuilder = new Builder(0.6, 0.6, 0.0015, 0.00075, 0.003, 0.0025, 0.15, 1200);
        }
    }

    /**
     * This method creates a new simulator with the parsed in paramaters.
     *
     * It then runs the simulation till any specie dies and returns this animal's index
     *
     * If the number of steps is less than the best number of steps, it uses the current
     * best probabilties and forms a weighted probability sum of the previous and best
     * probabilties. It then creates a mutation on this and calls the run method again.
     *
     * @param nemoProb new nemo breeding probability to be tested
     * @param doryProb new dory breeding probability to be tested
     * @param dolphinProb new dolphin breeding probability to be tested
     * @param blueWhaleProb new blue whale breeding probability to be tested
     * @param orcaProb new orca breeding probability to be tested
     * @param sharkProb new shark breeding probability to be tested
     * @param plantProb new plant breeding probability to be tested
     * @param bestNumberOfSteps bestNumberOfSteps in the file. Although it is not necessary to parse this, it is done so to ensure saftety when running the algorithm
     */

    private void run(double nemoProb, double doryProb, double dolphinProb, double blueWhaleProb, double orcaProb, double sharkProb, double plantProb, int bestNumberOfSteps) {
        while(repeatTimes > 0) {
            bestNumberOfSteps = this.getBestNumberOfSteps();
            Random rand = new Random();

            //Multuiplier increases the probability
            multiplier = (1+(((float)rand.nextInt(6))/100));
            //Decrease by will reduce the probability
            decreaseBy = (1-((float)rand.nextInt(6)/100));
            repeatTimes--;

            //Run the simulation
            Simulator simulatorParent =  new Simulator(nemoProb, doryProb, dolphinProb, blueWhaleProb, orcaProb, sharkProb, plantProb);
            int runNum = simulatorParent.runLongSimulation();
            currentNumberOfSteps = simulatorParent.getStep();

            printToTerminal(nemoProb, doryProb, dolphinProb, blueWhaleProb, orcaProb, sharkProb, plantProb, bestNumberOfSteps);
            System.out.println("BEST: " + bestNumberOfSteps);
            System.out.println("CURRENT: " + currentNumberOfSteps);
            if(currentNumberOfSteps > bestNumberOfSteps) {
                printToFile(nemoProb, doryProb, dolphinProb, blueWhaleProb, orcaProb, sharkProb, plantProb, currentNumberOfSteps); //Should paste all parameters to file
            }
            else {
                if(currentNumberOfSteps >= (((double)bestNumberOfSteps)*0.75)) {

                    //Will cross over the two probabilties using a weighted probability sum
                    nemoProb = getRatio(1, nemoProb, bestNumberOfSteps, currentNumberOfSteps);
                    doryProb = getRatio(3, doryProb, bestNumberOfSteps, currentNumberOfSteps);
                    dolphinProb = getRatio(5, dolphinProb, bestNumberOfSteps, currentNumberOfSteps);
                    blueWhaleProb = getRatio(7, blueWhaleProb, bestNumberOfSteps, currentNumberOfSteps);
                    orcaProb = getRatio(9, orcaProb, bestNumberOfSteps, currentNumberOfSteps);
                    sharkProb = getRatio(11, sharkProb, bestNumberOfSteps, currentNumberOfSteps);
                    plantProb = getRatio(13, plantProb, bestNumberOfSteps, currentNumberOfSteps);
                }
                switch(runNum){
                    case 0:

                    run(nemoProb*decreaseBy, doryProb*decreaseBy, dolphinProb*decreaseBy, blueWhaleProb*decreaseBy, orcaProb*decreaseBy, sharkProb*decreaseBy, plantProb*multiplier, bestNumberOfSteps);
                    break;
                    case 1:

                    run(nemoProb*multiplier, doryProb*decreaseBy, dolphinProb*decreaseBy, blueWhaleProb*decreaseBy, orcaProb*decreaseBy, sharkProb*decreaseBy, plantProb*decreaseBy, bestNumberOfSteps);
                    break;
                    case 2:

                    run(nemoProb*decreaseBy, doryProb*multiplier, dolphinProb*decreaseBy, blueWhaleProb*decreaseBy, orcaProb*decreaseBy, sharkProb*decreaseBy, plantProb*decreaseBy, bestNumberOfSteps);
                    break;
                    case 3:

                    run(nemoProb*decreaseBy, doryProb*decreaseBy, dolphinProb*multiplier, blueWhaleProb*decreaseBy, orcaProb*decreaseBy, sharkProb*decreaseBy, plantProb*decreaseBy, bestNumberOfSteps);
                    break;
                    case 4:

                    run(nemoProb*decreaseBy, doryProb*decreaseBy, dolphinProb*decreaseBy, blueWhaleProb*multiplier, orcaProb*decreaseBy, sharkProb*decreaseBy, plantProb*decreaseBy, bestNumberOfSteps);
                    break;
                    case 5:

                    run(nemoProb*decreaseBy, doryProb*decreaseBy, dolphinProb*decreaseBy, blueWhaleProb*decreaseBy, orcaProb*multiplier, sharkProb*decreaseBy, plantProb*decreaseBy, bestNumberOfSteps);
                    break;
                    case 6:

                    run(nemoProb*decreaseBy, doryProb*decreaseBy, dolphinProb*decreaseBy, blueWhaleProb*decreaseBy, orcaProb*decreaseBy, sharkProb*multiplier, plantProb*decreaseBy, bestNumberOfSteps);
                    break;
                }
            }
        }
    }

    /**
     * Print the current (identified as the best) probability in the file
     * @param nemoProb Breeding probability of the nemo
     * @param doryProb Breeding probability of the dory
     * @param dolphinProb Breeding probability of the dolphin
     * @param blueWhaleProb Breeding probability of the blueWhale
     * @param orcaProb Breeding probability of the orca
     * @param sharkProb Breeding probability of the shark
     * @param plantProb Breeding probability of the plant
     * @param bestNumberOfSteps the highest number of steps the program worked
     *
     */
    private void printToFile(double nemoProb, double doryProb, double dolphinProb, double blueWhaleProb, double orcaProb, double sharkProb, double plantProb, int bestNumberOfSteps) {
        String str = ("Nemo: " + nemoProb + " ,Dory: " + doryProb + " ,Dolphin: " + dolphinProb + " ,BlueWhale: " + blueWhaleProb + " ,Orca: " + orcaProb + " ,Shark: " + sharkProb +" ,Plant: " + plantProb + " ---BestSTEPS: " + bestNumberOfSteps + " !");
        setBestNumberOfSteps(bestNumberOfSteps);

        try { Files.write(Paths.get("./MostCurrentData.txt"), str.getBytes()); }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Print the current probability of species in the terminal
     * @param nemoProb Breeding probability of the nemo
     * @param doryProb Breeding probability of the dory
     * @param dolphinProb Breeding probability of the dolphin
     * @param blueWhaleProb Breeding probability of the blueWhale
     * @param orcaProb Breeding probability of the orca
     * @param sharkProb Breeding probability of the shark
     * @param plantProb Breeding probability of the plant
     * @param bestNumberOfSteps the highest number of steps the program worked
     */
    private void printToTerminal(double nemoProb, double doryProb, double dolphinProb, double blueWhaleProb, double orcaProb, double sharkProb, double plantProb, int bestNumberOfSteps) {
        String str = ("Nemo: " + nemoProb + " ,Dory: " + doryProb + " ,Dolphin: " + dolphinProb + " ,BlueWhale: " + blueWhaleProb + " ,Orca: " + orcaProb + " ,Shark: " + sharkProb +" ,Plant: " + plantProb + " ---BestSTEPS: " + bestNumberOfSteps + " !");
        System.out.println(str);
    }

    /**
     * Return the current number of steps the simulator worked 
     * @return currentNumberOfSteps The number of steps the simulator worked
     */
    private int getCurrentNumberOfSteps() {
        return currentNumberOfSteps;
    }

    /**
     * Scan the MostCurrentdata.txt, if found fill
     * array of elements with index 15 with the value found
     * in the file otherwise throw an exception or 
     * Return -1.
     * @return 
     */
    private int getBestNumberOfSteps() {
        String contents = "";
        try{
            contents = new String(Files.readAllBytes(Paths.get("MostCurrentData.txt")));
        }
        catch(Exception ex) 
        {
            System.out.println("Failed to find MostCurrentData.txt in folder or unable to read correctly. Using default initial values");
        }

        if(!contents.equals("")){
            String[] arrayOfElements = contents.split(" ");
            return Integer.valueOf(arrayOfElements[15]);
        }
        else       
        {
            return -1;
        }
    }

    /**
     * Change the number if best steps
     * @param newBest The new best number of steps 
     */
    private void setBestNumberOfSteps(int newBest) {
        bestNumberOfSteps = newBest;
    }

    /**
     * Will return the ratio of the animal using the best number of steps and
     * current number of steps as the ratio.
     *
     * @param indexInTheFile The index for the animal within the "MostCurrentData.txt" file
     * @param previousProbability The previous probability of the organism
     * @param bestNumberOfSteps The best number of steps from the file
     * @param currentNumberOfSteps The current number of steps in the simulation
     * @return
     */

    private double getRatio(int indexInTheFile, double previousProbability, int bestNumberOfSteps, int currentNumberOfSteps) {

        String contents = "";
        double bestProbability;
        try{
            contents = new String(Files.readAllBytes(Paths.get("MostCurrentData.txt")));
        }
        catch(Exception ex) 
        {
            System.out.println("Failed to find MostCurrentData.txt in folder or unable to read correctly. Using default initial values");
        }

        if(!contents.equals("")){
            String[] arrayOfElements = contents.split(" ");
            bestProbability =   Double.parseDouble(arrayOfElements[indexInTheFile]);

            double ratioForBestProbability = ((double)bestNumberOfSteps/(bestNumberOfSteps+currentNumberOfSteps));
            double ratioForPreviousProbability = ((double)currentNumberOfSteps/(bestNumberOfSteps+currentNumberOfSteps));

            return (ratioForBestProbability*bestProbability + ratioForPreviousProbability*previousProbability);
        }
        else       
        {
            return -0;
        }

    }
}