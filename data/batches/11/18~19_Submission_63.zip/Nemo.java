import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a nemo.
 * Nemos eat plants, catch disease, age, move, breed, and die.
 * They require a female partner to breed.
 * They are orange in color.
 *
 * @version 2019.02.19
 */
public class Nemo extends PlantEater {
    // Characteristics shared by all nemos (class variables).

    // The age at which a nemo can start to breed.
    private static final int BREEDING_AGE = 40;
    // The age to which a nemo can live.
    private static final int MAX_AGE = 39420;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 9;
    //The maximum health of the nemo
    private static final int MAX_HEALTH = 64;
    //The default probabilty of fieldobjects breeding
    private static double defaultBreedingProbability ;
    //Current breeding probability
    private static double breedingProbability;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    //Individual nemo characteristics
    //True if female
    private boolean female;

    /**
     * Create a new nemo. A nemo may be created with age
     * zero (a new born) or with a random age.
     *
     * If created with age zero, then it will start with less food level
     * 
     * @param randomAge If true, the nemo will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Nemo(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(MAX_HEALTH));
        }
        else {
            //It's a new born nemo
            setAge(0);
            setFoodLevel((int)(MAX_HEALTH*0.25));;
        }

        setBreedingProbability(getDefaultBreedingProbability());
        //set nemo to male or female
        Random randBoolean = new Random();
        female = randBoolean.nextBoolean();
    }

    /**
     * This is what the nemo does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newNemos A list to return newly born nemos.
     */
    public void act(List<FieldObjects> newNemos, int timeOfDay)
    {
        incrementAge();
        //The probability increases whne the healht is maximum
        if(getFoodLevel() == MAX_HEALTH) { setBreedingProbability(getBreedingProbability()*2); }
        if(getAge() > MAX_AGE) {setDead();}
        incrementHunger();
        if(isAlive() && timeOfDay>6 && timeOfDay<18) {
            //Only the females can give birth
            if(this.getIsFemale()){
                giveBirth(newNemos);  
            }
            //Eat food
            Location oldLoaction = getLocation();
            Location newLocation = findFood();
            if(!oldLoaction.equals(newLocation))
            {
                eat();
            }
            // Try to move into a free location if no food found
            if(newLocation==null){
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * When the nemo eats a plant, we change it's fields
     */
    protected void eat()
    {
        int foodLevel = getFoodLevel();
        int maxHealth = getMaxHealth();
        setFoodLevel((foodLevel + Plant.getPlantFoodValue()));
        if(foodLevel > maxHealth)
        {
            foodLevel = maxHealth;
        }
    }

    /**
     * Check whether or not this nemo is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newNemos A list to return newly born nemos.
     */
    private void giveBirth(List<FieldObjects> newNemos)
    {
        // New nemos are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Nemo young = new Nemo(false, field, loc);
            newNemos.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A nemo can breed if it has reached the breeding age.
     * @return true if the nemo can breed, false otherwise.
     */
    private boolean canBreed()
    { Field field=getField();
        List<Location> nearLocations = field.adjacentLocations(getLocation());
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        nearLocations.removeAll(free);
        List<FieldObjects> fieldObjects = new ArrayList<FieldObjects>();
        for(int i=0; i < nearLocations.size(); i++){
            fieldObjects.add((FieldObjects)field.getObjectAt(nearLocations.get(i)));
        }
        for(FieldObjects fieldObject:fieldObjects){
            if(fieldObject instanceof Nemo && ((Nemo)fieldObject).getIsFemale()!=this.getIsFemale() && getAge()>=BREEDING_AGE && ((Nemo)fieldObject).getAge()>=BREEDING_AGE){
                return true;
            }
        }
        return false;

    }

    /**
     * Return the gender of the animal
     * @return female boolean whether the animal is female
     */
    public boolean getIsFemale() {
        return female;
    }

    /**
     * Set the gender of the animal
     * @param female boolean whether the animal is female or not.
     */
    public void setFemale(boolean female) {
        this.female = female;
    }

    /**
     * Return the maximum health of the dory
     * @return The max health
     */
    public int getMaxHealth()
    {
        return MAX_HEALTH;
    }

    /**
     * Return the breeding age of the animal
     * @return breedingage the breading age of the animal
     */
    public static int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the maximum age of the animal
     * @return max_age the maximum age of the animal
     */
    public static int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the maximum litter size of the animal
     * @return max_litter_size the maximum litter size of the animal
     */
    public static int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the breeding probability of the fieldobjects
     * @return the probabilty of the fieldobject breeding
     */
    public static double getBreedingProbability() 
    {
        return breedingProbability;
    }

    /**
     * Change the breeding probability of a fieldobject
     * @param newProbabilty The new breeding probabilty
     */
    public static void setBreedingProbability(double newProbability)
    {
        breedingProbability = newProbability;
    }

    /**
     * Return te default breeding probability
     * @return defaultBreedingProbability returns the probability
     */
    public static double getDefaultBreedingProbability()
    {
        return defaultBreedingProbability;
    }

    /**
     * Change the default breeding probability of a fieldobject
     * @param newDefaultProbabilty The new default breeding probabilty
     */
    public static void setDefaultBreedingProbability(double newDefaultProbability)
    {
        defaultBreedingProbability = newDefaultProbability;
    }

}