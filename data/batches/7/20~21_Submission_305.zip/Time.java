/**
 * A time object. Each step in the simulation is an hour.
 *
 * @version 17/02/21
 */
public class Time {
    public static int hour;

    private static boolean day;

    /**
     * Create a time object with hour set to 0
     */
    public Time() {
        hour = 0;
    }
    
    /**
     * Increase the hour by one. If the hour is 24, set it to 0 instead to comply with the 24 hour format.
     * @return true if it is daytime, false otherwise
     */
    public boolean timeStatus() {
        hour++;
        if (hour==24) {
            hour = 0;
        }
        if (hour >= 0 && hour <= 6) {
            day = false;
        }
        else {day = true;}
        return day;
    }   
    
    /**
     * @return hour The hour.
     */
    public int getTime() {
        return hour;        
    }

    /**
     * @return day A boolean, true if it is daytime, false otherwsie
     */
    public boolean isDay() {
        return day;
    }
}
