import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A model of the animal snake.
 *
 * @version 15/02/2021
 */
public class Snake extends Diurnal {
    // Characteristics shared by all snakes

    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a snake can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births a snake can have.
    private static final int MAX_LITTER_SIZE = 7;
    // The food value of the snake if it is eaten.
    private static final int FOOD_VALUE = 9;
    // The inital food level of a snake.
    private static final int INTIAL_ENERGY = 7;
    // The maximum amount of energy a frog can have;
    private static final int MAX_FOOD_LEVEL = 10;

    //a List of food the snake can eat.
    private static final List<String> food = new ArrayList<>(Arrays.asList("frog"));

    /**
     * Create a snake.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this snake is carrying, if any.
     */
    public Snake(Boolean randomAge, Field field, Location location, Disease disease) {
        super(randomAge, "snake", food, field, location, disease);
    }
    
    /**
     * Return the max age of a snake.
     * @return MAX_AGE The max age of a snake.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the breeding age of a snake. They cannot breed until they have reached this age.
     * @return BREEDING_AGE The breeding age of a snake.
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Return the food value of a snake.
     * @return FOOD_VALUE The food value of a snake.
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * Return the maximum number of babies a snake can have at one time.
     * @return MAX_LITTER_SIZE The maximum litter size of a snake.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the probability of a snake breeding.
     *@return BREEDING_PROBABILITY The probability of a snake breeding.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the initial food level a snake has when newly created.
     * @return INTIAL_ENERGY The inital food level of a snake.
     */
    protected int getInitialEnergy() {
        return INTIAL_ENERGY;
    }

    /**
     * @return The maximum amount of energy an animal can have
     */
    protected int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return a birthed animal.
     * @param location The location where the new animal should be born in
     * @return a new cat object.
     */
    protected Animal birth(Location location) {
        return (new Snake(false, getField(), location, getDisease()));
    }
}
