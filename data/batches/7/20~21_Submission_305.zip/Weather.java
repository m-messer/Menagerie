import java.util.Random;
import java.util.HashMap;

/**
 * A weather object. The type of weather per step is randomly generated. 
 * The weather will affect how plants grow and animals hunt.
 *
 * @version 19/02/21
 */

public class Weather
{   
    // The level of visibility out of 1
    private double visibility;
    // The level of soil fertility out of 1
    private double soilFertility;
    // The level of sun out of 1
    private double sunLevel;
    // A boolean to denote if it snowing or not
    private boolean snow;

    // The current weather type occuring
    private WeatherTypes currentWeather;
    
    // The probability of the weather changing
    private static final double WEATHER_CHANGE_PROBABILITY = 0.3;
    
    // A shared random number generator
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Weather. The default values for weather effects are set.
     */
    public Weather() {
        visibility = 1;
        soilFertility = 0.25;
        sunLevel = 0.5;
        snow=false;

        currentWeather=WeatherTypes.SUN;       
    }

    /**
     * Change the current weather depending on the probability.
     */
    public void changeWeather() {
        if (rand.nextDouble()<=WEATHER_CHANGE_PROBABILITY) {
            WeatherTypes weather = currentWeather;
            do {
                currentWeather = WeatherTypes.randomWeather();
            } while ((currentWeather.equals(weather)));
            
            switch (currentWeather) {
                case SNOW:
                snow(); break;
                case RAIN:
                rain(); break;
                case FOG:
                fog(); break;
                case SUN:
                sun(); break;
            }
        }
    }
    
    /**
     * Chnage the visibility and sun levels due to the fog.
     */
    private void fog() {
        visibility = 0.5;   
        sunLevel = 0.3;
    }
    
    /**
     * Change the visibility, soil fertility and sun levels due to the rain.
     */
    private void rain() {
        visibility = 0.75;         
        if (soilFertility<=0.9){
            soilFertility+=0.1;
        }
        
        sunLevel=0;
    }
    
    /**
     * Change the sun, soil fertility, visibility levels due to the sun.
     * There is no snow when it is sunny, so this is set to false.
     */
    private void sun() {
        if (sunLevel<=0.9){
            sunLevel+=0.1;
        }
        
        if (soilFertility >= 0.1){
            soilFertility-=0.1;
        }
        
        visibility=1;
        snow=false;
    }  
    
    /**
     * Change the snow, visibility and sun levels due to the snow.
     */
    private void snow() {
        snow=true;
        visibility=0.25;        
        sunLevel=0.2;       
    }

    /**
     * Return the current weather type.
     * @return currentWeather The current weather type.
     */
    public String getCurrentWeather(){
        return currentWeather.getWeather();
    }    
    
    /**
     * Return the visibility level.
     * @return visibility The current visibility level.
     */
    public double getVisibility() {
        return visibility;
    }
    
    /**
     * Return the soil fertility.
     * @return soilFertility The current soil fertility level.
     */
    public double getSoilFertility() {
        return soilFertility;
    }
    
    /**
     * Return the sun level.
     * @return sunLevel The current sun level.
     */
    public double getSunLevel() {
        return sunLevel;
    }
    
    /**
     * Return true if it is snowing, false if not.
     * @return snow A boolean value detailing if it is snowing or not.
     */
    public boolean getSnowStatus() {
        return snow;
    }
}