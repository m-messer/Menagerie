import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A model of the animal frog.
 *
 * @version 15/02/2021
 */
public class Frog extends Diurnal
{
    // Characteristics shared by all frogs

    // The age at which a frog can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a frog can live.
    private static final int MAX_AGE = 23;
    // The likelihood of a frog breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of the frog if it is eaten
    private static final int FOOD_VALUE = 9;
    // The inital food level of a frog.
    private static final int INTIAL_ENERGY = 7;
    // The maximum amount of energy a frog can have;
    private static final int MAX_FOOD_LEVEL = 12;

    //A list of food the frog can eat.
    private static final List<String> food = new ArrayList<>(Arrays.asList("grasshopper"));

    /**
     * Create a frog.
     * 
     * @param randomAge If true, the frog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this frog is carrying, if any.
     */
    public Frog(boolean randomAge, Field field, Location location, Disease disease) {
        super(randomAge, "frog", food, field, location, disease);
    }

    /**
     * Return the max age of a frog.
     * @return MAX_AGE The max age of a frog.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }
    
    /**
     * Return the breeding age of a frog. They cannot breed until they have reached this age.
     * @return BREEDING_AGE The breeding age of a frog.
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the food value of a frog.
     * @return FOOD_VALUE The food value of a frog.
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * Return the maximum number of babies a frog can have at one time.
     * @return MAX_LITTER_SIZE The maximum litter size of a frog.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the probability of a frog breeding.
     *@return BREEDING_PROBABILITY The probability of a frog breeding.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the initial food level a frog has when newly created.
     * @return INTIAL_ENERGY The inital food level of a frog.
     */
    protected int getInitialEnergy() {
        return INTIAL_ENERGY;
    }

    /**
     * @return The maximum amount of energy an animal can have
     */
    protected int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return a birthed animal.
     * @param location The location where the new animal should be born in
     * @return a new cat object.
     */
    protected Animal birth(Location location) {
        return (new Frog(false, getField(), location, getDisease()));
    }
}
