import java.util.List;

/**
 * A general model of a Nocturnal animal - an animal asleep during the day
 *
 * @version 28/02/21
 */
public abstract class Nocturnal extends Animal {

    // The hour the animal wakes up (in 24hr clock)
    private static final int HOUR_WAKE_UP = 0;
    // The hour the animal goes to sleep (in 24hr clock)
    private static final int HOUR_FALL_ASLEEP = 6;
    
    /**
     * Creates a new nocturnal animal
     * 
     * @param randomAge If true, the animal will have a random age.
     * @param name The name of the animal species
     * @param food An list of the names of the food organisms an animal can eat
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease an animal has when it is created
     */
    public Nocturnal(boolean randomAge, String name,  List<String> food,  Field field, Location location, Disease disease) {
        super(randomAge, name, food, field, location, disease);
    } 

    /**
     * @return The hour an animal wakes up (24hr clock)
     */
    protected int getHourWakeUp() {
        return HOUR_WAKE_UP;
    }

    /**
     * @return The hour an animal falls asleep (24hr clock)
     */
    protected int getHourFallAsleep() {
        return HOUR_FALL_ASLEEP;
    }
}