/**
 * A model of the plant grass
 *
 * @version 28/02/21
 */
public class Grass extends Plant {
    
    // The probability of grass spreading.
    private static final double SPREAD_PROBABILITY = 0.1;
    // The max age of grass.
    private static final int MAX_AGE = 50;
    // The max size of grass.
    private static final int MAX_SIZE = 5;
    // The food inital value of grass if eaten. 
    private static int foodValue = 7;
    
    /**
     * Create a new grass object.
     * 
     * @param randomAge If true, the grass will have random age,
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this organism is carrying, if any. 
     */
    public Grass(Boolean randomAge, Field field, Location location, Disease disease) {
        super(randomAge, "grass", field, location, disease);
    }    

    /**
     * Set the food value to a higher value the larger the size of the grass.
     * @param growth The amount to increase the foodValue by
     */
    protected void setFoodValue(int growth) {
        foodValue = growth;
    }
    
    /**
     * Return the food value of grass.
     * @return FOOD_VALUE The food value of grass.
     */
    protected int getFoodValue() {
        return foodValue;
    }      

    /**
     * Return the max age of grass.
     * @return MAX_AGE The max age of grass.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the probability of grass spreading.
     * @return SPREAD_PROBABILITY The spread probability of grass.
     */
    protected double getSpreadProbability() {
        return SPREAD_PROBABILITY;
    }
    
    /**
     * Return the max size of grass.
     * @return MAX_SIZE The max size of grass.
     */
    protected int getMaxSize(){
        return MAX_SIZE;
    }

    /**
     * Return a new grass object.
     * @param location The location where the new animal should be born in
     * @return The new grass object.
     */
    protected Plant growNew(Location location) {
        return (new Grass(false, getField(), location, null));
    }
}
