import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A model of the animal Lizard.
 *
 * @version 15/02/2021
 */
public class Lizard extends Diurnal {
    // Characteristics shared by all lizards

    // The age at which a lizard can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a lizard can live.
    private static final int MAX_AGE = 12;
    // The likelihood of a lizard breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of the lizard if it is eaten
    private static final int FOOD_VALUE = 9;
    // The initial food level of a lizard.
    private static final int INTIAL_ENERGY = 9;
    // The maximum amount of energy a lizard can have;
    private static final int MAX_FOOD_LEVEL = 7;

    //a List of food the lizard can eat.
    private static final List<String> food = new ArrayList<>(Arrays.asList("frog"));

    /**
     * Create a lizard.
     * 
     * @param randomAge If true, the lizard will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this lizard is carrying, if any. 
     */
    public Lizard(Boolean randomAge, Field field, Location location, Disease disease) {
        super(randomAge, "lizard", food, field, location, disease);
    }

    /**
     * Return the max age of a lizard.
     * @return MAX_AGE The max age of a lizard.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the breeding age of a lizard. They cannot breed until they have reached this age.
     * @return BREEDING_AGE The breeding age of a lizard.
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the food value of a lizard.
     * @return FOOD_VALUE The food value of a lizard.
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * Return the maximum number of babies a lizard can have at one time.
     * @return MAX_LITTER_SIZE The maximum litter size of a lizard.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the probability of a lizard breeding.
     *@return BREEDING_PROBABILITY The probability of a lizard breeding.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the initial food level a lizard has when newly created.
     * @return INTIAL_ENERGY The inital food level of a lizard.
     */
    protected int getInitialEnergy() {
        return INTIAL_ENERGY;
    }

    /**
     * @return The maximum amount of energy an animal can have
     */
    protected int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return a birthed animal.
     * @param location The location where the new animal should be born in
     * @return a new cat object.
     */
    protected Animal birth(Location location) {
        return (new Lizard(false, getField(), location, getDisease()));
    }
}
