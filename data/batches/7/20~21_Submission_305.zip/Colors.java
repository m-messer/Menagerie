import java.awt.Color;

/**
 * Stores the colors used in the simulation in RGB
 *
 * @version 01/03/21
 */
public class Colors {
    public static final Color PINK = new Color(254,127,156);
    public static final Color GREEN = new Color(160,200,121);
    public static final Color PURPLE = new Color(181,100,227);
    public static final Color ORANGE = new Color(253,106,2);
    public static final Color BLUE = new Color(0,32,255);
    public static final Color CYAN = new Color(0,255,255);
    public static final Color GRAY = new Color(134,136,138);
    public static final Color YELLOW = new Color(248, 228, 115);
    public static final Color RED = new Color(126, 25, 27);
}