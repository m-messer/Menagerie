import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A model of the animal grasshopper.
 *
 * @version 15/02/2021
 */
public class Grasshopper extends Diurnal {
    // Characteristics shared by all grasshoppers

    // The age at which a grasshopper can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a grasshopper can live.
    private static final int MAX_AGE = 10;
    // The likelihood of a grasshopper breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of the grasshopper if it is eaten
    private static final int FOOD_VALUE = 6;
    // The initial food level of a grasshopper.
    private static final int INTIAL_ENERGY = 10;
    // The maximum amount of energy a grasshoppper can have.
    private static final int MAX_FOOD_LEVEL = 6;
    // A list of food the grasshopper can eat.
    private static final List<String> food = new ArrayList<>(Arrays.asList("flower", "grass"));

    /**
     * Create a grasshopper.
     * 
     * @param randomAge If true, the grasshopper will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this grasshopper is carrying, if any. 
     */
    public Grasshopper(boolean randomAge, Field field, Location location, Disease disease) {
        super(randomAge, "grasshopper", food, field, location, disease);
    }

    /**
     * Return the max age of a grasshopper.
     * @return MAX_AGE The max age of a grasshopper.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the breeding age of a grasshopper. They cannot breed until they have reached this age.
     * @return BREEDING_AGE The breeding age of a grasshopper.
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the food value of a grasshopper.
     * @return FOOD_VALUE The food value of a grasshopper.
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * Return the maximum number of babies a grasshopper can have at one time.
     * @return MAX_LITTER_SIZE The maximum litter size of a grasshopper.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the probability of a grasshopper breeding.
     *@return BREEDING_PROBABILITY The probability of a grasshopper breeding.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the initial food level a grasshopper has when newly created.
     * @return INTIAL_ENERGY The inital food level of a grasshopper.
     */
    protected int getInitialEnergy() {
        return INTIAL_ENERGY;
    }

    /**
     * @return The maximum amount of energy an animal can have
     */
     protected int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return a birthed animal.
     * @param location The location where the new animal should be born in
     * @return a new cat object.
     */
    protected Animal birth(Location location) {
        return (new Grasshopper(false, getField(), location, getDisease()));
    }
}
