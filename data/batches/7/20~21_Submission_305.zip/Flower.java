/**
 * A model of the plant flower.
 *
 * @version 15/02/2021
 */
public class Flower extends Plant {

    // The probability of flowers spreading
    private static final double SPREAD_PROBABILITY = 0.7;
    // The max age of a flower.
    private static final int MAX_AGE = 40;
    // The max size of a flower
    private static final int MAX_SIZE = 4;
    // The inital food value of the flower if eaten.
    private static int foodValue = 3;

    /**
     * Create a new flower object.
     * 
     * @param randomAge If true, the flower will have random age,
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this organism is carrying, if any. 
     */
    public Flower(Boolean randomAge, Field field, Location location, Disease disease) {
        super(randomAge, "flower", field, location, disease);
    }    

    /**
     * Set the food value to a higher value the larger the size of the grass.
     * @param growth The amount to increase the foodValue by
     */
    protected void setFoodValue(int growth) {
        foodValue = growth;
    }
    
    /**
     * Return the food value of the flower.
     * @return FOOD_VALUE The food value of flower.
     */
    protected int getFoodValue() {
        return foodValue;
    }      
    
    /**
     * Return the max age of flower.
     * @return MAX_AGE The max age of flower.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the probability of flower spreading.
     * @return SPREAD_PROBABILITY The spread probability of flower.
     */
    protected double getSpreadProbability() {
        return SPREAD_PROBABILITY;
    }
    
    /**
     * Return the max size of flower.
     * @return MAX_SIZE The max size of flower.
     */
    protected int getMaxSize(){
        return MAX_SIZE;
    }

    /**
     * Return a new flower object.
     * @param location The location where the new animal should be born in
     * @return The new flower object.
     */    
    protected Plant growNew(Location location) {
        return (new Flower(false, getField(), location, null));
    }
}