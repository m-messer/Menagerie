/**
 * A model of the disease Chlamidya.
 *
 * @version 28/02/21
 */
public class Chlamidya extends Disease {

    // The number of years, by which an animal that gets chlamidya, life is shortened
    private static final int LIFE_SHORTENING_FACTOR = 3;
    // The chance of one affected animal spreading chlamidya 
    // to another animal which can be affected
    private static final double DISEASE_SPREAD_PROBABILITY = 0.3;

    /**
     * Create a new instance of Chlamidya called chlamidya, which can affect
     * the animal cat
     */
    public Chlamidya() {
        super("chlamidya", new String [] {"cat"});
    }
    
    /**
     * @return LIFE_SHORTENING_FACTOR The number of years, which an animal's life is shortened
     */
    protected int getLifeShorteningFactor(){
        return LIFE_SHORTENING_FACTOR;
    }

    /**
     * @return DISEASE_SPREAD_PROBABILITY The chance of the disease spreading
     */
    protected double getDiseaseSpreadProbability() {
        return DISEASE_SPREAD_PROBABILITY ;
    }
}
