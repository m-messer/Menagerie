import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing different animal species and plants. With other natural phenomena -
 * weather and disease being simulated.
 *
 * @version 01/03/21
 */
public class Simulator {

    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;

    // The probability that a lizard will be created in any given grid position.
    private static final double LIZARD_CREATION_PROBABILITY = 0.07;
    // The probability that a cat will be created in any given grid position.
    private static final double CAT_CREATION_PROBABILITY = 0.05; 
    // The probability that a grass patch will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.04;
    // The probability that a snake patch will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.06;
    // The probability that a grasshopper patch will be created in any given grid position.
    private static final double GRASSHOPER_CREATION_PROBABILITY = 0.03;
    // The probability that a frog patch will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.04;
    // The probability that a flower patch will be created in any given grid position.
    private static final double FLOWER_CREATION_PROBABILITY = 0.04;
    // The probability of an organism having a disease when created.
    private static final double DISEASE_UPON_CREATION = 0.05;
    
    // A list of the available diseases within a simulation
    private static final Disease[] availableDiseases = {new Chlamidya(), new RootRot(), new Salmonella()};

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A time tracker
    private Time time;
    // Simulate the weather
    private Weather weather;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {        
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Main method which creates a new simulation and then simulates for 1000 steps
     */
    public static void main(String[] args) {
        Simulator simulator = new Simulator();
        simulator.simulate(500);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        time = new Time();
        weather = new Weather();

        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        setColors();
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(100);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each organism, weather and time
     */
    public void simulateOneStep() {
        step++;
        weather.changeWeather();

        if (time.timeStatus()) {
            view.setDayColor();
        }
        else {view.setNightColor();}

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, Time.hour, weather.getVisibility());
            if(! animal.isAlive()) {
                field.clear(animal.getLocation());
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        // Provide space for new plants.
        List<Plant> newPlants = new ArrayList<>();        
        // Let all plants spread.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.grow(weather.getSoilFertility(), weather.getSunLevel(), weather.getSnowStatus());
            plant.spread(newPlants, weather.getSnowStatus());
            if(! plant.isAlive()) {
                it.remove();
            }
        }
               
        // Add the plants to the main lists.
        plants.addAll(newPlants);

        view.showStatus(step, field, Time.hour, weather.getCurrentWeather(), time.isDay());
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, Time.hour, weather.getCurrentWeather(), time.isDay());
    }
    
    /**
     * Randomly populate the field with living things.
     */
    private void populate() {
        Disease diseaseToGive = null;
        Disease disease = null;
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // Get a random disease to give to the created organism
                // The disease will be checked that it can affect the organism before being given in the organims constructor
                if (rand.nextDouble()<=DISEASE_UPON_CREATION){
                    disease = availableDiseases[rand.nextInt(availableDiseases.length)];  
                }
                
                
                if(rand.nextDouble() <= LIZARD_CREATION_PROBABILITY) {                    
                    Location location = new Location(row, col);
                    Lizard lizard = new Lizard(true, field, location, disease);
                    animals.add(lizard);
                }
                else if(rand.nextDouble() <= CAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);         
                    Cat cat = new Cat(true, field, location, disease);
                    animals.add(cat);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location, disease);
                    plants.add(grass);
                }
                else if(rand.nextDouble() <= FLOWER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Flower flower = new Flower(true, field, location, disease);
                    plants.add(flower);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location, disease);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location, disease);
                    animals.add(frog);
                }
                else if(rand.nextDouble() <= GRASSHOPER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grasshopper grasshopper = new Grasshopper(true, field, location, disease);
                    animals.add(grasshopper);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Set the colors to be used to represent the organisms within the simulation
     */
    private void setColors() {
        view.setColor(Lizard.class, Colors.BLUE);
        view.setColor(Cat.class, Colors.ORANGE);
        view.setColor(Grass.class, Colors.GREEN);
        view.setColor(Grasshopper.class, Colors.RED);
        view.setColor(Frog.class, Colors.PINK);
        view.setColor(Snake.class, Colors.CYAN);
        view.setColor(Flower.class, Colors.PURPLE);
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }    
}


