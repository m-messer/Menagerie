import java.util.Random;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;

enum WeatherTypes {
    SNOW("snow"), RAIN("rain"), FOG("fog"), SUN("sun");

    // A cached array of the available enum types
    private static final List<WeatherTypes> VALUES = Collections.unmodifiableList(Arrays.asList(values()));
    // The number of available weather types
    private static final int SIZE = VALUES.size();
    // A shared random number generator
    private static final Random rand = Randomizer.getRandom();

    // A string of the name of the weather type
    private String weatherString;

    /**
     * Creates a weather type with a corresponding string of the name of the weather type
     * @param weatherName A string of the name of the weather type
     */
    WeatherTypes(String weatherName) {
        weatherString = weatherName;
    }

    /**
     * @return A random weather type
     */
    public static WeatherTypes randomWeather()  {
        return VALUES.get(rand.nextInt(SIZE));
    }

    /**
     * @return A string of the name or the weather type
     */
    public String getWeather() {
        return weatherString;
    }
}