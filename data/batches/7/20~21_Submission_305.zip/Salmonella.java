/**
 * A model of the disease Salmonella.
 *
 * @version 28/02/21
 */
public class Salmonella extends Disease {

    // The number of years, by which an animal that gets salmonella, life is shortened
    private static final int LIFE_SHORTENING_FACTOR = 5;
    // The chance of one affected animal spreading salmonella 
    // to another animal which can be affected
    private static final double DISEASE_SPREAD_PROBABILITY = 0.3;

    /**
     * Create a new instance of Salmonella called salmonella, which can affect
     * the animals lizard, snake and frog
     */
    public Salmonella() {
        super("salmonella", new String[] {"lizard", "snake", "frog"});
    }
    
    /*
     * @return LIFE_SHORTENING_FACTOR The number of years, which an animal's life is shortened
     */
    protected int getLifeShorteningFactor(){
        return LIFE_SHORTENING_FACTOR;
    }

    /*
     * @return DISEASE_SPREAD_PROBABILITY The chance of the disease spreading
     */
    protected double getDiseaseSpreadProbability() {
        return DISEASE_SPREAD_PROBABILITY ;
    }
}