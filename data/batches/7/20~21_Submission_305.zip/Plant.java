import java.util.List;
import java.util.Random;

/**
 * Plant represents plant based organisms
 *
 * @version 28/02/21
 */
public abstract class Plant extends LivingThing {
    
    // A shared random number generator
    private static final Random rand = new Random();
    // The current size of the plant
    private int size;

    /**
     * Create a new plant, with a name to denote its species, at location in field. The
     * plant can either be created a random age, or as a newborn.
     * 
     * @param randomAge If true, the plant will have a random age.
     * @param name The name of the plant species
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease a plant has when it is created
     */
    public Plant(Boolean randomAge, String name, Field field, Location location, Disease disease) {
        super(name, field, location, disease);  

        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
        }
        else {
            setAge(0);
        }
    }

    /**
     * Make this plant spread (essentially breeding)
     * @param newPlants A list to hold the newly born plants
     * @param snow A boolean to denote if it is snowing, as plants can't breed if it snowing
     */
    protected void spread(List<Plant> newPlants, boolean snow) {
        spreadDisease();
        if((rand.nextDouble()<=getSpreadProbability()) && isAlive() && !snow) {          
            // Try to spread into a free location.
            // New plants can spread into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());

            for (Location loc:free){
                newPlants.add(growNew(loc));
            }
        }
    }   
    
    /**
     * If a plant has a disease then it spreads to the neighbouring plants which the disease can affect
     */
    protected void spreadDisease() {        
        if (getDisease()!=null){
            List<LivingThing> neighbours = getNeighbouringLivingThings();
            
            for (LivingThing neighbour:neighbours){
                String neighbourName = neighbour.getName();
                Disease disease = getDisease();

                if(getName().equals(neighbourName) && disease.canAffect(neighbourName) && rand.nextInt()<=disease.getDiseaseSpreadProbability()){
                    neighbour.giveDisease(disease);
                }
            }
        }
    }
    
    /**
     * If the plant has the correct weather conditions then it grows, which increases its food value if it is eaten
     * @param soilFertility The conditions of the soil, which acts as a probability to plant growth
     * @param sunLevel The amount of sun available to the plant, which acts as a probability to plant growth
     * @param snow A boolean to denote if it is snowing, as plants can't grow if it snowing 
     */
    protected void grow(double soilFertility, double sunLevel, boolean snow) {
        incrementAge();

        if (rand.nextDouble() <= soilFertility && rand.nextDouble() <= sunLevel && !snow && size<getMaxSize()){
            size++;
            setFoodValue(getFoodValue()+1);
        }
    }

    /**
     * Return a new flower object.
     * @param location The location where the new animal should be born in
     * @return The new flower object.
     */ 
    protected abstract Plant growNew(Location location);

    /**
     * Return the probability of grass spreading.
     * @return SPREAD_PROBABILITY The spread probability of grass.
     */
    protected abstract double getSpreadProbability();
    
    /**
     * Return the max size of grass.
     * @return MAX_SIZE The max size of grass.
     */
    protected abstract int getMaxSize();

    /**
     * Set the food value to a higher value the larger the size of the grass.
     * @param growth The amount to increase the foodValue by
     */
    protected abstract void setFoodValue(int growth);
    }

