import java.util.List;
import java.util.Random;

/**
 * An enumerated class which contains the possible sex
 * characteristics of the animal
 */
enum Sex {
    FEMALE, MALE;
}

/**
 * A class representing shared characteristics of animals.
 *
 * @version 28/02/2021
 */
public abstract class Animal extends LivingThing {

    // The animal's food level, which is increased by eating their food type.
    private int foodLevel;
    // Denotes the sex characteristics of the animal;
    private Sex sex;
    // The food type the animal consumes
    private List <String> food;
    // A boolean which represents if an animal is awake
    private boolean awake;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal, with a name to denote its species, at location in field. The
     * animal can either be created a random age, or as a newborn.
     * 
     * @param randomAge If true, the animal will have a random age.
     * @param name The name of the animal species
     * @param food An list of the names of the food organisms an animal can eat
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease an animal has when it is created
     */
    public Animal(boolean randomAge, String name, List<String> food, Field field, Location location, Disease disease) {
        super(name, field, location, disease);

        this.food = food;
        setSex();

        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            foodLevel = rand.nextInt();
        }
        else {
            setAge(0);
            foodLevel = getInitialEnergy();
        }
    }

    /**
     * Checks if two animals which are able to breed with each other,
     * if they can they give birth to a litter of babies
     * @param animal The animal to breed with the current animal
     * @param newAnimals A list to place in the animal babies
     */
    protected void meet(Animal animal, List<Animal> newAnimals) {
        if (animal.getSex() != sex && canBreed() && animal.canBreed() &&  rand.nextDouble() <= getBreedingProbability()) {
            animal.beenMatedWith(getDisease());
            beenMatedWith(animal.getDisease());
            giveBirth(newAnimals);
        }
    }       
    
    /**
     * Makes the animal act, all animals initially move and then check if the adjacent
     * organisms can be consumed or mated with
     * It also increments the animals age and hunger and checks if the animal should be asleep
     * or awake
     * @param newAnimals A list to receive newly born animals.
     */
    protected void act(List<Animal> newAnimals, int time, double visibility) {
        sleepSchedule(time);  
        
        if(isAlive() && awake) {
            incrementAge();
            incrementHunger();  

            move();   
            
            List<LivingThing> organisms = getNeighbouringLivingThings();
            
            for (LivingThing organism : organisms) {
                //Checks if the adjacent organism is consumable
                if (food.contains(organism.getName().toLowerCase())) {  
                    Location foodLocation = organism.getLocation();
                    consume(organism, visibility);
                    setLocation(foodLocation);
                    return;
                }
                //Checks if the adjacent organism can be mated with
                else if (organism.getName().toLowerCase().equals(getName())) {
                    if (organism instanceof Animal) {
                        Animal animal = (Animal) organism;
                        meet(animal, newAnimals);
                        return;
                    }
                }
            }
        
        }
    }

    /**
     * Allows an animal to consume an organism which increases
     * the animal's energy and kills the organism
     * @param organism The organism the animal will consume
     * @param visibility The visibility, which denotes if an animal can see enough to eat
     */
    private void consume(LivingThing organism, double visibility) {
        if (rand.nextDouble() <= visibility){
            foodLevel += organism.getFoodValue();
            organism.setDead();
        }
        if (foodLevel > getMaxFoodLevel()) {
            foodLevel = getMaxFoodLevel();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    private void incrementHunger() {   
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Changes the awake status of the animal dependent on the current hour
     * @param time The current hour time
     */
    protected void sleepSchedule(int time) {
        if (time == getHourWakeUp()) {
            setAwake();
        }
        if (time == getHourFallAsleep()) {
            setAsleep();
        }
    }

    /**
     * Finds a free adjacent location to the animal, if there are free
     * locations, then the animal will choose randomly which one to move
     * to
     * @return true if the animal manages to move, false otherwise
     */
    private void move() {
        Location randLocation = getField().getRandomSteppableLocations(getLocation());
        getField().clear(getLocation());

        if (randLocation != null) {
            setLocation(randLocation);
        }      
    }

    /**
     * Checks that if two animals that meet are of the opposite 
     * sex then they can breed
     * @param newAnimals A list where the newly created animals can be stored
     * @return Returns true if the animals have successfully mated, 
     * false otherwise
     */
    protected void giveBirth(List<Animal> newAnimals) {
        List<Location> free = getField().getFreeAdjacentLocations(getLocation());

        // Generate a number representing the number of births, the number of births
        // may be zero
        int births = rand.nextInt(getMaxLitterSize()) + 1;;

        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newAnimals.add(birth(loc));
        }
    }

    /** 
     * @return returns 0 or 1 with equal probability  
     */
    static int randEvenProb() { 
        return (int) (10 * Math.random()) & 1; 
    } 

    /**
     * Sets the sex characteristics of the animal, with an
     * random equal probability the animal is either male or female
     */
    protected void setSex() {
        if (randEvenProb() == 0) {
            sex = Sex.FEMALE;
        }
        else {
            sex = Sex.MALE;
        }
    }
    
    /**
     * Gives the animal the disease of the other animal they have mated with, 
     * if the other animal has a disease
     * @param diseaseStatus The held disease of the animal they are mating with
     */
    protected void beenMatedWith(Disease diseaseStatus) {
        giveDisease(diseaseStatus);
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed() {
        return getAge() >= getBreedingAge();
    }

    /**
     * Makes the animal be awake
     */
    protected void setAwake() {
        awake = true;
    }

    /**
     * Makes the animal be asleep
     */
    protected void setAsleep() {
        awake = false;
    }

    /**
     * @return sex The sex characteristics of the animal
     */
    private Sex getSex() {
        return sex;
    }

    /**
     * @return foodLevel The current energy of the animal
     */
    private int getFoodLevel() {
        return foodLevel;
    }   

    /**
     * @return awake A boolean stating whether an animal is awake
     */
    protected boolean getAwake() {
        return awake;
    }

    /**
     * @return MAX_AGE The max age of an animal.
     */
    protected abstract int getMaxAge();

    /**
     * Return the breeding age of an animal. They cannot breed until they have reached this age.
     * @return BREEDING_AGE The breeding age of an animal.
     */
    protected abstract int getBreedingAge();

    /**
     * @return FOOD_VALUE The food value of an animal if it is eaten.
     */
    protected abstract int getFoodValue();

    /**
     *@return BREEDING_PROBABILITY The probability of an animal breeding.
     */
    protected abstract double getBreedingProbability();

    /**
     * @return MAX_LITTER_SIZE The maximum litter size of an animal.
     */
    protected abstract int getMaxLitterSize();

    /**
     * Return a birthed animal.
     * @param location The location where the new animal should be born in
     * @return a new animal baby.
     */
    protected abstract Animal birth(Location location);

    /**
     * @return The inital food level of an animal.
     */
    protected abstract int getInitialEnergy();

    /**
     * @return The hour an animal falls asleep (24hr clock)
     */
    protected abstract int getHourFallAsleep();

    /**
     * @return The hour an animal wakes up (24hr clock)
     */
    protected abstract int getHourWakeUp();

    /**
     * @return The maximum amount of energy an animal can have
     */
    protected abstract int getMaxFoodLevel();
}
