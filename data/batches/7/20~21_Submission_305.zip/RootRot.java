/**
 * A model of the disease Root Rot.
 *
 * @version 28/02/21
 */
public class RootRot extends Disease {
    
    // The number of years, by which an animal that gets root rot, life is shortened
    private static final int LIFE_SHORTENING_FACTOR = 10;
    // The chance of one affected plant spreading root rot 
    // to another plant which can be affected
    private static final double DISEASE_SPREAD_PROBABILITY = 0.3;

    /**
     * Create a new instance of RootRot called rootRot, which can affect
     * the plants grass and flower
     */
    public RootRot() {
        super("rootRot", new String[] {"grass", "flower"});                
    }
    
    /*
     * @return LIFE_SHORTENING_FACTOR The number of years, which a plant's life is shortened
     */
    protected int getLifeShorteningFactor(){
        return LIFE_SHORTENING_FACTOR;
    }

    /*
     * @return DISEASE_SPREAD_PROBABILITY The chance of the disease spreading
     */
    protected double getDiseaseSpreadProbability() {
        return DISEASE_SPREAD_PROBABILITY ;
    }
}
