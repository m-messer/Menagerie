import java.util.Arrays;

/**
 * A general model of a disease
 *
 * @version 28/02/21
 */
public abstract class Disease {   

    // The name of the disease
    private String name;  
    // The names of the organisms the diease can affect  
    private String[] organismsAffected;

    /**
     * A new diease is created with a name and an array of the names of the
     * organisms it can affect
     * @param name The name of the disease
     * @param organismsAffected An array of the names of the organisms affected
     */
    public Disease(String name, String[] organismsAffected) {
        this.name = name;    
        this.organismsAffected = organismsAffected;
    }                
    
    /**
     * Checks if an organism can be affected by the disease
     * @param name The name of the organism to check
     * @return True if the organism can be affected by the disease, false otherwise
     */
    protected boolean canAffect(String name) {
        boolean contains = Arrays.stream(organismsAffected).anyMatch(name::equals);
        return contains;
    }

    /**
     * @return The number of years, which an animal's life is shortened
     */
    protected abstract int getLifeShorteningFactor();

    /**
     * @return The chance of the disease spreading
     */
    protected abstract double getDiseaseSpreadProbability();
}
