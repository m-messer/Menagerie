import java.util.List;
import java.util.ArrayList;

/**
 * This class represents all living things in the field.
 *
 * @version 14/02/21
 */
public abstract class LivingThing {

    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // Classification of organism
    private String name;
    // The organism's age.
    private int age;
    // The disease the living thing has, if any.
    private Disease disease;
    
    /**
     * Create a new living thing. 
     * 
     * @param name The name of the living thing.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this organism is carrying, if any. 
     */
    public LivingThing(String name, Field field, Location location, Disease disease) {
        this.name = name;
        alive = true;
        this.field = field;
        
        giveDisease(disease);
        setLocation(location);
    }

    /**
     * Return a list of other neighbouring living things to this one.
     * @return List<LivingThing> A list of neighbouring living things in relation to this one.
     */
    protected List<LivingThing> getNeighbouringLivingThings() {
        List<LivingThing> organisms = new ArrayList<>();
        List<Location> locations = field.adjacentLocations(location);

        for (Location local : locations) {
            if (field.getObjectAt(local) instanceof LivingThing) {
                LivingThing organism = field.getObjectAt(local);
                organisms.add(organism);
            }
        }
        return organisms;
    }  

    /**
     * Give this organism the disease or set disease to null if it doesnt have a disease.
     * @param diseaseStatus The disease to be given to the animal
     */
    protected void giveDisease(Disease diseaseStatus) {
        if (diseaseStatus != null && diseaseStatus.canAffect(name)){
            disease = diseaseStatus;
            diseaseEffects();
        }
        else {
            disease = null;
        }
    }

    /**
     * Increase the age.
     * This could result in the organism's death.
     */
    protected void incrementAge() {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Implement the effects of the disease the organism has, if it has one. 
     * At this point, the only effects a disease has is shortening life.
     */
    protected void diseaseEffects() { 
        if (disease!=null){
            age+=disease.getLifeShorteningFactor();
        }
    }
    
     /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation) {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        field.clear(location);
    }
    
    /**
     * Set the age of this organism.
     * @param n Age to set the animal to
     */
    protected void setAge(int n) {
        age = n;
    }
    
    /**
     * @return location The organism's location.
     */
    protected Location getLocation() {
        return location;
    }    
    
    /**
     * @return The organism's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * @return the classification of the organism.
     */
    protected String getName() {
        return name;
    }

    /**
     * @return true if the animal is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }    
    
    /**
     * @return disease The disease the organism has or null if it doesn't have one.
     */
    protected Disease getDisease() {
        return disease;
    }
       
    /**
     * @return age The age of the organism.
     */
    protected int getAge() {
        return age;
    }

    /**
     * @return the food value of the organism.
     */
    protected abstract int getFoodValue();
    
    /**
     * @return the maximum age of an organism.
     */
    protected abstract int getMaxAge(); 
}
