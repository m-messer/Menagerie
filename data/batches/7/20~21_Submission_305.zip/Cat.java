import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * A model of the animal Cat.
 *
 * @version 15/02/2021
 */
public class Cat extends Nocturnal {
    // Characteristics shared by all cats

    // The age at which a cat can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a cat can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a cat breeding.
    private static final double BREEDING_PROBABILITY = 0.34;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // Food value of a the cat if it was eaten
    private static final int FOOD_VALUE = 4;
    // The initial food level of a cat.
    private static final int INTIAL_ENERGY = 7;
    // The maximum amount of energy a cat can have;
    private static final int MAX_FOOD_LEVEL = 20;

    //a List of food the cat can eat.
    private static final List<String> food = new ArrayList<>(Arrays.asList("lizard"));

    /**
     * Create a new cat.
     * 
     * @param randomAge If true, the cat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param disease The disease this cat is carrying, if any.
     */
    public Cat(boolean randomAge, Field field, Location location, Disease disease) {
        super(randomAge, "cat", food, field, location, disease);
    }

    /**
     * @return MAX_AGE The max age of a cat.
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the breeding age of a cat. They cannot breed until they have reached this age.
     * @return BREEDING_AGE The breeding age of a cat.
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return FOOD_VALUE The food value of a cat.
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * @return MAX_LITTER_SIZE The maximum litter size of a cat.
     */
    protected int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     *@return BREEDING_PROBABILITY The probability of a cat breeding.
     */
    protected double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return INTIAL_ENERGY The inital food level of a cat.
     */
    protected int getInitialEnergy() {
        return INTIAL_ENERGY;
    }

    /**
     * @return The maximum amount of energy an animal can have
     */
    protected int getMaxFoodLevel() {
        return MAX_FOOD_LEVEL;
    }

    /**
     * Return a birthed animal.
     * @param location The location where the new animal should be born in
     * @return a new cat object.
     */
    protected Animal birth(Location location) {
        return (new Cat(false, getField(), location, getDisease()));
    }
}
