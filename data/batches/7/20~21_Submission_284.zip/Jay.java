import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Jay.
 * Jays age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Jay extends Organism
{
    // Characteristics shared by all Jays (class variables).

    // The age at which a Jay can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a Jay can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a Jay breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    //How much an infection will affect this animal
    private static final int INFECTION = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    private static final int SUNFLOWER_FOOD_VALUE = 30;
    // The Jay's age.
    private int age;
    // The jays food level increased by eating sunflowers
    private int foodLevel;
    /**
     * Create a new Jay. A Jay may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Jay will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Jay(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SUNFLOWER_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SUNFLOWER_FOOD_VALUE;
        }
    }

    /**
     * This is what the Jay does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newJays A list to return newly born Jays.
     */
    public void act(List<Organism> newJays)
    {
        incrementAge();
        if (getDaylight() == false)
        {
            return;
        }
        
        incrementHunger();
        if(isAlive()) {
            giveBirth(newJays);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    private Location findFood()
    {
        if (foodLevel > 100) {
            return null;
        }        
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Sunflower) {
                Sunflower sunflower = (Sunflower) Organism;
                if(sunflower.isAlive()) { 
                    sunflower.setDead();
                    if (sunflower.getInfected() == true)
                    {
                        setInfected();
                    }
                    foodLevel += SUNFLOWER_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Increase the age.
     * This could result in the Jay's death.
     */
    private void incrementAge()
    {
        age++;
        if(getInfected() == true && age > MAX_AGE - INFECTION)
        {
            setDead();
        }
        else if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this Jay is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newJays A list to return newly born Jays.
     */
    private void giveBirth(List<Organism> newJays)
    {
        // New Jays are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        Iterator<Location> it = free.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Jay) {
                Jay jay = (Jay) Organism;
                boolean gender1 = genderCheck();
                boolean gender2 = jay.genderCheck();
                if(jay.isAlive() && isAlive() && (gender1 != gender2) ) { 
                    if (jay.getInfected() == true)
                    {
                        setInfected();
                    }
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Jay young = new Jay(false, field, loc);
                        newJays.add(young);
                    }
                }
            }
        }

    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Jay can breed if it has reached the breeding age.
     * @return true if the Jay can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
