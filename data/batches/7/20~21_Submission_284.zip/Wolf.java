import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Wolves.
 * Wolveses age, move, eat Jays, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Organism
{
    // Characteristics shared by all wolves (class variables).
    
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single Jay. In effect, this is the
    // number of steps a Wolves can go before it has to eat again.
    private static final int JAY_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Wolves's age.
    private int age;
    // The Wolves's food level, which is increased by eating Jays.
    private int foodLevel;

    /**
     * Create a Wolf. A Wolves can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Wolves will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(JAY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = JAY_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Wolf does most of the time: it hunts for
     * Jays. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWolves A list to return newly born Wolves.
     */
    public void act(List<Organism> newWolves)
    {
        incrementAge();
        if (getDaylight() == true){
            return;
        }
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWolves);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the Wolves's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Wolves more hungry. This could result in the Wolves's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for Jays adjacent to the current location.
     * Only the first live Jay is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if (foodLevel > 50) {
            return null;
        }
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Jay) {
                Jay jay = (Jay) Organism;
                if(jay.isAlive()) { 
                    if (jay.getInfected() == true)
                    {
                        setInfected();
                    }
                    jay.setDead();
                    foodLevel += JAY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolveses A list to return newly born Wolves.
     */
    private void giveBirth(List<Organism> newWolves)
    {
        // New Wolveses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        Iterator<Location> it = free.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Jay) {
                Wolf wolf = (Wolf) Organism;
                boolean gender1 = genderCheck();
                boolean gender2 = wolf.genderCheck();
                if(wolf.isAlive() && isAlive() && (gender1 != gender2) ) { 
                    if (wolf.getInfected() == true)
                    {
                        setInfected();
                    }
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Wolf young = new Wolf(false, field, loc);
                        newWolves.add(young);
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Wolves can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
