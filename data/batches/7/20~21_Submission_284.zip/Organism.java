import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of Organisms.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Organism
{
    // Whether the Organism is alive or not.
    private boolean alive;
    // The Organism's field.
    private Field field;
    // The Organism's position in the field.
    private Location location;
    //Whether Organism is male or female
    private boolean isMale;
    // whether it is currently daytime or not
    private boolean daylight;
    //To retrieve a daylight value
    private boolean isInfected;
    //instance of the simulator
    private Simulator simulator;
    //current weather of the simulation
    private String condition;
    /**
     * Create a new Organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        Random rand = new Random();
        isMale = rand.nextBoolean();
        isInfected = (rand.nextInt(100) == 1);
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * @return true if organism is infected, false if not
     */
    protected boolean getInfected()
    {
        return isInfected;
    }
    
    /**
     * Sets isInfected value to true of organism 
     */
    protected void setInfected()
    {
        isInfected = true;
    }
    
    /**
     * Make this Organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born Organisms.
     */
    abstract public void act(List<Organism> newOrganisms);
   
    /**
     * return whether the Organism is a male or female
     * @return true if the Organism is a male
     */
    protected boolean genderCheck()
    {
        return isMale;
    }
    
    /**
     * Check whether the Organism is alive or not.
     * @return true if the Organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the Organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the Organism's location.
     * @return The Organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Returns whether it is day time or not
     * @return true if it is daytime
     */
    protected boolean getDaylight()
    {
        daylight = simulator.getDaylight();
        return daylight;
    }
    
    /**
     * Returns current weather conditions
     * @return weather conditions
     */
    protected String getWeather()
    {
        condition = simulator.getWeather();
        return condition;
    }
    
    /**
     * Place the Organism at the new location in the given field.
     * @param newLocation The Organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the Organism's field.
     * @return The Organism's field.
     */
    protected Field getField()
    {
        return field;
    }
}
