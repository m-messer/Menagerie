import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing jays and Wolfes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.05;
    // The probability that a jay will be created in any given grid position.
    private static final double JAY_CREATION_PROBABILITY = 0.3; 
    // The probability that a coyote will be created in any given grid postion
    private static final double COYOTE_CREATION_PROBABILITY = 0.05;
    //The probability a deer will be created on the grid
    private static final double DEER_CREATION_PROBABILITY = 0.2;
    //the probability a lion will be created
    private static final double LION_CREATION_PROBABILITY = 0.05;
    //The probability a sunflower will be created
    private static final double SUNFLOWER_CREATION_PROBABILITY = 0.45;
    //The probability hay will be made
    private static final double HAY_CREATION_PROBABILITY = 0.35;
    //The time in the simulation
    private int time = 0;
    //Whether it is day or night right now
    private static boolean daylight;
    //curent weather of the simulation
    private static String condition = "Sunny";

    // List of Organisms in the field.
    private List<Organism> Organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    
 
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        Organisms = new ArrayList<>();
        field = new Field(depth, width);
     
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Jay.class, Color.BLUE);
        view.setColor(Wolf.class, Color.CYAN);
        view.setColor(Coyote.class, Color.RED);
        view.setColor(Deer.class, Color.MAGENTA);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Sunflower.class, Color.YELLOW);
        view.setColor(Hay.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Wolf and jay.
     */
    public void simulateOneStep()
    {
        step++;
   
        // Provide space for newborn Organisms.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all jays act.
        for(Iterator<Organism> it = Organisms.iterator(); it.hasNext(); ) {
            Organism Organism = it.next();
            Organism.act(newOrganisms);
            if(! Organism.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born Wolfes and jays to the main lists.
        Organisms.addAll(newOrganisms);
        updateTime();
        view.showStatus(step, field, condition);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        Organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, condition);
    }
    
    /**
     * change the time and daylight according to the step number
     */
    private void updateTime()
    {
        time = step % 24;
        if (time % 3 == 0){
            condition = changeWeather();
        }
        daylight = (time < 20 && time >5);
    }
    
    /**
     * @return weather condition
     */
    public static String getWeather()
    {
        return condition;
    }
    
    /**
     * radndomly select a weather from sunny, raining and snowing
     * @return return weather condition
     */
    public String changeWeather()
    {
        Random rand = new Random();
        int rng = rand.nextInt(3);
        switch(rng) {
            case 0:
            condition = "Sunny";
            break;
            case 1:
            condition = "Raining";
            break;
            case 2:
            condition = "Snowing";
            break;
        }
        
        return condition;
    }

    /**
     * get whether it is daytime or not
     * @return return daylight
     */
    public static boolean getDaylight()
    {
        return daylight;
    }
    
    /**
     * Randomly populate the field with Wolfes and jays.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf Wolf = new Wolf(true, field, location);
                    Organisms.add(Wolf);
                }
                else if(rand.nextDouble() <= JAY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Jay jay = new Jay(true, field, location);
                    Organisms.add(jay);
                }
                else if(rand.nextDouble() <= COYOTE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Coyote coyote = new Coyote(true, field, location);
                    Organisms.add(coyote);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    Organisms.add(deer);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    Organisms.add(lion);
                }
                else if(rand.nextDouble() <= SUNFLOWER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sunflower sunflower = new Sunflower(true, field, location);
                    Organisms.add(sunflower);
                }                
                else if(rand.nextDouble() <= HAY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hay hay = new Hay(true, field, location);
                    Organisms.add(hay);
                }                
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
