

/**
 * Interface enforcing the required for an animal that can be eaten
 */
interface Eatable {

	/**
	 * Should return the food value of an animal 
	 */
	public int getFoodValue();

}
