import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a zebra.
 * Zebras age, move, breed, and die.
 *
 * 
 * @version 18/02/19
 */
public class Zebra extends Animal
{
    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 200;
    private static final int INFECTED_MAX_AGE = 50;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();    
    private static final int WAKE_TIME = 11;//(wake at 5 AM)
    // The age to which a zebra can live.
    private static final int SLEEP_TIME = 19;//(Sleep at 7 AM)    
    // The zebra's age.
    private int age;
    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location,"zebra",50);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            setFoodLevel(rand.nextInt(250));
        }
        else {
            age = 0;
            setFoodLevel(250);
        }
        setPrey();
    }

    /**
     * Make this animal live, this method is different from the act method
     * As it takes into account WAKE_TIME and AND SLEEP_TIME, to define when the animal is awake.
     * If it is awake it will act. Otherwise, the animal grows old but does not act, IncrementAge() is called, but the rest of the act method isnt.
     *@param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */

    public void live(List<Organism> newAnimals)
    {
        incrementAge();
        if ((Simulator.getTime() <= (SLEEP_TIME + Simulator.getSleepModifier())) && (Simulator.getTime()>=(WAKE_TIME - Simulator.getSleepModifier())))
        {
            act(newAnimals);
        }
    }    

    /**
     * The Zebra's empty constructor, this method is used when creating the "Food Web " for all the Organisms, who can eat who.
     * Instead of creating a real Zebra object we simply make an empty one.
     * @param randomAge If true, the Lion will have a random age.
     */

    public Zebra(boolean randomAge)
    {
        super("zebra");
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }  

    /**
     * Increase the age.
     * This could result in the zebra's death.
     */
    protected void incrementAge()
    {
        age++;
        if(getInfected() && age > INFECTED_MAX_AGE){

            setDead();
        }
        else if(age > MAX_AGE) {

            setDead();
        }
    }

    /**
     * Check whether or not this zebra is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newZebras A list to return newly born zebras.
     * @param breedingModifier, changes breeding prob according to weather
     * If the parents were infected, the newborn will also be infected
     */
    protected void giveBirth(List<Organism> newZebras, double breedingModifier)
    {
        // New zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(breedingModifier);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Zebra young = new Zebra(false, field, loc);
            if (getInfected()){
                young.setInfected();
            }
            newZebras.add(young);
        }
    } 

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     * @param breedingModifier, changes breeding prob according to weather
     */
    protected int breed(double breedingModifier)
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= (BREEDING_PROBABILITY + breedingModifier)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A zebra can breed if it has reached the breeding age.
     * @return true if the zebra can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Adds animals to the list of "prey" for the current animal.
     */
    private void setPrey()
    {
        setEdible(new Grass());
    }
}

