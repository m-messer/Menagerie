import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Hunter.
 * Hunters move, eat, hunt, age , and die
 *
 * 
 * @version 18/02/19
 */
public class Hunter extends Animal
{
    // The age at which a Hunter can start to breed.
    private static final int BREEDING_AGE = 500;
    // The age to which a Hunter can live.
    private static final int MAX_AGE = 1000;
    // The age to which an infected Hunter can live.
    private static final int INFECTED_MAX_AGE = 500;
    // The likelihood of a Hunter breeding.
    private static final double BREEDING_PROBABILITY = 0.4 ;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    // The Hunter's age.
    private int age;
    // The Hunter's food level, which is increased by eating .
    private static final int WAKE_TIME = 10;//(wake at 5 AM)
    // The age to which a zebra can live.
    private static final int SLEEP_TIME = 20;//(Sleep at 7 AM)
    /**
     * Create a Hunter. A Hunter can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Hunter will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hunter(boolean randomAge, Field field, Location location)
    {
        super(field, location,"Hunter",10);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            setFoodLevel(rand.nextInt(5000)); 
        }
        else {
            age = 0;
            setFoodLevel(5000);
        }
        setPrey();
    }

    /**
     * The Hunter's empty constructor, this method is used when creating the "Food Web " for all the Organisms, who can eat who.
     * Instead of creating a real Hunter object we simply make an empty one.
     * @param randomAge If true, the Hunter will have random age and hunger level.
     */

    public Hunter(boolean randomAge)
    {
        super("Hunter");
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * Make this animal live, this method is different from the act method
     * As it takes into account WAKE_TIME and AND SLEEP_TIME, to define when the animal is awake.
     * If it is awake it will act. Otherwise, the animal grows old but does not act, IncrementAge() is called, but the rest of the act method isnt.
     *@param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */
    public void live(List<Organism> newHunters)
    {
        incrementAge();
        if ((Simulator.getTime() <= (SLEEP_TIME + Simulator.getSleepModifier())) && (Simulator.getTime()>=(WAKE_TIME - Simulator.getSleepModifier())))
        {
            act(newHunters);
            if (isAlive()){
                hunt();
            }
        }
    }

    /**

     * The hunter does not only move around with the find food method,
     * he also uses the hunt method everytime act is called. The hunt method lets him kil any Animal, up to 8 blocks away
     * using a modified version of the adjacentLocations() method.
     */
    public void hunt()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(),8);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Organism) {
                Organism prey = (Organism) organism;
                for(int i=0; i<getEdibleSize(); i++){
                    if(getEdible(i).getName().equals(prey.getName()) && prey.isAlive()){
                        prey.setDead();
                    }
                }                            
            }
        }
    }  
    
    /**
     * Increase the age. This could result in the Hunter's death.
     */
    protected void incrementAge()
    {
        age++;
        if(getInfected() && age > INFECTED_MAX_AGE){
            setDead();
        }
        else if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this Hunter is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHunters A list to return newly born Hunters.
     * @param breedingModifier, changes the BREEDING_PROBABILITY
     */
    protected void giveBirth(List<Organism> newHunters, double breedingModifier)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(breedingModifier);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hunter  young = new Hunter(false, field, loc);
            if (getInfected()){
                young.setInfected();
            }
            newHunters.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(double breedingModifier)
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= (BREEDING_PROBABILITY + breedingModifier)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Hunter can breed if it has reached the breeding age.
     * @return true if the hunter canbreed, else false
     * @param breedingModifier, changes the BREEDING_PROBABILITY
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }   

    /**
     * Adds animals to the list of "prey" for the current animal.
     */
    private void setPrey()
    {
        setEdible(new Zebra(false));
        setEdible(new Wolf(false));
        setEdible(new Sheep(false));
        setEdible(new Lion(false));
        setEdible(new Grass());
    }
}
