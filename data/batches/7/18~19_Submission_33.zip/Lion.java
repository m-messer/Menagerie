import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat , and die.
 *
 * 
 * @version 18/02/19
 */
public class Lion extends Animal
{
    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a lion can live.
    private static final int MAX_AGE = 500;
    // The age to which an infected lion can live.
    private static final int INFECTED_MAX_AGE = 60;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    // The lion's age.
    private int age;
    // The lion's food level, which is increased by eating .
    private static final int WAKE_TIME = 13;//(wake at 5 AM)
    // The age to which a zebra can live.
    private static final int SLEEP_TIME = 20;//(Sleep at 7 AM)
    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location,"lion",20);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            setFoodLevel(rand.nextInt(50)); 
        }
        else {
            age = 0;
            setFoodLevel(30);
        }
        setPrey();
    }
    
    /**
     * The Lion's empty constructor, this method is used when creating the "Food Web " for all the Organisms, who can eat who.
     * Instead of creating a real Lion object we simply make an empty one.     
     * @param randomAge If true, the Lion will have a random age.
     */
    public Lion(boolean randomAge)
    {
        super("lion");
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * Make this animal live, this method is different from the act method
     * As it takes into account WAKE_TIME and AND SLEEP_TIME, to define when the animal is awake.
     * If it is awake it will act. Otherwise, the animal grows old but does not act, IncrementAge() is called, but the rest of the act method isnt.
     *@param newAnimals A list to return newly born lions.
     */
    public void live(List<Organism> newAnimals)
    
    {
        incrementAge();
        if ((Simulator.getTime() <= (SLEEP_TIME + Simulator.getSleepModifier())) && (Simulator.getTime()>=(WAKE_TIME - Simulator.getSleepModifier())))
        {
            act(newAnimals);
        }
    }

    /**
     * Increase the age. This could result in the lion's death.
     */
    protected void incrementAge()
    {
        age++;
        if(getInfected() && age > INFECTED_MAX_AGE){

            setDead();
        }
        else if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     * @param breedingModifier, changes breeding prob according to weather
     */
    protected void giveBirth(List<Organism> newLions, double breedingModifier)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(breedingModifier);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion  young = new Lion(false, field, loc);
            if (getInfected()){
                young.setInfected();
            }
            newLions.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed. 
     * @return The number of births (may be zero).
     * @param breedingModifier, changes breeding prob according to weather
     */
    protected int breed(double breedingModifier)
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= (BREEDING_PROBABILITY + breedingModifier)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A lion can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }   

    /**
     * Adds animals to the list of "prey" for the current animal.
     */
    private void setPrey()
    {
        setEdible(new Zebra(false));        
        setEdible(new Sheep(false));
        setEdible(new Grass());
    }
}
