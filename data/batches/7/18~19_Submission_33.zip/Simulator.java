import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing all Organisms
 * @version 18/02/19
 */

public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;

    // The probability that different animals will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.015;
    private static final double ZEBRA_CREATION_PROBABILITY = 0.07;    
    private static final double GRASS_CREATION_PROBABILITY = 0.25;
    private static final double WOLF_CREATION_PROBABILITY = 0.008;
    private static final double POND_CREATION_PROBABILITY = 0.0008;
    private static final double SHEEP_CREATION_PROBABILITY = 0.1;
    private static final double HUNTER_CREATION_PROBABILITY = 0.001;
    

    //List of all possible weather patterns
    private List<String> weather;    

    private static String currentWeather;

    //Modifiers that change how the animals behave according to weather
    private static int HUNGER_MODIFIER;
    private static  double FERTILITY_MODIFIER;
    private static int SLEEP_MODIFIER;

    // List of animals in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //Time in simulation
    private static long time= 0;
    // Count of how many animals are infected 
    private static int infectedCounter;

    /**
     * Construct a simulation field with default size.
     * And choose a weather pattern
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        weather  = new ArrayList<>();
        addWeather();
        chooseWeather();
    }

    /**
     * Create a simulation field with the given size.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        weather  = new ArrayList<>();
        addWeather();
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // set organism colours
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Water.class, Color.BLUE);
        view.setColor(Wolf.class, Color.YELLOW);
        view.setColor(Hunter.class, Color.PINK);
        view.setColor(Sheep.class, Color.MAGENTA);

        chooseWeather();//Choose initial weather pattern
        reset();

    }

    /**
     * Iterates over every alive animal to check and see if it is infected, if it is we add it to the counter.
     * This method runs at the start of every step
     */
    private  void infectedCounter()
    {
        infectedCounter = 0;
        for (Organism org :organisms){
            if (org instanceof Animal && org.isAlive()){
                Animal org2 = (Animal) org;
                if(org2.getInfected()){
                    infectedCounter++;
                }
            }
        }
    }

    /**
     * The main method
     * Used to start the simulator without creating a simulator object
     */
    public static void main(String args[])
    {
        Simulator s = new Simulator();
        s.reset();
        s.runLongSimulation();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run the simulation for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(20); // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal
     * Increase the time with each step
     * Change the weather pattern every 24 hours (24 steps)
     */
    public void simulateOneStep()
    {
        step++;
        time++;
        time = time % 24;
        infectedCounter();
        if (time == 0 )
        {
            chooseWeather();
            changeWeatherConditions();
        }
        
        // list for all organisms created
        List<Organism> newOrganisms = new ArrayList<Organism>();        
        // invoke live method on all organisms
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organisms = it.next();
            organisms.live(newOrganisms);
            if(! organisms.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born organisms to the main list.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        field.clear();
        makePond();
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with all types of animals, and grass using their creation probabilities
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if (field.getObjectAt(location)== null){
                        Lion lion = new Lion(true, field, location);
                        organisms.add(lion);
                    }
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if (field.getObjectAt(location)== null){
                        Zebra zebra = new Zebra(true, field, location);
                        organisms.add(zebra);
                    }
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if (field.getObjectAt(location)== null){
                        Grass grass = new Grass(field, location);
                        organisms.add(grass);
                    }
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if (field.getObjectAt(location)== null){
                        Wolf wolf = new Wolf(true,field, location);
                        organisms.add(wolf);
                    }
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if (field.getObjectAt(location)== null){
                        Sheep sheep = new Sheep(true,field, location);
                        organisms.add(sheep);
                    }
                }
                else if(rand.nextDouble() <= HUNTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if (field.getObjectAt(location)== null){
                        Hunter hunter = new Hunter(true,field, location);
                        organisms.add(hunter);
                    }
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Randomly generates ponds on the field before placing down animals. The water organism does not move or act. 
     * We use a function to make the ponds as circles, with the center of the pond being one of the locations in the field. 
     * Any number of ponds can be generated but the probability is set with POND_CREATION_PROBABILITY
     */
    private void makePond()
    {
        field.clear();
        Random rand = Randomizer.getRandom();
        for(int row = 5; row < field.getDepth()-5; row++) {
            for(int col = 5; col < field.getWidth()-5; col++) {
                if (rand.nextDouble() <= POND_CREATION_PROBABILITY ){
                    for (int i = row-9; i <= row+9; i++) {
                        for (int j = col-9; j <= col+9; j++) {
                            if (j<=0 || j>= field.getWidth()|| i<=0 || i>= field.getDepth()){
                                break;
                            }

                            else if ((j-col)*(j-col)+ (i-row) *(i-row)   <= 10*10){
                                Location location = new Location(i, j);
                                Water water = new Water(field, location,"water", 1);
                                organisms.add(water);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Return the time int
     */
    protected static long getTime() 
    {
        return time;
    }

    /**
     * Return the time in a 24 hour format : 00:00
     */

    protected static String timeToString()
    {
        String output;
        if (time < 10){
            output ="0"+time+":00";
        }
        else{
            output = getTime() + ":00";
        }
        return output;
    }

    /**
     * Add all possible weathers to the list of weathers, Sun is repeated multiple 
     * times to increase the probability of it being sunny
     */

    private void addWeather (){
        weather.add("fog");
        weather.add("cold");
        weather.add("sun");
        weather.add("sun");
        weather.add("sun");
        weather.add("sun");
        weather.add("snow");
    }

    /** 
     * Changes the current weather pattern
     */

    private String chooseWeather()
    {
        addWeather();
        Random rand = new Random();
        int i = rand.nextInt(6) ;
        currentWeather = weather.get(i); 
        changeWeatherConditions();
        return currentWeather;
    }

    /**
     * Changes the Behaviour modifiers according to current weather pattern
     */

    private void changeWeatherConditions()
    {
        if(currentWeather.equals("sun")){
            resetWeather();  
        }
        else if(currentWeather.equals("fog")){
            resetWeather();
            SLEEP_MODIFIER=1;
        }
        else if(currentWeather.equals("cold")){
            resetWeather();
            HUNGER_MODIFIER = 1;
            FERTILITY_MODIFIER= -1.0;
        }
        else if(currentWeather.equals("snow")){
            resetWeather();
            HUNGER_MODIFIER = 1; // Animal get hungry faster in snow
            FERTILITY_MODIFIER= -1.0; // Animals cant breed in snow
            SLEEP_MODIFIER=1;   // Animals sleep less in snow
        }
    }

    /**
     * Reset weather to default conditions (sunny);
     */
    private void resetWeather()
    {
        HUNGER_MODIFIER =0;
        FERTILITY_MODIFIER=0.0;
        SLEEP_MODIFIER=0;
    }

    /**
     * Return the current weather pattern;
     */

    protected static String getCurrentWeather()
    {
        return currentWeather;
    }

    /**
     *  Returns the value of the Hunger modifier 
     *  This is used when changing the behaviour of the animals according to the weather.
     */

    public static int getHungerModifier()
    {
        return HUNGER_MODIFIER;
    }

    /**
     *  Returns the value of the fertility modifier 
     *  This is used when changing the behaviour of the animals according to the weather.
     */

    public static double getFertilityModifier()
    {
        return FERTILITY_MODIFIER;
    }

    /**
     *  Returns the value of the Sleep modifier . 
     *  This is used when changing the behaviour of the animals according to the weather.
     */

    public static  int getSleepModifier()
    {
        return SLEEP_MODIFIER;
    } 

    /**
     *Return the counter of how many animals are currently infected;
     */
    protected static int getInfectedCounter()
    {
        return infectedCounter;
    }
}
