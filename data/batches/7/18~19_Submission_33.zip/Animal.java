import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * 
 * @version 18/02/19
 */
public abstract class Animal extends Organism
{
    // The sex of the animal
    private boolean isMale; 
    private Random sex = new Random();   
    // The animals hunger level, how much it has eaten
    private int foodLevel;
    // Whether or not the animal is infected
    private boolean isInfected; 
    //Probability of animals getting infected randomly at any step
    private static double INFECTION_PROBABILITY = 0.00005;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param food The amount of food given to animal thats eats this animal. The foodWorth or foodValue of any given animal.
     * This changes according to the species. (Each species is worth a different amount of food)
     */
    public Animal(Field field, Location location,String name, int food)
    {
        super(field, location,name,food);
        this.isMale = sex.nextBoolean();
        isInfected = false;

    }

    /**
     * The Animals's empty constructor, this method is used when creating the "Food Web " for all the Organisms, who can eat who.
     * Instead of creating a real Animal object we simply make an empty one.
     */

    public Animal(String name)
    {
        super(name);
    }
    
    /**
     * Make this animal live, this method is different from the act method
     * As it takes into account WAKE_TIME and AND SLEEP_TIME, to define when the animal is awake.
     * If it is awake it will act. Otherwise, the animal grows old but does not act, IncrementAge() is called, but the rest of the act method isnt.
     *@param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */
    abstract public void live(List<Organism> newOrganism);
    
    /**
     * Make this animal act - that is: make it do
     * what it is supposed to do. 
     * @param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */
    public void act(List<Organism> newAnimals)
    {
        incrementHunger();
        beInfected();
        if(isAlive()) {
            checkForPartner(newAnimals);
            //giveBirth(newLions);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Random probability of infecting any number of animals on every step
     */

    protected void beInfected()
    {
        Random rand = new Random();
        if (rand.nextDouble() <= INFECTION_PROBABILITY)
        {isInfected = true;
        }
    }

    /**
     * Make the animals grow old with each step
     */
    protected abstract void incrementAge();

    /**
     * Check whether or not two animals are of the same species, both able to reproduce, and of opposite sex.
     * Also this method will infect the mate of the animal if one of them is Infected.
     */
    protected void checkForPartner(List<Organism> newAnimals){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal){
                Animal mate = (Animal) animal;
                if (isInfected){
                    mate.setInfected();
                }
                else if (mate.getInfected()){
                    setInfected();
                }
                if(mate.getClass().equals(getClass())) {
                    if(getSex() ==! mate.getSex()){
                        giveBirth(newAnimals,Simulator.getFertilityModifier());
                    }
                }
            }
        }
    }

    /**
     * If checkForPartner was passed, using the LITTER_SIZE and the BREEDING_PROBABILITY there is a chance 
     * the animals will giveBirth to a new set of Animals/Organisms.  If one of the parents were infected, the the newborn baby will be aswell.
     */
    protected abstract void giveBirth(List<Organism> newAnimals, double breedingModifier);

    /**
     * Generate a number representing the number of births,
     * if it can breed. 
     * @return The number of births (may be zero).
     * @param breedingModifier, changes breeding prob according to weather
     */
    protected abstract int breed(double breedingModifier);

    /**
     * Look for animals adjacent to the current location.
     * If the animal is prey and is alive, only the first one is eaten (killed)
     * It's foodValue is added to the current animals food Level, essentially feeding the animal..
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Organism) {
                Organism prey = (Organism) organism;
                for(int i=0; i<getEdibleSize(); i++){
                    if(getEdible(i).getName().equals(prey.getName()) && prey.isAlive()){
                        prey.setDead();
                        setFoodLevel(getFoodLevel()+ prey.getFoodValue());
                        return where;
                    }
                }                            
            }
        }
        return null;
    }   

    /**
     * Make the animal get hungry with each step, The animal also get hungry faster according to the weather pattern
     * This is done by modifying the value of HUNGER_MODIFIER;
     */

    protected void incrementHunger()
    {
        setFoodLevel(getFoodLevel()-(1 + Simulator.getHungerModifier()));
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }

    /**
     * Make an animal infected
     */
    protected void setInfected()
    {
        isInfected = true;
    }

    /**
     * Chekc if an animal isInfected
     * @return true if the animal is infected
     */
    protected boolean getInfected()
    {
        return isInfected;
    }

    /**
     * Check if an animal IsMale
     * @return true if the animal is male
     */
    protected boolean getSex()
    {
        return isMale;
    }

    /**
     * Get the animal's hunger/food level
     * @return int the animal's current foodLevel
     */
    protected int getFoodLevel()
    { 
        return foodLevel;  
    }

    /**
     * Change the food Level
     * @param int, the value to which we should change the foodLevel 
     */
    protected void setFoodLevel(int level)
    { 
        foodLevel = level; 
    }
}
