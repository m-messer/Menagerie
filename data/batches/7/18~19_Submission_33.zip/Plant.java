import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;
/**
 * Simple model of a plant
 * Represents all shared characteristics of a Plant
 *
 * 
 * @version 18/02/19
 */

public abstract class Plant extends Organism
{
    /**
     * Constructor for objects of class Plant
     * @param food is the food value of the plant 
     * @param name is the name of the plant
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location,String name, int food)
    {
        super(field,location, name ,food);
    }

    /**
     * Empty constructor to set edibles
     * @param name set the name of the animal.
     */
    public Plant(String name)
    {
        super(name);
    }
    
    /**
     * abstract method to simulate plant growth
     * @param newPlant is a list of organisms
     */
    protected abstract void grow(List<Organism> newPlant);
    
    /**
     * abstract method to simulate plants living
     * @param newPlant is a list of organisms
     */
    protected abstract void live(List<Organism> newOrganism);
    
    /**
     * Makes the plant grow, similar to reproduction of animals except we don't need a partner. 
     * Plants reproduce on their own
     * @param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */
    public void act(List<Organism> newPlants) 
    {
        grow(newPlants);
    }
}

