import java.util.List;
/**
 * Water objects
 * Water does not do anything except fill up a location in the field
 *
 * 
 * @version 18/02/19
 * 
 */
public class Water extends Organism
{   
     /**
     * Create a Water block can be created as a new born 
     * @param int food, how much foodValue the water has, how much it will feed another animal when eaten
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Water(Field field, Location location,String name, int food)
    {
        // initialise instance variables
        super(field,location, name ,food);        
    }    
    
    /**
     * Water does not move, die or act in any way so both the act method are empty
     */
    public void act(List<Organism> newWater)
    {
    }

    /**
     * Water does not move, die or act in any way so both the live method are empty
     */
    public void live(List<Organism> newWater)
    {
    }           
}
