import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;
/**
 * Represents all shared characteristics of an Organism
 * 
 *
 * 
 * @version 18/02/19
 */
public abstract class Organism
{
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    private List<Organism> edible;

    private String name;

    private int foodValue;

    /**
     * constructor for organisms
     * 
     * @param name is the name of the organsism
     * @param food is the food value of the organism
     * @param field The field currently occupied.
     * @param location The location within the field.
     */    
    public Organism(Field field, Location location, String name, int food)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        edible = new ArrayList<>();
        this.name = name;
        this.foodValue = food;  
    }
    
    /**
     * constructor for organisms
     * 
     * @param name is the name of the organsism
     */  
    public Organism(String name)
    {
        alive = true;       
        edible = new ArrayList<>();
        this.name = name;
    }
    
    /**
     * abstract method to make organisms act
     * @param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */
    abstract public void act(List<Organism> newOrganism);
    
    /**
     * abstract method to make organisms live
     * @param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */
    abstract protected void live(List<Organism> newOrganism);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the Organism at a certain index in the edible list#
     * @return Organism to return
     * @param index, index in list to return
     */
    protected Organism getEdible(int index)
    {
        return edible.get(index);
    }
    
    /**
     * Adds an organism to the list of edible organisms 
     */
    protected void setEdible(Organism organism)
    {
        
        edible.add(organism);
    }
    
    /**
     * @return the size of the edible list
     */
    protected int getEdibleSize()
    {
        return edible.size();
    }
    
    /**
     * @Return the name of an Organism
     */
    protected String getName()
    {
        return name;
    }
    
    /**
     * @return int foodValue of an organism
     */
    protected int getFoodValue()
    {
        return foodValue;
    }
}
