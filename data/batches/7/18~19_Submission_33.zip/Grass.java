import java.util.List;
import java.util.Random;
import java.util.Iterator;
/** 
 *Simple model of a Grass
 * Grass grows
 * 
 *
 * 
 * @version 18/02/19
 */
public class Grass extends Plant
{
    // instance variables - replace the example below with your own
    // instance variables - replace the example below with your own
    private static final Random rand = Randomizer.getRandom();

    private static final double BREEDING_PROBABILITY = 1.0;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;

    private static final int WAKE_TIME = 1;
    
    private static final int SLEEP_TIME = 24;

    /**
     * Constructor for objects of class Grass
     * @param field The field currently occupied.
     * @param location The location within the field.
     */

    public Grass(Field field, Location location)
    {
        super(field, location,"grass",25);
    }
    
    /**
     * The Grass's empty constructor, this method is used when creating the "Food Web " for all the Organisms, who can eat who.
     * Instead of creating a real grass object we simply make an empty one.
     */

    public Grass()
    {
        super("grass");
    }
    
    /**
     * Make this animal live, this method is different from the act method
     * As it takes into account WAKE_TIME and AND SLEEP_TIME, to define when the animal is awake.
     * If it is awake it will act. Otherwise, the animal grows old but does not act, IncrementAge() is called, but the rest of the act method isnt.
     *@param newPlants, list of Organisms where the new borns organisms will be places (if they are born)
     */
    

    protected void live(List<Organism> newPlants)
    {
        if ( Simulator.getTime() <= SLEEP_TIME && Simulator.getTime()>=WAKE_TIME){
            if(isAlive()){
                act(newPlants);
            }            
        }
    }
    
    /**
     * Makes the grass grow, similar to reproduction of animals except we don't need a partner. 
     * Grass reproduces on its own
     * @param newOrganism, list of Organisms where the new borns organisms will be places (if they are born)
     */
    protected void grow(List<Organism> newPlants)
    {
        Field field = getField();        
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(field,loc);
            newPlants.add(young);
        }    
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.     
     * @return The number of births (may be zero).
     * 
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
