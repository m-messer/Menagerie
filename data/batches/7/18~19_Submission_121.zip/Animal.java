import java.util.Random;

/**
 * Abstract class Animal - A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public abstract class Animal extends Creatures
{
    // The animal's gender.
    protected boolean isFemale;
    
    /**
     * Create a new animal at location in field.
     * @param isAnimal Whether the creature is an animal.
     * @param animalsField The state of the animals' field.
     * @param plantsField The state of the plants' field.
     * @param location The location within the field.
     */
    public Animal(boolean isAnimal, Field animalsField, Field plantsField, Location location)
    {
        super(isAnimal, animalsField, plantsField, location);
        this.isFemale = isFemale;
        setGender();
        setLocation(location);
    }

    /**
     * Decide whether the animal is a male or female.
     */
    protected void setGender()
    {
        isFemale = rand.getBoolean();
    }
    
    /**
     * Check the gender of the animal.
     * @return true if the animal is a female.
     */
    protected boolean getIsFemale()
    {
        return isFemale;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            animalsField.clear(location);
            location = null;
            animalsField = null;
        }
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            animalsField.clear(location);
        }
        location = newLocation;
        animalsField.place(this, newLocation);
    }
}
