import java.util.Random;

/**
 * Abstract class Plant - A class representing shared characteristics of plants.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public abstract class Plant extends Creatures
{
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    protected double growthValue;
    
    /**
     * Create a new plant at location in field.
     * 
     * @param isAnimal Whether this creature is an animal. 'false' in this case.
     * @param plantsField The state of the plants' field.
     * @param animalsField The state of the animals' field.
     * @param location The location within the field.
     */
    public Plant(boolean isAnimal, Field plantsField, Field animalsField, Location location)
    {
        super(isAnimal, plantsField, animalsField, location);
        setGrowthValue();
        setLocation(location);
    }
    
    /** 
     * To calculate the growth value of all plants.
     */
    protected void setGrowthValue()
    {
        growthValue = (rainfall + sunlight)/2;
    }
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            plantsField.clear(location);
            location = null;
            plantsField = null;
        }
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            plantsField.clear(location);
        }
        location = newLocation;
        plantsField.place(this, newLocation);
    }
}
