import java.util.List;
import java.util.Random;

/**
 * A simple model of grass.
 * Grass age, reproduce and die.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public class Grass extends Plant
{
    // The age at which grass can start to breed.
    private static final int REPRODUCTION_AGE = 3;
    // The likelihood of grass breeding.
    private static final double REPRODUCING_PROBABILITY = 0.27;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The growth rate of grass.
    private static final double GROWTH_RATE = 1.05;
    // The age to which grass can live.
    private static final int MAX_AGE = 40;
    // The maximum size to which grass can grow, grass will stop growing when it reaches this size.
    private static final int MAX_SIZE = 10;
    // A shared random number generator to control reproducing.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The grass's age.
    private int age;
    // The grass's size.
    private double size;
    // The grass's food value.
    private double foodValue;
    
    /**
     * Create grass. Grass can be reproduced asexually.
     * The newly grown grass will have a size of 0.
     * 
     * @param randomAge If true, the grass will have random age.
     * @param isAnimal Whether this creature is an animal. 'false' in this case.
     * @param plantsField The state of the plants' field.
     * @param animalsField The state of the animals' field.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, boolean isAnimal, Field plantsField, Field animalsField, Location location)
    {
        super(isAnimal, plantsField, animalsField, location);
        age = 0;
        size = 0;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            size = rand.nextInt(3);
        }
    }

    /**
     * This is what grass does most of the time: it grows and reproduces.
     * In the process, it might die of old age.
     * @param newGrass A list to return newly grown grass.
     */
    public void act(List<Creatures> newGrass)
    {
        super.setGrowthValue();
        if(isAlive() && !isNight) {
            growNew(newGrass);
            grow();
        }
    }
    
    /**
     * The parent grass will reproduce here.
     * New growns will be made into free adjacent locations.
     * @param newGrass A list to return newly grown grass.
     */
    private void growNew(List<Creatures> newGrass)
    {
        // New mice are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getPlantsField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(true, false, plantsField, animalsField, loc);
            newGrass.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can reproduce.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canReproduce() && rand.nextDouble() <= REPRODUCING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A grass can reproduce if it has reached the reproduction age.
     * @return true if the grass can reproduce, false otherwise.
     */
    private boolean canReproduce()
    {
        return age >= REPRODUCTION_AGE;
    }
    
    /**
     * Grass will grow in size and age in every step.
     * The size is determined by the growthValue.
     */
    private void grow()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
        
        if(size < MAX_SIZE) {
            size *= (1+ growthValue/10);
        }
    }
    
    /**
     * The food value of grass is calculated here.
     * It is proportional to the size of the grass.
     */
    public double getFoodValue()
    {
        // the food value of grass is calculated
        // using the formula y = mx + c.
        foodValue = size + 8;
        return foodValue;
    }
}
