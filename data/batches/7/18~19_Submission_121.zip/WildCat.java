import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a cat.
 * Cats age, move, eat (grasshoppers and mice), breed and die.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public class WildCat extends Animal
{
    // Characteristics shared by all wild cats (class variables).
    // The age at which a wild cat can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a wild cat can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a wild cat breeding.
    private static final double BREEDING_PROBABILITY = 0.69;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food values of a single grasshopper and a mouse. 
    // In effect, this is the number of steps a wild cat can go before it has to eat again.
    private static final int GRASSHOPPER_FOOD_VALUE = 7;
    private static final int MICE_FOOD_VALUE = 13;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The wild cat's age.
    private int age;
    // The wild cat's food level, which is increased by eating grasshopper and mice.
    private int foodLevel;
    // The disease - plague in this simulator. True if it is infected.
    protected boolean isInfectedByPlague;
    // The number of steps until this wild cat would die.
    protected int deathCounter = 0;

    /**
     * Create a wild cat. A wild cat can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cat will have random age and hunger level.
     * @param isAnimal Whether this creature is an animal.
     * @param animalsField The state of the animals' field.
     * @param plantsField The state of the plants' field.
     * @param location The location within the field.
     */
    public WildCat(boolean randomAge, boolean isAnimal, Field animalsField, Field plantsField, Location location)
    {
        super(isAnimal, animalsField, plantsField, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASSHOPPER_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASSHOPPER_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the wild cat does most of the time: it hunts for
     * grasshoppers and mice. In the process, it might breed, die of hunger,
     * die of sickness, or die of old age.
     * @param newWildCat A list to return newly born wild cats.
     */
    public void act(List<Creatures> newWildCat)
    {
        incrementAge();
        incrementHunger();
        incrementDiseaseLevel();
        if(isAlive()) {
            Location newMateLocation = findMate();
            if(newMateLocation != null) {
                giveBirth(newWildCat);   
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getAnimalsField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the wild cat's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this wild cat more hungry. This could result in the wild cat's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Make this cat more sick. The cat will die when the counter reaches 10.
     */
    private void incrementDiseaseLevel()
    {
        if(isInfectedByPlague) {
            deathCounter++;
            if(deathCounter >=10) {
                setDead();
            }
        }
    }
    
    /**
     * Look for grasshoppers or mice adjacent to the current location.
     * Only the first live grasshopper or mouse is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getAnimalsField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            // Cat can only eat when fog level is less than 8.
            if (fog <= 0.8) {
                if(animal instanceof Grasshopper) {
                    Grasshopper grasshopper = (Grasshopper) animal;
                    if(grasshopper.isAlive()) { 
                        grasshopper.setDead();
                        foodLevel = GRASSHOPPER_FOOD_VALUE;
                        return where;
                    }
                }
                else if(animal instanceof Mice) {
                    Mice mice = (Mice) animal;
                    if(mice.isAlive()) { 
                        mice.setDead();
                        foodLevel = MICE_FOOD_VALUE;                      
                        if (mice.isInfectedByPlague) {
                            isInfectedByPlague = true;
                        }                    
                        return where;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this wild cat is to give birth at this step.
     * Only the mother can give birth. The father cannot.
     * New births will be made into free adjacent locations.
     * @param newWildCat A list to return newly born wild cats.
     */
    private void giveBirth(List<Creatures> newWildCat)
    {
        // New wild cats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getAnimalsField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            if (isFemale == true) {
                Location loc = free.remove(0);
                WildCat young = new WildCat(false, true, animalsField, plantsField, loc);
                newWildCat.add(young);
            }
        }
    }
        
    /**
     * Look for mates adjacent to the current location.
     * The wild cat only mates with the first cat.
     * @return Where wild cat was found, or null if it wasn't.
     */
    private Location findMate()
    {
        Field field = getAnimalsField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof WildCat) {
                WildCat wildCat = (WildCat) animal;
                if(wildCat.isAlive() && isFemale != wildCat.getIsFemale()) { 
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A wild cat can breed if it has reached the breeding age.
     * @return true if the cat can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
