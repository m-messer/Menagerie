import java.util.List;
import java.util.Random;

/**
 * Abstract class Creatures - A class representing shared characteristics of all the creatures.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public abstract class Creatures
{
    // Whether the animal/plant is alive or not.
    protected boolean alive;
    // The animals' field.
    protected Field animalsField;
    // The plants' field.
    protected Field plantsField;
    // Whether the creature is an animal.
    private boolean isAnimal;
    // The creature's position in the field.
    protected Location location;
    // Create a randomizer object.
    protected static Randomizer rand;
    
    // The weather properties of the environment.
    protected boolean isNight;
    protected double rainfall;
    protected double sunlight;
    protected double fog;
    
    /**
     * Create a new creature at location in field.
     * 
     * @param isAnimal Whether the creature is an animal.
     * @param myField The field of the kingdom currently occupied.
     * @param otherField The field of the other kingdom.
     * @param location The location within the field.
     */
    public Creatures(boolean isAnimal, Field myField, Field otherField, Location location)
    {
        alive = true;
        this.isAnimal = isAnimal;
        if (isAnimal) {
            this.animalsField = myField;
            this.plantsField = otherField;
        }
        else {
            this.plantsField = myField;
            this.animalsField = otherField;
        }
        rand = new Randomizer();
    }
    
    /**
     * Make this animal/plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newCreatures A list to receive newly born animals.
     */
    abstract public void act(List<Creatures> newCreatures);

    /**
     * Check whether the animal/plant is alive or not.
     * @return true if the animal/plant is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Return the creature's location.
     * @return The creature's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the animals' field.
     * @return The animals' field.
     */
    protected Field getAnimalsField()
    {
        return animalsField;
    }
    
    /**
     * Return the plants' field.
     * @return The plants' field.
     */
    protected Field getPlantsField()
    {
        return plantsField;
    }
    
    /**
     * Set the part of the day.
     * @param isNight The current part of the day. True if it's at night.
     */
    protected void setIsNight(boolean isNight)
    {
        this.isNight = isNight;
    }
    
    /**
     * Set the amount of the sunlight in the environment.
     * @param sunlight The current amount of sunlight.
     */
    protected void setSunlight(double sunlight)
    {
        this.sunlight = sunlight;
    }
    
    /**
     * Set the amount of the rainfall in the environment.
     * @param rainfall The current amount of rainfall.
     */
    protected void setRainfall(double rainfall)
    {
        this.rainfall = rainfall;
    }
    
    /**
     * Set the amount of the fog in the environment.
     * @param fog The current amount of fog.
     */
    protected void setFog(double fog)
    {
        this.fog = fog;
    }

}
