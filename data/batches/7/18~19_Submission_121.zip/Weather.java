/**
 * Class Weather - A class representing the weather of the environment.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public class Weather
{
    // The amount of sunlight in the environment.
    private double sunlight = 0;
    // The amount of rain in the environment.
    private double rainfall = 0;
    // The amount of fog in the environment.
    private double fog = 0;
    // Create a randomizer object.
    private Randomizer random;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
    }

    /**
     * Setup the weather of the environment.
     * @param step25 The current step of the environment, which is reset to 0 when it reaches 25.
     * @param isNight Whether the environment is at nighttime.
     */
    public void setWeather(int step25, boolean isNight)
    {   
       // sunlight is larger than 0 in daytime.
       // the amount of sunlight is calculated from sin(0) to sin(90).
        if (!isNight) {
           sunlight = Math.sin((step25)*((Math.PI)/25));
           // when rainfall level is larger than 0.5, the amount of sunlight will be decreased.
           if (rainfall > 0.5) {
               sunlight *= 0.9;
           }
       }
       // sunlight is 0 when in nighttime.
       else {
           sunlight = 0;
       }
       
       // the amount of rainfall is random throughout the day.
       rainfall = random.getDouble();
       
       // there is no fog when sunlight level is larger than 2.
       // the amount of fog is random between 0 and 1 when sunlight level is smaller than 0.2.
       if(sunlight <= 0.2) {
            fog = random.getDouble();
       }
       else {
            fog = 0;
       }       
    }
    
    /**
     * Return the current amount of rainfall.
     * @return the amount of rainfall.
     */
    public double getAmountOfRainfall()
    {
        return rainfall;
    }
    
    /**
     * Return the current amount of sunlight.
     * @return the amount of sunlight.
     */
    public double getAmountOfSunlight()
    {
        return sunlight;
    }
    
    /**
     * Return the current amount fo fog.
     * @return the amount of fog.
     */
    public double getAmountOfFog()
    {
        return fog;
    }
}
