import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing different kinds of animals and plants.
 * 
 * Class Simulator - where the simulator is created.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 * 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that eagle will be created in any given grid position.
    private static final double EAGLE_CREATION_PROBABILITY = 0.04;
    // The probability that wild cat will be created in any given grid position.
    private static final double WILDCAT_CREATION_PROBABILITY = 0.06;
    // The probability that snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.07;
    // The probability that grasshopper will be created in any given grid position.
    private static final double GRASSHOPPER_CREATION_PROBABILITY = 0.10;
    // The probability that mice will be created in any given grid position.
    private static final double MICE_CREATION_PROBABILITY = 0.20;
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.25;
    // The probability that corn will be created in any given grid position.
    private static final double CORN_CREATION_PROBABILITY = 0.22;
    

    // List of creatures in the field.
    private List<Creatures> creatures;
    // The current state of the animals' field.
    private Field animalsField;
    // The current state of the plants' field.
    private Field plantsField;
    // The current step of the simulation.
    private int step;
    // The current step of the simulation, but it will be reset to 0 in every 25 steps.
    private int step25 = 0;
    // A boolean showing the part of the day, either day or night.
    private static boolean isNight = false;
    
    // The weather of the environment.
    protected Weather weather;
    
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        creatures = new ArrayList<>();
        animalsField = new Field(depth, width);
        plantsField = new Field(depth, width);
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Grasshopper.class, Color.ORANGE);
        view.setColor(WildCat.class, Color.BLUE);
        view.setColor(Snake.class, Color.RED);
        view.setColor(Mice.class, Color.CYAN);
        view.setColor(Eagle.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Corn.class, Color.YELLOW);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(animalsField); step++) {
            simulateOneStep();
            // delay(120);   // uncomment this to run more slowly

            step25++;
            isNight();
        }
    }
    
    /**
     * Alternate between day and night during the simulation.
     * It changes the boolean isNight.
     */
    private void isNight()
    {
        if (step25 == 25 && !isNight) {
            isNight = true;
            step25 = 0;
        }
        else if (step25 == 25 && isNight) {
            isNight = false;
            step25 = 0;
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each creature.
     */
    public void simulateOneStep()
    {
        step++;
       
        // Provide space for newborn creatures.
        List<Creatures> newCreatures = new ArrayList<>();      
        
        // Update the weather of the environment.
        weather.setWeather(step25, isNight);
        double sunlight = weather.getAmountOfSunlight();
        double rainfall = weather.getAmountOfRainfall();
        double fog = weather.getAmountOfFog();
        
        // Let all creatures act.
        for(Iterator<Creatures> it = creatures.iterator(); it.hasNext(); ) {
            Creatures creatures = it.next();
            creatures.setIsNight(isNight);
            creatures.setSunlight(sunlight);
            creatures.setRainfall(rainfall);
            creatures.setFog(fog);
            creatures.act(newCreatures);
            if(! creatures.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born creatures to the main lists.
        creatures.addAll(newCreatures);

        // Update the state in the view.
        view.showStatus(step, animalsField, plantsField, sunlight, rainfall, fog, isNight);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        creatures.clear();
        populate();
        
        // Show the starting state in the view.
        double sunlight = weather.getAmountOfSunlight();
        double rainfall = weather.getAmountOfRainfall();
        double fog = weather.getAmountOfFog();
        view.showStatus(step, animalsField, plantsField, sunlight, rainfall, fog, isNight);
    }
    
    /**
     * Randomly populate the field with all species of creatures.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        animalsField.clear();
        plantsField.clear();
        for(int row = 0; row < animalsField.getDepth(); row++) {
            for(int col = 0; col < animalsField.getWidth(); col++) {
                if(rand.nextDouble() <= WILDCAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    WildCat wildcat = new WildCat(true, true, animalsField, plantsField, location);
                    creatures.add(wildcat);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, true, animalsField, plantsField, location);
                    creatures.add(snake);
                }
                else if(rand.nextDouble() <= GRASSHOPPER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grasshopper grasshopper= new Grasshopper(true, true, animalsField, plantsField, location);
                    creatures.add(grasshopper);
                }
                else if(rand.nextDouble() <= MICE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mice mice = new Mice(true, true, animalsField, plantsField, location);
                    creatures.add(mice);
                }
                else if(rand.nextDouble() <= EAGLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(true, true, animalsField, plantsField, location);
                    creatures.add(eagle);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, false, plantsField, animalsField, location);
                    creatures.add(grass);
                }
                else if(rand.nextDouble() <= CORN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Corn corn = new Corn(true, false, plantsField, animalsField, location);
                    creatures.add(corn);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
