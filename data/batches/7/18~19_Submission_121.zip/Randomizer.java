import java.util.Random;

/**
 * Provide control over the randomization of the simulation. By using the shared, fixed-seed 
 * randomizer, repeated runs will perform exactly the same (which helps with testing). Set 
 * 'useShared' to false to get different random behaviour every time.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public class Randomizer
{
    // The default seed for control of randomization.
    private static final int SEED = 1111;
    // A shared Random object, if required.
    private static final Random rand = new Random(SEED);
    // Determine whether a shared random generator is to be provided.
    private static final boolean useShared = true;

    /**
     * Constructor for objects of class Randomizer
     */
    public Randomizer()
    {
    }

    /**
     * Provide a random generator.
     * @return A random object.
     */
    public static Random getRandom()
    {
        if(useShared) {
            return rand;
        }
        else {
            return new Random();
        }
    }
    
    /**
     * Reset the randomization.
     * This will have no effect if randomization is not through
     * a shared Random generator.
     */
    public static void reset()
    {
        if(useShared) {
            rand.setSeed(SEED);
        }
    }
    
    /**
     * Generate a random boolean.
     * @return A random boolean (true/false).
     */
    public static boolean getBoolean() {
        return rand.nextBoolean();
    }
    
    /**
     * Generate a random double.
     * @return A random double (between 0.0 and 1.0).
     */
    public static double getDouble() {
        return rand.nextDouble();
    }
    
    /**
     * Decide whether the creature is infected by disease.
     * @param probability The probability in percentage.
     */
    public static boolean getIfInfected(double probability) {
        double randNumber = rand.nextDouble();
        if (randNumber >= 0 && randNumber <= (1 - probability/100)) {
            return false;
        }
        else {
            return true;
        }
    }
}
