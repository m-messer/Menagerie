import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a grasshopper.
 * Grasshoppers age, move, eat (grass only), breed (asexually) and die.
 *
 * @version 2016.02.29 (2)
 * 
 * 18-19 4CCS1PPA Programming Practice and Applications
 * Term 2 Coursework 3 - Predator/Prey Simulation (Pair Programming)
 */
public class Grasshopper extends Animal
{
    // Characteristics shared by all grasshoppers (class variables).
    // The age at which a grasshopper can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a grasshopper can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a grasshopper breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The default food value of grass. In effect, this is the
    // number of steps a grasshopper can go before it has to eat again.
    private static double grassFoodValue = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The grasshopper's age.
    private int age;
    // The grasshopper's food level, which is increased by eating grass.
    private int foodLevel;

    /**
     * Create a grasshopper. A grasshopper may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grasshopper will have random age and hunger level.
     * @param isAnimal Whether this creature is an animal.
     * @param animalsField The state of the animals' field.
     * @param plantsField The state of the plants' field.
     * @param location The location within the field.
     */
    public Grasshopper(boolean randomAge, boolean isAnimal, Field animalsField, Field plantsField, Location location)
    {
        super(isAnimal, animalsField, plantsField, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt((int)(grassFoodValue));
        }
        else {
            age = 0;
            foodLevel = (int) (grassFoodValue);
        }
    }
    
    /**
     * This is what the grasshopper does most of the time: it finds grass.
     * In the process, it might breed, die of hunger or die of old age.
     * @param newGrasshopper A list to return newly born grasshoppers.
     */
    public void act(List<Creatures> newGrasshopper)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && !isNight) {
            giveBirth(newGrasshopper);    
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getAnimalsField().freeAdjacentLocation(getLocation());
            }
            // Try to move into a free location.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the grasshopper's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE && !isNight) {
            setDead();
        }
    }
    
    /**
     * Make this grasshopper more hungry. This could result in the grasshopper's death.
     */
    private void incrementHunger()
    {
        if(!isNight) {
            foodLevel--;
            if(foodLevel <= 0 && !isNight) {
                setDead();
            }
        }
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first grass found is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getPlantsField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    // the food value of grass is calculated in the grass class.
                    grassFoodValue = grass.getFoodValue();
                    foodLevel = (int) Math.round(grassFoodValue);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this grasshopper is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrasshopper A list to return newly born grasshoppers.
     */
    private void giveBirth(List<Creatures> newGrasshopper)
    {
        // New grasshoppers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getAnimalsField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            if (isFemale == true) {
                Location loc = free.remove(0);
                Grasshopper young = new Grasshopper(false, true, animalsField, plantsField, loc);
                newGrasshopper.add(young);
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A grasshopper can breed if it has reached the breeding age.
     * @return true if the grasshopper can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
