import java.util.Random;

/**
 * Write a description of class Plant here.
 *
 * @version 2021.03.03
 */
public class Plant
{
    // The age to which plants can live.
    private static final int MAX_AGE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The plant's age.
    private int age;
    // The plant's position in the field.
    private final Location location;
    
    /**
     * Constructor for objects of class Plant
     */
    public Plant(boolean randomAge, Location location)
    {
        Random random = new Random();
        this.location = location;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
   
    /**
     * Return the plant's age (growth).
     * @return The plant's age (growth).
     */
    protected int getAge()
    {
        return age;
    }
        
    /**
     * Return the plant's age (growth).
     * @return The plant's age (growth).
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Increase the age and grow, but it will not grow past its maximum
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            this.age = age;
        }
    }
    
    /**
     * If eaten, the age will return back to 0
     */
    public void eaten()
    {
        age = 0;
    }
}
