import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.03
 */
public abstract class Animal
{
    // The probability that there will be a disease in this animal.
    private final double DISEASE_PROBABILITY = 0.02;
    // The probability that there will be a disease in this animal.
    private final double TRANSMISSION_PROBABILITY = 0.15;
    // The amount of steps that the animal can survive with the disease before dying.
    private final int STEPS_SURVIVAL = 10;
    // The amount of steps this animal has had the disease.
    private int stepsWithDisease;
    // Whether the animal is alive or not.
    private boolean alive;
    // Whether the animal is male (true) or female (false).
    private final boolean gender;
    // Whether the animal has the horrible disease (true) or not (false).
    private boolean disease;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        this.alive = true;
        this.field = field;
        Random random = new Random();
        this.gender = random.nextBoolean();
        setLocation(location);
        this.stepsWithDisease = 0;
        this.disease = random.nextDouble() <= DISEASE_PROBABILITY;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, int time);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean getGender()
    {
        return gender;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Transmits DISEASE with a chance of not getting it
     */
    public void transmitDisease()
    {
        if(Randomizer.getRandom().nextDouble() <= TRANSMISSION_PROBABILITY) this.disease = true;
    }

    /**
     * Spread the disease to the adjacent squares around it.
     */
    public void spreadDisease() 
    {
        if(isAlive()) {

            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            for (Location where : adjacent) {
                Object transmitAnimal = field.getObjectAt(where);
                if (transmitAnimal instanceof Animal) {
                    Animal spreadAnimal = (Animal) transmitAnimal;
                    spreadAnimal.transmitDisease();
                }
            }
        }
    }

    /**
     * Returns disease.
     * @return value of disease.    
     */
    public boolean hasDisease()
    {
        return disease;
    }

    /**
     * Increments Steps with Disease, with a check if the animal can survive.
     */
    public void incrementStepsWithDisease()
    {
        stepsWithDisease++;

        if (stepsWithDisease > STEPS_SURVIVAL) {
            this.setDead();
        }    
    }

    /**
     * Returning the value of the amount of steps that this animal has had the disease for
     */
    public int getStepsWithDisease()
    {
        return stepsWithDisease;
    }    
}
