import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2021.03.03
 */
public class Gazelle extends Animal
{
    // Characteristics shared by all gazelles (class variables).

    // The age at which a gazelles can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a gazelles can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a gazelles breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // number of steps a Gazelle can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 50;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The gazelle's age.
    private int age;
    // The Gazelle's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a new gazelle. A gazelle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the gazelle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gazelle(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the gazelle does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGazelle A list to return newly born rabbits.
     */
    public void act(List<Animal> newGazelle, int time)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (time == 3) giveBirth(newGazelle);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    
    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Gazelle more hungry. This could result in the Cheetah's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this gazelle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGazelles A list to return newly born gazelle.
     */
    private void giveBirth(List<Animal> newGazelles)
    {
        // New gazelles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        int births = 0;
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Gazelle) {
                Gazelle gazelle = (Gazelle) animal;
                if (this.getGender() ^ gazelle.getGender())
                    births += breed();
            }
        }
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Gazelle young = new Gazelle(false, field, loc);
            newGazelles.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Look for Plants adjacent at the current location.
     * Only the first plant found is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        Location where = this.getLocation();
        Object plantObject = field.getPlantsAt(where);
        if(plantObject instanceof Plant) {
            Plant plant = (Plant) plantObject;
            if(plant.getAge() == plant.getMaxAge()) { 
                foodLevel = PLANT_FOOD_VALUE;
                plant.eaten();
                return where;
            }
            else {
                return where;
            }
        }
        return null;
    }
}
