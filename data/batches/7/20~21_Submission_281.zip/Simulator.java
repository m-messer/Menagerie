import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sharks, dolphins, whales, clown fish, angel fish and flounders.
 *
 * @version 2021.03.01
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a dolphin will be created in any given grid position.
    private static final double DOLPHIN_CREATION_PROBABILITY = 0.04;

    //The probability that a whale will be created in any given grid position. 
    private static final double WHALE_CREATION_PROBABILITY = 0.04;

    //The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.04;

    // The probability that a clown fish will be created in any given grid position.
    private static final double CLOWN_FISH_CREATION_PROBABILITY = 0.04;  

    // The probability that a flounder will be created in any given grid position.
    private static final double FLOUNDER_CREATION_PROBABILITY = 0.04;

    //The probability that an angel fish will be created in any given grid position. 
    private static final double ANGEL_FISH_CREATION_PROBABILITY = 0.04;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current types of infections
    private Infection infection; 
    // The current conditions of weather
    private Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        

        animals = new ArrayList<>();
        field = new Field(depth, width);
        infection = new Infection(0.5,0.2,0.2,1);
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(ClownFish.class,Color.ORANGE);
        view.setColor(Dolphin.class, Color.BLUE);
        view.setColor(Flounder.class, Color.PINK);
        view.setColor(AngelFish.class, Color.RED);
        view.setColor(Whale.class, Color.GREEN);
        view.setColor(Shark.class, Color.YELLOW);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (3000 steps).
     */
    public void runLongSimulation()
    {
        simulate(3000);
        simulateOneStep();
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.isNocturnal() && isNight() || !animal.isNocturnal() && !isNight())
            {
                animal.act(newAnimals, weather);
                if(!animal.isAlive()) {
                    it.remove();
                }
            }
        }
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        // Checks the probability of being sunny, windy or rainy.
        weather.checkWeatherProbability();

        view.showStatus(step, field, weather.weatherDescription());
    }

    /**
     * Returns true if it is night, by checking if the step is even
     * @return true if the step is even, which means night, and false otherwise
     */
    public boolean isNight()
    {
        return step % 2 == 0;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, weather.weatherDescription());
    }

    /**
     * Randomly populate the field with whales, sharks, dolphins, 
     * clown fish, angel fish and flounders and add diseased animals if the random generated number
     * is greater than the infection probability.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= DOLPHIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dolphin dolphin = new Dolphin(true, field, location);
                    animals.add(dolphin);
                    if(rand.nextDouble() <= infection.getInfectionProbability())
                    {
                        dolphin.setInfection(infection);
                    }
                }
                else if(rand.nextDouble() <= FLOUNDER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Flounder flounder = new Flounder(true, field, location);
                    animals.add(flounder);
                    if(rand.nextDouble() <= infection.getInfectionProbability())
                    {
                        flounder.setInfection(infection);
                    }
                }
                else if(rand.nextDouble() <= ANGEL_FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    AngelFish angel_fish = new AngelFish(true, field, location);
                    animals.add(angel_fish);
                    if(rand.nextDouble() <= infection.getInfectionProbability())
                    {
                        angel_fish.setInfection(infection);
                    }
                }
                else if(rand.nextDouble() <= CLOWN_FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    ClownFish clown_fish = new ClownFish(true, field, location);
                    animals.add(clown_fish);
                    if(rand.nextDouble() <= infection.getInfectionProbability())
                    {
                        clown_fish.setInfection(infection);
                    }
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    animals.add(whale);
                    if(rand.nextDouble() <= infection.getInfectionProbability())
                    {
                        whale.setInfection(infection);
                    }
                }
                else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                    if(rand.nextDouble() <= infection.getInfectionProbability())
                    {
                        shark.setInfection(infection);
                    }
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
