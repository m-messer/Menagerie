import java.util.List;
import java.util.Random;

/**
 * A simple model of a clown fish.
 * Clown fish age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class ClownFish extends Animal
{
    // Characteristics shared by all ClownFishs (class variables).

    // The age at which a ClownFish can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a ClownFish can live.
    private static final int MAX_AGE = 120;

    // The likelihood of a ClownFish breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new ClownFish. A ClownFish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the ClownFish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public ClownFish(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location,false);
    }

    /**
     * This is what the ClownFish does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newClownFish A list to return newly born ClownFishs.
     * @param weather The type of weather that influences its behaviour.
     */
    public void act(List<Animal> newClownFish, Weather weather)
    {
        incrementAge();
        reactToInfection();
        if(isAlive() && !weather.isWindy()) {
            giveBirth(newClownFish);   
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this ClownFish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimal A list to return newly born ClownFish.
     */
    public void giveBirth(List<Animal> newAnimal)
    {
        // New Flounder are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        if(field.hasOppositeGenderNeighbours(this)){
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                ClownFish young = new ClownFish(false, field, loc);
                newAnimal.add(young);
            }
        }

    }

    /**
     * This method returns the breeding probability of the Clown Fish. 
     * @return the breeding probability
     */
    protected double breedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * This returns the maximum age of the ClownFish. 
     * @return the maximum age
     */
    protected  int maximumAge()
    {
        return MAX_AGE;
    }

    /**
     * This method returns the breeding age of the ClownFish. 
     * @return the breeding age
     */
    protected  int breedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * This method returns the maximum litter of the ClownFish
     * @return the maximum litter of the clown fish
     */
    protected  int maximumLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
