import java.util.Random;

/**
 * This class provides the weather for the simulation.
 *
 * @version 2021.03.01
 */
public class Weather
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private boolean sun;
    private boolean rain; 
    private boolean wind;
    
    // The likelihood of rain
    private static final double RAIN_PROBABILITY = 0.5;
    // The likelihood of sun 
    private static final double SUN_PROBABILITY = 0.4;
    // The likelihood of rain
    private static final double WIND_PROBABILITY = 0.3;

    public void checkWeatherProbability()
    {
        sun = false;
        rain = false;
        wind = false;
        if(rand.nextDouble() <= WIND_PROBABILITY)
        {
            wind = true;
        }
        else if(rand.nextDouble() <= RAIN_PROBABILITY)
        {
            rain = true;
        }
        else if(rand.nextDouble() <= SUN_PROBABILITY)
        {
            sun = true;
        }
    }

    /**
     * Returns true if it is raining
     */
    public boolean isRaining()
    {
        return rain;
    }

    /**
     * Returns true if it is sunny
     */
    public boolean isSunny()
    {
        return sun;
    }

    /**
     * Returns true if it is windy
     */
    public boolean isWindy()
    {
        return wind;
    }

    /**
     * If the weather variables are true, the method returns a string with the description
     * of that weather. 
     */
    public String weatherDescription()
    {
        if(sun)
        {
            return "It's sunny.";
        } 
        else if(rain)
        {
            return "It's raining.";
        } 
        else if(wind)
        {
            return "It's windy.";
        } 
        return "it's undetected from under the sea";
    }
}
