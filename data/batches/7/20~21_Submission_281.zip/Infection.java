/**
 * The Infection class creates the infection in the under-the-sea world.
 *
 * @version 2021.03.01
 */
public class Infection
{
    // The probability that an animal will carry a disease.
    private double infectionProbability;

    // The probability that an animal will be immune.
    private double curedProbability;

    // The probability that an animal will die from being infected.
    private double deathProbability; 

    // The age to which an animal can live while being diseased.
    private double relativeMaxAgeWithInfection;

    /**
     * Create infection among animals.
     * 
     * @param infectionProbability the probability that an animal is infected
     * @param curedProbability the probability that an animal is cured
     * @param deathProbability the probability that an animal dies because of the disease
     * @param relativeMaxAgeWithInfection the maximum age an infected animal can live up to
     */
    public Infection(double infectionProbability, double curedProbability, double deathProbability, double relativeMaxAgeWithInfection)
    {
        this.infectionProbability = infectionProbability; 
        this.curedProbability = curedProbability;
        this.deathProbability = deathProbability;
        this.relativeMaxAgeWithInfection = relativeMaxAgeWithInfection;
    }

    /**
     * Returns the value of the infection probability.
     * @return the value of the infection probability
     */
    public double getInfectionProbability()
    {
        return infectionProbability;
    }

    /**
     * Returns the value of the cured probability.
     * @return the value of the cured probability
     */
    public double getCuredProbability()
    {
        return curedProbability;
    }

    /**
     * Return the value of the life expectancy that the animal can live with the infection.
     * @return the value of the maximum age of a diseased animal
     */
    public double getRelativeMaxAgeWithInfection()
    {
        return relativeMaxAgeWithInfection;
    }

    /**
     * Returns the value of the death probability.
     * @return the value of the death probability
     */
    public double getDeathProbability()
    {
        return deathProbability;
    }

    /**
     * An animal can get randomly infected.
     * @return true if the animal can get infected, false otherwise
     */
    public boolean checkInfectionProbability(double random)
    {
        return  random <= getInfectionProbability();
    }

}
