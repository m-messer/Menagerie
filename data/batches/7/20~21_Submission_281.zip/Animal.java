import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.01
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    // Whether the animal is infected or not.
    private  Infection infection;

    // The animal's age.
    private int age;

    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    // The animal's gender. 
    private Gender gender;

    //The animal's sleeping pattern.
    private boolean isNocturnal;
   
    // Gender enum which has two constants - female and male.
    private enum Gender{
        FEMALE,
        MALE
    }

    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param nocturnal If true, the animal is nocturnal.
     */
    public Animal(boolean randomAge, Field field, Location location, boolean nocturnal)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        age = 0;
        gender = getRandomGender();
        isNocturnal = nocturnal; 
        if(randomAge) {
            age = rand.nextInt(maximumAge());
        }
    }

    /**
     * Randomly returns either Gender.FEMALE or Gender.MALE
     */
    public Gender getRandomGender(){
        int randomNumber = rand.nextInt(2);
        if(randomNumber == 0){
            return Gender.FEMALE;
        }
        return Gender.MALE;
    }

    /**
     * Returns the gender of the animal.
     * @return the gender
     */
    public Gender getGender(){
        return gender; 
    }

    /**
     * Sets the infection for an animal.
     */
    public void setInfection(Infection infectionType)
    {
        infection = infectionType; 
    }

    /**
     * Set the animal as cured.
     */
    public void setCured()
    {
        infection = null; 
    }

    /**
     * Returns the infection value.
     * @return the infection value
     */
    public Infection getInfection(){
        return infection; 
    }

    /**
     * Checks if the animal is infected.
     * @return true if the animal is infected, false otherwise
     */
    public boolean isInfected()
    {
        return infection != null;
    }

    /**
     * Checks if the animal is nocturnal.
     * @retrun true if the animal is nocturnal, false otherwise
     */
    public boolean isNocturnal()
    {
        return isNocturnal; 
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newAnimals A list to receive newly born animals.
     * @param weather The type of weather that affect the animal's behaviour.
     */
    abstract public void act(List<Animal> newAnimals, Weather weather);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= breedingAge();
    }

    /**
     * Increase the age.
     * This could result in the animals death if it exceeds the maximum age or if the animal
     * is infected and the life span is larger than the maximum age of a diseased animal.
     */
    protected void incrementAge()
    {
        age++;
        if(age > maximumAge()) {
            setDead();
        }
        else if(isInfected() && age > age * infection.getRelativeMaxAgeWithInfection()) {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= breedingProbability()) {
            births = rand.nextInt(maximumLitterSize()) + 1;
        }
        return births;
    }

    /**
     * This method determines if the animal gets infected, cured or dies from 
     * infection.
     */
    public void reactToInfection()
    {
        if(isAlive()){
        getInfectedOfNeighbour();
        getCuredRandomly();
        deadOfInfection();
        }
    }

    /**
     * If a non-infected animal is next to an infected animal of the same type, 
     * it has a chance of catching that specific infection. 
     */
    public void getInfectedOfNeighbour()
    {
        Field field = getField();
        if(!isInfected()) 
        {
            Infection neighboursInfection = field.hasInfectedNeighbour(this);
            if(neighboursInfection == null) {
                return;
            }
            if(neighboursInfection.checkInfectionProbability(rand.nextDouble())) {
                this.setInfection(neighboursInfection); 
            }
        }
    }

    /**
     * An animal may get randomly cured.
     */
    public void getCuredRandomly(){
        if(isInfected() && rand.nextDouble() <= infection.getCuredProbability())
        {
            this.setCured();
        }
    }

    /**
     * Animal will die if it is infected and its death probability is greater than the random value. 
     */
    protected void deadOfInfection()
    {
        if(isInfected() && rand.nextDouble() <= infection.getDeathProbability())
        {
            setDead();
        }
    }

    /**
     * Abstract method for the animal giving birth.
     */
    protected abstract void giveBirth(List<Animal> newAnimal);

    /**
     * Abstract method for returning breeding probability of the animal.
     */
    protected abstract double breedingProbability();

    /**
     * Abstract method for returning the maximum age of the animal. 
     */
    protected abstract int maximumAge();

    /**
     * Abstract method for returning the breeding age of the animal. 
     */
    protected abstract int breedingAge();

    /**
     * Abstract method for returning maximum litter size of animal. 
     */

    protected abstract int maximumLitterSize();
}
