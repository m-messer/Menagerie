import java.util.Random;
import java.util.List;

/**
 * A simple model of an angel fish.
 * Angel Fish age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class AngelFish extends Animal
{
    // Characteristics shared by all AngelFishs (class variables).
    // The age at which a AngelFish can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a AngelFish can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a AngelFish breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;

    /**
     * Constructor for objects of class AngelFish
     */
    public AngelFish(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, true);
    }

    /**
     * This is what the AngelFish does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newAngelFish A list to return newly born Angel Fish.
     * @param weather The type of weather that influences its behaviour.
     */
    public void act(List<Animal> newAngelFish, Weather weather)
    {
        incrementAge();
        reactToInfection();
        if(isAlive() && !weather.isRaining()) {
            giveBirth(newAngelFish);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this AngelFish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimal A list to return newly born Angel Fish.
     */
    public void giveBirth(List<Animal> newAnimal)
    {
        // New AngleFish are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        if(field.hasOppositeGenderNeighbours(this))
        {
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) 
            {
                Location loc = free.remove(0);
                AngelFish young = new AngelFish(false, field, loc);
                newAnimal.add(young);
            }
        }
    }

    /**
     * This method returns the breeding probability value for the Angel Fish. 
     * @return the breeding probability
     */
    protected double breedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * This returns the maximum age of the AngelFish 
     * @return the maximum age
     */
    protected  int maximumAge()
    {
        return MAX_AGE;
    }

    /**
     * This method returns the breeding age of the AngelFish
     * @return the breeding age
     */
    protected  int breedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * This method returns the maximum litter of the AngelFish
     * @return the maximum litter of the angel fish
     */
    protected  int maximumLitterSize()
    {
        return MAX_LITTER_SIZE;

    }

    
}
