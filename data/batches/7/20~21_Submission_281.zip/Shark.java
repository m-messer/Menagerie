import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a shark.
 * Sharks age, move, eat clown fishs, and die.
 *
 * @version 2021.03.01
 */
public class Shark extends Animal
{
    // Characteristics shared by all sharks (class variables).

    // The age at which a shark can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a shark can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a shark breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;

    // The food value of a single clown fish. In effect, this is the
    // number of steps a shark can go before it has to eat again.
    private static final int CLOWNFISH_FOOD_VALUE = 6;

    // Individual characteristics (instance fields).
    // The shark's food level, which is increased by eating clown fishs/flounder/angel fish.
    private int foodLevel;

    /**
     * Create a shark. A shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the shark will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shark(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, true);
        if(randomAge) {
            foodLevel = rand.nextInt(CLOWNFISH_FOOD_VALUE);
        }
        else {
            foodLevel = CLOWNFISH_FOOD_VALUE;
        }
    }

    /**
     * This is what the shark does most of the time: it hunts for
     * clown fish. In the process, it might breed, die of hunger,
     * die of old age, or catch disease.
     * @param newSharks A list to return newly born sharks.
     * @param weather The type of weather that influences its behaviour.
     */
    public void act(List<Animal> newSharks, Weather weather)
    {
        incrementAge();
        incrementHunger();
        reactToInfection();
        if(isAlive() && !weather.isRaining()) {
            giveBirth(newSharks);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this shark more hungry. This could result in the shark's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for clown fish adjacent to the current location.
     * Only the first live clown fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof ClownFish) {
                ClownFish clownFish = (ClownFish) animal;
                if(clownFish.isAlive()) { 
                    clownFish.setDead();
                    foodLevel += CLOWNFISH_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this shark is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimal A list to return newly born shark.
     */
    public void giveBirth(List<Animal> newAnimal)
    {
        // New sharks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        if(field.hasOppositeGenderNeighbours(this)){
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Shark young = new Shark(false, field, loc);
                newAnimal.add(young);
            }
        }
    }

    /**
     * This returns the breeding probability of the shark.
     * @return the breeding probability
     */
    protected double breedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * This returns the maximum age of the shark. 
     * @return the maximum age
     */
    protected  int maximumAge()
    {
        return MAX_AGE;
    }

    /**
     * This method returns the breeding age of the shark. 
     * @return the breeding age
     */
    protected  int breedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * This method returns the maximum litter of the shark.
     * @return the maximum litter of the shark
     */
    protected  int maximumLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

}
