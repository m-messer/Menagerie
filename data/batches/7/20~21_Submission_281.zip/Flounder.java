import java.util.Random;
import java.util.List;

/**
 * A simple model of a flounder. Flounders age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Flounder extends Animal
{
    // Characteristics shared by all flounders (class variables).
    
    // The age at which a flounder can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a flounder can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a flounder breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;

    /**
     * Constructor for objects of class Flounder
     */
    public Flounder(boolean randomAge,Field field, Location location)
    {
        super(randomAge, field, location,false);
    }

    /**
     * This is what the flounder does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newFlounders A list to return newly born flounders.
     * @param weather The type of weather that influences its behaviour.
     */
    public void act(List<Animal> newFlounders, Weather weather)
    {
        incrementAge();
        reactToInfection();
        if(isAlive() && !weather.isSunny()) {
            giveBirth(newFlounders);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this flounder is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimal A list to return newly born floundes.
     */
    public void giveBirth(List<Animal> newAnimal)
    {
        // New flounders are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        if(field.hasOppositeGenderNeighbours(this))
        {
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) 
            {
                Location loc = free.remove(0);
                Flounder young = new Flounder(false, field, loc);
                newAnimal.add(young);
            }
        }
    }

    /**
     * Returns the breeding probability value.
     * @return the breeding probability
     */
    protected double breedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * This returns the maximum age of the flounder. 
     * @return the maximum age
     */
    protected  int maximumAge()
    {
        return MAX_AGE;
    }

    /**
     * This method returns the breeding age of the flounder. 
     * @return the breeding age
     */
    protected  int breedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * This method returns the maximum litter of the flounder
     * @return the maximum litter of the flounder
     */
    protected  int maximumLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}

