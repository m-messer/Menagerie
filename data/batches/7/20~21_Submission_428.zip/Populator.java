import java.util.Random;
import java.util.ArrayList;
import java.util.List;
/**
 * Creates the initial state of the organisims on the Field.
 *
 * @version 2021.03.01
 */
public class Populator
{   
    //Organisims creation probability.
    private static final double LION_CREATION_PROBABILITY = 0.05;
    private static final double ZEBRA_CREATION_PROBABILITY = 0.15;    
    private static final double PLANT_CREATION_PROBABILITY = 0.25;    
    private static final double TIGER_CREATION_PROBABILITY = 0.05;
    private static final double BUTEERFLY_CREATION_PROBABILITY = 0.15;    
    private static final double SNAKE_CREATION_PROBABILITY = 0.05; 

    //A list of organisims to be filled.
    private List<Organisim> populatedOrganisims;

    public Populator()
    {
        populatedOrganisims = new ArrayList<Organisim> ();
    }

    /** 
     * Populate the field with organisims.
     * @param Field the field containing all the organisims
     * @return List of organisims
     */
    public List<Organisim> populateOrganisims(Field field)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) 
        {
            for(int col = 0; col < field.getWidth(); col++) 
            {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    populatedOrganisims.add(lion);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    populatedOrganisims.add(zebra);
                }

                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    populatedOrganisims.add(plant);
                }

                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true,field, location);
                    populatedOrganisims.add(tiger);
                }

                else if(rand.nextDouble() <= BUTEERFLY_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Butterfly butterfly = new Butterfly(true, field, location);
                    populatedOrganisims.add(butterfly);
                }

                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    populatedOrganisims.add(snake);
                }
            }
        }
        return populatedOrganisims;
    }
}