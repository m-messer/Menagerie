import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Zebra.
 * Zebras age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Zebra extends Prey
{
    //The age to which a zebra can live.
    private static final int MAX_AGE = 120;
    //The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    //The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    //The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 4;
    //A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new Zebra. A zebra may be created with age zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * A zebra activates its defence when its in danger by warning neighboring zebras.
     */
    public void activateDefense()
    {   
        //Checks if it is near a predator.
        if(inDanger())
        {
            List<Location> neighbors = getField().adjacentLocations(getLocation());
            Iterator<Location> it = neighbors.iterator();
            while(it.hasNext())
            {
                Location where = it.next();            
                Object obj = getField().getObjectAt(where);

                if(obj != null && obj.getClass() == this.getClass()) 
                {   
                    Animal animal = (Animal) obj;
                    //Warn other zebras adjacent to this zebra.
                    warnNeighboringZebra(animal);
                }
            }
        }
    }

    /**
     * When a zebra is warned that a predator is near, the animal moves two steps if it can.
     * @param animal Is the animal to be warned
     */
    private void warnNeighboringZebra(Animal animal)
    {   
        //Moves the zebra one step.
        Location newLocation = moveOneStep(animal.getLocation());
        if(newLocation != null && rand.nextDouble() <= DEFENSE_PROBABILITY)
        {   
            //Moves the zebra a second step.
            newLocation = moveOneStep(newLocation);
            if(newLocation != null)
            {
                animal.setLocation(newLocation);
            }
        }
    }

    /**
     * Moves the zebra one step to a free adjacent location.
     * 
     * @param location the animal's current location
     * @return location of the new free location
     */
    private Location moveOneStep(Location location)
    {  
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(location); 
        Location newlocation = null;
        if(free.size() > 0)
        {
            int index = rand.nextInt(free.size());
            newlocation = free.get(index);
        }
        return newlocation;
    }

    /**
     * Generate a new born of zebra.
     * @param randomAge If true, the zebra will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     * 
     * @return new zebra object
     */
    public Organisim generateNewBorn(boolean randomAge, Field field, Location loc)
    {
        Organisim zebra = new Zebra(randomAge, field, loc);
        return zebra;
    }

    /**
     * A zebra sleeps between the hours 11 and 13.
     * 
     * @param time time of the day
     * @return true if time is between 11 to 13, false otherwise
     */
    public boolean isSleeping(int time)
    {
        return (time >= 11 && time <= 13);
    }

    //A list of accessor methods
    /**
     * Returns the max of a zebra.
     * @return the max age
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the breeding age of a zebra.
     * @return the breeding age
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the breeding probability of a zebra.
     * @return the breeding probability
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the max litter size of  a zebra.
     * @return the max litter size
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
