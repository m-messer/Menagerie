import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Snake.
 * 
 * Snakes age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Snake extends Predator 
{   
    //The age to which a snake can live.
    private static final int MAX_AGE = 140;
    //The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    //The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    //The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 5;
    //The food value of a Butterfly. In effect, this is the
    //number of steps a snake can go before it has to eat again.
    private static final int BUTTERFLY_FOOD_VALUE = 12;
    //A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new snake. A snake may be created with age zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the snake will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * A snake sleeps between the hours 11 and 15.
     * 
     * @param time time of the day
     * @return true if time is between 11 to 15, false otherwise
     */
    public boolean isSleeping(int time)
    {
        return (time >= 11 && time <= 15);
    }

    /**
     * Generate a new born of snake.
     * @param randomAge If true, the snake will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     * 
     * @return a new snake object
     */
    public Organisim generateNewBorn(boolean randomAge, Field field, Location loc)
    {
        Organisim snake = new Snake(randomAge, field, loc);
        return snake;
    }

    /**
     * A snake hunts a prey if its of type butterfly.
     * 
     * @param Prey prey that the snake eats
     * @return true if the snake ate the prey, false otherwise 
     */
    public boolean isHunted(Prey prey)
    {   
        //Checks if prey is of type butterfly and if the butterfly's defence is activated.
        if(prey instanceof Butterfly && !((Butterfly)prey).isCamouflageActivated())
        {
            prey.setDead();
            updateFoodLevel(BUTTERFLY_FOOD_VALUE);
            return true;
        }
        return false;
    }

    //A list of accessor methods
    /** 
     * Returns the max age of a snake.
     * @return the max age
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return the food value of a butterfly.
     * @return the butterfly food value
     */
    public int getFoodValue()
    {
        return BUTTERFLY_FOOD_VALUE;
    }

    /** 
     * Returns the breeding age of a snake.
     * @return the breeding age
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /** 
     * Returns the breeding probability of a snake.
     * @return the breeding probability
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /** 
     * Returns the max litter size of a snake.
     * @return the max litter size
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}