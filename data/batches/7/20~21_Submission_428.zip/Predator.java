import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of Predators.
 * 
 * Predators can chase preys, and their vision can be influenced by the weather.
 *
 * @version 2021.03.01
 */
public abstract class Predator extends Animal
{
    /**
     * Create a Predator at given location in field.
     * 
     * @param randomAge determines whether the age of the animal is random
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Predator(boolean randomAge, Field field, Location loc)
    {
        super(randomAge, field, loc);
    }

    /**
     * This is what the animal does most of the time: it hunts for food and breeds.
     * In the process might catch and spread a disease, or die of hunger or of old age.
     * It also checks weather the animal has a clear vision based on the weather conditions.
     * @param newOrganisims A list to return newly born animals
     * @param time time of the day
     * @param weather the weather at this time
     */
    public void act(List<Organisim> newOrganisims, int time, Weather weather)
    {
        super.act(newOrganisims, time, weather);
        //Predators can move and chase their preys only if they have clear vision.
        if(canAct(time) && hasClearVision(weather))
        {
            move();
        }
    }

    /**
     * Look for food adjacent to the current location. 
     * If it's a prey it eats plants, and if it's a predator it eats a prey
     * @return where food was found, or null if it wasn't
     */
    public Location findFood()
    {
        List<Location> adjacent = getField().adjacentLocations(getLocation());;
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) 
        {
            Location where = it.next();            
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Prey) 
            {
                Prey prey = (Prey) animal;
                //Checks if predator can eat this prey species.
                if(isHunted(prey)) 
                { 
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Checks whether a predator can see in this weather.
     * 
     * @param weather the current weather condition
     * @return true if weather is not foggy, false otherwise
     */
    private boolean hasClearVision(Weather weather)
    {
        if(weather.isFog())
        {
            return false;
        }
        return true;
    }

    /**
     * A Predator hunts a prey if its of type it consumes
     * 
     * @param Prey prey that the predator eats
     * @return true if the predator ate the prey, false otherwise 
     */
    abstract public boolean isHunted(Prey prey);
}