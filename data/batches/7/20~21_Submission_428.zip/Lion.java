import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Lion.
 * 
 * Lions age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Lion extends Predator
{
    //The age to which a lion can live.
    private static final int MAX_AGE = 140;
    //The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    //The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 10;
    //The food value of a Zebra. In effect, this is the
    //number of steps a Lion can go before it has to eat again.
    private static final int ZEBRA_FOOD_VALUE = 15;
    //A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new lion. A lion may be created with age zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the lion will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Generate a new born of lion.
     * @param randomAge If true, the lion will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     * 
     * @return new lion object
     */
    public Organisim generateNewBorn(boolean randomAge, Field field, Location loc)
    {
        Organisim lion = new Lion(randomAge, field, loc);
        return lion;
    }

    /**
     * A lion hunts a prey if its of type zebra.
     * 
     * @param Prey prey that the lion eats
     * @return true if the lion ate the prey, false otherwise 
     */
    public boolean isHunted(Prey prey)
    {
        //Checks if prey is of type zebra.
        if(prey instanceof Zebra)
        {
            prey.setDead();
            updateFoodLevel(ZEBRA_FOOD_VALUE);
            return true;
        }
        return false;
    }

    /**
     * A lion sleeps between the hours 17 and 21.
     * 
     * @param time time of the day
     * @return true if time is between 17 to 21, false otherwise
     */
    public boolean isSleeping(int time)
    {
        return (time >= 17 && time <= 21);
    }

    //A list of accessor methods
    /**
     * Returns the breeding age of a lion.
     * @return the breeding age
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /** 
     * Returns the breeding probability of a lion.
     * @return the breeding probability
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /** 
     * Returns the max litter size of a lion.
     * @return the max litter size
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /** 
     * Returns the max age of a lion.
     * @return the max age
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return the food value of a zebra.
     * @return the zebra food value
     */
    public int getFoodValue()
    {
        return ZEBRA_FOOD_VALUE;
    }
}