import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Tiger.
 * 
 * Tigers age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Tiger extends Predator 
{
    //The age to which a Tiger can live.
    private static final int MAX_AGE = 140;
    //The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    //The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 10;
    //The food value of a zebra. In effect, this is the
    //number of steps a tiger can go before it has to eat again.
    private static final int ZEBRA_FOOD_VALUE = 15;
    //A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new Tiger. A tiger may be created with age zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the tiger will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Generate a new born of tiger.
     * @param randomAge If true, the tiger will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     * 
     * @return a new tiger object
     */
    public Organisim generateNewBorn(boolean randomAge, Field field, Location loc)
    {
        Organisim tiger = new Tiger(randomAge, field, loc);
        return tiger;
    }

    /**
     * A tiger hunts a prey if its of type zebra.
     * 
     * @param Prey prey that the tiger eats
     * @return true if the tiger ate the prey, false otherwise 
     */
    public boolean isHunted(Prey prey)
    {
        //Checks if prey is of type zebra.
        if(prey instanceof Zebra)
        {
            prey.setDead();
            updateFoodLevel(ZEBRA_FOOD_VALUE);
            return true;
        }
        return false;
    }

    /**
     * A tiger sleeps between the hours 19 and 23.
     * 
     * @param time time of the day
     * @return true if time is between 19 to 23, false otherwise
     */
    public boolean isSleeping(int time)
    {
        return (time >= 19 && time <= 23);
    }

    //A list of accessor methods
    /** 
     * Returns the max age of a tiger.
     * @return the max age
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return the food value of a zebra.
     * @return the zebra food value
     */
    public int getFoodValue()
    {
        return ZEBRA_FOOD_VALUE;
    }

    /** 
     * Returns the breeding age of a tiger.
     * @return the breeding age
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /** 
     * Returns the breeding probability of a tiger.
     * @return the breeding probability
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /** 
     * Returns the max litter size of a tiger.
     * @return the max litter size
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}