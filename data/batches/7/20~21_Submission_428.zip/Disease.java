/**
 * class Disease - a class to represent an infectious disease in the environment.
 * 
 * An infectious diease have a virus incubation period and can cause animals to be dead.
 *
 * @version 2021.03.01
 */
public class Disease
{
    //Probability of infection by contact.
    private static final double INFECTION_PROBABILITY_CONTACT = 0.1;
    //Probability that the disease kills the host.
    private static final double DEATH_PROBABILITY = 0.5;
    //Represents how long a disease lasts.
    private static final int INCUBATION_PERIOD = 5;
    //Tracks the virus incubation period carried by an animal.
    private int diseaseTracker;

    /**
     * Construct objects of class disease. 
     */
    public Disease()
    {
        diseaseTracker = 0;
    }

    /**
     * Returns probibility of infection if it contacts another animal.
     * @return probibility of infection by contact
     */
    public double infenctionByContacnt()
    {
        return INFECTION_PROBABILITY_CONTACT;
    }

    /**
     * Returns probibility of death if an animal is infected by the disease.
     * @return probibility of death
     */
    public double getDeathProbability()
    {
        return DEATH_PROBABILITY;
    }

    /**
     * Checks if the virus incubation period is over, and increments the tracker.
     * @return true if the incubation period has finished, false otherwise
     */
    public boolean incubationFinished()
    {
        incrementDiseaseTracker();
        if(diseaseTracker >= INCUBATION_PERIOD)
        {
            return true;
        }
        return false;
    }

    /**
     * Increments the disease tracker.
     */
    private void incrementDiseaseTracker()
    {
        diseaseTracker++;
    }
}