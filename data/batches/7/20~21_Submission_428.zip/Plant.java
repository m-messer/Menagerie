import java.util.List;
import java.util.Random;
/**
 * Class Plant - a class representing shared characterstics of plants.
 * 
 * Plants can grow and propagate new seeds when the weather conditiionds are supportive.
 *
 * @version 2021.03.01
 */
public class Plant extends Organisim
{
    //The likelihood of a plant growing.
    private static final double GROWTH_PROBABILITY = 0.5;
    //The maximum number of Seeds.
    private static final int MAX_SEED_SIZE = 2;
    //A shared random number generator. 
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new Plant at location in field.
     * 
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * This is what the plant does most of the time: it reproduces if the weather is rainy.
     * 
     * @param newOrganisims A list to return newly reproduced seeds
     * @param time time of the day
     * @param weather the weather at this time
     */
    public void act(List<Organisim> newOrganisims, int time, Weather weather)
    {
        Location newLocation;
        if(isAlive() && weather.isRain())
        {   
            //Produces new seeds if the weather is rainy.
            propagateNewSeeds(newOrganisims);
        }
    }

    /**
     * A plant reproduces new seeds into the free adjacent loctions.
     * @param newPlants a list to add new plants into
     */
    private void propagateNewSeeds(List<Organisim> newPlants) 
    { 
        Field field = getField(); 
        List<Location> free = field.getFreeAdjacentLocations(getLocation()); 
        int seeds = seedsSize(); 

        for(int i = 0; i < seeds && free.size() > 0; i++)
        { 
            Location loc = free.remove(0); 
            Plant plant = new Plant(field, loc); 
            newPlants.add(plant); 
        } 
    } 

    /**
     * Generates a random number of seeds that a plant can produce.
     * @return the number of seeds to be produced
     */
    private int seedsSize() 
    { 
        int seeds = 0; 
        if(rand.nextDouble() <= GROWTH_PROBABILITY)
        { 
            seeds = rand.nextInt(MAX_SEED_SIZE) + 1; 
        } 
        return seeds; 
    } 
}