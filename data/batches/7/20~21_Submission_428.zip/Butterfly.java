import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Butterfly.
 * 
 * Butterflys age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Butterfly extends Prey
{    
    //The age to which a Butterfly can live.
    private static final int MAX_AGE = 120;
    //The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //The likelihood of a butterfly breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    //The age at which a butterfly can start to breed.
    private static final int BREEDING_AGE = 7;
    //A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    //Whether a butterfly camouflage is activated.
    private boolean camouflageActivated;

    /**
     * Create a new buttefly. A butterfly may be created with age zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the butterfly will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Butterfly(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * A butterfly activates its defence when its in danger by activating camouflage if its surrounded by plants.
     */
    public void activateDefense()
    {
        //Counter to check the number of surrounding plants.
        int plantCounter = 0;
        camouflageActivated = false;
        //Checks if the butterfly is near a predator.
        if(inDanger())
        {
            List<Location> neighbors = getField().adjacentLocations(getLocation());
            Iterator<Location> it = neighbors.iterator();

            while(it.hasNext())
            {
                Location where = it.next();            
                Object organisim = getField().getObjectAt(where);
                if(organisim != null && organisim instanceof Plant)
                { 
                    plantCounter++;
                }
            }
            //If the plant counter is at least 3, and depending on defence probability camouflage can be activated.
            if(plantCounter >= 3 && rand.nextDouble() <= DEFENSE_PROBABILITY)
            {
                camouflageActivated = true;
            }
        }
    }

    /**
     * Generate a new born of butterfly.
     * @param randomAge If true, the butterfly will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     * 
     * @return new butterfly object
     */
    public Organisim generateNewBorn(boolean randomAge, Field field, Location loc)
    {
        Organisim butterfly = new Butterfly(randomAge, field, loc);
        return butterfly;
    }

    /**
     * A butterfly sleeps between the hours 8 and 10.
     * 
     * @param time time of the day
     * @return true if time is between 8 to 10, false otherwise
     */
    public boolean isSleeping(int time)
    {
        return (time >= 8 && time <= 10);
    }

    //A list of accessor methods
    /** 
     * Checks whether camouflage is activated.
     * @return true if its activated, false otherwise
     */
    public boolean isCamouflageActivated()
    {
        return camouflageActivated;
    }

    /**
     * Returns the breeding probability of a butterfly.
     * @return the breeding probability
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the max litter size of a butterfly.
     * @return the max litter size
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the max age of a butterfly
     * @return the max age
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the breeding age of a butterfly.
     * @return the breeding age
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}