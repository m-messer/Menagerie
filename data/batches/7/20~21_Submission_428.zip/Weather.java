import java.util.Random;
/**
 * class Weather - a class to keep track of the weather.
 *
 * @version 2021.03.01
 */
public class Weather
{
    //A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    //Represnts the air tempreture in this habitat.
    private double tempreture;
    //Boolean flag to indicate whether the weather is foggy.
    private boolean isFoggy;
    //Boolean flag to indicate whether the weather is rainy.
    private boolean isRainy;

    /**
     * Construct objects of class weather.
     */
    public Weather()
    {
        setWeather();
    }

    /**
     * Returns the tempreture value.
     * @return the current tempreture value
     */
    public double getTempreture()
    {
        return tempreture;
    }

    /**
     * Sets the tempreture randomly to a value between 0 to 40.
     */
    public void setTempreture()
    {
        tempreture = rand.nextDouble() * 41; 
    }

    /**
     * Sets the weather to fog if the tempreture is between 30 to 41 and to rain if its between 0 to 33.
     */
    public void setWeather()
    {
        setTempreture();
        resetWeather();
        if(tempreture >= 30 && tempreture < 41)
        {
            isFoggy = true;
        }

        if(tempreture >= 0 && tempreture < 33)
        {
            isRainy = true;
        }
    }

    /**
     * Returns true if the weather is foggy.
     * @return true if the weather is foggy, false otherwise
     */
    public boolean isFog()
    {
        return isFoggy;
    }

    /**
     * Returns true if the weather is rainy.
     * @return true if the weather is rainy, false otherwise
     */
    public boolean isRain()
    {
        return isRainy;
    }

    /**
     * Resets the weather conditions.
     */
    private void resetWeather()
    {
        isFoggy = false;
        isRainy = false;
    }

    /**
     * Returns a string describing the status of weather.
     * @return "Foggy and Rainy" if the weather is both foggy and rainy,"Foggy" if the weather is
     * foggy and "Rainy" if it's rainy
     */
    public String getWeatherStatus()
    {
        String status = "";
        if(isFoggy && isRainy)
        {
            status = "Foggy and Rainy";
        }

        else if(isFoggy)
        {
            status = "Foggy";
        }

        else if(isRainy)
        {
            status = "Rainy";
        }
        return status;
    }
}