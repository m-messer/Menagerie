import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field containing different organsims (Plants and Animals).
 *
 * @version 2021.03.01
 */
public class Simulator
{
    //The default width of the simulation
    private static final int DEFAULT_WIDTH = 150;
    //The default depth of the simulation
    private static final int DEFAULT_DEPTH = 100;
    //The number of hours in a day.
    private static final int DAY_HOURS = 24;
    //A list of organisims to be filled.
    private List<Organisim> organisims;
    //Simulation field.
    private Field field;
    //The current step in the simulation, each step represent one hour.
    private int step;
    //A graphical interface of the simulation.
    private SimulatorView view;
    //Populator to initilize organisims.
    private Populator populator;
    //Weather object for the simulation.
    private Weather weather;
    //Keeps track of the time of the day.
    private int timeCounter;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero
     * @param width Width of the field. Must be greater than zero
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) 
        {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        field = new Field(depth, width);
        weather = new Weather();
        populator = new Populator();

        //Populates the organisims list.
        organisims = populator.populateOrganisims(field);

        //Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Tiger.class, Color.RED);
        view.setColor(Butterfly.class, Color.YELLOW);
        view.setColor(Snake.class, Color.BLUE); 
        view.setColor(Plant.class, Color.GREEN);

        //Show the curret status of the simulation.
        view.showStatus(step, field, timeCounter, weather.getWeatherStatus());
    }

    /**
     * Run the simulation from its current state for a reasonably long period.
     * (800 steps).
     */
    public void runLongSimulation()
    {
        simulate(800);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run the simulation
     */
    public void simulate(int numSteps)
    {   
        for(int step = 1; step <= numSteps && view.isViable(field); step++) 
        {   
            simulateOneStep();
            delay(80);
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each organisim.
     */
    public void simulateOneStep()
    {
        //Increments the number of steps.
        step++;
        //Updates time of the day.
        updateTimer();
        //Updates the weather condition.
        updateWeather();
        //Provide space for newborn organisims.
        List<Organisim> newOrganisims = new ArrayList<>();    

        //Let all organisims act.
        for(Iterator<Organisim> it = organisims.iterator(); it.hasNext();) 
        {
            Organisim organisim = it.next();
            organisim.act(newOrganisims, timeCounter, weather);

            if(!organisim.isAlive())
            {
                it.remove();
            }
        }

        //Add the newly born organisims to the main list.
        organisims.addAll(newOrganisims);
        view.showStatus(step, field, timeCounter, weather.getWeatherStatus());
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        timeCounter = 0;
        organisims.clear();
        organisims = populator.populateOrganisims(field);
        view.showStatus(step, field, timeCounter, weather.getWeatherStatus());
    }

    /** 
     * Returns the time counter.
     * @return the time counter
     */
    public int getTime()
    {
        return timeCounter;
    }

    /**
     * Updates the time based on the number of steps taken during the simulation.
     */
    private void updateTimer()
    {
        timeCounter = step % DAY_HOURS;
    }

    /**
     * Updates the weather based on the time of the day.
     */
    private void updateWeather()
    {
        if(timeCounter == 12)
        {
            weather.setWeather();
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try 
        {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) 
        {
            //Wake up.
        }
    }
}
