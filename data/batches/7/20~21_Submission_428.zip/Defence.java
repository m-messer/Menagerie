/**
 * Defence Interface - It provides a template for the prey animals to use.
 *
 * @version 2021.03.01
 */
public interface Defence
{
    //Probability that an animal will activate its defence when its in danger.
    public static final double DEFENSE_PROBABILITY = 0.5;
    
    /**
     * An animal activates its defence when surrounded by predators.
     */
    abstract public void activateDefense(); 
}