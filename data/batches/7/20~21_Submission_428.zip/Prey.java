import java.util.List;
import java.util.Iterator;
/**
 * A class representing shared characteristics of Preys. 
 * 
 * Preys can eat plants, and can be at risk when surrounded by predators.
 *
 * @version 2021.03.01
 */
public abstract class Prey extends Animal implements Defence
{
    //The food value of a plant. In effect, this is the
    //number of steps a Prey can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 9;

    /**
     * Create a prey at given location in field.
     * 
     * @param randomAge determines whether the age of the animal is random
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Prey(boolean randomAge, Field field, Location loc)
    {
        super(randomAge, field, loc);
    }

    /**
     * Return the prey's food (plants) food value.
     * @return the plant food value
     */
    public int getFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }

    /**
     * This is what the animal does most of the time: it hunts for food and breeds.
     * In the process might catch and spread a disease, or die of hunger or of old age.
     * It can also activate defence against predators.
     * @param newOrganisims A list to return newly born animals
     * @param time time of the day
     * @param weather the weather at this time
     */
    public void act(List<Organisim> newOrganisims, int time, Weather weather)
    {
        super.act(newOrganisims, time, weather);
        if(canAct(time))
        {   
            //Prey activates its defence mechanisim.
            activateDefense();
            move();
        }
    }

    /**
     * Look for food adjacent to the current location. 
     * If it's a prey it eats plants, and if it's a predator it eats a prey
     * @return where food was found, or null if it wasn't
     */
    public Location findFood()
    {
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) 
        {
            Location where = it.next();            
            Object organism = getField().getObjectAt(where);
            if(organism instanceof Plant) 
            {
                Plant plant = (Plant) organism;
                if(plant.isAlive()) 
                {   
                    plant.setDead();
                    updateFoodLevel(PLANT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Checks if a prey is in next to a predator.
     * @return true if it's adjacent to a predator, false otherwise
     */
    public boolean inDanger()
    {
        boolean predatorFound = false;
        List<Location> neighbors = getField().adjacentLocations(getLocation());
        Iterator<Location> it = neighbors.iterator();
        while(it.hasNext())
        {
            Location where = it.next();            
            Object organisim = getField().getObjectAt(where);
            //Checks if there is a neighboring predator.
            if(organisim != null && organisim instanceof Predator)
            {
                predatorFound = true;
            }   
        }
        return predatorFound;
    }
}