import java.util.List;
import java.util.Random;
/**
 * Abstract class Organisim - a class representing shared characterstics between animals and plants.
 *
 * @version 2021.03.01
 */
public abstract class Organisim
{   
    //Represents whether an organisim is alive or dead.
    private boolean alive;
    //The organism field.
    private Field field;
    //The organism location.
    private Location location; 

    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Organisim (Field field, Location location)
    {
        alive = true;
        this.field = field;
        this.location = location;
        setLocation(location);
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is alive, false otherwise
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Removes the organism from the field when it is no longer alive.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) 
        {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) 
        {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the organism's location.
     * @return The organism's location
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Return the organism's field.
     * @return The organism's field
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * This is what the organism does most of the time: it hunts for food and breeds.
     * 
     * @param newOrganisims A list to return newly born animals
     * @param time time of the day
     * @param weather the weather at this time
     */
    abstract public void act(List<Organisim> newOrganisims, int time, Weather weather);
}