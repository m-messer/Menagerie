import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 * 
 * Animals can act during the simulation, they can reproduce and look for their food source.
 * 
 * Animals can also catch a disease and transmit it to their neighboring animals.
 *
 * @version 2021.03.01
 */
public abstract class Animal extends Organisim 
{   
    //A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    //Probability that an animal will be randomly infected by a disease.
    private static final double DISEASE_EXISTENCE_PROBABILITY = 0.001;
    //The likelihood of an animal's sex to be female.
    private static final double SEX_PROBABILITY = 0.5;
    //Represents whether an animal is male or female.
    private boolean isFemale; 
    //Current food level of the animal.
    private int foodLevel;
    //Represents the animal's age.
    private int age;
    //Represents a disease that an animal can catch.
    private Disease disease;

    /**
     * Create a new animal at location in field, and sets the initial age, sex and food level based on randomAge value.
     * 
     * @param randomAge determines whether the age of the animal is random
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        //Sets the animal's initial age, sex, and food level.
        setFoodLevel(randomAge);
        setAge(randomAge);
        setSex();
    }

    /**
     * Sets sex to female or male based on sex probability.
     */
    protected void setSex()
    {
        //Animal's sex is determined randomly by the sex probability.
        if (rand.nextDouble() <= SEX_PROBABILITY)
        {
            isFemale = true;
        }

        else
        {
            isFemale = false;
        }
    }

    /**
     * Sets the animal's food level randomly or to their prey food value.
     * @param randomAge determines whether the food level of the animal is random
     */
    protected void setFoodLevel(boolean randomAge)
    {
        if(randomAge) 
        {
            foodLevel = rand.nextInt(getFoodValue());
        }
        else 
        {
            foodLevel = getFoodValue();
        }
    }

    /**
     * Sets animal's age randomly if random age is true, and to 0 otherwise.
     * @param randomAge determines whether the age of the animal is random
     */
    protected void setAge(boolean randomAge)
    {
        if(randomAge) 
        { 
            //Age is set to a value between 0 and the animal's max age.
            age = rand.nextInt(getMaxAge());
        }
        else 
        {
            age = 0;
        }
    }

    /**
     * Returns the animal's sex.
     * @return true if the animal is female, and false if male
     */
    protected boolean isFemale() 
    {
        return isFemale;
    }

    /**
     * Updates the animal food level to newlevel.
     * @param newLevel the animal food level is set to newLevel
     */
    protected void updateFoodLevel(int newLevel)
    {
        foodLevel = newLevel;
    }

    /**
     * This is what the animal does most of the time: it hunts for food and breeds.
     * In the process it might catch and spread a disease, or die of hunger or of old age.
     * @param newOrganisims A list to return newly born animals
     * @param time time of the day
     * @param weather the weather at this time
     */
    public void act(List<Organisim> newOrganisims, int time, Weather weather)
    {
        incrementAge();
        incrementHunger();
        //Checks if the disease has killed the animal.
        simulateDiseaseEffect();
        //Checks whether the animal is alive and awake.
        if(canAct(time))
        { 
            catchDisease();
            spreadDisease();
            giveBirth(newOrganisims);
        }
    }

    /**
     * Checks if the animal is alive and awake.
     * @param time time of the day 
     * @return true if the animal is alive and not sleeping, false otherwise
     */
    public boolean canAct(int time)
    {
        return isAlive() && !isSleeping(time);
    }

    /**
     * Make the animal move if it finds food, or to an empty location if it does not.
     * if there is no empty adjacent location it dies of overcrowding.
     */
    public void move()
    {
        //Cheks if the food level of the animal is low.
        if(foodLevel <= 5)
        {
            //Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) 
            { 
                //No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            //See if it was possible to move.
            if(newLocation != null) 
            {
                setLocation(newLocation);
            }
            else 
            {
                //Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make the animal more hungry. This could result in the animal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0)
        {
            setDead();
        }
    }

    /**
     * Make the animal grow older. This could result in the animal's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > getMaxAge())
        {
            setDead();
        }
    }

    /**
     * The animal catches a disease randomly if it's not infected.
     */
    private void catchDisease()
    {   
        //An animal can catch a new disease based on disease existence probability.
        if(!isInfected() && rand.nextDouble() <= DISEASE_EXISTENCE_PROBABILITY)
        {
            setNewDisease();
        }
    }

    /**
     * The animal spreads the disease to adjacent animals of the same species, based on probaility of infection.
     */
    private void spreadDisease()
    {
        //Check that the animal is infected.
        if(isInfected())
        {
            List<Location> neighbors = getField().adjacentLocations(getLocation());
            Iterator<Location> it = neighbors.iterator();
            while(it.hasNext())
            {
                Location where = it.next();            
                Object obj = getField().getObjectAt(where);
                //Check that the neighboring animal is of the same species.
                if(obj != null && obj.getClass() == this.getClass()) 
                {   Animal animal = (Animal) obj;
                    //Animals are infected based on infection probability.
                    if(rand.nextDouble() <= disease.infenctionByContacnt()) 
                    { 
                        //Transmit the disease to the adjacent animal.
                        transmitDisease(animal);
                    }
                }
            }
        }
    }

    /**
     * Gives the disease to the adjacent animal if it's not infected.
     * @param animal the animal to be infected from the disease
     */
    private void transmitDisease(Animal animal)
    {
        if(!animal.isInfected())
        {
            animal.setNewDisease();
        }
    }

    /**
     * Create a new disease for the animal.
     */
    private void setNewDisease()
    {
        disease = new Disease();
    }

    /**
     * Check if the disease incubation period is over, if true it randomly sets the animal to dead
     * based on death probability.
     */
    private void simulateDiseaseEffect()
    {
        if(isInfected() && disease.incubationFinished())
        {
            if(rand.nextDouble() <= disease.getDeathProbability())
            {
                setDead();
            }
            //Set disease to null when incubation period is over.
            disease = null;
        }
    }

    /**
     * Checks whether an animal is infected with a disease.
     * @return true if disease is not null, false otherwise
     */
    private boolean isInfected()
    {
        return (disease != null);
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise
     */
    private boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * An animal gives birth to new animals into free adjacent loctions.
     * @param newAnimals a list to add new born animals into
     */
    private void giveBirth(List<Organisim> newAnimals)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            Location loc = free.remove(0);
            Organisim young = generateNewBorn(false, field, loc);
            newAnimals.add(young);
        }
    }

    /**
     * Generates the number of births for an animal if it can breed.
     * @return the number of births of an animal.
     */
    private int breed()
    {
        int births = 0;
        //An animal can breed if it reaches breeding age, meet opposite sex and based on breeding probability.
        if(canBreed() && meetOppositeSex() && rand.nextDouble() <= getBreedingProbability()) 
        {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Check whether or not this animal is adjacent to an animal of the opposite sex.
     * @return true if an animal meets another animal of opposite sex, false otherwise
     */
    private boolean meetOppositeSex()
    {
        List<Location> neighbors = getField().adjacentLocations(getLocation());
        Iterator<Location> it = neighbors.iterator();
        while(it.hasNext())
        {
            Location where = it.next();            
            Object obj = getField().getObjectAt(where);
            if(obj != null && obj.getClass() == this.getClass()) 
            {
                Animal animal = (Animal) obj;
                //Checks whether this animal and the neihboring animal are of opposite sex.
                if(isFemale() != animal.isFemale()) 
                { 
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Generate a new born of animal.
     * @param randomAge If true, the animal will have a random age
     * @param field The field currently occupied
     * @param location The location within the field
     * 
     * @return new organisim object
     */
    abstract public Organisim generateNewBorn(boolean randomAge, Field field, Location loc);

    /**
     * Look for food adjacent to the current location. 
     * @return where food was found, or null if it wasn't
     */
    abstract public Location findFood();

    /**
     * Checks if an animal is sleeping.
     * @param time time of the day
     * 
     * @return true if time is between 11 to 13, false otherwise
     */
    abstract public boolean isSleeping(int time);

    // A list of accessor methods
    /** 
     * Returns the breeding probability of an animal.
     * @return the breeding probability
     */
    abstract public double getBreedingProbability();

    /** 
     * Returns the max litter size of an animal.
     * @return the max litter size
     */
    abstract public int getMaxLitterSize();

    /** 
     * Returns the breeding age of an animal.
     * @return the breeding age
     */
    abstract public int getBreedingAge();

    /** 
     * Returns the food value of an animal.
     * @return the food value
     */
    abstract public int getFoodValue();

    /** 
     * Returns the max age of an animal.
     * @return the max age
     */
    abstract public int getMaxAge();
}
