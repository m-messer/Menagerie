public interface EatableByFalcon {
}
