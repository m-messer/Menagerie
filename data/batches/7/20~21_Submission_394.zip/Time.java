
/**
 * A timer which returns whether it is day.
 *
 * @version (a version number or a date)
 */
public class Time
{

    /**
     * Return true if the setting now is day.
     *
     * @return True if the setting is day
     */
    public boolean getTime(int step)
    {
        return step % 2 < 1;
    }
}
