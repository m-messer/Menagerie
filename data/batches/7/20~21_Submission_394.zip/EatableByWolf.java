public interface EatableByWolf {
}
