import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Disease class. Occasionally, random diseases are generated affecting random species.
 * There is a variety of diseases.
 *
 * @version (a version number or a date)
 */
public class Disease
{
    // Number of animals one disease can kill until the rest of the animals become immune to it and it no longer can kill them.
    private static final int MAX_DEATH = 100;
    // Probability that another animal can get infected. The smaller the number, the bigger the probability.
    int infectionRate;
    // Specifies whether disease can hop across different species or is limited only to their own.
    boolean hoppingDisease;
    // Specifies how many more steps an animal can make until it dies.
    Integer stepsLeftToLive;
    // Range of disease: how far an animal has to be from other animal for the disease to spread.
    int range;
    // List of animals that the specific disease has infected.
    List<Animal> infectedAnimalList = new LinkedList<>();
    int totalInfections;
    int maxDeaths;

    /**
     * Constructor for objects of class Disease.
     * Nobody can control or foresee an upcoming disease.
     * Chances of disease appearing are completely random.
     * Limits can be changed and experimented with.
     */
    public Disease()
    {
        Random random = new Random();
        range = 1;
        // The smaller the number, the bigger is the probability for infection to spread.
        // Meaning, that if random number is 5, probability for the disease to spread will be 1/5.
        infectionRate = random.nextInt(5) + 1;
        hoppingDisease = random.nextBoolean();
        stepsLeftToLive = random.nextInt(2);
        totalInfections = 0;
        // Each disease can kill between 10 and MAX_DEATH animals
        maxDeaths = random.nextInt(MAX_DEATH) + 10;
    }

    /**
     * After each step is made in the system, the list of diseased animals.
     * is reviewed to check if any of the animals have died and in that case remove them from the list.
     * If it is not dead, remaining steps to live are reduced by one.
     */
    public void reviewInfectedAnimals() {
        for (Iterator<Animal> iterator = infectedAnimalList.listIterator(); iterator.hasNext();) {
            Animal animal = iterator.next();
            if (animal.getStepsToLiveIfInfected() == 0) {
                iterator.remove();
                animal.setDead();
            }
            else {
                animal.decreaseStepsToLiveIfInfected();
            }
        }
    }

    /**
     * Infected animal spreads the disease to nearby animals, if it can, based on the type of disease.
     * @param infectedAnimal animal that has the ability to spread the disease
     */
    public void spreadDisease (Animal infectedAnimal) {
        reviewInfectedAnimals();
        List<Animal> around = infectedAnimal.meet(range);
        if (totalInfections > maxDeaths) {
            return;
        }

        infectAnimal(infectedAnimal);
        for (Animal animal : around) {
            if (animal != null) {
                if (tryToInfect()) {
                    if (hoppingDisease) {
                        //infectAnimal(animal);
                        spreadDisease(animal);
                    } else {
                        if ((animal.getClass() == infectedAnimal.getClass())) {
                            //infectAnimal(animal);
                            spreadDisease(animal);
                        }
                    }
                }
            }
        }
    }

    /**
     * Tries to infect an animal based on how easily the disease spreads.
     * @return true, if animal was infected
     */
    private boolean tryToInfect() {
        Random random = new Random();
        return random.nextInt(infectionRate)==0;
    }

    /**
     * Infect an animal with the disease.
     * @param animal animal that has been infected with the disease.
     */
    private void infectAnimal(Animal animal) {
        totalInfections++;
        animal.setStepsToLiveIfInfected(stepsLeftToLive);
        infectedAnimalList.add(animal);
    }
}
