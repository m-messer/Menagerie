import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a falcon.
 *
 * @version 2016.02.29 (2)
 */
public class Falcon extends Carnivore
{
    // Characteristics shared by all falcons (class variables).
    private static final int BREEDING_AGE = 2;
    // The age to which a falcon can live.
    private static final int MAX_AGE = 8;
    // The likelihood of a falcon breeding.
    private static final double BREEDING_PROBABILITY = 0.23;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // This is the number of steps a falcon can go before it has to eat again.
    private static final int FOOD_VALUE = 8;
    // This is to indicate whether a falcon is diurnal(Active in day).
    private static final boolean DIURNALITY = true;
    // This is the number of grids a falcon can meets another one across.
    private static final int MEET_RANGE = 5;
    
    /**
     * Create a falcon. A falcon can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     */
    public Falcon(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the falcon does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newFalcons A list to return newly born falcon.
     */
    public void act(List<Animal> newFalcons)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newFalcons);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Falcon don't live on the ground so no overcrowding.
                // setDead();
            }
        }
    }

    /**
     * Check whether or not this falcon is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFalcons A list to return newly born falcons.
     */
    private void giveBirth(List<Animal> newFalcons)
    {
        // New falcons are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Falcon young = new Falcon(false, field, loc);
            newFalcons.add(young);
        }
    }

    /**
     * Return whether the animal is a prey of falcon.
     * @param animal nearby animal.
     * @return whether the given animal is eatable by falcon or not.
     */
    public boolean getEatablePrey(Animal animal) {
        return animal instanceof EatableByFalcon;
    }

    /**
     * Return the falcon's maximum age.
     * @return The falcon's maximum age.
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the falcon's maximum litter size.
     * @return The falcon's maximum litter size.
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the falcon's breeding age.
     * @return The falcon's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the falcon's breeding probability.
     * @return The falcon's breeding probability.
     */
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the falcon's food value.
     * @return The falcon's food value.
     */
    public int getFoodValue() {
        return FOOD_VALUE;
    }
    
    /**
     * Return the falcon's diurnality.
     * @return True if falcon is active in day.
     */
    public boolean getDiurnality() {
        return DIURNALITY;
    }     
    
    /**
     * Return the falcon's meeting range.
     * @return The falcon's meeting range.
     */
    public int getMeetRange() {
        return MEET_RANGE;
    }
}
