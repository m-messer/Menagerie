import java.util.List;

/**
 * A simple model of a sheep.
 *
 * @version 2016.02.29 (2)
 */
public class Sheep extends Herbivore implements EatableByWolf, EatableByFox, EatableByFalcon
{
    // Characteristics shared by all sheeps (class variables).

    // The age at which a sheep can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a sheep can live.
    private static final int MAX_AGE = 17;
    // The likelihood of a sheep breeding.
    private static final double BREEDING_PROBABILITY = 0.95;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 14;
    // This is the number of steps a sheep can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    // This is to indicate whether a sheep is diurnal(Active in day).
    private static final boolean DIURNALITY = true;
    // This is the number of grids a sheep can meets another one across.
    private static final int MEET_RANGE = 5;

    /**
     * Create a new sheep. A sheep may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sheep(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the sheep does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newSheeps A list to return newly born sheeps.
     */
    public void act(List<Animal> newSheeps)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSheeps);
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null && !findFood()) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Check whether or not this sheep is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSheeps A list to return newly born sheeps.
     */
    private void giveBirth(List<Animal> newSheeps)
    {
        // New sheeps are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Sheep young = new Sheep(false, field, loc);
            newSheeps.add(young);
        }
    }
        
    /**
     * Return the sheep's maximum age.
     * @return The sheep's maximum age.
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the sheep's maximum litter size.
     * @return The sheep's maximum litter size.
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the sheep's breeding age.
     * @return The sheep's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the sheep's breeding probability.
     * @return The sheep's breeding probability.
     */
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the sheep's food value.
     * @return The sheep's food value.
     */
    public int getFoodValue() {
        return FOOD_VALUE;
    }
    
    /**
     * Return the sheep's diurnality.
     * @return True if sheep is active in day.
     */
    public boolean getDiurnality() {
        return DIURNALITY;
    }     
    
    /**
     * Return the sheep's meeting range.
     * @return The sheep's meeting range.
     */
    public int getMeetRange() {
        return MEET_RANGE;
    }
}
