import java.util.Random;
/**
 * The settings to be processed and checked in each simulation step.
 *
 * @version (a version number or a date)
 */
public class Weathers
{
    // The probability that rain will be generated.
    private static final double RAIN_PROBABILITY = 0.20;      
    // The probability that fog will be generated.
    private static final double FOG_PROBABILITY = 0.20;    
    // The probability that draught will be generated.
    private static final double DRAUGHT_PROBABILITY = 0.20;  
    
    
    // The longest weather duration
    private static final int WEATHER_TIME = 3;
    // Weather duration
    private int weatherTime;
    // The weather in the step
    private Weather weather;
    // Step counters to change weather back to default
    private int counter;
    // Randomizer to choose random weather duration
    private Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Weathers
     * Initialize it to Weather.CLEAR.
     * Reset the counter.
     */
    public Weathers()
    {
        weather = Weather.CLEAR;
        counter = 0;
        weatherTime = rand.nextInt(WEATHER_TIME);
    }
    
    /**
     * The method makes an increment to make weather cycle
     * with possiblity of varying between four enum types.
     */
    public void increment()
    {
        counter++;
        if (counter >= weatherTime){
            if (rand.nextDouble() <= RAIN_PROBABILITY){
                changeWeather(Weather.RAIN);
            }
            else if(rand.nextDouble() <= RAIN_PROBABILITY + FOG_PROBABILITY){
                changeWeather(Weather.FOG);
            }
            else if(rand.nextDouble() <= RAIN_PROBABILITY + FOG_PROBABILITY + DRAUGHT_PROBABILITY){
                changeWeather(Weather.DRAUGHT);
            }
            else{
                changeWeather(Weather.CLEAR);
            }
        }
    }
    
    /**
     * Change the weather to another weather and reset 
     * the counter.
     * @param another weather
     */
    private void changeWeather(Weather w)
    {
        weather = w;
        counter = 0;
        weatherTime = rand.nextInt(WEATHER_TIME);
    }

    /**
     * Return the current weather.
     * 
     * @return weather of current setting
     */
    public Weather getWeather()
    {
        return weather;
    }
}
