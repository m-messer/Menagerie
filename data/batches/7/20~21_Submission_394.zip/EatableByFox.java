public interface EatableByFox {
}
