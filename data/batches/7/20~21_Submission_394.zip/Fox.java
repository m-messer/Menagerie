import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Fox extends Carnivore implements EatableByFalcon
{
    // Characteristics shared by all foxes (class variables).
    private static final int BREEDING_AGE = 3;
    // The age to which a fox can live.
    private static final int MAX_AGE = 9;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // This is the number of steps a fox can go before it has to eat again.
    private static final int FOOD_VALUE = 10;
    // This is to indicate whether a sheep is diurnal(Active in day).
    private static final boolean DIURNALITY = false;
    // This is the number of grids a fox can meets another one across.
    private static final int MEET_RANGE = 5;
    
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     */
    public Fox(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the fox does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Animal> newFoxes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newFoxes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Animal> newFoxes)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fox young = new Fox(false, field, loc);
            newFoxes.add(young);
        }
    }

    /**
     * Return whether the animal is a prey of fox.
     * @param animal nearby animal.
     * @return whether the given animal is eatable by fox or not.
     */
    public boolean getEatablePrey(Animal animal) {
        return animal instanceof EatableByFox;
    }

    /**
     * Return the fox's maximum age.
     * @return The fox's maximum age.
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the fox's maximum litter size.
     * @return The fox's maximum litter size.
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the fox's breeding age.
     * @return The fox's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the fox's breeding probability.
     * @return The fox's breeding probability.
     */
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the fox's food value.
     * @return The fox's food value.
     */
    public int getFoodValue() {
        return FOOD_VALUE;
    }
    
    /**
     * Return the fox's diurnality.
     * @return True if fox is active in day.
     */
    public boolean getDiurnality() {
        return DIURNALITY;
    }     
    
    /**
     * Return the fox's meeting range.
     * @return The fox's meeting range.
     */
    public int getMeetRange() {
        return MEET_RANGE;
    }
}
