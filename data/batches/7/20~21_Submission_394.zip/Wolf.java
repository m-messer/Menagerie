import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a wolf.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Carnivore
{
    // Characteristics shared by all wolves (class variables).
    private static final int BREEDING_AGE = 3;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 11;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.20;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // This is the number of steps a wolf can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    // This is to indicate whether a wolf is diurnal(Active in day).
    private static final boolean DIURNALITY = false;
    // This is the number of grids a wolf can meets another one across.
    private static final int MEET_RANGE = 5;
        
    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the wolf does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newWolves A list to return newly born wolf.
     */
    public void act(List<Animal> newWolves)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWolves);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolves.
     */
    private void giveBirth(List<Animal> newWolves)
    {
        // New wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, field, loc);
            newWolves.add(young);
        }
    }

    /**
     * Return whether the animal is a prey of wolf.
     * @param animal nearby animal
     * @return whether the given animal is eatable by wolf or not.
     */
    public boolean getEatablePrey(Animal animal) {
        return animal instanceof EatableByWolf;
    }
        
    /**
     * Return the wolf's maximum age.
     * @return The wolf's maximum age.
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the wolf's maximum litter size.
     * @return The wolf's maximum litter size.
     */
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the wolf's breeding age.
     * @return The wolf's breeding age.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the wolf's breeding probability.
     * @return The wolf's breeding probability.
     */
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the wolf's food value.
     * @return The wolf's food value.
     */
    public int getFoodValue() {
        return FOOD_VALUE;
    }
    
    /**
     * Return the wolf's diurnality.
     * @return True if wolf is active in day.
     */
    public boolean getDiurnality() {
        return DIURNALITY;
    }     
    
    /**
     * Return the wolf's meeting range.
     * @return The wolf's meeting range.
     */
    public int getMeetRange() {
        return MEET_RANGE;
    }
}
