import java.util.List;
import java.util.Iterator;
/**
 * Abstract class Carnivore 
 * An attempt to reuse the findFood() method in animals' 
 * seperate classes.
 * @version (version number or date here)
 */
public abstract class Carnivore extends Animal
{
    /**
     * Create a new herbivore. A herbivore may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Carnivore(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Look for food adjacent to the current location.
     * Only the first live food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Animal animal = (Animal) field.getObjectAt(where);
                if (getEatablePrey(animal)) {
                    if (animal.isAlive()) {
                        animal.setDead();
                        resetFoodLevel();
                        return where;
                    }
                }

        }
        return null;
    }

    /**
     * Return whether the animal is a prey of certain species of animal.
     * @param animal nearby animal.
     * @return whether the given animal is eatable by the specific animal or not.
     */
    protected abstract boolean getEatablePrey(Animal animal);
}
