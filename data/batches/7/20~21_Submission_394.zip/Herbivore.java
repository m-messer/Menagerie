
/**
 * Abstract class Herbivore 
 * An attempt to reuse the findFood() method in animals' 
 * seperate classes.
 * @version (version number or date here)
 */
public abstract class Herbivore extends Animal
{
    /**
     * Create a new herbivore. A herbivore may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Herbivore(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Find plants in the current location.
     * Eat it if it has food level.
     * Return the status of finding food as a boolean.
     * @return True if the animal find some food.
     */
    protected boolean findFood()
    {
        Field field = getField();
        // Calculate how much food is needed.
        int needFood = getFoodValue() - getFoodLevel();
        if (field.getPlantLevel(getLocation()) >= needFood) {
            resetFoodLevel();
            field.consume(needFood, getLocation());
            return true;
        }
        else {
            return false;
        }
    }
}
