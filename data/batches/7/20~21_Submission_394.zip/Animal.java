import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Randomizer.
    private static final Random rand = Randomizer.getRandom();

    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // Animal's age.
    private int age;
    // Animal's food level.
    private int foodLevel;
    // Animal's gender
    private boolean gender; // T (true) - female, F (false) - male
    // If animal is infected, tells how many steps it has to live.
    private int stepsToLiveIfInfected;

    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge If true, the animal will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        foodLevel = getFoodValue()/3;
        gender = rand.nextBoolean();
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(getFoodValue());
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    protected void decreaseStepsToLiveIfInfected() {
        this.stepsToLiveIfInfected--;
    }

    protected void setStepsToLiveIfInfected(int daysToLive) {
        this.stepsToLiveIfInfected = daysToLive;
    }

    protected int getStepsToLiveIfInfected() {
        return this.stepsToLiveIfInfected;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make an animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Returns the animal's food level (hunger).
     */    
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * An animal's food level is reset (animal is no longer hungry).
     */
    protected void resetFoodLevel() {
        foodLevel = getFoodValue();
    }

    /**
     * Checks the surrounding area for other animals.
     * @return A list of nearby animals (that an animal has met).
     */
    protected List<Animal> meet(int radius) {
        List<Animal> nearAnimals = new ArrayList<>();
        if (isAlive()) {
            Field field = getField();
            List<Location> subadjacent = field.subadjacentLocations(getLocation(),radius);
            Iterator<Location> it = subadjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Animal animal = (Animal) field.getObjectAt(where);
                nearAnimals.add(animal);
            }
        }
        return nearAnimals;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age and has met
     * another animal of different gender but the same species.
     */
    private boolean canBreed()
    {
        boolean meet = false;
        for(Animal animal : meet(getMeetRange())){
            if (animal != null && animal.getClass() == this.getClass() && !animal.gender) {
                if (animal.isAlive() && age >= animal.getBreedingAge()) {
                    meet = true;
                }
            }
        }   
        return age >= getBreedingAge() && gender && meet;
    }
    
    // Getters for specific animal species fields
    abstract public int getMaxAge();
    abstract public int getMaxLitterSize();
    abstract public int getBreedingAge();
    abstract public int getFoodValue();
    abstract public double getBreedingProbability();
    abstract public boolean getDiurnality();
    abstract public int getMeetRange();
}
