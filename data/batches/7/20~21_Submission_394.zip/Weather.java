
/**
 * Enumeration class Weather - Stating the type of weather
 *
 * @version (version number or date here)
 */
public enum Weather
{
    RAIN, DRAUGHT, FOG, CLEAR
}
