import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Sharks, Whales, SeaTurtles, Seals, Shrimp and SeaWeed.
 *
 * @version 2019.02.22
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 300;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;
    // The probability that a Shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.05;
    // The probability that a Whale will be created in any given grid position.
    private static final double WHALE_CREATION_PROBABILITY = 0.07;
    // The probability that a Seal will be created in any given grid position.
    private static final double SEAL_CREATION_PROBABILITY = 0.09;  
    // The probability that a Shrimp will be created in any given grid position.
    private static final double SHRIMP_CREATION_PROBABILITY = 0.25; 
    // The probability that a Sea Turtle will be created in any given grid position.
    private static final double SEA_TURTLE_CREATION_PROBABILITY = 0.06; 
    // The probability that a Sea Weed will be created in any given grid position.
    private static final double SEA_WEED_CREATION_PROBABILITY = 0.3;  

    // List of animals in the field.
    private List<Animal> animals;
    // List of SeaWeed in the field.
    private List<SeaWeed> seaWeeds;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    //Create Earthquake weather object.
    private Earthquake currentWeather;
    //String of the current weather.
    private String currentWeatherName;
    //String of the current time of day.
    private String currentTimeOfDay = "Morning";
    //integer of the current temprature of water.
    private int currentTemprature = 12;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
         this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        seaWeeds = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        //Assign color to all the visible animals and seaweed
        view.setColor(Shark.class, Color.RED);
        view.setColor(Whale.class, Color.ORANGE);
        view.setColor(Seal.class, Color.YELLOW);
        view.setColor(Shrimp.class, Color.MAGENTA);
        view.setColor(SeaTurtle.class, Color.CYAN);
        view.setColor(SeaWeed.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Sharks, Whales, SeaTurtles, Seals, Shrimp and SeaWeed.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Provide space for newborn seaweed.
        List<SeaWeed> newSeaWeed = new ArrayList<>();
        
        // Let all Animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, currentTimeOfDay, currentTemprature);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        // Let all SeaWeed act.
        for(Iterator<SeaWeed> it = seaWeeds.iterator(); it.hasNext(); ) {
            SeaWeed seaWeed = it.next();
            int noOfSeaWeed = seaWeeds.size();
            if (noOfSeaWeed<(DEFAULT_WIDTH*DEFAULT_DEPTH/2)){
                seaWeed.act(newSeaWeed, currentTimeOfDay);
            }
            
            if(! seaWeed.isAlive()) {
                it.remove();
            }
        }
        
        // Add the newly born Animals to the main list of all animals.
        animals.addAll(newAnimals);
        // Add the newly born SeaWeed to the main list of all SeaWeed.
        seaWeeds.addAll(newSeaWeed);
        
        // Simulate Earthquake every 200 Steps.
        if (step%200 == 0){
            Earthquake currentWeather = new Earthquake();
            // Update the list of all Animals after the earthquake has killed off some of the animals.
            animals = currentWeather.act(animals);
            // Update the current weather name to be earthquake
            currentWeatherName = currentWeather.getName();
        }
        // Set the name of the current weather to Normal if it is not an Earthquake.
        else{
            currentWeatherName= "Normal";
        }
        
        //Method to check the current time of day.
        timeOfDay();
        
        // Show the current state in the view.
        view.showStatus(step, currentWeatherName, currentTimeOfDay, currentTemprature, field);
    }
    
    /**
     * Check the current time of day using the number of steps.
     * There are 4 possiblilities for time of day each lasting 25 steps:
     * Morning, Afternoon, Evening and Night.
     */
    public void timeOfDay(){
        Random rand = new Random();
        if(step%100 == 0){
            currentTimeOfDay = "Morning";
            //Temprature between 10-20
            currentTemprature = rand.nextInt(10) + 10;
        }
        else if(step%75 == 0){
            currentTimeOfDay = "Night";
            //Temprature between 5-15
            currentTemprature = rand.nextInt(10) + 5;
        }
        else if(step%50 == 0){
            currentTimeOfDay = "Evening";
            //Temprature between 10-20
            currentTemprature = rand.nextInt(10) + 15;
        }
        else if(step%25 == 0){
            currentTimeOfDay = "Afternoon";
            //Temprature between 15-25
            currentTemprature = rand.nextInt(10) + 20;
        }
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        // Show the starting state in the view.
        view.showStatus(step, currentWeatherName, currentTimeOfDay, currentTemprature, field);
    }
    
    /**
     * Randomly populate the field with Sharks, Whales, SeaTurtles, Seals, Shrimp and SeaWeed.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    animals.add(whale);
                }
                else if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location);
                    animals.add(seal);
                }
                else if(rand.nextDouble() <= SHRIMP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shrimp shrimp = new Shrimp(true, field, location);
                    animals.add(shrimp);
                }
                else if(rand.nextDouble() <= SEA_TURTLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    SeaTurtle seaTurtle = new SeaTurtle(true, field, location);
                    animals.add(seaTurtle);
                }
                else if(rand.nextDouble() <= SEA_WEED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    SeaWeed seaWeed = new SeaWeed(true, field, location);
                    seaWeeds.add(seaWeed);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
