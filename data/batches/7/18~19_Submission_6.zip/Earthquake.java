import java.util.*;
/**
 * To simulate an earthquake by killing a certain fraction
 * of the currently living animals.
 *
 * @version 2019.02.22
 */
public class Earthquake
{
    
    // Maximum magnitude of earthquake, value represents max percentage killed.
    private static final int MAX_MAG = 30;
    private static final Random rand = Randomizer.getRandom();
    // magnitude variable as a decimal.
    private int magnitude;
    // Name of the current weather object.
    private String name;
    /**
     * Constructor for objects of class Earthquake
     */
    public Earthquake()
    {
        name = "Earthquake";
        magnitude = rand.nextInt(MAX_MAG);
    }
    
    /**
     * Return name of current weather object.
     * @return name
     */
    public String getName(){
        return name;
    }
    
    /**
     * Return a list of animals currently alive after an Earthquake event.
     *
     * @param animals
     * @return animals
     */
    public List<Animal> act(List<Animal> animals)
    {
       int noAnimals = animals.size();
       int removingAnimals = Math.round(noAnimals*magnitude/100);
       Collections.shuffle(animals);
       Iterator<Animal> it = animals.iterator();
       for(int i = 0; i<removingAnimals; i++) {
            Animal animal = it.next();
            animal.setDead();
            it.remove();
        } 
       
       return animals;
    }
}
