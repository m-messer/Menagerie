import java.util.*;

/**
 * A model of the behavior of zebras.
 * Zebras age, move, breed , eat plants and die under certain circumstances.
 *
 * @version 2021.03.02 (1)
 */
public class Zebra extends Animal
{
    /**
     * Create a zebra. A zebra can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // The age at which a zebra can start to breed.
        BREEDING_AGE = 1;
        // The age to which a zebra can live.
        MAX_AGE = 150;
        // The likelihood of a zebra breeding.
        BREEDING_PROBABILITY = BreedingProb.ZEBRA.getValue();
        // The maximum number of births a zebra can give.
        MAX_LITTER_SIZE = 40;
       
        //Zebra's foodlevel
        foodLevel = 80;
        //Zebras do not act at night.
        doesActAtNight = false;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(foodLevel);
        }
        else {
            age = 0;
            foodLevel = foodLevel;
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel += foodLevel + plant.getFoodValue(); 
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this zebra is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    public void giveBirth(List<Living> newZebras)
    {
        // New zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(canAnimalBreed()){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Zebra young = new Zebra(false, field, loc);
                newZebras.add(young);
            }        
        }
        
    }
}
