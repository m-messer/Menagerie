
/**
 * Holds the breeding probabilites of animals and plants. 
 * Makes it easier to be accsesed from the simulator class
 *
 * @version 2021.03.02 (1)
 */
public enum BreedingProb
{
    
    DEER(0.10), WOLF(0.10), PLANT(0.4), LION(0.05), ZEBRA(0.05), TIGER(0.05);
    
    // The value of the Breeding Probabiilty
    private double value;
    
    /**
     * Consturcts a BreedingProb object
     * Only has a double value
     */
    BreedingProb(double value){
        this.value= value;
    }
    
    /**
     * @return the value of Breeding probability
     */
    public double  getValue(){
        return value;
    }
    
}
