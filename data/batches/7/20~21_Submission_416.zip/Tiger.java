import java.util.*;

/**
 * A model of the behavior of tigers.
 * Tigers age, move, breed , eat plants and die under certain circumstances.
 *
 * @version 2021.03.02 (1)
 */
public class Tiger extends Animal
{
    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // The age at which a tiger can start to breed.
        BREEDING_AGE = 15;
        // The age to which a tiger can live.
        MAX_AGE = 150;
        // The likelihood of a tiger breeding.
        BREEDING_PROBABILITY = BreedingProb.TIGER.getValue();
        // The maximum number of births a tiger can give.
        MAX_LITTER_SIZE = 2;
       
        //Tiger's foodlevel
        foodLevel = 11;
        //Tigers do not act at night
        doesActAtNight = false;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(foodLevel);
        }
        else {
            age = 0;
            foodLevel = foodLevel;
        }
    }
    

    /**
     * Look for food source(Zebras) adjacent to the current location.
     * Only the first live zebra is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if(zebra.isAlive()) { 
                    zebra.setDead();
                    foodLevel += foodLevel + zebra.getFoodValue(); 
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not the tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTigers A list to return newly born tigers.
     */
    public void giveBirth(List<Living> newTigers)
    {
        // Get a list of adjacent free locations.
        if(canAnimalBreed()){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Tiger young = new Tiger(false, field, loc);
                newTigers.add(young);
            }
        }
        
    }
}
