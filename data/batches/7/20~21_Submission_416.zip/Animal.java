import java.util.*;

/**
 * A class representing shared characteristics of all animals.
 *
 * @version 2021.03.02 (3)
 */
public abstract class Animal extends Living
{  
    //every animal has a gender
    protected Gender gender;
    // Holds wheter the animal is night or day animal
    // True - sleeps during day acts at night
    // False - sleeps at night acts during day
    protected boolean doesActAtNight;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);          
        gender = gender.random();
    }
    
    /**
     * Gives birth
     */
    abstract public void giveBirth(List<Living> newLivings);
    
    /**
     * Make this animal find food
     */
    abstract public Location findFood();
    
    /**
     * Accessor method
     * @return the gender of the animal
     */
    public Gender getGender(){
        return gender;
    }
    
    /**
     * Accessor method
     * @return true if it acts at night
     */
    public boolean getDoesActAtNight(){
        return doesActAtNight;
    }

    /**
     * This is what the animas do most of the time: they try to find
     * food sources . In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLivings 
     */
    public void act(List<Living> newLivings)
    {
        if(isAlive()) {
          giveBirth(newLivings);            
          // Move towards a source of food if found.
          Location newLocation = findFood();
          if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
          // See if it was possible to move.
          if(newLocation != null) {
              setLocation(newLocation);
          }
          else {
              // Overcrowding.
              setDead();
          }
        }
    }

    /**
     * Add an extra constraint for animals to breed.
     * Animal must be from the opposite gender
     * @return true if an animmal can breed
     */
    public boolean canAnimalBreed(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        boolean birth = false;
        while(it.hasNext()){
            if(field.getObjectAt(it.next()) instanceof Animal && getGender() == getGender().opposite()){
                birth = true;
            }
        }
        
        if(birth) { 
            infect(adjacent); //disase in sexually transmitted thus if an animal breeds it is transmitted
        }
        
        return birth;
    }

}

