import java.util.*;
/**
 * There might be diffrent types of times in the sense that it can divided
 * further like daybreak, morning, noon, night and so on
 *
 * @version 2021.03.02 (1)
 */
public enum Time
{
    DAY("day"), NIGHT("night");
    
    private String name;
    // Default randomizer
    private Random random = new Random();
    
    /**
     * @param name of type String
     */
    Time(String name){
        this.name = name;
    }
    
    /**
     * Return the name.
     * @return name
     */
    public String getName(){
        return name;
    }
    
    /**
     * Return the time.
     * @return result
     */
    public Time random(){
        int pos = random.nextInt(2);
        Time result = DAY;
        if(pos == 1){
           return DAY;
        }
        
       if(pos == 0){
           return NIGHT;
        } 
          
        
        return result;
    }
    
    /**
     * Change the time form night to day and vice versa.
     * @return NIGHT or Day
     */
    public Time change(){
        if(equals(DAY)){
            return NIGHT;
        }
        return DAY;
    }
}


