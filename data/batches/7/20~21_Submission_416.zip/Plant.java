import java.util.*;

/**
 * A model of a plant.
 * Plants age and die and reproduce.
 *
 * @version 2021.03.02 (1)
 */
public class Plant extends Living
{

    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
        
        BREEDING_AGE = 1;
        // The age to which a plant can live.
        MAX_AGE = 30;
        // The likelihood of a plant reproducing.
        BREEDING_PROBABILITY = BreedingProb.PLANT.getValue();
        // The maximum number of reproductions.
        MAX_LITTER_SIZE = 5;
        // The plants  age.
        age = 0;  
        // The plants food level, which is equal to its food value.
        foodLevel = 10;
    }
    
    /**
     * Boost the food level of plant when it rains
     * Because it produces more grass and plants
     */
    public void boostFoodLevel(){
        foodLevel = foodLevel + (foodLevel/2);
    }
    
    /**
     *
     * @param newPlants A list to return new plants..
     */
    public void act(List<Living> newPlants)
    {
        if(isAlive()) {
            giveBirth(newPlants);            
            // Plants dont move
        }
    }

    /**
     * Check whether or not this plant is to reproduce at this step.
     * New plants will be into free adjacent locations.
     * @param newPlants A list to return new plants.
     */
    private void giveBirth(List<Living> newPlants)
    {
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(field, loc);
            newPlants.add(young);
        }
    }
}
