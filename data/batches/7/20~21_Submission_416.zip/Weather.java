import java.util.*;
/**
 * There can be diffrent types of weathers like sunny, foggy or rainy.
 * More can be added in the future.
 *
 * @version 2021.03.02 (1)
 */
public enum Weather
{
    RAIN("rain"), FOG("fog"), SUN("sunny");
    
    private String name;
    // Default randomizer
    private static Random random = new Random();
    
    /**
     * @param name of type String
     */
    Weather(String name){
        this.name = name;
    }
    
    
    /**
     * Choose a weather 
     * @return result
     */
    public Weather random(){
       int pos = random.nextInt(3);
       Weather result = null;
       if(pos == 0){
           return RAIN;
        }
        
       if(pos == 1){
           return FOG;
        }
       
       if(pos == 2){
           return SUN;
       } 
       return result;
    }
    
    /**
     * Return the name.
     * @return name
     */
    public String getName(){
        return name;
    }
  
    
    
}
