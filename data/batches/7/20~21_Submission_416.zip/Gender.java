import java.util.*;
/**
 * Enumeration class Gender 
 * Differentiates between female and male animals to make the process of breedig more realistic.
 *
 * @version 2021.03.02 (1)
 */
public enum Gender
{
    MALE("male"), FEMALE("female");
    
    // The name of the object, used for comparison
    private String name;
    // Default randomizer
    private static Random random = new Random();
    
    /**
     * Consturcts a BreedingProb object
     * Only has a double value
     * @param name 
     */
    Gender(String name){
        this.name = name;
    }
    
    /**
     * Generate a random gender
     * @return a random gender
     */
    public static Gender random(){
       int pos = random.nextInt(2);
       Gender result = null;
       if(pos == 1){
           return MALE;
        }
        
       if(pos == 0){
           return FEMALE;
        } 
            
       return result;
    }
    
    /**
     * Accesor method
     * @return name
     */
    public String getName(){
        return name;
    }
    
    /**
     * @return the opposite gender
     */
    public Gender opposite(){
        if(equals(MALE)){
            return FEMALE;
        }
        
        return MALE;
    }
}
