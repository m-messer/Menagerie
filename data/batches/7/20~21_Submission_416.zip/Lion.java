import java.util.*;

/**
 * A model of the behavior of lions.
 * Lions age, move, breed , eat zebras and die under certain circumstances.
 *
 * @version 2021.03.02 (1)
 */
public class Lion extends Animal
{
    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // The age at which a lion can start to breed.
        BREEDING_AGE = 15;
        // The age to which a lion can live.
        MAX_AGE = 150;
        // The likelihood of a lion breeding.
        BREEDING_PROBABILITY = BreedingProb.LION.getValue();
        // The maximum number of births a lion can give.
        MAX_LITTER_SIZE = 2;
        //Lions do not act at night
        doesActAtNight = false;
        //Lion's foodlevel
        foodLevel = 11; 
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(foodLevel);
        }
        else {
            age = 0;
            foodLevel = foodLevel;
        }
    }
    
    /**
     * Look for food source (Zebras) adjacent to the current location.
     * Only the first live zebra is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if(zebra.isAlive()) { 
                    zebra.setDead();
                    foodLevel += foodLevel + zebra.getFoodValue(); 
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not the lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    public void giveBirth(List<Living> newLions)
    {
        // Get a list of adjacent free locations.
        if(canAnimalBreed()){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Lion young = new Lion(false, field, loc);
                newLions.add(young);
            }
        
        }
        
    }
}
