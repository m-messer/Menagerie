import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 *A model of the behavior of wolves.
 * Wolves age, move, breed , eat rabbits and die under certain conditions.
 *
 * @version 2021.03.02 (3)
 */
public class Wolf extends Animal
{
   /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // The age at which a wolf can start to breed.
        BREEDING_AGE = 15;
        // The age to which a wolf can live.
        MAX_AGE = 150;
        // The likelihood of a wolf breeding.
        BREEDING_PROBABILITY = BreedingProb.WOLF.getValue();
        // The maximum number of births.
        MAX_LITTER_SIZE = 2;
        //Wolf's foodlevel
        foodLevel = 11;
        //Wolf's act at night
        doesActAtNight = true;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(foodLevel);
        }
        else {
            age = 0;
            foodLevel = foodLevel;
        }
    }

    /**
     * Look for deers adjacent to the current location.
     * Only the first live deer is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel += foodLevel + deer.getFoodValue(); 
                    return where;
                }
            }
        }
        return null;
    }
    
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolves.
     */
    public void giveBirth(List<Living> newWolves)
    {
        // New wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(canAnimalBreed()){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Wolf young = new Wolf(false, field, loc);
                newWolves.add(young);
            }
        }
        
    }
  
}
