import java.util.*;

/**
 * Abstract class of superclass for living organisms. (both Animals and Plants)
 * All living organisms have common functions
 *
 * @version 2021.03.02 (1)
 */
public abstract class Living
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // Default randomizer
    private Random random = new Random();
    
    // The min age that an organisim can breed
    protected static int BREEDING_AGE;
    // The age to which an organism can live.
    protected static int MAX_AGE;
    // The likelihood of a organism breeding.
    protected static double BREEDING_PROBABILITY;
    // The maximum number of births/reproductions.
    protected static int MAX_LITTER_SIZE;
    // The organism's age.
    protected int age;
    // The organism's food level, which is increased by consuming their food source.
    protected int foodLevel;
    // infection
    protected boolean infected;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Living(Field field, Location location)
    {
        alive = true;
        this.field = field;
        //inspired form stackoverflow.com/questions/8183840/probability-in-java
        infected = random.nextInt(1000) == 0;
        setLocation(location);
    }
    
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive new Animals.
     */
    abstract public void act(List<Living> newAnimals);
    
    /**
     * Make this animal live - act out his essential events
     */
    public void live(){
        //Essential funcitons. Does them regardless of time
        incrementAge();
        incrementHunger();
   
    }
    
    /**
     * Accessor method
     * @return wheter the organism is infected or not 
     */
    public boolean isInfected(){
        return infected;
    }
       
    /**
     * Accessor method
     * @return food level
     */
    protected int getFoodValue() {
        return foodLevel;
    }
    
    /**
     * Make this organism infected
     */
    public void getInfected(){
        if(infected){
            return; //if already infected end the function
        }
        
        infected = true;
    }
    
    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
        
    /**
     * Generate a number representing the number of births/ reproductions,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
    * Increase the age. This could result in the fox's death.
    */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Infect other living objects
     * @param the locations of the livings that are going to get infected
     */
    protected void infect(List<Location> locations){
        if(isInfected()){
            Field field = getField();
            Iterator<Location> it = locations.iterator();
            while(it.hasNext()){
                Object object = field.getObjectAt(it.next());
                if(object instanceof Living){
                    Living living = (Living) object;
                    living.getInfected();
                }
            }
        }
    }
}
