import java.util.List;
import java.util.Random;
import java.util.*;

/**
 *A model of the behavior of deer.
 * Deer age, move, breed , eat plants and die under certain circumstances.
 *
 * @version 2021.03.02 (3)
 */
public class Deer extends Animal
{
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // The age at which a deer can start to breed.
        BREEDING_AGE = 7;
        // The age to which a deer can live.
        MAX_AGE = 35;
        // The likelihood of a deer breeding.
        BREEDING_PROBABILITY = BreedingProb.DEER.getValue();
        // The maximum number of births a deer can give.
        MAX_LITTER_SIZE = 4;
        //Deers act at night
        doesActAtNight = true;
        //Deer's foodLevel
        foodLevel = 9; 
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object living = field.getObjectAt(where);
            if(living instanceof Plant) {
                Plant plant = (Plant) living;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel += foodLevel + plant.getFoodValue(); 
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeers A list to return newly born deers.
     */
    public void giveBirth(List<Living> newDeers)
    {
        // New deers are born into adjacent locations.
        // Get a list of adjacent free locations.  
        if(canAnimalBreed()){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Deer young = new Deer(false, field, loc);
                newDeers.add(young);
            }
        }
        
    }
}
