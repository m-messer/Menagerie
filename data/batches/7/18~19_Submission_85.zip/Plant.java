import java.util.List;
import java.util.Random;

/**
 * A simple model of a Plant.
 * Plants grow. On rainy days, they grow faster.
 *
 * @version 2019.2.22 
 */
public class Plant extends Animal
{
    // Characteristics shared by all Plants (class variables).

    //The age to which a Plant can live.
    private static final int MAX_YEAR = 130;
    // The age at which a plant can start to breed.
    private static final int BREEDING_AGE = 4;
    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The likelihood of plants growing.
    private static final double RAINY_BREEDING_PROBABILITY = 0.5;
    // The likelihood of weather being rainy.
    private static final double RAINY_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The Plant's age.
    private int age;
    //gender
    private boolean isFemale;
    //check the weather is rainy or not
    private boolean isRainy;
    /**
     * Create a new Plant. A Plant is given age zero
     * 
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location, boolean isFemale)
    {
        super(field, location, isFemale);
        age = 0;
        if(rand.nextDouble() < RAINY_PROBABILITY )
            isRainy = true;
        else
            isRainy = false;
    }
    
    /**
     * Plants will grow but it cannot grow.
     */
    public void act(List<Animal> newPlants)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newPlants);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int grow()
    {
        int births = 0;
        if(isRainy)
        {
            if(canBreed() && rand.nextDouble() <= RAINY_BREEDING_PROBABILITY) 
            {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            }
        }
        else
        {
             if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) 
            {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            }
        }
        return births;
    }
    
     /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLambs A list to return newly born Lambs.
     */
    private void giveBirth(List<Animal> newPlants)
    {
        // New Lambs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = grow();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(field, loc, isFemale);
            newPlants.add(young);
        }
    }
    
     /**
     * A Lamb can breed if it has reached the breeding age.
     * @return true if the plant can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    

    /**
     * Increase the age.
     * This could result in the Plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_YEAR) {
            setDead();
        }
    }
    
}
