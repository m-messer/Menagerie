import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 * The rabbit might die because of disease
 *
 * @version 2019.2.22 
 */
public class Rabbit extends Animal
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 11;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.095;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The likelihood of death of a rabbit
    private static final double DEATH_PROBABILITY = 0.2;
    // The likelihood of contract the disease
    private static final double DISEASE_PROBABILITY = 0.01;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a rabbit can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 15;
    // The rabbit's food level, which is increased by eating plants.
    private int foodLevel;
    // The rabbit's age.
    private int age;
    //gender of rabbits
    private boolean isFemale;
    //night behavior of the rabbit
    private boolean sleepAtNight;
    //define the time
    private int time;

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(field, location, isFemale);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
        isFemale = rand.nextBoolean();
        sleepAtNight = true;
        time = 0;
    }
    
    /**
     * This is what the rabbit does most of the time - It finds plants to eat
     * Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Animal> newRabbits)
    {
        incrementAge();
        incrementHunger();
        time++;
        if(time > 24)
        {
            time = 0;
        }
         if(sleepAtNight && time <= 22 && time >=6)
         // rabbit will sleep at night
        {
        if(isAlive()) {
            giveBirth(newRabbits);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        }
    }
    /**
     * Look for Rabbits adjacent to the current location.
     * Only the first live Rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location spread()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    rabbit.getDisease();
                    return where;
                }
            }
        }
        return null;
    }
    
     /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private boolean getDisease()
    {

        if(canBreed() && rand.nextDouble() <= DISEASE_PROBABILITY) {
            return true;
        }
        else{
            return false;
        }
        
    }
    
    private void dead()
    {
        if(getDisease() == true && rand.nextDouble() <= DEATH_PROBABILITY){
            setDead();
        }
    }

    /**
     * A Lion can breed if it has reached the breeding age.
     */
    private boolean canDisease()
    {
        return true;
    }
    
    /**
     * Increase the age.
     * This could result in the rabbit's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    private void giveBirth(List<Animal> newRabbits)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rabbit young = new Rabbit(false, field, loc, isFemale);
            newRabbits.add(young);
        }
    }
        
    /**
     * Animal propagate when a male and female individual meet
     */
    private int propagate()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal; 
                if(isFemale != rabbit.isFemale() )
                {
                    if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }
              }
           }
            return births;
   }
   
    private boolean isFemale()
   {
       return isFemale;
   }
   
   private int breed()
   {
       int births = 0;
       if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                        return births;
    }  
    
   /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
   /**
     * Make this rabbit more hungry. This could result in the rabbit's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
   /**
     * Look for plants adjacent to the current location.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
}
