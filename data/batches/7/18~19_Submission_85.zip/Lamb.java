import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Lamb.
 * Lambs age, move, breed, and die.
 * The lamb might die because of disease
 *
 * @version 2019.2.22 
 */
public class Lamb extends Animal
{
    // Characteristics shared by all Lambs (class variables).

    // The age at which a Lamb can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a Lamb can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a Lamb breeding.
    private static final double BREEDING_PROBABILITY = 0.1885;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single lamb. In effect, this is the
    // number of steps a lamb can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 25;
    // The likelihood of death of a lamb
    private static final double DEATH_PROBABILITY = 0.2;
    // The likelihood of contract the disease
    private static final double DISEASE_PROBABILITY = 0.01;
    // The lamb's food level, which is increased by eating plants.
    private int foodLevel;
    // The Lamb's age.
    private int age;
    //gender of a lamb 
    private boolean isFemale;
    //night behavior of the lamb
    private boolean sleepAtNight;
    //define the time
    private int time;


    /**
     * Create a new Lamb. A Lamb may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Lamb will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lamb(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(field, location, isFemale);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
        isFemale = rand.nextBoolean();
        sleepAtNight = true;
        time = 0;
    }
    
    /**
     * This is what the Lamb does most of the time - It finds plants to eat
     * Sometimes it will breed or die of old age.
     * @param newLambs A list to return newly born Lambs.
     */
    public void act(List<Animal> newLambs)
    {
        incrementAge();
        incrementHunger();
        time++;
        if(time > 24)
        {
            time = 0;
        }
         if(sleepAtNight && time <= 22 && time >=6)
        {
        if(isAlive()) {
            giveBirth(newLambs);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        }
    }
    
    /**
     * Animal propagate when a male and female individual meet
     */
    private int propagate()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Lamb) {
                Lamb Lamb = (Lamb) animal; 
                if(isFemale != Lamb.isFemale() )
                {
                    if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }
              }
           }
            return births;
   }
   
   /**
     * Look for Lambs adjacent to the current location.
     * Only the first live Lamb is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location spread()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Lamb) {
                Lamb lamb = (Lamb) animal;
                if(lamb.isAlive()) { 
                    lamb.getDisease();
                    return where;
                }
            }
        }
        return null;
    }
    
     /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private boolean getDisease()
    {

        if(canBreed() && rand.nextDouble() <= DISEASE_PROBABILITY) {
            return true;
        }
        else{
            return false;
        }
        
    }
    
    private void dead()
    {
        if(getDisease() == true && rand.nextDouble() <= DEATH_PROBABILITY){
            setDead();
        }
    }

    /**
     * A Lion can breed if it has reached the breeding age.
     */
    private boolean canDisease()
    {
        return true;
    }
   
     private boolean isFemale()
   {
       return isFemale;
   }
   
   /**
     * Increase the age.
     * This could result in the Lamb's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
   /**
     * Check whether or not this Lamb is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLambs A list to return newly born Lambs.
     */
    private void giveBirth(List<Animal> newLambs)
    {
        // New Lambs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lamb young = new Lamb(false, field, loc, isFemale);
            newLambs.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Lamb can breed if it has reached the breeding age.
     * @return true if the Lamb can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Make this Lamb more hungry. This could result in the Lamb's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for plants adjacent to the current location.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
}
