import java.awt.*;

/**
 * A simple model of a bear.
 * Bears age, move, eat mice, duck and wolves, and die.
 *
 * @version 2022.03.02
 */
public class Bear extends Predator {
	// Characteristics shared by all bears (class variables).

	// The age at which a bear can start to breed.
	private static final int BREEDING_AGE = 40;
	// The age to which a bear can live.
	private static final int MAX_AGE = 300;
	// The likelihood of a bear breeding.
	private static final double BREEDING_PROBABILITY = 0.18;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 5;

	/**
	 * Create a bear. A bear can be created as a new born (age zero
	 * and not hungry) or with a random age and food level.
	 *
	 * @param randomAge If true, the bear will have random age and hunger level.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Bear(boolean randomAge, Field field, Location location) {
		super(randomAge, field, location);
		setFoodChainLevel(3);
		setFoodValue(30);
		setSickProbability(10);
		setRecoverProbability(4);
		setAdditionalFoodValue(40);
	}

	/**
	 * Return the bear's breeding age.
	 *
	 * @return The bear's breeding age.
	 */
	protected int getBreedingAge() {
		return BREEDING_AGE;
	}

	/**
	 * Return the bear's maximum age.
	 *
	 * @return The bear's maximum age.
	 */
	protected int getMaxAge() {
		return MAX_AGE;
	}

	/**
	 * Return the bear's breeding probability.
	 *
	 * @return The bear's breeding probability.
	 */
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Return the bear's maximum litter size.
	 *
	 * @return The bear's maximum litter size.
	 */
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * Return a new animal object of a bear which represents its child.
	 *
	 * @return A new animal object of a bear.
	 */
	protected Animal createNewAnimal(boolean randomAge, Field field, Location loc) {
		return new Bear(randomAge, field, loc);
	}

	/**
	 * Define the colour to be used for a given object of a bear.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the colour of the bear.
	 */
	protected Color getObjectColor(Climate climate) {
		return new Color(69, 54, 48);
	}
}
