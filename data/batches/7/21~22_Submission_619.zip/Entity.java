import java.awt.*;

/**
 * Entities are objects that are visible on the field of the simulation.
 * They have a location and an associated colour to represent it.
 *
 * @version 2022.03.02
 */
public abstract class Entity {

	// The field.
	private Field field;
	// The position in the field.
	private Location location;

	/**
	 * Create a new entity object at location in field.
	 *
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Entity(Field field, Location location) {
		this.field = field;
		setLocation(location);
	}

	/**
	 * Define a colour to be used for a given object of an entity.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the objects colour.
	 */
	protected abstract Color getObjectColor(Climate climate);


	/**
	 * Return the field.
	 *
	 * @return The field.
	 */
	protected Field getField() {
		return field;
	}

	/**
	 * Set the field to null.
	 */
	protected void setFieldNull() {
		field = null;
	}


	/**
	 * Return the location.
	 *
	 * @return The location.
	 */
	protected Location getLocation() {
		return location;
	}

	/**
	 * Place the entity at the new location in the given field.
	 *
	 * @param newLocation The entity's new location.
	 */
	protected void setLocation(Location newLocation) {
		if (location == null) {
			location = null;
		}

		if (location != null) {
			field.clear(location);
		}
		location = newLocation;

		if (this instanceof Animal) {
			field.placeAnimal(this, newLocation);
		} else {
			field.placePlant(this, newLocation);
		}
	}

	/**
	 * Set the location to null.
	 */
	protected void setLocationNull() {
		location = null;
	}

}
