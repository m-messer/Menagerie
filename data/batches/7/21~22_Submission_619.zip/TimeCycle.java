/**
 * Enumeration class TimeCycle - Describes the time of day of the simulation
 *
 * @version 2022.03.02
 */
public enum TimeCycle {
	DAY,
	NIGHT;

	/**
	 * Switch the time cycle to the opposite.
	 *
	 * @param currentTimeCycle the time cycle that need to be switched.
	 * @return The switched time cycle.
	 */
	public TimeCycle toggleTimeCycle(TimeCycle currentTimeCycle) {
		if (currentTimeCycle == TimeCycle.DAY) {
			return TimeCycle.NIGHT;
		} else {
			return TimeCycle.DAY;
		}
	}
}
