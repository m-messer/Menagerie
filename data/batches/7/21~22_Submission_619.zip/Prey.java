import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals that are prey.
 *
 * @version 2022.03.02
 */
public abstract class Prey extends Animal {
	// A random number generator
	private static final Random rand = Randomizer.getRandom();

	/**
	 * Create a new prey animal at location in field. A prey
	 * animal may be created with age zero (a new born) or with
	 * a random age.
	 *
	 * @param randomAge If true, the prey will have a random age.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Prey(boolean randomAge, Field field, Location location) {
		super(field, location);
		setAge(0);
		setFoodLevel(6);
		if (randomAge) {
			setAge(rand.nextInt(getMaxAge()));
		}
		setMaxSickStep(20);
	}

	/**
	 * This is what a typical prey does most of the time: it runs around.
	 * In the process, it might breed, die of hunger, or die of old age.
	 *
	 * @param newAnimals A list to return newly born prey.
	 */
	protected void normalAct(List<Animal> newAnimals) {
		findFood();
		giveBirth(newAnimals);
		// Try to move into a free location.
		Location newLocation = getField().freeAnimalAdjacentLocation(getLocation());
		if (newLocation != null) {
			setLocation(newLocation);
		} else {
			// Overcrowding.
			setDead();
		}
	}

	/**
	 * Look for plants in its current location.
	 * Only the first edible plant is eaten.
	 */
	private void findFood() {
		Field field = getField();
		Location where = getLocation();
		Object plant = field.getPlantAt(where);

		if (plant instanceof Plant) {
			Plant nearPlant = (Plant) plant;
			// Feed the prey after eating a plant.
			if (nearPlant.canEat()) {
				nearPlant.reduceStage();
				setFoodLevel(8);
			}
		}
	}
}
