import java.awt.*;

/**
 * A simple model of a wolf.
 * Wolves age, move, eat mice and ducks (and in rare cases other wolves),
 * and die.
 *
 * @version 2022.03.02
 */
public class Wolf extends Predator {
	// Characteristics shared by all wolves (class variables).

	// The age at which a wolf can start to breed.
	private static final int BREEDING_AGE = 20;
	// The age to which a wolf can live.
	private static final int MAX_AGE = 250;
	// The likelihood of a wolf breeding.
	private static final double BREEDING_PROBABILITY = 0.17;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 6;

	/**
	 * Create a wolf. A wolf can be created as a new born (age zero
	 * and not hungry) or with a random age and food level.
	 *
	 * @param randomAge If true, the wolf will have random age and hunger level.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Wolf(boolean randomAge, Field field, Location location) {
		super(randomAge, field, location);
		toggleNocturnal();
		setFoodChainLevel(2);
		setFoodValue(10);
		toggleCannibal();
		setSickProbability(15);
		setRecoverProbability(4);
		setAdditionalFoodValue(9);
	}

	/**
	 * Return the wolf's breeding age.
	 *
	 * @return The wolf's breeding age.
	 */
	protected int getBreedingAge() {
		return BREEDING_AGE;
	}

	/**
	 * Return the wolf's maximum age.
	 *
	 * @return The wolf's maximum age.
	 */
	protected int getMaxAge() {
		return MAX_AGE;
	}

	/**
	 * Return the wolf's breeding probability.
	 *
	 * @return The wolf's breeding probability.
	 */
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Return the wolf's maximum litter size.
	 *
	 * @return The wolf's maximum litter size.
	 */
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * Return a new animal object of a wolf which represents its child.
	 *
	 * @return A new animal object of a wolf.
	 */
	protected Animal createNewAnimal(boolean randomAge, Field field, Location loc) {
		return new Wolf(randomAge, field, loc);
	}

	/**
	 * Define the colour to be used for a given object of a wolf.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the colour of the wolf.
	 */
	protected Color getObjectColor(Climate climate) {
		return new Color(50, 50, 47);
	}
}
