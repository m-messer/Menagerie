import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing prey (mice, birds and ducks), predators (wolves and
 * bears), and plants (grass and flowers).
 *
 * @version 2022.03.02
 */
public class Simulator {
	// Constants representing configuration information for the simulation.
	// The default width for the grid.
	private static final int DEFAULT_WIDTH = 320;
	// The default depth of the grid.
	private static final int DEFAULT_DEPTH = 200;
	// The probability that a flower will be created in any given grid position.
	private static final double FLOWER_CREATION_PROBABILITY = 0.07;
	// The probability that a mouse will be created in any given grid position.
	private static final double MOUSE_CREATION_PROBABILITY = 0.07;
	// The probability that a duck will be created in any given grid position.
	private static final double DUCK_CREATION_PROBABILITY = 0.07;
	// The probability that a bird will be created in any given grid position.
	private static final double BIRD_CREATION_PROBABILITY = 0.07;
	// The probability that a wolf will be created in any given grid position.
	private static final double WOLF_CREATION_PROBABILITY = 0.03;
	// The probability that a bear will be created in any given grid position.
	private static final double BEAR_CREATION_PROBABILITY = 0.03;
	// The default day cycle of the simulation.
	private static final TimeCycle DEFAULT_TIMECYCLE = TimeCycle.DAY;
	// The default weather of the simulation.
	private static final Weather DEFAULT_WEATHER = Weather.SUN;
	// The length of a single day or night cycle.
	private static final int TIMECYCLE_LENGTH = 4;

	// List of animals in the field.
	private List<Animal> animals;
	// List of plants in the field.
	private List<Plant> plants;
	// The current state of the field.
	private Field field;
	// The current step of the simulation.
	private int step;
	// A graphical view of the simulation in grid.
	private SimulatorView gridView;
	// A graphical view of the simulation in graph.
	private GraphView graphView;
	// The current day cycle of the simulation.
	private TimeCycle currentTimeCycle;
	// The current climate of the simulation.
	private Climate climate;
	// The percentage of infected animals
	private int sickPercentage;

	/**
	 * Construct a simulation field with default size.
	 */
	public Simulator() {
		this(DEFAULT_DEPTH, DEFAULT_WIDTH);
		currentTimeCycle = DEFAULT_TIMECYCLE;
	}

	/**
	 * Create a simulation field with the given size.
	 *
	 * @param depth Depth of the field. Must be greater than zero.
	 * @param width Width of the field. Must be greater than zero.
	 */
	public Simulator(int depth, int width) {
		if (width <= 0 || depth <= 0) {
			System.out.println("The dimensions must be greater than zero.");
			System.out.println("Using default values.");
			depth = DEFAULT_DEPTH;
			width = DEFAULT_WIDTH;
		}

		// Create a separate layer for all animals
		animals = new ArrayList<>();
		// Create a separate layer for all plants
		plants = new ArrayList<>();
		field = new Field(depth, width);
		climate = new Climate(DEFAULT_WEATHER);

		// Create a view of the state of each location in the field.
		gridView = new SimulatorView(depth, width);

		// Create a view of the number of animals over time using a graph.
		graphView = new GraphView(1000, 500, 500);

		// Setup a valid starting point.
		reset();
	}

	/**
	 * Run the simulation from its current state for a reasonably long period,
	 * (4000 steps).
	 */
	public void runLongSimulation() {
		simulate(4000);
	}

	/**
	 * Run the simulation from its current state for the given number of steps.
	 * Stop before the given number of steps if it ceases to be viable.
	 *
	 * @param numSteps The number of steps to run for.
	 */
	public void simulate(int numSteps) {
		for (int step = 1; step <= numSteps && gridView.isViable(field); step++) {
			simulateOneStep();
			delay(60);   // Uncomment this to run more slowly.
		}
	}

	/**
	 * Run the simulation from its current state for a single step.
	 * Iterate over the whole field updating the state of each animal and plant.
	 */
	public void simulateOneStep() {
		step++;
		climate.updateClimate(step);

		// Let all plants grow.
		for (Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
			Plant plant = it.next();
			plant.increaseStage(climate);
		}

		// Provide space for newborn animals.
		List<Animal> newAnimals = new ArrayList<>();
		// Let all animals act.
		for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
			Animal animal = it.next();
			animal.act(newAnimals, currentTimeCycle);
			if (!animal.isAlive()) {
				it.remove();
			}
		}

		// Add the newly born animals to the main lists.
		animals.addAll(newAnimals);

		// Toggle the day-night cycle after the defined steps.
		if (step % TIMECYCLE_LENGTH == 0) {
			currentTimeCycle = currentTimeCycle.toggleTimeCycle(currentTimeCycle);
		}

		// Count the total number of sick animals
		int count = 0;
		for (Animal i : animals) {
			if (i.isSick()) {
				count++;
			}
		}

		sickPercentage = (count * 100) / animals.size();
		gridView.showStatus(step, currentTimeCycle, field, climate, sickPercentage);
		graphView.showStatus(step, field);
	}

	/**
	 * Reset the simulation to a starting position.
	 */
	public void reset() {
		step = 0;
		animals.clear();
		populate();
		currentTimeCycle = TimeCycle.DAY;
		climate.setCurrentWeather(Weather.SUN);
		// Show the starting state in the view.
		sickPercentage = 0;
		graphView.reset();
		gridView.showStatus(step, currentTimeCycle, field, climate, sickPercentage);
		graphView.showStatus(step, field);
	}

	/**
	 * Randomly populate the field with plants, predators and prey.
	 */
	private void populate() {
		Random rand = Randomizer.getRandom();
		field.clear();

		for (int row = 0; row < field.getDepth(); row++) {
			for (int col = 0; col < field.getWidth(); col++) {
				Location location = new Location(row, col);

				// First we generate the plant layer.
				// Every location must have a plant.
				if (rand.nextDouble() <= FLOWER_CREATION_PROBABILITY) {
					Flower flower = new Flower(field, location);
					plants.add(flower);
				} else {
					Grass grass = new Grass(field, location);
					plants.add(grass);
				}

				// Then we generate the animal layer.
				// Each location may or may not have a plant.
				if (rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
					Bird bird = new Bird(true, field, location);
					animals.add(bird);
					graphView.setColor(Bird.class, bird.getObjectColor(climate));
				} else if (rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
					Mouse mouse = new Mouse(true, field, location);
					animals.add(mouse);
					graphView.setColor(Mouse.class, mouse.getObjectColor(climate));
				} else if (rand.nextDouble() <= DUCK_CREATION_PROBABILITY) {
					Duck duck = new Duck(true, field, location);
					animals.add(duck);
					graphView.setColor(Duck.class, duck.getObjectColor(climate));
				} else if (rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
					Wolf wolf = new Wolf(true, field, location);
					animals.add(wolf);
					graphView.setColor(Wolf.class, wolf.getObjectColor(climate));
				} else if (rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
					Bear bear = new Bear(true, field, location);
					animals.add(bear);
					graphView.setColor(Bear.class, bear.getObjectColor(climate));
				}
				// Else leave the location empty.
			}
		}
	}

	/**
	 * Pause for a given time.
	 *
	 * @param millisec The time to pause for, in milliseconds.
	 */
	private void delay(int millisec) {
		try {
			Thread.sleep(millisec);
		} catch (InterruptedException ie) {
			// wake up
		}
	}
}