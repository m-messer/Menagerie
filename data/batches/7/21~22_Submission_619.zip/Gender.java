import java.util.Random;

/**
 * Enumeration class Gender - Describes the genders of an animal in the simulation.
 *
 * @version 2022.03.02
 */
public enum Gender {
	FEMALE,
	MALE;

	/**
	 * Generate a random gender.
	 *
	 * @return Female or male randomly.
	 */
	public Gender randomGender() {
		Random rand = Randomizer.getRandom();
		if (rand.nextInt(2) == 0) {
			return Gender.FEMALE;
		}
		return Gender.MALE;
	}
}
