import java.awt.*;

/**
 * A simple model of a mouse.
 * Mice age, move, breed, and die.
 *
 * @version 2022.03.02
 */
public class Mouse extends Prey {
	// Characteristics shared by all mice (class variables).

	// The age at which a mouse can start to breed.
	private static final int BREEDING_AGE = 3;
	// The age to which a mouse can live.
	private static final int MAX_AGE = 40;
	// The likelihood of a mouse breeding.
	private static final double BREEDING_PROBABILITY = 0.20;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 8;

	/**
	 * Create a new mouse. A mouse may be created with age
	 * zero (a new born) or with a random age.
	 *
	 * @param randomAge If true, the mouse will have a random age.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Mouse(boolean randomAge, Field field, Location location) {
		super(randomAge, field, location);
		setFoodChainLevel(1);
		setFoodValue(7);
		setSickProbability(50);
		setRecoverProbability(7);
	}

	/**
	 * Return the mouse's breeding age.
	 *
	 * @return The mouse's breeding age.
	 */
	protected int getBreedingAge() {
		return BREEDING_AGE;
	}

	/**
	 * Return the mouse's maximum age.
	 *
	 * @return The mouse's maximum age.
	 */
	protected int getMaxAge() {
		return MAX_AGE;
	}

	/**
	 * Return the mouse's breeding probability.
	 *
	 * @return The mouse's breeding probability.
	 */
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Return the mouse's maximum litter size.
	 *
	 * @return The mouse's maximum litter size.
	 */
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * Return a new animal object of a mouse which represents its child.
	 *
	 * @return A new animal object of a mouse.
	 */
	protected Animal createNewAnimal(boolean randomAge, Field field, Location loc) {
		return new Mouse(randomAge, field, loc);
	}

	/**
	 * Define the colour to be used for a given object of a mouse.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the colour of the mouse.
	 */
	protected Color getObjectColor(Climate climate) {
		return new Color(132, 132, 130);
	}
}
