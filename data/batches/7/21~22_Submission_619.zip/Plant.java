import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2022.03.02
 */
public abstract class Plant extends Entity {

	// A random number generator.
	private static final Random rand = Randomizer.getRandom();
	// Current stage of growth of a plant.
	private int stage;
	// The maximum stage a plant can grow to.
	private int maxStage;

	/**
	 * Create a new plant at location in field.
	 *
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Plant(Field field, Location location) {
		super(field, location);
	}

	/**
	 * Increase the stage of a plant according to if it is raining.
	 *
	 * @param climate The climate conditions of the simulation.
	 */
	protected void increaseStage(Climate climate) {
		if (stage < getMaxStage()) {
			if (climate.getCurrentWeather() == Weather.RAIN) {
				if (rand.nextDouble() <= 0.33) {
					stage++;
				}
			}
		}
	}

	/**
	 * Returns the maximum stage of a plant.
	 *
	 * @return The maximum stage of a plant.
	 */
	protected int getMaxStage() {
		return maxStage;
	}

	/**
	 * Set the maximum stage of a plant.
	 *
	 * @param maxStage The maximum stage of a plant.
	 */
	protected void setMaxStage(int maxStage) {
		this.maxStage = maxStage;
	}

	/**
	 * Decreases the stage of a plant by one.
	 */
	protected void reduceStage() {
		stage--;
	}

	/**
	 * Return whether or not this plant can be eaten.
	 * Plants at their final stage may not be eaten.
	 *
	 * @return True if the plant can be eaten.
	 */
	protected boolean canEat() {
		return stage > 0;
	}

	/**
	 * Return the current stage of the plant.
	 *
	 * @return The current stage of the plant.
	 */
	protected int getStage() {
		return stage;
	}

	/**
	 * Set the current stage of the plant.
	 *
	 * @param stage The current stage of the plant.
	 */
	protected void setStage(int stage) {
		this.stage = stage;
	}
}
