import java.util.Random;

/**
 * Represents the current climate conditions of this simulation.
 * The climate models both seasons and the current weather conditions.
 *
 * @version 2022.03.02
 */
public class Climate {
	// The length of a season in steps.
	private static final int SEASON_LENGTH = 16;
	// A random number generator for providing humidity increases.
	private static final Random rand = Randomizer.getRandom();
	// The current weather being simulated.
	private Weather currentWeather;
	// The current season being simulated.
	private Season currentSeason;
	// The humidity of the simulation as a percentage.
	private int humidity;

	/**
	 * Constructor for objects of class Climate.
	 */
	public Climate(Weather currentWeather) {
		this.currentWeather = currentWeather;
		currentSeason = Season.SPRING;
	}

	/**
	 * Updates the current weather conditions of the simulation.
	 * Weather conditions depend on the humidity and the current season.
	 *
	 * @param step The step number of the simulation.
	 */
	public void updateClimate(int step) {
		updateSeason(step);

		// Increase the humidity randomly between 10% to 20% every turn
		int humidityIncrease = rand.nextInt((20 - 10) + 1) + 10;

		if (humidity < 80 && (currentWeather == Weather.SUN || currentWeather == Weather.CLOUD)) {
			humidity += humidityIncrease;
		} else if (humidity < 100 && (currentWeather == Weather.SUN || currentWeather == Weather.CLOUD)) {
			humidity += humidityIncrease;
			currentWeather = Weather.CLOUD;
		} else if (humidity > 100 && (currentWeather == Weather.SUN || currentWeather == Weather.CLOUD) && currentSeason != Season.WINTER) {
			currentWeather = Weather.RAIN;
		} else if (humidity > 80 && currentWeather == Weather.RAIN) {
			humidity -= humidityIncrease;
		} else { // Once it has stopped raining
			humidity = 0;
			currentWeather = Weather.SUN;
		}
	}

	/**
	 * Updates the current season based on the number of steps.
	 *
	 * @param step The step number of the simulation.
	 */
	private void updateSeason(int step) {
		switch ((step / SEASON_LENGTH) % 4) {
			case 0:
				currentSeason = Season.SPRING;
				break;
			case 1:
				currentSeason = Season.SUMMER;
				break;
			case 2:
				currentSeason = Season.AUTUMN;
				break;
			case 3:
				currentSeason = Season.WINTER;
				break;
		}
	}

	/**
	 * Return the current weather of the simulation.
	 *
	 * @return The current weather of the simulation.
	 */
	public Weather getCurrentWeather() {
		return currentWeather;
	}

	/**
	 * Sets the current weather of the simulation.
	 *
	 * @param currentWeather The weather of the simulation.
	 */
	public void setCurrentWeather(Weather currentWeather) {
		this.currentWeather = currentWeather;
	}

	/**
	 * Return the current season of the simulation.
	 *
	 * @return The current season of the simulation.
	 */
	public Season getCurrentSeason() {
		return currentSeason;
	}

	/**
	 * Return the current humidity of the simulation.
	 *
	 * @return The current humidity of the simulation.
	 */
	public int getHumidity() {
		return humidity;
	}

}

