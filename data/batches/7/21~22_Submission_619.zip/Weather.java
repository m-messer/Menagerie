/**
 * Enumeration class Weather - Describes the current weather of the simulation.
 *
 * @version 2022.03.02
 */
public enum Weather {
	SUN,
	CLOUD,
	RAIN;
}
