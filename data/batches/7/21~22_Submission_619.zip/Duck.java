import java.awt.*;

/**
 * A simple model of a duck.
 * Ducks age, move, breed, and die.
 *
 * @version 2022.03.02
 */
public class Duck extends Prey {
	// Characteristics shared by all ducks (class variables).

	// The age at which a duck can start to breed.
	private static final int BREEDING_AGE = 4;
	// The age to which a duck can live.
	private static final int MAX_AGE = 50;
	// The likelihood of a duck breeding.
	private static final double BREEDING_PROBABILITY = 0.20;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 5;

	/**
	 * Create a new duck. A duck may be created with age
	 * zero (a new born) or with a random age.
	 *
	 * @param randomAge If true, the duck will have a random age.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Duck(boolean randomAge, Field field, Location location) {
		super(randomAge, field, location);
		setFoodChainLevel(1);
		setFoodValue(5);
		setSickProbability(10);
		setRecoverProbability(2);
	}

	/**
	 * Return the duck's breeding age.
	 *
	 * @return The duck's breeding age.
	 */
	protected int getBreedingAge() {
		return BREEDING_AGE;
	}

	/**
	 * Return the duck's maximum age.
	 *
	 * @return The duck's maximum age.
	 */
	protected int getMaxAge() {
		return MAX_AGE;
	}

	/**
	 * Return the duck's breeding probability.
	 *
	 * @return The duck's breeding probability.
	 */
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Return the duck's maximum litter size.
	 *
	 * @return The duck's maximum litter size.
	 */
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * Return a new animal object of a duck which represents its child.
	 *
	 * @return A new animal object of a duck.
	 */
	protected Animal createNewAnimal(boolean randomAge, Field field, Location loc) {
		return new Duck(randomAge, field, loc);
	}

	/**
	 * Define the colour to be used for a given object of a duck.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the colour of the duck.
	 */
	protected Color getObjectColor(Climate climate) {
		return new Color(241, 200, 23);
	}
}
