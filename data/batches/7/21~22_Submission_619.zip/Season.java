/**
 * Enumeration class Season - Describes the current season of the simulation.
 *
 * @version 2022.03.02
 */
public enum Season {
	SPRING,
	SUMMER,
	AUTUMN,
	WINTER;
}
