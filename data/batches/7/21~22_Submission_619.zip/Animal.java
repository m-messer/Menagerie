import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.03.02
 */
public abstract class Animal extends Entity {
	// Individual characteristics (instance fields).

	// A random number generator providing randomised sickness.
	private static final Random rand = Randomizer.getRandom();
	// Whether the animal is alive or not.
	private boolean alive;
	// The animal's age.
	private int age;
	// The animal gender, the default is male.
	private Gender gender = Gender.MALE;
	// Whether the animal is nocturnal or not.
	private boolean nocturnal;
	// The animal's level in the food chain.
	private int foodChainLevel;
	// The animal's food value.
	private int foodValue;
	// The animal's food level, which is increased by eating prey.
	private int foodLevel;
	// Whether the animal is sick or not.
	private boolean sick;
	// Probability of the animal getting sick.
	private int sickProbability;
	// Probability the animal recover from sickness.
	private int recoverProbability;
	// The step the animal took while sick.
	private int sickStep;
	// Recovery time of the animal, the maximum number of step that the animal can take before death by sickness.
	private int maxSickStep;

	/**
	 * Create a new animal at location in field.
	 *
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Animal(Field field, Location location) {
		super(field, location);
		alive = true;
		gender = gender.randomGender();
		nocturnal = false;
		sick = false;
		sickProbability = 16;
	}

	/**
	 * Make this animal act - that is: make it do
	 * whatever it wants/needs to do.
	 *
	 * @param newAnimals A list to receive newly born animals.
	 */
	abstract protected void normalAct(List<Animal> newAnimals);

	/**
	 * This method determine the action of an animal depending on the time of day.
	 *
	 * @param newAnimals A list to return newly born animals.
	 * @param time       The current day cycle.
	 */
	public void act(List<Animal> newAnimals, TimeCycle time) {
		incrementAge();
		incrementHunger();
		battleSickness();
		if (isAlive()) {
			if (time == TimeCycle.NIGHT && isNocturnal()) {
				// When it is night and the animal is nocturnal.
				normalAct(newAnimals);
			} else if (time == TimeCycle.DAY && isNocturnal()) {
				// When it is day and the animal is nocturnal.
				normalAct(newAnimals);
			} else if (time == TimeCycle.DAY && !isNocturnal()) {
				// When it is day and the animal is not nocturnal.
				normalAct(newAnimals);
			}
		}
	}

	/**
	 * Increase the age.
	 * This could result in the animal's death.
	 */
	protected void incrementAge() {
		age++;
		if (age > getMaxAge()) {
			setDead();
		}
	}

	/**
	 * An animal can breed if it has reached the breeding age and if it is near another animal of its kind and opposite gender.
	 *
	 * @return true if the animal can breed, false otherwise.
	 */
	private boolean canBreed() {
		Field field = getField();
		List<Location> adjacent = field.adjacentAnimalLocations(getLocation());
		Iterator<Location> it = adjacent.iterator();
		boolean returnValue = age >= getBreedingAge();
		while (it.hasNext()) {
			Location where = it.next();
			Object animal = field.getAnimalAt(where);
			if (animal instanceof Animal) {
				Animal animalNear = (Animal) animal;
				// Make sure animal breeds with the same species and opposite gender.
				if (animalNear.getClass().equals(this.getClass()) && getGender() != animalNear.getGender()) {
					return returnValue;
				}
			}
		}
		return returnValue;
	}

	/**
	 * Generate a number representing the number of births,
	 * if the animal can breed.
	 *
	 * @return The number of births (maybe zero).
	 */
	private int breed() {
		int births = 0;
		if (canBreed() && rand.nextDouble() <= getBreedingProbability()) {
			births = rand.nextInt(getMaxLitterSize()) + 1;
		}
		return births;
	}

	/**
	 * Make the animal give birth at this step.
	 * New births will be made into free adjacent locations.
	 *
	 * @param newAnimals A list to return newly born animals.
	 */
	protected void giveBirth(List<Animal> newAnimals) {
		// New animals are born into adjacent locations.
		// Get a list of adjacent free locations.
		if (this.getGender() == Gender.FEMALE) {
			Field field = getField();
			List<Location> free = field.getFreeAnimalAdjacentLocations(getLocation());
			int births = breed();
			for (int b = 0; b < births && free.size() > 0; b++) {
				Location loc = free.remove(0);
				Animal young = createNewAnimal(false, field, loc);
				newAnimals.add(young);
			}
		}
	}

	/**
	 * Check whether the animal is alive or not.
	 *
	 * @return true if the animal is still alive.
	 */
	protected boolean isAlive() {
		return alive;
	}

	/**
	 * Indicate that the animal is no longer alive.
	 * It is removed from the field.
	 */
	protected void setDead() {
		alive = false;
		if (getLocation() != null) {
			getField().clear(getLocation());
			setLocationNull();
			setFieldNull();
		}
	}

	/**
	 * Randomly make the animal sick.
	 */
	protected void becomeSick() {
		if (!isSick()) {
			int randomNumber = rand.nextInt(getSickProbability());
			if (randomNumber == 1) {
				toggleSick();
			}
		}
	}

	/**
	 * Randomly make the animal recover from sickness.
	 */
	protected void notSick() {
		if (isSick()) {
			int randomNumber = rand.nextInt(getRecoverProbability());
			if (randomNumber == 1) {
				toggleSick();
				sickStep = 0;
			}
		}
	}

	/**
	 * Decide if a sick animal may recover from sickness,
	 * and if a healthy animal may become sick.
	 * Spreading the sickness to nearby animals of the same kind.
	 */
	protected void battleSickness() {
		if (sick) {
			if (sickStep >= maxSickStep) {
				setDead();
				return;
			}
			sickStep++;
			Field field = getField();
			if (field != null) {
				List<Location> adjacent = field.adjacentAnimalLocations(getLocation());
				Iterator<Location> it = adjacent.iterator();
				while (it.hasNext()) {
					Location where = it.next();
					Object animal = field.getAnimalAt(where);
					if (animal instanceof Animal) {
						Animal nearAnimal = (Animal) animal;
						if (nearAnimal.getClass().equals(this.getClass())) {
							nearAnimal.becomeSick();
						}
					}
				}
				this.notSick();
			}
		} else {
			becomeSick();
		}
	}

	/**
	 * Make this predator more hungry. This could result in the predator's death.
	 */
	protected void incrementHunger() {
		foodLevel--;
		if (foodLevel <= 0) {
			setDead();
		}
	}

	/**
	 * Toggle the nocturnal property of the animal.
	 */
	protected void toggleNocturnal() {
		nocturnal = !nocturnal;

	}

	/**
	 * Toggle the sick property of the animal.
	 */
	protected void toggleSick() {
		sick = !sick;

	}

	/**
	 * Return the probability of the animal getting sick.
	 *
	 * @return The probability of the animal getting sick.
	 */
	protected int getSickProbability() {
		return sickProbability;
	}

	/**
	 * Set the probability of the animal getting sick.
	 *
	 * @param inputValue the probability of the animal getting sick.
	 */
	protected void setSickProbability(int inputValue) {
		sickProbability = inputValue;
	}

	/**
	 * Return the probability of the animal recover from getting sick.
	 *
	 * @return The probability of the animal recover getting sick.
	 */
	protected int getRecoverProbability() {
		return recoverProbability;
	}

	/**
	 * Set the probability of the animal getting sick.
	 *
	 * @param inputValue the probability of the animal getting sick.
	 */
	protected void setRecoverProbability(int inputValue) {
		recoverProbability = inputValue;
	}

	/**
	 * Return the animal's gender.
	 *
	 * @return The animal's gender.
	 */
	protected Gender getGender() {
		return gender;
	}

	/**
	 * Return the animal's level on the food chain.
	 *
	 * @return The animal's level on the food chain.
	 */
	protected int getFoodChainLevel() {
		return foodChainLevel;
	}

	/**
	 * Sets the food chain level of the animal.
	 *
	 * @param level The animal's level on the food chain.
	 */
	protected void setFoodChainLevel(int level) {
		foodChainLevel = level;
	}

	/**
	 * Return the food value of the animal.
	 *
	 * @return The animal's food value.
	 */
	protected int getFoodValue() {
		return foodValue;
	}

	/**
	 * Sets the food level of the animal.
	 *
	 * @param value The animal's food value.
	 */
	protected void setFoodValue(int value) {
		foodValue = value;
	}

	/**
	 * Check if animal is nocturnal or not.
	 *
	 * @return true if the animal is nocturnal.
	 */
	protected boolean isNocturnal() {
		return nocturnal;
	}

	/**
	 * Check if animal is sick or not.
	 *
	 * @return true if the animal is sick.
	 */
	protected boolean isSick() {
		return sick;
	}

	/**
	 * Sets the initial age of the animal.
	 *
	 * @param age The animal's age.
	 */
	protected void setAge(int age) {
		this.age = age;
	}

	/**
	 * Return the food level of the animal.
	 *
	 * @return The foot level of the animal.
	 */
	public int getFoodLevel() {
		return foodLevel;
	}

	/**
	 * Sets the animal's food level after eating.
	 *
	 * @param foodLevel The food level of the animal after eating.
	 */
	public void setFoodLevel(int foodLevel) {
		this.foodLevel = foodLevel;
	}

	/**
	 * Return the sick step of the animal.
	 *
	 * @return The foot level of the animal.
	 */
	public int getSickStep() {
		return sickStep;
	}

	/**
	 * Sets the animal's sick step after eating.
	 *
	 * @param inputValue The sick step of the animal.
	 */
	public void setSickStep(int inputValue) {
		this.sickStep = inputValue;
	}

	/**
	 * Return the max sick step of the animal.
	 *
	 * @return The max sick step of the animal.
	 */
	public int getMaxSickStep() {
		return maxSickStep;
	}

	/**
	 * Sets the animal's max sick step.
	 *
	 * @param inputValue The max sick step of the animal.
	 */
	public void setMaxSickStep(int inputValue) {
		this.maxSickStep = inputValue;
	}

	/**
	 * Return the species breeding age.
	 *
	 * @return The species breeding age.
	 */
	abstract protected int getBreedingAge();

	/**
	 * Return the species maximum age.
	 *
	 * @return The species maximum age.
	 */
	abstract protected int getMaxAge();

	/**
	 * Return the species breeding probability.
	 *
	 * @return The species breeding probability.
	 */
	abstract protected double getBreedingProbability();

	/**
	 * Return the species maximum litter size.
	 *
	 * @return The species maximum litter size.
	 */
	abstract protected int getMaxLitterSize();

	/**
	 * Return a new animal object of the species.
	 *
	 * @return A new animal object of the species.
	 */
	abstract protected Animal createNewAnimal(boolean randomAge, Field field, Location loc);
}
