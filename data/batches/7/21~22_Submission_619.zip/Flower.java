import java.awt.*;
import java.util.Random;

/**
 * A simple model of a flower.
 * Flowers grow, get eaten and respond to change in climate.
 *
 * @version 2022.03.02
 */
public class Flower extends Plant {
	// A random number generator.
	private static final Random rand = Randomizer.getRandom();
	// Colour object used to store the initial colour of a flower.
	private Color plantColour;

	/**
	 * Create a new flower object at location in field.
	 *
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Flower(Field field, Location location) {
		super(field, location);
		setMaxStage(1);
		setStage(getMaxStage());

		// Flowers can be generated with three different colours.
		if (rand.nextDouble() <= 0.33) {
			plantColour = new Color(236, 0, 0);
		} else if (rand.nextDouble() <= 0.33) {
			plantColour = new Color(236, 98, 2);
		} else {
			plantColour = new Color(122, 0, 236);
		}
	}

	/**
	 * Define the colour to be used for a given instance of a flower.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the colour of the flower.
	 */
	protected Color getObjectColor(Climate climate) {
		if (getStage() == 1) {
			return plantColour;
		} else { // If the flower has been eaten then soil is displayed.
			return new Color(131, 101, 57);
		}
	}
}
