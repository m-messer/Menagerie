/**
 * Main entry point to the application. When executed, a simulator
 * will be created and a long simulation will be run.
 *
 * @version 2022.03.02
 */
public class Main {
	public static void main(String[] args) {
		Simulator simulator = new Simulator();
		simulator.runLongSimulation();
	}
}
