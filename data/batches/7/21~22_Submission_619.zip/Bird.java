import java.awt.*;

/**
 * A simple model of a bird.
 * Birds age, move, breed, and die.
 *
 * @version 2022.03.02
 */
public class Bird extends Prey {
	// Characteristics shared by all mice (class variables).

	// The age at which a bird can start to breed.
	private static final int BREEDING_AGE = 3;
	// The age to which a bird can live.
	private static final int MAX_AGE = 50;
	// The likelihood of a bird breeding.
	private static final double BREEDING_PROBABILITY = 0.17;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 7;

	/**
	 * Create a new bird. A bird may be created with age
	 * zero (a new born) or with a random age.
	 *
	 * @param randomAge If true, the bird will have a random age.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Bird(boolean randomAge, Field field, Location location) {
		super(randomAge, field, location);
		setFoodChainLevel(1);
		setFoodValue(5);
		setSickProbability(10);
		setRecoverProbability(6);
	}

	/**
	 * Return the bird's breeding age.
	 *
	 * @return The bird's breeding age.
	 */
	protected int getBreedingAge() {
		return BREEDING_AGE;
	}

	/**
	 * Return the bird's maximum age.
	 *
	 * @return The bird's maximum age.
	 */
	protected int getMaxAge() {
		return MAX_AGE;
	}

	/**
	 * Return the bird's breeding probability.
	 *
	 * @return The bird's breeding probability.
	 */
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Return the bird's maximum litter size.
	 *
	 * @return The bird's maximum litter size.
	 */
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * Return a new animal object of a bird which represents its child.
	 *
	 * @return A new animal object of a bird.
	 */
	protected Animal createNewAnimal(boolean randomAge, Field field, Location loc) {
		return new Bird(randomAge, field, loc);
	}

	/**
	 * Define the colour to be used for a given object of a bird.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the colour of the bird.
	 */
	protected Color getObjectColor(Climate climate) {
		return new Color(236, 110, 11);
	}
}
