import java.awt.*;
import java.util.Random;

/**
 * A simple model of a grass.
 * Grass grow, get eaten and respond to change in climate.
 *
 * @version 2022.03.02
 */
public class Grass extends Plant {
	// A random number generator.
	private static final Random rand = Randomizer.getRandom();

	/**
	 * Create a new grass object at location in field.
	 *
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Grass(Field field, Location location) {
		super(field, location);

		// Grass can be generated with random stages.
		if (rand.nextDouble() <= 0.5) {
			setMaxStage(3);
		} else if (rand.nextDouble() <= 0.3) {
			setMaxStage(2);
		} else {
			setMaxStage(1);
		}
		setStage(getMaxStage());
	}

	/**
	 * The stages of grass are dynamic and changes as according to the current season.
	 * Different seasons have different maximum stages.
	 *
	 * @param climate The climate conditions of the simulation.
	 */
	protected void increaseStage(Climate climate) {
		super.increaseStage(climate);
		if (climate.getCurrentSeason() == Season.SPRING && getStage() > 2) {
			setStage(2);
		} else if (climate.getCurrentSeason() == Season.SUMMER && getStage() > 3) {
			setStage(3);
		} else if (climate.getCurrentSeason() == Season.AUTUMN && getStage() > 2) {
			setStage(2);
		} else if (climate.getCurrentSeason() == Season.WINTER && getStage() > 1) {
			setStage(1);
		}
	}

	/**
	 * Define the colour to be used for a given object of a grass.
	 * The colour of grass is dynamic is changes as according to its stage
	 * and the current season.
	 *
	 * @param climate The climate of the simulation.
	 * @return Color object representing the color of the grass.
	 */
	protected Color getObjectColor(Climate climate) {
		switch (climate.getCurrentSeason()) {
			case SPRING:
				if (getStage() == 2) {
					return new Color(34, 140, 61);
				} else if (getStage() == 1) {
					return new Color(68, 201, 104);
				} else {
					return new Color(131, 101, 57);
				}
			case SUMMER:
				if (getStage() == 3) {
					return new Color(11, 102, 35);
				} else if (getStage() == 2) {
					return new Color(34, 140, 61);
				} else if (getStage() == 1) {
					return new Color(68, 201, 104);
				} else {
					return new Color(131, 101, 57);
				}
			case AUTUMN:
				if (getStage() == 2) {
					return new Color(68, 201, 104);
				} else if (getStage() == 1) {
					return new Color(154, 140, 84);
				} else {
					return new Color(131, 101, 57);
				}
			case WINTER:
				if (getStage() == 1) {
					return new Color(214, 233, 202);
				} else {
					return new Color(255, 250, 250);
				}
			default:
				return new Color(0, 0, 0);
		}
	}
}
