import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals that
 * are predators.
 *
 * @version 2022.03.02
 */
public abstract class Predator extends Animal {
	// Individual characteristics (instance fields).

	// A random number generator.
	private static final Random rand = Randomizer.getRandom();
	// Whether or not the animal is a cannibal.
	private boolean cannibal;
	// Additional food value to supplement the predator.
	private int additionalFoodValue;

	/**
	 * Create a new predator animal. A predator can be created as a
	 * new born (age zero and not hungry) or with a random age and food
	 * level.
	 *
	 * @param randomAge If true, the predator will have random age and hunger level.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Predator(boolean randomAge, Field field, Location location) {
		super(field, location);
		if (randomAge) {
			setAge(rand.nextInt(getMaxAge()));
			setFoodLevel(rand.nextInt(5));
		} else {
			setAge(0);
			setFoodLevel(6);
		}
		cannibal = false;
		additionalFoodValue = 0;
		setMaxSickStep(30);
	}

	/**
	 * This is what a typical predator does most of the time: it hunts for
	 * animals lower in the food chain. In the process, it might breed,
	 * die of hunger, die of sickness or die of old age.
	 *
	 * @param newAnimals A list to return newly born predator.
	 */
	protected void normalAct(List<Animal> newAnimals) {
		giveBirth(newAnimals);
		// Move towards a source of food if found.
		Location newLocation = findFood();
		if (isAlive()) {
			if (newLocation == null) {
				// No food found - try to move to a free location.
				newLocation = getField().freeAnimalAdjacentLocation(getLocation());
			}
			// See if it was possible to move.
			if (newLocation != null) {
				setLocation(newLocation);
			} else {
				// Overcrowding.
				setDead();
			}
		}
	}

	/**
	 * Look for prey adjacent to the current location.
	 * Only the first live prey that is eaten.
	 *
	 * @return Where food was found, or null if it wasn't.
	 */
	private Location findFood() {
		Field field = getField();
		List<Location> adjacent = field.adjacentAnimalLocations(getLocation());
		Iterator<Location> it = adjacent.iterator();
		while (it.hasNext()) {
			Location where = it.next();
			Object animal = field.getAnimalAt(where);
			if (animal instanceof Animal) { // Is it an animal.
				Animal nearAnimal = (Animal) animal;
				// Will look for food in the surrounding area.
				if (nearAnimal.getFoodChainLevel() < this.getFoodChainLevel()) {
					// Check if the animal is lower in the food chain.
					if (nearAnimal.isAlive()) {
						nearAnimal.setDead();
						setFoodLevel(nearAnimal.getFoodValue() + additionalFoodValue);
						return where;
					}
				}
				// If there is no available food and the predator is hungry
				// then the predator will cannibalise if it can do so.
				if (nearAnimal.getFoodChainLevel() == this.getFoodChainLevel()) {
					if (nearAnimal.isAlive() && this.isCannibal()) {
						if (getFoodLevel() < 2 && nearAnimal.getClass().equals(this.getClass())) {
							nearAnimal.setDead();
							setFoodLevel(nearAnimal.getFoodValue() + additionalFoodValue);
							return where;
						}
					}
				}
			}
		}
		return null;
	}

	/**
	 * Return if this predator is a cannibal.
	 *
	 * @return True if the predator is a cannibal.
	 */
	public boolean isCannibal() {
		return cannibal;
	}

	/**
	 * Toggle whether if this predator is a cannibal.
	 */
	public void toggleCannibal() {
		cannibal = !cannibal;
	}

	/**
	 * Return the additional food value which supplements the predator.
	 *
	 * @return The additional food value.
	 */
	protected int getAdditionalFoodValue() {
		return additionalFoodValue;
	}

	/**
	 * Set an additional food value to supplement the predator.
	 *
	 * @param inputValue The additional food value.
	 */
	protected void setAdditionalFoodValue(int inputValue) {
		additionalFoodValue = inputValue;
	}
}
