import java.util.List;
import java.util.Random;
import java.util.Iterator;


/**
 * A class representing shared characteristics of preys.
 *
 * @version 2020.02.22
 */
public abstract class Prey extends Animal
{
    // Characteristics shared by all preys (class variables).

    // The age at which a prey can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a prey can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a prey breeding.
    private double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //food value for the grass
    private static final int PREY_FOOD_VALUE = 4;
    

    // Individual characteristics (instance fields).
    
    // The rabbit's age.
    private int age;
    // The fox's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PREY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PREY_FOOD_VALUE;
        }
    }
    


    /**
     * Increase the age.
     * This could result in the rabbit's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A prey can breed if it has reached the breeding age.
     * @return true if the prey can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Make this prey more hungry. This could result in the prey's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Grass) {
                foodLevel += PREY_FOOD_VALUE;
                return where;
            }
        }
        return null;
    }
    /**
     * Creates a constraint if the animal has a disease
     */
    protected void stdConstraints()
    { if (std=true)
        { 
                        BREEDING_PROBABILITY = BREEDING_PROBABILITY/2;
                    }
}
}
