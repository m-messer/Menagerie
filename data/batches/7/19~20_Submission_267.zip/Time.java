
/**
 * This class keeps the day and night cycle going
 *
 * @version 2020.02.22
 */
public class Time
{
    public static boolean day;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        day = true;
    }

    /**
     * link step from simulator to time
     *
      */
    public static boolean dayCycle()
    {
        int cycle = Simulator.getStep();
        if (cycle % 100 == 0) {
            if (day == true) {
                day = false;
            }
            else if (day == false) {
                day = true;
            }
        }
        return day;
    }
}
