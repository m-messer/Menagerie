import java.util.Random;

/**
 * Write a description of class Element here.
 *
 * @version (a version number or a date)
 */
public abstract class Element extends Animal
{
    // instance variables - replace the example below with your own
       private static final Random rand = Randomizer.getRandom();
       private static final double BREEDING_PROBABILITY = 0.70;
       private static final int MAX_LITTER_SIZE = 1;
       // shows how much steps can be made when a prey eats a plant
       private static final int PREY_FOOD_VALUE = 7;




    /**
     * Constructor for objects of class Element
     */
    public Element(Field field, Location location)
    {
        super(field, location);
    }
    
     /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births =MAX_LITTER_SIZE;
        }
        return births;
    }
   
}

