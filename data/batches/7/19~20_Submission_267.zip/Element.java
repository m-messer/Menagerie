import java.util.Random;

/**
 * A class representing shared characteristics of elements
 *
 * @version 2020.02.22
 */
public abstract class Element
{

    private Field field;
    
    private Location location;

    /**
     * Constructor for objects of class Element
     */
    public Element(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }
    
       /**
     * Return the element's location.
     * @return The element's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
        /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.placeElement(this, newLocation);
    }
   
}

