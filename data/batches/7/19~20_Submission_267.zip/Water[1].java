import java.util.*;

/**
 * Write a description of class Grass here.
 *
 * @version (a version number or a date)
 */
public class Water extends Element
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Grass
     */
     public Water( Field field, Location location)
    {
        super( field, location);
    }
             public void act(List<Animal> newWater)
    {
           
}
}
