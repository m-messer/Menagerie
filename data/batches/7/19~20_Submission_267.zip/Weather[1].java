import java.util.Random;


/**
 * Write a description of class Weather here.
 *
 * @version (a version number or a date)
 */
public class Weather
{
    // instance variables - replace the example below with your own
    private static final double RAIN_PROBABILITY = 0.15;
    private static final double HIGHWINDS_PROBABILITY = 0.06;
    private static final double FOG_PROBABILITY = 0.17;
    public static boolean rain;
    public static boolean winds;
    public static boolean fog;


    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
       rain=false;
       winds=false;
       fog=false;
    }
    /**
     * we have an alternance every 100 steps between a probability of bad weather and and good weather
     */
    public void setWeather(){
        int cycle = Simulator.getStep();
        Random rand = Randomizer.getRandom();
        if (cycle % 100 == 0) {
            if(rand.nextDouble() <= RAIN_PROBABILITY) {
                   rain = true;
                }
            if(rand.nextDouble() <= HIGHWINDS_PROBABILITY) {
                    winds= true;
                }
            if(rand.nextDouble() <= FOG_PROBABILITY) {
                    fog= true;
                }
            }
         if( cycle % 200 ==0){
        rain=false;
       winds=false;
       fog=false;
        }
    }

    public static boolean getRain(){
        return rain;
    }
    
    public static boolean getWinds(){
        return winds;
    }
        
    public static boolean getFog(){
        return fog;
    }
}
