import java.util.*;

/**
 * Write a description of class Grass here.
 *
 * @version (a version number or a date)
 */
public class Grass extends Element
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Grass
     */
     public Grass( Field field, Location location)
    {
        super( field, location);
    }
     public void act(List<Animal> newGrass)
    {
            giveBirth(newGrass);
}

    
        /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    private void giveBirth(List<Animal> newGrass)
    {
        // New Grass is born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = super.breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Element Grass = new Grass(field, loc);
            newGrass.add(Grass); 
        }
    }
    


   
}
