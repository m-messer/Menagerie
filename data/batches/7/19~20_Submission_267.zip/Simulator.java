import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Lions, Hyenas, Antelopes, warthogs and Zebras.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a Hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.01;
    // The probability that a Lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.01;
    // The probability that a Zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.10;
        // The probability that a Warthog will be created in any given grid position.
private static final double WARTHOG_CREATION_PROBABILITY = 0.10;
// The probability that a Antelope will be created in any given grid position.
private static final double ANTELOPE_CREATION_PROBABILITY = 0.10;
// The probability that a Grass will be created in any given grid position.
private static final double GRASS_CREATION_PROBABILITY = 0.20;

    // List of animals in the field.
    private List<Animal> animals; 
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private static int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new GridView(depth, width);
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Warthog.class, Color.RED);
        view.setColor(Antelope.class, Color.YELLOW);
        view.setColor(Hyena.class, Color.BLACK);
        view.setColor(Lion.class, Color.PINK);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Water.class, Color.BLUE);

        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
             //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animals.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
        
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object element = field.getObjectAt(row, col);
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY && !(element instanceof Water)) {
                    Location location = new Location(row, col);
                    Element Grass = new Grass(field, location);
                }
            }
        }
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
              // this creates a river  
        for(int row = 0; row < field.getDepth(); row++) {
           for(int col = 0; col < field.getWidth(); col++) {
              for(int r = 0; r < 30; r++){
                int a=(row - 20)^2;
                int b=(col-100)^2;
                  if ( (a+b) == (r^2)){
                      Location location = new Location(row, col);
                      Element Water = new Water(field, location); 
                    }
                }
            }
        }
        // this populates the fiels with animals and grass
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object element = field.getObjectAt(row, col);
                if (!(element instanceof Water)) {
                    if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Predator Hyena = new Hyena(true, field, location);
                        animals.add(Hyena);
                    }
                    else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Predator Lion = new Lion(true, field, location);
                        animals.add(Lion);
                    }
                    else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Prey Zebra = new Zebra(true, field, location);
                        animals.add(Zebra);
                    }
                    else if(rand.nextDouble() <= WARTHOG_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Prey Warthog = new Warthog(true, field, location);
                        animals.add(Warthog);
                    }
                    else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Prey Antelope = new Antelope(true, field, location);
                        animals.add(Antelope);
                    }
                    else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Element Grass = new Grass(field, location);
                    }
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    public static int getStep()
    {
        return step;
    }
    
    public List<Animal> getAnimals()
    {
        return animals;
    }
}
