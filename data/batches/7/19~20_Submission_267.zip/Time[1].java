
/**
 * Write a description of class Time here.
 *
 * @version (a version number or a date)
 */
public class Time
{
    // instance variables - replace the example below with your own
    public static boolean day;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        day = true;
    }

    /**
     * link step from simulator to time
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static boolean dayCycle()
    {
        int cycle = Simulator.getStep();
        if (cycle % 100 == 0) {
            if (day == true) {
                day = false;
            }
            else if (day == false) {
                day = true;
            }
        }
        return day;
    }
}
