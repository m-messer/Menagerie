
/**
 * This Class gives a field and a location to the grass that will 
 * be eaten by the animals for strenght
 *
 * @version 2020.02.22
 */
public class Grass extends Element
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Grass
     */
     public Grass( Field field, Location location)
    {
        super( field, location);
    }
}
