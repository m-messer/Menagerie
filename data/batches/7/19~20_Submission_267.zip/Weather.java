import java.util.Random;


/**
 * This class uses the steps and randomness to allow for 
 * different weather patterns
 *
 * @version 2020.02.22
 */
public class Weather
{
    //different probabilities for different weather
    private static final double RAIN_PROBABILITY = 0.15;
    private static final double HIGHWINDS_PROBABILITY = 0.06;
    private static final double FOG_PROBABILITY = 0.17;
    // booleans to have info on the weather
    public static boolean rain;
    public static boolean winds;
    public static boolean fog;


    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
       // we start with good weather
        rain=false;
       winds=false;
       fog=false;
    }
    /**
     * we have an alternance every 100 steps between a probability of bad weather and and good weather
     */
    public void setWeather(){
        int cycle = Simulator.getStep();
        Random rand = Randomizer.getRandom();
        if (cycle % 100 == 0) {
            if(rand.nextDouble() <= RAIN_PROBABILITY) {
                   rain = true;
                }
            if(rand.nextDouble() <= HIGHWINDS_PROBABILITY) {
                    winds= true;
                }
            if(rand.nextDouble() <= FOG_PROBABILITY) {
                    fog= true;
                }
            }
            // this if statement allows to have good weather from time to time
         if( cycle % 200 ==0){
        rain=false;
       winds=false;
       fog=false;
        }
    }

    public static boolean getRain(){
        return rain;
    }
    
    public static boolean getWinds(){
        return winds;
    }
        
    public static boolean getFog(){
        return fog;
    }
}
