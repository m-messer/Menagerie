import java.util.*;
import java.util.Random;

/**
 * Write a description of class antelope here.
 *
 * @version (a version number or a date)
 */
public class Antelope extends Prey
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class antelope
     */
    public Antelope(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    public void act(List<Animal> newAntelopes)
    {
        super.incrementAge();
        if(isAlive()) {
            if(super.male==true){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey antelopes = (Prey) animal;
                if(antelopes.male==false) { 
                    giveBirth(newAntelopes);
                }
            }
        }
                 }
            if(super.male==false){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey antelopes = (Prey) animal;
                if(antelopes.male==true) { 
                    giveBirth(newAntelopes);
                }
            }
        }
                 }          
            // Try to move into a free location.
            if (Weather.getWinds() == true && Simulator.getStep() % 2 ==0) {//antalope does not move in the high winds 
            }
            else{
           // Move towards a source of food if found.
            Location newLocation = super.findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
}
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    private void giveBirth(List<Animal> newAntelopes)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = super.breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Prey young = new Antelope(false, field, loc);
            newAntelopes.add(young);
                if(super.std=true){
                young.std=true;
        
        }
    }
            
        }
         
    }

