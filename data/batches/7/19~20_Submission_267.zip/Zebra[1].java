import java.util.*;
import java.util.Random;

/**
 * Write a description of class zebra here.
 *
 * @version (a version number or a date)
 */
public class Zebra extends Prey
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class zebra
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    public void act(List<Animal> newZebras)
    {
        super.incrementAge();
        if(isAlive()) {
            if(super.male==true){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey zebra = (Prey) animal;
                if(super.male==false) { 
                    giveBirth(newZebras);
                }
            }
        }
                 }
            if(super.male==false){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey zebra = (Prey) animal;
                if(zebra.male==true) { 
                    giveBirth(newZebras);
                }
            }
        }
                 }
                
            // Try to move into a free location.
            if (Weather.getRain() == true && Simulator.getStep() % 2 ==0) {//zebra does not move whan its raining 
            }
            else{// Move towards a source of food if found.
            Location newLocation = super.findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
}
}
}
    /**
     *
     */
    private void giveBirth(List<Animal> newZebras)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = super.breed();
       
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Prey young = new Zebra(false, field, loc);
            newZebras.add(young);
                    if(super.std=true){
                young.std=true;
        
        }
        }
         
    }
}
