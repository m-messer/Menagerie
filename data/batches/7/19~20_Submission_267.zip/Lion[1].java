import java.util.*;
import java.util.Random;

/**
 * Write a description of class Lions here.
 *
 * @version (a version number or a date)
 */
public class Lion extends Predator
{
    // instance variables - replace the example below with your own
 

    /**
     * Constructor for objects of class Lions
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    private void giveBirth(List<Animal> newLions)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = super.breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Predator young = new Lion(false, field, loc);
            newLions.add(young);
            if(super.std=true){
                young.std=true;
        
        }
    }
    }
    public void act(List<Animal> newLions)
    {
        super.incrementAge();
        super.incrementHunger();
        if(isAlive()) {
            {
              if(super.male==true){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Predator) {
                Predator lion = (Predator) animal;
                if(lion.male==false) { 
                    giveBirth(newLions);
                }
            }
        }
                 }
            if(super.male==false){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Predator) {
                Predator lion = (Predator) animal;
                if(lion.male==true) { 
                    giveBirth(newLions);
                }
            }
        }
            if (Time.dayCycle() == !true && Simulator.getStep() % 2 ==0) {//Lion moves less at night 
            }
            else{
            // Move towards a source of food if found.
            Location newLocation = super.findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        }
    }

}
}
}


