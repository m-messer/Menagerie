    import java.util.*;
    import java.util.Random;
    
    /**
    * A simple model of a antelope.
    * antelope age, move, breed,eat and die.
    *
 * @version 2020.02.22
    */
    public class Antelope extends Prey
    {
        
        
        /**
         * Constructor for objects of class antelope
         */
        public Antelope(boolean randomAge, Field field, Location location)
        {
            super(randomAge, field, location);
        }
        /**
         * This method shows the day to day actions that an
         * antelope does: 
         * move, breed,eat
         */
        public void act(List<Animal> newAntelopes)
        {
            super.incrementAge();
        super.incrementHunger();
        if(isAlive()) {
            if(super.male==true){
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Prey) {
                        Prey antelopes = (Prey) animal;
                        if(antelopes.male==false) { 
                            giveBirth(newAntelopes);
                        }
                    }
                }
            }
            if(super.male==false){
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Prey) {
                        Prey antelopes = (Prey) animal;
                        if(antelopes.male==true) { 
                            giveBirth(newAntelopes);
                        }
                    }
                }
            }          
            // Try to move into a free location.
            if (Weather.getWinds() == true && Simulator.getStep() % 2 ==0) {//antalope does not move in the high winds 
            }
            else{
                // Move towards a source of food if found.
                Location newLocation = super.findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    /**
     * method to give birth
     */
    private void giveBirth(List<Animal> newAntelopes)
    {
        // New antelope are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = super.breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Prey young = new Antelope(false, field, loc);
            newAntelopes.add(young);
                    if(super.std=true){
                young.std=true;
        
            }   
        }
    
    }
 
}

