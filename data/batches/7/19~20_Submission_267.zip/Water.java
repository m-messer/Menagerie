
/**
 * This Class creates the water Element that will be used to create the river. It has no methods as the water is
 * used as a barrier that the animals cannot go on.
 *
 * @version 2020.02.22
 */
public class Water extends Element
{

    /**
     * Constructor for objects of class Grass
     */
     public Water( Field field, Location location)
    {
        super( field, location);
    }
}
