import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Sparrow.
 * Sparrows age, move, eat worms, and die. Sparrows do not have genders. 
 * 
 *
 * @version  02/03/2021
 */
public class Sparrow extends Animal
{
    // Characteristics shared by all Sparrows (class variables).

    // The age at which a Sparrow can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a Sparrow can live.
    private static final int MAX_AGE = 25; 
    // The likelihood of a Sparrow breeding.
    private static final double BREEDING_PROBABILITY = 0.03;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single worm. In effect, this is the
    // number of steps a Sparrow can go before it has to eat again.
    private static final int WORM_FOOD_VALUE = 2; 
    /**
     * Create a Sparrow. A Sparrow can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Sparrow will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sparrow(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(WORM_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(WORM_FOOD_VALUE);
        }
    }

    /**
     * This is what the Sparrow does most of the time: it hunts for
     * worms. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSparrows A list to return newly born Sparrows.
     */
    public void act(List<Animal> newSparrows)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSparrows);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is the night act of the sparrow. The sparrows
     * during the night is sleeping. 
     * The bird doesnt move, hunt or breed
     * @param List<Animal> newSparrows a list to collect the baby sparrows born
     */
    public void Nightact(List<Animal> newSparrows){
        incrementAge();
    }

    /**
     * Look for worms adjacent to the current location.
     * Only the first live worm is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Worm) {
                Worm worm = (Worm) animal;
                if(worm.isAlive()) { 
                    worm.setDead();
                    incrementFoodLevel(WORM_FOOD_VALUE); 
                    return where;
                }
            }

        }
        return null;
    }

    /**
     * Check whether or not this Sparrow is to give birth at this step.
     * New births will be made into free adjacent locations. 
     * If the adjacent location is grass, then the sparrow can give birth and the grass dies.
     * @param newSparrows A list to return newly born Sparrows.
     */
    private void giveBirth(List<Animal> newSparrows)
    {
        // New Sparrows are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            if(free.get(0) != null){
                if (field.getObjectAt(free.get(0)) instanceof Grass){
                    Grass grass = (Grass) field.getObjectAt(free.get(0));
                    grass.setDead();
                }
            }
            Location loc = free.remove(0);
            Sparrow young = new Sparrow(false, field, loc);
            newSparrows.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births.
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Sparrow can breed if it has reached the breeding age.
     * @return true if the sparrow can breed or false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}

