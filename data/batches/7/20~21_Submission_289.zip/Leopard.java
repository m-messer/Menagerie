import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Leopard.
 * Leopards age, move, eat antelopes and zebras, and die.
 * Their behaviour changes differs during the day and night:
 * The leopard breeds only during the day and feeds during the night but moves
 * all the time. It can breed only when it has met a mate of the oposite gender
 * and both animals have reached the breeding age. A leopard can get infected
 * if it eats a sick antelope and becomes more hungry.
 * If they breed when they are infected then the newly born leopards will be 
 * sick as well.
 * 
 *
 * @version 02/03/2021
 */
public class Leopard extends Animal
{
    // Characteristics shared by all Leopards (class variables).

    // The age at which a leopard can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a leopard can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a leopard breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single antelope or zebra. In effect, this is the
    // number of steps a leopard can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 3;
    private static final int ZEBRA_FOOD_VALUE = 4;
    // The probability a leopard can die of a deseas.
    private static final double IMMUNITY = 0.1;
    // The probability of a leopard surviving the sickness
    private static final double survivalRate = 0.7;
    // Determines the time of day
    private boolean isNight;

    /**
     * Create a leopard. A leopard can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the leopard will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Leopard(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(ANTELOPE_FOOD_VALUE + ZEBRA_FOOD_VALUE) + 1);
        }
        else {
            setAge(0);
            setFoodLevel(ANTELOPE_FOOD_VALUE + ZEBRA_FOOD_VALUE);
        }
        setGender();
    }

    /**
     * Returns if it's night
     * @return boolean true If it's night
     * @return false if It's day
     */
    private boolean getisNight(){
        return isNight;
    }

    /**
     * This is what the leopard does most of the time: it hunts for
     * antelopes and zebras. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLeopards A list to return newly born Leopards.
     */
    public void act(List<Animal> newLeopards)
    {
        incrementAge();
        incrementHunger();
        //If the animal is sick then it experiences symptoms of the desease
        if (getSick()){
            sickness();
        }  

        if(isAlive()) {
            // Move towards a source of food if found.
            Location newLocation = findAdjacentLocations(newLeopards);
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is the night act of the leopard.
     * it breeds only during the day  and hunts only during the night
     * but moves all the time.
     * @param newLeopards A list for the newly born leopards
     */
    public void Nightact(List<Animal> newLeopards){
        incrementAge();
        //when night act is called from the simulator class "isNight" is set to true
        isNight = true;
        act(newLeopards);
        //change back variable
        isNight = false;
    }

    /**
     * Look for antelopes and zebras adjacent to the current location.
     * Only the first live antelope or zebra is eaten.
     * If it encouteres grass it can eat some and walk over it.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findAdjacentLocations(List<Animal> newLeopards)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(identifyAnimal(animal, newLeopards)){
                return where;
            }
            else if (animal instanceof Grass){
                Grass grass = (Grass) animal;
                if (grass.isAlive()){
                    grass.setDead();
                    incrementFoodLevel(2);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * A method to identify the encountered animal.
     * @param animal The encountered animal
     * @param newLeopards The list for the new animals born
     * @return true If the preditor has found a prey
     * @return false If the animal has met anything else
     */
    private boolean identifyAnimal(Object animal,List<Animal> newLeopards)
    {
        if(animal instanceof Antelope) {
            Antelope antelope = (Antelope) animal;
            if(antelope.isAlive()) {
                feed(antelope, ANTELOPE_FOOD_VALUE);
                //Check if the encountered antelope is sick
                if (antelope.getSick()){
                    //The leopard is infecteed
                    setSick();
                }
                return true;
            }
        }
        else if(animal instanceof Zebra) {
            Zebra zebra = (Zebra) animal;
            if(zebra.isAlive()) { 
                feed(zebra,ZEBRA_FOOD_VALUE);
                return true;
            }
        } 
        else if(animal instanceof Leopard) {
            Leopard leopard = (Leopard) animal;
            //Check if the encountered leopard is sick
            checkIfSick(leopard);
            if(leopard.isAlive() && (leopard.getGender()!= getGender())){
                //Leopards breed only during the day
                if (!getisNight()){
                    giveBirth(newLeopards);
                }
            }
            return false;
        }
        return false;
    }

    /**
     * If the acting leopard is sick then it infects the animal it has met.
     * If the animal the acting leopard has met is sick, then it infects 
     * the acting lion.
     * @param animal The animal encountered
     */
    private void checkIfSick( Animal animal)
    {
        if(getSick()){
            animal.setSick();
        }
        else if(animal.getSick()){
            setSick();
        }
    }

    /**
     * The leopard feeds only at night. The prey is set to dead
     * @param animal The prey hunt
     * @param foodValue The food value of the prey
     */
    private void feed(Animal animal, int foodValue)
    {
        if(getisNight()){
            animal.setDead();
            incrementFoodLevel(foodValue);
        }
    }

    /**
     * Whenever a leopard is sick they get more hungry.
     * There is a certain probability the leopard can survive the sickness
     * or die from it.
     */
    private void sickness() {
        double chance = rand.nextDouble();
        if(chance <= IMMUNITY){
            //the leopard has died from the sickness
            setDead();
        }
        else if (chance >= survivalRate){
            //the leopard has recovered from the sickness
            setHealthy();
        }
        else{
            //the animal is still sick and can spread the desease
            incrementHunger();
        }
    }

    /**
     * Check whether or not this leopard is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLeopards A list to return newly born leopards.
     */
    private void giveBirth(List<Animal> newLeopards)
    {
        // New Leopards are born into adjacent locations.
        // Get a list of adjacent free locations.

        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            if(free.get(0) != null){
                //If the location is occupied by grass it can eat some and 
                //give birth over it
                if (field.getObjectAt(free.get(0)) instanceof Grass){
                    Grass grass = (Grass) field.getObjectAt(free.get(0));
                    grass.setDead();
                    incrementFoodLevel(2);//5
                }
            }
            Location loc = free.remove(0);
            Leopard young = new Leopard(false, field, loc);
            //If the acting leopard is sick the cubs born are sick too
            if(getSick()){
                young.setSick();
            }
            newLeopards.add(young);
        }
    }

    /** 
     * Checks if the animals around are leopards and what their gender is
     * @return true If the leopard met is of the oposite gender
     */
    private boolean aLeopardIsNear()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator <Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Leopard) {
                Leopard leopard = (Leopard) animal;
                if(leopard.isAlive() && (leopard.getGender()!= getGender())){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births.
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A leopard can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
