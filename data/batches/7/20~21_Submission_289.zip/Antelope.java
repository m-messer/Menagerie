import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a antelope.
 * antelopes age, move, breed, eat plants and die. 
 * There is a disease in the Savannah that starts with antelopes, antelopes have a chance of 
 * getting this disease and can then pass it on to other antelopes or other animals that eat them.
 * Antelopes have genders and can breed when they meet the oppopsite gender
 *
 * @version  02/03/2021
 */
public class Antelope extends Animal
{
    // Characteristics shared by all antelopes (class variables)
    // The age at which a antelope can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a antelope can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a antelope breeding.
    private static final double BREEDING_PROBABILITY = 0.21;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single plant. In effect, this is the number of steps an antelope can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 6;
    // The probability that the antelope will die to the disease
    private static final double IMMUNITY = 0.03;
    // The probability that the antelope will survive and become healthy
    private static final double survivalRate = 0.6;
    /**
     * Create a new antelope. A antelope may be created with age
     * zero (a new born) or with a random age.
     * A gender is set randomly between male or female.
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Antelope(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(PLANT_FOOD_VALUE)+1);
        }
        else {
            setAge(0);
            setFoodLevel(PLANT_FOOD_VALUE);
        }
        setGender();
    }

    /**
     * This is what the antelope does most of the time - it runs 
     * around eating grass. Sometimes it will breed or die of old age. 
     * Or it may die of the disease.
     * @param newantelopes A list to return newly born antelopes.
     */
    public void act(List<Animal> newAntelopes)
    {
        incrementAge();
        incrementHunger();
        makeSick();
        if(getSick()){
            sickness();
        }
        if(isAlive()) {
            giveBirth(newAntelopes);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * The night act of the animal: 
     * Antelopes do not change their bahaviour at night
     * @param List for new antelopes
     */
    public void Nightact(List<Animal> newAntelopes){
        act(newAntelopes);
    }

    /**
     * Look for antelopes adjacent to the current location.
     * Only the first live antelope is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Grass){
                Grass grass = (Grass) animal;
                if (grass.isAlive()){
                    grass.setDead();
                    incrementFoodLevel(PLANT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * The behaviour of the animal when its sick:
     * There is a probability they can die from the disease, 
     * or they can recover and become healthy, or they can carry the disease, 
     * and the effect of the sickness, is that they get hungrier.  
     */
    private void sickness() {
       double chance = rand.nextDouble();
       if(chance <= IMMUNITY){
           setDead();
       }
       else if (chance >= survivalRate){
            setHealthy();
       }
       else{
            incrementHunger();
       }
    }
    
    /**
     * Antelopes in the Savanna can randomly get the disease.
     */
    private void makeSick()
    {
        if(rand.nextDouble() <  0.05){
            setSick();
        }
    }

    /**
     * Check whether or not this antelope is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newantelopes A list to return newly born antelopes.
     */
    private void giveBirth(List<Animal> newAntelopes)
    {
        // New antelopes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            if(free.get(0) != null){
                if (field.getObjectAt(free.get(0)) instanceof Grass){
                    //If grass is at the location, eat the grass and move to the location
                    Grass grass = (Grass) field.getObjectAt(free.get(0));
                    grass.setDead();
                    incrementFoodLevel(PLANT_FOOD_VALUE);
                }
            }
            Location loc = free.remove(0);
            //Check if there is an antelope nearby of the oposite gender
            if(anAntelopeIsNear()){
                Antelope young = new Antelope(false, field, loc);
                if(getSick()){
                    young.setSick();
                }
                newAntelopes.add(young);
            }
        }
    }

    /**
     * checks if the animal around is an Antelope and of what gender
     * If either antelope is sick, then the other antelope becomes sick 
     * @return true for the giveBirth method if the animal around
     * is an antelope of the opopsite gender
     */
    private boolean anAntelopeIsNear()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator <Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Antelope) {
                Antelope antelope = (Antelope) animal;
                //sick antelopes pass on the disease to antelopes they meet
                if(getSick() ){
                    antelope.setSick();
                }
                else if(antelope.getSick()){
                    setSick();
                }
                //check they are opposite genders
                if(antelope.isAlive() && (antelope.getGender()!= getGender())){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births.
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A antelope can breed if it has reached the breeding age.
     * @return true if the antelope can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
