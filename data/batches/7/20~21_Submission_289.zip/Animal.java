import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 * Animals can eat, age, have genders or get sick.
 *
 * @version  02/03/2021
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // Whether the animal is sick or not
    private boolean isSick;
    // The animal's field.
    private Field field;
    // Random needed to generate random age or gender.
    protected Random rand = Randomizer.getRandom();
    // The animal's position in the field.
    private Location location;
    //The animals foodLevel, depicts the animals energy and strength
    private double foodLevel;
    // The animals age
    private double age;
    //The gender of the animal
    private String gender;
    //The max age, the animal dies at this age.
    private int maxAge;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param Max_Age The maximum age of each animal
     */
    public Animal(Field field, Location location, int MAX_AGE)
    {
        alive = true;        
        this.field = field;
        setLocation(location);
        isSick = false;
        maxAge = MAX_AGE;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * The night act of the animal. It can differ between species
     * @param newAnimals A list to receive the newly born animals
     */
    abstract public void Nightact(List<Animal> newAnimals);
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Assign a gender to each animal, randomly selecting either male or female
     * @return gender: male or female
     */
    protected String setGender(){
        if(rand.nextBoolean()) {
            gender = "male";
        }else{
            gender = "female";
        }
        return gender;
    }
    
    /**
     * @return the age of the animal
     */
    protected double getAge()
    {
        return age;
    }
    
    /**
     * Set the age when an animal is created
     * @param double age, either a random age or 0
     */
    protected void setAge(double age)
    {
      this.age = age;   
    }
    
    /**
     * Used to set the foodLevel for each animal when it is created
     */
    protected void setFoodLevel(double foodLevel)
    {
        this.foodLevel = foodLevel;
    }
    
    /**
     * Increments the foodLevel by the food value of whatever was eaten.
     * @param foodValue of the animal/grass that was eaten
     */
    protected void incrementFoodLevel(int foodValue)
    {
        foodLevel += foodValue;
    }
    
     /**
     * Returns the gender of the animal
     * @return String the gender
     */
    protected String getGender()
    {
        return gender;
   }
    
    /**
     * Returns the food level of the animal.
     * It depicts the animals energy and strength
     * @return double food level
     */
    protected double getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Increase the age. This could result in the Animal's death.
     */
    protected void incrementAge()
    {
        age = age + 0.02;
        if(age > maxAge) {
            setDead();
        }
    }
    
   /**
     * Make this Animal more hungry. This could result in the Sparrow's death.
     */
    protected void incrementHunger()
    {
        foodLevel-= 0.02;;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return if the animal is sick
     * @return true if sick, false otherwise
     */
    protected boolean getSick(){
        return isSick;
    }
    
    /**
     * Make the animal sick
     */
    protected void setSick(){
        isSick = true;
    }
    
    /**
     * The animal can recover from the sickness
     */
    protected void setHealthy(){
        isSick = false;
    }
 
}
