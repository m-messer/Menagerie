import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * Simulate plants. Plants grow at a given rate, but they do not move. Some creatures eat
 * plants. They will die if they do not find their food plant.
 * @version  02/03/2021
 */

public class Grass
{
    //growth rate of the grass
    private static final int GROWTH_RATE = 2;
    //boolean field to keep track if its alive
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    //Random to generate random growth
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        this.field = field;
        setLocation(location);   
        alive = true;
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    private void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead(){
        alive = false;
    }
    
    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isAlive(){
        return alive;
    }
    
    /**
     *The growth method for the grass
     */
    public void grow(List<Grass> newPlants){
        if(isAlive()){
            giveBirth(newPlants);           
        }
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    private Field getField()
    {
        return field;
    }
    
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    private Location getLocation()
    {
        return location;
    }
    
    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
    */
    private void giveBirth(List<Grass> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        for(int b = 0; b < GROWTH_RATE && free.size() > 0; b++) {
            if(free.get(0) != null){
                if (field.getObjectAt(free.get(0)) instanceof Grass){
                    Grass grass = (Grass) field.getObjectAt(free.get(0));
                    grass.setDead();
                }
            }           
            Location loc = free.remove(0);
            Grass young = new Grass( field, loc);
            newPlants.add(young);
        }
    }
}
 
