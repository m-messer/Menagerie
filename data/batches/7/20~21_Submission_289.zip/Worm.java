import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Worm.
 * Worms age, move, breed,eat plants and die.
 *
 * @version 02/03/2021
 */
public class Worm extends Animal
{
    // Characteristics shared by all Worms (class variables).

    // The age at which a Worm can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a Worm can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a Worm breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single plant. In effect, this is the
    // number of steps an worm can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 9;

    /**
     * Create a new Worm. A Worm may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Worm will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Worm(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(PLANT_FOOD_VALUE)+1);
        }
        else {
            setAge(0);
            setFoodLevel(PLANT_FOOD_VALUE);
        }
    }

    /**
     * This is what the Worm does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newWorms A list to return newly born Worms.
     */
    public void act(List<Animal> newWorms)
    {
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWorms);
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is the night act of the worm
     * It doesnt differ from  the daytime routine of the worm
     * 
     * @param List of newWorms to collect the baby worms born
     */
    public void Nightact(List<Animal> newWorms){
        incrementAge();
        act(newWorms);
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plants is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Grass){
                Grass grass = (Grass) animal;
                if (grass.isAlive()){
                    grass.setDead();
                    incrementFoodLevel(PLANT_FOOD_VALUE);
                    return where;
                }
            }

        }
        return null;
    }

    /**
     * Check whether or not this Worm is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWorms A list to return newly born Worms.
     */
    private void giveBirth(List<Animal> newWorms)
    {
        // New Worms are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            if(free.get(0) != null){
                
                if (field.getObjectAt(free.get(0)) instanceof Grass){
                    Grass grass = (Grass) field.getObjectAt(free.get(0));
                    grass.setDead();
                    incrementFoodLevel(5);
                }
            }
            Location loc = free.remove(0);
            Worm young = new Worm(false, field, loc);
            newWorms.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births.
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Worm can breed if it has reached the breeding age.
     * @return true if the Worm can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
