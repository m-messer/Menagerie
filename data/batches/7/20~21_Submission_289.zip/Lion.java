import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Lion.
 * Lions age, move, eat antelopes and zebras, and die.
 * Their behaiviour changes at night: they breed during the night but do not hunt.
 * They breed once they find a mate of the oposite gender. 
 * During the day they hunt but do not breed. If they eat a sick antelope they can get sick
 * and if they breed when they are sick the cubs will be sick as well.
 *
 * @version 02/03/2021
 * 
 */
public class Lion extends Animal
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single antelope or zebra. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 3;
    private static final int ZEBRA_FOOD_VALUE = 4;
    // The probability a lion can die of a deseas.
    private static final double IMMUNITY = 0.1;
    // The probability of a lion surviving the sickness
    private static final double survivalRate = 0.7;
    // Determines the time of day
    private boolean isNight;

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location, MAX_AGE);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(ANTELOPE_FOOD_VALUE + ZEBRA_FOOD_VALUE) + 1);
        }
        else {
            setAge(0);
            setFoodLevel(ANTELOPE_FOOD_VALUE + ZEBRA_FOOD_VALUE);
        }
        setGender();
    }

    /**
     * Returns if it's night
     * @return boolean true if it's night
     * @return boolean false if it's day
     */
    private boolean getisNight(){
        return isNight;
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * antelopes and zebras. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newlions A list to return newly born lions.
     */
    public void act(List<Animal> newLions)
    {
        incrementAge();
        incrementHunger();
        //If the animal is sick then it experiences symptoms of the desease
        if(getSick()){
            sickness();
        }   

        if(isAlive()) {
            // Move towards a source of food if found.
            Location newLocation = findAdjacentLocations(newLions);
            if(isAlive() && (getField()!= null) && (getLocation()!= null)){

                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * This is the night act of the lion.
     * The lion breeds only during the nigth and hunts during the day but moves all the time
     * @param newLions A list to return newly born lions
     */
    public void Nightact(List<Animal> newLions){
        incrementAge();
        //when night act is called from the simulator class "isNight" is set to true 
        isNight = true;
        act(newLions);
        //change back variable
        isNight = false;
    }

    /**
     * Whenever a lion is sick they get more hungry. 
     * There is a certain probability the lion can survive the sickness
     * or die from it.
     */
    private void sickness() {
        double chance = rand.nextDouble();
        if( chance <= IMMUNITY){
            //the animal has died from the sickness
            setDead(); 
        }
        else if (chance >= survivalRate){
            //the animal has recovered from the sickness
            setHealthy();
        }
        else{
            //the animal is still sick and can spread the deseas
            incrementHunger();
        }
    }

    /**
     * Looks for antelopes and zebras adjacent to the current location of the lion.
     * Only the first live antelope or zebra is eaten.
     * If it encounters grass it can eat some and walk over it.
     * @param newLions A list to return newly born lions
     * @return Where food was found, or null if it wasn't.
     */
    private Location findAdjacentLocations(List<Animal> newLions)
    {
        Field field = getField();
        if(!field.equals(null) && !getLocation().equals(null)){
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(identifyAnimal(animal, newLions)){
                    return where;
                }
                else if (animal instanceof Grass){
                    Grass grass = (Grass) animal;
                    if (grass.isAlive()){
                        grass.setDead();
                        incrementFoodLevel(2);
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * A method to identify the encountered animal.
     * @param animal The encountered animal
     * @param newLions A list for the new animals born
     * @return true If the preditor has found a prey
     * @return false If the preditor has found anything different from prey
     */
    private boolean identifyAnimal(Object animal, List<Animal> newLions)
    {
        if(animal instanceof Antelope) {
            Antelope antelope = (Antelope) animal;
            if(antelope.isAlive()) { 
                //Eat the antelope
                feed(antelope, ANTELOPE_FOOD_VALUE);
                //Check if the antelope encountered is sick
                if(antelope.getSick()){
                    //The lion was infected
                    setSick();
                }
                return true;
            }
        }
        else if(animal instanceof Zebra) {
            Zebra zebra = (Zebra) animal;
            if(zebra.isAlive()) { 
                //Eat the zebra
                feed(zebra,ZEBRA_FOOD_VALUE);
                return true;
            }
        } 
        else if(animal instanceof Lion) {
            Lion lion = (Lion) animal;
            if(isAlive() && !(getLocation().equals(null))){
                //Check if the encountered animal is sick
                checkIfSick(lion);
                //Check if the lion can compete with the encountered one
                if(canCompete(lion)){
                    compete(lion);
                }
                else{
                    giveBirth(newLions);
                }
            }
        }
        return false;
    }

    /**
     * If the acting lion is sick then it infects the animal it has met.
     * If the animal the acting lion has met is sick, then it infects the acting lion.
     * @param animal The animal encountered
     */
    private void checkIfSick( Animal animal)
    {
        if(getSick() ){
            animal.setSick();
        }
        else if(animal.getSick()){
            setSick();
        }
    }

    /**
     * The lion feeds only during the day. The prey is set to dead.
     * @param animal The prey hunt
     * @param foodValue The food value of the prey
     */
    private void feed(Animal animal, int foodValue)
    {
        if(!getisNight()){
            animal.setDead();
            incrementFoodLevel(foodValue);
        }
        return;
    }

    /**
     * Checks if the gender of the acting lion a one has met is also male
     * @param lion The lion our acting lion has met
     * @return true If the genders of both animals are male 
     * @return false if their genders of the lions are different or both are female
     */
    private boolean canCompete(Lion lion)
    {
        return (lion.getGender().equals("male")) &&
        (getGender().equals("male"));
    }

    /**
     * A male lion competes for superiority with another male one.
     * The food value of each represents the energy and strength of the animals.
     * The animal with greater food level defeats the oponent.
     * @param lion The lion our acting lion has met
     */
    private void compete(Lion lion)
    {
        if(lion.getFoodLevel() < getFoodLevel()){
            //if the acting lion wins the encountered lion is set to dead
            lion.setDead();
            return;
        }
        // Otherwise the acting lion dies
        setDead();
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    private void giveBirth(List<Animal> newLions)
    {
        // New lions are born into adjacent locations.
        // Get a list of adjacent free locations.
        
        Field field = getField();
        if(!(getField().equals(null))&& !(getLocation().equals(null))){
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births;
            //if the list of free locations is null then new lions cannot be born
            if(free == null){
                births = 0;
            }
            else{
                births= breed();
                for(int b = 0; b < births && free.size() > 0; b++) {
                    if(free.get(0) != null){
                        //If the location is occupied by grass it can eat some and 
                        //give birth over it
                        if (field.getObjectAt(free.get(0)) instanceof Grass){
                            Grass grass = (Grass) field.getObjectAt(free.get(0));
                            grass.setDead();
                            incrementFoodLevel(2);
                        }
                    }
                    Location loc = free.remove(0);
                    Lion young = new Lion(false, field, loc);
                    //If the acting lion is sick then the cubs born will also be sick
                    if(getSick()){
                        young.setSick();
                    }
                    newLions.add(young);
                }
            }
        }
    }

    /** 
     * Checks if the animals around are lions and what their gender is as well 
     * as if they are mature enough to breed
     * @return true If the animal around is lion of the oposite gender
     * and old enough to breed
     * @return false If the animall around is not a lion or of the oposite
     * gender and old enough to breed
     */
    private boolean aLionIsNear()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator <Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Lion) {
                Lion lion = (Lion) animal;
                if(lion.isAlive() && (lion.getGender()!= getGender()) 
                && (lion.getAge() >= BREEDING_AGE)){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births.
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A lion can breed if it has reached the breeding age, is night time 
     * and has met a mate of the oposite gender of the breeding age.
     * @return If it's night time and the acting lion is old enough to breed 
     * and has met a lion of the oposite gender that is also old enough to 
     * breed
     */
    private boolean canBreed()
    {
        return (getisNight()) && (getAge() >= BREEDING_AGE) 
        && (aLionIsNear()); 
    }
}

