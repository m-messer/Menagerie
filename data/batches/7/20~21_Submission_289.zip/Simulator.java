import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing antelopes, zebras, lions, leopards, sparrows and worms.
 * The simulation also contains grass that the animals can walk over 
 * and eat.
 *
 * @version  02/03/2021
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a Lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;
    // The probability that a antelope will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.02;   
    // The probability that a leopard will be created in any given grid position.
    private static final double LEOPARD_CREATION_PROBABILITY = 0.02;
    // The probability that a sparrow will be created in any given grid position.
    private static final double SPARROW_CREATION_PROBABILITY = 0.02;
    // The probability that a worm will be created in any given grid position.
    private static final double WORM_CREATION_PROBABILITY = 0.02;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.02;
    private static final Random rand = Randomizer.getRandom();
    // List of animals in the field.
    private List<Animal> animals;
    //List of plants in the simulator
    private List<Grass> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    //The current time of day
    private String timeOfDay;
    //Used to change the time of day
    private boolean change;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        timeOfDay = "Day";
        change = true;
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants =  new ArrayList<>();
        field = new Field(depth, width);
        timeOfDay = "Day";
        change = true;

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Antelope.class, Color.ORANGE);
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Lion.class, Color.BLUE);
        view.setColor(Leopard.class, Color.PINK);
        view.setColor(Sparrow.class, Color.RED);
        view.setColor(Worm.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(100);   // uncomment this to run more slowly
        }
    }

    /**
     * A method to set the time of day
     * A day = 50 steps
     * A night = 50 steps
     * @param the current step
     * @return timeOfDay Day or Night
     */
    private String setTime(int step){
        if(step % 50 == 0){
            change = !change;
            if(change == true){
                timeOfDay =  "Day";
            }
            else if (change == false){ 
                timeOfDay = "Night";
            }
        }
        return timeOfDay;
    }

    /**
     * Returns the time of day
     * @return String 'Day' if it's daytime
     * @return String 'Night' if it's nighttime
     */
    private String getTime(){
        return timeOfDay;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant
     */
    public void simulateOneStep()
    {
        step++;
        timeOfDay = setTime(step);
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act. Their behaviour may change in the Day and at Night
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if((timeOfDay.equals("Day")) && (animal.isAlive())){
                animal.act(newAnimals);
            }

            if ((timeOfDay.equals("Night")) && (animal.isAlive())){
                animal.Nightact(newAnimals);
            }

            if(! (animal.isAlive())) {
                it.remove();
            }
        }
        //add new born animals to the list
        animals.addAll(newAnimals);

        List<Grass> newPlants = new ArrayList<>();        
        // Let all plants grow.
        for(Iterator<Grass> it = plants.iterator(); it.hasNext(); ) {
            Grass grass = it.next();
            grass.grow(newPlants);
            if(! (grass.isAlive())) {
                it.remove();
            }
        }
        //add new plants to the list.
        plants.addAll(newPlants);

        view.showStatus(step, field,timeOfDay);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        timeOfDay = "Day";
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, timeOfDay);
    }

    /**
     * Randomly populate the field with Lions, antelopes, zebras, leopards, sparrows and worms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope = new Antelope(true, field, location);
                    animals.add(antelope);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }else if(rand.nextDouble() <= LEOPARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Leopard leopard = new Leopard(true, field, location);
                    animals.add(leopard);
                }
                else if(rand.nextDouble() <= SPARROW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sparrow sparrow = new Sparrow(true, field, location);
                    animals.add(sparrow);
                }
                else if(rand.nextDouble() <= WORM_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Worm worm = new Worm(true, field, location);
                    animals.add(worm);
                }else if(rand.nextDouble() <= 0.09){
                    Location location = new Location (row, col);
                    Grass grass = new Grass( field, location);
                    plants.add(grass);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

}
