import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * Heavily modified version of the predator-prey simulation.
 * 6 species(coyote,squirrel,wolf,deer,duck,grass).
 * 2 predators - coyote,wolf.
 * 3 preys - squirrel,deer,duck.
 * 1 poisonous plant which kills the 3 preys around it.
 * 
 * @version 2019.02.21 (2)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a coyote will be created in any given grid position.
    private static final double COYOTE_CREATION_PROBABILITY = 0.1;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.25;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.12;
    // The probability that a duck will be created in any given grid position.
    private static final double DUCK_CREATION_PROBABILITY = 0.25;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.16;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.002;
    // Step value for creating more plants.
    private static final int PLANT_GROW_RATE = 15;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //Step duration of the night.
    private static final int nightDuration = 25;
    //Boolean array for weather changes
    private static final boolean[] weatherParam = new boolean[2];

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //Time of day value of the simulation
    private boolean isDay = true;
    //Weather creation
    private static Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * 
     * @param depth
     *            Depth of the field. Must be greater than zero.
     * @param width
     *            Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        //Storing the animals and the plants
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Squirrel.class, Color.ORANGE);
        view.setColor(Coyote.class, Color.BLUE);
        view.setColor(Wolf.class, Color.BLACK);
        view.setColor(Duck.class, Color.GREEN);
        view.setColor(Deer.class, Color.MAGENTA);
        view.setColor(Grass.class, new Color(178, 110, 54));
        // Setup a valid starting point.
        reset();
        
    }

    /**
     * Run the simulation from its current state for a reasonably long period, (4000
     * steps).
     */
    public void runLongSimulation() {
        simulate(1500);
    }

    /**
     * Run the simulation from its current state for the given number of steps. Stop
     * before the given number of steps if it ceases to be viable.
     * Alternates between day and night (changing after every nightDuration value)
     * Delay added.
     * @param numSteps
     *            The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            if (step % nightDuration == 0) {
                isDay = !isDay;
            }
            simulateOneStep();
            if (!isDay) {
                delay(10);  //Delay for night.
            }
        }
    }

    /**
     * Counting the population of a specific species.
     * @param species - the class of the counted species.
     */
    private int countTotalSpecies(Class species) {
        int count = 0;
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if (animal != null) {
                    if (animal.getClass().equals(species)) {
                        count++;
                    }
                }
            }
        }
        return count;
    }

    /**
     * Counting the infertile wolves.
     * Return a 2 decimal rounded percentage of infertile wolves/whole population.
     */
    private double getWolfInfertile() {
        int healthy = countTotalSpecies(Wolf.class);
        int count = 0;
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if (animal instanceof Wolf) {
                    Wolf wolf = (Wolf) animal;
                    if (wolf.isInfertile()) {

                        count++;
                    }
                }
            }
        }
        if (healthy == 0) {
            return 0.0;
        } else {
            
            
            return round((count*1.0 / healthy*1.0) * 100.0,2);

        }
    }
    
    /**
     * Counting the infected squirrels.
     * Return a 2 decimals rounded percentage of infected squirrels/whole population.
    */
    private double getInfectedSquirrels() {
        int healthy = countTotalSpecies(Squirrel.class);
        int count = 0;
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if (animal instanceof Squirrel) {
                    Squirrel squirrel = (Squirrel) animal;
                    if (squirrel.isInfected()) {

                        count++;
                    }
                }
            }
        }
        if (healthy == 0) {
            return 0.0;
        } else {
            
            
            return round((count*1.0 / healthy*1.0) * 100.0,2);

        }
    }

    /**
     * Run the simulation from its current state for a single step. Iterate over the
     * whole field updating the state of each species.
     * Updating the weather when it is called with the right step.
     * Growing plants if it is in a right step.
     * Passing the datas for the SimlatorView.
     */
    public void simulateOneStep() {
        step++;
        weather.update(weatherParam, step);
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();

        // Let all animals act.
        for (Iterator<Animal> it = animals.iterator(); it.hasNext();) {
            Animal animal = it.next();
            animal.act(newAnimals, isDay);
            if (!animal.isAlive()) {
                it.remove();
            }
        }
        // Let all plants act.
        for (Iterator<Plant> it = plants.iterator(); it.hasNext();) {
            Plant plant = it.next();
            plant.act();
            if (!plant.isAlive()) {
                it.remove();
            }
        }
        //Growing plants if it is the right step.
        growPlants();

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, weather.getCurrentTemp(), weatherParam[0], field, getWolfInfertile(), getInfectedSquirrels());


    }

    /**
     * Growing procedure of the plants.
     * If it is raining(fertile soil), it takes less steps to spawn/grow new plants.
     * Searching through the field for free locations and creating plants based on its probability.
     */
    private void growPlants() {

        int growRate;
        if (!weatherParam[1]) {
            growRate = 2 * PLANT_GROW_RATE;
        } else {
            growRate = PLANT_GROW_RATE;
        }

        if (step % growRate == 0 && weatherParam[0]) {
            for (int row = 0; row < field.getDepth(); row++) {
                for (int col = 0; col < field.getWidth(); col++) {

                    Location location = new Location(row, col);
                    if (field.getObjectAt(location) == null && rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {

                        Grass grass = new Grass(field, location);
                        plants.add(grass);

                    }

                }
            }

        }

    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        plants.clear();
        weather = new Weather();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, weather.getCurrentTemp(), weatherParam[0], field, getWolfInfertile(), getInfectedSquirrels());
    }

    /**
     * Fully randomized populisation of the animals based on their probability.
     * Using a boolean array to sort out animals then randomising which animal is going to be spawned by a counter.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        int one;

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                double creationProb = rand.nextDouble();
                boolean[] creation = { false, false, false, false, false, false };
                if (creationProb <=COYOTE_CREATION_PROBABILITY) {
                    creation[0] = true;
                }
                if (creationProb <=SQUIRREL_CREATION_PROBABILITY) {
                    creation[1] = true;
                }
                if (creationProb <= WOLF_CREATION_PROBABILITY) {
                    creation[2] = true;
                }
                if (creationProb <= DUCK_CREATION_PROBABILITY) {
                    creation[3] = true;
                }
                if (creationProb <= DEER_CREATION_PROBABILITY) {
                    creation[4] = true;
                }
                if (creationProb <= PLANT_CREATION_PROBABILITY) {
                    creation[5] = true;
                }
                int trueCount = 0;
                int elementNumber = -1;
                for (int i = 0; i < creation.length; i++) {
                    if (creation[i]) {
                        trueCount++;
                    }
                }
                if (trueCount > 0) {
                    int choseAnimal = rand.nextInt(trueCount) + 1;
                    int counter = 0;
                    for (int i = 0; i < creation.length; i++) {

                        if (creation[i]) {
                            counter++;
                            if (counter == choseAnimal) {
                                elementNumber = i;
                            }
                        }
                    }
                }

                if (elementNumber == 0) {
                    Location location = new Location(row, col);
                    Coyote coyote = new Coyote(true, field, location);
                    animals.add(coyote);
                } else if (elementNumber == 1) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    animals.add(squirrel);
                } else if (elementNumber == 2) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                } else if (elementNumber == 3) {
                    Location location = new Location(row, col);
                    Duck duck = new Duck(true, field, location);
                    animals.add(duck);
                } else if (elementNumber == 4) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    animals.add(deer);
                } else if (elementNumber == 5) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(field, location);
                    plants.add(grass);
                }
                // else leave the location empty.

            }
        }
    }

    /**
     * Pause for a given time.
     * 
     * @param millisec
     *            The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Rounding the final values.
     * Copied from https://stackoverflow.com/questions/2808535/round-a-double-to-2-decimal-places, Obtained by X, Y 20:17, 21/02/2019
     */
    private static double round(double value, int places) {             
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
    
}
