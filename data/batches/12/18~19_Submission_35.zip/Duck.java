import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a duck.
 * Ducks age, move, breed, and die.
 * 
 * @version 2019.02.21
 */
public class Duck extends Animal
{
    // Characteristics shared by all ducks (class variables).

    // The age at which a duck can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a duck can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a duck breeding.
    private static final double BREEDING_PROBABILITY = 0.23;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The duck's age.
    private int age;
    // the duck's gender status.
    private boolean isFemale;

    /**
     * Create a new duck. A duck may be created with age
     * zero (a new born) or with a random age.
     * Gender always random.
     * 
     * @param randomAge If true, the duck will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Duck(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        isFemale = rand.nextBoolean();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            isFemale = rand.nextBoolean();
        }
    }
    
    /**
     * This is what the duck does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * Ducks can die due to posionous plants.
     *  
     * @param newducks A list to return newly born ducks.
     * @param isDay
     *            Moves if it is true.
     */
    public void act(List<Animal> newducks, boolean isDay) {
        if (isDay) { 
            incrementAge();
            if (isAlive()) {
                giveBirth(newducks);

                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }

                // Check if duck is poisoned by nearby plants
                if (isAlive()) {
                    List<Location> nearby = getField().adjacentLocations(getLocation());
                    Iterator<Location> it = nearby.iterator();

                    while (it.hasNext()) {
                        Location where = it.next();
                        Object plant = getField().getObjectAt(where);
                        if (plant instanceof Grass) {

                            setDead();
                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the duck's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this duck is to give birth at this step. New births will
     * be made into free adjacent locations.
     * There must be a male and female duck in order to breed.Only females can breed.
     * @param newDucks
     *            A list to return newly born ducks.
     */
    private void giveBirth(List<Animal> newDucks)
    {
        boolean containsMale = false;
        Field field = getField();
        List<Location> free = field.adjacentLocations(getLocation());
        if(this.isFemale){
            Iterator<Location> it = free.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Duck){
                    Duck duck = (Duck) animal;
                    if(duck.isFemale == false){
                        containsMale = true;
                        break;
                    }
                }
            }
            if(containsMale){
                int births = breed();
                List<Location> free1 = field.getFreeAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free1.size() > 0; b++) {
                        Location loc = free1.remove(0);
                        Duck young = new Duck(false, field, loc);
                        newDucks.add(young);
                    }
            }
        }
    }  
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A duck can breed if it has reached the breeding age.
     * @return true if the duck can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
