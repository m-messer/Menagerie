import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a coyote. Coyotes age, move, eat and die.
 * 
 * @version 2019.02.21
 */
public class Coyote extends Animal {
    // Characteristics shared by all coyotes (class variables).

    // The age at which a coyote can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a coyote can live.
    private static final int MAX_AGE = 45;
    // The likelihood of a coyote breeding.
    private static final double BREEDING_PROBABILITY = 0.48;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The coyote's age.
    private int age;
    // The coyote's food level, which is increased by eating.
    private int foodLevel;
        // the coyote's gender status.
    private boolean isFemale;

    /**
     * Create a coyote. A coyote can be created as a new born (age zero and not hungry) or
     * with a random age and food level.
     * Gender always random
     * 
     * @param randomAge
     *            If true, the coyote will have random age and hunger level.
     * @param field
     *            The field currently occupied.
     * @param location
     *            The location within the field.
     */
    public Coyote(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = 35;
            isFemale = rand.nextBoolean();
        } else {
            age = 0;
            foodLevel = 30;
            isFemale = rand.nextBoolean();
        }
    }

    /**
     * This is what the coyote does most of the time: it hunts for food. In the
     * process, it might breed, die of hunger, or die of old age.
     * Acts only if it is daytime.
     * 
     * @param field
     *            The field currently occupied.
     * @param newCoyotes
     *            A list to return newly born coyotes.
     *@param isDay
     *            Moves if it is true.            
     */
    public void act(List<Animal> newCoyotes, boolean isDay) {
        if (isDay) {
            incrementAge();
            incrementHunger();
            if (isAlive()) {
                giveBirth(newCoyotes);
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the coyote's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this coyote more hungry. This could result in the coyote's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for food adjacent to the current location. Only the first live prey
     * is eaten.
     * Hunts only if hungry.
     * Preys are squirrels and ducks for him.
     * Randomized killing if there are 2 different edible species in adjacent locations.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            Random random = new Random();
            int randomFood = random.nextInt(2);
            if (animal instanceof Squirrel && isHungry() && randomFood == 1) {
                Squirrel squirrel = (Squirrel) animal;
                if (squirrel.isAlive()) {
                    squirrel.setDead();
                    foodLevel = foodLevel + SQUIRREL_FOOD_VALUE;
                    return where;
                }
            } else if (animal instanceof Duck && isHungry() && randomFood == 0) {
                Duck duck = (Duck) animal;
                if (duck.isAlive()) {
                    duck.setDead();
                    foodLevel = foodLevel + DUCK_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this coyote is to give birth at this step. New births will
     * be made into free adjacent locations.
     * There must be a male and female coyote in order to breed.Only females can breed.
     * 
     * @param newcoyotes
     *            A list to return newly born coyotes.
     */
    private void giveBirth(List<Animal> newCoyotes) {
        boolean containsMale = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        if (this.isFemale && !isHungry()) {
            Iterator<Location> it = adjacent.iterator();
            while (it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if (animal instanceof Coyote) {
                    Coyote coyote = (Coyote) animal;
                    if (!coyote.isFemale) {
                        containsMale = true;
                        break;
                    }
                }
            }
        }
        
        if (containsMale) {
            List<Location> free1 = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for (int b = 0; b < births && free1.size() > 0; b++) {
                Location loc = free1.remove(0);
                Coyote young = new Coyote(false, field, loc);
                newCoyotes.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A coyote can breed if it has reached the breeding age.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Method for comparing the coyote's food level and decides whether it is hungry or not.
     */
    private boolean isHungry() {
        return (foodLevel < 50);
    }
}
