import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * Model of the posionous grass, which kills preys.
 * Identical to the original rabbit class (to an extend).
 * 
 * @version 2019.02.21
 */
public class Grass extends Plant {
	// Characteristics shared by all plants(class variables).
	private static final int MAX_AGE = 10;
	// The plant's age.
	private int age;

	/**
	 * Create a new plant. A plant is created with age zero.	
	 * @param field
	 *            The field currently occupied.
	 * @param location
	 *            The location within the field.
	 */
	public Grass(Field field, Location location) {
		super(field, location);
		age = 0;
	}

	/**
         * Incrementing age of the plant.
	 */
	public void act() {		
		incrementAge();
	}

	/**
	 * Increase the age. This could result in the plant's death.
	 */
	private void incrementAge() {
		age++;
		if (age > MAX_AGE) {
			setDead();
		}
	}

	
}
