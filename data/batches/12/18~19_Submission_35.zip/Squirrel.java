import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a squirrel. 
 * Squirrels age, move, breed, and die.
 * 
 * @version 2019.02.21
 */
public class Squirrel extends Animal {
    // Characteristics shared by all squirrels (class variables).

    // The age at which a squirrel can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a squirrel can live.
    private static final int MAX_AGE = 30;
    private static final int INFECTED_MAX_AGE = 20;
    // The likelihood of a squirrel breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    private static final int PLANT_FOOD_VALUE = 10;
    // The squirrel's age.
    private int age;
    // the squirrel's gender status.
    private boolean isFemale;
    //the squirrel's infection status.
    private boolean isInfected;
    
    /**
     * Create a squirrel. A squirrel can be created as a new born (age zero) or
     * with a random age.Gender always random.
     * Every x-th. squirrel is infected.
     * 
     * @param randomAge
     *            If true, the squirrel will have random age.
     * @param field
     *            The field currently occupied.
     * @param location
     *            The location within the field.
     */
    public Squirrel(boolean randomAge, Field field, Location location) {
        super(field, location);
        age = 0;
        isFemale = rand.nextBoolean();
        if (rand.nextInt(100) == 1) {
            isInfected = true;
        }
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the squirrel does most of the time - it runs around. Sometimes it
     * will breed or die of old age.
     * Squirrels can die due to posionous plants.
     * Gender always random.
     * 
     * @param newSquirrels
     *            A list to return newly born squirrels.
     *@param isDay
         *            Moves if it is true.            
     */
    public void act(List<Animal> newSquirrels, boolean isDay) {
        if (isDay) {
            incrementAge();
            if (isAlive()) {
                giveBirth(newSquirrels);

                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }

                // Check if squirrel is poisoned by nearby plants
                if (isAlive()) {
                    List<Location> nearby = getField().adjacentLocations(getLocation());
                    Iterator<Location> it = nearby.iterator();

                    while (it.hasNext()) {
                        Location where = it.next();
                        Object plant = getField().getObjectAt(where);
                        if (plant instanceof Grass) {

                            setDead();
                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the squirrel's death.
     * If squirrel is infected, then maximum age is lowered.
     */
    private void incrementAge() {
        age++;
        if (!isInfected && age > MAX_AGE) {
            setDead();
        } else if (isInfected && age > INFECTED_MAX_AGE) {
            setDead();
        }
    }

     /**
     * Check whether or not this squirrel is to give birth at this step. New births will
     * be made into free adjacent locations.
     * There must be a male and female squirrel in order to breed.Only females can breed.
     * if female or male squirrel is infected, then the newborns are ifected as well.
     * @param newSquirrels
     *            A list to return newly born squirerels.
     */
    private void giveBirth(List<Animal> newSquirrels) {
        boolean containsMale = false;
        boolean maleInfected = false;
        Field field = getField();
        List<Location> free = field.adjacentLocations(getLocation());
        if (this.isFemale) {
            Iterator<Location> it = free.iterator();
            while (it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if (animal instanceof Squirrel) {
                    Squirrel squirrel = (Squirrel) animal;
                    if (!squirrel.isFemale) {
                        containsMale = true;
                        if (squirrel.isInfected()) {
                            maleInfected = true;
                        }
                        break;
                    }
                }
            }
            if (containsMale) {
                int births = breed();
                List<Location> free1 = field.getFreeAdjacentLocations(getLocation());
                for (int b = 0; b < births && free1.size() > 0; b++) {
                    Location loc = free1.remove(0);
                    Squirrel young = new Squirrel(false, field, loc);
                    if (this.isInfected || maleInfected) {
                        young.getInfection();
                    }
                    newSquirrels.add(young);
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A squirrel can breed if it has reached the breeding age.
     * 
     * @return true if the squirrel can breed, false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }

    /**
     *Set the infected value to true.
     */
    private boolean getInfection() {
        isInfected = true;
        return isInfected;
    }
    
    /**
     *Get the infected value.
    */
    public boolean isInfected() {
        return isInfected;
    }
}
