import java.util.Random;

/**
 *New class of creating 2 different "weathers" for the simulation.
 *2 different things only effect the plants:
 *     -Raining/fertile and dry season - needed for plants to grow
 *     -Temperature of the step - slows then the growth rate of the plant.
 *     
 */
public class Weather {
	//Used constants of the class
	private final int rainLimit = 30; //Every 30 steps it will rain.
	private final int heatLimit = 35; //Final temperature point of fertile season.
	private final int rainRate = 10; //every x step, it  can rain.
	private final int heatCheckRate = 3; //Checking the heat every x step.
	private int lastRain; //Step difference between the curretn step and last rain step.
	private int currentTemp; //current temperature value

	Random rand = Randomizer.getRandom();

	/**
	 * Constructor for objects of class Weather
	 */
	public Weather() {
		lastRain = 0;
		currentTemp = 17;
		
	}

	/**
	 *Updating the weathers based on the step and randomisiation.
	 */
	public void update(boolean[] weatherParam, int step) {

		rain(weatherParam, step);

		temperature(weatherParam, step);
	}

	/**
	 * Method for updating the temperature.
	 * 
	 * @param boolean array place 1
	 *           Indicates whether the temperature is below or above the heat limit.
	 * @param int step
	 *           For checking the temperature every heatCheckRate steps.       
	 */
	public void temperature(boolean[] weatherParam, int step) {

		if (step % heatCheckRate == 0) {
			boolean sign = rand.nextBoolean();
			if (sign) {
				currentTemp = (currentTemp + rand.nextInt(3));
			} else {
				currentTemp = (currentTemp - rand.nextInt(3));
			}
		}

		if (currentTemp > heatLimit) {
			weatherParam[1] = false;
		} else {
			weatherParam[1] = true;
		}
	}
	
        /**
	 *Returns the current temperature.
	 *
	 *@return The current temperature
	*/
	public int getCurrentTemp() {
		return currentTemp;
	}

	/**
	 * Method for updating the weather/rain condition.
	 * It might rain after a fixed step amount.
	 * 
	 * @param boolean array place 0
	 *           Indicates whether the soil is fertile or dry.
	 * @param int step
	 *           For checking the weather every rainRate steps.       
	 */
	public void rain(boolean[] weatherParam, int step) {

		if ((step - lastRain) > rainLimit) {
			weatherParam[0] = false;
		} else {
			weatherParam[0] = true;
		}

		if (step % rainRate == 0 && rand.nextBoolean()) {
			lastRain = step;
		}
	}

}
