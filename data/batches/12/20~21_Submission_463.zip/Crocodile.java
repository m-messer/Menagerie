import java.util.List;
import java.util.Random;

/**
 * A simple model of a Crocodile.
 * Crocodiles age, move, eat zebras, antelopes, bread and die.
 *
 * @version 2016.02.29 (2)
 */
public class Crocodile extends Predator
{
  // Characteristics shared by all Crocodiles (class variables).
  // The food value of a single crocodile
  private static final int CROCODILE_FOOD_VALUE = 125;
  // The age at which a Crocodile can start to breed.
  private static final int BREEDING_AGE = 5;
  // The age to which a Crocodile can live.
  private static final int MAX_AGE = 2500;
  // The likelihood of a Crocodile breeding.
  private static final double BREEDING_PROBABILITY = 0.3;
  // The maximum number of births.
  private static final int MAX_LITTER_SIZE = 2;
  // A shared random number generator to control breeding.
  private static final Random rand = Randomizer.getRandom();

  // Individual characteristics (instance fields).


  /**
   * Create a Crocodile. A Crocodile can be created as a new born (age zero
   * and not hungry) or with a random age and food level.
   *
   * @param isRandom If true, the Crocodile will have random age and hunger level.
   * @param field The field currently occupied.
   * @param location The location within the field.
   */
  public Crocodile(boolean isRandom, Field field, Location location)
  {
    super(field, location);
    favouritePreys.add(Antelope.class);
    favouritePreys.add(Zebra.class);
    setAgeAndHungerLevel(isRandom);
  }

  /**
   * Set crocodile's age and hunger lever
   * @param isRandom if true, then set age and hungerLevel randomly
   */
  protected void setAgeAndHungerLevel(boolean isRandom){
    if(isRandom){
      age = rand.nextInt(MAX_AGE);
      hungerLevel = rand.nextInt(CROCODILE_FOOD_VALUE) + 1;
    }
    else{
      age = 0;
      hungerLevel = CROCODILE_FOOD_VALUE;
    }
  }

  /**
   * Check whether or not this Crocodile is to give birth at this step.
   * New births will be made into free adjacent locations.
   * @param newCrocodiles A list to return newly born Crocodiles.
   */
  protected void giveBirth(List<Animal> newCrocodiles)
  {
    // New Crocodiles are born into adjacent locations.
    // Get a list of adjacent free locations.
    Field field = getField();
    List<Location> free = field.getFreeAdjacentLocations(getLocation());
    int births = getLitterSize();
    for(int b = 0; b < births && free.size() > 0; b++) {
      Location loc = free.remove(0);
      Crocodile young = new Crocodile(false, field, loc);
      newCrocodiles.add(young);
    }
  }

  /**
   * Generate a number representing the number of births,
   * if it can breed.
   * @return The number of births (may be zero).
   */
  protected int getLitterSize()
  {
    int births = 0;
    if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
      births = rand.nextInt(MAX_LITTER_SIZE) + 1;
    }
    return births;
  }

  /**
   * Return true if crocodile is female and is in breeding age
   * @return true if crocodile is physically able to breed
   */
  protected boolean isOfAge(){return age >= BREEDING_AGE;}

  /**
   * Return the crocodile's food value
   * @return The crocodile's food value
   */
  protected int getFoodValue(){return CROCODILE_FOOD_VALUE;}

  /**
   * Return the crocodile's max age
   * @return The crocodile's max age
   */
  protected int getMaxAge(){return MAX_AGE;}

  /**
   *
   * @return
   */
  @Override
  protected boolean isHungry() {
    return hungerLevel <= CROCODILE_FOOD_VALUE;
  }
}
