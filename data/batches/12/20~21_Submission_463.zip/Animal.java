import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * <p>This code was built on top of the <i>2016.02.29</i>
 *
 * @version 2021.03.03
 */
public abstract class Animal {
  private Field field;
  private Location location;
  private boolean alive;
  protected boolean isFemale;
  protected boolean isInfected;
  protected int age;
  protected int hungerLevel;
  protected List<Animal> nearbyAnimals;

  /**
   * Create a new animal at the given location in the field,
   * and randomly assign their biological attributes.
   *
   * @param field the field currently occupied
   * @param location the location within the field
   */
  public Animal(Field field, Location location) {
    Random random = new Random();
    alive = true;
    this.field = field;
    setLocation(location);
    isFemale = random.nextBoolean();
    isInfected = random.nextBoolean();
    nearbyAnimals = new ArrayList<>();
  }

  /**
   * Allow an animal to act. Their behaviour may vary depending on whether they
   * are a predator or a prey, whether it is a day time or night time, or what
   * the weather conditions are like.
   *
   * @param newAnimals the list to be filled with newly born animals
   * @param currentTime
   * @param sunrise
   * @param sunset
   */
  final void act(List<Animal> newAnimals,
                 LocalTime currentTime,
                 LocalTime sunrise,
                 LocalTime sunset) {
    incrementAge();
    if (isAlive()) {
      if (isInfected) { infect(); }
      if (currentTime.isAfter(sunrise) && currentTime.isBefore(sunset)) {
        performDayBehaviour(newAnimals);
      } else {
        performNightBehaviour(newAnimals);
      }
    }
  }

  abstract void performDayBehaviour(List<Animal> newAnimals);

  abstract void performNightBehaviour(List<Animal> newAnimals);

  /**
   * A female animal can breed if, and only if, they have reached their
   * breeding age, and there exists another male animal of the same species
   * in their close proximity, that is, in the neighbouring cell in the field.
   *
   * @return <tt>true</tt> if the animal can breed
   */
  final boolean canBreed() {
    boolean mateFound = false;
    findNearbyAnimals();
    for (Animal mate : nearbyAnimals) {
      if ((mate.getClass() == this.getClass())
          && (mate.isOfAge() && this.isOfAge())
          && (!mate.isFemale && this.isFemale)) {
        mateFound = true;
        break;
      }
    }
    return mateFound;
  }

  abstract boolean isOfAge();

  abstract void giveBirth(List<Animal> newAnimals);

  abstract int getLitterSize();

  abstract int getFoodValue();

  abstract void setAgeAndHungerLevel(boolean isRandom);

  /**
   * Allow an animal to spread a disease to other animals.
   */
  final void infect() {
    findNearbyAnimals();
    for (Animal animal : nearbyAnimals) {
      if (!animal.isInfected) {
        animal.isInfected = true;
      }
    }
  }

  /**
   * Allow an animal to look for nearby animals in their close proximity,
   * that is, in the neighbouring cell in the field.
   */
  final void findNearbyAnimals() {
    Field field = getField();
    List<Location> adjacent = field.adjacentLocations(getLocation());
    Iterator<Location> it = adjacent.iterator();
    while (it.hasNext()) {
      Location where = it.next();
      Object obj = field.getObjectAt(where);
      if (obj != null) {
        Animal animal = (Animal) obj;
        nearbyAnimals.add(animal);
      }
    }
  }

  /**
   * Return the animal's field.
   *
   * @return the animal's field
   */
  Field getField() {
    return field;
  }

  /**
   * Return the animal's location.
   *
   * @return the animal's location
   */
  Location getLocation() {
    return location;
  }

  /**
   * Place the animal at the new location in the field.
   *
   * @param newLocation the animal's new location
   */
  void setLocation(Location newLocation) {
    if (location != null) {
      field.clear(location);
    }
    location = newLocation;
    field.place(this, newLocation);
  }

  /**
   * Check whether an animal is alive, or not.
   *
   * @return <tt>true</tt> if the animal is alive
   */
  boolean isAlive() {
    return alive;
  }

  /**
   * Indicate that an animal is no longer alive and remove them from the field,
   * that is, clear their previously occupied location in the field.
   */
  void setDead() {
    alive = false;
    if (location != null) {
      field.clear(location);
      location = null;
      field = null;
    }
  }

  /**
   * Make the animal older, that is, increment their age. This could result in
   * the animal's death. Note that the animal will age faster if they are
   * infected.
   */
  void incrementAge() {
    if (isInfected) {
      age = age + 3;
    } else {
      age++;
    }
    if (age > getMaxAge()) { setDead(); }
  }

  abstract int getMaxAge();

  /**
   * Make the animal more hungry, that is, decrease their hunger level.
   * This could result in the animal's death.
   */
  void incrementHunger() {
    hungerLevel--;
    if (hungerLevel <= 0) { setDead(); }
  }
}
