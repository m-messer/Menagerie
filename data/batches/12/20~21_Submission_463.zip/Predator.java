import java.util.ArrayList;
import java.util.List;

/**
 * A class representing shared behavioural characteristics of predators.
 *
 * @version 2021.03.03
 */
public abstract class Predator extends Animal {
  protected ArrayList<Class> favouritePreys = new ArrayList<>();

  /**
   * Create a new predator at the given location in the field.
   *
   * @param field the field currently occupied.
   * @param location the location within the field.
   */
  Predator(Field field, Location location) {
    super(field, location);
  }

  /**
   * A predator may give birth, move around, or die of overcrowding during day time.
   *
   * @param newLions the list to be filled with newly born predators.
   */
  public void performDayBehaviour(List<Animal> newPredators) {
    incrementHunger();
    if (isAlive()) {
      giveBirth(newPredators);
      // See if it was possible to move.
      Location newLocation = getField().freeAdjacentLocation(getLocation());
      if (newLocation != null) {
        setLocation(newLocation);
      } else { // Overcrowding.
        setDead();
      }
    }
  }

  /**
   * A predator may find food, or move around during night time.
   *
   * @param newLions the list to be filled with newly born predators.
   */
  public void performNightBehaviour(List<Animal> newPredators) {
    incrementHunger();
    if (isAlive()) {
      Location newLocation = null;
      if (isHungry()) {
        newLocation = findFood();
      } else {
        if (newLocation == null) {
          newLocation = getField().freeAdjacentLocation(getLocation());
          if (newLocation != null) {
            setLocation(newLocation);
          }
        }
      }
    }
  }

  abstract boolean isHungry();

  private Location findFood() {
    Location where = null;
    findNearbyAnimals();
    for (Animal prey : nearbyAnimals) {
      if (favouritePreys.contains(prey.getClass()) && prey.isAlive()) {
        where = prey.getLocation();
        prey.setDead();
        hungerLevel += prey.getFoodValue();
        break;
      }
    }
    return where;
  }
}
