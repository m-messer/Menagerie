import java.util.List;

/**
 * A class representing shared behavioural characteristics of preys.
 *
 * @version 2021.03.03
 */
public abstract class Prey extends Animal
{
    /**
     * Create a new prey at location in field.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location) {
        super(field, location);
    }

    /**
     * This is what the prey does during daytime - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newPreys A list to return newly born preys.
     */
    @Override
    public void performDayBehaviour(List<Animal> newPreys)
    {
        if(isAlive()) {
            giveBirth(newPreys);
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is what the prey does during nighttime - it sleeps (doesn't move)
     * and tries to breed.
     * Sometimes it will die of old age.
     * @param newPreys A list to return newly born preys.
     */
    @Override
    public void performNightBehaviour(List<Animal> newPreys)
    {
        if(isAlive()){
            giveBirth(newPreys);
        } // else sleep
    }
}
