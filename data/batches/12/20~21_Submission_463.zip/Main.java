public class Main {
  public static void main(String[] args) {
    Simulator sim = new Simulator();
    sim.simulate(200);
  }
}
