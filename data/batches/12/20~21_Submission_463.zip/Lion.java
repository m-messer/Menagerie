import java.util.List;
import java.util.Random;

/**
 * A simple model of a Lion.
 * Lions age, move, eat zebras, mouses, antelopes, bread and die.
 *
 * @version 2016.02.29 (2)
 */
public class Lion extends Predator
{
  // Characteristics shared by all Lions (class variables).
  // The food value of a single lion.
  private static final int LION_FOOD_VALUE = 100;
  // The age at which a lion can start to breed.
  private static final int BREEDING_AGE = 3;
  // The age to which a lion can live.
  private static final int MAX_AGE = 2000;
  // The likelihood of a lion breeding.
  private static final double BREEDING_PROBABILITY = 0.8;
  // The maximum number of births.
  private static final int MAX_LITTER_SIZE = 4;
  // A shared random number generator to control breeding.
  private static final Random rand = Randomizer.getRandom();

  // Individual characteristics (instance fields).

  /**
   * Create a Lion. A lion can be created as a new born (age zero
   * and not hungry) or with a random age and food level.
   * @param isRandom If true, the Lion will have random age and hunger level.
   * @param field The field currently occupied.
   * @param location The location within the field.
   */
  public Lion(boolean isRandom, Field field, Location location)
  {
    super(field, location);
    favouritePreys.add(Antelope.class);
    favouritePreys.add(Zebra.class);
    favouritePreys.add(Mouse.class);
    setAgeAndHungerLevel(isRandom);
  }

  /**
   * Set lion's age and hungerLevel
   * @param isRandom if true, then set age and hungerLevel randomly
   */
  protected void setAgeAndHungerLevel(boolean isRandom){
    if(isRandom){
      age = rand.nextInt(MAX_AGE);
      hungerLevel = rand.nextInt(LION_FOOD_VALUE) + 1;
    }
    else{
      age = 0;
      hungerLevel = LION_FOOD_VALUE;
    }
  }

  /**
   * Check whether or not this lion is to give birth at this step.
   * New births will be made into free adjacent locations.
   * @param newLions A list to return newly born Lions.
   */
  protected void giveBirth(List<Animal> newLions)
  {
    // New lions are born into adjacent locations.
    // Get a list of adjacent free locations.
    Field field = getField();
    List<Location> free = field.getFreeAdjacentLocations(getLocation());
    int births = getLitterSize();
    for(int b = 0; b < births && free.size() > 0; b++) {
      Location loc = free.remove(0);
      Lion young = new Lion(false, field, loc);
      newLions.add(young);
    }
  }

  /**
   * Generate a number representing the number of births,
   * if it can breed.
   * @return The number of births (may be zero).
   */
  protected int getLitterSize()
  {
    int births = 0;
    if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
      births = rand.nextInt(MAX_LITTER_SIZE) + 1;
    }
    return births;
  }

  /**
   * Return true if lion is female and is in breeding age
   * @return true if lion is physically able to breed
   */
  protected boolean isOfAge(){return age >= BREEDING_AGE;}

  /**
   * Return the lion's food value
   * @return The lion's food value
   */
  protected int getFoodValue(){return LION_FOOD_VALUE;}

  /**
   * Return the lion's max age
   * @return The lion's max age
   */
  protected int getMaxAge(){return MAX_AGE;}

  @Override
  protected boolean isHungry() {
    return hungerLevel <= LION_FOOD_VALUE;
  }
}
