import java.util.List;
import java.util.Random;

/**
 * A simple model of a zebra.
 * zebras age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Zebra extends Prey
{
    // Characteristics shared by all zebras (class variables).
    // The food value of a single zebra
    private static final int ZEBRA_FOOD_VALUE = 50;
    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).

    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * @param isRandom If true, the zebra will have a random age and hunger.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean isRandom, Field field, Location location)
    {
        super(field, location);
        setAgeAndHungerLevel(isRandom);
    }

    /**
     * Set zebra's age and hungerLevel
     * @param isRandom if true, then set age and hungerLevel randomly
     */
    protected void setAgeAndHungerLevel(boolean isRandom){
        if(isRandom){
            age = rand.nextInt(MAX_AGE);
            hungerLevel = rand.nextInt(ZEBRA_FOOD_VALUE) + 1;
        }
        else{
            age = 0;
            hungerLevel = ZEBRA_FOOD_VALUE;
        }
    }
    
    /**
     * Check whether or not this zebra is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newZebras A list to return newly born zebras.
     */
    protected void giveBirth(List<Animal> newZebras)
    {
        // New zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = getLitterSize();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Zebra young = new Zebra(false, field, loc);
            newZebras.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int getLitterSize()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Return true if zebra is female and is in breeding age
     * @return true if zebra is physically able to breed
     */
    protected boolean isOfAge(){return age >= BREEDING_AGE;}

    /**
     * Return the zebra's food value
     * @return The zebra's food value
     */
    protected int getFoodValue(){return ZEBRA_FOOD_VALUE;}

    /**
     * Return the zebra's max age
     * @return The zebra's max age
     */
    protected int getMaxAge(){return MAX_AGE;}
}
