
/**
 * The predator class stores animals that are predators 
 *
 * @version 2022.03.01 (2)
 */
public abstract class Predator extends Animal
{


    /**
     * Constructor for objects of class Predator
     */
    public Predator(Field field, Location location)
    {
        super(field,location);

    }


}
