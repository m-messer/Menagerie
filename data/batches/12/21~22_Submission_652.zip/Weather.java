import java.util.Random;

/**
 * The weather class performs weather events and this affects the population of animals.
 *
 * @version 2022.03.01 (2)
 */
public class Weather
{
    
    private static final double PROBABILTY_OF_LIGHTNING = 0.96; //The probability that there will be lightning 
    private static final Random rand= Randomizer.getRandom();
    private boolean lightning = false;
    public Weather weather;

    /**
     * Constructor for objects of class Weather
    */
    public Weather()
    { 
    this.weather= weather;
    }

    /**
     * @returns if lightening occurs and comapres it to a probability 
     */
    public boolean isLightning(){  
    { double s = rand.nextDouble();
        
      if (s>=PROBABILTY_OF_LIGHTNING){
          lightning = true;
      }
      else {
          lightning = false;
      }
      
      return lightning;
    }
    }
    

}
