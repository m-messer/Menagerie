

/**
  * The prey class stores animals that are prey
 *
 * @version 2022.03.01 (2)
 */
public abstract class Prey extends Animal
{

    

    /**
     * Constructor for objects of class Prey
     */
    public Prey(Field field, Location location)
    {
        super(field, location);
 
    }


}
