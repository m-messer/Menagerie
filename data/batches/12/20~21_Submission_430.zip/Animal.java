import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.SplittableRandom;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.02 (3)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's sex. 
    private Sex sex;
    // The animal's age.
    private int age;
    // Whether the this animal is pregrant or not (only if sex=Sex.FEMALE)
    private boolean isPregnant=false;
    // Whether the animal is sick or not.
    private boolean isSick;
    // The hunger of the animal.
    private int foodLevel;
    // How sick the animal is.
    private int sicknessLevel = 0;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param sex The sex of the animal.
     */
    public Animal(Field field, Location location, Sex sex)
    {
        this(field, location);
        this.sex = sex;
    }
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.sex = Sex.randomSex();
        if(enterIfProbability(5))
            isSick = true;
        else
            isSick = false;   
    }
    
    /**
     * This method check the sickeness status of the animal.
     * It may also set the animal sick if one of the neighbouring animals
     * is sick as well.
     * Once the level of sickness has reached the maximum level,
     * the animal dies. 
     */
    public void checkSickness() {
        if (isAlive()) {
            if (isSick) {
                if (sicknessLevel >= getMaxSicknessLevel()) {
                    setDead();
                } else {
                    if (enterIfProbability(60)) {
                        sicknessLevel++;
                    }
                }
            } else {
                Iterator<Location> i = field.adjacentLocations(location).iterator();
                while (i.hasNext()) {
                    Location l = i.next();
                    Object animal = field.getObjectAt(l);
                    if (animal instanceof Animal) {
                        Animal a = (Animal) animal;
                        if (a.isSick()) {
                            if (enterIfProbability(35)) {
                                isSick = true;
                            }
                        }
                    }
                }
            }
        } 
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, int time, Weather weather);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the animal's sex.
     * @return The animal's sex.
     */
    protected Sex getSex()
    {
        return sex;
    }
    
    /**
     * Compare two animals and return if two animals' sex are opposite.
     * @return Whether two animals' sex are opposite .
     */
    protected boolean isOppositeSex(Animal animal){
        return !(this.sex == animal.sex);
    }
    
    /**
     * Make the female animal meet with a male one. 
     * Female can get pregnat based on probability.
     * If the female is already pregnant, then she will give birth to new borns.
     * @param newFoxes A list to return newly born foxes.
     * @param probabilty The probability for a female to get pregnant.
     */
    protected void meet(List<Animal> newAnimals,int probability){
        if(probability<0 || probability>100){ meet(newAnimals); return;}
        if(sex == Sex.FEMALE){
            if(!isPregnant){
                Iterator<Location> i = field.adjacentLocations(location).iterator();
                while(!isPregnant && i.hasNext()){
                    Location l = i.next();
                    Object adjacent = getField().getObjectAt(l);
                    
                    if(adjacent instanceof Animal && 
                        adjacent.getClass().isAssignableFrom(this.getClass()))
                    {
                        Animal adjacentAnimal = (Animal) adjacent;
                        if(adjacentAnimal.sex == Sex.MALE){
                            if(enterIfProbability(probability))
                                isPregnant = true;
                        }
                    }
                }
            } else {
                giveBirth(newAnimals);
            }
        }
    }
    
    
    /**
     * Make the female animal meet with a male one. 
     * Female always gets.
     * If the female is pregnant, then she will give birth to new borns.
     * @param newFoxes A list to return newly born foxes.
     */
    protected void meet(List<Animal> newAnimals){
       meet(newAnimals, 100);
    }
    
    /** 
     * Private method to decide the enter of a if statement given a probability.
     */
    private static boolean enterIfProbability(int probability){
        SplittableRandom r = new SplittableRandom();
        return r.nextInt(1, 101) <= probability;
    }
    
    /**
     * Increase the age.
     * This could result in the rabbit's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= getBreedingAge();
    }
    
     /**
     * Return whether the animal is sick of a widespread disease.
     * @return Whether the animal is sick or not.
     */
    public boolean isSick() {
        return isSick;
    }
    
    /**
     * Return the age of the animal.
     * @return The age of the animal.
     */
    public int getAge(){
        return age;
    }
    
    /**
     * Set the age of the animal to a new age.
     * @param The new age of the animal.
     */
    public void setAge(int age){
        this.age = age;
    }

    /**
     * Return the maximum food level
     * @return The maximum food level
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set the hunger of the animal.
     * @param the new level of hunger.
     */
    public void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Return the age at which a fox can start to breed.
     * @return The age at which a fox can start to breed.
     */
    public abstract int getBreedingAge();
    
    /**
     * Return the age to which this animal can live.
     * @return The age to which this animal can live.
     */
    public abstract int getMaxAge();
    
    /**
     * Return the likelihood of this animal breeding.
     * @return the likelihood of this animal to breed.
     */
    public abstract double getBreedingProbability();
    
    /**
     * Return the maximum number of births.
     * @return The maximum number of births.
     */
    public abstract int getMaxLitterSize();
    
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    public abstract void giveBirth(List<Animal> newAnimals);
    
    /**
     * Return the maximum level of sickness.
     * @return The maximum level of sickness.
     */
    public abstract int getMaxSicknessLevel();
}
