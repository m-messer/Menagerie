import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Fox extends Predator
{
    // Characteristics shared by all foxes (class variables).
    
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.16;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The likelihood of a female to get pregnant.
    private static final int PREGNANCY_PROBABILITY = 50;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 15;
    // The level of sickeness this animal has to reach to die
    private static final int MAX_SICKNESS_LEVEL = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();  

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location)
    {
        super(field, location, Rabbit.class);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(RABBIT_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(RABBIT_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Animal> newFoxes, int time, Weather weather)
    {
        incrementAge();
        checkSickness();
        if(time > 14 || time < 9){
            incrementHunger();
            if(isAlive()) {
                meet(newFoxes, PREGNANCY_PROBABILITY); 
                switch(weather){
                    case SUNNY:
                    case RAINY:        
                        // Move towards a source of food if found.
                        Location newLocation = findFood();
                        
                        if(newLocation == null) { 
                            // No food found - try to move to a free location.
                            newLocation = getField().freeAdjacentLocation(getLocation());
                        }
                        // See if it was possible to move.
                        if(newLocation != null) {
                        setLocation(newLocation);
                        }
                        else {
                            // Overcrowding.
                            setDead();
                        }  
                    break;
                    
                    case STORMY:
                    case FOGGY:
                    break;
                }
                
           }
        }
    }

    
    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    public void giveBirth(List<Animal> newFoxes)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fox young = new Fox(false, field, loc);
            newFoxes.add(young);
        }
    }
    
    /**
     * Return the age to which this animal can live.
     * @return The age to which this animal can live.
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the age at which a fox can start to breed.
     * @return The age at which a fox can start to breed.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Return the likelihood of this animal breeding.
     * @return the likelihood of this animal to breed.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum number of births.
     * @return The maximum number of births.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the maximum level of sickness.
     * @return The maximum level of sickness.
     */
    public int getMaxSicknessLevel() {
        return MAX_SICKNESS_LEVEL;
    }
    
    /**
     * Returns the food value of a single prey. In effect, this is the
     * number of steps a predator can go before it has to eat again.
     */
    public int getPreyFoodValue(){
        return RABBIT_FOOD_VALUE;
    }
}
