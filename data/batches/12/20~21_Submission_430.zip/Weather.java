import java.util.Random;

/**
 * Enumeration class Weather 
 * This enum describe the weather of the simulation
 *
 * @version 02-03-2021
 */
public enum Weather
{
    SUNNY, RAINY, FOGGY, STORMY;
    
    /**
     * This method return a random weather condition.
     * @return A random weather condition, randomly picked.
     */
    public static Weather getRandomWeather(){
        Random r = new Random();
        Integer rand = r.nextInt(4);
        Weather weather = null;
        switch(rand){
            case 0:
                weather = SUNNY;
            break;
            case 1:
                weather = RAINY;
            break;
            case 2:
                weather = FOGGY;
            break;
            case 3:
                weather = STORMY;
            break;
        }
        return weather;
    }
}
