import java.util.List;
import java.util.Random;

/**
 * A simple model of a deer.
 * Rabbits age, move, breed, eat deers, and die.
 *
 * @version 2021.03.02 (3)
 */
public class Wolf extends Predator
{
    // Characteristics shared by all wolves (class variables).
    
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The likelihood of a female to get pregnant.
    private static final int PREGNANCY_PROBABILITY = 50;
    // The food value of a single wolf. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 15;
    // The level of sickeness this animal has to reach to die
    private static final int MAX_SICKNESS_LEVEL = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a wolf. A coyote can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location, Deer.class);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(DEER_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(DEER_FOOD_VALUE);
        }
    }
 
    /**
     * This is what the wolf does most of the time: it hunts for
     * deers. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWolves A list to return newly born wolves.
     */
    public void act(List<Animal> newWolves, int time, Weather weather)
    {
        incrementAge();
        checkSickness();
        if(time > 1 || time < 5){
            incrementHunger();
            if(isAlive()) {
                meet(newWolves, PREGNANCY_PROBABILITY); 
                switch(weather){
                    case SUNNY:
                    case RAINY:        
                        // Move towards a source of food if found.
                        Location newLocation = findFood();
                        
                        if(newLocation == null) { 
                            // No food found - try to move to a free location.
                            newLocation = getField().freeAdjacentLocation(getLocation());
                        }
                        // See if it was possible to move.
                        if(newLocation != null) {
                        setLocation(newLocation);
                        }
                        else {
                            // Overcrowding.
                            setDead();
                        }  
                    break;
                    
                    case STORMY:
                    case FOGGY:
                    break;
                }
            }
        }
    }

    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolf A list to return newly born wolves.
     */
    public void giveBirth(List<Animal> newWolves)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, field, loc);
            newWolves.add(young);
        }
    }
    
    /**
     * Return the age to which this animal can live.
     * @return The age to which this animal can live.
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the age at which a fox can start to breed.
     * @return The age at which a fox can start to breed.
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Return the likelihood of this animal breeding.
     * @return the likelihood of this animal to breed.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Return the maximum number of births.
     * @return The maximum number of births.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the maximum level of sickness.
     * @return The maximum level of sickness.
     */
    public int getMaxSicknessLevel() {
        return MAX_SICKNESS_LEVEL;
    }
    
    /**
     * Returns the food value of a single prey. In effect, this is the
     * number of steps a predator can go before it has to eat again.
     */
    public int getPreyFoodValue(){
        return DEER_FOOD_VALUE;
    }
}
