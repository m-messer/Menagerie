import java.util.*;

/**
 * A class representing shared characteristics of preys. 
 * This means animals that do not eat other animal but eat plants.
 *
 * @version 2021.03.02 (3)
 */
public abstract class Prey extends Animal
{
    /**
     * Create a new prey animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location){
        super(field, location);
        setFoodLevel(getPlantFoodValue());
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public void findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            
            if(plant instanceof Plant)
            {
                Plant food = (Plant) plant;
                if(food.isAvailable()) { 
                    food.setEaten();
                    setFoodLevel(getPlantFoodValue());
                }
            }
        }
    }
    
    /**
     * Returns the food value of a single prey. In effect, this is the
     * number of steps a wolf can go before it has to eat again.
     */
    public abstract int getPlantFoodValue();
}
