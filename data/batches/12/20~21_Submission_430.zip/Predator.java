import java.util.*;
/**
 * A class representing shared characteristics of predators. 
 * This means animals that do not eat other animal but eat plants.
 *
 * @version 2021.03.02 (3)
 */
public abstract class Predator extends Animal
{
    //This field stores the class of the animal this predator is going to eat
    private Class <? extends Prey> preyType;

    /**
     * Create a new predator animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param prey The Class type of the prey this predator is going to eat.
     */
    public Predator(Field field, Location location, Class<? extends Prey> prey)
    {
        super(field, location);
        setFoodLevel(getPreyFoodValue());
        preyType = prey;
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            if(animal instanceof Animal && animal.getClass().isAssignableFrom(preyType))
            {
                Animal prey = (Animal) animal;
                if(prey.isAlive()) {
                    prey.setDead();
                    setFoodLevel(getPreyFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Returns the food value of a single prey. In effect, this is the
     * number of steps a predator can go before it has to eat again.
     */
    public abstract int getPreyFoodValue();
}