import java.util.Random;
/**
 * Enumeration class Sex 
 * This enum describe the sex of every animal.
 *
 * @version 02-03-2021
 */
public enum Sex
{
    MALE, FEMALE;
    
    /**
     * This method return a random sex between MALE and FEMALE
     * @return A sex value, randomly picked.
     */
    public static Sex randomSex(){
        Random r = new Random();
        if(r.nextBoolean())
            return Sex.MALE;
        else 
            return Sex.FEMALE;
    }
}
