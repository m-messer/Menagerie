
/**
 * Write a description of class Plant here.
 *
 * @version (a version number or a date)
 */
public class Plant
{
    private boolean isEaten = false;
    private Location location;
    private Field field;
    private int growingSteps;
    private static final int maxSteps = 10;
    
    public Plant(Location location, Field field) {
        this.field = field;
        setLocation(location);
    }
    
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    public void act(Weather weather) {
        if (isEaten) {
            switch (weather){
                case RAINY:
                case STORMY:
                    if (growingSteps >= maxSteps) {
                        isEaten = false;  
                        growingSteps = 0;
                        }
                    else {
                        growingSteps++;
                    }
                break;
                
                default:
                    //do nothing in case of sun or fog
                break;
            }
        }
            
    }
    
    /**
     * Return the plant's location.
     * @return The plants's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    public boolean isAvailable() {
        return !isEaten;
    }
    
    public void setEaten() {
        isEaten = true;
    }
}
