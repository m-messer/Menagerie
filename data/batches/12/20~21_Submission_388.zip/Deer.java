import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a deer.
 * deer age, move, eat grass, and die.
 * @version (a version number or a date)
 */
public class Deer extends Animal
{
     // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a deer can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single Grass. In effect, this is the
    // number of steps a deer can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 12;
    
    // The deer's age.
    private int age;
    // The deer's food level, which is increased by eating grass.
    private int foodLevel;
    // The deer's gender
    private boolean gender;
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age. Deer's are also assigned random genders
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
            gender = rand.nextDouble() < 0.5;
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
            gender = rand.nextBoolean();
        }
    }
    
    /**
     * This is what the deer does most of the time - it eats
     * grass. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newDeer A list to return newly born deer.
     */
    public void act(List<Animal> newDeer)
    {
       incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newDeer);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
   
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
       Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Grass) {
                Grass grass = (Grass) animal;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Make this deer more hungry. This could result in the deer's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
     /**
     * Increase the age.
     * This could result in the deer's death.
     */
     private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this deer is to give birth at this step.
     * Deer can only propagate when a male and female individual meet.
     * New births will be made into free adjacent locations.
     * @param newDeer A list to return newly born deer.
     */
    private void giveBirth(List<Animal> newDeer)
    {
        // New deer are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc);
            newDeer.add(young);
        }
    }
    
    /**
     * Check for the deers gender.
     * @return the deers gender as a boolean
     */
    private boolean checkGender()
    {
        return gender;
    }
    
    /**
     * A deer can breed if it has reached the breeding age.
     * @return true if the deer can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * There is a check for gender.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            Field field = getField();
            boolean genderNow = checkGender();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);

                if(animal instanceof Deer) {
                    Deer deer = (Deer) animal;
                    if(deer.checkGender() != genderNow) {
                        births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                    }
                }
            }
        }
        return births;
    }
}