import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple modle of grass
 * Grass age, grow and die
 *
 * @version (a version number or a date)
 */
public class Grass extends Animal
{
    // The age at which a grass can start to breed.
    private static int BREEDING_AGE = 1;
    // The age to which a grass can live.
    private static int MAX_AGE = 40;
    // The likelihood of a grass breeding.
    private static double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 8;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    
    // Individual characteristics (instance fields).
    // The grass's age.
    private int age;
    /**
     * Create a grass object.Grass can be created as a new born (age zero
     * ) or with a random age.
     * 
     * @param randomAge If true, the grass will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
         age = rand.nextInt(MAX_AGE);
        }
        else {
         age = 0;
        }
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newGrass)
    {
         incrementAge();
         if(isAlive() && Time.isDay()) {
             giveBirth(newGrass);
         }
    }
    
    /**
     * Increase the age. This could result in the grass's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrass A list to return newly born grass.
     */
    private void giveBirth(List<Animal> newGrass)
    {
        // New grass are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A Grass can breed if it has reached the breeding age and it is day time.
     */
    private boolean canBreed()
    {
        return ((age >= BREEDING_AGE) && Time.isDay()); 
    }
}