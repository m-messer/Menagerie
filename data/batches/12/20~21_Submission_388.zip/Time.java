import java.util.LinkedList;

/**
 * A time system, used to keep track of day/night state and also seasons.
 *
 * @version (a version number or a date)
 */
public class Time
{
    // True for day and false for night.
    private boolean daytime;
    // The number of days into a season.
    private int daysGone;
    // A list for all four seasons.
    private LinkedList<String> seasons;
    // A variable to store current season.
    private String currentSeason = "Spring";
    // static version of current season.
    private static String staticSeason = "Spring";
    // static version of daytime.
    private static boolean staticDayTime = true;
    
    /**
     * Set the time of day to be daytime and number of days past in the simulation to be 0.
     * Add different seasons into the list which will be dispalyed in the simulation.
     */
    public Time()
    {
        seasons = new LinkedList<String>();
        daytime = true;
        daysGone = 0;
        seasons.add("Spring");
        seasons.add("Summer");
        seasons.add("Autum");
        seasons.add("Winter");
    }

    /**
     * After every 5 steps the time of day changes.
     * The days that have gone by get incremented.
     * @param steps the number of steps that have gone by in the simulation.
     */
    public void dayNightCycle(int steps)
    {
        if(steps % 5 == 0)
        {
            daytime = !daytime;
            staticDayTime = !staticDayTime;
            daysGone ++;
        }
        seasonCycle();
    }

    /**
     * Reset the time of day back to day time and set the number of days that have past back to 0. 
     * In essence this this will just help reset the simulation back to its starting point
     */
    public void resetTime() 
    {
        daytime = true;
        daysGone = 0;
    }

    /**
     * Reset the season back to Spring.
     * In essence this this will just help reset the simulation back to its starting point.
     */
    public void resetSeason()
    {
        while(seasons.peek() != "Spring")
        {
            seasonCycle();
        }
    }

    /**
     * Remove the head of the list(which acts as the current season) so that a new season will be the current season.
     */
    public void nextSeason()
    {
        seasons.add(seasons.poll());
        currentSeason = seasons.peek();
        staticSeason = seasons.peek();
    }

    /**
     * Cycle through the seasons every 5 full days.
     */
    public void seasonCycle()
    {
        if(daysGone == 10) {
            nextSeason();
            daysGone = 0;
        }
    }

    /**
     * Check what the season at the front of list is, the head of the list is what the current season is.
     * @return What the current season in the simulation is.
     */
    public String currentSeason()
    {
        return currentSeason;
    }

    /**
     * Check what the current time is.
     * @return the time of day as a String, it is either day or night.
     */
    public String currentTime()
    {
        if(daytime) {
            return "Day time";
        } else {
            return "Night time";
        }
    }

    /**
     * Check what the current time is.
     * @return true if its daytime, false if its night time.
     */
    public boolean currentTimeState()
    {
        if(daytime) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * return the current state of seasons
     * @return true for winter, false for any other seasons.
     */
    public static boolean isWinter()
    {   
        if (staticSeason.equals("Winter")) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * return the current day/night state
     * @return ture for day and false for night.
     */
    
    public static boolean isDay()
    {
        return staticDayTime;
    }

    /**
     * The number of days that have passed in the simulation
     * @return the number of days gone by as an int.
     */
    public int getDates() 
    {
        return daysGone;
    }
}