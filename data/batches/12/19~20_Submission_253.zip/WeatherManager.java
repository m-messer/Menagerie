/**
 * Provide a weather manager for keeping track of
 * the current weather in the simulation.
 *
 * @version 2020.02.10
 */

public class WeatherManager {
    // Different types of weather.
    public enum Weather {RAINING, SNOWING, FOG, DROUGHT}

    // The simulation's time manager.
    private TimeManager timeManager;

    // The current weather.
    private Weather weather;
    // The duration of the current weather.
    private int duration = 0;

    /**
     * Create a weather manager.
     *
     * @param timeManager The time manager of the simulation.
     */
    public WeatherManager(TimeManager timeManager) {
        this.timeManager = timeManager;
        setWeather();
    }

    /**
     * Update the weather manager.
     */
    public void updateWeather() {
        duration--;
        if (duration == 0)
            setWeather();
    }

    /**
     * Set the weather and determine it's duration.
     */
    public void setWeather() {
        duration = Randomizer.getRandom().nextInt(10) + 1;
        boolean ok = false;
        while (!ok) {
            ok = true;
            weather = Weather.values()[Randomizer.getRandom().nextInt(Weather.values().length)];
            if (weather == Weather.SNOWING && timeManager.getSeason() != TimeManager.Season.WINTER)
                ok = false;
            if (weather == Weather.DROUGHT && timeManager.getSeason() != TimeManager.Season.SUMMER)
                ok = false;
        }
    }

    /**
     * Return the current weather.
     *
     * @return The current weather.
     */
    public Weather getWeather() {
        return weather;
    }
}