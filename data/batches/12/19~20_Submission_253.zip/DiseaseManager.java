/**
 * Provide a disease manager for keeping track of
 * diseases in the simulation.
 *
 * @version 2020.02.10
 */

import java.util.List;
import java.util.Random;

public class DiseaseManager {
    // A shared random number generator to control disease.
    private static final Random rand = Randomizer.getRandom();

    // Different types of disease.
    public enum Disease {FLU, POX, POLIO}

    // The likelihood of flu appearing.
    public static final double FLU_APPEARING_PROBABILITY = 0.08;
    // The likelihood of flu spreading.
    public static final double FLU_SPREADING_PROBABILITY = 0.01;
    // The maximum number of steps an animal who contracted flu can go.
    public static final int FLU_SEVERITY = 5;
    // The likelihood of pox appearing.
    public static final double POX_APPEARING_PROBABILITY = 0.08;
    // The likelihood of pox spreading.
    public static final double POX_SPREADING_PROBABILITY = 0.01;
    // The maximum number of steps an animal who contracted pox can go.
    public static final int POX_SEVERITY = 5;
    // The likelihood of polio appearing.
    public static final double POLIO_APPEARING_PROBABILITY = 0.08;
    // The likelihood of polio spreading.
    public static final double POLIO_SPREADING_PROBABILITY = 0.01;
    // The maximum number of steps an animal who contracted polio can go.
    public static final int POLIO_SEVERITY = 5;

    /**
     * Create a disease manager.
     */
    public DiseaseManager() {

    }

    /**
     * Create diseases.
     */
    public void createDiseases(List<Organism> organisms) {
        for (Organism organism : organisms) {
            if (organism instanceof Animal) {
                Animal animal = (Animal) organism;
                if (rand.nextDouble() <= FLU_APPEARING_PROBABILITY)
                    animal.addDisease(Disease.FLU, FLU_SEVERITY);
                if (rand.nextDouble() <= POX_APPEARING_PROBABILITY)
                    animal.addDisease(Disease.POX, POX_SEVERITY);
                if (rand.nextDouble() <= POLIO_APPEARING_PROBABILITY)
                    animal.addDisease(Disease.POLIO, POLIO_SEVERITY);
            }
        }
    }
}
