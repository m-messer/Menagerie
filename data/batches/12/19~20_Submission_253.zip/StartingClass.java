/**
 * Starting class of the simulation.
 *
 * @version 2020.02.10
 */

public class StartingClass {

    public static void main(String[] args){
        Simulator simulator = new Simulator();
        simulator.runLongSimulation();
    }
}