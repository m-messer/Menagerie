/**
 * A simple model of a grass.
 * Grasses age, spread, and die.
 *
 * @version 2020.02.10
 */

import java.util.List;
import java.util.Random;

public class Grass extends Plant {
    // Characteristics shared by all grasses (class variables).
    // The age at which a grass can start to spread.
    private static final int SPREAD_AGE = 5;
    // The age to which a grass can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a grass spreading.
    private static final double SPREADING_PROBABILITY = 0.075;
    // The maximum number of newly created grasses.
    private static final int MAX_LITTER_SIZE = 4;
    // The number of steps a grass can go before it needs water again.
    private static final int WATER_CAPACITY = 9;
    // A shared random number generator to control spreading.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The grass' age.
    private int age;
    // The grass' water level, which is increased during rain.
    private int waterLevel;

    /**
     * Create a grass. A grass can be created as new (age zero
     * and not hungry) or with a random age and water level.
     *
     * @param randomAge If true, the grass will have a random age and water level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            waterLevel = rand.nextInt(WATER_CAPACITY);
        } else {
            age = 0;
            waterLevel = WATER_CAPACITY;
        }
    }

    /**
     * This is what the grass does most of the time: it looks for
     * water and spreads. In the process, it might spread, die of thirst,
     * die of old age, or be eaten.
     *
     * @param newGrasses A list to return newly created grasses.
     */
    @Override
    public void act(List<Organism> newGrasses, TimeManager timeManager, WeatherManager weatherManager) {
        incrementAge();
        incrementThirst();
        if (isAlive()) {
            createNewPlants(newGrasses);
            if (weatherManager.getWeather() == WeatherManager.Weather.RAINING) {
                waterLevel = Math.min(waterLevel + 1, WATER_CAPACITY);
            }
            if (getField().freeAdjacentLocation(getLocation()) == null) {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the grass' death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this grass more thirsty. This could result in the grass' death.
     */
    private void incrementThirst() {
        waterLevel--;
        if (waterLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this grass is to spread at this step.
     * Newly created grasses will be made into free adjacent locations.
     *
     * @param newGrasses A list to return newly born grasses.
     */
    private void createNewPlants(List<Organism> newGrasses) {
        // New grasses are created into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int newGrassesCount = spread();
        for (int b = 0; b < newGrassesCount && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrasses.add(young);
        }
    }

    /**
     * Generate a number representing the number of
     * newly created plants, if it can spread.
     *
     * @return The number of new grasses (may be zero).
     */
    private int spread() {
        int newGrassesCount = 0;
        if (canSpread() && rand.nextDouble() <= SPREADING_PROBABILITY) {
            newGrassesCount = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return newGrassesCount;
    }

    /**
     * A grass can spread if it has reached the spreading age.
     *
     * @return true if the grass can spread, false otherwise.
     */
    private boolean canSpread() {
        return age >= SPREAD_AGE;
    }
}
