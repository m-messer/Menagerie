/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing jaguars, wolves and bears as predators,
 * raccoons, beavers, squirrels, owls and deer as prey
 * and grasses, fruits and ferns to be eaten by prey animals.
 * Time, weather and diseases affect the behaviour of the
 * organisms in the simulation.
 *
 * @version 2020.02.10
 */

import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 220;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;

    // The probability that a jaguar will be created in any given grid position.
    private static final double JAGUAR_CREATION_PROBABILITY = 0.02;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.025;
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.03;

    // The probability that a raccoon will be created in any given grid position.
    private static final double RACCOON_CREATION_PROBABILITY = 0.07;
    // The probability that a beaver will be created in any given grid position.
    private static final double BEAVER_CREATION_PROBABILITY = 0.075;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.08;
    // The probability that an owl will be created in any given grid position.
    private static final double OWL_CREATION_PROBABILITY = 0.085;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.09;

    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.07;
    // The probability that a fruit will be created in any given grid position.
    private static final double FRUIT_CREATION_PROBABILITY = 0.075;
    // The probability that a fern will be created in any given grid position.
    private static final double FERN_CREATION_PROBABILITY = 0.085;

    // List of organism in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    // Manager for time in the simulation.
    private TimeManager timeManager;
    // Manager for weather in the simulation
    private WeatherManager weatherManager;
    // Manager for disease in the simulation.
    private DiseaseManager diseaseManager;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        view.setColor(Jaguar.class, Color.BLUE);
        view.setColor(Wolf.class, Color.LIGHT_GRAY);
        view.setColor(Bear.class, Color.CYAN);

        view.setColor(Raccoon.class, Color.ORANGE);
        view.setColor(Beaver.class, Color.RED);
        view.setColor(Squirrel.class, Color.PINK);
        view.setColor(Owl.class, Color.MAGENTA);
        view.setColor(Deer.class, Color.YELLOW);

        view.setColor(Grass.class, new Color(0, 204, 0));
        view.setColor(Fruit.class, new Color(0, 153, 0));
        view.setColor(Fern.class, new Color(0, 102, 0));

        timeManager = new TimeManager();
        weatherManager = new WeatherManager(timeManager);
        diseaseManager = new DiseaseManager();

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
//            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each organism.
     */
    public void simulateOneStep() {
        step++;

        timeManager.incrementHour();
        weatherManager.updateWeather();
        diseaseManager.createDiseases(organisms);

        // Provide space for newly created organisms.
        List<Organism> newOrganisms = new ArrayList<>();
        // Let all organisms act.
        for (Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms, timeManager, weatherManager);
            if (!organism.isAlive()) {
                it.remove();
            }
        }

        // Add the newly created organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with organisms.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= JAGUAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Jaguar jaguar = new Jaguar(true, field, location);
                    organisms.add(jaguar);
                } else if (rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    organisms.add(wolf);
                } else if (rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, field, location);
                    organisms.add(bear);
                } else if (rand.nextDouble() <= RACCOON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Raccoon raccoon = new Raccoon(true, field, location);
                    organisms.add(raccoon);
                } else if (rand.nextDouble() <= BEAVER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Beaver beaver = new Beaver(true, field, location);
                    organisms.add(beaver);
                } else if (rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    organisms.add(squirrel);
                } else if (rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    organisms.add(owl);
                } else if (rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    organisms.add(deer);
                } else if (rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    organisms.add(grass);
                } else if (rand.nextDouble() <= FRUIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fruit fruit = new Fruit(true, field, location);
                    organisms.add(fruit);
                } else if (rand.nextDouble() <= FERN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fern fern = new Fern(true, field, location);
                    organisms.add(fern);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
