/**
 * A class representing shared characteristics of plants.
 *
 * @version 2020.02.10
 */

public abstract class Plant extends Organism {

    /**
     * Create a new plant at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location) {
        super(field, location);
    }
}
