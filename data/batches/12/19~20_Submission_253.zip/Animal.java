/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.10
 */

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public abstract class Animal extends Organism {
    // Whether the animal is a female or not.
    private boolean female;
    // Diseases the animal has contracted.
    private Set<DiseaseManager.Disease> diseases;
    // The progress of each disease.
    private HashMap<DiseaseManager.Disease, Integer> diseasesProgress;

    /**
     * Create a new animal at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        super(field, location);
        female = Randomizer.getRandom().nextBoolean();
        diseases = new HashSet<>();
        diseasesProgress = new HashMap<>();
    }

    /**
     * Check whether the animal is a female or not.
     *
     * @return true if the animal is a female.
     */
    protected boolean isFemale() {
        return female;
    }

    /**
     * Add a disease the animal has contracted.
     *
     * @param disease  Disease the animal has contracted.
     * @param daysLeft How many days the animal which contracted the disease has left.
     */
    public void addDisease(DiseaseManager.Disease disease, int daysLeft) {
        if (!diseases.contains(disease)) {
            diseases.add(disease);
            diseasesProgress.put(disease, daysLeft);
        }
    }

    /**
     * Update the animal's diseases and spread them to nearby animals.
     */
    protected void updateDiseases() {
        // Update diseases progress.
        for (DiseaseManager.Disease disease : diseases) {
            int diseaseProgress = diseasesProgress.get(disease) - 1;
            diseasesProgress.put(disease, diseaseProgress);
            if (diseaseProgress == 0)
                setDead();
        }
        // Spread the diseases to nearby animals.
        Field field = getField();
        if (field != null) {
            for (Location location : field.adjacentLocations(getLocation()))
                if (field.getObjectAt(location) instanceof Animal) {
                    if (diseases.contains(DiseaseManager.Disease.FLU) && Randomizer.getRandom().nextDouble() <=
                            DiseaseManager.FLU_SPREADING_PROBABILITY)
                        ((Animal) field.getObjectAt(location)).addDisease(DiseaseManager.Disease.FLU, DiseaseManager.FLU_SEVERITY);
                    if (diseases.contains(DiseaseManager.Disease.POX) && Randomizer.getRandom().nextDouble() <=
                            DiseaseManager.POX_SPREADING_PROBABILITY)
                        ((Animal) field.getObjectAt(location)).addDisease(DiseaseManager.Disease.POX, DiseaseManager.POX_SEVERITY);
                    if (diseases.contains(DiseaseManager.Disease.POLIO) && Randomizer.getRandom().nextDouble() <=
                            DiseaseManager.POLIO_SPREADING_PROBABILITY)
                        ((Animal) field.getObjectAt(location)).addDisease(DiseaseManager.Disease.POLIO, DiseaseManager.POLIO_SEVERITY);
                }
        }
    }
}
