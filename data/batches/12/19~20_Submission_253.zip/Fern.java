/**
 * A simple model of a fern.
 * Ferns age, spread, and die.
 *
 * @version 2020.02.10
 */

import java.util.List;
import java.util.Random;

public class Fern extends Plant {
    // Characteristics shared by all ferns (class variables).
    // The age at which a fern can start to spread.
    private static final int SPREAD_AGE = 5;
    // The age to which a fern can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a fern spreading.
    private static final double SPREADING_PROBABILITY = 0.12;
    // The maximum number of newly created ferns.
    private static final int MAX_LITTER_SIZE = 4;
    // The number of steps a fern can go before it needs water again.
    private static final int WATER_CAPACITY = 9;
    // A shared random number generator to control spreading.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The fern's age.
    private int age;
    // The fern's water level, which is increased during rain.
    private int waterLevel;

    /**
     * Create a fern. A fern can be created as new (age zero
     * and not hungry) or with a random age and water level.
     *
     * @param randomAge If true, the fern will have a random age and water level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Fern(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            waterLevel = rand.nextInt(WATER_CAPACITY);
        } else {
            age = 0;
            waterLevel = WATER_CAPACITY;
        }
    }

    /**
     * This is what the fern does most of the time: it looks for
     * water and spreads. In the process, it might spread, die of thirst,
     * die of old age, or be eaten.
     *
     * @param newFerns A list to return newly created ferns.
     */
    @Override
    public void act(List<Organism> newFerns, TimeManager timeManager, WeatherManager weatherManager) {
        incrementAge();
        incrementThirst();
        if (isAlive()) {
            createNewPlants(newFerns);
            if (weatherManager.getWeather() == WeatherManager.Weather.RAINING)
                waterLevel = Math.min(waterLevel + 1, WATER_CAPACITY);
        }
    }

    /**
     * Increase the age. This could result in the fern's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this fern more thirsty. This could result in the fern's death.
     */
    private void incrementThirst() {
        waterLevel--;
        if (waterLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this fern is to spread at this step.
     * Newly created ferns will be made into free adjacent locations.
     *
     * @param newFerns A list to return newly born ferns.
     */
    private void createNewPlants(List<Organism> newFerns) {
        // New ferns are created into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int newFernsCount = spread();
        for (int b = 0; b < newFernsCount && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fern young = new Fern(false, field, loc);
            newFerns.add(young);
        }
    }

    /**
     * Generate a number representing the number of
     * newly created plants, if it can spread.
     *
     * @return The number of new ferns (may be zero).
     */
    private int spread() {
        int newFernsCount = 0;
        if (canSpread() && rand.nextDouble() <= SPREADING_PROBABILITY) {
            newFernsCount = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return newFernsCount;
    }

    /**
     * A fern can spread if it has reached the spreading age.
     *
     * @return true if the fern can spread, false otherwise.
     */
    private boolean canSpread() {
        return age >= SPREAD_AGE;
    }
}
