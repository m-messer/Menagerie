/**
 * A simple model of a fruit.
 * Fruits age, spread, and die.
 *
 * @version 2020.02.10
 */

import java.util.List;
import java.util.Random;

public class Fruit extends Plant {
    // Characteristics shared by all fruits (class variables).
    // The age at which a fruit can start to spread.
    private static final int SPREAD_AGE = 5;
    // The age to which a fruit can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a fruit spreading.
    private static final double SPREADING_PROBABILITY = 0.12;
    // The maximum number of newly created fruits.
    private static final int MAX_LITTER_SIZE = 4;
    // The number of steps a fruit can go before it needs water again.
    private static final int WATER_CAPACITY = 9;
    // A shared random number generator to control spreading.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The fruit's age.
    private int age;
    // The fruit's water level, which is increased during rain.
    private int waterLevel;

    /**
     * Create a fruit. A fruit can be created as new (age zero
     * and not hungry) or with a random age and water level.
     *
     * @param randomAge If true, the fruit will have a random age and water level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Fruit(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            waterLevel = rand.nextInt(WATER_CAPACITY);
        } else {
            age = 0;
            waterLevel = WATER_CAPACITY;
        }
    }

    /**
     * This is what the fruit does most of the time: it looks for
     * water and spreads. In the process, it might spread, die of thirst,
     * die of old age, or be eaten.
     *
     * @param newFruits A list to return newly created fruits.
     */
    @Override
    public void act(List<Organism> newFruits, TimeManager timeManager, WeatherManager weatherManager) {
        incrementAge();
        incrementThirst();
        if (isAlive()) {
            createNewPlants(newFruits);
            if (weatherManager.getWeather() == WeatherManager.Weather.RAINING)
                waterLevel = Math.min(waterLevel + 1, WATER_CAPACITY);
        }
    }

    /**
     * Increase the age. This could result in the fruit's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this fruit more thirsty. This could result in the fruit's death.
     */
    private void incrementThirst() {
        waterLevel--;
        if (waterLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this fruit is to spread at this step.
     * Newly created fruits will be made into free adjacent locations.
     *
     * @param newFruits A list to return newly born fruits.
     */
    private void createNewPlants(List<Organism> newFruits) {
        // New fruits are created into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int newFruitsCount = spread();
        for (int b = 0; b < newFruitsCount && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fruit young = new Fruit(false, field, loc);
            newFruits.add(young);
        }
    }

    /**
     * Generate a number representing the number of
     * newly created plants, if it can spread.
     *
     * @return The number of new fruits (may be zero).
     */
    private int spread() {
        int newFruitsCount = 0;
        if (canSpread() && rand.nextDouble() <= SPREADING_PROBABILITY) {
            newFruitsCount = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return newFruitsCount;
    }

    /**
     * A fruit can spread if it has reached the spreading age.
     *
     * @return true if the fruit can spread, false otherwise.
     */
    private boolean canSpread() {
        return age >= SPREAD_AGE;
    }
}
