/**
 * A simple model of a jaguar.
 * Jaguars age, move, breed, eat raccoons, beavers and squirrels, and die.
 *
 * @version 2020.02.10
 */

import java.util.List;
import java.util.Iterator;
import java.util.Random;

public class Jaguar extends Animal {
    // Characteristics shared by all jaguars (class variables).
    // The age at which a jaguar can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a jaguar can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a jaguar breeding.
    private static final double BREEDING_PROBABILITY = 0.03;
    // The radius in which a jaguar can breed.
    private static final int BREEDING_RADIUS = 5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The number of steps a jaguar can go before it has to eat again.
    private static final int FOOD_CAPACITY = 20;
    // The food value of a single raccoon.
    private static final int RACCOON_FOOD_VALUE = 20;
    // The food value of a single beaver.
    private static final int BEAVER_FOOD_VALUE = 20;
    // The food value of a single squirrel.
    private static final int SQUIRREL_FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The jaguar's age.
    private int age;
    // The jaguar's food level, which is increased by eating raccoons, beavers and squirrels.
    private int foodLevel;

    /**
     * Create a jaguar. A jaguar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the jaguar will have a random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Jaguar(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_CAPACITY);
        } else {
            age = 0;
            foodLevel = FOOD_CAPACITY;
        }
    }

    /**
     * This is what the jaguar does most of the time: it hunts for
     * raccoons, beavers and squirrels. In the process, it might breed,
     * die of hunger, or die of old age.
     *
     * @param newJaguars A list to return newly born jaguars.
     */
    @Override
    public void act(List<Organism> newJaguars, TimeManager timeManager, WeatherManager weatherManager) {
        incrementAge();
        incrementHunger();
        updateDiseases();
        if (isAlive() && timeManager.isDaytime()) {
            giveBirth(newJaguars);
            // Move towards a source of food if found.
            Location newLocation = null;
            if (weatherManager.getWeather() != WeatherManager.Weather.FOG)
                newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the jaguar's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this jaguar more hungry. This could result in the jaguar's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for raccoons, beavers and squirrels adjacent to the current location.
     * Only the first live animal is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if (organism instanceof Raccoon) {
                Raccoon raccoon = (Raccoon) organism;
                if (raccoon.isAlive()) {
                    raccoon.setDead();
                    foodLevel = Math.min(foodLevel + RACCOON_FOOD_VALUE, FOOD_CAPACITY);
                    return where;
                }
            }
            if (organism instanceof Beaver) {
                Beaver beaver = (Beaver) organism;
                if (beaver.isAlive()) {
                    beaver.setDead();
                    foodLevel = Math.min(foodLevel + BEAVER_FOOD_VALUE, FOOD_CAPACITY);
                    return where;
                }
            }
            if (organism instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) organism;
                if (squirrel.isAlive()) {
                    squirrel.setDead();
                    foodLevel = Math.min(foodLevel + SQUIRREL_FOOD_VALUE, FOOD_CAPACITY);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this jaguar is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newJaguars A list to return newly born jaguars.
     */
    private void giveBirth(List<Organism> newJaguars) {
        // New jaguars are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Jaguar young = new Jaguar(false, field, loc);
            newJaguars.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A female jaguar can breed if it has reached the breeding age
     * and has a male partner of breeding age within the breeding radius.
     *
     * @return true if the jaguar can breed.
     */
    private boolean canBreed() {
        if (!isFemale() || !hasBreedingAge()) return false;
        Field field = getField();
        for (int x = getLocation().getRow() - BREEDING_RADIUS + 1; x < getLocation().getRow() + BREEDING_RADIUS - 1; x++)
            for (int y = getLocation().getCol() - BREEDING_RADIUS + 1; y < getLocation().getCol() + BREEDING_RADIUS - 1; y++)
                if ((x >= 0 && x < field.getDepth() && y >= 0 && y < field.getWidth()) && field.getObjectAt(x, y) instanceof Jaguar &&
                        !((Jaguar) field.getObjectAt(x, y)).isFemale() && ((Jaguar) field.getObjectAt(x, y)).hasBreedingAge())
                    return true;
        return false;
    }

    /**
     * Check whether the jaguar has reached the breeding age.
     *
     * @return true if the jaguar has reached the breeding age.
     */
    protected boolean hasBreedingAge() {
        return age >= BREEDING_AGE;
    }
}
