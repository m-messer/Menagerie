/**
 * Provide a time manager for keeping track of
 * elapsed time in the simulation. A day is two hours long
 * and there are four seasons, each lasting 10 days.
 *
 * @version 2020.02.10
 */

 

public class TimeManager {
    // Different types of seasons.
    public enum Season {WINTER, SPRING, SUMMER, AUTUMN}

    // Current hour and day.
    private int hour, day;

    /**
     * Create a time manager starting on hour 0 and day 0.
     */
    public TimeManager() {
        this(0, 0);
    }

    /**
     * Create a time manager starting on a custom hour and day.
     *
     * @param hour The starting hour for the timer.
     * @param day  The starting day for the timer.
     */
    public TimeManager(int hour, int day) {
        // If the hour is invalid it gets set to 0.
        if (hour < 0 || hour > 1) hour = 0;
        // If the day is invalid it gets set to 0.
        if (day < 0) day = 0;
        this.hour = hour;
        this.day = day;
    }

    /**
     * Increment the timer's hour and keep track of the day.
     */
    public void incrementHour() {
        hour++;
        if (hour == 2) {
            hour = 0;
            day++;
        }
    }

    /**
     * Determine whether it is daytime.
     *
     * @return true If it is daytime.
     */
    public boolean isDaytime() {
        if (hour % 2 == 0) return true;
        return false;
    }

    /**
     * Return the current season calculated from the day.
     *
     * @return The current season.
     */
    public Season getSeason() {
        switch (day / 10 % 4) {
            case 0:
                return Season.WINTER;
            case 1:
                return Season.SPRING;
            case 2:
                return Season.SUMMER;
            default:
                return Season.AUTUMN;
        }
    }
}
