import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Orca.
 * Orcas age, move, eat antarctic krills, ice krills, and die.
 *
 * @version 2016.02.29 (2)
 * 2021.02.16
 */
public class Orca extends Animal
{
    // Characteristics shared by all Orcas (class variables).

    // The age at which a Orca can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a Orca can live.
    private static int MAX_AGE = 200;
    // The likelihood of a Orca breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // number of steps the animal can go before it has to eat again.
    private static final int SATIETY_LEVEL = 45;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Health status of an orca
    private boolean isSick;

    /**
     * Create a Orca. A Orca can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Orca will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Orca(boolean randomAge, Field field, Location location, boolean isSick)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(SATIETY_LEVEL));
        }
        else {
            setAge(0);
            setFoodLevel(SATIETY_LEVEL);
        }
        this.isSick = isSick;
        if(isSick){
            setMaxAge();
        }
    }

    /**
     * This is what the Orca does most of the time: it hunts for
     * iceKrills. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newOrcas A list to return newly born Orcas.
     */
    public void act(List<Actor> newOrcas)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            getInfected();
            giveBirth(newOrcas);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is to check if any nearby orca is sick,
     * if so then there will be a 20% of chance to be infected.
     */
    private void getInfected(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            if (field.getObjectAt(where) != null && field.getObjectAt(where) instanceof Orca){
                Orca orca = (Orca) field.getObjectAt(where);
                if(orca.getIsSick()){
                    isSick = generateDisease();
                    if (isSick){
                        setMaxAge(); //reduce max age when the orca is sick
                    }
                }
            }
        }
    }

    /**
     * return the health status of the orca
     */
    private boolean getIsSick(){
        return isSick;
    }
    
    /**
     * Look for target adjacent to the current location.
     * Only the first live target is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof IceKrill) {
                IceKrill iceKrill = (IceKrill) animal;
                if(iceKrill.isAlive()) { 
                    iceKrill.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
            if(animal instanceof AntarcticKrill) {
                AntarcticKrill antarcticKrill = (AntarcticKrill) animal;
                if(antarcticKrill.isAlive()) { 
                    antarcticKrill.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
            if(animal instanceof Squid) {
                Squid squid = (Squid) animal;
                if(squid.isAlive()) { 
                    squid.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
            if(animal instanceof ElephantSeal) {
                ElephantSeal elephantSeal = (ElephantSeal) animal;
                if(elephantSeal.isAlive()) { 
                    elephantSeal.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * The probablity of 20% of the orca getting infected by disease.
     */
    private boolean generateDisease()
    {
        int i = rand.nextInt(10);
        return i <= 1;
    }

    /**
     * Create new baby orca.
     */
    protected Animal createAnimal(){
        Orca orca = new Orca(true, getField(), getLocation(), generateDisease());
        return orca;
    }

    /**
     * Get max litter age of the orca.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Get breeding probability of the orca.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Get max age of the orca.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Set new max age for infected orca.
     */
    public void setMaxAge(){
        MAX_AGE = 100;
    }

    /**
     * Get breeding age of the orca.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Get breeding age of the orca.
     */
    public int getSatietyLevel(){
        return SATIETY_LEVEL;
    }
}
