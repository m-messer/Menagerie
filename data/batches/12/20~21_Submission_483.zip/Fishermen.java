import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Fishermen will be generated at a random number at the beginning of the simulation
 * and the number of fishermen will not change,
 * they won't disappear or produce more.
 *
 * @version 2021.02.18 
 */
public class Fishermen implements Actor
{
    private Field field;
    private Location location;
    private static final double FISHERMEN_CREATION_PROBABILITY = 0.002;    
    private static final Random rand = Randomizer.getRandom();
    private boolean active;

    /**
     * Constructor for objects of class Phytoplankton
     */
    public Fishermen(Field field, Location location)
    {
        active = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * This is what the fishermen does most of the time,
     * It goes around the field, and catches animals.
     * @param newphytoplanktons A list to return newly born phytoplanktons.
     */
    public void act(List<Actor> newFishermen)
    {
        if(active){
            Location newLocation = findTarget();
            if(newLocation == null){
                // Try to move into a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
        }
    }

    /**
     * Look for target adjacent to the current location.
     */
    private Location findTarget()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof IceKrill) {
                IceKrill iceKrill = (IceKrill) animal;
                if(iceKrill.isAlive()) { 
                    iceKrill.setDead();
                    return where;
                }
            }
            else if(animal instanceof AntarcticKrill) {
                AntarcticKrill antarcticKrill = (AntarcticKrill) animal;
                if(antarcticKrill.isAlive()) { 
                    antarcticKrill.setDead();
                    return where;
                }
            }
            else if(animal instanceof Squid) {
                Squid squid = (Squid) animal;
                if(squid.isAlive()) { 
                    squid.setDead();
                    return where;
                }
            }
        }
        return null;
    }

    /**
    * Check whether the animal is alive or not.
    */
    public boolean isAlive() 
    {
        return active;
    }

    /**
     * Return the fishermen's location.
     * @return The fishermen's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Place the fishermen at the new location in the given field.
     * @param newLocation The fishermen's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the fishermen's field.
     * @return The fishermen's field.
     */
    public Field getField()
    {
        return field;
    }

    /**
     * The fishermen will not move and find targets during night time, 
     */
    public void notActive(List<Actor> newFishermen)
    {

    }
}
