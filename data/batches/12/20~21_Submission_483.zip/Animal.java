import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 * 2021.02.16
 */
public abstract class Animal implements Actor
{
    private boolean alive; // Whether the animal is alive or not.
    private Field field; // The animal's field.
    private Location location; // The animal's position in the field.

    private static final Random rand = Randomizer.getRandom();
    private boolean isFemale; //gender of animal
    private int age;
    private int foodLevel;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        isFemale = generateGender();
    }


    /**
     * Get max litter age of the animal.
     */
    protected abstract int getMaxLitterSize();

    /**
     * Get breeding probability of the animal.
     */
    protected abstract double getBreedingProbability();

    /**
     * Get max age of the animal.
     */
    protected abstract int getMaxAge();

    /**
     * Get breeding age of the animal.
     */
    protected abstract int getBreedingAge();

    /**
     * Create new animal.
     */
    protected abstract Animal createAnimal();

    /**
     * Get animal satiety level.
     */
    protected abstract int getSatietyLevel();

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newAnimals);

    /**
     * Animals sleep, age and hunger will still increase.
     */
    public void notActive(List<Actor> newAnimals)
    {
        incrementAge();
        incrementHunger();
    }

    /**
     * Create a new animal with the probability of 0.5 to be either male or female.
     */
    private boolean generateGender()
    {
        int i = rand.nextInt(2);
        return i == 0;
    }

    /**
     * Get the gender of animal.
     */
    public boolean getIsFemale()
    {
        return isFemale;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimal A list to return newly born animal.
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newAnimals.add(createAnimal());
        }
    }

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        setAge(getAge() + 1);
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        setFoodLevel(getFoodLevel() - 1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * The animals will breed only if they meet opposite gender of the same species.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        int births = 0;
        while(it.hasNext()) {
            Location where = it.next();
            if (field.getObjectAt(where) != null && field.getObjectAt(where) instanceof Animal){
                Animal animal = (Animal) field.getObjectAt(where);
                if(getClass() == animal.getClass() && getIsFemale() != animal.getIsFemale()){
                    if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
                        births = rand.nextInt(getMaxLitterSize()) + 1;
                    }
                }
            }
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }
    
    /**
     * Set age for animal.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * Return the animal's age.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Set food level for animal.
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }
    
    /**
     * Return the animal's food level.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
}
