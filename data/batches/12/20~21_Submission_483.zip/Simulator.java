import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing iceKrills and penguin.
 *
 * @version 2016.02.29 (2)
 * 2021.02.19
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;

    // The probability that an animal will be created in any given grid position.
    private static final double PENGUIN_CREATION_PROBABILITY = 0.05;
    private static final double ICE_KRILL_CREATION_PROBABILITY = 0.25;    
    private static final double ANTARCTIC_KRILL_CREATION_PROBABILITY = 0.25;    
    private static final double SQUID_CREATION_PROBABILITY = 0.07;
    private static final double ELEPHANT_SEAL_CREATION_PROBABILITY = 0.05;
    private static final double ORCA_CREATION_PROBABILITY = 0.03;
    private static final double PHYTOPLANKTON_CREATION_PROBABILITY = 0.3;
    private static final double FISHERMEN_CREATION_PROBABILITY = 0.01;

    private List<Actor> actors; // List of actors in the field.
    private Field field; // The current state of the field.
    private int step; // The current step of the simulation.
    private SimulatorView view; // A graphical view of the simulation.
    
    // Time during a day, which is divided into 8 steps
    private int time;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(IceKrill.class, Color.RED);
        view.setColor(Penguin.class, Color.BLUE);
        view.setColor(AntarcticKrill.class, Color.ORANGE);
        view.setColor(Squid.class, Color.PINK);
        view.setColor(ElephantSeal.class, Color.GRAY);
        view.setColor(Orca.class, Color.BLACK);
        view.setColor(Phytoplankton.class, Color.GREEN);
        view.setColor (Fishermen.class, Color.MAGENTA);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(500);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of actors.
     */
    public void simulateOneStep()
    {
        step++;
        incrementTime(); //time goes by every step

        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all actor act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            if (actor instanceof Phytoplankton){
                if(!isRaining()){
                    actor.act(newActors); // Phytoplankton act when it's not raining.
                }
                else if (isRaining()){
                    actor.notActive(newActors);
                }
                if(!actor.isAlive()) {
                    it.remove();
                }
            }
            else if (actor instanceof Fishermen){
                if (isMorning() && !isRaining()){
                    actor.act(newActors); //Fishermen act only when it's morning and not raining.
                }
            }
            else if (actor instanceof Animal){
                if (isMorning()){
                    if (actor instanceof Penguin || actor instanceof AntarcticKrill || actor instanceof IceKrill || actor instanceof Orca){
                        actor.act(newActors);
                    }
                    else if (actor instanceof Squid || actor instanceof ElephantSeal){
                        actor.notActive(newActors);
                    }
                }
                else if (!isMorning()){
                    if (actor instanceof Penguin || actor instanceof AntarcticKrill || actor instanceof IceKrill || actor instanceof Orca){
                        actor.notActive(newActors);
                    }
                    else if (actor instanceof Squid || actor instanceof ElephantSeal){
                        actor.act(newActors);
                    }
                }
                if(!actor.isAlive()) {
                    it.remove();
                }
            }
        }

        // Add the newly born actor to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field, time, isRaining());
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        time = 0;
        actors.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, time, isRaining());
    }

    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PENGUIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Penguin penguin = new Penguin(true, field, location);
                    actors.add(penguin);
                }
                else if(rand.nextDouble() <= ICE_KRILL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    IceKrill iceKrill = new IceKrill(true, field, location);
                    actors.add(iceKrill);
                }
                else if(rand.nextDouble() <= ANTARCTIC_KRILL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    AntarcticKrill antarcticKrill = new AntarcticKrill(true, field, location);
                    actors.add(antarcticKrill);
                }
                else if(rand.nextDouble() <= SQUID_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squid squid = new Squid(true, field, location);
                    actors.add(squid);
                }
                else if(rand.nextDouble() <= ELEPHANT_SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    ElephantSeal elephantSeal = new ElephantSeal(true, field, location);
                    actors.add(elephantSeal);
                }
                else if(rand.nextDouble() <= ORCA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Orca orca = new Orca(true, field, location, false); //Initially no orca is sick.
                    actors.add(orca);
                }
                else if(rand.nextDouble() <= PHYTOPLANKTON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Phytoplankton phytoplankton = new Phytoplankton(true, field, location);
                    actors.add(phytoplankton);
                }
                else if(rand.nextDouble() <= FISHERMEN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fishermen fishermen = new Fishermen (field, location);
                    actors.add(fishermen);
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Generate random weather (rainy or sunny).
     * 1 is raining and 0 is sunny
     */
    public boolean isRaining()
    {
        Random rand = Randomizer.getRandom();
        int i = rand.nextInt(2);
        return i == 1; //raining 
    }

    /**
     * Time increases every steps and reset to 0 when it reaches 7.
     */
    public int incrementTime()
    {
        return time = (time + 1) % 8;
    }

    /**
     * There is 8 "hours" in the simulation.
     * 0 to 3 is day time.
     * 4 to 7 is night time.
     */
    protected boolean isMorning()
    {
        return time <= 3;
    }
}
