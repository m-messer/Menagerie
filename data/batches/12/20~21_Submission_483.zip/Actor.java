import java.util.List;

/**
 * 
 *The interfaces to be extented at any class wishing to participate in the simulation.
 * @version 2021.02.18 
 */
public interface Actor
{
    /**
     * Perform the actors behaviour.
     */
    void act (List<Actor> newActors);
    
    /**
     * Is the actor is active?
     */
    boolean isAlive();
    
    /**
     * Actor is not active.
     */
    void notActive (List<Actor> newActors);
}