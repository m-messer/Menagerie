import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Penguin.
 * Penguins age, move, eat antarctic krills, ice krills, and die.
 *
 * @version 2016.02.29 (2)
 * 2021.02.16
 */
public class Penguin extends Animal
{
    // Characteristics shared by all Penguins (class variables).

    // The age at which a Penguin can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a Penguin can live.
    private static final int MAX_AGE = 39;
    // The likelihood of a Penguin breeding.
    private static final double BREEDING_PROBABILITY = 0.19;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // number of steps a Penguin can go before it has to eat again.
    private static final int SATIETY_LEVEL = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Penguin. A Penguin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Penguin will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Penguin(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(SATIETY_LEVEL));
        }
        else {
            setAge(0);
            setFoodLevel(SATIETY_LEVEL);
        }
    }

    /**
     * This is what the Penguin does most of the time:
     * In the process, it might breed, die of hunger, or die of old age.
     * @param field The field currently occupied.
     * @param newPenguins A list to return newly born Penguins.
     */
    public void act(List<Actor> newPenguins)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPenguins);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for target adjacent to the current location.
     * Only the first live target is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof IceKrill) {
                IceKrill iceKrill = (IceKrill) animal;
                if(iceKrill.isAlive()) { 
                    iceKrill.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
            if(animal instanceof AntarcticKrill) {
                AntarcticKrill antarcticKrill = (AntarcticKrill) animal;
                if(antarcticKrill.isAlive()) { 
                    antarcticKrill.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
            if(animal instanceof Squid) {
                Squid squid = (Squid) animal;
                if(squid.isAlive()) { 
                    squid.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Create new baby penguin.
     */
    protected Animal createAnimal(){
        Penguin penguin = new Penguin(true, getField(), getLocation());
        return penguin;
    }

    /**
     * Get max litter age of the penguin.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Get breeding probability of the penguin.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Get max age of the penguin.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Get breeding age of the penguin.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Get breeding age of the penguin.
     */
    public int getSatietyLevel(){
        return SATIETY_LEVEL;
    }
}
