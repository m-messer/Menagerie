import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * Write a description of class Phytoplankton here.
 *
 * @version 2021.02.18 
 */
public class Phytoplankton implements Actor
{
    // Characteristics shared by all phytoplanktons (class variables).

    // The age at which a phytoplankton can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a phytoplankton can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a phytoplankton breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The phytoplankton's age.
    private int age;
    private boolean alive;
    private Field field;
    private Location location;

    /**
     * Constructor for objects of class Phytoplankton
     */
    public Phytoplankton(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the phytoplankton does most of the time 
     * Sometimes it will breed or die of old age.
     * @param newphytoplanktons A list to return newly born phytoplanktons.
     */
    public void act(List<Actor> newPhytoplanktons)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newPhytoplanktons);        
        }
        // Try to move into a free location.
        else{
            // Overcrowding.
            setDead();
        }
    }
    
    /**
     * Check whether the phytoplankton is alive or not.
     */
    public boolean isAlive() 
    {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    public Field getField()
    {
        return field;
    }

    /**
     * Check whether or not this plant is to reproduce at this step.
     * New births will be made into free adjacent locations.
     * @param newphytoplankton A list to return newly born plant.
     */
    private void giveBirth(List<Actor> newPhytoplanktons)
    {
        // New plant are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Phytoplankton young = new Phytoplankton (false, field, loc);
            newPhytoplanktons.add(young);
        }
    }

    /**
     * Increase the age. This could result in the plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * The plant can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * The plant will only increase age and not breed when it's raining.
     * 
     */
    public void notActive (List<Actor> newActors)
    {
        incrementAge();
    }
}
