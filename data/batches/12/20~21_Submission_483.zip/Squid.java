import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Squid.
 * Squids age, move, eat antarctic krills, ice krills, and die.
 * 
 *
 * @version 2016.02.29 (2)
 * 2021.02.16
 */
public class Squid extends Animal
{
    // Characteristics shared by all Squids (class variables).

    // The age at which a Squid can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Squid can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a Squid breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // number of steps the animal can go before it has to eat again.
    private static final int SATIETY_LEVEL = 17;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Squid. A Squid can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Squid will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Squid(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(SATIETY_LEVEL));
        }
        else {
            setAge(0);
            setFoodLevel(SATIETY_LEVEL);
        }
    }

    /**
     * This is what the Squid does most of the time: it hunts for
     * iceKrills. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSquids A list to return newly born Squids.
     */
    public void act(List<Actor> newSquids)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSquids);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for target adjacent to the current location.
     * Only the first live target is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof IceKrill) {
                IceKrill iceKrill = (IceKrill) animal;
                if(iceKrill.isAlive()) { 
                    iceKrill.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
            if(animal instanceof AntarcticKrill) {
                AntarcticKrill antarcticKrill = (AntarcticKrill) animal;
                if(antarcticKrill.isAlive()) { 
                    antarcticKrill.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Create new baby squid.
     */
    protected Animal createAnimal(){
        Squid squid = new Squid(true, getField(), getLocation());
        return squid;
    }

    /**
     * Get max litter age of the squid.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Get breeding probability of the squid.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Get max age of the squid.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Get breeding age of the squid.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Get breeding age of the squid.
     */
    public int getSatietyLevel(){
        return SATIETY_LEVEL;
    }
}
