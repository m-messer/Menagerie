import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a antarcticKrill.
 * AntarcticKrills age, move, breed, and die.
 *
 
 * @version 2016.02.29 (2)
 * 2021.02.16
 */
public class AntarcticKrill extends Animal
{
    // Characteristics shared by all antarcticKrills (class variables).

    // The age at which a antarcticKrill can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a antarcticKrill can live.
    private static final int MAX_AGE = 45;
    // The likelihood of a antarcticKrill breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // number of steps the animal can go before it has to eat again.    
    private static final int SATIETY_LEVEL = 18;

    /**
     * Create a new antarcticKrill. A antarcticKrill may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the antarcticKrill will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public AntarcticKrill(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(SATIETY_LEVEL));
        }
        else {
            setAge(0);
            setFoodLevel(SATIETY_LEVEL);
        }
    }

    /**
     * This is what the antarcticKrill does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newAntarcticKrills A list to return newly born antarcticKrills.
     */
    public void act(List<Actor> newAntarcticKrills)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newAntarcticKrills);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for phytoplankton adjacent to the current location.
     * Only the first live phytoplankton is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Phytoplankton) {
                Phytoplankton phytoplankton = (Phytoplankton) plant;
                if(phytoplankton.isAlive()) { 
                    phytoplankton.setDead();
                    setFoodLevel(SATIETY_LEVEL);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Create new baby antarctic krill.
     */
    protected Animal createAnimal(){
        AntarcticKrill antarcticKrill = new AntarcticKrill(true, getField(), getLocation());
        return antarcticKrill;
    }

    /**
     * Get max litter age of the antarctic krill.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Get breeding probability of the antarctic krill.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Get max age of the antarctic krill.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Get breeding age of the antarctic krill.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Get breeding age of the antarctic krill.
     */
    public int getSatietyLevel(){
        return SATIETY_LEVEL;
    }
}
