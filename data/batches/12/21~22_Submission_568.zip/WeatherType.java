/**
 * Enumeration class WeatherType 
 * Stores the enums for the different weather conditions. 
 *
 * @version 2022.03.02
 */
public enum WeatherType
{
    RAINING,SUNNY,CLOUDY
}
