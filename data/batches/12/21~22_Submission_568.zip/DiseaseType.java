/**
 * Enumeration class DiseaseType
 * Stores the enums for different disease types. 
 *
 * @version 2022.03.02
 */
public enum DiseaseType {
    CONTACT,
    SEXUAL,
    FOODBORNE
}
