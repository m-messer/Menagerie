/**
 * Enumeration class TimesOfDay
 * Stores the enums for day and time. 
 *
 * @version 2022.03.02
 */
public enum TimesOfDay
{
    DAY, NIGHT
}
