import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a killer whale. 
 * killer whale age, move, breed, eat clownfish and cod, and die.
 * It may have disease and influenced by the weather.
 *
 * @version 2016.02.29 (2)
 */
public class KillerWhale extends Predator
{
    // Characteristics shared by all killer whale (class variables).
    private static final double DISEASE_INFECTED_PROBABILITY = 0.01;
    // The age at which a killer whale can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a killer whale can live.
    private static final int MAX_AGE = 180;
    // The likelihood of a killer whale breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single killer whale. In effect, this is the
    // number of steps a killer whale can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    private int age;
    // The killer whale's food level, which is increased by eating clownfish and cod.
    private int foodLevel;
    
    private boolean isFemale;


    /**
     * Create a killer whale. A killer whale can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * The gender of a killer whale is random.
     * 
     * @param randomAge If true, the killer whale will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public KillerWhale(boolean randomAge, Field field, Location location)
     {
        super(field, location);
     
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
        
        if(rand.nextInt(2) == 0){
            isFemale = true;
        }
        else{
            isFemale = false;
        }
    }
    
    /**
     * This is what the killer whale does during the day time: 
     * it hunts for clownfish and cod. In the process, it might breed, die of hunger,
     * die of diease or die of old age.
     * 
     * @param field The field currently occupied.
     * @param newWhales A list to return newly born killer whales.
     */
    public void dayAct(List<Creature> newWhales)
    {
        incrementAge();
        incrementHunger();
        diseaseInfection();
        if(isAlive()) {
            giveBirth(newWhales);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * The killer whale does nothing during the night time. 
     */
    public void nightAct()
    {
        // the Killerwhale do not avt in the night
    }

    /**
     * Increase the age. This could result in the killer whale's death.
     */
    private void incrementAge()
    {
        //age increase automatically
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this killer whale more hungry. This could result in the killer whale's death.
     */
    private void incrementHunger()
    {
        //foodLevel decrease automatically
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for clownfish and cod that are adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        // set the adjacentLocation that excute whether the creature can have food
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Clownfish) {
                Clownfish clownfish = (Clownfish) creature;
                int number = clownfish.adjacentPredatorNumber();
                if(clownfish.isAlive() && number == 1) { 
                    clownfish.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
                else if(clownfish.isAlive() && number > 1){
                    int index = rand.nextInt(number);
                    if(index == 0){
                        clownfish.setDead();
                        foodLevel = FOOD_VALUE;
                        return where;
                    }
                }
            }
            else if(creature instanceof Cod) {
                Cod cod = (Cod) creature;
                if(cod.isAlive()) { 
                    cod.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this killer whale is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWhales A list to return newly born killer whales.
     */
    private void giveBirth(List<Creature> newWhales)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            KillerWhale young = new KillerWhale(false, field, loc);
            newWhales.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        // give the new born to a creature
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A killer whale can breed if it is female, have adjacent 
     * male killer whale and has reached the breeding age.
     * @return If the killer whale can breed
     */
    private boolean canBreed()
    {
        // whether the creatures can 
        if(age >= BREEDING_AGE && isFemale && hasAdjacentMale()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Return the killer whale's gender.
     * @return The killer whale's gender.
     */
    public boolean getIsFemale()
    {
        return isFemale;
    }
    
    /**
     * Return the killer whale's age.
     * @return The killer whale's age.
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * Check if the killer whale has adjacent male killer whale.
     * @return if the killer whale has adjacent male killer whale.
     */
    private boolean hasAdjacentMale()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof KillerWhale) {
                KillerWhale killerWhale = (KillerWhale) creature;
                if(killerWhale.isAlive() && !killerWhale.getIsFemale() && killerWhale.getAge() >= BREEDING_AGE){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check if the killer whale has adjacent disease infected killer whale.
     * @return if the killer whale has adjacent disease infected killer whale.
     */
    private boolean adjacentInfectedKillerWhale()
    {
        Field field = getField();
        if(getLocation() == null) return false;
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof KillerWhale) {
                KillerWhale killerWhale = (KillerWhale) creature;
                if(killerWhale.isAlive() && killerWhale.hasDisease()){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * The killer whale will be infected if it has adjacent killer whale. 
     */
    private void infectedDisease()
    {
        if(adjacentInfectedKillerWhale() && rand.nextDouble() <= DISEASE_INFECTED_PROBABILITY){
            setDisease();
        }
    }
    
    /**
     * Increase the disease level of the infected killer whale
     * or set disease to the killer whale if it will be infected.
     */
    private void diseaseInfection()
    {
        if(hasDisease()){
            incrementDiseaseLevel();
        }
        else{
            infectedDisease();
        }
    }
}
