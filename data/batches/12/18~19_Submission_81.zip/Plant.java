
/**
 * Plant is a subclass of creature.
 *
 * @version (2019.2.21)
 * */
public abstract class Plant extends Creature
{
    
    /**
     * Create a plant.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        
        super(field, location);
    }

    
}
