import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Prey is a subclass of class Creature.
 * prey may have disease.
 *
 * @version (2019.2.21)
 */
public abstract class Prey extends Creature
{
    private static final double DISEASE_PROPABILITY = 0.01;
    private Disease disease;
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a prey.The prey is created as no disease initially.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location)
    {
        super(field, location);
        disease = new Disease(false,0);
        if(rand.nextDouble() <= DISEASE_PROPABILITY){
            disease = new Disease(true,0);
        }
        else{
            disease = new Disease(false,0);
        }
    }
    
    /**
     * Return whether the prey has the disease.
     * @return whether the prey has the disease.
     */
    public boolean hasDisease()
    {
        return disease.getHasDisease();
    }
    
    /**
     * Prey is infected by disease.
     */
    public void setDisease()
    { 
         disease.setDisease();
    }
    
    /**
     * Increase the prey's disease level. 
     */
    public void incrementDiseaseLevel()
    {
        disease.incrementLevel();
        if(disease.isDead()){
            setDead();
        }
    }

    /**
     * Return the number of adjacent predators of the prey.
     * @return The number of adjacent predators of the prey
     */
    public int adjacentPredatorNumber()
    {
        int number = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Object creature = field.getObjectAt(it.next());
            if(creature instanceof KillerWhale){
                number++;
            }
            else if(creature instanceof Dogfish){
                number++;
            }
        }
        return number;
    }
}
