import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a dogfish.
 * dogfish age, move, breed, eat clownfish and lobster, and die.
 * It may have disease and influenced by the weather.
 *
 * @version (2019.2.21)
 */
public class Dogfish extends Predator
{
    // The age at which a Dogfish can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a Dogfish can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a Dogfish breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single dogfish. In effect, this is the
    // number of steps a Dogfish can go before it has to eat again.
    private static final int FOOD_VALUE = 10;
    // the probility that the dogfish can get disease
    private static final double DISEASE_INFECTED_PROBABILITY = 0.01;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    private int age;
    // The Dogfish's food level, which is increased by eating clownfish and cod.
    private int foodLevel;
    // The gender of the dogfish
    private boolean isFemale;
    
    /**
     * Create a dogfish. A dogfish can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * The gender of a dogfish is random.
     * 
     * @param randomAge If true, the dogfish will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Dogfish(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        //set up the age information 
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
        
        if(rand.nextInt(2) == 0){
            isFemale = true;
        }
        else{
            isFemale = false;
        }
    }
    
    /**
     * This is what the dogfish does during the day time: 
     * it hunts for clownfish and lobster. In the process, it might 
     * breed, die of hunger, die of diease or die of old age.
     * 
     * @param field The field currently occupied.
     * @param newDogfish A list to return newly born dogfish.
     */
    public void dayAct(List<Creature> newDogfish)
    {
           // define the age
        incrementAge();
            // define the hunger
        incrementHunger(); 
            // the infection of the disease 
        diseaseInfection();
        if(isAlive()) {
            
            // have the new generation
            giveBirth(newDogfish);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * The killer whale does nothing during the night time.
     */
    public void nightAct()
    {
        // the Dogfish do not act in the night
    }

    /**
     * Increase the age. This could result in the dogfish's death.
     */
    private void incrementAge()
    {
        //increase the age
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    
    /**
     * Make this dogfish more hungry. This could result in the dogfish's death.
     */
    private void incrementHunger()
    {
        // decrease the food level
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    
    /**
     * Look for clownfish and lobster that are adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        // from class Field get the location 
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Clownfish) {
                Clownfish clownfish = (Clownfish) creature;
                int number = clownfish.adjacentPredatorNumber();
                if(clownfish.isAlive() && number == 1) { 
                    clownfish.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
                else if(clownfish.isAlive() && number > 1){
                    int index = rand.nextInt(number);
                    if(index == 0){
                        clownfish.setDead();
                        foodLevel = FOOD_VALUE;
                        return where;
                    }
                }
            }
            else if(creature instanceof Lobster) {
                Lobster lobster = (Lobster) creature;
                if(lobster.isAlive()) { 
                    lobster.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this dogfish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDogfish A list to return newly born dogfish. 
     */
    private void giveBirth(List<Creature> newDogfish)
    {
        // New Dogfish are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Dogfish young = new Dogfish(false, field, loc);
            newDogfish.add(young);
        }
    
    }
    
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A dogfish can breed if it is female, have adjacent 
     * male dogfish and has reached the breeding age.
     * @return If the dogfish can breed.
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE && isFemale && hasAdjacentMale()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Return the dogfish's gender.
     * @return The dogfish's gender.
     */
    public boolean getIsFemale()
    {
        return isFemale;
    }
    
    
    /**
     * Return the dogfish's age.
     * @return The dogfish's age.
     */ 
    public int getAge()
    {
        return age;
    }
    
    /**
     * Check if the dogfish has adjacent male dogfish.
     * @return if the dogfish has adjacent male dogfish.
     */
    private boolean hasAdjacentMale()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Dogfish) {
                Dogfish dogfish = (Dogfish) creature;
                if(dogfish.isAlive() && !dogfish.getIsFemale() && dogfish.getAge() >= BREEDING_AGE){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check if the dogfish has adjacent disease infected dogfish.
     * @return if the dogfish has adjacent disease infected dogfish.
     */
    private boolean adjacentInfectedDogfish(){
        Field field = getField();
        if(getLocation() == null)return false;
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Dogfish) {
                Dogfish dogfish = (Dogfish) creature;
                if(dogfish.isAlive() && dogfish.hasDisease()){
                    return true;
                }
            }
        }

        return false;
    }
    
    
    /**
     * The dogfish will be infected if it has adjacent dogfish. 
     */
    private void infectedDisease()
    {
        if(adjacentInfectedDogfish() && rand.nextDouble() <= DISEASE_INFECTED_PROBABILITY){
            setDisease();
        }
    }
    
    /**
     * Increase the disease level of the infected dogfish
     * or set disease to the dogfish if it will be infected.
     */
    private void diseaseInfection()
    {
        if(hasDisease()){
            incrementDiseaseLevel();
        }
        else{
            infectedDisease();
        }
    }
}
