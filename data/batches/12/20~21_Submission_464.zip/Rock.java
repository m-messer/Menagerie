import java.util.List;

/**
 * This class is for the rock entities which cannot move during the simulation and which
 * animals must traverse around - they cannot go through or over them.
 *
 * @version 2020.02.27 (3)
 */

public class Rock extends Entity {

    public Rock(Field field, Location location) {
        super(field, location);
        this.field = field;
        setLocation(location);
    }

    /**
     * Return the rock's location.
     *
     * @return The rock's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the rock at the new location in the given field.
     *
     * @param newLocation The rock's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location, 1);
        }
        location = newLocation;
        field.placeRock(this, newLocation, 1);
    }

    /**
     * Return the rock's field.
     *
     * @return The rock's field.
     */
    protected Field getField() {
        return field;
    }
}
