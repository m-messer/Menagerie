import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.27 (3)
 */
public abstract class Animal extends Entity {
    // Whether the animal is alive or not.
    private boolean alive;
    // Whether the animal is female or not.
    protected boolean isFemale;

    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        super(field, location);
        alive = true;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newAnimals A list to receive newly born animals.
     * @param night    Whether it is day or night
     * @param night    Whether it is day or night
     * @param fog      Whether it is foggy or not
     */
    abstract public void act(List<Animal> newAnimals, Boolean night, Boolean fog);

    /**
     * Check whether the animal is alive or not.
     *
     * @return true if the animal is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the animal at the new location in the given field.
     *
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Check if the animal is female or not
     *
     * @return true if the animal is female
     */
    protected boolean getIsFemale() {
        return isFemale;
    }
}
