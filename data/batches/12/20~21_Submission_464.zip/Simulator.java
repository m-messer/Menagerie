import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits, foxes, bears, deer and frogs.
 *
 * @version 2020.02.27 (3)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 110;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.03;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.1;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.05;
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.02;
    // The probability that a frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.1;
    // The probability that a rock will be created in any given grid position.
    private static final double ROCK_CREATION_PROBABILITY = 0.005;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // List of entities in the field.
    private List<Entity> entities;
    // List of rabbits in the field.
    private List<Rabbit> rabbits;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        entities = new ArrayList<>();
        rabbits = new ArrayList();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.PINK);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Bear.class, Color.RED);
        view.setColor(Deer.class, Color.YELLOW);
        view.setColor(Frog.class, Color.GREEN);
        view.setColor(Rock.class, Color.GRAY);

        // Setup a valid starting point.
        reset(false);
    }

    public static void main(String[] args) {
        Simulator sim = new Simulator(0, 0);
        sim.runLongSimulation();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(100);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            //boolean fogDay = rand.nextBoolean();
            boolean fogDay;
            boolean fogNight;

            int randomNum = rand.nextInt((10 - 1) + 1) + 1;
            fogDay = randomNum < 2;
            for (int i = 0; i < 3; i++) {
                simulateOneStepDay(fogDay);
                delay(60);   // uncomment this to run more slowly
            }
            fogDay = false;
            for (int i = 0; i < 7; i++) {
                simulateOneStepDay(fogDay);
                delay(60);   // uncomment this to run more slowly
            }

            randomNum = rand.nextInt((10 - 1) + 1) + 1;
            fogNight = randomNum < 2;
            for (int i = 0; i < 3; i++) {
                simulateOneStepNight(fogNight);
                delay(60);   // uncomment this to run more slowly
            }
            fogNight = false;
            for (int i = 0; i < 27; i++) {
                simulateOneStepNight(fogNight);
                delay(60);   // uncomment this to run more slowly
            }
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStepDay(Boolean fog) {
        step++;

        //boolean fog = rand.nextBoolean();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Let all rabbits act.
        for (Iterator<Entity> it = entities.iterator(); it.hasNext(); ) {
            Entity animal = it.next();
            if (animal instanceof Animal) {
                ((Animal) animal).act(newAnimals, false, fog);
                if (!((Animal) animal).isAlive()) {
                    it.remove();
                }
            }
        }
        // Add the newly born animals to the main lists.
        entities.addAll(newAnimals);
        view.showStatusDay(step, field, fog);
    }

    public void simulateOneStepNight(Boolean fog) {
        step++;

        //boolean fog = rand.nextBoolean();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Let all rabbits act.
        for (Iterator<Entity> it = entities.iterator(); it.hasNext(); ) {
            Entity animal = it.next();
            if (animal instanceof Animal) {
                ((Animal) animal).act(newAnimals, true, fog);
                if (!((Animal) animal).isAlive()) {
                    it.remove();
                }
            }
        }
        // Add the newly born animals to the main lists.
        entities.addAll(newAnimals);
        view.showStatusNight(step, field, fog);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset(Boolean fog) {
        step = 0;
        entities.clear();
        populate();

        fog = false;

        // Show the starting state in the view.
        view.showStatusDay(step, field, fog);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= ROCK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rock rock = new Rock(field, location);
                    entities.add(rock);
                } else if (rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    entities.add(fox);
                } else if (rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    entities.add(rabbit);
                } else if (rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    entities.add(deer);
                } else if (rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, field, location);
                    entities.add(bear);
                } else if (rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    entities.add(frog);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
