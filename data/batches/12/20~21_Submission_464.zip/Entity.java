/**
 *
 * This class holds all entities that can be present in the simulation
 * including animals and rocks.
 *
 * @version 2020.02.27 (3)
 */

public abstract class Entity {

    // The entity's field.
    protected Field field;
    // The entity's position in the field.
    protected Location location;

    public Entity(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }


    /**
     * Return the entity's location.
     * @return The entity's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    protected abstract void setLocation(Location newLocation);

    /**
     * Return the entity's field.
     * @return The entity's field.
     */
    protected Field getField()
    {
        return field;
    }
}
