import java.util.List;
import java.util.Random;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 02.03.2022
 */
public class Rabbit extends Animal {
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 5;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    //The value which will be added to the predator's food level upon consumption.
    private static final int FOOD_VALUE = 9;
    //The diet of the rabbit, which consists only of plants.
    private static final Class[] DIET = new Class[]{Plant.class};
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a newborn) or with a random age.
     *
     * @param randomAge If true, the rabbit will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, DIET, FOOD_VALUE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
    }

    /**
     * This is what the rabbit does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * On occasion, it will also create new disease and infect other rabbits.
     *
     *
     * @param newRabbits A list to return newly born rabbits.
     * @param sunny Whether it is sunny
     * @param raining Whether it is raining
     */
    public void act(List<Wildlife> newRabbits, boolean sunny, boolean raining) {
        incrementAge();
        incrementHunger();


        if (isAlive()) {
            giveBirth(newRabbits);

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            // May random create a new disease.
            if (rand.nextDouble() <= getDiseaseCreationPossibility()) {
                createDisease();
            }
            // If the rabbit is diseased, it can infect other animals.
            infect();

            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newRabbits A list to return newly born rabbits.
     */
    private void giveBirth(List<Wildlife> newRabbits) {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rabbit young = new Rabbit(false, field, loc);
            newRabbits.add(young);
        }
    }


}
