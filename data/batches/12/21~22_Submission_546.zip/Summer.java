/**
 * A basic representation of summer.
 * The days are long and sunny; it rarely rains.
 *
 * @version 02.03.2022
 */
public class Summer implements Season {
    private static double chanceOfSun = 0.7;
    private static double chanceOfRain = 0.2;
    private static int dayLength = 14;
    private static double averageTemperature = 20;
    private static String name = "Summer";

    public Summer() {
    }

    public double getChanceOfSun() {
        return chanceOfSun;
    }

    public double getChanceOfRain() {
        return chanceOfRain;
    }

    public int getDayLength() {
        return dayLength;
    }

    public String getName() {
        return name;
    }

    public Season nextSeason() {
        return new Autumn();
    }

}
