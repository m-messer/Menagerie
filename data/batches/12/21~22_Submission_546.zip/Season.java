/**
 * This  interface represents a generic season, which aer distinguished by
 * their likelihood to generate weather phenomena, such as sun and rain.
 * The length of days also varies.
 *
 * @version 02.03.2022
 */
public interface Season {
    /**
     * @return The chances that it will be sunny
     */
    double getChanceOfSun();

    /**
     * @return The chance that it will rain
     */
    double getChanceOfRain();

    /**
     * @return The length of days during that season
     */
    int getDayLength();

    /**
     * @return The name of the season
     */
    String getName();

    /**
     * @return The following season
     */
    Season nextSeason();
}
