/**
 * A basic representation of spring.
 * The days are medium length and the weather is mild.
 *
 * @version 02.03.2022
 */
public class Spring implements Season {
    private static double chanceOfSun = 0.7;
    private static double chanceOfRain = 0.2;
    private static int dayLength = 14;
    private static double averageTemperature = 20;
    private static String name = "Spring";

    public Spring() {
    }

    public double getChanceOfSun() {
        return chanceOfSun;
    }

    public double getChanceOfRain() {
        return chanceOfRain;
    }

    public int getDayLength() {
        return dayLength;
    }

    public double getAverageTemperature() {
        return averageTemperature;
    }

    public String getName() {
        return name;
    }

    public Season nextSeason() {
        return new Summer();
    }

}
