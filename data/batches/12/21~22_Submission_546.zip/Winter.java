/**
 * A basic representation of winter.
 * The days are short and rainy; the sun rarely shines.
 *
 * @version 02.03.2022
 */
public class Winter implements Season {
    private static double chanceOfSun = 0.2;
    private static double chanceOfRain = 0.6;
    private static int dayLength = 8;
    private static double averageTemperature = 5;
    private static String name = "Winter";

    public Winter() {
    }

    public double getChanceOfSun() {
        return chanceOfSun;
    }

    public double getChanceOfRain() {
        return chanceOfRain;
    }

    public int getDayLength() {
        return dayLength;
    }

    public double getAverageTemperature() {
        return averageTemperature;
    }

    public String getName() {
        return name;
    }

    public Season nextSeason() {
        return new Spring();
    }
}
