import java.util.List;
import java.util.Random;

/**
 * A simple model of a plant.
 * Plants grow when it is sunny. They die if it doesn't rain enough.
 *
 * @version 02.03.2022
 */
public class Plant extends Wildlife {
    // The amount of water a new plant start off with.
    private int waterLevel;
    // Whether a plant is poisonous.
    private final boolean poisonous;
    // The chance that the plant will grow.
    private static double SPAWNING_PROBABILITY = 0.05;
    // The value of the plant to the rabbit who eats it.
    private static final int FOOD_VALUE = 1;

    private static Random rand = Randomizer.getRandom();

    /**
     * Create a new Plant, which may be poisonous.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location) {
        super(field, location, FOOD_VALUE);
        this.waterLevel = 100;
        poisonous = rand.nextDouble() < 0.02;
    }

    /**
     * @return Whether the plant is poisonous
     */
    public boolean isPoisonous() {
        return poisonous;
    }

    /**
     * This is what the plant will do most of the time, depending on the whether
     *
     * @param newPlants A list to hold the new plants
     * @param sunny     Whether it is sunny
     * @param raining   Whether it is raining
     */
    public void act(List<Wildlife> newPlants, boolean sunny, boolean raining) {
        // New plants are spawned into adjacent locations.
        // Get a list of adjacent free locations.

        Field field = getField();
        if (sunny) { //plants will only grow if it is sunny outside
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int spawns = rand.nextInt(2);
            if (rand.nextDouble() < SPAWNING_PROBABILITY)
                for (int b = 0; b < spawns && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    Plant newPlant = new Plant(field, loc);
                    newPlants.add(newPlant);
                }
        }

        if (raining) {
            transpire();
            decrementWaterLevel();
        }
    }

    /**
     * The water level will go down consistently. It will die if it doesn't have enough water.
     */
    private void decrementWaterLevel() {
        waterLevel--;
        if (waterLevel <= 0) {
            setDead();
        }
    }

    /**
     * The water level will become full every time it rains
     */
    private void transpire() {
        waterLevel = 1000;
    }
}

