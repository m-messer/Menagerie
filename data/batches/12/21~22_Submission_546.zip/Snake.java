
import java.util.List;

/**
 * A simple model of a snake.
 * Snakes age, move, eat rabbits, and die.
 *
 * @version 02.03.2022
 */
public class Snake extends Animal {
    // Characteristics shared by all foxes (class variables).
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.04;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 100;
    // The age to which a fox can live.
    private static final int MAX_AGE = 10000;
    private static final Class[] DIET = new Class[]{Rabbit.class};
    // The food value of the snake, which is how much it is worth for a lion.
    private static final int FOOD_VALUE = 10;


    /**
     * Create a fox. A fox can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, DIET, FOOD_VALUE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);

    }

    /**
     * This is what the snake does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * On occasion, it will also create new disease and infect other snakes.
     *
     * @param newSnakes A list to return newly born snakes.
     * @param raining   Whether it is raining.
     * @param sunny     Whether it is sunny.
     */
    public void act(List<Wildlife> newSnakes, boolean sunny, boolean raining) {
        incrementAge();
        incrementHunger();

        if (isAlive()) {
            giveBirth(newSnakes);

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if (rand.nextDouble() <= getDiseaseCreationPossibility()) {
                createDisease();
            }
            infect();

            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newSnakes A list to return newly born snakes.
     */
    private void giveBirth(List<Wildlife> newSnakes) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Snake young = new Snake(false, field, loc);
            newSnakes.add(young);

        }
    }
}
