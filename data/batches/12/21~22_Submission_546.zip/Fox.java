import java.util.List;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 02.03.2022
 */
public abstract class Fox extends Animal {
    // Characteristics shared by all foxes (class variables).
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The fox's diet. This consists only of rabbits.
    private static final Class[] DIET = new Class[]{Rabbit.class};
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int FOOD_VALUE = 15;

    /**
     * Create a fox. A fox can be created as a newborn (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, DIET, FOOD_VALUE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
        setNocturnal();

    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newFoxes A list to return newly born foxes.
     * @param sunny    Whether it is sunny
     * @param raining  Whether it is raining
     */
    public abstract void act(List<Wildlife> newFoxes, boolean sunny, boolean raining);

}
