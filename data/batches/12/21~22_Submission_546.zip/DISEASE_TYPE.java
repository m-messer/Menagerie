import java.util.List;
import java.util.Random;

/**
 * A class representing different types of diseases
 * The type will decide which sort of animal characteristics they affect
 *
 * @version 02.03.2022
 */
public enum DISEASE_TYPE {BREEDING_PROBABILITY_DISEASE, MAX_LITTER_SIZE_DISEASE, MAX_AGE_DISEASE;

    private static final List<DISEASE_TYPE> DISEASE_TYPE_LIST =
            List.of(values());
    private static final int SIZE = DISEASE_TYPE_LIST.size();
    private static final Random RANDOM = new Random();

    public static DISEASE_TYPE randomDiseaseType()  {
        return DISEASE_TYPE_LIST.get(RANDOM.nextInt(SIZE));
    }
}

