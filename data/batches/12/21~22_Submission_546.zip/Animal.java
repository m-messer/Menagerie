import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.floor;


/**
 * A class representing shared characteristics of animals.
 *
 * @version 02.03.2022
 */
public abstract class Animal<reach> extends Wildlife {
    // The list of items in the animal's diet
    private final Class[] diet;
    //The amount of food the animal has. The animal will die if this reaches zero.
    private int foodLevel;
    // The maximum age the animal can reach/ The animal will die if the animal reaches this age
    private int maxAge;
    // The minimum age at which an animal can breed
    private final int breedingAge;
    // The age of the animal
    private int age;
    // The probability that an animal will breed at any point.
    private double breedingProbability;
    // The maximum size of an animal's litter
    private int maxLitterSize;
    // The possibility that an anila will create a disease
    private final static double diseaseCreationPossibility = 0.001;
    // The diseases that an animal has. These might be passed to another animal.
    private List<Disease> diseases = new ArrayList<>();

    /**
     * Create a new animal at location in field.
     *
     * @param randomAge           Whether the animal will be created at a random age.
     * @param field               The field currently occupied.
     * @param location            The location within the field.
     * @param maxAge              The age at which the animal will die.
     * @param breedingAge         The age at which the animal will start breeding.
     * @param diet                The classes that make up the animal's diet.
     * @param foodValue           The value which will be added to the predator's food level upon consumption.
     * @param breedingProbability The probability of breeding.
     * @param maxLitterSize       The maximum size of the litter.
     */
    public Animal(boolean randomAge, Field field, Location location, int maxAge, int breedingAge, Class[] diet,
                  int foodValue, double breedingProbability, int maxLitterSize) {
        super(field, location, foodValue);
        this.diet = diet;
        this.maxAge = maxAge;
        this.breedingAge = breedingAge;
        this.breedingProbability = breedingProbability;
        this.maxLitterSize = maxLitterSize;
        this.foodLevel = 8;
        age = 0;
        if (randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(20);
        }
    }

    /**
     * Look for food in adjacent to the current location.
     * Only the first bit of food found is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Class foodItem : diet) {
            for (Location where : adjacent) {
                Object prey = field.getObjectAt(where);
                if (prey != null) {
                    if (prey.getClass().equals(foodItem)) {
                        Wildlife victim = (Wildlife) prey;
                        if (victim.isAlive()) {
                            victim.setDead();
                            int foodValue = victim.getFoodValue();
                            setFoodLevel(foodValue);
                            return where;
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     *
     * @return true if the rabbit can breed, false otherwise.
     */
    protected boolean canBreed() {
        return age >= breedingAge;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && (rand.nextDouble() <= breedingProbability)) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge() {
        age++;
        if (age > maxAge) {
            setDead();
        }
    }

    /**
     * Make the animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Set the food level to the food value of whatever is being eaten.
     *
     * @param foodValue Thw=e food value of the prey.
     */
    private void setFoodLevel(int foodValue) {
        foodLevel = foodValue;
    }


    /**
     * Make a new disease, add it to the list of diseases and apply it's effects.
     */
    protected void createDisease() {
        Disease newDisease = new Disease();
        diseases.add(newDisease);
        applyDisease(newDisease);
    }

    /**
     * Apply the effects of a disease. This may affect the breeding probability, the maximum age,
     * or the maximum litter size.
     *
     * @param disease The disease being affected.
     */
    private void applyDisease(Disease disease) {
        DISEASE_TYPE diseaseType = disease.getDiseaseType();
        double reductionFactor = disease.getReductionFactor();
        switch (diseaseType) {
            case MAX_LITTER_SIZE_DISEASE:
                maxLitterSize = (int) Math.max(1.0, floor(maxLitterSize * reductionFactor));
                break;
            case BREEDING_PROBABILITY_DISEASE:
                breedingProbability = breedingProbability * reductionFactor;
                break;
            case MAX_AGE_DISEASE:
                maxAge = (int) floor(maxAge * reductionFactor);
                break;
        }
    }

    /**
     * Get infected by another animal.
     *
     * @param disease The disease being passed to the animal/
     */
    private void getInfected(Disease disease) {
        ;

        applyDisease(disease);
    }

    /**
     * Pass on one's diseases to surrounding animal's of the dame species.
     * This will only happen if the contagion is high enough.
     */
    protected void infect() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Disease disease : diseases) {
            if (disease.getContagion() >= 0.9) {
                for (Location where : adjacent) {
                    Object animal = field.getObjectAt(where);
                    if (animal != null) {
                        if (animal.getClass().equals(this.getClass())) { //Animals can only infect other animals of the same species
                            ((Animal) animal).getInfected(disease);
                        }
                    }
                }
            }
        }
    }

    /**
     * @return How likely it is for a disease to be created
     */
    protected double getDiseaseCreationPossibility() {
        return diseaseCreationPossibility;
    }
}
