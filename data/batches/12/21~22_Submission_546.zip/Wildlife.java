import java.util.List;
import java.util.Random;

/**
 * The most abstract class from which all living things inherit.
 * It contains much of the very basic functions that they all do such as
 * having a field and location.
 *
 * @version 02.03.2022
 */
public abstract class Wildlife {
    // The field currently occupied
    private Field field;
    // The location within the field.
    private Location location;
    // Whether the wildlife is alive
    private boolean alive;
    //The value of the food to predators
    private final int foodValue;
    //Whether the wildlife is nocturnal. This defaults to false.
    private boolean nocturnal = false;
    protected Random rand = Randomizer.getRandom();

    public Wildlife(Field field, Location location, int foodValue) {
        alive = true;
        this.location = location;
        this.field = field;
        this.foodValue = foodValue;
        setLocation(location);
    }

    abstract public void act(List<Wildlife> newWildlife, boolean sunny, boolean raining);

    /**
     * Indicate that the wildlife is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the wildlife's location.
     *
     * @return The wildlife's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the wildlife at the new location in the given field.
     *
     * @param newLocation The wildlife's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Check whether the wildlife is alive or not.
     *
     * @return true if the wildlife is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }


    /**
     * Return the wildlife's field.
     *
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * @return The wildife's food value.
     */
    protected int getFoodValue() {
        return foodValue;
    }

    /**
     * @return Whether the wildlife is nocturnal.
     */
    public boolean isNocturnal() {
        return nocturnal;
    }

    /**
     * Make the wildlife nocturnal.
     */
    public void setNocturnal() {
        nocturnal = true;
    }


}
