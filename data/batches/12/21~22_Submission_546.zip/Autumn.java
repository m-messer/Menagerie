/**
 * A basic representation of autumn.
 * The days are medium length and the weather is mild.
 *
 * @version 02.03.2022
 */
public class Autumn implements Season {
    private static double chanceOfSun = 0.5;
    private static double chanceOfRain = 0.5;
    private static int dayLength = 12;
    private static double averageTemperature = 13;
    private static String name = "Autumn";

    public Autumn() {
    }

    public double getChanceOfSun() {
        return chanceOfSun;
    }

    public double getChanceOfRain() {
        return chanceOfRain;
    }

    public int getDayLength() {
        return dayLength;
    }

    public double getAverageTemperature() {
        return averageTemperature;
    }

    public String getName() {
        return name;
    }

    public Season nextSeason() {
        return new Winter();
    }
}