import java.util.Random;

/**
 * A class representing the environment.
 * It generates weather conditions based on the season;
 *
 * @version 02.03.2022
 */

public class Environment {
    // The current season of the simulator
    private Season currentSeason;
    // This is the arbitrary time. At the moment it corresponds to the 24-hour clock
    private int timeOfDay;
    // Whether it is raining
    private boolean raining;
    // Whether it is sunny.
    private boolean sunny;
    // The temperature of the environment
    private int temperature;
    //The day within the season. This resets at the beginning of every season.
    private int dayNumber;
    private static Random rand = Randomizer.getRandom();

    /**
     * Create an environment. It defaults to start in the summer
     */
    public Environment() {
        dayNumber = 1;
        timeOfDay = 0;
        currentSeason = new Summer();
        raining = false;
        sunny = false;

    }

    /**
     * @return Whether it is raining.
     */
    public boolean isRaining() {
        return raining;
    }

    /**
     * @return Whether it is sunny
     */
    public boolean isSunny() {
        return sunny;
    }

    /**
     * This increments the time and is called with every new step in the simulator.
     * It adjusts the day number and season accordingly
     *
     * @return nighttime Whether it is nighttime
     */
    public boolean incrementTime() {
        timeOfDay++;
        timeOfDay %= 24;
        if (timeOfDay == 0) {
            dayNumber++;
            dayNumber = dayNumber % 90; //The day number will reset at the beginning of every season.
        }
        if (timeOfDay == 0 && dayNumber == 0) {
            currentSeason = currentSeason.nextSeason();
        }

        return isNightTime();

    }

    /**
     * @return Whether it is nighttime
     */
    private boolean isNightTime() {
        return timeOfDay > currentSeason.getDayLength();
    }

    /**
     * Generate the weather of the environment, based on the season's statistics.
     */
    public void generateWeather() {
        double weatherIndex = rand.nextDouble();
        if (weatherIndex < currentSeason.getChanceOfRain()) {
            raining = true;
        } else {
            raining = false;
        }

        if (weatherIndex < currentSeason.getChanceOfSun()) {
            sunny = true;
        } else {
            sunny = false;
        }

    }

    /**
     * @return The day within the season that we are at
     */
    public int getDayNumber() {
        return dayNumber;
    }

    /**
     * @return The name of the current season.
     */
    public String getSeasonName() {
        return currentSeason.getName();
    }

}
