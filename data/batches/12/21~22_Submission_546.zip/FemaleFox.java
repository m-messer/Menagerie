import java.util.List;

/**
 * The female fox wll only breed if it mates with a male fox.
 * Otherwise, it is the same as a generic fox.
 *
 * @version 02.03.2022
 */

public class FemaleFox extends Fox {

    public FemaleFox(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);

    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * On occasion, it will also create new disease and infect other female foxes.
     *
     * @param newFoxes A list to return newly born foxes.
     * @param sunny    Whether it is sunny
     * @param raining  Whether it is raining
     */
    public void act(List<Wildlife> newFoxes, boolean sunny, boolean raining) {
        incrementAge();
        incrementHunger();


        if (isAlive()) {
            giveBirth(newFoxes);

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            // May randomly create a new disease.
            if (rand.nextDouble() <= getDiseaseCreationPossibility()) {
                createDisease();
            }
            // If the fox is diseased, it can infect other animals.
            infect();

            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Wildlife> newFoxes) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacentLocations = field.adjacentLocations(getLocation());
        for (Location location : adjacentLocations) {
            List<Location> twoStepsOut = field.adjacentLocations(location);
            for (Location place : twoStepsOut) {
                if (field.getObjectAt(location) instanceof MaleFox) {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for (int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        if (rand.nextBoolean()) {
                            FemaleFox young = new FemaleFox(true, field, loc);
                            newFoxes.add(young);
                        } else {
                            MaleFox young = new MaleFox(true, field, loc);
                            newFoxes.add(young);
                        }

                    }
                }
            }
        }
    }


    public boolean isMale() {
        return false;
    }
}
