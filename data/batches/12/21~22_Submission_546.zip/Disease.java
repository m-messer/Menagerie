import java.util.Random;
/**
 * A class representing  a disease.
 * The disease can be passed round animals, affecting them as they are infected.
 *
 * @version 02.03.2022
 */
public class Disease {
    private final static Random rand = Randomizer.getRandom();
    // The type of the disease.
    private final DISEASE_TYPE diseaseType = DISEASE_TYPE.randomDiseaseType();
    //How much the disease will affect the characteristic of the animal.
    private final double reductionFactor = rand.nextDouble();
    //How contagious the disease is.
    private final double contagion = rand.nextDouble();

    public Disease(){
    }

    /**
     * @return How much the disease affects the animal
     */
    public double getReductionFactor(){
        return reductionFactor;
    }

    /**
     * @return How contagious the disease is.
     */
    public double getContagion(){
        return contagion;
    }

    /**
     * @return The type of the disease.
     */
    public DISEASE_TYPE getDiseaseType() {
        return diseaseType;
    }
}
