import java.util.List;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 * Male foxes do not breed, only females do when the meet male foxes.
 *
 * @version 02.03.2022
 */
public class MaleFox extends Fox {

    public MaleFox(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);

    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * On occasion, it will also create new disease and infect other male foxes.
     *
     * @param newFoxes A list to return newly born foxes.
     * @param sunny    Whether it is sunny
     * @param raining  Whether it is raining
     */
    public void act(List<Wildlife> newFoxes, boolean sunny, boolean raining) {
        incrementAge();
        incrementHunger();


        if (isAlive()) {
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // The fox may create a new disease
            if (rand.nextDouble() <= getDiseaseCreationPossibility()) {
                createDisease();
            }
            //If the fox has a disease, then it might infect other animals.
            infect();

            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }
}
