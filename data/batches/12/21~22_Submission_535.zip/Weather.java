/**
 * An enmuerated type to store weather conditions and variables associated with them
 *
 * @version 2022.03.01
 */
public enum Weather {
    CLEAR("Clear"),
    RAIN("Rain",            0.15, 2,    0.225, 6,   0.05,   0.2,   3,   0.1,   4,   0.05,  2),
    HEAVYRAIN("Heavy Rain", 0.14, 2,    0.2,   8,   0.06,   0.175, 3,   0.125, 5,   0.025, 2),   
    HEATWAVE("Heat Wave",   0.14, 1,    0.175, 3,   0.03,   0.15,  3,   0.05,  3,   0.075, 2),
    SNOW("Snowing",         0.18, 3,    0.175, 3,   0.01,   0.225, 4,   0.04,  3,   0.1,   2),
    STORM("Storm",          0.15, 2,    0.275, 4,   0.07,   0.15,  3,   0.1,   5,   0.05,  2);

    private String name;
    
    /**
     * The standard constructor for a weather type, all parameters are assumed to be under the conditions of this weather.
     * @param name the name of the weather event
     * @param wolfBreed     % chance of wolves breeding
     * @param wolfLitter        max size of wolf litter
     * @param snakeBreed    % chance of snakes breeding
     * @param snakeLitter       max size of snake litter
     * @param eggHatch      % chance of eggs hatching
     * @param voleBreed     % chance of voles breeding
     * @param voleLitter        max size of vole litter
     * @param frogBreed     % chance of frogs breeding
     * @param frogLitter        max size of frog litter
     * @param hawkBreed     % chance of hawks breeding
     * @param hawkLitter        max size of hawk litter
     */
    Weather(String name, double wolfBreed, int wolfLitter, double snakeBreed, int snakeLitter, double eggHatch,
            double voleBreed, int voleLitter, double frogBreed, int frogLitter, double hawkBreed, int hawkLitter) {
        this.name = name;
        Wolf .conditions(wolfBreed, wolfLitter );
        Snake.conditions(snakeBreed,snakeLitter);
        Egg  .conditions(eggHatch);
        Vole .conditions(voleBreed, voleLitter );
        Frog .conditions(frogBreed, frogLitter );
        Hawk .conditions(hawkBreed, hawkLitter );
    }

    /**
     * Constructor for the reseting CLEAR type,
     * rather than change the probabilities to an appropriate given number
     * this resets them based on default values stored in their classes
     * @param name of the weather
     */
    Weather(String name) {
        this.name = name;
        Wolf .conditions();
        Snake.conditions();
        Egg  .conditions();
        Vole .conditions();
        Frog .conditions();
        Hawk .conditions();
    }

    /**
     * Accessor for name
     * @return a string representing the weather's name
     */
    public String getName() {
        return name;
    }
}
