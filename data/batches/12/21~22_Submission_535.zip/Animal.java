import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.03.01
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's sex, I know this being a bool is problematic but it makes logical sense to the simulation
    private boolean maleSex;
    // Whether the animal is nocturnal, diurnal or acts at day and night, active at day by default
    private Activity activity = Activity.DIURNAL;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);

        Random rand = new Random();
        int randInt = rand.nextInt(100);
        if(randInt < 50) maleSex = false;       // slight majority of females
        else maleSex = true;                    // rest are males
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    abstract void age(); 

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null)
            field.clear(location);
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * accessor method for whether the sex of an animal is male
     * @return true if the sex of the animal is male
     */
    protected boolean isMale() {
        return maleSex;
    }

    /**
     * Sets the animal's active period
     * @param activity an enum storing one of three possible activities
     */
    protected void setActivity(Activity activity) {
        this.activity = activity;
    }

    /**
     * accessor method returning the active period of the animal
     * @return an enum storeing one of three possible acitivities
     */
    protected Activity getActivity() {
        return activity;
    }
}