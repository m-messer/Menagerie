import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a vole.
 * Voles age, move, breed, and die.
 *
 * @version 2022.03.01
 */
public class Vole extends Animal
{
    // Characteristics shared by all Voles (class variables).

    // The age at which a vole can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a vole can live.
    private static final int MAX_AGE = 25;
    // The likelihood of a vole breeding.
    private static double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The vole's age.
    private int age;

    /**
     * Create a new vole. A vole may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the vole will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Vole(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * Returns BREEDING_PROBABILITY and MAX_LITTER_SIZE to their original values
     */
    public static void conditions() {
        conditions(0.2,4);
    }

    /**
     * Mutates the static BREEDING_PROBABILITY and MAX_LITTER_SIZE to
     * new values
     * @param breeding double between 0 and 1 representing probability of breeding
     * @param litter integer to represent the maximum number of newborns in a litter
     */
    public static void conditions(double breeding, int litter) {
        BREEDING_PROBABILITY = breeding;
        MAX_LITTER_SIZE = litter;
    }
    
    /**
     * This is what the vole does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newVoles A list to return newly born voles.
     */
    public void act(List<Animal> newVoles)
    {
        if(isAlive()) {
            giveBirth(newVoles);
            // Try to move to a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            // See if it was possible to move.
            if(newLocation != null) setLocation(newLocation);
            else setDead();                     // Overcrowding.
        }
    }

    /**
     * Increase the age.
     * This could result in the vole's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Increase age by 1, check wheather the animal should die of old age
     */
    public void age()
    {
        incrementAge();
    }

    /**
     * Check whether or not this vole is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newVoles A list to return newly born voles.
     */
    private void giveBirth(List<Animal> newVoles)
    {
        // New voles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Vole young = new Vole(false, field, loc);
            newVoles.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A vole can breed if it has reached the breeding age.
     * @return true if the vole can breed, false otherwise.
     */
    private boolean canBreed()
    {
        boolean oppositeSexPartner = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Vole) {
                Vole vole = (Vole) animal;
                if(isMale() != vole.isMale()) {
                    oppositeSexPartner = true;
                }       
            }
        }
        return oppositeSexPartner && age >= BREEDING_AGE;
    }
}
