/**
 * Class for the main(String[] args) method to exist within
 * @version 2022.03.01
 */
public class Main {
    public static void main(String[] args) {
        Simulator simulator = new Simulator();
    }
}