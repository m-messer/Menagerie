import java.util.List;
import java.util.Random;
/**
 * Simple model of eggs
 * They are laid by snakes, which in time hatch
 * @version 2022.03.01
 */
public class Egg extends Animal
{
    // Characteristics shared by all eggs (class variables).

    // The age to which an egg can reach before hatching.
    private static final int MAX_AGE = 15;
    // The likelihood of an egg hatching.
    private static double HATCHING_PROBABILITY = 0.04;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The egg's age.
    private int age;

    /**
     * Returns HATCHING_PROBABLITY to its original values
     */
    public static void conditions() {
        conditions(0.4);
    }


    public void age()
    {
        incrementAge();
    }

    /**
     * Mutates the static HATCHING_PROBABILITY to a new value
     * @param hatching double between 0 and 1 representing probability of hatching
     */
    public static void conditions(double hatching) {
        HATCHING_PROBABILITY = hatching;
    }

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the egg will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Egg(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * The only thing an egg can do is hatch and age
     * @param field The field currently occupied.
     * @param newSnakes A list to return newly born snakes.
     */
    public void act(List<Animal> newSnakes)
    {
        if(isAlive()) {
            if(rand.nextDouble() <= HATCHING_PROBABILITY){
                giveBirth(newSnakes);
            }
        }
    }
    /**
     * Increase the age. This could result in the snake's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this egg is to hatch snakes at this step.
     * New births will be made into free adjacent locations.
     * @param newSnakes A list to return newly born snakes.
     */
    private void giveBirth(List<Animal> newSnakes)
    {
        // New snakes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getBiasedAdjacentLocations(getLocation(), Vole.class, Frog.class);
        int births = hatches();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Snake young = new Snake(false, field, loc);
            newSnakes.add(young);
        }
    }

    /**
     * Method to run the probability of the egg hatching
     * @return 0 or 1, indicating how many new snakes to create (0 if unhatched)
     */
    private int hatches()
    {
        int hatch = 0;
        if(rand.nextDouble() <= HATCHING_PROBABILITY) {
            hatch = 1;
        }
        return hatch;
    } 
}