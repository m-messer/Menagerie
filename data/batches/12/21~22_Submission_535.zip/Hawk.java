import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Hawk.
 * Hawks age, move, eat prey, and die.
 *
 * @version 2022.03.01
 */
public class Hawk extends Animal
{
    // Characteristics shared by all Hawks (class variables).
    
    // The age at which a Hawk can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Hawk can live.
    private static final int MAX_AGE = 125;
    // The likelihood of a Hawk breeding.
    private static double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 3;
    // The food value of different animals. In effect, this is the
    // number of steps a Hawk can go before it has to eat again.
    private static final int FROG_FOOD_VALUE = 20;
    private static final int EGG_FOOD_VALUE = 7;
    private static final int RABBIT_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Hawk's age.
    private int age;
    // The Hawk's food level, which is increased by eating voles.
    private int foodLevel;

    /**
     * Create a Hawk. A Hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Hawk will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hawk(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FROG_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FROG_FOOD_VALUE;
        }
        setActivity(Activity.OMNI);
    }

    /**
     * Returns BREEDING_PROBABILITY and MAX_LITTER_SIZE to their original values
     */
    public static void conditions() {
        conditions(0.1,3);
    }

    /**
     * Mutates the static BREEDING_PROBABILITY and MAX_LITTER_SIZE to
     * new values
     * @param breeding double between 0 and 1 representing probability of breeding
     * @param litter integer to represent the maximum number of newborns in a litter
     */
    public static void conditions(double breeding, int litter) {
        BREEDING_PROBABILITY = breeding;
        MAX_LITTER_SIZE = litter;
    }
    
    /**
     * This is what the Hawk does most of the time: it hunts for
     * voles. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newHawks A list to return newly born Hawks.
     */
    public void act(List<Animal> newHawks)
    {
        if(isAlive()) {
            giveBirth(newHawks);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase age by one, decrease foodLevel and check to see if the animal should die of old age or hunger
     */
    public void age()
    {
        incrementAge();
        incrementHunger();
    }

    /**
     * Increase the age. This could result in the Hawk's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Hawk more hungry. This could result in the Hawk's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isAlive()) { 
                    frog.setDead();
                    foodLevel += FROG_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Egg) {
                Egg egg = (Egg) animal;
                if(egg.isAlive()) {
                    egg.setDead();
                    foodLevel += EGG_FOOD_VALUE;
                    return where; 
                }
            }
            else if (animal instanceof Vole) {
                Vole vole = (Vole) animal;
                if(vole.isAlive()) {
                    vole.setDead();
                    foodLevel += RABBIT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Hawk is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHawks A list to return newly born Hawks.
     */
    private void giveBirth(List<Animal> newHawks)
    {
        // New Hawks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getBiasedAdjacentLocations(getLocation(), Vole.class, Egg.class, Frog.class);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hawk young = new Hawk(false, field, loc);
            newHawks.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Hawk can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        boolean oppositeSexPartner = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hawk) {
                Hawk Hawk = (Hawk) animal;
                if(isMale() != Hawk.isMale()) {
                    oppositeSexPartner = true;
                }       
            }
        }
        return oppositeSexPartner && age >= BREEDING_AGE;
    }
}
