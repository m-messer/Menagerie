import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field.
 *
 * @version 2022.03.01
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 240;

    // The probability that an animal will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.01;
    private static final double VOLE_CREATION_PROBABILITY = 0.08;
    private static final double SNAKE_CREATION_PROBABILITY = 0.02;
    private static final double FROG_CREATION_PROBABILITY = 0.04;
    private static final double HAWK_CREATION_PROBABILITY = 0.0075;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A secondary step count varying from 1-4 to represent quarters of a day
    private int istep = 1;
    // The current Season, represented as an enumerated type
    private Season season = Season.SPRING;
    // The current weather event, represented as an enumerated type
    Weather weather = Weather.CLEAR;
    // The total days past, each day is 4 steps
    private int days = 1;
    // Whether the field is currently in light or darkness
    private boolean daytime=true;
    // How many days are in a season, it is at 30 for testing right now but may be increased to 90 later
    private final int seasonLength = 30;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Vole.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Snake.class, new Color(28,104,89));   // Dark Green
        view.setColor(Egg.class, new Color(150, 255, 171)); // Light Green
        view.setColor(Frog.class, Color.CYAN);
        view.setColor(Hawk.class, Color.RED); //new Color(140,75,40));
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep()
    {
        step++;
        updateSeason();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.age();
            if(animal.getActivity().equals(Activity.OMNI) || (animal.getActivity().equals(Activity.NOCTURNAL) && !daytime) || (animal.getActivity().equals(Activity.DIURNAL) && daytime)){
                animal.act(newAnimals);
            }
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        updateBalance();
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        days = 0;
        season = Season.SPRING;
        daytime = true;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);         // temporarily store this location
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= VOLE_CREATION_PROBABILITY) {
                    Vole vole = new Vole(true, field, location);
                    animals.add(vole);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Frog frog = new Frog(true, field, location);
                    animals.add(frog);
                }
                else if(rand.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    Hawk hawk = new Hawk(true, field, location);
                    animals.add(hawk);
                }
            }
        }
    }

    /**
     * Randomly populate open cells
     */
    private void freePopulate()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);         // temporarily store this location
                if(field.getObjectAt(location) != null) continue;   // skip this iteration if cell populated
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY*0.05) {
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= VOLE_CREATION_PROBABILITY*0.05) {
                    Vole vole = new Vole(true, field, location);
                    animals.add(vole);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY*0.05) {
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY*0.05) {
                    Frog frog = new Frog(true, field, location);
                    animals.add(frog);
                }
                else if(rand.nextDouble() <= HAWK_CREATION_PROBABILITY*0.005) {
                    Hawk hawk = new Hawk(true, field, location);
                    animals.add(hawk);
                }
            }
        }
    }

    /**
     * populate free cells with a specific animal
     * @param animal the animal type to be populated with (as Animal.class)
     */
    private void freePopulate(Class<?> animal)
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);         // temporarily store this location
                if(field.getObjectAt(location) != null) continue;   // skip this iteration if cell populated
                if(animal.equals(Wolf.class) && rand.nextDouble() <= WOLF_CREATION_PROBABILITY*0.5){
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                } else
                if(animal.equals(Vole.class) && rand.nextDouble() <= VOLE_CREATION_PROBABILITY*0.5){
                    Vole vole = new Vole(true, field, location);
                    animals.add(vole);
                } else
                if(animal.equals(Snake.class) && rand.nextDouble() <= SNAKE_CREATION_PROBABILITY*0.5){
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                } else
                if(animal.equals(Frog.class) && rand.nextDouble() <= FROG_CREATION_PROBABILITY*0.5) {
                    Frog frog = new Frog(true, field, location);
                    animals.add(frog);
                } else
                if(animal.equals(Hawk.class) && rand.nextDouble() <= HAWK_CREATION_PROBABILITY*0.05) {
                    Hawk hawk = new Hawk(true, field, location);
                    animals.add(hawk);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * A balancing method, used to increase random chance,
     * this helps prevent animal types going extinct by creating new ones in underpopulated areas.
     * if the field in general is underpopulated it will run a limited version of populate,
     * otherwise it oppose the current state with appropriate new prey/predators to help preseve an equilibrium
     */
    private void updateBalance()
    {   
        Random rand = new Random();
        if(rand.nextInt(2) == 0) return;    // kills method 50% of the times it is used to avoid overuse 
        // are there more empty tiles than populated ones
        if(DEFAULT_DEPTH*DEFAULT_WIDTH > 2*animals.size() )    // arithmetically equivalent to x - animals.size() > animals.size()
        {
            freePopulate();
            return;
        }
        int wolves  = view.getStats().getCounters().get(Wolf.class  ).getCount();
        int snakes  = view.getStats().getCounters().get(Snake.class ).getCount() + view.getStats().getCounters().get(Egg.class).getCount();
        int hawks   = view.getStats().getCounters().get(Hawk.class  ).getCount();
        int voles   = view.getStats().getCounters().get(Vole.class  ).getCount();
        int frogs   = view.getStats().getCounters().get(Frog.class  ).getCount();
        if(voles > DEFAULT_DEPTH*DEFAULT_WIDTH - animals.size() || hawks + snakes > wolves) { freePopulate(Wolf.class); return;     }
        if(frogs > DEFAULT_DEPTH*DEFAULT_WIDTH - animals.size() || hawks + wolves > snakes) { freePopulate(Snake.class);return;     }
        if(voles > frogs) { freePopulate(Frog.class);                                                                   return;     }
        if(voles < frogs) { freePopulate(Vole.class);                                                                   return;     }
        
    }
    
    /**
     * Set the amount of daylight depending on the season
     * and Update the season if appropriate
     */
    public void updateSeason()
    {
        boolean newDay;
        if(istep==4){
            days++;
            istep=1;
            newDay = true;
        }else{
            istep++;
            newDay = false;
        }
        switch(season){
            case SPRING:
                if(newDay && days%seasonLength==0){
                    season=Season.SUMMER;
                }
                switch(istep){
                    case 1: case 4: daytime=false;break;
                    case 2: case 3: daytime=true ;break;
                }
                break;
            case SUMMER:
                if(newDay && days%seasonLength==0){
                    season=Season.AUTUMN;
                }
                switch(istep){
                    case 1: daytime=false;               break;
                    case 2: case 3: case 4: daytime=true;break;
                }
                break;
            case AUTUMN:
                if(newDay && days%seasonLength==0){
                    season=Season.WINTER;
                }
                switch(istep){
                    case 1: case 4: daytime=false;break;
                    case 2: case 3: daytime=true ;break;
                }
                break;
            case WINTER:
                if(newDay && days%seasonLength==0){
                    season=Season.SPRING;
                }
                switch(istep){
                    case 2: daytime=false;               break;
                    case 1: case 3: case 4: daytime=true;break;
                }
                break;
        }
        weather();
    }

    /**
     * update the weather, changing it appropriately based off the current Season.
     */
    public void weather() {
        int c = season.getChance();
        Random rand = new Random();
        int probInt = rand.nextInt(100);
        weather = Weather.CLEAR;
        if(probInt < c) {
                weather = Weather.RAIN;
            if(probInt < (c*0.1) && !season.equals(Season.WINTER)) {
                weather = Weather.HEAVYRAIN;
            }
            if(probInt < 65 && season.equals(Season.WINTER)) {
                weather = Weather.SNOW;
            }
            if((season.equals(Season.SUMMER) || season.equals(Season.AUTUMN))
                && probInt < (1-c)*0.1) {
                weather = Weather.HEATWAVE;
            }
            if(probInt < c*0.05) {
                weather = Weather.STORM;
            }
        }
    }

    /**
     * Accessor for the season
     * @return the current season, represented as an enumerated type
     */
    public Season getSeason() {
        return season;
    }

    /**
     * Accessor for the step count of the simulation
     * @return the number of steps that the sim has taken so far
     */
    public int getStep() {
        return step;
    }

    /**
     * Accessor for the day count of the simulation
     * @return the number of days that the sim has undergone so far
     */
    public int getDays() {
        return days;
    }

    /**
     * Accessor for the current daytime
     * @return true if it is currently daytime
     */
    public boolean getDaytime() {
        return daytime;
    }

    /**
     * Methood to return an appropriately indented string reflecting the time of day
     * @return a string reflecting daytime
     */
    public String translateDaytime() {
        if(daytime) {
            return "Day   ";     // extended to ensure consistant indentation
        }else{
            return "Night";
        }
    }

    /**
     * Accessor for the current weather event
     * @return weather, represented as an enumerated type
     */
    public Weather getWeather() {
        return weather;
    }
}
