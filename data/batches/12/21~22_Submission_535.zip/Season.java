/**
 * An enumerated class used to store the four seasons simulated
 * the chance of weather events is stored here aswell
 *
 * @version 2022.03.01
 */
public enum Season {
    SPRING("Spring",50),
    SUMMER("Summer",20),
    AUTUMN("Autumn",40),
    WINTER("Winter",30);

    private String name;
    private int weatherChance;

    Season(String name, int weatherChance) {
        this.weatherChance = weatherChance;
        this.name = name;
    }

    /**
     * Accessor for weatherChance
     * @return an integer below 100 representing the chance/100 for a weatherevent to occur
     */
    public int getChance() {
        return weatherChance;
    }

    /**
     * Accessor for the name
     * @return the name of the season as a string
     */
    public String getName() {
        return name;
    }
}