import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a frog.
 * Frogs age, move, breed, and die.
 *
 * @version 2022.03.01
 */
public class Frog extends Animal
{
    // Characteristics shared by all voles (class variables).

    // The age at which a vole can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a vole can live.
    private static final int MAX_AGE = 25;
    // The likelihood of a vole breeding.
    private static double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The frog's age.
    private int age;

    /**
     * Create a new frog. A frog may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the vole will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        if(rand.nextDouble() < 0.5) {
            setActivity(Activity.NOCTURNAL);           // frogs are varied, set half to be nocturnal
        }
    }
    
    /**
     * Returns BREEDING_PROBABILITY and MAX_LITTER_SIZE to their original values
     */
    public static void conditions() {
        conditions(0.075,4);
    }

    /**
     * Mutates the static BREEDING_PROBABILITY and MAX_LITTER_SIZE to
     * new values
     * @param breeding double between 0 and 1 representing probability of breeding
     * @param litter integer to represent the maximum number of newborns in a litter
     */
    public static void conditions(double breeding, int litter) {
        BREEDING_PROBABILITY = breeding;
        MAX_LITTER_SIZE = litter;
    }
    
    /**
     * This is what the vole does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newFrogs A list to return newly born voles.
     */
    public void act(List<Animal> newFrogs)
    {
        if(isAlive()) {
            giveBirth(newFrogs);
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            // See if it was possible to move.
            if(newLocation != null) setLocation(newLocation);
            else setDead();                     // Overcrowding.
            
        }
    }


    /**
     * Increase age by one and check to see if the animal should die of old age
     */
    public void age()
    {
        incrementAge();
    }

    /**
     * Increase the age.
     * This could result in the frog's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this frog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFrogs A list to return newly born frogs.
     */
    private void giveBirth(List<Animal> newFrogs)
    {
        // New frogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Frog young = new Frog(false, field, loc);
            newFrogs.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A frog can breed if it has reached the breeding age.
     * @return true if the frog can breed, false otherwise.
     */
    private boolean canBreed()
    {
        boolean oppositeSexPartner = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Frog) {
                Frog vole = (Frog) animal;
                if(isMale() != vole.isMale()) {
                    oppositeSexPartner = true;
                }       
            }
        }
        return oppositeSexPartner && age >= BREEDING_AGE;
    }
}
