/**
 * An enmuerated type to store the day/night behaviour of animals
 *
 * @version 2022.03.01
 */
public enum Activity {
    NOCTURNAL,              // ACTIVE AT NIGHT
    DIURNAL,                // ACTIVE AT DAY
    OMNI;                   // ACTIVE AT ALL TIMES
}
