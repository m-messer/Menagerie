import java.util.List;
/**
 * A class representing shared characteristics and methods of Plants.
 *
 * @version 2020.03.01
 */
public abstract class Plants extends Actor
{
    // Characteristics shared by all plants 

    //the amount of food level it will increase each step
    private int growthRate;
    //the amount of water needed to be alive
    private int waterLevel;
    //the food level a animal can gain after eating a plant 
    private int plantFoodLevel;
    //the maximum food level a animal can gain after eating a plant 
    private int maxPlantFoodLevel;

    
    /**
     * Create a new plant at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(Field field, Location location)
    {
        super(field, location);
        waterLevel = 20;
        growthRate = 2;

    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born Plants.
     */
    abstract public void act(List<Actor> newPlants);

    /**
     * increase the plant food level
     * it will stop if maximum plant food level is reached.
     */
    protected void increasePlantFoodLevel()
    {
        if(plantFoodLevel + growthRate <= maxPlantFoodLevel){
            plantFoodLevel = plantFoodLevel + growthRate;
        }
    }

    /**
     * increase the water level
     */
    protected void increaseWaterLevel()
    {
        waterLevel++;
    }

    /**
     * decrease the water level. This could result in the plant's death.
     */
    protected void decreaseWaterLevel()
    {
        waterLevel--;
        if(waterLevel <= 0) {
            setDead();
        }
    }

    /**
     * set maximum plant food level
     * @param maxFoodLevel The maximum food level a plant can give to the prey
     */
    protected void setMaxPlantFoodLevel(int maxFoodLevel)
    {
        maxPlantFoodLevel = maxFoodLevel;
    }

    /**
     * @return maxPlantFoodLevel The maximum food level a plant can give to the prey
     */
    protected int getMaxPlantFoodLevel()
    {
        return maxPlantFoodLevel;
    }

    /**
     * set plant food level
     * @param foodLevel The food level a plant can give to the prey
     */
    protected void setPlantFoodLevel(int foodLevel)
    {
        plantFoodLevel = foodLevel;
    }

    /**
     * @return plantFoodLevel The food level a plant can give to the prey
     */
    public int getPlantFoodLevel()
    {
        return plantFoodLevel;
    }
}
