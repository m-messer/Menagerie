import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a cheetah.
 *
 * @version 2021.03.01
 */
public class Cheetah extends Animal
{
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a cheetah. A cheetah can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the cheetah will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cheetah(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
        setBreedingAge(1);
        setMaxAge(100);
        setBreedingProbability(0.23);
        setLitterSize(1);
        setGender();
        setEatingFoodValue(10);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(100));
        }
        else {
            setAge(0);
            setFoodLevel(100);
            
        }

    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        if (getFoodValue() <= getEatingFoodValue()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                if(actor instanceof Zebra) {
                    Zebra zebra = (Zebra) actor;
                    if(zebra.isAlive()) { 
                        zebra.setDead();
                        setFoodLevel(zebra.getZebraFoodLevel());
                        return where;
                    }
                }
                else if(actor instanceof Horse) {
                    Horse horse = (Horse) actor;
                    if(horse.isAlive()) { 
                        horse.setDead();
                        setFoodLevel(horse.getHorseFoodLevel());
                        return where;
                    }
                }
                else if(actor instanceof Deer) {
                    Deer deer= (Deer) actor;
                    if(deer.isAlive()) { 
                        deer.setDead();
                        setFoodLevel(deer.getDeerFoodLevel());
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     *Check whether or not this cheetah is adjacent to a different gender cheetah to breed
     *@return true if founded, or false if not
     */
    public boolean findPairs()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Object animal = field.getObjectAt(it.next());
            if(animal instanceof Cheetah) {
                Cheetah cheetah = (Cheetah) animal;
                if(cheetah.isAlive() && cheetah.getGender()) { 
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this cheetah is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCheetahs A list to return newly born Cheetahs.
     */
    public void giveBirth(List<Actor> newCheetahs)
    {
        // New Cheetahs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cheetah young = new Cheetah(false, field, loc);
            young.findTimeOfDay();
            //set the time of the new born cheetah the same as others
            young.getTimeObject().setTime(young.getTimeOfDay()); 
            newCheetahs.add(young);
        }
    }

}
