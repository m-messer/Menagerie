import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a deer.
 *
 * @version 2021.03.01
 */
public class Deer extends Animal
{
    //the food level a predator can gain when a deer is ate
    private int deerFoodLevel;
    
    private static final Random rand = Randomizer.getRandom();
    
    private Time time;
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
        deerFoodLevel = 30;
        setBreedingAge(1);
        setMaxAge(100);
        setBreedingProbability(0.2);
        setLitterSize(1);
        setGender();
        setEatingFoodValue(1);
        
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(100));
        }
        else {
            setAge(0);
            setFoodLevel(100);
            
        }
    }

    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        if (getFoodValue() <= getEatingFoodValue()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                if(actor instanceof Grass) {
                    Grass grass = (Grass) actor;
                    if(grass.isAlive()) { 
                        grass.setDead();
                        setFoodLevel(grass.getPlantFoodLevel());
                        return where;

                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this deer is adjacent to a different gender deer to breed
     * @return true if founded, or false if not
     */
    public boolean findPairs()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Object animal = field.getObjectAt(it.next());
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive() && deer.getGender()) { 
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeers A list to return newly born deers.
     */
    public void giveBirth(List<Actor> newDeers)
    {
        // New deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc);
            young.findTimeOfDay();
            //set the time of the new born deer the same as others
            young.getTimeObject().setTime(young.getTimeOfDay()); 
            newDeers.add(young);
        }
    }

    /**
     * @return deerFoodLevel The food level a predator can gain when a deer is ate
     */
    public int getDeerFoodLevel()
    {
        return deerFoodLevel;
    }
    
    
}
