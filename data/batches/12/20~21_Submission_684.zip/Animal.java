import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics and methods of animals.
 *
 * @version 2021.03.01
 */
public abstract class Animal extends Actor
{
    // Characteristics shared by all animals.

    // The age at which an animal can start to breed.
    private int BREEDING_AGE;
    // The age to which an animal can live.
    private int MAX_AGE;
    // The likelihood of an animal breeding.
    private double BREEDING_PROBABILITY;
    // The maximum number of births.
    private int MAX_LITTER_SIZE;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // the gender of the animal. True for male, false for female.
    private boolean IS_MALE;

    //the age of the animal
    private int age;
    //the food level of the animal
    private int foodLevel;
    //animals can only eat food when their foodLevel <= eatingFoodValue 
    private int eatingFoodValue;

    private Time time;
    //the time of a day
    private int timeOfDay;

    private Disease disease;

    /**
     * Create an animal.
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        time = new Time();
        timeOfDay = 0;
        disease = new Disease();
    }

    /**
     * This is what the animal does most of the time: it finds food. 
     * In the process, it might breed, die of hunger,
     * or die of old age,  or die of disease.
     * @param newAnimals A list to receive newly born Animals.
     */
    public void act(List<Actor> newAnimals)
    {
        incrementAge();
        incrementHunger();
        disease.infection(); //animals can be infected by disease
        
        //All animals can only move between 6am to 9pm.
        if (time.getTime() == 6 || time.getTime() == 9 || time.getTime() == 12 || time.getTime() == 15 || time.getTime() == 18){ 

            if(isAlive()) {
                if (getGender() == false && findPairs()){ //only female can give birth
                    giveBirth(newAnimals); 
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();

                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                    // if no free location, move to the location with plants
                    if(newLocation == null) {
                        List<Location> adjacent = getField().adjacentLocations(getLocation());
                        Iterator<Location> it = adjacent.iterator();
                        List<Location> plantsLocation = new ArrayList();

                        while(it.hasNext()) {
                            Object object = getField().getObjectAt(it.next());
                            if(object instanceof Plants) {
                                Plants plants = (Plants) object;
                                plantsLocation.add(plants.getLocation());
                            }
                        }

                        if(plantsLocation.size()>0){
                            newLocation = plantsLocation.get(0);
                            Object object = getField().getObjectAt(newLocation);
                            Plants plant = (Plants) object;
                            plant.setDead(); //plant will be killed if animal moves to its location
                        }
                        else{
                            newLocation = null;
                        }

                    }
                }

                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);

                }
                else{
                    setDead(); //over crowded
                }

                // disease can spread to animals at adjacent location
                if(disease.getIsInfected()){
                    List<Location> adjacent = getField().adjacentLocations(getLocation());
                    Iterator<Location> it = adjacent.iterator();
                    while(it.hasNext()) {
                        Object actor = getField().getObjectAt(it.next());
                        if(actor instanceof Animal){
                            Animal animal = (Animal) actor;
                            animal.getDiseaseObject().infection();
                        }
                    }

                    setDead();  //die of disease
                }
            }

        }
        time.incrementTime();
    }

    /**
     * Increase the age. This could result in the animal's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Set the gender of the animal
     * 50% male, 50% female
     * @return IS_MALE The gender of the animal. True for male, false for female.
     */
    public boolean setGender()
    {
        if (rand.nextInt(2) == 1 ){
            IS_MALE = true;

        }
        else{
            IS_MALE = false;
        }
        return IS_MALE;
    }

    /**
     * Make this fox more hungry. This could result in the animal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Make this animal find food
     */
    abstract public Location findFood();

    /**
     * Make this animal give birth
     * @param newAnimals A list to return newly born Animals.
     */
    abstract public void giveBirth(List<Actor> newAnimals);

    /**
     * Make this animal find pairs
     */
    abstract public boolean findPairs();

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * @return IS_MALE The gender of the animal. True for male, false for female.
     */
    protected boolean getGender()
    {
        return IS_MALE;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if this animal can breed
     * @return false if this animal can not breed
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Set the breeding age of an animal
     * @param breedingAge The age an animal can breed.
     */
    protected void setBreedingAge(int breedingAge)
    {
        BREEDING_AGE = breedingAge;
    }

    /**
     * Set the maximum age of an animal
     * @param maxAge The maximum age an animal can live.
     */
    protected void setMaxAge(int maxAge)
    {
        MAX_AGE = maxAge;
    }

    /**
     * @return MAX_AGE The maximum age of an animal
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Set the breeding probability of an animal
     * @param probability The likelihood of animal breeding
     */
    protected void setBreedingProbability(double probability)
    {
        BREEDING_PROBABILITY = probability;
    }

    /**
     * Set the maximum litter size of an animal
     * @param size The maximum number of births.
     */
    protected void setLitterSize(int size)
    {
        MAX_LITTER_SIZE = size;
    }

    /**
     * Set the food level of an animal
     * @param food level The food level of an animal.
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }

    /**
     * Set the age of an animal
     * @param age The age of an animal.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Set the eating food value of an animal.
     * Animals can only eat food when their foodLevel <= eatingFoodValue 
     * @param eatingFoodValue The eating food value.
     */
    protected void setEatingFoodValue(int eatingFoodValue)
    {
        this.eatingFoodValue = eatingFoodValue;
    }

    /**
     * @return foodLevel The food level of an animal
     */
    protected int getFoodValue()
    {
        return foodLevel;
    }

    /**
     * @return eatingFoodLevel The eating food level of an animal
     */
    protected int getEatingFoodValue()
    {
        return eatingFoodValue;
    }

    /**
     * @return time A Time object which indicate the time of a day
     */
    protected Time getTimeObject()
    {
        return time;
    }

    /**
     * Find the time of a day.
     * It is used when a new animal is born.
     * This method takes the largest hours from other animals 
     * at adjacent locations.
     */
    protected void findTimeOfDay()
    {

        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {

            Object object = getField().getObjectAt(it.next());
            if(object instanceof Animal) {
                Animal animal = (Animal) object;

                if(timeOfDay<animal.getTimeObject().getTime()){
                    timeOfDay = animal.getTimeObject().getTime();
                }

            }

        }

    }

    /**
     * @return timeOfDay Hours of a day
     */
    protected int getTimeOfDay()
    {
        return timeOfDay;
    }

    /**
     * @return disease A Disease object which indicate the disease
     */
    protected Disease getDiseaseObject()
    {
        return disease;
    }

}
