import java.util.Random;
/**
 * A class representing disease.
 *
 * @version 2021.03.01
 */
public class Disease
{
    //indicate if an animal is infected by the disease
    private boolean isInfected;
    //The likelihood of the infection of the disease
    private double DISEASE_PROBABILITY;
    // A shared random number generator to control infection.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create the disease. 
     * Initially no animal is infected.
     */
    public Disease()
    {
        isInfected = false;
        DISEASE_PROBABILITY = 0.000000000001;
    }
    
    /**
     * Check whether or not this animal should be infected.
     * if yes, infect the animal. 
     */
    public void infection()
    {
        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            isInfected = true;
        }
    }

    /**
     * @return If the animal is infected.
     */
    public boolean getIsInfected()
    {
        return isInfected;
    }
    
    
}
