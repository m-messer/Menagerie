import java.util.Random;
/**
 * A class representing the weather.
 *
 * @version 2021.03.01
 */
public class Weather
{
    //indicate if it is raining
    private boolean isRaining;
    //The likelihood of the raining
    private static final double RAINING_PROBABILITY = 0.7;
    // A shared random number generator to control raining.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create the weather. 
     * Initially it is not raining.
     */
    public Weather()
    {
        isRaining = false;
    }
    
    /**
     * Check whether or not it should rain.
     * if yes, rain. 
     */
    public void rain()
    {
        if(rand.nextDouble() <= RAINING_PROBABILITY){
            isRaining = true;
        }
    }

    /**
     * @return If it is raining.
     */
    public boolean getIsRaining()
    {
        return isRaining;
    }
}
