import java.util.List;
import java.util.Iterator;
/**
 * A simple model of a grass.
 * Grasses grow, spread and die.
 *
 * @version 2021.03.01
 */
public class Grass extends Plants
{
    private Weather weather;
    
    /**
     * Create a new grass at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
        setMaxPlantFoodLevel(100);
        setPlantFoodLevel(20);
        weather = new Weather();
    }
    
    /**
     * This is what the grass does most of the time: it grows and increase its plant food level. 
     * In the process, it might die of lack of water
     * While it is raining, plants can spread out into the free adjacent locations and increase its water level.
     * @param newPlants A list to return newly born plants.
     */
    public void act(List<Actor> newPlants)
    {
        weather.rain();
        boolean isRaining = weather.getIsRaining();
        decreaseWaterLevel();
        increasePlantFoodLevel();
        
        //spread out into the free adjacent locations
        if(isAlive() && isRaining){
            List<Location> freeAdjacent = getField().getFreeAdjacentLocations(getLocation());
            Iterator<Location> it = freeAdjacent.iterator();
            while(it.hasNext()) {
                Location location = it.next();
                Grass grass = new Grass(getField(), location);
                newPlants.add(grass);
            }
            increaseWaterLevel();
        }
    }
}
