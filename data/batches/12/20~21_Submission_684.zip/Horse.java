import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a horse.
 *
 * @version 2021.03.01
 */
public class Horse extends Animal
{
    //the food level a predator can gain when a horse is ate
    private int horseFoodLevel;
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new horse. A horse may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the horse will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Horse(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
        horseFoodLevel = 30;
        setBreedingAge(1);
        setMaxAge(100);
        setBreedingProbability(0.2);
        setLitterSize(1);
        setGender();
        setEatingFoodValue(1);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(100));
        }
        else {
            setAge(0);
            setFoodLevel(100);
            
        }
    }

    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        if (getFoodValue() <= getEatingFoodValue()){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                if(actor instanceof Grass) {
                    Grass grass = (Grass) actor;
                    if(grass.isAlive()) { 
                        grass.setDead();
                        setFoodLevel(grass.getPlantFoodLevel());
                        return where;

                    }
                }
            }
        }
        return null;
    }

    /**
     *Check whether or not this horse is adjacent to a different gender horse to breed
     *@return true if founded, or false if not
     */
    public boolean findPairs()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Object animal = field.getObjectAt(it.next());
            if(animal instanceof Horse) {
                Horse horse = (Horse) animal;
                if(horse.isAlive() && horse.getGender()) { 
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this horse is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHorses A list to return newly born horses.
     */
    public void giveBirth(List<Actor> newHorses)
    {
        // New horses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Horse young = new Horse(false, field, loc);
            young.findTimeOfDay();
            //set the time of the new born horse the same as others
            young.getTimeObject().setTime(young.getTimeOfDay());
            newHorses.add(young);
        }
    }

    /**
     * @return horseFoodLevel The food level a predator can gain when a horse is ate
     */
    public int getHorseFoodLevel()
    {
        return horseFoodLevel;
    }
}
