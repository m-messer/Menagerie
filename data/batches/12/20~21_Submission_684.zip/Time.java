
/**
 * A class representing the time of a day from 0 to 24.
 *
 * @version 2021.03.01
 */
public class Time
{
    private int time; //hours

    /**
     * Create the time. 
     * Initially it is 0.
     */
    public Time()
    {
        time = 0;
    }

    /**
     * @return The time of a day.
     */
    public int getTime()
    {
        return time;
    }
    
    /**
     * Set the time.
     * @param time int between 0 and 24
     */
    public void setTime(int time)
    {
        this.time = time;
    }
    
    /**
     * Increase the time.
     */
    public void incrementTime()
    {
        if (time == 24){
            time = 3;
        }
        else{
            time+=3;
        }
    }
}
