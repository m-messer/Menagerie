import java.util.Random;

/**
 * A class representing shared characteristics of wheathers.
 * There are three kinds of weather (sunny, rainny, and foggy),
 * and the possibilities of each weather occurs are 0.5, 0.4, 
 * and 0.1 respectively.
 * @version 2016.02.29 (2)
 */
public class Weather
{   
    private String weather;

    public Weather()
    {
        weather = "sunny";
    }

    /**
     * Show the weather of a day, there are three different kinds of
     * weather which are sunny, rainny, and foggy.
     */
    public String getWeather()
    {
        if(Randomizer.getRandom().nextDouble() <= 0.5) {
            weather = "sunny";  // Sunny day has no influence, it is just a normal day.
        }
        else if(Randomizer.getRandom().nextDouble() > 0.5 && Randomizer.getRandom().nextDouble() <= 0.9) {
            weather = "rainny";  // Rainny day causes grass grow at a faster rate.
        }
        else if(Randomizer.getRandom().nextDouble() > 0.9) {
            weather = "foggy";  // Foggy day makes predators less likely to pery successfully.
        }
        return weather;
    }
}
