import java.util.List;
import java.lang.Math;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Creature
{   
    
    // sex of an animal, 0 = female and 1 = male
    private int sex;
    
    // The amount of oxygen an animal need to survive
    protected static final double ANIMAL_OXYGEN_REQUIRED = 0.0002;
    // The possibility that an animal may be infected by a disease.
    protected static final double INFECTION_RATE = 0.4;
    // The possibility an animal may die of a disease.
    protected static final double MORTALITY_RATE = 0.06;
    // The steps an animal need to withstand in order to get immunity
    protected static final int stepStandNum = 3;
    
    // If the animal is infected by disease.
    private boolean isInfected;
    // If the animal is immuned from the diease.
    private boolean isImmuned;
  
    
    
  
    public Animal(Field field, Location location){
        super(field, location);
        sex = (int)(Math.round(Math.random()));
        isInfected = false;
        isImmuned = false;
    }
    
    public int getSex(){
        return sex;
    }
    
    public abstract boolean encounterWithDiffSex();
    
    public abstract Location findFood();
    
    /**
     * identify if a creature need to sleep
     * 
     * return true if currently it is night.
     */
    public boolean needSleep(boolean atDayTime){
        return !atDayTime;
    }
 
    
    
    /**
     * get if an animal is infected.
     * 
     */
        public boolean getIsInfected(){
        return isInfected;
    }
    
     /**
     * get if an animal is immuned.
     * 
     */
    public boolean getIsImmuned(){
        return isImmuned;
    }
    
    /**
     * 
     */
    public void setIsInfected(boolean bl){
        isInfected = bl;
    }
    
    /**
     * 
     */
    public void setIsImmuned(boolean bl){
        isImmuned = bl;
    }
    
    
}
