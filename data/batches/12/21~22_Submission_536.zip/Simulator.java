import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing predators and preys.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that an creature will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.1;
    private static final double HAYENA_CREATION_PROBABILITY = 0.022;
    private static final double RAT_CREATION_PROBABILITY = 0.35; 
    private static final double DEER_CREATION_PROBABILITY = 0.02; 
    private static final double WOLF_CREATION_PROBABILITY = 0.021; 
    private static final double PANTHER_CREATION_PROBABILITY = 0.01;
    
    // List of creatures in the field.
    private List<Creature> creatures;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The current day of the simulation.
    private int day;
    // The current state of the time of a day.
    private String time;
    // The current state of the weather of a day.
    private Weather weather;
    private String weatherType;
    // The state of the disease.
    private Disease disease;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        creatures = new ArrayList<>();
        weather = new Weather();
        disease = new Disease();
        field = new Field(depth, width, weather);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Rat.class, Color.ORANGE);
        view.setColor(Deer.class, Color.YELLOW);
        view.setColor(Hayena.class, Color.RED);
        view.setColor(Wolf.class, Color.GRAY);
        view.setColor(Panther.class, Color.BLACK);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep()
    {
        step++;
        day = step / 3; // One day consists of three steps.
        weatherType = weather.getWeather();
        disease.startOfDisease(creatures);
        // Provide space for newborn creatures
        List<Creature> newCreatures = new ArrayList<>();
        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
            Creature creature = it.next();
            if (getTime().equals("night") && creature.isNightAnimal()) {
                creature.act(newCreatures, disease);
            }
            if (!getTime().equals("night")) {
                creature.act(newCreatures, disease);
            }
            if(!creature.isAlive()) {
                it.remove();
            }
        }
        
        // Add the newly born creatures to the main lists.
        creatures.addAll(newCreatures);
        
        view.showStatus(step, time, weatherType, Animal.animalsDieOfDisease, field);
    }
    
    /**
     * Show the time period of a day, there are three periods which
     * are morning, afternoon, and night.
     */
    public String getTime()
    {
        if(step % 3 == 2) {
            time = "night";
        }
        else if(step % 3 == 1) {
            time = "afternoon";
        }
        else if(step % 3 == 0) {
            time = "morning";
        }
        return time;
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        day = 0;
        time = "morning";
        weatherType = "sunny";
        Animal.animalsDieOfDisease = 0;
        creatures.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, time, weatherType, Animal.animalsDieOfDisease, field);
    }
    
    /**
     * Randomly populate the field with creatures.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    creatures.add(grass);
                }
                else if(rand.nextDouble() <= HAYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hayena hayena = new Hayena(true, field, location);
                    creatures.add(hayena);
                }
                else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(true, field, location);
                    creatures.add(rat);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    creatures.add(wolf);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    creatures.add(deer);
                }
                else if(rand.nextDouble() <= PANTHER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Panther panther = new Panther(true, field, location);
                    creatures.add(panther);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
