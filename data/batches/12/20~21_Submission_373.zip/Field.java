import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Represent a rectangular grid of field positions.
 * Each position is able to store a single animal.
 *
 * @version 2016.02.29
 */
public class Field
{
	// A random number generator for providing random locations.
	private static final Random rand = Randomizer.getRandom();

	// The depth and width of the field.
	private int depth, width;
	// Storage for the actors.
	private Cell[][] field;
	//EnvironmentalConditions object applied to this field.
	private EnvironmentalConditions environmentalConditions;

	/**
	 * Represent a field of the given dimensions.
	 *
	 * @param depth                   The depth of the field.
	 * @param width                   The width of the field.
	 * @param environmentalConditions The EnvironmentalConditions object applied to this field.
	 */
	public Field(int depth, int width, EnvironmentalConditions environmentalConditions)
	{
		this.depth = depth;
		this.width = width;
		this.environmentalConditions = environmentalConditions;
		field = new Cell[depth][width];

		for (int i = 0; i < depth; i++) {
			for (int j = 0; j < width; j++) {
				field[i][j] = new Cell();
			}
		}
	}

	/**
	 * Empty the field.
	 */
	public void clear()
	{
		for (int row = 0; row < depth; row++) {
			for (int col = 0; col < width; col++) {
				field[row][col].clear();
			}
		}
	}

	/**
	 * Clear the given location.
	 *
	 * @param location The location to clear.
	 */
	public void clear(Actor actor, Location location)
	{
		field[location.getRow()][location.getCol()].clear(actor);
	}

	public void clean(Location location)
	{
		field[location.getRow()][location.getCol()].clean();
	}

	/**
	 * Place an animal at the given location.
	 * If there is already an animal at the location it will
	 * be lost.
	 *
	 * @param actor The animal to be placed.
	 * @param row   Row coordinate of the location.
	 * @param col   Column coordinate of the location.
	 */
	public void place(Actor actor, int row, int col)
	{
		place(actor, new Location(row, col));
	}

	/**
	 * Place an animal at the given location.
	 * If there is already an animal at the location it will
	 * be lost.
	 *
	 * @param actor    The animal to be placed.
	 * @param location Where to place the animal.
	 */
	public void place(Actor actor, Location location)
	{
		field[location.getRow()][location.getCol()].place(actor);
	}

	/**
	 * Return the animal at the given location, if any.
	 *
	 * @param location Where in the field.
	 * @return The animal at the given location, or null if there is none.
	 */
	public Animal getAnimalAt(Location location)
	{
		return getAnimalAt(location.getRow(), location.getCol());
	}

	/**
	 * Return the animal at the given location, if any.
	 *
	 * @param row The desired row.
	 * @param col The desired column.
	 * @return The animal at the given location, or null if there is none.
	 */
	public Animal getAnimalAt(int row, int col)
	{
		return field[row][col].getAnimal();
	}

	/**
	 * Return the Plant stored at a given location
	 *
	 * @param location the location we want to obtain the plant from
	 * @return the Plant stored (in a Cell) at a given location - null if there is none.
	 */
	public Plant getPlantAt(Location location)
	{
		return getPlantAt(location.getRow(), location.getCol());
	}

	/**
	 * Return the Plant located at given coordinates
	 *
	 * @param row The row of the location we want to obtain the plant from
	 * @param col The column of the location we want to obtain the plant from
	 * @return the Plant stored (in a Cell) at a given location - null if there is none.
	 */
	public Plant getPlantAt(int row, int col)
	{
		return field[row][col].getPlant();
	}

	/**
	 * Generate a random location that is adjacent to the
	 * given location, or is the same location.
	 * The returned location will be within the valid bounds
	 * of the field.
	 *
	 * @param location The location from which to generate an adjacency.
	 * @return A valid location within the grid area.
	 */
	public Location randomAdjacentLocation(Location location)
	{
		List<Location> adjacent = adjacentLocations(location);
		return adjacent.get(0);
	}

	/**
	 * Get a shuffled list of the free adjacent locations.
	 *
	 * @param location Get locations adjacent to this.
	 * @return A list of free adjacent locations.
	 */
	public List<Location> getAdjacentLocationsFreeFromAnimals(Location location)
	{
		List<Location> free = new LinkedList<>();
		List<Location> adjacent = adjacentLocations(location);
		for (Location next : adjacent) {
			if (getAnimalAt(next) == null) {
				free.add(next);
			}
		}
		return free;
	}

	/**
	 * Get a shuffled list of the free adjacent locations.
	 *
	 * @param location Get locations adjacent to this.
	 * @return A list of free adjacent locations.
	 */
	public List<Location> getAdjacentLocationsFreeFromPlants(Location location)
	{
		List<Location> free = new LinkedList<>();
		List<Location> adjacent = adjacentLocations(location);
		for (Location next : adjacent) {
			if (getPlantAt(next) == null) {
				free.add(next);
			}
		}
		return free;
	}

	/**
	 * Get a shuffled list of the free adjacent locations.
	 *
	 * @param location Get locations adjacent to this.
	 * @return A list of free adjacent locations.
	 */
	public List<Location> getAdjacentLocationsFreeFromPlants(Location location, int radius)
	{
		List<Location> free = new LinkedList<>();
		List<Location> adjacent = adjacentLocations(location, radius);
		for (Location next : adjacent) {
			if (getPlantAt(next) == null) {
				free.add(next);
			}
		}
		return free;
	}

	/**
	 * Try to find a free location that is adjacent to the
	 * given location. If there is none, return null.
	 * The returned location will be within the valid bounds
	 * of the field.
	 *
	 * @param location The location from which to generate an adjacency.
	 * @return A valid location within the grid area.
	 */
	public Location adjacentLocationFreeFromAnimals(Location location)
	{
		// The available free ones.
		List<Location> free = getAdjacentLocationsFreeFromAnimals(location);
		if (free.size() > 0) {
			return free.get(0);
		} else {
			return null;
		}
	}

	/**
	 * Try to find a free location that is adjacent to the
	 * given location. If there is none, return null.
	 * The returned location will be within the valid bounds
	 * of the field.
	 *
	 * @param location The location from which to generate an adjacency.
	 * @return A valid location within the grid area.
	 */
	public Location adjacentLocationFreeFromPlants(Location location)
	{
		// The available free ones.
		List<Location> free = getAdjacentLocationsFreeFromPlants(location);
		if (free.size() > 0) {
			return free.get(0);
		} else {
			return null;
		}
	}

	/**
	 * Return a shuffled list of locations adjacent to the given one.
	 * The list will not include the location itself.
	 * All locations will lie within the grid.
	 *
	 * @param location The location from which to generate adjacencies.
	 * @return A list of locations adjacent to that given.
	 */
	public List<Location> adjacentLocations(Location location)
	{
		assert location != null : "Null location passed to adjacentLocations";
		// The list of locations to be returned.
		List<Location> locations = new LinkedList<>();
		if (location != null) {
			int row = location.getRow();
			int col = location.getCol();
			for (int roffset = -1; roffset <= 1; roffset++) {
				int nextRow = row + roffset;
				if (nextRow >= 0 && nextRow < depth) {
					for (int coffset = -1; coffset <= 1; coffset++) {
						int nextCol = col + coffset;
						// Exclude invalid locations and the original location.
						if (nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
							locations.add(new Location(nextRow, nextCol));
						}
					}
				}
			}

			// Shuffle the list. Several other methods rely on the list
			// being in a random order.
			Collections.shuffle(locations, rand);
		}
		return locations;
	}

	/**
	 * Return a shuffled list of locations within the given square radius.
	 * The list will not include the location itself.
	 * All locations will lie within the grid.
	 *
	 * @param location The location from which to generate adjacencies.
	 * @param radius   The square radius of the search.
	 * @return A list of locations adjacent to that given.
	 */
	public List<Location> adjacentLocations(Location location, int radius)
	{
		assert location != null : "Null location passed to adjacentLocations";
		// The list of locations to be returned.
		List<Location> locations = new LinkedList<>();
		if (location != null) {
			int row = location.getRow();
			int col = location.getCol();
			for (int roffset = -radius; roffset <= radius; roffset++) {
				int nextRow = row + roffset;
				if (nextRow >= 0 && nextRow < depth) {
					for (int coffset = -radius; coffset <= radius; coffset++) {
						int nextCol = col + coffset;
						// Exclude invalid locations and the original location.
						if (nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
							locations.add(new Location(nextRow, nextCol));
						}
					}
				}
			}

			// Shuffle the list. Several other methods rely on the list
			// being in a random order.
			Collections.shuffle(locations, rand);
		}
		return locations;
	}

	/**
	 * Return the depth of the field.
	 *
	 * @return The depth of the field.
	 */
	public int getDepth()
	{
		return depth;
	}

	/**
	 * Return the width of the field.
	 *
	 * @return The width of the field.
	 */
	public int getWidth()
	{
		return width;
	}

	/**
	 * @return The EnvironmentalConditions object applied to this field.
	 */
	public EnvironmentalConditions getEnvironmentalConditions()
	{
		return environmentalConditions;
	}

}
