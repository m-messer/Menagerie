import java.util.HashMap;
import java.util.Set;

/**
 * A class that keeps track of the death which occurred in the simulation.
 *
 * @version 2021.02
 */
public class DeathTracker
{
	private static DeathTracker singleton;
	//The deaths consisting of species, the cause of the death, and the number of animal concerned by each cause.
	private HashMap<Class, HashMap<String, Integer>> deaths;

	/**
	 * Create a new DeathTracker
	 */
	private DeathTracker()
	{
		deaths = new HashMap<>();
	}

	/**
	 * Compares this animal with the given argument.
	 *
	 * @return true if both animals are of the same species
	 */
	public static DeathTracker getDeathTracker()
	{
		if (singleton == null) {
			singleton = new DeathTracker();
		}
		return singleton;
	}

	/**
	 * Add a death to be stored in the DeathTracker
	 *
	 * @param actorClass   The class of the actor that died.
	 * @param causeOfDeath The
	 */
	public void addDeath(Class actorClass, String causeOfDeath)
	{
		HashMap<String, Integer> actorsDeaths = deaths.get(actorClass);
		if (actorsDeaths == null) {
			actorsDeaths = new HashMap<>();
			deaths.put(actorClass, actorsDeaths);
		}
		Integer deathsNumber = actorsDeaths.get(causeOfDeath);
		if (deathsNumber == null) {
			deathsNumber = 0;
		}
		deathsNumber++;
		actorsDeaths.put(causeOfDeath, deathsNumber);
	}

	/**
	 * Print information about the deaths occured during the simulation.
	 * It prints the causes of the death, and the number of animals concerned by each cause for each species.
	 */
	public void printDeaths()
	{
		Set<Class> animalsClasses = deaths.keySet();
		System.out.println("Causes of death:");
		for (Class animalClass : animalsClasses) {
			HashMap<String, Integer> actorsDeaths = deaths.get(animalClass);
			Set<String> animalsCausesOfDeaths = actorsDeaths.keySet();
			System.out.println(animalClass.getName() + ":");
			for (String animalCauseOfDeath : animalsCausesOfDeaths) {
				System.out.printf("    Cause: %17s, number %6d\n", animalCauseOfDeath,
						actorsDeaths.get(animalCauseOfDeath));
			}
		}
	}
}   
