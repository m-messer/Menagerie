import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing an animal
 *
 * @version 2021.02
 */
public abstract class Animal extends Actor
{
	//Whether the animal is a male or not (= a female)
	private boolean isMale;
	//The age of the animal
	private int age;
	//The amount of food of an animal. It increase when eating, and decrease when hungrying.  
	private int foodLevel;

	private static final Random rand = Randomizer.getRandom();

	/**
	 * Create a new animal at a location in field.
	 *
	 * @param field                The field currently occupied
	 * @param location             The location within the field
	 * @param maxAge               The max age of a new animal
	 * @param maxStartingFoodLevel The max starting foodLevel of a new animal (= a limit for the
	 *                                random starting foodLevel)
	 * @param randomAge            A random age assigned to the new animal.
	 */
	public Animal(Field field, Location location, int maxAge, int maxStartingFoodLevel, boolean randomAge)
	{
		super(field, location);
		isMale = rand.nextBoolean();
		if (randomAge) {
			age = rand.nextInt(maxAge);
			this.foodLevel = rand.nextInt(maxStartingFoodLevel);
		} else {
			age = 0;
			this.foodLevel = maxStartingFoodLevel;
		}
	}

	/**
	 * Look for prey adjacent to the current location.
	 *
	 * @return Where food was found, or null if it wasn't.
	 */
	protected Location findFood()
	{
		Field field = getField();
		List<Location> huntable = getHuntableLocations();
		Iterator<Location> it = huntable.iterator();
		while (it.hasNext()) {
			Location where = it.next();
			if (tryEating(field.getAnimalAt(where)) || tryEating(field.getPlantAt(where))) {
				return where;
			}
		}
		return null;
	}

	/**
	 * @return A list of the adjacent locations
	 */
	protected List<Location> getHuntableLocations()
	{
		return getField().adjacentLocations(getLocation());
	}

	/**
	 * Attempts to eat the actor. If eating is successful, return true.
	 *
	 * @param actor The actor to be eaten.
	 */
	private boolean tryEating(Actor actor)
	{
		int actorFoodValue = getFoodValue(actor);
		if (actorFoodValue > 0 && actor.isAlive() && actor.isEdible()) {
			actor.setDead();
			DeathTracker.getDeathTracker().addDeath(actor.getClass(), "consumed by " + this.getClass().getName());
			foodLevel += actorFoodValue;
			return true;
		}
		return false;
	}

	/**
	 * Returns the current food level of the Animal.
	 */
	public int getFoodLevel()
	{
		return foodLevel;
	}

	/**
	 * Increase the age. This could result in the animal's death.
	 */
	protected void incrementAge()
	{
		age++;
		if (age > getMaxAge()) {
			setDead();
			DeathTracker.getDeathTracker().addDeath(this.getClass(), "age");
		}
	}

	/**
	 * Make this human more hungry. This could result in the animal's death.
	 */
	protected void incrementHunger()
	{
		foodLevel--;
		if (foodLevel <= 0) {
			setDead();
			DeathTracker.getDeathTracker().addDeath(this.getClass(), "starvation");
		}
	}

	/**
	 * Returns the age of the animal.
	 */
	public int getAge()
	{
		return age;
	}

	/**
	 * Returns true if the animal is male.
	 */
	public boolean isMale()
	{
		return isMale;
	}


	/**
	 * This is what the animal does once every step.
	 * It always moves, ages, and gets more hungry.
	 * Also, it might eat, breed, give birth, or die.
	 *
	 * @param newActors A list to return newly born actors.
	 */
	public void act(List<Actor> newActors)
	{
		incrementAge();
		incrementHunger();
		if (isAlive() && !isSleeping()) {
			giveBirth(newActors);
			// Move towards a source of food if found.
			Location newLocation = !isWellFed() ? findFood() : null;
			if (newLocation == null) {
				// No food found - try to move to a free location.
				newLocation = getField().adjacentLocationFreeFromAnimals(getLocation());
			}
			// See if it was possible to move.
			if (newLocation != null) {
				setLocation(newLocation);
			} else {
				// Overcrowding.
				setDead();
				DeathTracker.getDeathTracker().addDeath(this.getClass(), "overcrowding");
			}
		}
	}

	/**
	 * @return true if the animal has enough food to live until its death ; return false otherwise.
	 */
	private boolean isWellFed()
	{
		return (getMaxAge() - getAge()) < getFoodLevel();
	}

	/**
	 * Generate a number representing the number of births, if it can breed.
	 *
	 * @return The number of births (may be zero).
	 */
	private int breed()
	{
		int births = 0;
		if (canBreed() && rand.nextDouble() <= getBreedingProbability()) {
			births = rand.nextInt(getMaxLitterSize()) + 1;
		}
		return births;
	}


	/**
	 * Check whether or not this animal is to give birth at this step. New births
	 * will be made into free adjacent locations.
	 *
	 * @param newYoungs A list to return newly born animals.
	 */
	public void giveBirth(List<Actor> newYoungs)
	{
		// New animal are born into adjacent locations.
		// Get a list of adjacent free locations.
		Field field = getField();
		List<Location> locations = field.adjacentLocations(getLocation(), getBreedingRadius());
		for (Location location : locations) {
			Animal partner = field.getAnimalAt(location);
			if (partner != null && partner.isSameSpecies(this)
					&& partner.isMale() != this.isMale()) {
				List<Location> free = field.getAdjacentLocationsFreeFromAnimals(location);
				int births = breed();
				for (int b = 0; b < births && free.size() > 0; b++) {
					Location loc = free.remove(0);
					Actor young = produceYoung(field, loc);
					newYoungs.add(young);
				}
				break;
			}
		}

	}

	/**
	 * Compares this animal with the given argument.
	 *
	 * @param animal the animal to compare with
	 * @return true if both animal are of the same species.
	 */
	protected abstract boolean isSameSpecies(Animal animal);

	/**
	 * @return the max age of the animal
	 */
	public abstract int getMaxAge();

	/**
	 * @return The breeding age of the animal
	 */
	public abstract int getBreedingAge();

	/**
	 * @return The breeding probability of the animal
	 */
	public abstract double getBreedingProbability();

	/**
	 * @return The max number of offsprings the animal can give birth to
	 */
	public abstract int getMaxLitterSize();

	/**
	 * @return The radius in which the animal can find a partner to breed with
	 */
	public abstract int getBreedingRadius();

	/**
	 * Returns the food value of the actor to this specific animal.
	 *
	 * @param food The actor to be eaten.
	 * @return The food value if the animal can eat it, 0 if the animal doesn't eat the actor.
	 */
	public abstract int getFoodValue(Actor food);

	/**
	 * Animal sleep during night-time
	 *
	 * @return true if the animal is sleeping, false otherwise.
	 */
	public boolean isSleeping()
	{
		return getField().getEnvironmentalConditions().isNight();
	}

	/**
	 * An animal can breed if it has reached the breeding age and if it is not sleeping.
	 *
	 * @return true if it can breed, flase otherwise.
	 */
	public boolean canBreed()
	{
		return age >= getBreedingAge() && !isSleeping();
	}
}
