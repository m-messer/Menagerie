
import java.util.HashMap;

/**
 * A simple model of a Wolf.
 * Wolf's age, move, eat hares, and die.
 *
 * @version 2021.02
 */

public class Wolf extends Animal
{
	// Characteristics shared by all wolves (class variables).

	// The age at which a wolf can start to breed.
	private static final int BREEDING_AGE = 15;
	// The age to which a wolf can live.
	private static final int MAX_AGE = 80;
	// The likelihood of a wolf breeding.
	private static final double BREEDING_PROBABILITY = 0.083;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 2;
	// The maximum radius in which to look for a partner
	private static final int BREEDING_RADIUS = 5;
	// A shared random number generator to control breeding.
	//private static final Random rand = Randomizer.getRandom();
	// The amount of food that the Wolf gets by eating a specific animal is stored in a Map.
	private static final HashMap<Class, Integer> FOOD_TABLE;

	static {
		FOOD_TABLE = new HashMap<>();
		FOOD_TABLE.put(Hare.class, 9);
		FOOD_TABLE.put(Rat.class, 5);
	}

	//The starting foodLevel of a new owl.
	private static final int STARTING_FOOD_VALUE = 9;

	/**
	 * Create a wolf. A wolf can be created as a new born (age zero
	 * and not hungry) or with a random age and food level.
	 *
	 * @param randomAge If true, the wolf will have random age and hunger level.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Wolf(boolean randomAge, Field field, Location location)
	{
		super(field, location, MAX_AGE, STARTING_FOOD_VALUE, randomAge);
	}

	/**
	 * Create and return a newborn wolf.
	 *
	 * @param field    The field that the new wolf should be placed in.
	 * @param location The location of the new wolf.
	 * @return A new wolf.
	 */
	protected Actor produceYoung(Field field, Location location)
	{
		return new Wolf(false, field, location);
	}

	/**
	 * Compares this wolf with the given argument.
	 *
	 * @param animal the animal to compare with
	 * @return true if the animal is a wolf.
	 */
	protected boolean isSameSpecies(Animal animal)
	{
		return animal instanceof Wolf;
	}

	/**
	 * @return the max age of wolves
	 */
	public int getMaxAge()
	{
		return MAX_AGE;
	}

	/**
	 * @return the breeding age of wolves
	 */
	public int getBreedingAge()
	{
		return BREEDING_AGE;
	}

	/**
	 * The breeding probability of wolves
	 */
	public double getBreedingProbability()
	{
		return BREEDING_PROBABILITY;
	}

	/**
	 * @return the maximum number of offsprings a wolf can give birth to.
	 */
	public int getMaxLitterSize()
	{
		return MAX_LITTER_SIZE;
	}

	/**
	 * The breeding radius of wolves.
	 */
	public int getBreedingRadius()
	{
		return BREEDING_RADIUS;
	}

	/**
	 * Return the food value of wolves for a given prey.
	 *
	 * @param food the prey wolves can eat
	 * @return the food value of wolves for the given prey
	 */
	public int getFoodValue(Actor food)
	{
		if (food == null) {
			return 0;
		}
		Class foodClass = food.getClass();
		if (FOOD_TABLE.containsKey(foodClass)) {
			return FOOD_TABLE.get(foodClass);
		} else {
			return 0;
		}
	}
}
