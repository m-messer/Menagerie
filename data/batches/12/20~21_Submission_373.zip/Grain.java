/**
 * A class representing a Grain.
 *
 * @version 2021.02
 */
public class Grain extends Plant
{

	//The spread probability of a grain. 
	private static final double SPREAD_PROBABILITY = 0.5;

	/**
	 * Create a new grain.
	 *
	 * @param randomGrowth if true, the grain will be assigned a random growth
	 * @param field        The field  where the grain will be located in.
	 * @param location     The location within the field.
	 */
	public Grain(boolean randomGrowth, Field field, Location location)
	{
		super(randomGrowth, field, location);
	}

	/**
	 * @return the spreading probability of grains.
	 */
	public double getSpreadProbability()
	{
		return SPREAD_PROBABILITY;
	}

	/**
	 * Create and return a new spread grain.
	 *
	 * @param field    The field that the new grain should be placed in.
	 * @param location The location of the new grain.
	 * @return A new grain.
	 */
	public Actor produceYoung(Field field, Location location)
	{
		return new Grain(false, field, location);
	}
}
