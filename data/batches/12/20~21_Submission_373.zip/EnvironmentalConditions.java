import java.util.Random;

/**
 * A class representing the environmental conditions of the field.
 */
public class EnvironmentalConditions
{
	//The probability of raining
	private static final double RAIN_PROBABILITY = 0.4;
	//The max time (in step) a rainy period can last. 
	private static final int MAX_RAIN_TIME = 10;

	//The default duration of a day
	private static final int DEFAULT_DAY_DURATION = 10;

	//Times that define that start end end of night, measured in hours (the whole day is 24 hours).
	private static final double NIGHT_START_TIME = 20;
	private static final double NIGHT_END_TIME = 7;

	//The duration of a day (number of steps)
	private int dayDuration;
	//The current step (similar to the hour of the day)
	private int currentStep;
	//Whether it is raining or not. 
	private boolean isRaining;
	//The duration of a specific rainy period (cannot exceed the MAX_RAIN_TIME)
	private int rainTimer;

	private Random rand;

	/**
	 * Create an EnvironmentalConditions object if no dayDuration is specified
	 * (therefore, the default day duration is assigned to the day duration)
	 */
	public EnvironmentalConditions()
	{
		this(DEFAULT_DAY_DURATION);
	}

	/**
	 * Create an an EnvironmentalConditions object if a dayDuration is specified
	 *
	 * @param dayDuration The duration of a day
	 */
	public EnvironmentalConditions(int dayDuration)
	{
		rand = Randomizer.getRandom();
		this.dayDuration = dayDuration;
		currentStep = (int) (NIGHT_END_TIME / 24 * dayDuration) + 1;
		setRaining();
	}

	/**
	 * @return true if it is night, false otherwise
	 */
	public boolean isNight()
	{
		double currentTime = getCurrentTime();
		return currentTime >= NIGHT_START_TIME || currentTime < NIGHT_END_TIME;
	}

	/**
	 * Increment a step (similar to incrementing an hour to a clock)
	 */
	public void increment()
	{
		currentStep++;
		if (currentStep > dayDuration) {
			currentStep = 0;
		}
		setRaining();
	}

	/**
	 * @return the current time according to a 24-hour clock
	 */
	public double getCurrentTime()
	{
		return (1.0 * currentStep / dayDuration) * 24;
	}

	/**
	 * Decrement the rainTimer and, if it is not raining yet, then set raining.
	 */
	private void setRaining()
	{
		rainTimer--;
		if (rainTimer <= 0) {
			isRaining = rand.nextDouble() < RAIN_PROBABILITY;
			rainTimer = rand.nextInt(MAX_RAIN_TIME);
		}
	}

	/**
	 * @return true if it's raining, false otherwise.
	 */
	public boolean isRaining()
	{
		return isRaining;
	}


}
