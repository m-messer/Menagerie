import java.util.List;
import java.util.Random;

/**
 * A class representing a plant.
 * Plants grow, spread, and might die if they are eaten.
 *
 * @version 2021.02
 */
public abstract class Plant extends Actor
{

	private static final Random rand = Randomizer.getRandom();
	//The max size of a plant; that is, the max number of stages of growth a plant can possibly reach
	private static final int MAX_SIZE = 7;
	//The radius in which plants can spread.
	private static final int SPREADING_RADIUS = 3;
	//The max number of stages of growth per tick (= step)
	private static final int MAX_GROWTH_PER_TICK = 5;
	//The amount of plants that can be spread by one plant
	private static final int SPREAD_AMOUNT = 5;
	//The number of growth stages.
	private int growth;


	/**
	 * Create a new plant.
	 *
	 * @param randomGrowth if true, the plant will be assigned a random growth
	 * @param field        The field  where the plant will be located in.
	 * @param location     The location within the field.
	 */
	public Plant(boolean randomGrowth, Field field, Location location)
	{
		super(field, location);
		if (randomGrowth) {
			growth = rand.nextInt(MAX_SIZE + 1);
		} else {
			growth = 0;
		}
	}

	/**
	 * Indicate that the plant is no longer alive.
	 * It is removed from the field.
	 * A plant dies when its growths has fell below 0
	 */
	public void setDead()
	{
		growth--;
		if (growth < 0) {
			super.setDead();
		}
	}

	/**
	 * This is what the plant does once every step.
	 * If is raining, and if it has not reached its maximum growth, then it grows.
	 * If it is raining, and it has reached its maximum growth, then it spreads.
	 *
	 * @param newPlants A list to return newly spread plants.
	 */
	public void act(List<Actor> newPlants)
	{
		if (isAlive() && getField().getEnvironmentalConditions().isRaining()) {
			if (rand.nextDouble() < getSpreadProbability()) {
				if (growth < MAX_SIZE) {
					grow();
				} else {
					spread(newPlants);
				}
			}
		}
	}

	/**
	 * A plant grows if it is raining and if it has not reached its maximum growth yet.
	 * Growing means incrementing the growth.
	 */
	private void grow()
	{
		if (getField().getEnvironmentalConditions().isRaining() && growth < MAX_SIZE) {
			growth += rand.nextInt(MAX_GROWTH_PER_TICK + 1);
		}
		if (growth > MAX_SIZE) {
			growth = MAX_SIZE;
		}
	}

	/**
	 * Spread. New plants will be made into free adjacent locations.
	 *
	 * @param newPlants A list to return new plants spread.
	 */
	private void spread(List<Actor> newPlants)
	{
		Field field = getField();
		;
		List<Location> free = field.getAdjacentLocationsFreeFromPlants(getLocation(), SPREADING_RADIUS);
		int spreadSize = getSpreadSize();
		for (int b = 0; b < spreadSize && free.size() > 0; b++) {
			Location loc = free.remove(0);
			Actor young = produceYoung(field, loc);
			newPlants.add(young);
		}
	}

	/**
	 * @return The amount of plants that can be spread by one plant
	 */
	private int getSpreadSize()
	{
		return SPREAD_AMOUNT;
	}

	/**
	 * @return The spread probability of a plant
	 */
	public abstract double getSpreadProbability();

	/**
	 * @return true if a plant can be eaten; false otherwise.
	 */
	public boolean isEdible()
	{
		return growth > 1;
	}
}
