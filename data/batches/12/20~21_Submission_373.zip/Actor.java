import java.util.List;

/**
 * A class representing shared characteristics of actors.
 *
 * @version 2021.02
 */
public abstract class Actor
{
	// Whether the actor is alive or not.
	private boolean isAlive;
	// The actor's field.
	private Field field;
	// The actor's position in the field.
	private Location location;

	/**
	 * Create a new actor at location in field.
	 *
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Actor(Field field, Location location)
	{
		isAlive = true;
		this.field = field;
		setLocation(location);
	}

	/**
	 * Make this actor act - that is: make it do
	 * whatever it wants/needs to do.
	 *
	 * @param newActors A list to receive newly born actor.
	 */
	abstract public void act(List<Actor> newActors);

	/**
	 * Check whether the actor is alive or not.
	 *
	 * @return true if the actor is still alive.
	 */
	protected boolean isAlive()
	{
		return isAlive;
	}

	/**
	 * Indicate that the actor is no longer alive.
	 * It is removed from the field.
	 */
	protected void setDead()
	{
		isAlive = false;
		if (location != null) {
			field.clean(location);
			location = null;
			field = null;
		}
	}

	/**
	 * Return the actor's location.
	 *
	 * @return The actor's location.
	 */
	protected Location getLocation()
	{
		return location;
	}

	/**
	 * Place the actor at the new location in the given field.
	 *
	 * @param newLocation The actor's new location.
	 */
	protected void setLocation(Location newLocation)
	{
		if (location != null) {
			field.clear(this, location);
		}
		location = newLocation;
		field.place(this, newLocation);
	}

	/**
	 * Return the actor's field.
	 *
	 * @return The actor's field.
	 */
	protected Field getField()
	{
		return field;
	}

	/**
	 * Create and return a newborn of the same class as the Actor.
	 *
	 * @param field    The field that the new Actor should be placed in.
	 * @param location The location of the new Actor.
	 * @return A new instance of the same class as the Actor.
	 */
	protected abstract Actor produceYoung(Field field, Location location);


	/**
	 * @return true if the actor (plant) can be eaten, false otherwise
	 */
	public boolean isEdible()
	{
		return true;
	}

}
