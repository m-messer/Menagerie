import java.util.List;
import java.util.HashMap;
import java.util.Random;

/**
 * A simple model of an owl.
 *
 * @version 2021.02
 */
public class Owl extends Animal
{
	// Characteristics shared by all wolves (class variables).

	// The age at which an owl can start to breed.
	private static final int BREEDING_AGE = 35;
	// The age to which a owl can live.
	private static final int MAX_AGE = 140;
	// The likelihood of a owl breeding.
	private static final double BREEDING_PROBABILITY = 0.055;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 2;
	// The maximum radius in which to look for a partner
	private static final int BREEDING_RADIUS = 7;
	// The amount of food that owl gets by eating a specific animal is stored in a Map.
	private static final HashMap<Class, Integer> FOOD_TABLE;

	static {
		FOOD_TABLE = new HashMap<>();
		FOOD_TABLE.put(Rat.class, 30);
	}

	//The starting foodLevel of a new owl.
	private static final int STARTING_FOOD_VALUE = 30;
	//The maximum radius in which to look for preys to hunt.
	private static final int HUNTING_RADIUS = 3;

	/**
	 * Create an owl. A owl can be created as a new born (age zero
	 * and not hungry) or with a random age and food level.
	 *
	 * @param randomAge If true, the owl will have random age and hunger level.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Owl(boolean randomAge, Field field, Location location)
	{
		super(field, location, MAX_AGE, STARTING_FOOD_VALUE, randomAge);
	}

	/**
	 * Create and return a newborn owl.
	 *
	 * @param field    The field that the new owl should be placed in.
	 * @param location The location of the new owl.
	 * @return A new owl.
	 */
	protected Actor produceYoung(Field field, Location location)
	{
		return new Owl(false, field, location);
	}

	/**
	 * Compares this owl with the given argument.
	 *
	 * @param animal the animal to compare with
	 * @return true if the animal is an owl.
	 */
	protected boolean isSameSpecies(Animal animal)
	{
		return animal instanceof Owl;
	}

	/**
	 * @return The max age of owls.
	 */
	public int getMaxAge()
	{
		return MAX_AGE;
	}

	/**
	 * @return the bredding age of owls.
	 */
	public int getBreedingAge()
	{
		return BREEDING_AGE;
	}

	/**
	 * @return the breeding probability of owls.
	 */
	public double getBreedingProbability()
	{
		return BREEDING_PROBABILITY;
	}

	/**
	 * @return the max number of offsprings owls can give birth to
	 */
	public int getMaxLitterSize()
	{
		return MAX_LITTER_SIZE;
	}

	/**
	 * @return the beeding radius of owls
	 */
	public int getBreedingRadius()
	{
		return BREEDING_RADIUS;
	}

	/**
	 * Return the food value of owls for a given prey.
	 *
	 * @param food the prey owls can eat
	 * @return the food value of owls for the given prey
	 */
	public int getFoodValue(Actor food)
	{
		if (food == null) {
			return 0;
		}
		Class foodClass = food.getClass();
		if (FOOD_TABLE.containsKey(foodClass)) {
			return FOOD_TABLE.get(foodClass);
		} else {
			return 0;
		}
	}

	/**
	 * Return whether an owl is sleeping or not
	 * Owls sleep during daytime (= when it is not night).
	 *
	 * @return true if the owl is sleeping, false otherwise
	 */
	public boolean isSleeping()
	{
		return !getField().getEnvironmentalConditions().isNight();
	}

	/**
	 * @return A list of adjacet locations (in which there might be preys to hunt)
	 */
	protected List<Location> getHuntableLocations()
	{
		return getField().adjacentLocations(getLocation(), HUNTING_RADIUS);
	}
}
