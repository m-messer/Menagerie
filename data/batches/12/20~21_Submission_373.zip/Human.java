import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a human.
 * Human age, move, eat hares and wolves, and die.
 *
 * @version 2021.02
 */
public class Human extends Animal
{
	// Characteristics shared by all humans (class variables).

	// The age at which a human can start to breed.
	private static final int BREEDING_AGE = 50;
	// The age to which a human can live.
	private static final int MAX_AGE = 300;
	// The likelihood of a human breeding.
	private static final double BREEDING_PROBABILITY = 0.05;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 1;
	// The maximum radius in which to look for a partner
	private static final int BREEDING_RADIUS = 9;
	// The amount of food that human gets by eating a specific animal is stored in a Map.
	private static final HashMap<Class, Integer> FOOD_TABLE;

	static {
		FOOD_TABLE = new HashMap<>();
		FOOD_TABLE.put(Hare.class, 12);
		FOOD_TABLE.put(Wolf.class, 22);
	}

	////The starting foodLevel of a new human.
	private static final int STARTING_FOOD_VALUE = 40;
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	//The time the human starts sleeping
	private static final int STARTING_SLEEPING_TIME = 21;
	//The time the human ends sleeping.
	private static final int ENDING_SLEEPING_TIME = 7;
	// The maximum radius in which an disease can propagate. 
	private static final int DISEASE_SPREAD_RADIUS = 2;
	//The probability for a disease to spread. 
	private static final double DISEASE_SPREAD_PROBABILITY = 0.1;
	//The probability for a human to die from disease. 
	private static final double DISEASE_DEATH_PROBABILITY = 0.06;
	// The probability for a sick human to cure
	private static final double DISEASE_CURE_PROBABILITY = 0.1;
	//The probability for a human to be infected
	private static final double INFECTION_PROBABILITY = 0.3;
	//Whether a human is sick or not
	private boolean isSick;
	//Whether a human was cured or not. 
	private boolean wasCured;

	/**
	 * Create a human. A human can be created as a new born (age zero
	 * and not hungry) or with a random age and food level.
	 *
	 * @param randomAge If true, the human will have random age and hunger level.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Human(boolean randomAge, Field field, Location location)
	{
		super(field, location, MAX_AGE, STARTING_FOOD_VALUE, randomAge);
		isSick = rand.nextDouble() < INFECTION_PROBABILITY && randomAge;
		wasCured = false;
	}

	/**
	 * Simulation of disease is part of human's acting.
	 */
	public void act(List<Actor> newActors)
	{
		simulateDisease();
		super.act(newActors);
	}

	/**
	 * The disease is simulated.
	 * If a human is sick, then:
	 * he may spread it (depending on the DISEASE_SPREAD_RADIUS).
	 * he may die (depending on the DISEASE_DEATH_PROBABILITY).
	 * he may heal (depending on the DISEASE_CURE_PROBABILITY).
	 */
	private void simulateDisease()
	{
		if (isSick) {
			//Spread disease to other humans
			List<Location> locations = getField().adjacentLocations(getLocation(), DISEASE_SPREAD_RADIUS);
			for (Location location : locations) {
				Animal animal = getField().getAnimalAt(location);
				if (animal instanceof Human) {
					((Human) animal).infect();
				}
			}
			//Die
			if (rand.nextDouble() < DISEASE_DEATH_PROBABILITY) {
				setDead();
				DeathTracker.getDeathTracker().addDeath(this.getClass(), "disease");
			}
			//Heal
			if (rand.nextDouble() < DISEASE_CURE_PROBABILITY) {
				isSick = false;
				wasCured = true;
			}
		}
	}

	/**
	 * A human might be infected (depending on the DISEASE_SPREAD_PROBABILITY)
	 * A human that was cured cannot be infected again.
	 */
	public void infect()
	{
		if (!wasCured && rand.nextDouble() < DISEASE_SPREAD_PROBABILITY) {
			isSick = true;
		}
	}

	/**
	 * Create and return a newborn human.
	 *
	 * @param field    The field that the new human should be placed in.
	 * @param location The location of the new human.
	 * @return A new human.
	 */
	protected Actor produceYoung(Field field, Location location)
	{
		return new Human(false, field, location);
	}

	/**
	 * Compares this human with the given argument.
	 *
	 * @param animal the animal to compare with
	 * @return true if the animal is a human.
	 */
	protected boolean isSameSpecies(Animal animal)
	{
		return animal instanceof Human;
	}

	/**
	 * @return the max age of humans
	 */
	public int getMaxAge()
	{
		return MAX_AGE;
	}

	/**
	 * @return the breeding age of humans
	 */
	public int getBreedingAge()
	{
		return BREEDING_AGE;
	}

	/**
	 * @return The breeding probability of humans
	 */
	public double getBreedingProbability()
	{
		return BREEDING_PROBABILITY;
	}

	/**
	 * @return the max number of offsprings a human can give birth to.
	 */
	public int getMaxLitterSize()
	{
		return MAX_LITTER_SIZE;
	}

	/**
	 * @return the breeding radius.
	 */
	public int getBreedingRadius()
	{
		return BREEDING_RADIUS;
	}

	/**
	 * Return the food value of humans for a given prey.
	 *
	 * @param food the prey humans can eat
	 * @return the food value of human for the given prey
	 */
	public int getFoodValue(Actor food)
	{
		if (food == null) {
			return 0;
		}
		Class foodClass = food.getClass();
		if (FOOD_TABLE.containsKey(foodClass)) {
			return FOOD_TABLE.get(foodClass);
		} else {
			return 0;
		}
	}

	/**
	 * Return whether a human is sleeping or not
	 * Humans sleep between STARTING_SLEEPING_TIME and ENDING_SLEEPING_TIME.
	 *
	 * @return true if the human is sleeping, false otherwise
	 */
	public boolean isSleeping()
	{
		EnvironmentalConditions environmentalConditions = getField().getEnvironmentalConditions();
		return environmentalConditions.getCurrentTime() >= STARTING_SLEEPING_TIME
				|| environmentalConditions.getCurrentTime() <= ENDING_SLEEPING_TIME;
	}
}
