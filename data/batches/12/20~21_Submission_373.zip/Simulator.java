import java.util.*;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing wolves, hares, rats, owls, humans, grass, and grain plants.
 *
 * @version 2021.02
 */
public class Simulator
{
	// Constants representing configuration information for the simulation.
	// The default width for the grid.
	private static final int DEFAULT_WIDTH = 120;
	// The default depth of the grid.
	private static final int DEFAULT_DEPTH = 120;

	//Creation probabilities for Wolf, Hare, Rat, Owl, Human. The values are cumulative, so each consecutive
	//constant should be larger than the previous one.
	private static final double WOLF_CREATION_PROBABILITY = 0.03;
	private static final double HARE_CREATION_PROBABILITY = 0.08;
	private static final double RAT_CREATION_PROBABILITY = 0.14;
	private static final double OWL_CREATION_PROBABILITY = 0.18;
	private static final double HUMAN_CREATION_PROBABILITY = 0.2;

	//Creation probabilites for Grass and Grain. There probabilities are completely seperate from the animal ones.
	//There probabilities are also cumulative, so they should grow as they go down.
	private static final double GRASS_CREATION_PROBABILITY = 0.5;
	private static final double GRAIN_CREATION_PROBABILITY = 1;

	// List of actors in the field.
	private List<Actor> actors;
	// The current state of the field.
	private Field field;
	// The current step of the simulation.
	private int step;
	// A graphical view of the simulation.
	private SimulatorView view;
	//The environmental conditions of a simulation. 
	private EnvironmentalConditions environmentalConditions;

	/**
	 * Construct a simulation field with default size.
	 */
	public Simulator()
	{
		this(DEFAULT_DEPTH, DEFAULT_WIDTH);
	}

	/**
	 * Create a simulation field with the given size.
	 *
	 * @param depth Depth of the field. Must be greater than zero.
	 * @param width Width of the field. Must be greater than zero.
	 */
	public Simulator(int depth, int width)
	{
		if (width <= 0 || depth <= 0) {
			System.out.println("The dimensions must be greater than zero.");
			System.out.println("Using default values.");
			depth = DEFAULT_DEPTH;
			width = DEFAULT_WIDTH;
		}

		actors = new ArrayList<>();
		environmentalConditions = new EnvironmentalConditions(24);
		field = new Field(depth, width, environmentalConditions);

		// Create a view of the state of each location in the field.
		view = new SimulatorView(depth, width);

		view.setColor(Grass.class, Color.GREEN);
		view.setColor(Grain.class, Color.YELLOW);

		view.setColor(Hare.class, new Color(118, 85, 65)); //BROWN
		view.setColor(Wolf.class, Color.ORANGE);
		view.setColor(Human.class, Color.PINK);
		view.setColor(Rat.class, Color.BLACK);
		view.setColor(Owl.class, Color.BLUE);

		// Setup a valid starting point.
		reset();
	}

	/**
	 * Run the simulation from its current state for a reasonably long period,
	 * (4000 steps).
	 */
	public void runLongSimulation()
	{
		simulate(4000);
	}

	/**
	 * Run the simulation from its current state for the given number of steps.
	 * Stop before the given number of steps if it ceases to be viable.
	 *
	 * @param numSteps The number of steps to run for.
	 */
	public void simulate(int numSteps)
	{
		for (int step = 1; step <= numSteps && view.isViable(field); step++) {
			simulateOneStep();
			// delay(60);   // uncomment this to run more slowly
		}
		DeathTracker.getDeathTracker().printDeaths();
	}

	/**
	 * Run the simulation from its current state for a single step.
	 * Iterate over the whole field updating the state of each
	 * actor.
	 */
	public void simulateOneStep()
	{
		step++;
		environmentalConditions.increment();
		// Provide space for newborn animals.
		List<Actor> newActors = new ArrayList<>();
		// Let all rabbits act.
		for (Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
			Actor actor = it.next();
			actor.act(newActors);
			if (!actor.isAlive()) {
				it.remove();
			}
		}

		// Add the newly born actors to the main lists.
		actors.addAll(newActors);

		view.showStatus(step, field);
	}

	/**
	 * Reset the simulation to a starting position.
	 */
	public void reset()
	{
		step = 0;
		actors.clear();
		populate();

		// Show the starting state in the view.
		view.showStatus(step, field);
	}

	/**
	 * Randomly populate the field with actors.
	 */
	private void populate()
	{
		Random rand = Randomizer.getRandom();
		field.clear();
		//Populate the field with Animals
		for (int row = 0; row < field.getDepth(); row++) {
			for (int col = 0; col < field.getWidth(); col++) {
				Location location = new Location(row, col);
				Actor actor = null;
				double outcome = rand.nextDouble();
				if (outcome <= WOLF_CREATION_PROBABILITY) {
					actor = new Wolf(true, field, location);
				} else if (outcome <= HARE_CREATION_PROBABILITY) {
					actor = new Hare(true, field, location);
				} else if (outcome <= RAT_CREATION_PROBABILITY) {
					actor = new Rat(true, field, location);
				} else if (outcome <= OWL_CREATION_PROBABILITY) {
					actor = new Owl(true, field, location);
				} else if (outcome <= HUMAN_CREATION_PROBABILITY) {
					actor = new Human(true, field, location);
				}
				if (actor != null) {
					actors.add(actor);
				}
				// else leave the location empty.
			}
		}
		//Populate the field with Plants
		for (int row = 0; row < field.getDepth(); row++) {
			for (int col = 0; col < field.getWidth(); col++) {
				Location location = new Location(row, col);
				Actor actor = null;
				double outcome = rand.nextDouble();
				if (outcome <= GRASS_CREATION_PROBABILITY) {
					actor = new Grass(true, field, location);
				} else if (outcome <= GRAIN_CREATION_PROBABILITY) {
					actor = new Grain(true, field, location);
				}
				if (actor != null) {
					actors.add(actor);
				}
				// else leave the location empty.
			}
		}
	}

	/**
	 * Pause for a given time.
	 *
	 * @param millisec The time to pause for, in milliseconds
	 */
	private void delay(int millisec)
	{
		try {
			Thread.sleep(millisec);
		} catch (InterruptedException ie) {
			// wake up
		}
	}

	public static void main(String[] args)
	{
		Simulator sim = new Simulator();
		sim.runLongSimulation();
	}
}
