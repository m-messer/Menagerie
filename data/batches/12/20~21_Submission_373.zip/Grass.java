/**
 * A class representing a Grass.
 *
 * @version 2021.02
 */

public class Grass extends Plant
{
	//The spread probability of a grain. 
	private static final double SPREAD_PROBABILITY = 0.7;


	/**
	 * Create a new grass.
	 *
	 * @param randomGrowth if true, the grass will be assigned a random growth
	 * @param field        The field  where the grass will be located in.
	 * @param location     The location within the field.
	 */
	public Grass(boolean randomGrowth, Field field, Location location)
	{
		super(randomGrowth, field, location);
	}

	/**
	 * @return the spreading probability of the grass.
	 */
	public double getSpreadProbability()
	{
		return SPREAD_PROBABILITY;
	}

	/**
	 * Create and return a new spread grass.
	 *
	 * @param field    The field that the new grass should be placed in.
	 * @param location The location of the new grass.
	 * @return A new grass.
	 */
	public Actor produceYoung(Field field, Location location)
	{
		return new Grass(false, field, location);
	}
}
