import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a rat.
 * Rats age, move, breed, and die.
 *
 * @version 2021.02
 */
public class Rat extends Animal
{
	// Characteristics shared by all rats (class variables).

	// The age at which a rat can start to breed.
	private static final int BREEDING_AGE = 2;
	// The age to which a rat can live.
	private static final int MAX_AGE = 40;
	// The likelihood of a rat breeding.
	private static final double BREEDING_PROBABILITY = 0.11;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 4;
	// The maximum radius in which to look for a partner
	private static final int BREEDING_RADIUS = 5;
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	// The amount of food that rats get by eating a specific plant is stored in a Map.
	private static final HashMap<Class, Integer> FOOD_TABLE;

	static {
		FOOD_TABLE = new HashMap<>();
		FOOD_TABLE.put(Grain.class, 10);
	}

	//The starting foodLevel of a new rat
	private static final int STARTING_FOOD_VALUE = 3;

	/**
	 * Create a new rat. A rat may be created with age
	 * zero (a new born) or with a random age.
	 *
	 * @param randomAge If true, the rat will have a random age.
	 * @param field     The field currently occupied.
	 * @param location  The location within the field.
	 */
	public Rat(boolean randomAge, Field field, Location location)
	{
		super(field, location, MAX_AGE, STARTING_FOOD_VALUE, randomAge);
	}

	/**
	 * Create and return a newborn rat.
	 *
	 * @param field    The field that the new rat should be placed in.
	 * @param location The location of the new rat.
	 * @return A new rat.
	 */
	protected Actor produceYoung(Field field, Location location)
	{
		return new Rat(false, field, location);
	}

	/**
	 * Compares this rat with the given argument.
	 *
	 * @param animal the animal to compare with
	 * @return true if the animal is an rat.
	 */
	protected boolean isSameSpecies(Animal animal)
	{
		return animal instanceof Rat;
	}

	/**
	 * @return the max age of rats.
	 */
	public int getMaxAge()
	{
		return MAX_AGE;
	}

	/**
	 * @return the breeding age of rats.
	 */
	public int getBreedingAge()
	{
		return BREEDING_AGE;
	}

	/**
	 * @return the breeding probability of rats.
	 */
	public double getBreedingProbability()
	{
		return BREEDING_PROBABILITY;
	}

	/**
	 * @return the maximum number of offsprings a rat can give birth to.
	 */
	public int getMaxLitterSize()
	{
		return MAX_LITTER_SIZE;
	}

	/**
	 * @return the breeding radius of rats.
	 */
	public int getBreedingRadius()
	{
		return BREEDING_RADIUS;
	}

	/**
	 * Return the food value of rats for a given plant.
	 *
	 * @param food the plant rats can eat
	 * @return the food value of rats for the given plant.
	 */
	public int getFoodValue(Actor food)
	{
		if (food == null) {
			return 0;
		}
		Class foodClass = food.getClass();
		if (FOOD_TABLE.containsKey(foodClass)) {
			return FOOD_TABLE.get(foodClass);
		} else {
			return 0;
		}
	}
}
