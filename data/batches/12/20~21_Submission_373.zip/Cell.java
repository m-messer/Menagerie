/**
 * A class representing a cell of a field. It stores a single animal and a single plant.
 *
 * @version 2021.02
 */

public class Cell
{
	//The animal stored in the Cell
	private Animal animal;
	//The plant stored in the Cell  
	private Plant plant;

	/**
	 * Create a new Cell.
	 */
	public Cell()
	{
		animal = null;
		plant = null;
	}

	/**
	 * Assigned a plant to the cell
	 *
	 * @param plant the plant to assign to the cell
	 */
	public void setPlant(Plant plant)
	{
		this.plant = plant;
	}

	/**
	 * @return The plant stored in the cell - null if no plant is stored.
	 */
	public Plant getPlant()
	{
		return plant;
	}

	/**
	 * Assigned an animal to the cell
	 *
	 * @param animal The animal to assign to the cell
	 */
	public void setAnimal(Animal animal)
	{
		this.animal = animal;
	}

	/**
	 * @return The animal stored in the cell - null if no animal is stored.
	 */
	public Animal getAnimal()
	{
		return animal;
	}

	/**
	 * Place an actor into the cell, regardless whether it is a plant or an animal.
	 *
	 * @param actor The actor to place into the cell
	 */
	public void place(Actor actor)
	{
		if (actor instanceof Animal) {
			setAnimal((Animal) actor);
		} else if (actor instanceof Plant) {
			setPlant((Plant) actor);
		}
	}

	/**
	 * Remove an actor from the cell, regardless whether it is a plant or an animal.
	 *
	 * @param actor
	 */
	public void clear(Actor actor)
	{
		if (animal == actor) {
			animal = null;
		}
		if (plant == actor) {
			plant = null;
		}
	}

	/**
	 * Remove both the plant and the animal from the cell.
	 */
	public void clear()
	{
		animal = null;
		plant = null;
	}

	/**
	 * Remove dead actors from the cell.
	 */
	public void clean()
	{
		if (animal != null && !animal.isAlive()) {
			animal = null;
		}
		if (plant != null && !plant.isAlive()) {
			plant = null;
		}
	}
}
