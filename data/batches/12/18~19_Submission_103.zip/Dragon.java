import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.awt.Color;
/**
 * A simple model of a dragon.
 * Dragons age, move, eat rabbits, and die.
 *
 * @version 19.02.2019
 */
public class Dragon extends Animal
{
    /**
     * Create a dragon. A dragon can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the dragon will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If true the dragon is male.
     */
    public Dragon(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            age = rand.nextInt(maxAge());
            foodLevel = rand.nextInt(stepsTillStarve());
        }
        else {
            age = 0;
            foodLevel = foodLevel;
        }
    }
    
    /**
     * constructor to create instance of Dragon which does not act in the simulation
     * these instances only represent dragon species in the Simulator class
     */
    public Dragon()
    {
        super();
    }
    
    /**
     * This is what the dragon does most of the time: it hunts for
     * unicorns jackalopes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newdragones A list to return newly born dragones.
     * @param daytime boolean If true its daytime.
     * @param months The number of months gone by in the simulator.
     * @param newYear boolean If true a new year went by.
     */
    public void act(List<Animal> newDragons, boolean daytime, int months, boolean newYear)
    {
        if(!daytime){super.act(newDragons, daytime, months, newYear);}
        
    }

    /**
     * This method checks whether or not this dragon is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    protected void giveBirth(List<Animal> newDragons)
    {
        
        Field field = getField();
        // find a mate in the adjacent locations
        if(!mateTest(field)){
            //System.out.println("mate not found");
            return;
        }
        //System.out.println("mate found");
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Dragon young = (Dragon) createNewAnimal(false, field, loc);
            newDragons.add(young);
            
        }
        //System.out.println("baby dragons");
    }
    
    /**
     * This method returns to the breeding probability of dragons.
     * @return double The specific breading probability.
     */
    public double getBreedingProbability ()
    {
        return breedingProbability();
     }
    
    /**
     * This method creates new dragons in the simulation.
     * @param randomAge If true a random age is set.
     * @param field The field of the new dragon.
     * @param location The location of the new dragon.
     * @return Animal The new dragon created.
     */
     public Animal createNewAnimal(boolean randomAge, Field field, Location location)
    {
        Dragon dragon = new Dragon(randomAge, field, location, super.generateGender());
        return dragon;
    }
    
    /**
     * This method returns to the breeding age of dragons.
     * @return double The specific breading age.
     */
    protected double breedingAge()
    {
        return 1;
    }
    
    /**
     * This method returns to the maximum age of dragons.
     * @return int The specific maximum age.
     */
    protected int maxAge()
    {
        return 15;
    }
    
    /**
     * This method return to the breeding probability of dragons.
     * @return double The specific breading probability.
     */
    protected double breedingProbability()
    {
        return 0.15;
    }
    
    /**
     * This method return to the maximum litter size of dragons.
     * @return int The specific maximum litter size.
     */
    protected int maxLitterSize()
    {
        return 6;
    }
    
    /**
     * This method return to the color of dragons represented in the simulator.
     * @return double The specific color. 
     */
    protected Color color()
    {
        return Color.GREEN;
    }
    
    /**
     * This method retrun to the specific age of dragons.
     * @return int The specific age.
     */
    protected int age()
    {
        return age;
    }
    
    /**
     * This method return to the specific number of steps until the dragon dies of starvation.
     * @return int The specific step until starvation.
     */
    protected int stepsTillStarve()
    {
        return 40;
    }
    
    /**
     * This method returns the orginal number of moves a dragon can do.
     * @return int The original number of moves.
     */
    protected int originalMoves()
    {
        return 2;
    }
    
    /**
     * This method retruns whether the dragon is imune to the disease in the paramenter.
     * @param disease The specific disease.
     * @return boolean If true animal is immune.
     */
    protected boolean isImmune(String disease){
        return true;
    }
}
