import java.util.*;
import java.util.Random;
import java.awt.Color;
/**
 * A simple model of a jackalope.
 * Jackalopes age, move, breed, and die.
 *
 * @version 19.02.2019
 */
public class Jackalope extends Prey
{
    // Characteristics shared by all jackalopes (class variables).
    /**
     * Create a new jackalope. A jackalope may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the jackalope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale The gender of the animals.
     */
    public Jackalope(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(maxAge());
        }
    }
    
    /**
     * constructor to create instance of Jackalope which does not act in the simulation
     * these instances only represent jackalope species in the Simulator class
     */
    public Jackalope()
    {
        
    }
    
    /**
     * This is what the jackalope does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newJackalopes A list to return newly born jackalopes.
     * @param daytime boolean If true its daytime.
     * @param months The number of months gone by in the simulator.
     * @param newYear boolean If true a new year went by
     */
    public void act(List<Animal> newJackalopes, boolean daytime, int months, boolean newYear)
    {
        if(daytime){super.act(newJackalopes,daytime, months, newYear);}
        
     }

    /**
     * This method checks whether or not this jackalope is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newJackalopes A list to return newly born jackalopes.
     */
    protected void giveBirth(List<Animal> newJackalopes)
    {
        Field field = getField();
        // find a mate in the adjacent locations
        if(!mateTest(field)){
            return;
        }
        
        // New jackalopes are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Jackalope young = (Jackalope) createNewAnimal(false, field, loc);
            newJackalopes.add(young);
        }
    }
    
    /**
     * This method creates new jackalopes in the simulation.
     * @param randomAge If true a random age is set.
     * @param field The field of the new jackalope.
     * @param location The location of the new jackalope.
     * @return Animal The new jackalope created.
     */
    public Animal createNewAnimal(boolean randomAge, Field field, Location location)
    {
        Jackalope jackalope = new Jackalope(randomAge, field, location,super.generateGender());
        return jackalope;
    }
    
    /**
     * This method returns to the breeding age of jackalopes.
     * @return double The specific breading age.
     */
    protected double breedingAge()
    {
        return 0;
    }
    
    /**
     * This method returns to the maximum age of jackalopes.
     * @return int The specific maximum age.
     */
    protected int maxAge()
    {
        return 4;
    }
    
    /**
     * This method return to the breeding probability of jackalopes.
     * @return double The specific breading probability.
     */
    protected double breedingProbability()
    {
        return 0.40;
    }
    
    /**
     * @returns maximumm number of births
     */
    protected int maxLitterSize()
    {
        return 1;
    }
    
    /**
     * This method return to the color of jackalope represented in the simulator.
     * @return double The specific color.
     */
    protected Color color()
    {
        return Color.BLUE;
    }
    
    /**
     * This method returns the food value a jackalope is worth.
     * @return int The food value.
     */
    protected int foodValue() 
    {
        return 9;
    }
    
    /**
     * This method returns a list of predators that can eat jackalopes.
     * @returns List of classes of predators.
     */
    protected List<Class> predators()
    {
        List<Class> predators = new ArrayList<>();
        predators.add(Griffin.class);
        predators.add(Dragon.class);
        return predators;
    }
    
    /**
     * This method return to the specific number of steps until the jackalope dies of starvation.
     * @return int The specific step until starvation.
     */
    protected int stepsTillStarve()
    {
        return 4;
    }
}
