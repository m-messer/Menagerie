import java.util.*;
import java.util.Random;
import java.awt.Color;
/**
 * A simple model of a unicorn.
 * Unicorns age, move, breed, and die.
 *
 * @version 19.02.2019
 */
public class Unicorn extends Prey
{
    // Characteristics shared by all unicorns (class variables).
    /**
     * Create a new unicorn. A unicorn may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the unicorn will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale The gender of the animals.
     */
    public Unicorn(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(maxAge());
        }
    }
    
    /**
     * constructor to create instance of Unicorn which does not act in the simulation
     * these instances only represent unicorn species in the Simulator class
     */
    public Unicorn()
    {
    }
    
    /**
     * This is what the unicorn does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newUnicorns A list to return newly born unicorns.
     * @param daytime boolean If true its daytime.
     * @param months The number of months gone by in the simulator.
     * @param newYear boolean If true a new year went by.
     */
    public void act(List<Animal> newUnicorns, boolean daytime, int months, boolean newYear)
    {
        if(daytime){super.act(newUnicorns,daytime, months, newYear);}
        
    }

    /**
     * This method checks whether or not this unicorn is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newUnicorns A list to return newly born unicorns.
     */
    protected void giveBirth(List<Animal> newUnicorns)
    {
        Field field = getField();
        // find a mate in the adjacent locations
        if(!mateTest(field)){
            return;
        }
        // New unicorns are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Unicorn young = (Unicorn) createNewAnimal(false, field, loc);
            newUnicorns.add(young);
        }
    }
    
    /**
     * This method creates new animals in the simulation.
     * @param randomAge If true a random age is set.
     * @param field The field of the new animal.
     * @param location The location of the new animal.
     * @return Animal The new animal created.
     */
    public Animal createNewAnimal(boolean randomAge, Field field, Location location)
    {
        Unicorn unicorn = new Unicorn(randomAge, field, location,super.generateGender());
        return unicorn;
    }
   
    /**
     * This method returns to the breeding age of unicorns.
     * @return double The specific breading age.
     */
    protected double breedingAge()
    {
        return 0.2;
    }
    
    /**
     * This method returns to the maximum age of unicorns.
     * @return int The specific maximum age.
     */
    protected int maxAge()
    {
        return 4;
    }
    
    /**
     * This method return to the breeding probability of unicorns.
     * @return double The specific breading probability.
     */
    protected double breedingProbability()
    {
        return 0.10;
    }
    
    /**
     * This method return to the maximum litter size of unicorns.
     * @return int The specific maximum litter size.
     */
    protected int maxLitterSize()
    {
        return 3;
    }
    
    /**
     * This method return to the color of unicorn represented in the simulator.
     * @return double The specific color.
     */
    protected Color color()
    {
        return Color.MAGENTA;
    }
    
    /**
     * This method returns the food value a unicorn is worth.
     * @retrun int The food value.
     */
    protected int foodValue() 
    {
        return 9;
    }
    
    /**
     * This method returns a list of predators that can eat unicorns.
     * @returns List of classes of predators.
     */
    protected List<Class> predators()
    {
        List<Class> predators = new ArrayList<>();
        predators.add(Dragon.class);
        return predators;
    }
    
    /**
     * This method return to the specific number of steps until the unicorn dies of starvation.
     * @return int The specific step until starvation.
     */
    protected int stepsTillStarve()
    {
        return 4;
    }
    
    /**
     * This method retruns whether the animal is imune to the disease in the paramenter.
     * @param disease The specific disease.
     * @return boolean If true animal is immune.
     */
    protected boolean isImmune(String d)
    {
        if(d.equals(disease.MUTATION)){
            return true;
        }
        return false;
    }
    
}
