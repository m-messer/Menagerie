import java.util.*;
/**
 *Generates a random weather every few random steps
 *with a minimum of 2 steps per change 
 *
 *@version 19.02.2019
 */
public class Weather
{
    //Each weather type saved in their corresponding String final fields
    private final String MILD = "mild";
    private final String SUNNY = "sunny";
    private final String RAIN = "rain";
    private final String SNOW = "snow";
    private final String HOT = "hot";
    private final String COLD = "cold";
    //An Array of type Stirng containing all the weather types
    private String[] allWeather= new String[] {MILD, SUNNY, RAIN, SNOW, HOT, COLD};
    private static Random random = new Random();
    //The current weather initialized to its default value
    private String currentWeather = MILD;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    { 
    }
    
    /**
     * This method returns an Array of type String containing all the possible weather types in the simulator.
     * @return Stirng Array All weather types
     */
    public String[] getAllWeather()
    {
        return allWeather;
    }
    
    /**
     * This methos generates a random weather from the list and assigns it to the currentWeather field.
     * @param steps number of steps in the simulator.
     */
    public void generateWeather(int steps)
    {
        //only if odd number of steps and boolean is true, then change weather.
        if (steps % 2==1 && random.nextBoolean()){ 
            currentWeather = allWeather[random.nextInt(6)];
        }
    }
        
    /**
     * This method returns a String of the default weather = mild.
     * @return String Default weather
     */
    public String getDefault()
    {
        return MILD;
    }
    
    /**
     *  This method returns a String of the current weather.
     *  @return String Current weather
     */
    public String getCurrentWeather()
    {
        return currentWeather;
    }
}
