import java.util.*;
/**
 * Generate random natural disaster at random times in random places in field
 *
 * @version 19.02.2019
 */
public class NaturalDisaster
{
    public enum NDTypes
    {
        EARTHQUAKE, FIRE, STORM, NONE
    }
    // 3rd layer of the field - natural disasters act here
    private Field field;
    
    private static final Random random = new Random();
    //field depth
    private int depth;
    //field width
    private int width;
    //zone in field affected by nd
    List<Location> disasterZone;
    //current disaster
    private NDTypes current;
    
    /**
     * Constructor for objects of class NaturalDisaster
     */
    public NaturalDisaster(int depth, int width, Field field)
    {
        this.depth = depth;
        this.width = width;
        disasterZone = new LinkedList<Location>();
        this.field = field;
        current = NDTypes.NONE;
    }
    
    /**
     * This method sets the current disaster to one of the possible disaster based on a random number.
     * This includes the value None, for when there are no disaster.
     */
    private void whichDisaster()
    {
        //choose random disaster
        current = NDTypes.values()[random.nextInt(NDTypes.values().length)];
        while(current.equals(NDTypes.NONE)){
            //disaster cannot be NONE
            current = NDTypes.values()[random.nextInt(NDTypes.values().length)];
        }
    }
    
    /**
     * This method returns true if the disaster can occur, 
     * that is every 30 steps and if the boolean is true.
     * @param step The number of steps in the simulator.
     * @return boolean If true the disaster can occur.
     */
    private boolean canCauseDisaster(int step)
    {
        //if more than 30 days past, cause a natural disaster, or not 
        if(step%30==0){
            if(random.nextBoolean()){ // there will be a natural disaster
                return true;
            }
        }
        return false;
    }
    
    /**
     * This method creates a random area in the field and a random size of the area where the disaster can occur.
     */
    private void randomZone()
    {
        //random epicenter of disaster
        Location epicenter = new Location(random.nextInt(depth),random.nextInt(width));
        //perimeter of affected zone
        int range = random.nextInt(8);
        //generate all the locations in field affected -> return to simulator to kill animals
        disasterZone = field.adjacent2Locations(epicenter, range);
        disasterZone.add(epicenter);
    }
    
    /**
     * This method returns the curent disaster going on.
     * @return String The current disaster.
     */
    public NDTypes getCurrent()
    {
        return current;
    }
    
    /**
     * This method returns a list of location where the disaster will occur.
     * @return List of Locations The disaster zone.
     */
    public List<Location> getDisasterZone()
    {
        return disasterZone;
    }
    
    /**
     * This method generates a disaster based on conditions.
     * @param step The number of steps.
     */
    public void generate(int step)
    {
        if(canCauseDisaster(step)){
            whichDisaster();
            randomZone();
        }
        else{
            current = NDTypes.NONE;
            disasterZone=null;
        }
    }
    
}
