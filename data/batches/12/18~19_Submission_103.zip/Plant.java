import java.util.*;
public class Plant
/**
 * A simple model of a plants.
 * plants grow, eaten by prey, and die.
 *
 * @version 19.02.2019
 */
{
    //Hash map of each weather with the associated growth multiplier.
    private HashMap<String, Double> weatherGrowthX;
    // The original growth rate of plant in normal conditions
    public static final double GROWTH_RATE=0.18;
    // The current growth rate of the plant 
    private double currentGrowthRate;
    //Max number of seeds produced 
    private static final int MAX_SEEDS = 2;
    // Whether the plant is alive or not.
    private boolean alive; 
    // The plants's field.
    private Field field;
    // The plants's position in the field.
    private Location location;
    // A shared random number generator to control reproduction.
    protected static final Random rand = Randomizer.getRandom();
    // List of all herbivores that eat the plants
    private static Class[] herbivores ={Jackalope.class, Phoenix.class, Unicorn.class};   
    // How many steps without rain
    private int noRainCounter;
    // How many days can plants survive without rain
    private static final int maxStepsNoRain = 12;
    // Keep track of weather
    private Weather weather; 
    /**
     * Constructor for objects of class Plant
     * @param field in which the plant is in
     * @param location which the plant occupies
     * @param Weather object to keep track of the weather that the plant experiences
     */
    public Plant(Field field, Location location, Weather weather)
    {
        this.weather = weather;
        weatherGrowthX = new HashMap<>();
        weatherGrowthX.put("rain", 1.10);
        weatherGrowthX.put("sunny", 1.10);
        weatherGrowthX.put("snow", 0.80);
        weatherGrowthX.put("mild", 1.00);
        weatherGrowthX.put("hot", 0.50);
        weatherGrowthX.put("cold", 0.65);
        this.field = field;
        this.location = location;
        setLocation(location);
        alive = true;
        noRainCounter = 0;
    }
    
    /**
     * This method makes the plants spread around the field/ reproduce.
     * @param List of plants.
     * @return List type Plants list of all plants.
     */
    private List<Plant> grow(List<Plant> newPlants)
    {
        if(!isAlive()){return null;}
        Field plantfield = getField();
        // New plants are spawned into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        //sow each seed
        if(free.size()==0){
            return newPlants;
        }
        for(int i = 0; i< MAX_SEEDS && free.size() > 0; i++){
            //if random growth rate< GROWTH_RATE, spawn a new plant
            if(rand.nextDouble() <= GROWTH_RATE){
                Location loc = free.remove(0);
                //plantfield.clear(loc);
                Plant seedling = new Plant(plantfield, loc, weather);
                newPlants.add(seedling);
            }
            //else don't spawn a new plant
        }
        return newPlants;
    }
    
    /**
     * This method sets the plants dead when a fire or a storm occurs.
     * @param disaster The natural disaster.
     * @return boolean If true the plant is dead.
     */
    public boolean respondToDisaster(NaturalDisaster.NDTypes disaster){
        if(!disaster.equals(NaturalDisaster.NDTypes.EARTHQUAKE)){
            setDead();
            //System.out.println(this + " is alive? "+ isAlive());
            return true;
        }
        return false;
    }
    
    /**
     * This method makes the plants act by growing, adjusting to weather conditions,
     * get eaten and check their water levels.
     * @return List of type Plants.
     * @param List of plants. 
     * @param Field plant field.
     * @param String current weather.
     */
    public List<Plant> act(List<Plant> newPlants, Field animalField, String currentWeather)
    {
        adjustToWeather(currentWeather);
        grow(newPlants);
        getEaten(animalField);
        checkDehydration();
        return newPlants;
    }
    
    /**
     * This method changes the plant's growth depending on the current weather  - only one weather type.
     * iterating method from stack overflow:
     * https://stackoverflow.com/questions/1066589/iterate-through-a-hashmap
     * @param String current weather.
     */
    public void adjustToWeather(String currentWeather)
    {
        Iterator it = weatherGrowthX.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            if(currentWeather.equals(pair.getKey())){
                //when the weather type matches, growth rate will be multiplied by appropriate multiplier
                currentGrowthRate = GROWTH_RATE* (double)pair.getValue();
            }
        }
        if(currentWeather != "rain"){
            noRainCounter++;
        }
        else{ noRainCounter=0;}
    }
    
    /**
     * This method checks whether the plant is alive or not.
     * @return boolean true if the plant is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * This method indicate that the plant is no longer alive.
     * Therefore it is removed from the field.
     */
    private void setDead()
    {
        alive = false;
        if(location != null){
            field.clear(location);//remove animal from spot
            location = null;
            field = null;
        }
    }
    
    /**
     * This method returns the plant's field.
     * @return Field The plant's field.
     */
    public Field getField()
    {
        return field;
    }
    
    /**
     * This method returns the plant's location.
     * @return Location The plant's location.
     */
    private Location getLocation()
    {
        return location;
    }
    
    /**
     * This method looks for a herbivore to be eaten by.
     * @param Field the field of the plant. 
     */
    private void getEaten(Field field)
    {
        Object animal = field.getObjectAt(location);
        if(animal == null){ //if no animal in the same spot, plant doesn't get eaten
            return;
        }
        for(Class herb : herbivores){
            if(animal.getClass().equals(herb)){
                setDead();
                Animal a = (Animal) animal;
                a.feed(7); 
            }
        }
    }
    
    /**
     * This method places the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * This method sets the plant dead if there hasnt been enough rain the last few steps.
     */
    private void checkDehydration()
    {
        if(noRainCounter> maxStepsNoRain){
            setDead();
        }
    }
}
