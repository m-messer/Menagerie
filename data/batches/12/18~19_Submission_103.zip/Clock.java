
/**
 * This class calculates the number of days, months and years gone by.
 *
 * @version 19.02.2019
 */
public class Clock
{
    private boolean daytime;
    private int days;
    private int months;
    private int years;
    /**
     * Constructor for objects of class Time
     */
    public Clock()
    {
        daytime = true;
        days = 0;
        months = 0;
        years = 0;
    }
    
    /**
     * Calculates and returns whether it is daytime or not
     * if odd number of steps -> daytime
     * if even number of steps -> nightime
     * one step represents half a day - 12 hours
     */
    public boolean daytime()
    {
        return daytime;
    }
    
    /**
     * This method increments days and months and years if appropriate.
     * @param step The number of steps in the simulator.
     */
    public void incrementTime(int step)
    {
        if(step%2==0){
            daytime = true;
            days++;
        }
        if(step%2 == 1){
            daytime = false; //night time 
        }
        if(days%6==0){
            months++;
        }
        if(months%8==0){
            years++;
        }
    }
    
    /**
     * This method returns the number of days passed in the simulator.
     * @return int The number of days.
     */
    public int getDays()
    {
        return days;
    }
    
    /**
     * This method returns the number of months passed in the simulator.
     * @return int The number of months.
     */
    public int getMonths()
    { 
        return months;
    }
    
    /**
     * This method returns the number of years passed in the simulator.
     * @return int The number of years.
     */
    public int getYears()
    {
        return years;
    }
    
    /**
     * This method returns true if a new year has passed.
     * @return boolean If true another year has passed.
     */
    public boolean isNewYear()
    {
        return months%8==0;
    }
}
