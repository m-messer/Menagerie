import java.util.List;
import java.awt.Color;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 19.02.2019
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive; //SHOULD THIS BE PRIVATE OR PROTECTED 
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // the animal's gender
    protected boolean isMale;
    //the animal's age
    protected int age;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    //how many steps till starve
    protected int foodLevel;
    //Weather
    protected static Weather weather;
    //how many times the animal can move in one step
    protected int howManyMoves;
    //disease object to store info the diseases an animal has
    protected Disease disease;
    /**
     * Create a new instance of Animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale The gender of the animals.
     */
    public Animal(Field field, Location location, boolean isMale)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.isMale = isMale;
        //each animal starts with random food level
        foodLevel = rand.nextInt(13);
        howManyMoves = originalMoves();
        disease = new Disease();
    }
    
    /**
     * constructor to create instance of Animal which does not act in the simulation
     * these instances only represent animal species in the Simulator class
     */
     public Animal()
    {  
    }
    
    /**
     * This method assigns the weather in the paramenter to the static Weather field in this class.
     * Makes sure the weather experienced by the animals is the same to the one in the Simulator class
     * @param w The weather.
     */
    public static void setWeather(Weather w)
    {
        weather = w;
        //System.out.println("animal: "+weather);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * Exhibit generic animal behaviour
     * @param newAnimals A list to receive newly born animals.
     * @param daytime boolean If true its daytime.
     * @param months The number of months gone by in the simulator.
     * @param newYear boolean If true a new year went by.
     */
    public void act(List<Animal> newAnimals, boolean daytime, int months, boolean newYear)
    {
        if(isAlive()) {
            incrementHunger();
            if(!isAlive()){return;}
            diseaseEffects();
            if(!isAlive()){return;}
            adjustToWeather(); 
            if(!isAlive()){ return;} //animal can die due to weather
            if(isMale){giveBirth(newAnimals); }
            for(int i =0; i<howManyMoves; i++){
                if(!alive){return;}
                move();
            }
        }
        if(newYear){
            incrementAge();
        }
    }
    
    /**
     * This method moves the animal from one location of the field to a free adjacent one.
     */
    protected void move()
    {
        // Try to move into a free location.
        Location newLocation = getField().freeAdjacentLocation(getLocation());
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }
    
    /**
     * This method controls the reproduction and birth rate of the animals.
     * @param newAnimals The list of newly born animals.
     */
    abstract protected void giveBirth(List<Animal> newAnimals);
    
    /**
     * This method tests if the adjacent animal is of the same species and the opposite sex.
     * if so, they can breed and give birth.
     * @param field The field of the animal looking for a mate.
     * @return boolean If true the mate found is of oposite sex and nearby.
     */
    protected boolean mateTest(Field field)
    {
        String thisSpecies = this.getClass().getName();
        List<Location> adjacentLocation = field.adjacent2Locations(getLocation(),4);
        for(Location location : adjacentLocation){
            Animal animal = (Animal)field.getObjectAt(location);
            if(matchSpecies(animal, thisSpecies) && animal.getIsMale() != isMale){
                //infect mate if infected itself with std
                if(disease.checker(disease.STD)){
                    animal.disease.infectedWith(disease.STD);
                }
                return true;
            }
            
        }
        return false;
    }
    
    /**
     * This method checks whether the animal is imune to the disease in the paramenter.
     * @param disease The specific disease.
     * @return boolean If true animal is immune.
     */
    protected boolean isImmune(String disease)
    {
        return false;
    }
    
    /**
     * This methos generates a number representing the number of births,
     * if it can breed.
     * @return int The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= breedingProbability()) {
            births = rand.nextInt(maxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * This method checks if the animal is old enough to breed.
     * @return boolean If true the animal can breed.
     */
    protected boolean canBreed()
    {
        return age >= breedingAge();
    }
    
    /**
     * This method increase the age. This could result in the animal's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > maxAge()) {
            setDead();
        }
    }
    
    /**
     * This method makes the animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * This method checks whether the animal is alive or not.
     * @return boolean If true the animal is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * This method indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);//remove animal from spot
            location = null;
            field = null;
        }
    }

    /**
     * This method returns the animal's location.
     * @return Location The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * This method places the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * This method returns the animal's field.
     * @return Field The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * This method sets the animals gender to male or female.
     * @return boolean If true the animal is male.
     */
    public boolean generateGender()
    {
        Random random = new Random();
        boolean randBoo = random.nextBoolean();
        return randBoo;
    }
    
    /**
     * This method returns the gender of the animal
     * @return boolean If true the animal is male.
     */
    public boolean getIsMale()
    {
        return isMale;
    }
    
    /**
     * This method returns true if the animal and MatchAnimal are from the same class.
     * @param animal The  1st animal to match.
     * @param matchAnimal  The 2nd animal to match.
     * @return boolean If true the animals are from the same class.
     */
    protected boolean matchSpecies(Animal animal, String matchAnimal)
    {
        return animal != null && animal.getClass().getName().equals(matchAnimal);
    }
    
    /**
     * This method maps weather types to the corresponding animal behaviour. 
     */
    private void adjustToWeather()
    {
        //System.out.println(weather);
        for(String w : weather.getAllWeather()){
            String currentWeather = weather.getCurrentWeather();
            if(currentWeather.equals(w)){
                switch(currentWeather){
                    case "hot": decrementHunger();
                    break;
                    case "cold": incrementHunger();
                    break;
                    case "snow": incrementHunger();
                    reduceMovement();
                    break;
                    case "fog": reduceMovement(); //visibility is less so move less
                    break;
                    case "mild": resetBehaviour();
                    break;
                    case "sunny": resetBehaviour();
                    case "rain": resetBehaviour();
                }
                
            }
        }
    }
    
    /**
     * This method implements the effect of disease on the animal.
     */
    private void diseaseEffects()
    {
        //which diseases does the animal have?
        List<String> infectedWith = disease.whichDiseases();
        for(String d : infectedWith){
            switch(d){
                case "mutation":
                    setDead();
                break;
                case "phoenix pox":
                    incrementAge();
                break;
                case "std":
                    incrementAge();
                break;
            }
        }
    }
    
    /**
     * This method lets the animal respond to the disaster.
     * @param disaster The specific disaster.
     * @return boolean If true the animal is dead.
     */
    public boolean respondToDisaster(NaturalDisaster.NDTypes disaster)
    {
        if(disaster.equals(NaturalDisaster.NDTypes.EARTHQUAKE)){
            setDead();
            //System.out.println(this + " is dead? "+ isAlive());
            return true;
        }
        return false;
    }
    
    /**
     * This method decreases the level of hunger of an animal.
     */
    private void decrementHunger()
    {
        foodLevel++;
    }
    
    /**
     * This method decreases the number of moves per step each animal does.
     */
    private void reduceMovement()
    {
        if(howManyMoves!=0){
            howManyMoves--;
        }
    }
    
    /**
     * This method resets animal's behaviour of movement to its  original value.
     */
    private void resetBehaviour()
    {
        howManyMoves = originalMoves();
    }
    
    /**
     * This method creates new animals in the simulation.
     * @param randomAge If true a random age is set.
     * @param field The field of the new animal.
     * @param location The location of the new animal.
     * @return Animal The new animal created.
     */
    abstract public Animal createNewAnimal(boolean randomAge, Field field, Location location);
    
    //abstract accessor methods for animals' fields/ attributes
    //to be implemented in each species' class
    /**
     * This method accesses to the specific breeding age of each animal species.
     * @return double The specific breading age.
     */
    abstract protected double breedingAge();
    
    /**
     * This method accesses to the specific maximum age of each animal species.
     * @return int The specific maximum age.
     */
    abstract protected int maxAge();
    
    /**
     * This method accesses to the specific breeding probability of each animal species.
     * @return double The specific breading probability.
     */
    abstract protected double breedingProbability();
    
    /**
     * This method accesses to the specific maximum litter size of each animal species.
     * @return int The specific maximum litter size.
     */
    abstract protected int maxLitterSize();
    
    /**
     * This method accesses to the specific color of each animal species represented in the simulator.
     * @return double The specific color.
     */
    abstract protected Color color(); 
    
    //delete?
    //abstract protected Color maleColor();
    
    /**
     * This method accesses to the specific number of steps until the animal dies of starvation.
     * @return int The specific step until starvation.
     */
    abstract protected int stepsTillStarve();
    
    /**
     * This method increases the food level by a specific amount depending on the consumption of the animal.
     * @param foodValue The value of the food eaten.
     */
    public void feed(int foodValue)
    {
        foodLevel += foodValue;
    }
    
    /**
     * This method returns the orginal number of moves an animal can do.
     * @return int The original number of moves.
     */
    protected int originalMoves()
    {
        return 1;
     }
    
    /**
     * This method returns the size of the perimiter animals have to find a mate for reproduction.
     * @return int The perimiter range.
     */
    protected int matePerimeter()
    {
          return 1;
    }
    
    /**
     * This method returns the age of an animal.
     * @returns int The age of an animal.
     */
    public int getAge()
    {
         return age;
    }
}

