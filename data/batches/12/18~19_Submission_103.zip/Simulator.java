import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.*;

/**
 * Simulator class: 
 * Takes care of all the things that are going on in the simulator.
 * Calls all the classes to create an ecosystem of animals, plants, diseases, weather and natural disasters. 
 *
 * @version 19.02.19
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120; //120
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80; //80
    
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // List of animals species in the field.
    private List<Animal> species;
    
    // The current state of the field.
    private Field field;
    //The current state of the field of plants.
    private Field plantField;
    //The current state of the field of natural disasters.
    private Field disasterField;
    
    // A graphical view of the simulation for the animals.
    private SimulatorView view;
    // A graphical view of the simulation for the plants.
    private SimulatorView plantView;
    // A graphical view of the simulation for the natural disasters.
    private SimulatorView disasterView;
    
    // The current step of the simulation.
    private int step;
    //Calculates and models time passing in the simulation - days, months and years.
    private Clock clock;
    //The weather in field.
    private Weather weather;
    // The current weather in the field.
    private String currentWeather;
    //The natural disaster in the simulation.
    private NaturalDisaster naturalDisaster;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * This method creates a simulation field with the given size and includes all the required 
     * elements : Animals, Plants, Clock, Weather and Natural Disaster 
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        field = new Field(depth, width);
        clock = new Clock();
        animalFieldSetUp(depth, width);
        plants = new ArrayList<>();
        plantField = new Field(depth, width);
        plantView = new SimulatorView(depth, width);
        plantView.setColor(Plant.class, Color.GREEN);
        weather = new Weather();
        
        disasterField = new Field(depth, width);
        naturalDisaster = new NaturalDisaster(depth, width, disasterField);
        disasterView = new SimulatorView(depth, width);
        
        reset();
    }
    
    /**
     * This method creates a list of species of animals and assigns their individual colours to each and one of them.
     */
    private void animalFieldSetUp(int depth, int width)
    {
        animals = new ArrayList<>();
        // Create a view of the state of each location in the field.
        species = new ArrayList<Animal>();
        species.add(new Griffin());
        species.add(new Jackalope());
        species.add(new Dragon());
        species.add(new Phoenix());
        species.add(new Unicorn());
        view = new SimulatorView(depth, width);
        
        for (Animal animal: species){
            view.setColor(animal.getClass(), animal.color());
            
        }
    }
    
    /**
     * This method runs the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * This method runs the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(500);   // uncomment this to run more slowly 60
        }
    }
    
    /**
     * This method runs the simulation from its current state for a single step.
     * get the time, generate natural disaster and weather, simulate animal and plant behaviour, let time pass at the end.
     */
    public void simulateOneStep()
    {
        step++;
        int months = clock.getMonths();
        boolean daytime = clock.daytime();
        boolean newYear = clock.isNewYear();
        //generate random weather
        weather.generateWeather(step); 
        currentWeather = weather.getCurrentWeather();
        
        naturalDisaster.generate(step);
        NaturalDisaster.NDTypes currentDisaster = naturalDisaster.getCurrent();
        disasterView.showClimateStatus(step, disasterField, currentDisaster
        ,(LinkedList<Location>) naturalDisaster.getDisasterZone(), currentWeather);
        
        causeDisaster();
        simulateAnimals(daytime, months, newYear);
        simulatePlants();
        view.showStatus(step, field, currentWeather, currentDisaster);
        plantView.showStatus(step, plantField, currentWeather,currentDisaster );
        clock.incrementTime(step);
    }
    
    /**
     * This method generates a natural disaster in the field based on conditions 
     * and kills all plants and animals in the field regions affected
     */
    private void causeDisaster()
    {
        NaturalDisaster.NDTypes disaster = naturalDisaster.getCurrent();
        
        if(disaster!=NaturalDisaster.NDTypes.NONE){
            LinkedList<Location> zone = (LinkedList<Location>) naturalDisaster.getDisasterZone();
            //get the animals that are in the disaster zone
            for(Location location : zone){
                Object animal = field.getObjectAt(location);
                if(animal!=null){
                    Animal a = (Animal)animal;
                   
                    //if the animal dies, remove it from list of animals.
                    if(a.respondToDisaster(disaster)){
                        animals.remove(a);
                    }
                }
                Object plant = plantField.getObjectAt(location);
                if(plant!= null){
                    Plant p = (Plant) plant;
                   
                    //if the plant dies, remove it from list of plants
                    if(p.respondToDisaster(disaster)){
                        plants.remove(p);
                    }
                }
            }
        }
       
    }
    
    /**
     * This method resets the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        Animal.setWeather(weather);
        populate();
        populatePlants();
        currentWeather = weather.getDefault();
        NaturalDisaster.NDTypes currentDisaster = naturalDisaster.getCurrent();
        // Show the starting state in the view.
        
        view.showStatus(step, field, currentWeather,currentDisaster );
        plantView.showStatus(step, plantField, currentWeather, currentDisaster);
    }
    
    /**
     * This method simulates all the behaviours of each animal in one step.
     */
    private void simulateAnimals(boolean daytime, int months, boolean newYear)
    {
        // creates a list for the newly born animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, daytime, months, newYear);
            if(! animal.isAlive()) {
                it.remove();
            }
        }     
        // Add the newly born animal to the main list.
        animals.addAll(newAnimals);
    }
    
    /**
     * This method simulates all the behaviours of each plant in one step.
     */
    private void simulatePlants()
    {
        // Provide space for newly spawned plants.
        List<Plant> newPlants = new ArrayList<>();        
        // Let all plants grow.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ){
            Plant plant = it.next();
            plant.act(newPlants, field, currentWeather);
            if(! plant.isAlive()){
                it.remove();
            }
        }
        // Add the newly spawn plants to the main list.
        plants.addAll(newPlants);
    }
    
    /**
     * This method randomly populates the field with animals of all species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++){
            for(int col = 0; col < field.getWidth(); col++){
                for (Animal animal : species){
                    double populateChance = animal.breedingProbability()/8;
                    if (rand.nextDouble() <= populateChance){
                        Location location = new Location (row, col);
                        Animal newAnimal = animal.createNewAnimal(true, field, location);
                        animals.add(newAnimal);
                    }
                } 
                
                // else leave the location empty.
            }
        }
    }
    
    /**
     * This method randomly populates the field with plants.
     */
    private void populatePlants()
    {
        Random rand = Randomizer.getRandom();
        plantField.clear();
        for(int row = 0; row < plantField.getDepth(); row++){
            for(int col = 0; col < plantField.getWidth(); col++){
                double populateChance = Plant.GROWTH_RATE;
                if(rand.nextDouble() <= populateChance){
                    Location location = new Location (row, col);
                    Plant newPlant = new Plant(plantField, location, weather);
                    plants.add(newPlant);
                }
             //System.out.println(plantField.getObjectAt(row, col));
            }
        }
        
    }
    
    /**
     * This method pauses for a given amount of time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
