import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.awt.Color;
/**
 * A simple model of a griffin.
 * Griffin age, move, eat Jackalopes and phoenixes, and die.
 *
 * @version 19.02.2019
 */
public class Griffin extends Animal
 {
    /**
     * Create a griffin. A griffin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the griffin will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale If true the griffin is male.
     */
    public Griffin(boolean randomAge, Field field, Location location, boolean isMale)
     {
        super(field, location, isMale);
        if(randomAge) {
            age = rand.nextInt(maxAge());
            foodLevel = rand.nextInt(stepsTillStarve());
        }
        else {
            age = 0;
            foodLevel = foodLevel;
        }
        
    }
    
    /**
     * constructor to create instance of Griffin which does not act in the simulation
     * these instances only represent griffin species in the Simulator class
     */
    public Griffin()
    {
        super();
    }
    
    /**
     * This is what the griffin does most of the time: it hunts for
     * jakalopes and phoenixs. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newgriffines A list to return newly born griffines.
     * @param daytime boolean If true its daytime.
     * @param months The number of months gone by in the simulator.
     * @param newYear boolean If true a new year went by.
     */
    public void act(List<Animal> newGriffins, boolean daytime, int months, boolean newYear)
    {
        if(daytime){super.act(newGriffins, daytime, months, newYear);}
        
    }

    /**
     * This method checks whether or not this griffin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGriffins A list to return newly born griffins.
     */
    protected void giveBirth(List<Animal> newGriffins)
    {
        Field field = getField();
        // find a mate in the adjacent locations
        if(!mateTest(field)){
            return;
        }
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++){
            Location loc = free.remove(0);
            Griffin young = (Griffin) createNewAnimal(false, field, loc);
            newGriffins.add(young);
        }
    }
    
    /**
     * This method returns to the breeding probability of griffins.
     * @return double The specific breading probability.
     */
    public double getBreedingProbability ()
    {
        return breedingProbability();
    }

    /**
     * This method creates new griffin in the simulation.
     * @param randomAge If true a random age is set.
     * @param field The field of the new griffin.
     * @param location The location of the new griffin.
     * @return Animal The new griffin created.
     */
    public Animal createNewAnimal(boolean randomAge, Field field, Location location)
    {
        Griffin griffin = new Griffin(randomAge, field, location, super.generateGender());
        return griffin;
     }
    
    /**
     *  This method returns to the breeding age of griffins.
     * @return double The specific breading age.
     */
    protected double breedingAge()
    {
        return 1;
    }
    
    /**
     * This method returns to the maximum age of griffins.
     * @return int The specific maximum age.
     */
    protected int maxAge(){
        return 10;
    }
    
    /**
     * This method return to the breeding probability of griffins.
     * @return double The specific breading probability.
     */
    protected double breedingProbability()
    {
        return 0.15;
    }
    
    /**
     * This method return to the maximum litter size of griffins.
     * @return int The specific maximum litter size.
     */
    protected int maxLitterSize()
    {
        return 8;
    }
    
    /**
     * This method return to the color of griffins represented in the simulator.
     * @return double The specific color.
     */
    protected Color color()
    {
        return Color.ORANGE;
    }
    
    /**
     * This method return to the specific number of steps until the griffin dies of starvation.
     * @return int The specific step until starvation.
     */
    protected int stepsTillStarve()
    {
        return 30;
    }
    
    /**
     * This method returns the orginal number of moves a griffin can do.
     * @return int The original number of moves.
     */
    protected int originalMoves()
    {
        return 2;
    }
}
