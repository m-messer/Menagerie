import java.util.*;
import java.util.Random;
import java.awt.Color;
/**
 * A simple model of a phoenix.
 * Phoenixs age, move, breed, and die.
 *
 * @version 19.02.2019
 */
public class Phoenix extends Prey
{
    // Characteristics shared by all phoenixs (class variables).
    /**
     * Create a new phoenix. A phoenix may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the phoenix will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale The gender of the animals.
     */
    public Phoenix(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(maxAge());
        }
    }
    
    /**
     * constructor to create instance of Phoenix which does not act in the simulation
     * these instances only represent phoenix species in the Simulator class
     */
    public Phoenix()
    {
    }
    
    /**
     * This is what the phoenix does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPhoenixs A list to return newly born phoenixs.
     * @param daytime boolean If true its daytime.
     * @param months The number of months gone by in the simulator.
     * @param newYear boolean If true a new year went by.
     */
    public void act(List<Animal> newPhoenixs, boolean daytime, int months, boolean newYear)
    {
        if(daytime){super.act(newPhoenixs,daytime, months, newYear);}
    }

    /**
     * This method checks whether or not this phoenix is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPhoenixs A list to return newly born phoenixs.
     */
    protected void giveBirth(List<Animal> newPhoenixs)
    {
        Field field = getField();
        // find a mate in the adjacent locations
        if(!mateTest(field)){
            return;
        }
        // New phoenixs are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Phoenix young = (Phoenix) createNewAnimal(false, field, loc);
            newPhoenixs.add(young);
            //does young have the mutation?
            if(rand.nextInt(30)<1){
                young.disease.infectedWith(disease.MUTATION);
            }
        }
    }
    
    /**
     *  This method creates new phoenixs in the simulation.
     * @param randomAge If true a random age is set.
     * @param field The field of the new phoenix.
     * @param location The location of the new phoenix.
     * @return Animal The new phoenix created.
     */
    public Animal createNewAnimal(boolean randomAge, Field field, Location location)
    {
        Phoenix phoenix = new Phoenix(randomAge, field, location,super.generateGender());
        return phoenix;
    }
    //Characteristics shared by all phoenixes (class variables)
    /**
     * This method returns to the breeding age of phoenixs.
     * @return double The specific breading age.
     */
    protected double breedingAge()
    {
        return 0.8;
    }
    
    /**
     * This method returns to the maximum age of phoenixs.
     * @return int The specific maximum age.
     */
    protected int maxAge()
    {
        return 6;
    }
    
    /**
     * This method return to the breeding probability of phoenixs.
     * @return double The specific breading probability.
     */
    protected double breedingProbability()
    {
        return 0.3;
    }
    
    /**
     * This method return to the maximum litter size of phoenixs.
     * @return int The specific maximum litter size.
     */
    protected int maxLitterSize()
    {
        return 8;
    }
    
    /**
     * This method return to the color of phoenixs represented in the simulator.
     * @return double The specific color.
     */
    protected Color color()
    {
        return Color.RED;
    }
    
    /**
     * This method returns the food value a phoenix is worth.
     * @retrun int The food value.
     */
    protected int foodValue() 
    {
        return 9;
    }
    
    /**
     * This method returns a list of predators that can eat phoenixs.
     * @returns List of classes of predators.
     */
    protected List<Class> predators() 
    {
        List<Class> predators = new ArrayList<>();
        predators.add(Griffin.class);
        return predators;
    }
    
    /**
     * This method return to the specific number of steps until the phoenix dies of starvation.
     * @return int The specific step until starvation.
     */
    protected int stepsTillStarve()
    {
        return 4;
    }
}
