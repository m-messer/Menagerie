import java.awt.Color;
import java.util.*;
/**
 * A simple model of a griffin.
 * Griffin age, move, eat Jackalopes and phoenixes, and die.
 *
 * @version 19.02.2019
 */
abstract public class Prey extends Animal
{
    //The chance of survaving a interaction with a predator.
    private static final double SURVIVAL_RATE = 0.05;
    
    /**
     * Constructor for objects of class Prey
     */
    public Prey(Field field, Location location, boolean isMale)
    {
       super(field, location,isMale);
    }
    
    /**
     * constructor to create instance of Prey which does not act in the simulation
     * these instances only represent predator species in the Simulator class
     */
    public Prey()
    {
    }
    
    /**
     * Make this prey act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born pey.
     * @param daytime boolean If true its daytime.
     * @param months The number of months gone by in the simulator.
     * @param newYear boolean If true a new year went by.
     */
    public void act(List<Animal> newAnimals, boolean daytime, int months, boolean newYear)
    {
        super.act(newAnimals, daytime, months, newYear);
        if(!isAlive()){ return;}
        List<Animal> predatorsFound = new ArrayList<>();
        eatenByWho(findPredator(predators()));
    }
    
    /**
     * This method returns a list of animals around the prey.
     * @param predators The list of predators that can eat the prey.
     * @return List of predators around the prey.
     */
    public List<Animal> findPredator(List<Class> predators)
    {
        List<Animal> predatorsFound = new ArrayList<>();
        Field field = getField();
        if(field == null){System.out.println("field is null.");}
        if(getLocation()==null){System.out.println("location is null");}
        
        List<Location> adjacent = field.adjacent2Locations(getLocation(),2);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal != null){
                for(Class predator : predators){
                    //if the names of the animal and predator match
                    if(animal.getClass().getName().equals(predator.getName())) {
                        predatorsFound.add((Animal)animal);
                    }
                }
            }
        }
        if(predatorsFound.isEmpty()){
            return null;
        }
        return predatorsFound;
    }
    
    /**
     * This method decides randomly which of the predators around the prey will eat it
     * or wether it survives.
     * @param predatorsFound The list of predators surrounding the animal.
     */
    public void eatenByWho(List<Animal> predatorsFound)
    {
        //are there any predators in range?
        if(predatorsFound == null){
            return;
        }
        //does prey survive?
        if(rand.nextDouble()<= SURVIVAL_RATE){
            return;
        }
        //prey doesn't survive. it's now dead
        if(isAlive()) { 
            setDead();
        }
        //find return predator who get's prey. 
        int randIndex = rand.nextInt(predatorsFound.size());
        Animal winner = predatorsFound.get(randIndex);
        //if prey has disease, infected predator
        if(disease.checker(disease.PHOENIX_POX)){
            if(!winner.isImmune(disease.PHOENIX_POX)){
                winner.disease.infectedWith(disease.PHOENIX_POX);
            }
        }
        //feed the predator
        winner.feed(foodValue());
    }
    
    //abstract accessor methods for animals' fields/ attributes
    //to be implemented in each species' class
    /**
     * This method accesses to the specific breeding age of each prey species.
     * @return double The specific breading age.
     */
    abstract protected double breedingAge();
    
    /**
     * This method accesses to the specific maximum age of each prey species.
     * @return int The specific maximum age.
     */
    abstract protected int maxAge();
    
    /**
     * This method accesses to the specific breeding probability of each prey species.
     * @return double The specific breading probability.
     */
    abstract protected double breedingProbability();
    
    /**
     * This method accesses to the specific maximum litter size of each prey species.
     * @return int The specific maximum litter size.
     */
    abstract protected int maxLitterSize();
    
    /**
     * This method accesses to the specific color of each prey species represented in the simulator.
     * @return double The specific color.
     */
    abstract protected Color color();
    
    /**
     * This method accesses the specific food value by which each prey is worth.
     * @retrun int The food value.
     */
    abstract protected int foodValue();
    
    /**
     * This method accesses a list of predators that can eat each specific prey.
     * @returns List of classes of predators.
     */
    abstract protected List<Class> predators();
    
}