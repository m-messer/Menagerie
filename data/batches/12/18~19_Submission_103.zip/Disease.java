import java.util.*;
/**
 *Disease class: 
 *
 *
 * @version 19.02.19
 */
public class Disease
{
    // These diseases increases the age of the animal simulating as if the animal lives less.
    // This disease is passed on through reproduction. 
    public static final String STD = "std"; 
    // This disease is passed on by eating an animal infected.
    public static final String PHOENIX_POX = "phoenix pox"; 
    // Animals are randomly born with this diseas and die straight away.
    public static final String MUTATION = "mutation";
    public static final String[] allD = {PHOENIX_POX, MUTATION, STD};
    private HashMap<String,Boolean> allDiseases;
    private static Random random = new Random();
    private boolean infected;
    //reduced max age -> increment age!!
    /**
     * Constructor for objects of class Disease.
     */
    public Disease()
    {
        //animal gets disease at random
        //does the animal have a disease?
        boolean infected = false;
        allDiseases = new HashMap<>();
        allDiseases.put(STD, random.nextInt(20)<3);
        allDiseases.put(PHOENIX_POX, random.nextInt(20)<3);
        allDiseases.put(MUTATION, random.nextInt(20)<1);
    }

    /**
     * This method retruns a hashMap of all the possible diseases and a boolean indicating 
     * true the animal is infected, false the animal is not.
     * @returns HashMap String, boolean of all diseases True if animal infected.
     */
    public HashMap<String, Boolean> getAllDiseases()
    {
        return allDiseases;
    }
    
    /**
     * This method will make the animal infected with the diseas give if the random boolean 
     * is with in th range. 
     * @param disease the disease to infect the animal. 
     */
    public void infectedWith(String disease)
    {
        if(random.nextInt(30)<1){
            allDiseases.replace(disease, true);
            if(!infected){
                infected = true;
            }
        }
    }
    
    /**
     * This method returns a list of diseases the animal has. 
     * @return List type String diseases set animal has.
     */
    public List<String> whichDiseases()
    {
        List<String> d = new ArrayList<>();
        Iterator it = allDiseases.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            // add all diseases which the animal has to the arraylist to be returned
            if((boolean)pair.getValue() == true){
                d.add((String)pair.getKey());
            }
        }
        return d;
    }
    
    /**
     * This method returns true if the animal has the disease in the parameter.
     *@param d Stirng of specific disease.
     *@returns boolean whethere animal has disease.
     */
    public boolean checker(String d)
    {
        return allDiseases.containsKey(d);
    }
    
    /**
     * This method returns true if the animal is infected.
     * @return boolean True if infected.
     */
    public boolean isInfected()
    {
        return infected;
    }
}
