import java.util.ArrayList;

/**
 * Represent a rectangular grid of field positions. Each position is able to
 * store an array list of items.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class ItemField extends Field
{
    private ArrayList<Item>[][] itemField;

    /**
     * Represent a field of the given dimensions.
     * @param depth The depth of the field.
     * @param width The width of the field.
     */
    public ItemField(int depth, int width)
    {
        super(depth, width, true);
        itemField = new ArrayList[getDepth()][getWidth()];
        clear();
    }

    /**
     * Empty the item field.
     */
    public void clear()
    {
        for(int row = 0; row < getDepth(); row++){
            for(int col = 0; col < getWidth(); col++){
                itemField[row][col] = new ArrayList<Item>();
            }
        }
    }
    
    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    public void clear(Location location)
    {
        itemField[location.getRow()][location.getCol()] = new ArrayList<Item>();
    }

    /**
     * Return the list of the drop items at this location.
     * @param location The location where the items are.
     * @return An ArrayList of the drop items at this location
     */
    public ArrayList<Item> getItems(Location location)
    {
        return itemField[location.getRow()][location.getCol()];
    }

    /**
     * Return the list of the drop items at this location.
     * @param row The row on the item field.
     * @param col The colume on the item field.
     * @return An ArrayList of the drop items at this location
     */
    public ArrayList<Item> getItems(int row, int col)
    {
        return itemField[row][col];
    }

    /**
     * Some new itmes are put on the ground.
     * @param item The item add to the ground.
     * @param location The location where the item should be dropped.
     */
    public void addItem(Item item, Location location)
    {
        itemField[location.getRow()][location.getCol()].add(item);
    }
}
