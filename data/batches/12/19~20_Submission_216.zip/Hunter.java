import java.util.ArrayList;

/**
 * This is an interface providing methods for actions of a hunter.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public interface Hunter
{
    /**
     * Check if there is at least a target around.
     * @return true if find a target.
     */
    boolean findTarget();

    /**
     * Check if an actor is a target of this hunter.
     * @param actor The actor to be checked.
     * @return true if this actor is a target.
     */
    boolean isTarget(Actor actor);
    /**
     * Look for targets adjacent to the current location.
     * @return An ArrayList of the locations where targets were found.
     */
    ArrayList<Location> targetLocations();

    /**
     * Attack the target.
     * @param targetLocation An ArrayList of the location of the targets.
     */
    void attack(ArrayList<Location> targetLocation);
}
