import java.util.Random;
/**
 * A class for simulating weather
 *
 * @version 2021.03.02
 */
public class Weather
{
    // 
    protected static final Random rand = Randomizer.getRandom();
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    { }
    
    // Call this in simulator every couple steps
    public DifferentWeather simulateWeather()
    {
        // choose random weather
        // call different animal effects (pass in weather to animal method)
        
        double randNum = rand.nextDouble();
        if(randNum <= DifferentWeather.EARTHQUAKE.getProbability()) {
            return DifferentWeather.EARTHQUAKE;
        }
        else if(randNum <= DifferentWeather.FOG.getProbability()) {
            return DifferentWeather.FOG;
        }
        else if(randNum <= DifferentWeather.RAIN.getProbability()) {
            return DifferentWeather.RAIN;      
        }
        return DifferentWeather.SUN;
    }
}
