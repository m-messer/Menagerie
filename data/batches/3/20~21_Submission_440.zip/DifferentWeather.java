
/**
 * Enumeration class DifferentWeather - write a description of the enum class here
 *
 * @version 2021.02.27
 */
public enum DifferentWeather
{
    FOG("fog", 0.3), RAIN("rain", 0.45), EARTHQUAKE("earthquake", 0.05), SUN("sun", 1);
    
    private final String weatherString;
    private final double probability;
    
    private DifferentWeather(String weatherString, double probability) {
        this.weatherString = weatherString;
        this.probability = probability;
    }
    
    public String toString() {
        return weatherString;
    }
    
    public double getProbability() {
        return probability;
    }
}
