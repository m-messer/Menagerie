/**
 * Class to represent plants, plants have a food value.
 *
 * @version 2021.03.02
 */
public class Plant
{
    private static final int FOOD_VALUE = 10;

    /**
     * Constructor for objects of class Plant
     */
    public Plant()
    {  }
    
    public static int getFoodValue()
    {
        return FOOD_VALUE;
    }
}
