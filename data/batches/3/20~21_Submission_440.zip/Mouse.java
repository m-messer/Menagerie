import java.util.List;
import java.util.Iterator;

/**
 * Write a description of class Mouse here.
 *
 * @version 2021.03.02
 */
public class Mouse extends Prey
{
    // Whether or not the animal is active during the day.
    private static final boolean ACTIVE_IN_DAY = false;
    // The age at which an animal can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which an animal can live.
    private static final int MAX_AGE = 10;
    // The likelihood of an animal breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    //The amount of energy the prey supplies
    private static final int FOOD_VALUE = 10;
    // The food level when born. 
    private static final int FOOD_LIMIT = 10;

    /**
     * Constructor for objects of class Mouse
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        super.generateAge(randomAge, MAX_AGE, FOOD_LIMIT);
    }
    
    /**
     * @return Whether or not the animal is active during the day.
     */
    public boolean isActiveInDay()
    {
        return ACTIVE_IN_DAY;
    }
    
    /**
     * Increments the age. Possible for animal to die.
     */
    protected void incrementAge() 
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * @return The food level supplied by animal.
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born animals.
     */
    protected void giveBirth(List<Animal> newMice) 
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Mouse young = new Mouse(false, field, loc);
            newMice.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A squirrel can breed if it has reached the breeding age and meets an squirrel of the opposite gender 
     * that has also reached the breeding age.
     * @return True if they can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Mouse) {
                Mouse a = (Mouse) animal;
                return a.getGender() != this.getGender() && a.age >= BREEDING_AGE && 
                this.age >= BREEDING_AGE;
            }
        }
        return false;
    }
}
