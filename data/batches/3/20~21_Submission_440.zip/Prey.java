import java.util.Iterator;
import java.util.List;

/**
 * A class representing shared characteristics of prey.
 *
 * @version 2021.03.02
 */
public abstract class Prey extends Animal
{
    /**
     * Constructs a prey.
     * @param randomAge Whether or not the animal is a newborn.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Looks for plants in surroundings and returns a location where there is plants
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if(object instanceof Plant) {
                Plant plant = (Plant) object;
                setFoodLevel(Plant.getFoodValue());
                return where;
            }
        }
        return null;
    }
    
    /**
     * @return The food value supplied by the prey.
     */
    abstract public int getFoodValue();
}
