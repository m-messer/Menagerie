import java.util.List;
import java.util.Iterator;

/**
 * A class representing an Owl, owls are predators active at night.
 *
 * @version 2021.03.02
 */
public class Owl extends Predator
{
    // Whether or not the animal is active during the day.
    private static final boolean ACTIVE_IN_DAY = false;
    // The age at which an animal can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which an animal can live.
    private static final int MAX_AGE = 25;
    // The likelihood of an animal breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    //The food level when born.
    private static final int FOOD_LIMIT = 11;

    /**
     * Constructor for objects of class Owl, generates it's age and food level.
     * 
     * @param randomAge Whether or not the animal is a newborn.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Owl(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        super.generateAge(randomAge, MAX_AGE, FOOD_LIMIT);
    }
    
    /**
     * @return Whether or not the animal is active during the day.
     */
    public boolean isActiveInDay()
    {
        return ACTIVE_IN_DAY;
    }
    
    /**
     * Increments the age. Possible for animal to die.
     */
    protected void incrementAge() 
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOwls A list to return newly born animals.
     */
    protected void giveBirth(List<Animal> newOwls) 
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Owl young = new Owl(false, field, loc);
            newOwls.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An owl can breed if it has reached the breeding age and meets an owl of the opposite gender 
     * that has also reached the breeding age.
     * @return True if they can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Owl) {
                Owl a = (Owl) animal;
                return a.getGender() != this.getGender() && a.age >= BREEDING_AGE && 
                        this.age >= BREEDING_AGE;
            }
        }
        return false;
    }
}
