
import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.02
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animals gender, true for female and false for male
    private boolean gender;
    // Current age
    protected int age;
    // Number of steps an animal can go before it has to eat again.
    protected int foodLevel;
    // True if the animal has a disease
    private boolean hasDisease;

    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge Whether or not the animal is a newborn.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        gender = generateGender();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newAnimals, DifferentWeather weather)
    {
        incrementAge();
        incrementHunger();
        // might move to each switch case per weather
        if(isAlive()) {
            giveBirth(newAnimals);
            weatherAct(weather);
        }

        contractDisease();
        spreadDisease();

        if(hasDisease && rand.nextDouble() < 0.1) {
            setDead();
        }

    }

    private void weatherAct(DifferentWeather weather) {
        // switch cases for each weather
        switch(weather) {
            case EARTHQUAKE:
            earthquakeAct();
            break;
            case RAIN:
            rainAct();
            break;
            case FOG:
            fogAct();
            break;
            case SUN:
            sunAct();
            break;
        }
    }

    /**
     * The animal has a random chance of getting sick.
     */
    protected void contractDisease()
    {
        if(rand.nextDouble() < 0.01) {
            hasDisease = true;
        }
    }

    /**
     * The animal has a random chance of spreading the disease to neighboring animals.
     */
    protected void spreadDisease()
    {
        if(hasDisease && location!=null) {
            List<Location> adjacent = field.adjacentLocations(location);
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Animal) {
                    Animal a = (Animal) animal;
                    a.contractDisease();
                }
            }
        }
    }

    private void normalMovement() {
        if(isAlive()) {
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Method for animals when weather raining. Makes animals more hungry
     */
    private void rainAct()
    {
        incrementHunger();
        normalMovement();
    }

    /**
     * Method for when weather is foggy. Makes animals move randomly (i.e. not hunting)
     */
    private void fogAct()
    {   
        if(isAlive()) {
            // Move towards random locaiton
            Location newLocation = field.randomAdjacentLocation(location);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Method for when weather is sunny. No side effects
     * @param nweAnimals is a list of new animals
     */
    private void sunAct()
    {
        normalMovement();
    }

    /**
     * Method for when earthquake occurs. Higher probability of death
     */   
    private void earthquakeAct()
    {
        double deathRate = 0.25;
        if(rand.nextDouble() < deathRate) {
            setDead();
        }
        normalMovement();
    }

    /**
     * @return A location that has food.
     */
    abstract protected Location findFood();

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    abstract protected void giveBirth(List<Animal> newAnimals);

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    abstract protected int breed();

    /**
     * An animal can breed if it has reached the breeding age.
     */
    abstract protected boolean canBreed();

    /**
     * @return A random gender.
     */
    private boolean generateGender() 
    {
        if(rand.nextDouble()>0.5) {
            return true;
        }
        else {
            return false;
        }
        //return rand.nextBoolean();
    }

    /**
     * Generates the animal's age and food level.
     * A random age and food level is given if the animal is not a newborn, and 
     * random age and food level is set to default values if they are newborn.
     * @param randomAge False if the animal is newborn
     * @param maxAge The maximum possible age to generate.
     * @param foodLevelLimit The limit of food to generate an animal with.
     */
    protected void generateAge(boolean randomAge, int maxAge, int foodLevelLimit)
    {
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(foodLevelLimit);
        }
        else {
            age = 0;
            foodLevel = foodLevelLimit;
        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * @return The animal's gender.
     */
    public boolean getGender() 
    {
        return gender;
    }

    /**
     * @return True if the animal is acting during the day, false otherwise.
     */
    abstract public boolean isActiveInDay();

    /**
     * Increase the age by one.
     * This could result in the animals death.
     */
    abstract protected void incrementAge();

    /**
     * Decrease the food level by one. The animal dies if it's food level becomes 0.
     */
    protected void incrementHunger() 
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increase the animal's food level.
     * @param n The amount to increase by.
     */
    protected void setFoodLevel(int n) 
    {
        foodLevel += n;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
