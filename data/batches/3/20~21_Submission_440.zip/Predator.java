import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of predators. 
 * When predators are not full, they will hunt for prey in adjacent locations.
 *
 * @version 2021.03.02
 */
public abstract class Predator extends Animal
{
    private static final double HUNTING_PROBABILITY = 0.02;
    /**
     * Create a new Predator.
     * @param randomAge Whether or not the animal is a newborn.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * If the predators food level is below a certain level it will try to hunt 
     * prey in adjacent locations.
     * @return The location of the prey.
     */
    protected Location findFood()
    {
        if(foodLevel > 20 && rand.nextDouble() > HUNTING_PROBABILITY) {
            return null;
        }
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    setFoodLevel(prey.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
}
