import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Baleen Whale.
 * 
 * Baleen Whales age, move, breed, and die. 
 * Some Baleen whales are born with a terminal disease and 
 * can spread it to other baleen whales.
 * It is active during the day.
 *
 * @version 2020.02.02 (3)
 */
public class BaleenWhale extends Animal
{
    // Characteristics shared by all baleen whales (class variables)
 
    // The age at which a baleen whales can start to breed.
    private static final int BREEDING_AGE = 50;
    
    // The likelihood of a baleen whale breeding
    private static final double BREEDING_PROBABILITY = 0.65;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single plant of phytoplankton.
    // The max number of steps it can travel after.
    private static final int PYTHOPLANKTON_FOOD_VALUE = 10;
    // The food value of a single fish. 
    private static final int SMALLFISH_FOOD_VALUE = 8;
    // The likelihood of an infected baleen whale to pass on the disease. 
    private static final double INFECTION_RATE = 0.70; 
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    
    // Individual characteristics (instance fields).
    // The age to which a baleen whales can live.
    private int MAX_AGE = 200;
    // The whales's age.
    private int age;
    // The whale's food level, which is increased by eating organisms.
    private int foodLevel;
    // Whether or not the whale has the disease
    private boolean disease;

    /**
     * Create a whale. A whale can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the whale will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public BaleenWhale(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PYTHOPLANKTON_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PYTHOPLANKTON_FOOD_VALUE;
        }
        
        //Setting up if the whale has the disease
        setDiseaseStatus();
        
    }
    
    /**
     * Decides whether Whale has disease if so
     * it's life span is shortened
     */
    public void setDiseaseStatus()
    {
        int tempValue=rand.nextInt(10);
        if (tempValue==0){
            disease=true;
            //If the whale is younger than 150, thier life span shortens by 50 years
            if(age<=150){
                MAX_AGE=age+50;
            }
        }
        else{
            disease=false;
            
        }   
    }
    
     /**
     * @return The disease status of a whale.
     */
    public boolean getDiseaseStatus()
    {
          return disease;
    }
    
    /**
     * This is what the whale does most of the time. It sleeps at night and is 
     * awake during the day. If it is awake: it hunts for animals. In the process,
     * it might breed, die of hunger,or die of old age or diease. 
     * When it is asleep, it does not do anything except age. 
     * 
     * @param newWhales A list to return newly born whales.
     */
    public void act(List<Organism> newWhales)
    {
        incrementAge();
        if (!isAwake()){
            //doesn't do anything if asleep
            return;
        }
        
        
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWhales);
            //it may spread disease with neighbouring baleen whales
            spreadDisease();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the whale's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this whale more hungry. This could result in the whale's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for food adjacent to the current location.
     * Only the first live and awake or mature organism is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Phytoplankton) {
                Phytoplankton phytoplankton = (Phytoplankton) organism;
                if(phytoplankton.isAlive()&& phytoplankton.isMature() ) { 
                    phytoplankton.setEaten();
                    foodLevel = PYTHOPLANKTON_FOOD_VALUE;
                    return null;
                }
            }
            
            else if(organism instanceof SmallFish) {
                SmallFish smallFish = (SmallFish) organism;
                if(smallFish.isAlive() && smallFish.isAwake()) { 
                    smallFish.setDead();
                    foodLevel = SMALLFISH_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Look for other whales in areas adjacent to the current location.
     * If the first baleen whale has the disease, then it may contract it. 
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof BaleenWhale) {
                BaleenWhale baleenWhale = (BaleenWhale) organism;
                if(baleenWhale.getDiseaseStatus()&& baleenWhale.isAlive()) { 
                    if(rand.nextDouble() <= INFECTION_RATE){
                        disease=true;
                        if(age<= 150){
                            MAX_AGE= age+50;
                        }
                    }
                }
            }
        }
        
    }
    
    /**
     * Check whether or not this whale is to give birth at this step.
     * If it is in a neighboring location with a whale of the opposite gender, 
     * new births will be made into free adjacent locations.
     * @param newWhales A list to return newly born whales.
     */
    private void giveBirth(List<Organism> newWhales)
    {
        // New Whales are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // Get a list of all adjacent locations, which may include mate
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof BaleenWhale) {
                BaleenWhale mate = (BaleenWhale) animal;
                if (mate.getGender() != getGender()){
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        BaleenWhale young = new BaleenWhale(false, field, loc);
                        newWhales.add(young);
                    }
                    return;
                }
            }
        }
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A whale can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}