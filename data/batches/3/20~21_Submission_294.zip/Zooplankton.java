
/**
 * A simple model of an zooplankton plant.
 *
 * @version 2020.03.02
 */
public class Zooplankton extends Plant
{

    
    /**
     * Create a new zooplankton plant.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zooplankton(Field field, Location location)
    {
        super(location, field);
        
    }


}

