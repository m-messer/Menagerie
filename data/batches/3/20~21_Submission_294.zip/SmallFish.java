import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a small fish.
 * Fish age, move, eats, and dies.
 * It's active during the day and night.
 *
 * @version 2020.02.02 (3)
 */
public class SmallFish extends Animal

{
    // Characteristics shared by all SmallFish (class variables).
   
    // The age at which a fish can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a fish can live
    private static final int MAX_AGE = 60;
    // The likelihood of a fish breeding.
    private static final double BREEDING_PROBABILITY = 0.85;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of zooplanton.
    // The max number of steps it can travel after.
    private static final int ZOOPLANKTON_FOOD_VALUE = 10;
    // The food value of algae.
    private static final int ALGAE_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
   
    // Individual characteristics (instance fields).
    // The small fish age.
    private int age;
    // The small fish's food level, which is increased by eating plants.
    private int foodLevel;

    /**
     * Create a small fish. A smallfish can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the small fish will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public SmallFish(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ZOOPLANKTON_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ZOOPLANKTON_FOOD_VALUE;
        }
        
    }
   
    /**
     * This is what the small fish does most of the time: it searches for
     * zooplankton and algae. In the process, it might breed, die of hunger,
     * or die of old age. It is always awake. 
     * @param field The field currently occupied.
     * @param newFish A list to return newly born small fish.
     */
    public void act(List<Organism> newFish)
    {
        incrementAge();
        
        incrementHunger();
        if(isAlive()) {
            giveBirth(newFish);            
            // Move towards a source of food if found.
            if(weather.getWind()){
                if(age%2==0){
                    Location newLocation = findFood();
                    if(newLocation == null) {
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                }
            }
         }
    }

    /**
     * Increase the age. This could result in the small fish's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
   
    /**
     * Make this fish more hungry. This could result in the fish's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
   
    /**
     * Look for algae and zooplankton adjacent to the current location.
     * Only the first aglae or zooplankton is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Algae) {
                Algae algae = (Algae) plant;
                if(algae.isAlive() && algae.isMature()) {
                    algae.setEaten();
                    foodLevel = ALGAE_FOOD_VALUE;
                    return null;
                }
            }
            else if(plant instanceof Zooplankton){
                Zooplankton zooplankton = (Zooplankton) plant;
                if(zooplankton.isAlive() && zooplankton.isMature()) {
                    zooplankton.setEaten();
                    foodLevel = ZOOPLANKTON_FOOD_VALUE;
                    return null;
                }

            }    
        }
        return null;
    }
   
    /**
     * Check whether or not this Small fish is to give birth at this step.
     * If it is in a neighboring location with a fish of the opposite gender, 
     * New births will be made into free adjacent locations.
     * @param newFish A list to return newly born fish.
     */
    private void giveBirth(List<Organism> newFish)
    {
        //New fish are born into adjacent locations.
        //Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // Get a list of all adjacent locations, which may include mate
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof SmallFish) {
                SmallFish mate = (SmallFish) animal;
                if (mate.getGender() != getGender()){
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        SmallFish young = new SmallFish(false, field, loc);
                        newFish.add(young);
                    }
                    return;
                }
            }
        }
       
    }
       
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A small fish can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
