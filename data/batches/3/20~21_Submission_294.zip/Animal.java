import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.02 (3)
 */
public abstract class Animal extends Organism
{
    //the gender of the animal
    private final int gender;
    
    //whether the animal is awake or not
    private boolean awake;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location )
    {
        super(field, location);
        Random rand = new Random();
        gender= rand.nextInt(2);
        awake = true;
        
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Organism> newAnimals);
    
    /**
     * Returns the gender of the animal.
     * @return The gender of the animal
     */
    protected int getGender()
    {
        return gender;
    }
    
    /**
     * Returns true if the animal is awake, otherwise false.
     * @return The animal's awake status.
     */
    public boolean isAwake()
    {
        return awake;
    }
    
    /**
     * Switches the awake status of an animal.
     */
    public void changeAwake()
    {
        if (awake==true){
            awake=false;
        }
        else{
            awake=true;
        }
    }
   

}