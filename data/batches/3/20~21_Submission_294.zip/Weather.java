import java.util.Random;

/**
 * Represents the shared weather conditions of the Simulator 
 *
 * @version 2020.03.02 (1)
 */
public class Weather
{
    // storing whether it's sunny or not
    private boolean sun;
    
    // storing whether it's windy or not
    private boolean wind;
    
    // a randomiser to decide the current weather conditon
    private static final Random rand = Randomizer.getRandom();
    /**
     * Assigns value to instance variables sun and wind
     * by calling chooseRandom() method
     */
    public Weather()
    {
        //to set instance variables
        chooseRandom();
    }

    /**
     * Randomly assigning a boolean value for the two
     * weather conditions wind and sun
     *
     */
    public void chooseRandom()
    {
        // There is a 50% chance of sun or wind
        int tempsun = rand.nextInt(2);
        int tempwind = rand.nextInt(2);
        
        //Setting the sun variable as the result of the randomiser
        if (tempsun==0){
            sun=false;
        }
        else{
            sun=true;
        }
        
        //Setting the wind variable as the result of the randomiser
        if (tempwind==0){
            wind=false;
        }
        else{
            wind=true;
        }
    }
    
    /**
     * @return the current value of sun
     */
    public boolean getSun()
    {
        return sun;
    }
    
    /**
     * @return the current value of wind
     */
    public boolean getWind()
    {
        return wind;
    }
}
