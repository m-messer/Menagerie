import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Dolphin.
 * Dolphins age, move, breed, and die.
 * It's active during the day.
 *
 * @version 2020.02.02 (3)
 */
public class Dolphin extends Animal
{
    // Characteristics shared by all dolphins (class variables).
    
    // The age at which a dolphin can start to breed.
    private static final int BREEDING_AGE = 23;
    // The age to which a dolphin can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a dolphin breeding
    private static final double BREEDING_PROBABILITY = 0.55;
    // The amount of ingested plastic that can kill it.  
    private static final double MAX_PLASTIC_INTAKE = 5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single fish.
    // The max number of steps it can travel after.
    private static final int SMALLFISH_FOOD_VALUE = 8;
    // The food value of a single octopus.
    private static final int OCTOPUS_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The dolphin's age.
    private int age;
    // The dolphin's food level, which is increased by eating animals.
    private int foodLevel;
    // The amount of plastic the dolphin has ingested.
    private int plasticIntake=0;

    /**
     * Create a dolphin. A dolphin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the dolphin will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Dolphin(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(OCTOPUS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = OCTOPUS_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the dolphin does most of the time. It sleeps at night and is 
     * awake during the day. If it is awake: it hunts for animals. In the process,
     * it might breed, die of hunger,die of old age or die from eating too much
     * plastic.
     * 
     * @param newDolphins A list to return newly born dolphins.
     */
    public void act(List<Organism> newDolphins)
    {
        incrementAge();
        if (!isAwake()){
            return;
            //doesn't do anything if it's sleeping
        }
        
        incrementHunger();
        if(isAlive()) {
            // Check if it has ingested the max number of plastic it can handle
            if(plasticIntake>=MAX_PLASTIC_INTAKE){
                setDead();
                return;
            }
            giveBirth(newDolphins);
            // Move towards a source of food if found.
            Location newLocation = findFood();

            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the dolphin's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this dolphin more hungry. This could result in the dolphins's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for octopuses and fish adjacent to the current location.
     * Only the first live octopus or fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Octopus) {
                Octopus octopus = (Octopus) animal;
                if(octopus.isAlive() && octopus.isAwake()) {
                    if (octopus.getPlasticStatus()){
                        //incremented the amount octopus with plastic it's eaten
                        plasticIntake++;
                    }
                    octopus.setDead();
                    foodLevel = OCTOPUS_FOOD_VALUE;
                    return where;
                }
               
            }
            else if(animal instanceof SmallFish){  
                    SmallFish smallFish = (SmallFish) animal;
                    if(smallFish.isAlive() && smallFish.isAwake()) {
                        smallFish.setDead();
                        foodLevel = SMALLFISH_FOOD_VALUE;;
                        return where;
                    }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this dolphin is to give birth at this step.
     * If it is in a neighboring location with a dolphin of the opposite gender,
     * New births will be made into free adjacent locations.
     * @param newDolphins A list to return newly born dolphin.
     */
    private void giveBirth(List<Organism> newDolphins)
    {
        // New dolphins are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // Get a list of all adjacent locations, which may include mate
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Dolphin) {
                Dolphin mate = (Dolphin) animal;
                if (mate.getGender() != getGender()){
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Dolphin young = new Dolphin(false, field, loc);
                        newDolphins.add(young);
                    }
                    return;
                }
            }
        }
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A dolphin can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}