import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an Octopus.
 * Octopus's age, move, eats, and dies.
 * It's active during the day and night
 *
 * @version 2020.02.02 (3)
 */
public class Octopus extends Animal
{
    // Characteristics shared by all octopuses (class variables).
    
    // The age at which a octopus can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a octopus can live.
    private static final int MAX_AGE = 50;
    // The likelihood of an octopus breeding
    private static final double BREEDING_PROBABILITY = 0.74;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single plant of zooplankton.
    // The max number of steps it can travel after.
    private static final int ZOOPLANKTON_FOOD_VALUE = 14;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
   
    
    // Individual characteristics (instance fields).
    // The octopus's age.
    private int age;
    // The octopus's food level, which is increased by eating animals.
    private int foodLevel;
    // Whether or not the octopus has plastic in their body.
    private boolean hasPlastic;

    /**
     * Create an octopus. A octopus can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the octopus will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Octopus(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ZOOPLANKTON_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ZOOPLANKTON_FOOD_VALUE;
        }
        
        //the octopus may randomly have plastic in it's body
        setContainsPlastic();
    }
    
    /**
     * Randomly sets whether or not an octopus has plastic in its body
     */
    public void setContainsPlastic()
    { 
        // There's a 30% chance that they have plasitc in their body
        int tempValue= rand.nextInt(11);
        if (tempValue<=7){
            hasPlastic=false;
        }
        else{
            hasPlastic=true;
        }   
    }
    
    /**
     * @return The plastic status of an octopus.
     */
    public boolean getPlasticStatus()
    {
          return hasPlastic;
    }
    
    /**
     * This is what the octopus does most of the time: it soughts for
     * plants. In the process, it might breed, die of hunger,
     * or die of old age. It is always awake.
     * @param newOctopus A list to return newly born octopus.
     */
    public void act(List<Organism> newOctopus)
    {
        incrementAge();
        
        incrementHunger();
        if(isAlive()) {
            giveBirth(newOctopus);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the octopus's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this octopus more hungry. This could result in the octopus's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for octopus adjacent to the current location.
     * Only the first live zooplantok is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Zooplankton) {
                Zooplankton zooplankton = (Zooplankton) plant;
                if(zooplankton.isAlive() && zooplankton.isMature()) { 
                    zooplankton.setEaten();
                    foodLevel = ZOOPLANKTON_FOOD_VALUE;
                    return null;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this octopus is to give birth at this step.
     * If it is in a neighboring location with an octopus of the opposite gender,
     * new births will be made into free adjacent locations.
     * @param newOctopus A list to return newly born octopus.
     */
    private void giveBirth(List<Organism> newOctopus)
    {
        // New octopus are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // Get a list of all adjacent locations, which may include mate
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Octopus) {
                Octopus mate = (Octopus) animal;
                if (mate.getGender() != getGender()){
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Octopus young = new Octopus(false, field, loc);
                        newOctopus.add(young);
                    }
                    return;
                }
            }
        }
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A octopus can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
