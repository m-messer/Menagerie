import java.util.List;
import java.util.Random;

/**
 * Representing shared characteristics of all Plants
 *
 * @version 2020.03.02 (1)
 */
public abstract class Plant extends Organism
{ 
    //whether the plant has been eaten
    private boolean eaten = false;
    
    //The age where plants are old enough to be eaten
    protected static int MATURE_AGE = 4;
    
    //The plant's age
    protected int age;

    /**
     * Creates all plants as fully grown
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Location location, Field field)
    {
        super(field, location);
        
        //Intially sets all plants as fully grown; it's mature age
        age = 4;
    }
    
    /**
     * This is what the plant does most of the time: it grows,
     * when there is no sun, it takes longer to mature(grow)
     * 
     * @param newPlants A list of all plants.
     */
    public void act(List<Organism> newPlants){
        //Increments age
        if(isAlive()) {
           age++;
        }
        
        //Changes the mature age if there's no sun
        if(!weather.getSun()){
            MATURE_AGE=6;
        }
        else{
            MATURE_AGE=4;
        }
    } 
    
    /**
     * Sets age to 0
     */
    public void setEaten()
    {
        age=0;
    }
    
    /**
     * @return the value of eaten
     */
    public boolean getEaten()
    {
        return eaten; 
    }
    
    /**
    * @returns true if plant is of mature age
    */
    public boolean isMature()
    {
        return age>=MATURE_AGE;
    }
    
    
}