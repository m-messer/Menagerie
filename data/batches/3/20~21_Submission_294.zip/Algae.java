
/**
 * A simple model of an algae plant.
 *
 * @version 2020.03.02
 */
public class Algae extends Plant
{
    

    /** 
     * Create a new algae plant.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Algae(Field field, Location location)
    {
        super(location, field);
        
    }

    
}
