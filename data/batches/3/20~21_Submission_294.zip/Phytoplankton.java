
/**
 * A simple model of an phytoplankton plant.
 *
 * @version 2020.03.02
 */
public class Phytoplankton extends Plant
{
 

    /** 
     * Create a new phytoplankton plant.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Phytoplankton(Field field, Location location)
    {
        super(location, field);
        
    }
    
    
}

