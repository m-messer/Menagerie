import java.util.List ;
import java.util.Random ;
import java.util.Iterator ;
/**
 * A simple model of an octopus.
 * An octopus can eat, die, give birth, and move around
 *
 * @version 2021.03.01
 */
public class Octopus extends Animal 

{
    private static final int MAX_AGE = 120 ;
    private static final int BREEDING_AGE = 6;
    private static final double BREEDING_PROBABILITY = .42 ;
    private static final int MAX_LITTER_SIZE = 4;
    private static final int FISH_FOOD_VALUE = 5;
    private static final double INFECTION_SPREAD_PROBABILITY = 0.3;
    private static final Random rand = Randomizer.getRandom();
    private int age;
    private int foodLevel;
    private Disease disease;
    
    /**
     * Creates a new octopus with a random age and food value
     * @param randomAge If true, the octopus will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Octopus(boolean randomAge, Field field, Location location){
        super(field, location);
        disease = new Disease();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FISH_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FISH_FOOD_VALUE;
        }        
    }
     
    /**
     * This is how the octopus act. They give birth to new octopus, move
     * around, and look for food.
     * @param field The field currently occupied.
     * @param newOctopuses A list to return newly born octopuses.
     * @param isDay An indicator of whether it is day or night
     */
    public void act(List<Animal> newOctopuses, boolean isDay){
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newOctopuses);  
            spreadDisease(getField(),getLocation(),INFECTION_SPREAD_PROBABILITY);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    } 
    
    /**
     * Increases the age of the octopus
     * This could result in the octopus death
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this octopus more hungry. This could result in the octopus' death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
  
    
    /**
     * Look for fish adjacent to the current location.
     * Only the first live fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setDead();
                    foodLevel = FISH_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this octopus is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOctopuses A list to return newly born octopuses.
     */
    private void giveBirth(List<Animal> newOctopuses)
    {
        // New octopus are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Octopus young = new Octopus(false, field, loc);
            newOctopuses.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An octopus can breed if it has reached the breeding age.
     * @return gender True if isMale
     */
    private boolean canBreed()
    {
        Field field = getField();
        boolean gender = isMale();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()){
           Location loc = it.next();
           Object animal = field.getObjectAt(loc);
           if(animal instanceof Octopus){
               Octopus octopus = (Octopus) animal ;
               if(gender != octopus.isMale() && octopus.isAlive() && age >= BREEDING_AGE){
                   return true;
                }
            }
           
        }
        return false;
    }
}

