import java.util.*;
/**
 * A simple model of a plant.
 * A plant can grow taller and age
 *
 * @version 2021.03.01
 */
public class Plant extends HabitatConditions 
{
    private static final int BREEDING_AGE = 2;
    private static final int MAX_AGE = 60;
    private static final int MAX_HEIGHT = 6;
    
    private static final int MAX_LITTER_SIZE = 5;
    private static final Random rand = Randomizer.getRandom();
    
    private static double BREEDING_PROBABILITY = 0.78;
    private int age;
    private int height;
    private Weather weather ;
    
    /**
     * Creates a new plant with a random age and a height of 1
     * @param randomAge If true, the plant will have random age
     * @param field The field currently occupied
     * @param location The location within the field
     */
    public Plant(boolean randomAge, Field field, Location location){
        super(field, location);
        weather = new Weather();
        age = 0;
        height = 1;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }        
    }
    
    /**
     * This method shows how plants act during the different times of day and
     * weather conditions
     * @param newPlants A list to return newly born plants.
     * @param isDay Indicator of whether it is day or night
     */
    public void action(List<HabitatConditions> newPlants, boolean isDay){
        incrementAge();
        if(isAlive()){
            if(isDay){
                if("Summer".equals(weather.getWeather())){
                incrementHeight();
                incrementHeight();
                giveBirth(newPlants);
                
               }
                else{
                   incrementHeight();
                   giveBirth(newPlants);
                }
           }   
        }
    }
    
    /**
     * Plant grows older
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Increase in plant height
     */
    private void incrementHeight()
    {
        
        if(height<=MAX_HEIGHT){
            height++;
        }
    }
    
    /**
     * Returns the height of the plant
     * @return height - height of the plant
     */
    public int getHeight(){
        return height;
    }
    
    /**
     * This method shows how plants give birth
     * @param newPlants A list to return newly born plants.
     */
    private void giveBirth(List<HabitatConditions> newPlants){
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc);
            newPlants.add(young);
        }
    }
    
    /**
     * This method shows how plants breed and returns the number of births
     * @return births - number of births
     */
    private int breed(){
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * This method shows the scenario in which the plant can breed
     * @return true if plant can breed
     */
    private boolean canBreed(){
        Field field = getField();
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()){
           Location loc = it.next();
           Object tempPlant = field.getObjectAt(loc);
           if(tempPlant instanceof Plant){
               Plant plant = (Plant) tempPlant ;
               if( plant.isAlive() && age >= BREEDING_AGE){
                   return true;
                }
            }
           
        }
        return false;
    }
}
