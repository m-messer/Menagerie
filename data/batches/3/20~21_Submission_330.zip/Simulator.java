import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import javax.sound.sampled.*;


/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sharks, plants, fish, octopus, whale and tuna.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator 
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 250;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.039;
    // The probability that a fish will be created in any given grid position.
    private static final double FISH_CREATION_PROBABILITY = 0.07;   
    
    private static final double OCTOPUS_CREATION_PROBABILITY = 0.065;
    
    private static final double TUNA_CREATION_PROBABILITY = 0.068;
    private static final double WHALE_CREATION_PROBABILITY = 0.06;
    private static final double PLANT_CREATION_PROBABILITY = 0.098;
    
    
  

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private List<HabitatConditions> conditions;
    private Field field;
    // The current step of the simulation.
    private int step;
    private Random random;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    private Weather weather;
    private Disease disease;
    private int infected = 0;
    
    
    private int males = 0;
    private int females = 0;
    
    protected String dayOrNight;
    protected boolean isDay = false;
    
   /**
     * Construct a simulation field with default size.
     */
   public Simulator()
   {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
   }
    
   /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
   public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        conditions = new ArrayList<>();
        field = new Field(depth, width);
        
        weather = new Weather();
        disease = new Disease();
        random = new Random();
      
        

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Fish.class, Color.BLUE);
        view.setColor(Shark.class, Color.BLACK);
        view.setColor(Octopus.class, Color.MAGENTA);
        view.setColor(Tuna.class, Color.ORANGE);
        view.setColor(Whale.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);
        maleOrFemale();
        
        
        
        // Setup a valid starting point.
        reset();
        
    }
    
  /**
    * Run the simulation from its current state for a reasonably long period,
    * (100 steps).
   */
  public void runLongSimulation() 
    {
        simulate(500);
    }
    
  /**
   * This method sets the time of day to either Day or Night.
   * @param step The current number of steps
   */
  public void setDayAndNight(int step)
  {
        if(step % 15 == 0){
            dayOrNight = "NIGHT";
            isDay = false;
            
        } 
        
        if(step % 30 == 0){
            dayOrNight = "DAY";
            isDay = true;
            
        }
  }
    
  /**
   * @return isDay - boolean that expresses if it's day or night
   */
  public boolean isDay(){
        return isDay;
  }
  
  /**
   * @return dayOrNight - String that says either "DAY" or "NIGHT"
   */
  public String getDayAndNight(){
        return dayOrNight;
  }
  
  /**
   * Searches through the list of animals and then identifies the total number of males
   * and females that have been spotted in the simulation at any point.
   */
  private void maleOrFemale(){
      males = 0;
      females = 0;
      for(Iterator<Animal> iter = animals.iterator(); iter.hasNext();){ 
         Animal animal = iter.next(); 
         if(animal.isMale){
            view.stats.counters.get(animal.getClass()).males++;
         }else{
            view.stats.counters.get(animal.getClass()).females++;
         }
       }
    }
    
              
       
   /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
    */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            
            simulateOneStep();
            delay(80);   // uncomment this to run more slowly
        }
    }
    
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * species.
     */
    public void simulateOneStep() 
    {
        step++;
        setDayAndNight(step);
        maleOrFemale();
        
        weather.generateWeather(step, isDay);
        disease.generateDisease(DEFAULT_DEPTH,DEFAULT_WIDTH,step, field);

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, isDay);
            if(!animal.isAlive()) {
                it.remove();
            }
        }
        List<HabitatConditions> newConditions = new ArrayList<>();
        
        for(Iterator<HabitatConditions> it = conditions.iterator(); it.hasNext();){
            HabitatConditions condition = it.next();
            condition.action(newConditions, isDay);
           if(!condition.isAlive()){
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        conditions.addAll(newConditions);  //adds the plants to the conditions lists.
        
        

        view.showStatus(step, field, dayOrNight, weatherType(), weatherDuration(),remainingDuration(),infected());
   }
   
   /**
    * Returns the number of infected animals
    * @return infected The number of infected species
    */
    public int infected()
    {
        infected = disease.getInfected();
        return infected;
    }
        
   /**
     * Reset the simulation to a starting position.
     */
   public void reset() 
   {
        step = 0;
        animals.clear();
        conditions.clear();
        infected = 0;
        populate();
        
        setDayAndNight(step);
        
        
        // Show the starting state in the view.
        view.showStatus(step, field, dayOrNight,weatherType(), weatherDuration(),remainingDuration(),infected());
   }
    
   /**
    * @return weatherType. a String with the type of weather
    */
    public String weatherType(){
        String weatherType = weather.getWeather();
        return weatherType;
   }
   
   /**
    * @return weatherDuration - int that tells how long weather runs for
    */
   public int weatherDuration(){
        int weatherDuration = weather.getDuration();
        return weatherDuration;
   }
   
   
   /**
    * @return remDuration - int that tells remaining weather time
    */
   public int remainingDuration(){
        int remDuration = weather.getRemainingDuration();
        return remDuration;
   }
    
   /**
     * Randomly populate the field with animals.
     */
   private void populate()
   {
        Random rand = Randomizer.getRandom();
        field.clear();
        weather.generateWeather(step,isDay);
       
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fish fish = new Fish(true, field, location);
                    animals.add(fish);
                }
                else if(rand.nextDouble() <= OCTOPUS_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Octopus octopus = new Octopus(true, field, location);
                    animals.add(octopus);
                }
                else if(rand.nextDouble() <= TUNA_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Tuna tuna = new Tuna(true, field, location);
                    animals.add(tuna);
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Whale whale = new Whale(true, field, location);
                    animals.add(whale);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Plant plant = new Plant(true, field, location);
                    conditions.add(plant);
                }
                // else leave the location empty.
            }
            disease.generateDiseaseOutbreak(DEFAULT_DEPTH, DEFAULT_WIDTH,step,field);
        }
    }
    
   /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
