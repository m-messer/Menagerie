import java.util.List;
import java.util.Random;


/**
 * A class representing shared characteristics of animals.
 *
 * edited by Sundar Arvind and Shreyan Nageswaran
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Disease
{
    // Whether the animal is alive or not.
    private boolean alive;
    
    // The animal's field.
    private Field field;
    
    // The animal's position in the field.
    private Location location;
    
    // Whether the animal is a male
    public boolean isMale ;
    
    private Random random ;
    
    private boolean isInfected;
    
    private Disease disease;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        random = new Random();
        alive = true;
        isMale = randomGender();
        this.field = field;
        
        disease = new Disease();
        
        setLocation(location); 
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param isDay Boolean that states whether it is day or night
     */
    abstract public void act(List<Animal> newAnimals, boolean isDay);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Returns a true or false which indicates whether the animal is a male or female
     */
    protected boolean randomGender(){
        return (random.nextBoolean());
    }
    
    /**
     * Returns either true or false and if true then the animal is a male
     * @return true if animal is a male
     */
    protected boolean isMale(){
        return isMale;
    }
    
    /**
     * Returns true or false for whether or not the animal is infected
     * @return true if the animal is infected
     */
    protected boolean isInfected(){
        return isInfected;
    }
    
    /**
     * Sets the animal to be infected then increments the number of infected animals
     */
    protected void setInfected(){        
        isInfected = true;
        incrementInfected();        
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
