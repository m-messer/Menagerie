import java.util.*;
/**
 * This class describes how the animals in our simulation could potentially catch
 * a disease.
 *
 * @version 2021.03.01
 */
public class Disease
{
    private static final double BACTERIAL_INFECTION_PROBABILITY = 0.15;
    private static final double PLASTIC_HAZARD_INFECTION_PROBABILITY = 0.35;
    private String diseaseType;
    private Random rand;
    protected int infected;
    public Disease(){
        diseaseType = null;
        rand = new Random();
        infected = 0;
    }
    
    /**
     * Creates a random disease based on the infection probabilities
     */
    public void randomDisease(){
        if(rand.nextDouble()<= BACTERIAL_INFECTION_PROBABILITY){
            diseaseType = "Bacterial Infection";            
        }
        else {
            diseaseType = "Viral Infection";
        }    
    }
    
    /**
     * Generates a random disease and deploys it into the simulation
     * @param depth - depth of simulation
     * @param width - width of simulation
     * @param steps - number of steps 
     * @param field - field occupied
     */
    public void generateDisease(int depth, int width,int steps, Field field){
        if(steps % 100 == 0){
            randomDisease();
            generateDiseaseOutbreak(depth,width,steps,field);
        }
    }
    
    /**
     * Returns the type of disease
     * @return String with type of disease
     */
    public String getDiseaseType(){
        return diseaseType;
    }
    
    /**
     * Deploys the disease into the simulation view
     * @param depth - depth of simulation
     * @param width - width of simulation
     * @param steps - number of steps 
     * @param field - field occupied
     */
    public void generateDiseaseOutbreak(int depth, int width,int steps, Field field)
    {
       if(steps == 0){
            infected = 0;
            int outbreakRow = rand.nextInt(depth -10);
            int outbreakColumn = rand.nextInt(width - 10);
            Location outbreakLocation = new Location(outbreakRow, outbreakColumn);
            List<Location> outbreakLocations = field.adjacentLocationsWider(outbreakLocation);
            Iterator<Location> it = outbreakLocations.iterator();
            while(it.hasNext()){
               Location where = it.next();
               Object animal = field.getObjectAt(where);
               if(animal instanceof Animal){
                      Animal tempAnimal = (Animal) animal;
                      tempAnimal.setInfected();
                      infected++;
               }
            }
        }
        else{
        int outbreakRow = rand.nextInt(depth -10);
        int outbreakColumn = rand.nextInt(width - 10);
        Location outbreakLocation = new Location(outbreakRow, outbreakColumn);
        List<Location> outbreakLocations = field.adjacentLocationsWider(outbreakLocation);
        Iterator<Location> it = outbreakLocations.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal){
                Animal tempAnimal = (Animal) animal;
                tempAnimal.setInfected();
                infected++;
                
            }
         }
      }
    }
    
    /**
     * Spreads the disease to adjacent animals
     * @param location - location in the field
     * @param field - field occupied
     * @param infectionProbability - probability of infection occuring
     */
    public void spreadDisease(Field field, Location location,double infectionProbability){
        
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        
           
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal){
              Animal inf = (Animal) animal;  
              if(!inf.isInfected()) 
                
                if(inf.isAlive()&& (rand.nextDouble()<= infectionProbability)) { 
                    inf.setInfected();
                    infected++;
                }
             }          
        }
    }
    
    /**
     * Returns the number of infected animals
     * @return infected - num of infected animals
     */
    public int getInfected(){
       return infected;
    }
    
    /**
     * Increments the number of infected animals
     */
    public void incrementInfected(){
        infected++;
    }
}
