import java.util.*;


/**
 * This class creates and implements different weather conditions into our simulation.
 *
 * @version 2021.03.01
 */
public class Weather 
{
    private static final int WEATHER_MAX_DURATION = 40;
    private static final int WEATHER_MIN_DURATION = 10;
    private static double HEAT_PROBABILITY = 0.7;
    private static double STORM_PROBABILITY = 0.6;
    private Random rand;
    private String weatherType ;
    private boolean isStorm;
    private boolean isHeat;
    private int weatherTimer;
    private int startStep;
    private int remainingDuration;
   
    /**
     * Creates a type of weather
     */
    public Weather(){
        weatherType = null;
        isHeat = false;
        isStorm = false;
        weatherTimer = WEATHER_MIN_DURATION;
        startStep = 0;
        remainingDuration = 0;
        rand = new Random();
    }
    
    /**
     * Generates a weather condition and sets the time for how long it lasts for
     * @param steps - num of steps 
     * @param isDay Indicator of whether it is day or night
     */
    public void generateWeather(int steps, boolean isDay){
        remainingDuration = steps - startStep;
        Weather weather = new Weather();
        if((remainingDuration) % weatherTimer == 0){
            randomWeather(steps, isDay);
        }
    }
    
    /**
     * Creates a random weather condition based on the different probabilities for
     * each weather condition
     * @param steps - num of steps 
     * @param isDay Indicator of whether it is day or night
     */
    public void randomWeather(int steps, boolean isDay){
        startStep = steps;
        if(isDay){
            HEAT_PROBABILITY = 0.75;
            
            if(rand.nextDouble() <= HEAT_PROBABILITY){
                isStorm = false;
                weatherType = "Summer";
                isHeat = true;
                weatherTimer = WEATHER_MIN_DURATION + rand.nextInt(WEATHER_MAX_DURATION - WEATHER_MIN_DURATION);
                
                
            }
            else if (rand.nextDouble() <= STORM_PROBABILITY){
                isHeat = false;
                weatherType = "Storm";
                isStorm = true;
                weatherTimer = WEATHER_MIN_DURATION + rand.nextInt(WEATHER_MAX_DURATION - WEATHER_MIN_DURATION);
                
            }
            else {
                isHeat = false;
                isStorm = false;
                weatherType = null;
            }
            
        }
        else {
            
            STORM_PROBABILITY = .7;
            if(rand.nextDouble() <= HEAT_PROBABILITY){
                isStorm = false;
                weatherType = "Summer";
                isHeat = true;
                
            }
            else if (rand.nextDouble() <= STORM_PROBABILITY){
                isHeat = false;
                weatherType = "Storm";
                isStorm = true;
                
            }
            else {
                isHeat = false;
                isStorm = false;
                weatherType = null;
            }
        }   
    } 
    
    /**
     * Returns the current weather type
     * @return String of type of weather
     */
    public String getWeather(){
        return weatherType;
    }
    
    /**
     * Returns whether or not the type of weather is a storm
     * @return true if there is a storm
     */
    public boolean isStorm(){
        return isStorm;
    }
    
    /**
     * Returns whether or not the type of weather is summer
     * @return true if it is summer
     */
    public boolean isSummer(){
        return isHeat;
    }
    
    /**
     * Returns the amount of time each weather condition lasts for
     * @return int weatherTimer - integer of how long weather lasts for 
     */
    public int getDuration(){
        return weatherTimer;
    }
    
    /**
     * Returns the amount of time remaining of the current weather condition
     * @return int remainingDuration - integer of remaining time on weather
     */
    public int getRemainingDuration(){
        return remainingDuration;
    }
    
    
   
}
