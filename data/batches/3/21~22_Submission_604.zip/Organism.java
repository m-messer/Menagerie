import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of organisms.
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // Whether the organism is male or not.
    private boolean male;
    // Whether two organism of opposite gender come into to contact with one another.
    private boolean nextTo;
    // The current age of the organisms.
    protected int age;
    // The age at which the organisms can reproduce.
    protected int breedingAge;
    // Whether or not the organism has the disease.
    private boolean diseased;
    // Whether an organism with a disease has come in contact with an organism that doesn't have the disease. 
    private boolean meetDisease;
 
    //
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        // Sets the gender of all organims in the simulation
        setGender();
    }
    
    /**
     * Make this organism act - that is: make it do
     * whatever ait wants/needs to do.
     * @param newOrganisms A list to receive newly born organisms.
     */
    abstract public void act(List<Organism> newOrganisms);

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Sets the gender of an organism, there is a 50% chance of the organism being either male or female.
     * @return true if the organism is male.
     * @return false if the organism if female.
     */
    protected void setGender()
    {
        if (Math.random() > 0.5){
            male  = true;
        }
        else{
            male = false;
        }
    }
    
    protected void setBreedingAge(int age)
    {
        breedingAge = age;
    }
    
    /**
     * Checks if the organism is able to mate. They can given that they are past their breeding age and are in 
     * contact with another organism of the same species and opposite gender.
     */
    protected boolean canBreed()
    {
        if (age >= breedingAge && getMeet()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Checks if the organism has come into contact with another organism. if it has they will spread the disease to them.
     */
    protected boolean giveDisease()
    {
        if (getDiseaseMeet()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Check whether the organism is in contact with another organims of the opposite gender.
     */
    protected boolean getMeet()
    {
        Field field = getField();
        List<Location> loc = field.adjacentLocations(getLocation());
        Iterator<Location> it = loc.iterator();
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if (object instanceof Organism){
                Organism organism = (Organism) object;
                if (organism.checkMale() != this.checkMale()){
                    nextTo = true;
                }
                else{
                    nextTo = false;
                }
            }
        return nextTo;
    }
    
    protected boolean checkMale()
    {
        return male;
    }
    protected void setMale(boolean set)
    {
        male = set;
    }
    
    protected boolean checkDiseased()
    {
        return diseased;
    }
    protected void setDiseased(boolean set)
    {
        diseased = set;
    }
    
    /**
     * Check whether the organism is in contact with another organims with a disease. If so, the disease will spread to them.
     */
    private boolean getDiseaseMeet()
    {
        Field field = getField();
        List<Location> loc = field.adjacentLocations(getLocation());
        Iterator<Location> it = loc.iterator();
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if (object instanceof Organism){
                Organism organism = (Organism) object;
                if (organism.checkDiseased() != this.checkDiseased()){
                    meetDisease = true;
                }
                else{
                    meetDisease = false;
                }
            }
        return meetDisease;
    }
    
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    
}
