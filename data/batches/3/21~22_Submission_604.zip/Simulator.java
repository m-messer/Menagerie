import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.Timer;
import java.util.TimerTask;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.015;
    // The probability that a orca will be created in any given grid position.
    private static final double ORCA_CREATION_PROBABILITY = 0.02;
    // The probability that a seal will be created in any given grid position.
    private static final double SEAL_CREATION_PROBABILITY = 0.07; 
    // The probability that a turtle will be created in any given grid position.
    private static final double TURTLE_CREATION_PROBABILITY = 0.1;  
    // The probability that a seabird will be created in any given grid position.
    private static final double SEABIRD_CREATION_PROBABILITY = 0.07;  
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.08;

    
    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Seal.class, Color.LIGHT_GRAY);
        view.setColor(Shark.class, Color.BLUE);
        view.setColor(Orca.class, Color.RED);
        view.setColor(Turtle.class, Color.ORANGE);
        view.setColor(Seabird.class, Color.PINK);
        view.setColor(Seaweed.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(500);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(20); 
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn organisms.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all rabbits act.
        if (step%3==0){
        // Every third step indicates the transition from day to night, when it is night time, all 
        // organisms go to sleep and do not move, hence do nothing.
            ;
        }
        else{
        // In the steps between night stages, it is day time, during this period, all organisms 
        // are able to move and act.
            for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
                Organism organism = it.next();
                organism.act(newOrganisms);
                if(! organism.isAlive()) {
                    it.remove();
                }
            }
        }
        
            // Add the newly born foxes and rabbits to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
        
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with all the organisms in the simulation: sharks, orcas,
     * seals, turtles, seabirds and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    // Will set a random probability of a shark spawning with a disease.
                    shark.probDisease();
                    organisms.add(shark);
                }
                else if(rand.nextDouble() <= ORCA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Orca orca = new Orca(true, field, location);
                    // Will set a random probability of an orca spawning with a disease.
                    orca.probDisease();
                    organisms.add(orca);
                }
                else if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location);
                    // Will set a random probability of a seal spawning with a disease.
                    seal.probDisease();
                    organisms.add(seal);
                }
                else if(rand.nextDouble() <= TURTLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Turtle turtle = new Turtle(true, field, location);
                    // Will set a random probability of a turtle spawning with a disease.
                    turtle.probDisease();
                    organisms.add(turtle);
                }
                else if(rand.nextDouble() <= SEABIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seabird seabird = new Seabird(true, field, location);
                    // Will set a random probability of a seabird spawning with a disease.
                    seabird.probDisease(); 
                    organisms.add(seabird);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seaweed plant = new Seaweed(true, field, location);
                    organisms.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
