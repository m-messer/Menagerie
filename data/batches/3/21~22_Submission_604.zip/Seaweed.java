import java.util.List;
import java.util.Random;

/**
 * A simple model of a seaweed.
 * seaweeds age and die.
 */
public class Seaweed extends Organism
{
    // Characteristics shared by all seaweeds (class variables).

    // The age to which a seaweed can live before dying of natural causes.
    private static final int MAX_AGE = 1050;
    // The maximum number of new seaweeds produced.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The seaweed's age.
    private int age;

    /**
     * Create a new seaweed. A seaweed may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the seaweed will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seaweed(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the seaweed does most of the time, it does not move 
     */
    public void act(List<Organism> newSeaweeds)
    {
        incrementAge();
    }

    /**
     * Increase the age.
     * This could result in the seaweed's death after some time.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

}
