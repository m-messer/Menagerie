import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a seabird.
 * seabirds age, move, breed, and die.
 */
public class Seabird extends Organism
{
    // Characteristics shared by all seabirds (class variables).

    // The age at which a seabird can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a seabird can live before dying of natural causes.
    private static final int MAX_AGE = 12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The likelihood of a SeaBird spawning with a disease.
    private static final double DISEASE_PROBABILITY = 0.1;
    
    // Individual characteristics (instance fields).
    
    // The seabird's age.
    private int age;
        // The likelihood of a seabird breeding.
    private static  double BREEDING_PROBABILITY = 0.1;
 
    /**
     * Create a new seabird. A seabird may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the seabird will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seabird(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the seabird does most of the time - it flys around, and lands on 
     * the surface of the water from time to time. Sometimes it will breed, die or get eaten by a predator.
     * @param newseabirds A list to return newly born seabirds.
     */
    public void act(List<Organism> newSeabirds)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newSeabirds);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the seabird's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this seabird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newseabirds A list to return newly born seabirds.
     */
    private void giveBirth(List<Organism> newSeabirds)
    {
        // New seabirds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seabird young = new Seabird(false, field, loc);
            newSeabirds.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
        
    /**
     * Simulate disease. Some animals are occasionally infected.
     * if a seabird catches the disease, it will die.
     */
    public boolean probDisease()
    {
        boolean disease = false;
        if(rand.nextDouble() <= DISEASE_PROBABILITY) {
            disease = true;
            if (disease = true){
                setDead();
            }
        }
        return disease;
    }
}

