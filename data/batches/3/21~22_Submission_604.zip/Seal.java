import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a seal.
 * seals age, move, eat, and die. Seals only eat turtles.
 */
public class Seal extends Organism
{
    // Characteristics shared by all turtles (class variables).

    // The age at which a turtle can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a turtle can live before dying of natural causes.
    private static final int MAX_AGE = 65;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 100;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single turtle. In effect, this is the
    // number of steps a turtle can go before it has to eat again.
    private static final int PREY_FOOD_VALUE = 30;    
    // The likelihood of a orca spawning with a disease.
    private static final double DISEASE_PROBABILITY = 0.005;
    
    // Individual characteristics (instance fields).
    
    // The seal's age.
    private int age;
    // The seal's food level, which is increased by eating turtles.
    private int foodLevel;
    // The likelihood of a turtle breeding.
    private static double BREEDING_PROBABILITY = 0.25;

    /**
     * Create a new seal. A seal may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the seal will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seal(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the seal does most of the time - it runs 
     * around. Sometimes it will breed or die of old age or get eaten by a predator.
     * @param newseals A list to return newly born seals.
     */
    public void act(List<Organism> newSeals)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newSeals);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Make this seal more hungry. This could result in the seal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for prey(turtles) adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Turtle) {
                Turtle turtle = (Turtle) organism;
                if(turtle.isAlive()) { 
                    turtle.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Increase the age.
     * This could result in the seal's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this seal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newseals A list to return newly born seals.
     */
    private void giveBirth(List<Organism> newSeals)
    {
        // New seals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seal young = new Seal(false, field, loc);
            newSeals.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Simulate disease. Some animals are occasionally infected.
     * Seals that are infected will have 10 steps removed from their lifespan
     * It will also decrease the seals current foodLevel by 2, meaning it can no go less steps before it needs to eat again.
     * The probability that the infected seals will be able to reproduce will also be decreased by 0.01.
     */
    public boolean probDisease()
    {
        boolean disease = false;
        if(rand.nextDouble() <= DISEASE_PROBABILITY) {
            disease = true;
            if (disease = true){
               foodLevel = foodLevel - 2;
               age = age + 10;
               BREEDING_PROBABILITY = BREEDING_PROBABILITY - 0.01;
            }
        }
        return disease;
    }
}

