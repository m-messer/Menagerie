import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a bluebird
 * Bluebirds age, move, eat grasshoppers and slugs, breed and die.
 *
 * @version 2022.02.26
 */
public class Bluebird extends Animal
{
    // Characteristics shared by all rates (class variables).
    // The age at which a bluebird can start to breed.
    private static final int BREEDING_AGE = 50;
    // The age to which a bluebird can live.
    private static final int MAX_AGE = 1500;
    // The likelihood of a bluebird breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single grasshopper and slug. In effect, this is the
    // number of steps a bluebird can go before it has to eat again.
    private static final int GRASSHOPPER_FOOD_VALUE = 25;
    private static final int SLUG_FOOD_VALUE = 25;
    // Decrease the maximum age of the bluebird by this amount to simulate it
    // having a shorter life expectancy
    private static final int DISEASE_DECREASE_AGE = 50;
    
    // Individual characteristics (instance fields).
    // The bluebird's age.
    private int age;
    // The bluebird's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a bluebird. A bluebird can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the rat will have random age and hunger level.
     * @param worldInterface The enivornment conditions that the bluebird is living in,
     * the field currently occupied and their location within this field
     */
    public Bluebird(boolean randomAge, WorldInterface worldInterface)
    {
        super(worldInterface);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASSHOPPER_FOOD_VALUE + SLUG_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = GRASSHOPPER_FOOD_VALUE + SLUG_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the bluebird does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newrates A list to return newly born bluebirds.
     */
    public void act(OrganismList newBluebirds)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && getEnvironment().isDay() && getEnvironment().getWeather().getTemperature() > 0) {
            giveBirth(newBluebirds);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        } else if(isAlive()) {
            if(getField().freeAdjacentLocation(getLocation()) == null) {
                setDead();
            }
        }
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Grasshopper) {
                Grasshopper grasshopper = (Grasshopper) animal;
                if(grasshopper.isAlive()) { 
                    if (grasshopper.checkDisease()){
                        this.setDisease();    
                    }
                    grasshopper.setDead();
                    foodLevel = foodLevel + GRASSHOPPER_FOOD_VALUE;
                    return where;
                }
            } else if(animal instanceof Slug) {
                Slug slug = (Slug) animal;
                if(slug.isAlive()) { 
                    if (slug.checkDisease()){
                        this.setDisease();    
                    }
                    slug.setDead();
                    foodLevel = foodLevel + SLUG_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this bluebird is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newrates A list to return newly born bluebird.
     */
    private void giveBirth(OrganismList newBluebirds)
    {
        // New bluebirds are born into adjacent locations.
        // Get a list of adjacent occupied locations.
        List<Location> occupied = getField().adjacentLocations(getLocation());
        int births = breed();
        Iterator<Location> it = occupied.iterator();
        while(it.hasNext()) {
            // Find nearby bluebirds
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Bluebird) {
                // If bluebird is of opposite gender, breed.
                Bluebird bluebird = (Bluebird) animal;
                if(oppGender(bluebird)) {
                    //Get list of free locations to place new grasshoppers
                    List<Location> free = getField().getFreeAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Bluebird young = new Bluebird(false, new WorldInterface(getField(), loc, getEnvironment()));
                        newBluebirds.add(young);
                    }    
                }
            }
        }
    }

    /**
     * Increase the age and check if the bluebird is infected which will decrease their maximum age
     * This could result in the bluebird's death.
     */
    private void incrementAge()
    {
        age++;
        if(this.checkDisease()) {
            if(age > MAX_AGE - DISEASE_DECREASE_AGE) {
                setDead();    
            }
        } else {
            if(age > MAX_AGE) {
                setDead();
            }
        }
    }
    
    /**
     * Make this bluebird more hungry. This could result in the bluebird's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A bluebird can breed if it has reached the breeding age.
     * 
     * @return true if the bluebird can breed, false otherwise
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
