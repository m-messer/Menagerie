import java.util.List;
import java.util.Random;
/**
 * A simple model of a piece of grass
 * Grass can grow, breed and die
 *
 * @version 2022.02.26
 */
public class Grass extends Plant
{
    //Characteristics shared by all instances of grass (class variables).
    // The age to which a piece of grass can live.
    private static final int MAX_GROWTH = 4500;
    // The likelihood of a piece of grass breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    
    // Individual characteristics (instance fields).
    // The piece of grass' age
    private int age;

    /**
     * Create a peice of grass. Grass can be created as a new born (age zero)
     * or with a random age 
     * 
     * @param randomAge If true, the piece of grass will have random age.
     * @param worldInterface The enivornment conditions that the grass is living 
     * in and the field currently occupied and their location within this field
     */
    public Grass(boolean randomAge, WorldInterface worldInterface)
    {
        super(worldInterface);
        if(randomAge) {
            age = rand.nextInt(MAX_GROWTH);
        } else {
            age = 0;
        }
    }

    /**
     * This is what the grass piece does most of the time: breeds
     * @param field The field currently occupied.
     * @param newrates A list to return newly born rates.
     */
    public void act(OrganismList newGrass)
    {
        incrementGrowth();
        if(isAlive() && getEnvironment().isDay()) {
            giveBirth(newGrass);            
        }
    }
    
    /**
     * Check whether or not this piece of grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrass A list to return newly born pieces of grass.
     */
    private void giveBirth(OrganismList newGrass)
    {
        // New grass pieces are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = getField().getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(true, new WorldInterface(getField(), loc, getEnvironment()));
            newGrass.add(young);
        }
    }
    
    /**
     * Increase the age. This could result in the grass' death
     */
    private void incrementGrowth()
    {
        age++;
        if(age > MAX_GROWTH) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
