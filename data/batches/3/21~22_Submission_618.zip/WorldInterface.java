/**
 * This class is used to make it easier to change the constructors
 * for each animal/organism. It is used to hold the references to the
 * field, location and simulator conditions.
 *
 * @version 2022.02.26
 */
public class WorldInterface
{
    // Holds reference to the field object
    private Field field;
    // Holds reference to the simulator conditions object.
    private SimulatorConditions environment;
    // Holds reference to the location object.
    private Location location;

    /**
     * Initialise the WorldInterface, passing the three required
     * objects as parameters.
     * 
     * @param field The field object for the simulator
     * @param location The location object for the organism
     * @param environment The simulator conditions object for the simulator
     */
    public WorldInterface(Field field, Location location, SimulatorConditions environment)
    {
        this.field = field;
        this.environment = environment;
        this.location = location;
    }
    
    /**
     * Get the field object pointer.
     * 
     * @return pointer to field object
     */
    public Field getField()
    {
        return field;
    }

    /**
     * Get the simulator conditions object pointer.
     * 
     * @return pointer to simulator conditions object
     */
    public SimulatorConditions getSimulatorConditions()
    {
        return environment;
    }

    /**
     * Get the location object pointer.
     * 
     * @return pointer to location object
     */
    public Location getLocation()
    {
        return location;
    }
    
    /**
     * Change the location of the organism.
     * 
     * @param newLocation the location to set the
     * organism to.
     */
    public void setLocation(Location newLocation)
    {
        location = newLocation;
    }
    
    /**
     * Change the field pointer for the organism.
     * 
     * @param newField the field to set the organism
     * to.
     */
    public void setField(Field newField)
    {
        field = newField;
    }
}
