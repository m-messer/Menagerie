import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a rat
 * Rats age, move, eat grasshoppers, breed and die.
 *
 * @version 2022.02.26
 */
public class Rat extends Animal
{
    // Characteristics shared by all rate (class variables).
    // The age at which a rat can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rat can live.
    private static final int MAX_AGE = 1500;
    // The likelihood of a rat breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single grasshopper. In effect, this is the
    // number of steps a rat can go before it has to eat again.
    private static final int GRASSHOPPER_FOOD_VALUE = 20;
    // Decrease the maximum age of the rat by this amount to simulate it
    // having a shorter life expectancy   
    private static final int DISEASE_DECREASE_AGE = 50;
    
    // Individual characteristics (instance fields).
    // The rat's age.
    private int age;
    // The rat's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a rat. A rat can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the rat will have random age and hunger level.
     * @param worldInterface The enivornment conditions that the rat is living in
     * and the field currently occupied and their location within this field
     */
    public Rat(boolean randomAge, WorldInterface worldInterface)
    {
        super(worldInterface);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASSHOPPER_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASSHOPPER_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the rat does most of the time: it hunts for
     * grasshoppers. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newRats A list to return newly born rats.
     */
    public void act(OrganismList newRats)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && getEnvironment().getWeather().getTemperature() >= 5) {
            giveBirth(newRats);         
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();  
            }
        }
    }
    
    /**
     * Look for grasshoppers adjacent to the current location.
     * Only the first live grasshopper is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Grasshopper) {
                Grasshopper grasshopper = (Grasshopper) animal;
                if(grasshopper.isAlive()) { 
                    if (grasshopper.checkDisease()){
                        this.setDisease();    
                    }
                    grasshopper.setDead();
                    foodLevel = foodLevel + GRASSHOPPER_FOOD_VALUE;
                    return where;
                }
            } 
        }
        return null;
    }
    
    /**
     * Check whether or not this rat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRats A list to return newly born rates.
     */
    private void giveBirth(OrganismList newRats)
    {
        // New rats are born into adjacent locations.
        // Get a list of adjacent occupied locations.
        List<Location> occupied = getField().adjacentLocations(getLocation());
        int births = breed();
        Iterator<Location> it = occupied.iterator();
        while(it.hasNext()) {
            // Find nearby rats
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Rat) {
                // If rat is of opposite gender, breed.
                Rat rat = (Rat) animal;
                if(oppGender(rat)) {
                    //Get list of free locations to place new grasshoppers
                    List<Location> free = getField().getFreeAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Rat young = new Rat(false, new WorldInterface(getField(), loc, getEnvironment()));
                        newRats.add(young);
                    }    
                }
            }
        }
    }

    /**
     * Increase the age and check if the rat is infected which will decrease their maximum age
     * This could result in the rat's death.
     */
    private void incrementAge()
    {
        age++;
        if(this.checkDisease()) {
            if(age > MAX_AGE - DISEASE_DECREASE_AGE) {
                setDead();    
            }
        } else {
            if(age > MAX_AGE) {
                setDead();
            }
        }
    }
    
    /**
     * Make this rat more hungry. This could result in the rats's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A rat can breed if it has reached the breeding age.
     * 
     * @return true if the rat can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
