import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.02.26
 */
public abstract class Plant extends Organism
{
    // Characteristics shared by all plants (class variables).
    private static final double DISEASE_PROBABILITY = 0.03;
    //If a plant has a disease or not 
    private boolean hasDisease;
    
    /**
     * Create a new animal at location in field
     * 
     * @param worldInterface The enivornment conditions that the organism is living in and the field currently 
     * occupied and their location within this field
     */
    public Plant(WorldInterface worldInterface)
    {
        super(worldInterface);
        if (rand.nextDouble() <= DISEASE_PROBABILITY) {
            super.setDisease();
        }
    }
}