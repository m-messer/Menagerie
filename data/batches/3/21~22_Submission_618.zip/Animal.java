import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.02.26
 */
public abstract class Animal extends Organism
{
    //The animal's gender; true for male, false for female
    private boolean gender;
    
    /**
     * Create a new animal at location in field and assign random gender
     * 
     * @param worldInterface The enivornment conditions that the organism is living in and the field currently 
     * occupied and their location within this field
     */
    public Animal(WorldInterface worldInterface)
    {
        super(worldInterface);
        gender = rand.nextBoolean();
    }
    
    /**
     * Compares animal's gender with another animal's gender
     * 
     * @param animal The animal to be checked
     * @return true If the current animal's gender is not the same as the other animal's gender
     * else return false
     */
    public boolean oppGender(Animal animal)
    {
        return this.gender != animal.gender;
    }
}
