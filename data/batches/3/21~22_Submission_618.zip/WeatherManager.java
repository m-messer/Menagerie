import java.util.Random;
import java.util.List;

/**
 * Manages the weather conditions in the simulator. This class includes
 * random weather events such as rain or droughts.
 *
 * @version 2022.02.26
 */
public class WeatherManager
{
    // weather variables
    private int visibility;
    private int precipitation;
    private double temperature;
    
    private List<String> events; // holds a list of random events
    
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class WeatherManager
     */
    public WeatherManager()
    {
        visibility = 100;
        precipitation = 0;
        temperature = 20.0;
    }

    /**
     * Returns the current visibility, rated from 0 to 100.
     *
     * @return the current visibility
     */
    public int getVisibility()
    {
        return visibility;
    }

    /**
     * Returns the current precipitation, rated from 0 to 100.
     *
     * @return the current precipitation
     */
    public int getPrecipitation()
    {
        return precipitation;
    }

    /**
     * Returns the current temperature, in degrees celsius.
     *
     * @return the current temperature
     */
    public double getTemperature()
    {
        return temperature;
    }
    
    /**
     * Set the current visibility, rated from 0 to 100.
     *
     * @param visibility the new visibility value
     */
    public void setVisibility(int visibility)
    {
        if(visibility < 0 || visibility > 100) {
            return;
        }
        this.visibility = visibility;
    }

    /**
     * Set the current precipitation, rated from 0 to 100.
     *
     * @param precipitation the new precipitation value
     */
    public void setPrecipitation(int precipitation)
    {
        if(precipitation < 0 || precipitation > 100) {
            return;
        }
        this.precipitation = precipitation;
    }

    /**
     * Set the current temperature, in degrees celsius.
     *
     * @param temperature the temperature to set the field to
     */
    public void setTemperature(double temperature)
    {
        this.temperature = temperature;
    }
    
    /**
     * When called, weather conditions are changed to random values
     * and locked for a random period of time, up to 72 hours.
     */
    public void generateRandomEvent()
    {
        setVisibility(rand.nextInt(100));
        setPrecipitation(rand.nextInt(100));
        setTemperature(rand.nextInt(30) - 10);
    }
}
