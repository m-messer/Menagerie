import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing grass, slugs, grasshoppers, rats, bluebirds and hawks
 *
 * @version 2022.02.26
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;
    // The probability that a predator (hawks, bluebirds and rats) will be created in any given grid position.
    private static final double PRED_CREATION_PROBABILITY = 0.01;
    // The probability that a slug will be created in any given grid position.
    private static final double SLUG_CREATION_PROBABILITY = 0.02;   
    // The probability that a piece of grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILTY = 0.02;  
    // The probability that a grasshopper will be created in any given grid position.
    private static final double GRASSHOPPER_CREATION_PROBABILITY = 0.02; 

    // List of animals in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //The currenct conditions in the simulation
    private SimulatorConditions conditions;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);
        
        HashMap<Class, Color> organismColours = new HashMap<>();
        
        organismColours.put(Grasshopper.class, Color.ORANGE);
        organismColours.put(Rat.class, Color.BLACK);
        organismColours.put(Grass.class, Color.GREEN);
        organismColours.put(Slug.class, Color.MAGENTA);
        organismColours.put(Bluebird.class, Color.BLUE);
        organismColours.put(Hawk.class, Color.RED);
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, organismColours, this);
        
        for(Class organism : organismColours.keySet()) {
            view.setColor(organism, organismColours.get(organism));
        }
        
        conditions = new SimulatorConditions();
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        OrganismList newOrganims = new OrganismList();        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganims);
            if(! organism.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganims.getList());

        //increment the time and update weather
        conditions.stepForward();
        
        view.showStatus(step, field);
            
        HashMap<String, String> newDataValues = new HashMap<>();
        newDataValues.put("Time", conditions.getTimeString());
        newDataValues.put("Temperature", Double.toString(conditions.getTemperature())+"C");
        newDataValues.put("Visibility", Integer.toString(conditions.getVisibility()));
        newDataValues.put("Precipitation", Integer.toString(conditions.getPrecipitation()));
        view.setInfoText(newDataValues);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        conditions.reset();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
            
        HashMap<String, String> newDataValues = new HashMap<>();
        newDataValues.put("Time", conditions.getTimeString());
        newDataValues.put("Temperature", Double.toString(conditions.getTemperature())+"C");
        newDataValues.put("Visibility", Integer.toString(conditions.getVisibility()));
        newDataValues.put("Precipitation", Integer.toString(conditions.getPrecipitation()));
        view.setInfoText(newDataValues);
    }
    
    /**
     * Randomly populate the field with organisms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PRED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(true, new WorldInterface(field, location, conditions));
                    organisms.add(rat);
                }
                else if(rand.nextDouble() <= GRASSHOPPER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grasshopper grasshopper = new Grasshopper(true, new WorldInterface(field, location, conditions));
                    organisms.add(grasshopper);
                }
                else if(rand.nextDouble() <= SLUG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Slug slug = new Slug(true, new WorldInterface(field, location, conditions));
                    organisms.add(slug);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILTY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, new WorldInterface(field, location, conditions));
                    organisms.add(grass);
                }                
                else if(rand.nextDouble() <= PRED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bluebird bluebird = new Bluebird(true, new WorldInterface(field, location, conditions));
                    organisms.add(bluebird);
                }
                
                else if(rand.nextDouble() <= PRED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(true, new WorldInterface(field, location, conditions));
                    organisms.add(hawk);
                }
                
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
