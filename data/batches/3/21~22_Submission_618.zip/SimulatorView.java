import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashMap;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2022.02.26
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    //private JLabel stepLabel, population, infoLabel;
    private JPanel simStats;
    private FieldView fieldView;
    
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A map for storing the various labels showing population, time, weather etc.
    private HashMap<String, JLabel> labelValues;
    
    private JButton runLongBtn, runStepsBtn, oneStepBtn, resetBtn;
    // A statistics object computing and storing simulation information
    private FieldStats stats;
    // Holds the active simulator object to allow for the buttons to work.
    private Simulator simulator;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width, HashMap<Class, Color> organisms, Simulator simulator)
    {
        this.simulator = simulator;
        
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Predator/Prey Simulation");
        
        labelValues = new HashMap<>();
        
        setLocation(100, 50);
        
        fieldView = new FieldView(height, width);

        Container contents = getContentPane();
            
        // Create a sidebar to store the buttons and stats panels
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new GridLayout(0, 1));
        
        JPanel buttons = new JPanel();
        buttons.setLayout(new GridLayout(0, 1));
        
        runLongBtn = new JButton("Run long simulation");
        runLongBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { runLongSimulation(); }
        });
        buttons.add(runLongBtn);
        
        runStepsBtn = new JButton("Run simulation for x steps");
        runStepsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { simulateXSteps(); }
        });
        buttons.add(runStepsBtn);

        oneStepBtn = new JButton("Simulate one step");
        oneStepBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { simulateOneStep(); }
        });
        buttons.add(oneStepBtn);
        
        resetBtn = new JButton("Reset");
        resetBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { reset(); }
        });
        buttons.add(resetBtn);
        
        sidebar.add(buttons);
        
        simStats = new JPanel();
        simStats.setLayout(new GridLayout(0, 2));
        
        JLabel stepStaticLabel = new JLabel("Step: ");
        simStats.add(stepStaticLabel);
        
        JLabel stepDynamicLabel = new JLabel("0");
        simStats.add(stepDynamicLabel);
        labelValues.put("Step", stepDynamicLabel);
        
        // Spacer
        JLabel spacerEnvLabel = new JLabel("SIMULATOR CONDITIONS");
        simStats.add(spacerEnvLabel);
        JLabel spacerBlankEnvLabel = new JLabel("");
        simStats.add(spacerBlankEnvLabel);
        
        JLabel timeStaticLabel = new JLabel("Time: ");
        simStats.add(timeStaticLabel);
        
        JLabel timeDynamicLabel = new JLabel("09:00 (Spring)");
        simStats.add(timeDynamicLabel);
        labelValues.put("Time", timeDynamicLabel);
        
        JLabel temperatureStaticLabel = new JLabel("Temperature: ");
        simStats.add(temperatureStaticLabel);
        
        JLabel temperatureDynamicLabel = new JLabel("20C");
        simStats.add(temperatureDynamicLabel);
        labelValues.put("Temperature", temperatureDynamicLabel);
        
        JLabel visibilityStaticLabel = new JLabel("Visibility: ");
        simStats.add(visibilityStaticLabel);
        
        JLabel visibilityDynamicLabel = new JLabel("100");
        simStats.add(visibilityDynamicLabel);
        labelValues.put("Visibility", visibilityDynamicLabel);
        
        JLabel precipitationStaticLabel = new JLabel("Precipitation: ");
        simStats.add(precipitationStaticLabel);
        
        JLabel precipitationDynamicLabel = new JLabel("0");
        simStats.add(precipitationDynamicLabel);
        labelValues.put("Precipitation", precipitationDynamicLabel);
        
        // Spacer
        JLabel spacerPopLabel = new JLabel("POPULATION");
        simStats.add(spacerPopLabel);
        JLabel spacerBlankPopLabel = new JLabel("");
        simStats.add(spacerBlankPopLabel);
        
        for(Class organism : organisms.keySet()) {
            String name = organism.getSimpleName();
            JLabel staticLabel = new JLabel(name+": ");
            staticLabel.setForeground(organisms.get(organism));
            simStats.add(staticLabel);
            
            JLabel dynamicLabel = new JLabel("0");
            simStats.add(dynamicLabel);
            
            labelValues.put(name, dynamicLabel);
        }
        
        sidebar.add(simStats);

        // Add toolbar into panel with flow layout for spacing
        JPanel flow = new JPanel();
        flow.add(sidebar);
        
        contents.add(flow, BorderLayout.EAST);
        
        contents.add(fieldView, BorderLayout.CENTER);
        
        pack();
        setVisible(true);
    }
    
    /**
     * Define a color to be used for a given class of animal.
     * 
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * Update the stats data shown in the window.
     */
    public void setInfoText(HashMap<String, String> data)
    {
        for(String field : data.keySet()) {
            JLabel textFieldFetched = labelValues.get(field);
            
            textFieldFetched.setText(data.get(field));
        }
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass)
    {
        Color col = colors.get(animalClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * 
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }
            
        stats.reset();
        
        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    stats.incrementCount(animal.getClass());
                    fieldView.drawMark(col, row, getColor(animal.getClass()));
                }
                else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();
        
        HashMap<String, String> newStatsData = stats.getPopulationDetailsMap(field);
        newStatsData.put("Step", Integer.toString(step));
        setInfoText(newStatsData);
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * 
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    
    /**
     * When the long simulation button is clicked, run a long
     * simulation. The method call is asynchronous.
     */
    private void runLongSimulation()
    {
        /*
         * Code relating to the Thread lambda function is from:
         * https://www.baeldung.com/java-asynchronous-programming
         * Accessed 25/02/2022
         */
        new Thread(() -> {
            // Disable all buttons (to prevent errors)
            runLongBtn.setEnabled(false);
            runStepsBtn.setEnabled(false);
            oneStepBtn.setEnabled(false);
            resetBtn.setEnabled(false);
            
            simulator.runLongSimulation();
            
            // Re-enable all buttons
            runLongBtn.setEnabled(true);
            runStepsBtn.setEnabled(true);
            oneStepBtn.setEnabled(true);
            resetBtn.setEnabled(true);
        }).start();
    }
    
    /**
     * When the simulate x steps button is clicked, show a
     * pop-up asking for how many steps to simulate and then
     * carry it out.
     */
    private void simulateXSteps()
    {
        String inputSteps = JOptionPane.showInputDialog(this, "How many steps?", null);
        // Check if input is a number (to prevent crash)
        try {
            int convertedSteps = Integer.parseInt(inputSteps);
        } catch (NumberFormatException e) {
            return;   
        }
        
        /*
         * Code relating to the Thread lambda function is from:
         * https://www.baeldung.com/java-asynchronous-programming
         * Accessed 25/02/2022
         */
        new Thread(() -> {
            // Disable all buttons (to prevent errors)
            runLongBtn.setEnabled(false);
            runStepsBtn.setEnabled(false);
            oneStepBtn.setEnabled(false);
            resetBtn.setEnabled(false);
            
            simulator.simulate(Integer.parseInt(inputSteps));
            
            // Re-enable all buttons
            runLongBtn.setEnabled(true);
            runStepsBtn.setEnabled(true);
            oneStepBtn.setEnabled(true);
            resetBtn.setEnabled(true);
        }).start();
    }
    
    /**
     * When the one step button is clicked, step the simulator
     * forward by one.
     */
    private void simulateOneStep()
    {
        simulator.simulateOneStep();
    }
    
    /**
     * When the reset button is clicked, reset the simulator.
     */
    private void reset()
    {
        simulator.reset();
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                                 gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}