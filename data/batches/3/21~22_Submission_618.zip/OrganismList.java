import java.util.List;
import java.util.ArrayList;

/**
 * Stores all the organisms in one place. Allows for easier management
 * of organisms.
 *
 * @version 2022.02.26
 */
public class OrganismList
{
    private List<Organism> organisms;

    /**
     * Create the OrganismList
     */
    public OrganismList()
    {
        organisms = new ArrayList<>();
    }
    
    /**
     * Add an organism to the list.
     * 
     * @param organism the organism to add
     */
    public void add(Organism organism)
    {
        organisms.add(organism);
    }
    
    /**
     * Get the list of organisms.
     * 
     * @return a list containing all organisms.
     */
    public List<Organism> getList()
    {
        return organisms;
    }
}
