/**
 * Manages the time in the simulator. Starts at midnight.
 *
 * @version 2022.02.26
 */
public class TimeManager
{
    // variables that manage the time
    private int hour;
    private int minute;
    private int step; // minute increment
    
    private int dayNumber; // used to know when to change seasons
    
    // seasons: 0 - winter, 1 - spring, 2 - summer, 3 - autumn
    private int season;
    private int seasonDuration;
    
    /**
     * Constructor which initialises the time manager with the default
     * values.
     */
    public TimeManager()
    {
        this(9, 0, 30, 0, 1, 30);
    }
    
    /**
     * Constructor which initialises the time manager with the passed
     * values.
     */
    public TimeManager(int hour, int minute, int step, int dayNumber, int season, int seasonDuration)
    {
        this.hour = hour;
        this.minute = minute;
        this.step = step;
        this.dayNumber = dayNumber;
        this.season = season;
        this.seasonDuration = seasonDuration;
    }

    /**
     * Returns the time in HH:MM format (24 hour only).
     *
     * @return the time in HH:MM format.
     */
    public String getTimeFormatted()
    {
        return String.format("%02d", hour) + ":" + 
                String.format("%02d", minute);
    }

    /**
     * Returns the current hour.
     *
     * @return the current hour.
     */
    public int getHour()
    {
        return hour;
    }

    /**
     * Returns the current minute.
     *
     * @return the current minute.
     */
    public int getMinute()
    {
        return minute;
    }
    
    /**
     * Returns the current time in HHMM format (integer, leading 0's are
     * removed). Can be used to compare whether a given time is before or 
     * after another time in the same format.
     * 
     * @return the time in HHMM format.
     */
    public int getTimeInt()
    {
        return Integer.parseInt(String.format("%02d", hour)+
                                String.format("%02d", minute));
    }

    /**
     * Returns the current season.
     *
     * @return the current season.
     */
    public int getSeason()
    {
        return season;
    }

    /**
     * Returns the current season in string form (e.g. "Winter").
     *
     * @return the current season as a string.
     */
    public String getSeasonString()
    {
        if(season == 0) {
            return "Winter";
        } else if(season == 1) {
            return "Spring";
        } else if(season == 2) {
            return "Summer";
        } else if(season == 3) {
            return "Autumn";
        }
        return null;
    }

    /**
     * Increment the time forward by one step (5 minutes).
     */
    public void incrementTime()
    {
        minute = minute + step;
        
        // While loop is there to allow steps of more than 60 minutes.
        while(minute >= 60) {
            minute = minute - 60;
            hour++;
        }
        
        // ... and in this case, multi-day steps.
        while(hour >= 24) {
            hour = hour - 24;
            dayNumber++;
        }
        
        if(dayNumber >= seasonDuration) { // Do season change.
            season = (season + 1) % 4;
            dayNumber = 0;
        }
    }
}
