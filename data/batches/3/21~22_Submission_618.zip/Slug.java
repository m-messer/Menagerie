import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a slug.
 * Slugs age, move, eat grass, breed and die
 *
 * @version 2022.02.26
 */
public class Slug extends Animal
{
    // Characteristics shared by all slugs (class variables).
    // The age to which a slug can live.
    private static final int MAX_AGE = 400;
    // The age at which a slug can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a slug breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single piece of grass. In effect, this is the
    // number of steps a slug can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 40;
    // Decrease the maximum age of the slug by this amount to simulate
    // having a shorter life expectancy   
    private static final int DISEASE_DECREASE_AGE = 100;
    
    // Individual characteristics (instance fields).
    //The slug's age
    private int age;
    // The slug's food level, which is increased by eating grass.
    private int foodLevel;

    /**
     * Create a slug. A slug can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the slug will have random age and hunger level.
     * @param worldInterface The enivornment conditions that the slug is living in
     * and the field currently occupied and their location within this field
     */
    public Slug(boolean randomAge, WorldInterface worldInterface)
    {
        super(worldInterface);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * This is what the slug does most of the time: it hunts for
     * pieces of grass. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newrates A list to return newly born rates.
     */
    public void act(OrganismList newSlugs){
        incrementAge();
        incrementHunger();
        if(isAlive() && !getEnvironment().isDay()) {
            giveBirth(newSlugs);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        } else if(isAlive()) {
            if(getField().freeAdjacentLocation(getLocation()) == null) {
                setDead();
            }
        }   
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first found grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Grass) {
                Grass grass = (Grass) animal;
                if(grass.isAlive()) { 
                    if (grass.checkDisease()){
                        this.setDisease();    
                    }
                    grass.setDead();
                    foodLevel = foodLevel + GRASS_FOOD_VALUE;
                    return where;
                }
            } 
        }
        return null;
    }
    
    /**
     * Check whether or not this slug is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newslugs A list to return newly born slugs.
     */
    protected void giveBirth(OrganismList newSlugs)
    {
        // New slugs are born into adjacent locations.
        // Get a list of adjacent occupied locations.
        List<Location> occupied = getField().adjacentLocations(getLocation());
        int births = breed();
        Iterator<Location> it = occupied.iterator();
        while(it.hasNext()) {
            // Find nearby slugs
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Slug) {
                // If slug is of opposite gender, breed.
                Slug slug = (Slug) animal;
                if(oppGender(slug)) {
                    //Get list of free locations to place new slugs
                    List<Location> free = getField().getFreeAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Slug young = new Slug(false, new WorldInterface(getField(), loc, getEnvironment()));
                        newSlugs.add(young);
                    }    
                }
            }
        }
    }
    
    /**
     * Increase the age and check if the slug is infected which will decrease their maximum age
     * This could result in the slug's death.
     */
    private void incrementAge()
    {
        age++;
        if(this.checkDisease()) {
            if(age > MAX_AGE - DISEASE_DECREASE_AGE) {
                setDead();    
            }
        } else {
            if(age > MAX_AGE) {
                setDead();
            }
        }
    }
    
    /**
     * Make this slug more hungry which could result in its death
     */
    private void incrementHunger(){
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A slug can breed if it has reached the breeding age.
     * 
     * @return true if the slug can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
