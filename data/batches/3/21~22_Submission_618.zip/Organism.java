import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of organisms (animals and plants).
 *
 * @version 2022.02.26
 */
public abstract class Organism
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The organisms' field.
    private Field field;
    // The organism' position in the field
    private Location location;
    // The enivornment conditions that the organism is living in
    private SimulatorConditions environment;
    // If the organism has a disease or not 
    private boolean hasDisease;
    
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param worldInterface The enivornment conditions that the organism is living in and the field currently 
     * occupied and their location within this field
     */
    public Organism(WorldInterface worldInterface)
    {
        alive = true;
        this.field = worldInterface.getField();
        setLocation(worldInterface.getLocation());
        this.environment = worldInterface.getSimulatorConditions();
        hasDisease = false;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(OrganismList newOrganisms);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, location);
    }
    
    /**
     * Return the animal's environment.
     * @return The animal's environment.
     */
    protected SimulatorConditions getEnvironment()
    {
        return environment;
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Gives an organism a disease
     */
    protected void setDisease()
    {
        hasDisease = true;
    }
    
    /**
     * Check if the organism has a disease
     * 
     * @return true if the organism has a disease
     */
    protected boolean checkDisease()
    {
        return hasDisease;
    }
}
