import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a hawk.
 * Hawks can age, move, eat rats and bluebirds, breed and die
 *
 * @version 2022.02.26
 */
public class Hawk extends Animal
{
    // Characteristics shared by all hawks (class variables).
    // The age to which a hawk can live.
    private static final int MAX_AGE = 2000;
    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The food value of a single hawk. In effect, this is the
    // number of steps a hawk can go before it has to eat again.
    private static final int RAT_FOOD_VALUE = 30;
    private static final int BLUEBIRD_FOOD_VALUE = 40;
    // Decrease the maximum age of the hawk by this amount to simulate it
    // having a shorter life expectancy
    private static final int DISEASE_DECREASE_AGE = 50;
    
    // Individual characteristics (instance fields).
    //The hawk's age
    private int age;
    // The hawk's food level, which is increased by eating hawk.
    private int foodLevel;

    /**
     * Create a hawk. A hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hawk will have random age and hunger level.
     * @param worldInterface The enivornment conditions that the hawk is living in
     * and the field currently occupied and their location within this field
     */
    public Hawk(boolean randomAge, WorldInterface worldInterface)
    {
        super(worldInterface);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RAT_FOOD_VALUE + BLUEBIRD_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = RAT_FOOD_VALUE + BLUEBIRD_FOOD_VALUE;
        }
    }

    /**
     * This is what the hawk does most of the time: it hunts for
     * rats or bluebirds. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newrates A list to return newly born rates.
     */
    public void act(OrganismList newHawks)
    {
        incrementAge();
        incrementHunger();
        //Hawks do not move at night or if the visibility is lower than 20
        if(isAlive() && getEnvironment().isDay() && getEnvironment().getWeather().getVisibility() > 20) { 
            giveBirth(newHawks);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        } else if(isAlive()) {
            if(getField().freeAdjacentLocation(getLocation()) == null) {
                setDead();
            }
        }
    }
    
    /**
     * Look for rats or bluebirds adjacent to the current location.
     * Only the first live rat or bluebird is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
             if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.isAlive()) { 
                    if (rat.checkDisease()){
                        this.setDisease();    
                    }
                    rat.setDead();
                    foodLevel = foodLevel + RAT_FOOD_VALUE;
                    return where;
                }
            } else if(animal instanceof Bluebird) {
                Bluebird bluebird = (Bluebird) animal;
                if(bluebird.isAlive()) { 
                    if (bluebird.checkDisease()){
                        this.setDisease();    
                    }
                    bluebird.setDead();
                    foodLevel = foodLevel + BLUEBIRD_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }    

    /**
     * Check whether or not this hawk is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newhawks A list to return newly born newhawks.
     */
    private void giveBirth(OrganismList newHawks)
    {
        // New hawks are born into adjacent locations.
        // Get a list of adjacent occupied locations.
        List<Location> occupied = getField().adjacentLocations(getLocation());
        int births = breed();
        Iterator<Location> it = occupied.iterator();
        while(it.hasNext()) {
            // Find nearby hawks
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if(animal instanceof Hawk) {
                // If hawk is of opposite gender, breed.
                Hawk hawk = (Hawk) animal;
                if(oppGender(hawk)) {
                    //Get list of free locations to place new hawks
                    List<Location> free = getField().getFreeAdjacentLocations(getLocation());
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Hawk young = new Hawk(false, new WorldInterface(getField(), loc, getEnvironment()));
                        newHawks.add(young);
                    }    
                }
            }
        }
    }
    
    /**
     * Increase the age and check if the hawk is infected which will decrease their maximum age
     * This could result in the hawk's death.
     */
    private void incrementAge()
    {
        age++;
        if(this.checkDisease()) {
            if(age > MAX_AGE - DISEASE_DECREASE_AGE) {
                setDead();    
            }
        } else {
            if(age > MAX_AGE) {
                setDead();
            }
        }
    }
    
    /**
     * Make this hawk more hungry. This could result in the hawk's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hawk can breed if it has reached the breeding age.
     * @return true if the hawk can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}