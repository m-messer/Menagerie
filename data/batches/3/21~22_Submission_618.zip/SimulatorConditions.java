import java.util.HashMap;
import java.util.Random;

/**
 * Manages the weather and time conditions present in the simulation.
 *
 * @version 2022.02.26
 */
public class SimulatorConditions
{
    // initiate various condition managers
    private TimeManager timeMgr;
    private WeatherManager weatherMgr;
    
    // hours until next weather change
    private int nextWeatherChange;
    
    private HashMap<Integer, Integer> seasonSunrises;
    private HashMap<Integer, Integer> seasonSunsets;
    private HashMap<Integer, Integer> seasonMinTemps;
    private HashMap<Integer, Integer> seasonMaxTemps;
    
    private static final double RANDOM_EVENT_PROBABILITY = 0.01;
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Constructor that initialises the various condition managers with
     * their default conditions.
     */
    public SimulatorConditions()
    {
        timeMgr = new TimeManager();
        weatherMgr = new WeatherManager();
        
        seasonSunrises = new HashMap<>();
        seasonSunsets = new HashMap<>();
        seasonMinTemps = new HashMap<>();
        seasonMaxTemps = new HashMap<>();
        
        // Winter
        seasonSunrises.put(0, 800);
        seasonSunsets.put(0, 1600);
        seasonMinTemps.put(0, -10);
        seasonMaxTemps.put(0, 10);
        
        // Spring
        seasonSunrises.put(1, 730);
        seasonSunsets.put(1, 1630);
        seasonMinTemps.put(1, 0);
        seasonMaxTemps.put(1, 20);
        
        // Summer
        seasonSunrises.put(2, 630);
        seasonSunsets.put(2, 1800);
        seasonMinTemps.put(2, 5);
        seasonMaxTemps.put(2, 30);
        
        // Autumn
        seasonSunrises.put(3, 700);
        seasonSunsets.put(3, 1700);
        seasonMinTemps.put(3, -5);
        seasonMaxTemps.put(3, 20);
    }

    /**
     * Increment the time in accordance with the increment in the simulation.
     * Update weather conditions as appropriate.
     */
    public void stepForward()
    {
        timeMgr.incrementTime();
        //updateWeather();
        adjustWeather();
        if(rand.nextDouble() <= RANDOM_EVENT_PROBABILITY) {
            // Occasionally generate a significant weather change.
            weatherMgr.generateRandomEvent();
        }
    }
    
    /**
     * Update the weather conditions to the values passed. Values must
     * be within given range, if they are out of range then only the out of 
     * range values will not be updated.
     * 
     * @param visibility the new visibility value (0-100)
     * @param precipitation the new precipitation value (0-100)
     * @param temperature the new temperature value (advised -10.0 to 40.0)
     */
    public void updateWeather(int visibility, int precipitation, 
            double temperature)
    {
        weatherMgr.setVisibility(visibility);
        weatherMgr.setPrecipitation(precipitation);
        if(temperature >= seasonMinTemps.get(timeMgr.getSeason()) && 
            temperature <= seasonMaxTemps.get(timeMgr.getSeason())) {
            weatherMgr.setTemperature(temperature);
        }
    }
    
    /**
     * Adjusts the weather. This is different from updateWeather as the values 
     * will only go up or down a few notches, and no values can be passed.
     */
    public void adjustWeather()
    {
        int newVisibility = weatherMgr.getVisibility() + (rand.nextInt(6) - 2);
        int newPrecipitation = weatherMgr.getPrecipitation() + (rand.nextInt(5) - 2);
        double newTemperature = weatherMgr.getTemperature() + (rand.nextInt(5) - 2);
        
        updateWeather(newVisibility, newPrecipitation, newTemperature);
    }
    
    /**
     * Reset the time and weather conditions
     */
    public void reset()
    {
        timeMgr = new TimeManager();
        weatherMgr = new WeatherManager();
    }
    
    /**
     * Returns the current time as a string in HH:MM format.
     * 
     * @return string containing current time
     */
    public String getTimeString()
    {
        return timeMgr.getTimeFormatted()+" ("+timeMgr.getSeasonString()+")";
    }
    
    /**
     * Returns the current weather conditions as a string.
     * 
     * @return string containing weather conditions
     */
    public String getWeatherString()
    {
        return "Visibility: "+weatherMgr.getVisibility()+", Precipitation: "
                    +weatherMgr.getPrecipitation()+", Temperature: "
                    +weatherMgr.getTemperature()+"C";
    }
    
    
    /**
     * Returns the current visibility, rated from 0 to 100.
     *
     * @return the current visibility
     */
    public int getVisibility()
    {
        return weatherMgr.getVisibility();
    }

    /**
     * Returns the current precipitation, rated from 0 to 100.
     *
     * @return the current precipitation
     */
    public int getPrecipitation()
    {
        return weatherMgr.getPrecipitation();
    }

    /**
     * Returns the current temperature, in degrees celsius.
     *
     * @return the current temperature
     */
    public double getTemperature()
    {
        return weatherMgr.getTemperature();
    }
    
    /**
     * Returns true if it is currently day.
     * 
     * @return boolean, true if it is currently day.
     */
    public boolean isDay()
    {
        return ((timeMgr.getTimeInt() > seasonSunrises.get(timeMgr.getSeason())) && (timeMgr.getTimeInt() < seasonSunsets.get(timeMgr.getSeason())));
    }
    
    /**
     * Return the current weather.
     * 
     * @return weather object
     */
    public WeatherManager getWeather()
    {
        return weatherMgr;
    }
}