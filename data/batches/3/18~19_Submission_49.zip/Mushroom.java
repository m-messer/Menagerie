import java.util.List;
/**
 * A type of plant which is eaten by other animals
 *
 * @version 1.0.0.0
 */
public class Mushroom extends Plant
{
    /**
     * Constructor for objects of class Mushroom
     * 
     * @param field The field which stores animals
     * @param location The location of the actor
     * @param landscape The field which stores plants
     * @param events The event handler for the simulation
    */
    public Mushroom(Field field, Location location, Field landscape, Events events)
    {
        super(field, location, landscape, events);
    }
    
    /**
     * The act method for mushrooms
     * This is what the mushrooms will perform every step
     * The mushrooms will only create new mushroom, they cannot move or mate
     */
    protected void act(List<Actor> newMushroom)
    {
        if(isAlive()) { //if the mushroom is still alive
           propagate(newMushroom); //Create new mushrooms
        }
    }
    
}
