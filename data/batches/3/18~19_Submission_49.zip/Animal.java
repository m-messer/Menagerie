
import java.util.List;
import java.util.Random;
import java.lang.reflect.*;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{
    private int age; //The age of the animal
    private int breedingAge, maxAge;
    private int foodLevel; //How hungry the animal is
    private int maxLitterSize; //How many children the animal can produce at once
    private boolean female; //If the animal is female or not
    private double breedingProbability; //Chance to successfully give birth
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param landscape The field with plants.
     * @param events The event handler for the animal.
     * @param maxLitterSize The maximum number of babies the animal can create.
     * @param breedingProbability The chance the animal has to create a baby.
     * @param 
     * @param 
     */
    public Animal(Field field, Location location, Field landscape, Events events,int maxLitterSize, double breedingProbability, int maxAge, int breedingAge, boolean randomAge, int startingFood)
    {
        super(field,location,landscape, events); //Calls the constructor of the superclass
        this.maxLitterSize = maxLitterSize;
        this.breedingProbability = breedingProbability;
        //Sets the gender randomly
        if (getRand().nextInt(2) == 1)
        {
            female = true;
        }
        else
        {
            female = false;
        }
        this.maxAge = (maxAge);
        this.breedingAge = (breedingAge);
        if(randomAge) { //The animal already exists
            //Has random age and food
            setAge(getRand().nextInt(getMaxAge()));
            setFoodLevel(getRand().nextInt(startingFood));
        }
        else { //The animal is born
            //Starts with fresh stats
            setAge(0);
            setFoodLevel(startingFood);
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Actor> newAnimals)
    {
        incrementAge(); //Increase the age
        incrementHunger(); //Increase the hunger
        if(isAlive()) { //If the animal is alive
            giveBirth(newAnimals); //Give birth      
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation); //Moves to the prey
            }
            else {
                // Overcrowding.
                setDead();
            }
            
            if (getDisease() == 0) //If the disease counter reaches zero...
            {
                if (getRand().nextDouble()<= 0.7)
                {
                    setDisease(-1); //There is a chance the animal survives...
                }
                else
                {
                    setDead(); //Otherwise it is dead.
                }
            }
            else if (getDisease() > -1) //If the animal has a disease
            {
                setDisease(getDisease()-1); //The timer decreases
            }
        }
    }

    /**
     * Allows animals to create children
     * 
     * @param newAnimals A list to receive newly born animals.
     */
    public void giveBirth(List<Actor> newAnimals)
    {
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) { //For each child...
            Location loc = free.remove(0); //Get a free location.
            try
            {
                //Get the parents class
                Class cls = this.getClass();
                //Get the constructor for this class
                Constructor ct = cls.getConstructor(boolean.class, Field.class, Location.class, int.class, int.class, Field.class, Events.class);
                //Create an object with this constructor
                Actor retObj = (Actor) ct.newInstance(false, field, loc,getMaxAge(),getBreedingAge(), getLandscape(), getEvents());
                //Add the animal to the list
                newAnimals.add(retObj);
            }
            catch(Throwable e)
            {
                System.out.println(e);
            }
        }
    }
    
    /**
     * This method allows animal to look for food
     */
    abstract public Location findFood();
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++; //Increase the age
        if(age > maxAge) { //If the animal is too old it dies
            setDead();
        }
    }
    
    /**
     * Returns the object that is in the landscape at the same location as the animal
     * For example. Returns a mushroom, if the animal is stood on one.
     * 
     * @param location The location of the animal
     */
    protected Object objectInLandscape(Location location)
    {
        return getLandscape().getObjectAt(getLocation());
    }
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--; //Increase hunger
        if(foodLevel <= 0) { //The animal starves
            setDead();
        }
    }
    
    /**
     * Animals can breed if they have reached the breeding age.
     * There must also be an animal of the same species nearby.
     * This animal must be of the opposite gender.
     */
    protected boolean canBreed()
    {
        List<Location> locations = getField().adjacentLocations(getLocation());  //Gets the locations around the animal
        for (Location location : locations) //For each of these locations...
        {
            Animal animal = (Animal) getField().getObjectAt(location); //Get the animal at that location.
            if (animal != null)
            {
                if (animal.getClass().equals(this.getClass())) //If the animal is the same species...
                {
                    if (!(animal.isFemale() == this.isFemale())) //And not the same gender...
                    {
                        return age >= breedingAge; //And is above the breeding age, then return true.
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Returns the number of children the animal should have.
     * Also can cause the animal to become diseased
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && getRand().nextDouble() <= getBreedingProbability()) { //If the animal can breed and is lucky enough...
            births = getRand().nextInt(maxLitterSize) + 1; //They can have births amount of babies
        }
        if (getRand().nextDouble() <= 0.05) //There is a chance...
        {
            setDisease(10+getRand().nextInt(4)); //The animal contracts a disease.
        }
        return births;
    }
    
    /**
     * Changes the food level of the animal to a specified value
     * 
     * @param newFoodLevel The new level of food the animal should have
     */
    protected void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }
    
    /**
     * Changes the animals age
     * 
     * @param newAge The new age of the animal
     */
    protected void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * Changes the maximum age of the animal
     * 
     * @param newMaxAge The new maximum age of the animal
     */
    protected void setMaxAge(int newMaxAge)
    {
        maxAge = newMaxAge;
    }
    
    /**
     * Changes the breeding age of the animal
     * 
     * @param newBreedingAge The new age the animal must reach to breed
     */
    protected void setBreedingAge(int newBreedingAge)
    {
        breedingAge = newBreedingAge;
    }
    
    /**
     * Changes the maximum litter size of the animal
     * 
     * @newMaxLitterSize The new maximum number of babies the animal can produce
     */
    protected void setMaxLitterSize(int newMaxLitterSize)
    {
        maxLitterSize = newMaxLitterSize;
    }
    
    /**
     * Returns the age of the animal
     */
    protected int getAge()
    {
        return age;
    }
        
    /**
     * Returns the food level of the animal
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
        
    /**
     * Returns the chance the animal will create babies
     */
    protected double getBreedingProbability()
    {
        return breedingProbability;
    }
        
    /**
     * Returns the maximum age of the animal
     */
    protected int getMaxAge()
    {
        return maxAge;
    }
        
    /**
     * Returns the breeding age of the animal
     */
    protected int getBreedingAge()
    {
        return breedingAge;
    }
        
    /**
     * Returns the maximum number of babies the animal can produce
     */
    protected int getMaxLitterSize()
    {
        return maxLitterSize;
    }
    
    /**
     * Returns if the animal is female or not
     */
    protected boolean isFemale()
    {
        return female;
    }
}
