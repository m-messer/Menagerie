
import java.util.Random;
/**
 * This class control any events that occur in the simulation.
 * These events include the changing of weather and days.
 *
 * @version 1.0.0.0
 */
public class Events
{
    private Integer dayDuration; //Defines how long a day will last
    private Boolean day; //If it is currently day or not
    enum Weather
    {
        RAINY,SUNNY,CLOUDY,SNOWY, WINDY; //The different weather types
    };
    Weather weather; //The current weather

    /**
     * Create the event handler
     */
    public Events()
    {
        day = true; //The simulation starts at day
        dayDuration = 25; //The days will last 25 steps
        changeWeather(); //Sets the weather randomly
    }

    /**
     * Moves the event handler forward by 1 step
     * 
     * @param steps The current number of steps that have happened 
     */
    public void nextStep(Integer steps)
    {
        if ((steps % dayDuration) == 0) //Every dayDuration amount of steps...
        {
            day = !day; //Change day
        }
        if ((steps % 10) == 0) //Every 10 steps
        {
            changeWeather(); //Weather is randomly chosen
        }
    }

    /**
     * Changes the weather to a new randomly chosen type
     */
    public void changeWeather()
    {
        //Sets weather to a random element from the enum Weather using its index 
        //Generates a random number from 0 to the length of the enum -1
        weather = Weather.values()[Randomizer.getRandom().nextInt(Weather.values().length)];
    }

    /**
     * Returns the curretn weather
     */
    public Weather getWeather()
    {
        return weather;
    }
    
    /**
     * Returns if it is day or not
     */
    public Boolean isDay()
    {
        return day;
    }
}
