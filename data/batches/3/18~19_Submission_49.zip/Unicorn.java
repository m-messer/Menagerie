    import java.util.List;
    import java.util.Random;
    import java.util.Iterator;
    /**
     * Write a description of class Unicorn here.
     *
     * @version 1.0.0.0
     */
    public class Unicorn extends Animal
    {
        private static final double BREEDING_PROBABILITY = 0.24;
        // The maximum number of births.
        private static final int MAX_LITTER_SIZE = 4;
        private static final int MUSHROOM_FOOD_VALUE = 10;
        private static final int TOAD_FOOD_VALUE = 12;
        private Integer magicShroomed; //Counter for when the unicorn last ate a magic mushroom
        private static final int START_FOOD_VALUE = 12;
        /**
         * Create a new Unicorn. A Unicorn may be created with age
         * zero (a new born) or with a random age.
         * 
         * @param randomAge If true, the animal will have random age and hunger level.
         * @param field The field currently occupied.
         * @param location The location within the field.
         * @param maxAge The maximum age the animal can live until
         * @param breedingAge The age the animal must reach before it can breed
         * @param landscape The field storing plants
         * @param events The event handler for the animal
         */
        public Unicorn(boolean randomAge, Field field, Location location, int maxAge, int breedingAge, Field landscape, Events events)
        {
            super(field, location, landscape, events,MAX_LITTER_SIZE,BREEDING_PROBABILITY,maxAge,breedingAge,randomAge,START_FOOD_VALUE);
            if (randomAge)
            {
                magicShroomed = getRand().nextInt(5);
            }
            else
            {
                magicShroomed = 0;
            }
    }
    
    /**
     * Checks if there are any prey nearby before eating them
     * Alternatively, the unicorn can eat mushrooms
     * If the unicorn has eaten a magic mushroom, it can eat anything
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Actor animal = (Actor) field.getObjectAt(where);
            if(animal instanceof Toad) { //Eats a toad if there is one nearby
                Toad toad = (Toad) animal;
                if(toad.isAlive()) { 
                    toad.setDead();
                    setFoodLevel(TOAD_FOOD_VALUE);
                    return where;
                }
            }
            else
            {
                if (magicShroomed > 0) //If a magic shroom has been eaten...
                {
                    if (animal instanceof Animal) //Any Animal can be eaten.
                    {
                        if (animal.isAlive())
                        {
                            animal.setDead();
                            setFoodLevel(8);
                            return where;
                        }
                    }
                }
            }
        }
        Object mushroom = objectInLandscape(getLocation()); //Checks for mushrooms before eating them
        if (mushroom instanceof MagicMushroom)
        {
            magicShroomed = 15;
            Mushroom mush = (Mushroom) mushroom;
            setFoodLevel(MUSHROOM_FOOD_VALUE*2);
            mush.setDead();
        }
        else if (mushroom instanceof Mushroom)
        {
            Mushroom mush = (Mushroom) mushroom;
            setFoodLevel(MUSHROOM_FOOD_VALUE);
            mush.setDead();
        }
        
        return null;
    }

}

