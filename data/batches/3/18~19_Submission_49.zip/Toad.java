import java.util.List;
import java.util.Random;

/**
 * A simple model of a Toad.
 * Toads age, move, breed, and die.
 *
 * @version 1.0.0.0
 */
public class Toad extends Animal
{
    private static final double BREEDING_PROBABILITY = 0.17;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    private static final int MUSHROOM_FOOD_VALUE = 8;
    private static final int START_FOOD_VALUE = 7;
    /**
     * Create a new Toad. A Toad may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Toad will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Toad(boolean randomAge, Field field, Location location, int maxAge, int breedingAge, Field landscape, Events events)
    {
        super(field, location, landscape, events,MAX_LITTER_SIZE,BREEDING_PROBABILITY,maxAge,breedingAge,randomAge,START_FOOD_VALUE);
    }

    /**
     * Checks if the toad is on the same cell as a mushroom before eating it
     */
    public Location findFood()
    {
        Mushroom mushroom = (Mushroom) objectInLandscape(getLocation()); //Checks the cell
        if (mushroom instanceof Mushroom) //If there is a mushroom, then it is eaten
        {
            setFoodLevel(MUSHROOM_FOOD_VALUE);
            mushroom.setDead();
        }

        return null;
    }

    /**
     * Returns the chance of the toad successfully mating
     * Toads have a higher chance to breed during rain
     */
    protected double getBreedingProbability()
    {
        double breedingProp = super.getBreedingProbability();
        if (getEvents().weather.RAINY == getEvents().getWeather()) //If it is raining...
        {
            breedingProp *= 1.5; //The probability is increased
        }
        return breedingProp;
    }
}
