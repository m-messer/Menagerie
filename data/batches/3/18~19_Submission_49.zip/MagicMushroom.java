import java.util.List;
/**
 * A special type of mushroom which when eaten, gives the animal extra powers
 *
 * @version 1.0.0.0
 */
public class MagicMushroom extends Mushroom
{
    Integer duration; //How long the mushroom can live for
    
    /**
     * Creates a magic mushroom
     * 
     * @param field The field which stores animals
     * @param location The location of the actor
     * @param landscape The field which stores plants
     * @param events The event handler for the simulation
     */
    public MagicMushroom(Field field, Location location, Field landscape, Events events)
    {
        super(field, location, landscape, events);
        duration = 30;
    }
    
    /**
     * The act method for magic mushrooms
     * This is what the mushrooms will perform every step
     * The mushrooms will only create new mushroom, they cannot move or mate
     * The mushrooms will also die if they are alive for too long
     */
    protected void act(List<Actor> newMushroom)
    {
        super.act(newMushroom); //Acts the same way as mushrooms
        duration--; //Decrease it's duration timer.
        if (duration <= 0) { //Once the timer hits zero...
            setDead(); //The mushroom dies.
        }
    }
}
