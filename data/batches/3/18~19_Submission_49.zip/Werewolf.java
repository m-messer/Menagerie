import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a werewolf.
 * Werewolfes age, move, eat unicorns, and die.
 *
 * @version 1.0.0.0
 */
public class Werewolf extends Animal
{
    // The likelihood of a werewolf breeding.
    private static final double BREEDING_PROBABILITY = 0.11;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    private static final int UNICORN_FOOD_VALUE = 18;
    private static final int GOAT_FOOD_VALUE = 13;
    private static final int START_FOOD_VALUE = 11;
    /**
     * Create a werewolf. A werewolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The maximum age the animal can live until
     * @param breedingAge The age the animal must reach before it can breed
     * @param landscape The field storing plants
     * @param events The event handler for the animal
     */
    public Werewolf(boolean randomAge, Field field, Location location, int maxAge, int breedingAge, Field landscape,Events events)
    {
        super(field, location, landscape, events,MAX_LITTER_SIZE,BREEDING_PROBABILITY,maxAge,breedingAge,randomAge,START_FOOD_VALUE);
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Unicorn) { //If there is unicorn, eat it
                Unicorn unicorn = (Unicorn) animal;
                if(unicorn.isAlive()) { 
                    unicorn.setDead();
                    setFoodLevel(UNICORN_FOOD_VALUE);
                    return where;
                }
            }
            else if (animal instanceof Goat) { //If there is a goat, eat it
                Goat goat = (Goat) animal;
                if(goat.isAlive()) { 
                    goat.setDead();
                    setFoodLevel(GOAT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Returns the chance of the werewolf successfully mating
     * Werewolves have a higher chance to breed during the night
     */
    protected double getBreedingProbability()
    {
        double breedingProp = super.getBreedingProbability(); //Obtains the regular breeding chance
        if (!getEvents().isDay()) //If it is not day
        {
            breedingProp *= 2.2; //Increase the breeding chance
        }
        return breedingProp; //Return the new chance
    }
}
