import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Unicorns and Werewolfes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Werewolf will be created in any given grid position.
    private static final double WEREWOLF_CREATION_PROBABILITY = 0.09;
    // The probability that a Unicorn will be created in any given grid position.
    private static final double UNICORN_CREATION_PROBABILITY = 0.13;    
    // The probability that a Griffin will be created in any given grid position.
    private static final double GRIFFIN_CREATION_PROBABILITY = 0.07;
    // The probability that a Goat will be created in any given grid position.
    private static final double GOAT_CREATION_PROBABILITY = 0.16;
    // The probability that a Toad will be created in any given grid position.
    private static final double TOAD_CREATION_PROBABILITY = 0.10;
    // List of animals in the field.
    private List<Actor> actors;
    // The field on which animals are made
    private Field field;
    //The field on which plants are made
    private Field landscape;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //This controls events such as time and weather
    private Events events;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        //Adds actors into an array list
        actors = new ArrayList<>();
        //The fields which store the actors
        field = new Field(depth, width);
        landscape = new Field(depth, width);
        //Cnotroller for events such as weather
        events = new Events();
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width,events);
        //Sets the color of each animal in the simulation
        view.setColor(Unicorn.class, Color.ORANGE);
        view.setColor(Werewolf.class, Color.BLUE);
        view.setColor(Griffin.class, Color.CYAN);
        view.setColor(Goat.class, Color.GRAY);
        view.setColor(Toad.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(90);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal
     */
    public void simulateOneStep()
    {
        step++;
        events.nextStep(step); //Moves the events forward 1 step
        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            if (actor instanceof Actor)
            {
                actor.act(newActors); //Makes the actors 'act'
                if(! actor.isAlive()) { //If it is dead...
                    it.remove(); //Delete it
                }
            }
           
        }
        // Add the newly born animals to the list.
        actors.addAll(newActors);
        //Updates the view
        view.showStatus(step, field,landscape);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear(); //Clears the field before...
        populate(); //Adding animals to the field...
        addPlants(); //and adding plants to the field.
        // Show the starting state in the view.
        view.showStatus(step, field,landscape);
    }
    
    /**
     * Randomly populate the field with animals
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear(); //Clear the field
        //For each cell there is a chance to create an animal
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WEREWOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col); //Create a location for the animal
                    Werewolf Werewolf = new Werewolf(true, field, location,75,6, landscape, events); //Creates the animal
                    actors.add(Werewolf); //Adds the animal to the list of actors
                }
                else if(rand.nextDouble() <= UNICORN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Unicorn Unicorn = new Unicorn(true, field, location,60,4, landscape, events);
                    actors.add(Unicorn);
                }
                 else if(rand.nextDouble() <= GRIFFIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Griffin Griffin = new Griffin(true, field, location,98,5, landscape, events);
                    actors.add(Griffin);
                }
                else if(rand.nextDouble() <= GOAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Goat Goat = new Goat(true, field, location,62,3, landscape, events);
                    actors.add(Goat);
                }
                else if(rand.nextDouble() <= TOAD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Toad Toad = new Toad(true, field, location,35,6, landscape, events);
                    actors.add(Toad);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Add plants to the simulation
     */
    private void addPlants()
    {
        Random rand = Randomizer.getRandom();
        landscape.clear();
        //For each cell...
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                    if(rand.nextDouble() <= 0.4) //There is a chance to create a plant.
                    {
                        Location location = new Location(row, col);
                        Mushroom mushroom;
                        if (rand.nextDouble() <= 0.01) //There is a chance the mushroom will become a magic mushroom
                        {
                            mushroom = new MagicMushroom(landscape,location,landscape, events); //Creates a magic mushroom
                        }
                        else
                        {
                            mushroom = new Mushroom(landscape,location,landscape, events); //Creates a mushroom
                        }
                        actors.add(mushroom); //Adds the mushroom to the actor list
                    }
             }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
