import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a griffin.
 * Griffines age, move, eat rabbits, and die.
 *
 * @version 1.0.0.0
 */
public class Griffin extends Animal 
{
    // The likelihood of a griffin breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    //Amount of steps the animal can survive after eating
    private static final int GOAT_FOOD_VALUE = 16;
    //Starting Food Value
    private static final int START_FOOD_VALUE = 15;
    /**
     * Create a griffin. A griffin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The maximum age the animal can live until
     * @param breedingAge The age the animal must reach before it can breed
     * @param landscape The field storing plants
     * @param events The event handler for the animal
     */
    public Griffin(boolean randomAge, Field field, Location location, int maxAge, int breedingAge, Field landscape, Events events)
    {
        super(field, location, landscape, events,MAX_LITTER_SIZE,BREEDING_PROBABILITY,maxAge,breedingAge,randomAge,START_FOOD_VALUE);
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        //Gets the locations near the animal
        List<Location> adjacent = getField().multLocationGeneration(getLocation(),2);
        if (getEvents().weather.WINDY == getEvents().getWeather()) //If it is windy...
        {
            adjacent = getField().multLocationGeneration(getLocation(),15); //The griffin can look for food further away
        }
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) { //Searches all the locations
            Location where = it.next();
            Object animal = field.getObjectAt(where); //The animal at the new location
            if(animal instanceof Goat) { //If the animal is a goat, then it is eaten
                Goat goat = (Goat) animal;
                if(goat.isAlive()) { 
                    goat.setDead();//Checks if the goat is alive
                    setFoodLevel(GOAT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

}
