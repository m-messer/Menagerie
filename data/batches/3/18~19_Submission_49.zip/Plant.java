import java.util.List;
import java.lang.reflect.*;
/**
 * Abstract class Plant - Plants are eaten by other animals
 * They cannot move but are able to create more plants
 *
 * @version 1.0.0.0
 */
public abstract class Plant extends Actor
{
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    /**
     * Creates a plant
     * 
     * @param field The field which stores animals
     * @param location The location of the actor
     * @param landscape The field which stores plants
     * @param events The event handler for the simulation
     */
    public Plant(Field field, Location location, Field landscape, Events events)
    {
        super(field,location,landscape, events); //Calls the constructor of the superclass
    }
    
    /**
     * This allows the plants to propogate across the field
     * 
     * @param newPlants A list that is used to store the new plants that are created
     */
    public void propagate(List<Actor> newPlants)
    {
        if (!(getEvents().weather.SNOWY == getEvents().getWeather())) //Plants can't reproduce in the snow
        {
            List<Location> free = getLandscape().getFreeAdjacentLocations(getLocation()); //Generates the free locations around the plant
            if(free.size() > 1){
                Location loc = free.get(getRand().nextInt(free.size()-1)); //Gets a random location from the ones that are free
                try
                {
                    //Obtains the class of the plant
                    Class cls = this.getClass(); 
                    //Creates a constructor for the class of the plant
                    Constructor ct = cls.getConstructor(Field.class,Location.class,Field.class,Events.class);
                    //Creates an actor using the constructor
                    Actor retObj = (Actor) ct.newInstance(getField(),loc,getLandscape(), getEvents());
                    //Adds it to newPlants
                    newPlants.add(retObj);
                }
                catch(Throwable e)
                {
                    System.out.println(e);
                }
            }
        }
    }
}
