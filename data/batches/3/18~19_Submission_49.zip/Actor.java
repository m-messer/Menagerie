import java.util.Random;
import java.util.List;
/**
 * An actor is a living being which resides on a field
 * This includes animals and plants
 *
 * @version 1.0.0.0
 */
public abstract class Actor
{
    private boolean alive; //If the actor is alive or not
    private Field field; //The field which stores animals
    private Field landscape; //The field storing plants
    private Location location; //The location of the actor
    private Random rand = Randomizer.getRandom();
    private Events events; //The event controller
    private Integer disease; //The state of the actors health
    /**
     * Constructor for objects of class Actor
     * 
     * @param field The field which stores animals
     * @param location The location of the actor
     * @param landscape The field which stores plants
     * @param events The event handler for the simulation
     */
    public Actor(Field field, Location location, Field landscape,Events events)
    {
        alive = true;
        this.field = field;
        this.landscape = landscape;
        setLocation(location);
        this.events = events;
        disease = -1; //The actor is not diseased
    }

    /**
     * This method makes the actors perform their required actions every step
     */
    abstract protected void act(List<Actor> newActors);

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Kills the actor
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Returns how diseased the actor is
     */
    protected Integer getDisease()
    {
        return disease;
    }
    
    /**
     * Sets the actor's disease to a specified value
     * 
     * @param newNum The new number to set the actors disease to
     */
    protected void setDisease(Integer newNum)
    {
        disease = newNum;
    }
    
    /**
     * Returns the event handler for the actor
     */
    protected Events getEvents() 
    {
        return events;
    }
    
    /**
     * Returns the random class for the actor
     */
    protected Random getRand()
    {
        return rand;
    }
    
    /**
     * Returns the field with animals
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Returns the field with plants
     */
    protected Field getLandscape()
    {
        return landscape;
    }
    
    /**
     * Returns if the actor is alive or not
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Returns the current location of the actor
     */
    protected Location getLocation()
    {
        return location;
    }
}
