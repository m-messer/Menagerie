import java.util.List;
import java.util.Random;

/**
 * A simple model of a Goat.
 * Goats age, move, breed, and die.
 *
 * @version 1.0.0.0
 */
public class Goat extends Animal
{
    private static final double BREEDING_PROBABILITY = 0.34;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    private static final int MUSHROOM_FOOD_VALUE = 20;
    private static final int START_FOOD_VALUE = 19;
    /**
     * Create a new Goat. A Goat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The maximum age the animal can live until
     * @param breedingAge The age the animal must reach before it can breed
     * @param landscape The field storing plants
     * @param events The event handler for the animal
     */
    public Goat(boolean randomAge, Field field, Location location, int maxAge, int breedingAge, Field landscape, Events events)
    {
        super(field, location, landscape, events,MAX_LITTER_SIZE,BREEDING_PROBABILITY,maxAge,breedingAge,randomAge,START_FOOD_VALUE);
    }

    /**
     * The goat checks if there is a mushroom in its cell
     * And eats it if there is
     */
    public Location findFood()
    {
        Mushroom mushroom = (Mushroom) objectInLandscape(getLocation()); //Checks if the goat is standing on a mushroom
        if (mushroom instanceof Mushroom) //If there is a mushroom there it is eaten
        {
            setFoodLevel(MUSHROOM_FOOD_VALUE);
            mushroom.setDead();
        }
        return null;
    }

}
