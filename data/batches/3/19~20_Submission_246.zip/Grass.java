/**
 * A simple model of grass
 * They grow, get eaten and grow again
 * They are affected by the environment, mainly rain
 *
 * @version 2020.02.17
 */
public class Grass
{
    // Number's of days until next growth
    private static final int GROWTH_RATE = 3;


    // Stats of individual grass objects
    // The number of steps until the next growth
    private int nextGrowth;
    // Is the grass eaten
    private boolean empty;
    // Is the grass growing
    private boolean startGrowing;

    /**
     * Constructor for objects of class Grass
     */
    public Grass(Field grass, Location location)
    {
        nextGrowth = GROWTH_RATE;
        empty = false;
        startGrowing = false;
        grass.place(this, location);
    }

    /**
     * Set grass as empty as it has be eaten
     */
    public void ate() {
        empty = true;
    }

    /**
     * Set growing as true
     */
    public void grow() {
        startGrowing = true;
    }

    /**
     * Check if the current grass can start growing
     */
    public boolean canGrow() {
        return !empty && !startGrowing;
    }

    /**
     * Set the grass as growing
     * Grass will be grown after a set number of steps
     */
    public void growing() {
        if (startGrowing) {
            nextGrowth--;
        }
        if (nextGrowth < 0) {
            nextGrowth = GROWTH_RATE;
            startGrowing = false;
            empty = false;
        }
    }

    /**
     * @return if the grass is fully grown and can be eat
     */
    public boolean canEat() {
        if (!startGrowing && !empty) {
            return true;
        }
        return false;
    }
}
