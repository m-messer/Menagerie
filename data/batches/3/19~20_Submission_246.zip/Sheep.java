import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a sheep.
 * Sheeps age, move, breed, and die.
 *
 * @version 2020.02.17
 */
public class Sheep extends Prey
{
    // Characteristics shared by all sheeps (class variables).

    // The age at which a sheep can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a sheep can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a sheep breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The number of steps sheeps can take without grass
    private static final int FOOD_COUNT = 5;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The sheep's age.
    private int age;
    
    // The sheep's sex
    private boolean male;

    // The sheep's hunger
    private int food;

    /**
     * Create a new sheep. A sheep may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the sheep will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sheep(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        food = FOOD_COUNT;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        male = rand.nextBoolean();
    }

    /**
     * This is what the sheep does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newSheeps A list to return newly born sheeps.
     * @param field The field of grass
     */
    public void act(List<Animal> newSheeps, Field grass)
    {
        incrementAge();
        if(isAlive()) {
            // Check all adjacent locations for sheeps of the opposite sex
            Boolean breed = false;
            List<Location> adjacent = getField().adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            breed = false;
            while (it.hasNext() && breed != true) {
                Object animal = getField().getObjectAt(it.next());
                if(animal instanceof Sheep) {
                    Sheep adjSheep = (Sheep) animal;
                    if (adjSheep.getSex() != getSex()) {
                        breed = true;
                    }
                }
            }
            // Breed if there are sheeps of the opposite sex at adjacent cells
            if (breed) {
                giveBirth(newSheeps);
            }
            mutate();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
                eat(grass, newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            kill();
        }
    }

    /**
     * Check whether or not this sheep is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSheeps A list to return newly born sheeps.
     */
    private void giveBirth(List<Animal> newSheeps)
    {
        // New sheeps are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Sheep young = new Sheep(false, field, loc);
            newSheeps.add(young);
        }
    }

    /**
     * Increase the age.
     * This could result in the sheep's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * @return the hunger value of the sheep
     */
    protected int getHunger() {
        return food;
    }

    /**
     * @return the FOOD_COUNT of the sheep
     */
    protected int getFoodCount() {
        return FOOD_COUNT;
    }

    /**
     * mutate the hunger value of the sheep
     * @param amount the value ot set the hunger as
     */
    protected void setHunger(int amount) {
        food = amount;
    }

    /**
     * @return the MAX_LITTLE_SIZE of the sheep
     */
    protected int getMaxOffspring() {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the BREEDING_AGE of the sheep
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return the BREEDING_PROBABILITY of the sheep
     */
    protected double getBreedingProb() {
        if (isSick()) {
            return 3 * BREEDING_PROBABILITY / 4;
        }
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the age of the sheep
     */
    protected int getAge() {
        return age;
    }
    
    /**
     * @return the sex of the sheep
     */
    private boolean getSex() {
        return male;
    }
}
