import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat sheeps and deers, and die.
 *
 * @version 2020.02.17
 */
public class Lion extends Predator
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a lion can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The food value of a single sheep. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int SHEEP_FOOD_VALUE = 40;
    private static final int DEER_FOOD_VALUE = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The lion's age.
    private int age;

    // The lion's food level, which is increased by eating sheeps.
    private int foodLevel;

    // The lion's sex;
    private boolean male;

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
        foodLevel = SHEEP_FOOD_VALUE;
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * sheeps. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.
     * @param field The field of grass
     */
    public void act(List<Animal> newLions, Field grass)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // Check all adjacent locations for lions of the opposite sex
            // Within a certain block radius
            Boolean breed = false;
            List<Location> adjacent = getField().adjacentLocationsRadius(getLocation(), 20);
            Iterator<Location> it = adjacent.iterator();
            breed = false;
            while (it.hasNext() && breed != true) {
                Object animal = getField().getObjectAt(it.next());
                if(animal instanceof Lion) {
                    Lion adjLion = (Lion) animal;
                    if (adjLion.getSex() != getSex()) {
                        breed = true;
                    }
                }
            }
            // Breed if there are sheeps of the opposite sex at adjacent cells
            if (breed) {
                giveBirth(newLions); 
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            mutate();
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is how the lion eats
     * @param animal An Object of Animal
     * @return a boolean determining whether the lion has eaten
     */
    protected boolean eat(Object animal) {
        if (animal instanceof Deer) {
            Deer deer = (Deer) animal;
            if (deer.isAlive()) {
                deer.setDead();
                foodLevel += DEER_FOOD_VALUE;
                return true;
            }
        }
        if(animal instanceof Sheep) {
            Sheep sheep = (Sheep) animal;
            if(sheep.isAlive()) { 
                sheep.setDead();
                foodLevel += SHEEP_FOOD_VALUE;
                return true;
            }
        }
        return false;
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    private void giveBirth(List<Animal> newLions)
    {
        // New lions are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }

    /**
     * Increase the age. This could result in the lion's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * @return the MAX_LITTLE_SIZE of the lion
     */
    protected int getMaxOffspring() {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the BREEDING_AGE of the lion
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return the BREEDING_PROBABILITY of the lion
     */
    protected double getBreedingProb() {
        if (isSick()) {
            return 3 * BREEDING_PROBABILITY / 4;
        }
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the age of the lion
     */
    protected int getAge() {
        return age;
    }
    
    /**
     * @return the sex of the lion
     */
    private boolean getSex() {
        return male;
    }
}
