import java.util.Random;
/**
 * Abstract class Prey - a simple model of the animal type prey
 *
 * @version 2020.02.17
 */
public abstract class Prey extends Animal
{
    // The hunger value of the prey
    protected int food;
    // The likelihood of the prey to be killed by the disease
    private static final double KILL_PROBABILITY = 0.5;
    // The random number generator
    private static final Random rand = Randomizer.getRandom();

    public Prey(Field field, Location location) {
        super(field, location);
    }

    abstract protected int getFoodCount();

    abstract protected int getHunger();

    abstract protected void setHunger(int amount);

    /**
     * Checks the grass field in the simulation
     * If the current location of the animal in the grass fields has edible grass
     * Then, reset the hunger counter
     * @param grass the grass object in the grass field
     * @param currentLocation the current location of the animal
     */
    protected void eat(Field grass, Location currentLocation) {
        setHunger(getHunger() - 1);
        Object curObject = grass.getObjectAt(currentLocation);
        if (curObject instanceof Grass) {
            Grass curLocationGrass = (Grass) curObject;
            if (curLocationGrass.canEat()) {
                curLocationGrass.ate();
                setHunger(getFoodCount());
            }
        }
        if (getHunger() < 0) {
            setDead();
        }
    }

    

    /**
     * Kill of the prey if its sick and the kill probability hit
     */
    protected void kill() {
         if (isSick()) {
            if (rand.nextDouble() < KILL_PROBABILITY) {
                setDead();
            }
         }
     }
}
