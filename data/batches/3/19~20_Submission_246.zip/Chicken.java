import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a chicken.
 * Chickens age, move, breed, and die.
 *
 * @version 2020.02.17
 */
public class Chicken extends Prey
{
    // Characteristics shared by all chickens (class variables).

    // The age at which a chicken can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a chicken can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a chicken breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The number of steps chickens can take without grass
    private static final int FOOD_COUNT = 5;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The chicken's age.
    private int age;
    
    //The chicken's sex
    private boolean male;

    // The chicken's hunger
    private int food;

    /**
     * Create a new chicken. A chicken may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the chicken will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Chicken(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        food = FOOD_COUNT;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        male = rand.nextBoolean();
    }

    /**
     * This is what the chicken does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newChickens A list to return newly born chickens.
     * @param field The field of grass
     */
    public void act(List<Animal> newChickens, Field grass)
    {
        incrementAge();
        if(isAlive()) {
            // Check all adjacent locations for chickens of the opposite sex
            Boolean breed = false;
            List<Location> adjacent = getField().adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            breed = false;
            while (it.hasNext() && breed != true) {
                Object animal = getField().getObjectAt(it.next());
                if(animal instanceof Chicken) {
                    Chicken adjChicken = (Chicken) animal;
                    if (adjChicken.getSex() != getSex()) {
                        breed = true;
                    }
                }
            }
            // Breed if there are chickens of the opposite sex at adjacent cells
            if (breed) {
                giveBirth(newChickens);
            }
            mutate();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
                eat(grass, newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            kill();
        }
    }

    /**
     * Check whether or not this chicken is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newChickens A list to return newly born chickens.
     */
    private void giveBirth(List<Animal> newChickens)
    {
        // New chickens are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Chicken young = new Chicken(false, field, loc);
            newChickens.add(young);
        }
    }

    /**
     * Increase the age.
     * This could result in the chicken's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * @return the hunger value of the chicken
     */
    protected int getHunger() {
        return food;
    }

    /**
     * @return the FOOD_COUNT of the chicken
     */
    protected int getFoodCount() {
        return FOOD_COUNT;
    }

    /**
     * mutate the hunger value of the chicken
     * @param amount the value ot set the hunger as
     */
    protected void setHunger(int amount) {
        food = amount;
    }

    /**
     * @return the MAX_LITTLE_SIZE of the chicken
     */
    protected int getMaxOffspring() {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the BREEDING_AGE of the chicken
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return the BREEDING_PROBABILITY of the chicken
     */
    protected double getBreedingProb() {
        if (isSick()) {
            return 3 * BREEDING_PROBABILITY / 4;
        }
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the age of the chicken
     */
    protected int getAge() {
        return age;
    }
    
    /**
     * @return the sex of the chicken
     */
    private boolean getSex() {
        return male;
    }
}
