import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a deer.
 * Deers age, move, breed, and die.
 *
 * @version 2020.02.17
 */
public class Deer extends Prey
{
    // Characteristics shared by all deers (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a deer can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The number of steps deers can take without grass
    private static final int FOOD_COUNT = 5;
   
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The deer's age.
    private int age;
    
    // The deer's sex
    private boolean male;

    // The deer's hunger
    private int food;

    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        food = FOOD_COUNT;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        male = rand.nextBoolean();
    }

    /**
     * This is what the deer does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newDeers A list to return newly born deers.
     * @param field The field of grass
     */
    public void act(List<Animal> newDeers, Field grass)
    {
        incrementAge();
        if(isAlive()) {
            // Check all adjacent locations for deers of the opposite sex
            Boolean breed = false;
            List<Location> adjacent = getField().adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            breed = false;
            while (it.hasNext() && breed != true) {
                Object animal = getField().getObjectAt(it.next());
                if(animal instanceof Deer) {
                    Deer adjDeer = (Deer) animal;
                    if (adjDeer.getSex() != getSex()) {
                        breed = true;
                    }
                }
            }
            // Breed if there are deers of the opposite sex at adjacent cells
            if (breed) {
                giveBirth(newDeers);
            }
            mutate();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
                eat(grass, newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            kill();
        }
    }

    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeers A list to return newly born deers.
     */
    private void giveBirth(List<Animal> newDeers)
    {
        // New deers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc);
            newDeers.add(young);
        }
    }

    /**
     * Increase the age.
     * This could result in the deer's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * @return the hunger value of the deer
     */
    protected int getHunger() {
        return food;
    }

    /**
     * @return the FOOD_COUNT of the deer
     */
    protected int getFoodCount() {
        return FOOD_COUNT;
    }

    /**
     * mutate the hunger value of the deer
     * @param amount the value ot set the hunger as
     */
    protected void setHunger(int amount) {
        food = amount;
    }

    /**
     * @return the MAX_LITTLE_SIZE of the deer
     */
    protected int getMaxOffspring() {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return the BREEDING_AGE of the deer
     */
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * @return the BREEDING_PROBABILITY of the deer
     */
    protected double getBreedingProb() {
        if (isSick()) {
            return 3 * BREEDING_PROBABILITY / 4;
        }
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the age of the deer
     */
    protected int getAge() {
        return age;
    }
    
    /**
     * @return the sex of the deer
     */
    private boolean getSex() {
        return male;
    }
}