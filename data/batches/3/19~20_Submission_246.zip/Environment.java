import java.util.Random;

/**
 * A simple model of the environment
 * Includes the weather and the day-night cycle
 *
 * @version 2020.02.17
 */
public class Environment
{
    // The number of steps that it takes to complete half a day cycle
    private static final int DAY_CYCLE = 5;
    // The chance of rain
    private static final double RAIN_CHANCE = 0.3;
    // The chance of being cloudy
    private static final double CLOUDY_CHANCE = 0.3;
    // Random number generator, for the weather
    private static final Random rand = Randomizer.getRandom(); 

    // Current state of the environment
    private boolean day;
    private boolean rain;
    private boolean cloudy;
    private int daySinceLastRain;

    /**
     * Create a new environment for the simulation
     * Initially, it is day, and it has just rained
     */
    public Environment() {
        this.day = true;
        this.rain = false;
        this.daySinceLastRain = 0;
    }

    /**
     * Changes the setting of the environment
     * @param step the step counter of the simulation
     * @param grass the grass field, which will be affect by rain
     */
    public void setting(int step, Field grass) {
        toggleDaylight(step);
        switchWeather();
        if (daySinceLastRain < 15) {
            for (int row = 0; row < grass.getDepth(); row++) {
                for (int col = 0; col < grass.getWidth(); col++) {
                    Grass curLocationGrass = (Grass) grass.getObjectAt(row, col);
                    if (curLocationGrass.canGrow()) {
                        curLocationGrass.grow();
                    }
                    curLocationGrass.growing();
                }
            }
        }
    }
    /**
     * Toggling the day-night cycle every some steps
     * @param step the step counter of the simulation
     */
    private void toggleDaylight(int step) {
        if (step % DAY_CYCLE == 0 && step != 0) {
            day = !day;
        }
    }

    /**
     * @return is the simulation currently day time
     */
    public boolean isDay() {
        return day;
    }

    /**
     * Randomly switch up the weather based on each one's chance
     */
    private void switchWeather() {
        if (rand.nextDouble() <= RAIN_CHANCE) {
            rain = true;
            cloudy = true;
            daySinceLastRain = 0;
        }
        else if (rand.nextDouble() <= CLOUDY_CHANCE) {
            rain = false;
            cloudy = true;
        }
        else {
            rain = false;
            cloudy = false;
            daySinceLastRain++;
        }
    }
    
    /**
     * @return is the simulation currently raining
     */
    public boolean isRain() {
        return rain;
    }

    /**
     * @return is the simulation currently cloudy
     */
    public boolean isCloud() {
        return cloudy;
    }
}
