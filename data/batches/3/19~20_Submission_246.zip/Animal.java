import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.17
 */
public abstract class Animal
{

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The likelihood of getting sick
    protected static double DISEASE_PROBABILITY = 0.01;
    // The likelihood of getting infected
    protected static double INFECTION_PROBABILITY = 0.04;

    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's sickness stats
    protected boolean sick;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        sick = false;
        if (rand.nextDouble() <= DISEASE_PROBABILITY){
            sick = true;
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param field The field of grass
     */
    abstract public void act(List<Animal> newAnimals, Field field);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    abstract protected int getMaxOffspring();

    abstract protected int getBreedingAge();

    abstract protected double getBreedingProb();

    abstract protected int getAge();

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProb()) {
            births = rand.nextInt(getMaxOffspring() + 1);
        }
        return births;
    }

    /**
     * A chicken can breed if it has reached the breeding age.
     * @return true if the chicken can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Affects to the animal done by the disease
     * There are two ways to get the disease
     * Self mutation or infection
     */
    protected void mutate() {
        if (rand.nextDouble() <= DISEASE_PROBABILITY) {
            sick = true;
        }
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Object object = getField().getObjectAt(it.next());
            if (object instanceof Animal) {
                Animal animal = (Animal) object;
                if (animal.isSick()) {
                    if (rand.nextDouble() <= INFECTION_PROBABILITY) {
                        sick = true;
                    }
                }
            }        
        }
    }

    /**
     * @return whether or not the animal is sick
     */
    protected boolean isSick() {
        return sick;
    }
}