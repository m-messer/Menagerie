import java.util.List;
import java.util.Iterator;
/**
 * Abstract class Predator - A simple model of the animal type predator
 * @version 2020.02.17
 */
public abstract class Predator extends Animal
{
    public Predator(Field field, Location location) {
        super(field, location);
    }

    /**
     * An abstract method - For predators to eat the preys
     * @param animal An Object of Animal
     * @return a boolean determining whether the animal has eaten
     */
    abstract protected boolean eat(Object animal);

    /**
     * Look for sheeps adjacent to the current location.
     * Only the first live sheep is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(eat(animal)){
                return where;
            };
        }
        return null;
    }
}
