import java.util.List;

/**
 * A simple model of an infected Elephant.
 * Infected elephant's action.
 * This clsss extends Elephant class.
 *
 * @version 22.02.2020 
 */
public class InfectedElephant extends Elephant
{
    
    /**
     * Create a new infected elephant. An infected elephant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the infected elephant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public InfectedElephant(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the infected elephant does most of in the day time - it runs 
     * around and eat plants. Sometimes it will breed or die of old age.
     * @param newElephants A list to return newly born elephants.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newElephants, boolean isRain)
    {
        super.actDay(newElephants, isRain);
    }
    
    /**
     * This is what the infected elephant does most of in the night time - it sleeps
     * and eat plants. Sometimes it will breed or die of old age.
     * @param newElephants A list to return newly born elephants.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newElephants, boolean isRain)
    {
        super.actNight(newElephants, isRain);
    }
}
