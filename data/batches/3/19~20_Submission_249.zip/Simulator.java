import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing lions, wolves, zebras, elephants, cattle, a hunter, and plants.
 * They are infected by environment and disease.
 *
 * @version 22.02.2020 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that each predator will be created in any given grid position.
    private static final double Lion_CREATION_PROBABILITY = 0.04;
    private static final double WOLF_CREATION_PROBABILITY = 0.04;
    // The probability that each prey will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.04;    
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.04;
    private static final double CATTLE_CREATION_PROBABILITY = 0.04;
    // The probability that each plant will be created in any given grid position.
    private static final double FRUITTREE_CREATION_PROBABILITY = 0.03;
    private static final double VEGETABLE_CREATION_PROBABILITY = 0.03;
    
    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // Objects of Weather and Diease.
    private Weather weather;
    private Diease diease;
    // The current step of the simulation.
    private int step;
    // The depth and width of the grid.
    private int depth;
    private int width;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();
        diease = new Diease();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Elephant.class, Color.PINK);
        view.setColor(Cattle.class, Color.RED);
        view.setColor(Lion.class, Color.YELLOW);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Hunter.class, Color.BLACK);
        view.setColor(FruitTree.class, Color.GREEN);
        view.setColor(Vegetable.class, Color.CYAN);
        // Infected animals are represented by daker colors.
        view.setColor(InfectedZebra.class, Color.ORANGE.darker());
        view.setColor(InfectedElephant.class, Color.PINK.darker());
        view.setColor(InfectedCattle.class, Color.RED.darker());
        view.setColor(InfectedLion.class, Color.YELLOW.darker());
        view.setColor(InfectedWolf.class, Color.BLUE.darker());
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actor
     * (lion, wolf, zebra, elephant, cattle, hunter and plant).
     */
    public void simulateOneStep()
    {
        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>();
        
        // Update day and night.
        boolean isDay = getIsDay();
        // Increment steps.
        step++;
        // Update weather.
        weather.setRain();
        boolean isRain = weather.isRain();
        // set a diease in the field.
        diease.setDisease(actors, newActors);
        
        // Let all actors act in the daytime or in the nighttime.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            if(isDay) {
                actor.actDay(newActors, isRain);
            }
            else {
                actor.actNight(newActors, isRain);
            }
            // Remove the dead actors from the list except plants.
            // Remove the plants that destroyed by the hunter as well.
            if(! actor.isAlive()) {
                if(!(actor instanceof Plant)){
                    it.remove();
                }
                else {
                    Plant plant = (Plant) actor;
                    if(plant.getLocation() == null) {
                        it.remove();
                    }
                }
            }
        }
               
        // Add the newly born actors to the main lists.
        actors.addAll(newActors);
        
        // Update the labels.
        view.showStatus(step, field, getIsDay(), getIsRain(), Plant.getTotalAmount());
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        Plant.resetTotalAmount();
        actors.clear();
        diease.setIsDiseaseHappened(false);
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, getIsDay(), getIsRain(), Plant.getTotalAmount());
    }
    
    /**
     * Randomly populate the field with actors(animals, plants and the hunter).
     */
    private void populate()
    {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Lion_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    actors.add(lion);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    actors.add(wolf);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    actors.add(zebra);
                }
                else if(rand.nextDouble() <= ELEPHANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Elephant elephant = new Elephant(true, field, location);
                    actors.add(elephant);
                }
                else if(rand.nextDouble() <= CATTLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cattle cattle = new Cattle(true, field, location);
                    actors.add(cattle);
                }
                else if(rand.nextDouble() <= FRUITTREE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    FruitTree fruitTree = new FruitTree(field, location);
                    actors.add(fruitTree);
                }
                else if(rand.nextDouble() <= VEGETABLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Vegetable vegetable = new Vegetable(field, location);
                    actors.add(vegetable);
                }
                // else leave the location empty.
            }
        }
        // Create a hunter in the field.
        Location location = field.getRandomLocation();
        Hunter hunter = new Hunter(field, location);
        actors.add(hunter);
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Get that current step is day or night by checking the the
     * number of steps is odd(day) or even number(night).
     */
    private boolean getIsDay()
    {  
        if(step % 2 == 0){
            return false;
        }
        else{
            return true;
        }
    }
    
    /**
     * Get that current step is raining or not.
     */
    private boolean getIsRain()
    {  
        return weather.isRain();
    }
}
