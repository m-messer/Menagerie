import java.util.List;
import java.util.Random;

/**
 * A simple model of a cattle.
 * Cattle's action.
 * This clsss extends Prey class.
 *
 * @version 22.02.2020 
 */
public class Cattle extends Prey
{
    // Characteristics shared by all cattle (class variables).
    // The age at which a cattle can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a cattle can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a cattle breeding.
    private static final double BREEDING_PROBABILITY = 0.58;
    // The maximum number of births of a cattle.
    private static final int MAX_LITTER_SIZE = 5;
    // The maxium number of food level of a cattle.
    private static final int MAX_FOOD_LEVEL = 9;
    // Whether cattles eat fruit trees or not.
    private static final boolean DOES_EAT_FRUITTREE = true;
    // Whether cattles eat vegetables or not.
    private static final boolean DOES_EAT_VEGETABLE = true;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new cattle. A cattle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the cattle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cattle(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the cattle does most of in the day time - it runs 
     * around and eat plants. Sometimes it will breed or die of old age.
     * @param newCattles A list to return newly born cattles.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newCattles, boolean isRain)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect(newCattles);
            giveBirth(newCattles);
            eatPlant();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the cattle does most of in the night time - it sleeps
     * and eat plants. Sometimes it will breed or die of old age.
     * @param newCattles A list to return newly born cattles.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newCattles, boolean isRain)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect(newCattles);
            giveBirth(newCattles); 
            eatPlant();
        }
    }
    
    /**
     * Return the maxium age of cattles.
     * @return The maxium age of cattles.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Return the maxium number of a cattle can breed for one time.
     * @return The maxium number of a cattle can breed for one time.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the breeding age of a cattle.
     * @return The breeding age of a cattle.
     */
    @Override
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Return the maximum food level of a cattle.
     * @return The maximum food level of a cattle.
     */
    @Override
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the breeding probability of a cattle.
     * @return The breeding probability of a cattle.
     */
    @Override
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return true if cattles eat fruits of fruit trees.
     */
    @Override
    public boolean getDoesEatFruitTree()
    {
        return DOES_EAT_FRUITTREE;
    }
    
    /**
     * @return true if cattles eat fruits of vegetables.
     */
    @Override
    public boolean getDoesEatVegetable()
    {
        return DOES_EAT_VEGETABLE;
    }
    
    /**
     * Return a normal animal object. The dynamic type is Cattle.
     * @return an new animal instance of Cattle.
     */
    @Override
    public Animal getInstance(boolean randomAge, Field field, Location loc)
    {
        return new Cattle(randomAge, field, loc);
    }
    
    /**
     * Return an infected animal object. The dynamic type is InfectedCattle.
     * @return an new animal instance of InfectedCattle.
     */
    @Override
    public Animal getInfectedInstance(boolean randomAge, Field field, Location loc)
    {
        return new InfectedCattle(randomAge, field, loc);
    }
}