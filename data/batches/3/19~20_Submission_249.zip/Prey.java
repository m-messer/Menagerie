import java.util.List;
import java.util.Iterator;
/**
 * A class representing shared characteristics of preys.
 * This clss extends the Animal class.
 *
 * @version 22.02.2020 
 */
public abstract class Prey extends Animal
{
    // The value of different food to preys. Must be smaller than the maximum food value.
    private static final int FRUITTREE_FOOD_VALUE = 6;
    private static final int VEGETABLE_FOOD_VALUE = 9;
    
    /**
     * Create a new prey at location in field.(cannot be actually created as an object)
     * @param ture if the age is set randomly.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location)
    {
       super(randomAge, field, location);
    }
    
    /**
     * Look for plants adjacent to the current location.
     * Only the fruit of the first plant is eaten.
     */
    protected void eatPlant()
    {
        // Get adject object.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            // Check whether this Prey eat a specific type of plant or not and whether it is hungry or not.
            if(actor instanceof FruitTree && getDoesEatFruitTree() && getDoesHungery()) {
                FruitTree fruitTree = (FruitTree) actor;
                if(fruitTree.isAlive()) { 
                    fruitTree.decrementAmount();
                    setFoodLevel(FRUITTREE_FOOD_VALUE);
                }
            }
            if(actor instanceof Vegetable && getDoesEatVegetable() && getDoesHungery()) {
                Vegetable vegetable = (Vegetable) actor;
                if(vegetable.isAlive()) { 
                    vegetable.decrementAmount();
                    setFoodLevel(VEGETABLE_FOOD_VALUE);
                }
            }
        }
    }
    
    
    // Some abstract methods.
    /**
     * @return true if the prey eats fruits of fruit trees.
     */
    public abstract boolean getDoesEatFruitTree();
    
    /**
     * @return true if the prey eats fruits of vegetable.
     */
    public abstract boolean getDoesEatVegetable();
}
