import java.util.List;

/**
 * A simple model of an infected lion.
 * Infected lion's action.
 * This clsss extends Lion class.
 *
 * @version 22.02.2020 
 */
public class InfectedLion extends Lion
{
    
    /**
     * Create a new infected lion. An infected lion may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the infected lion will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public InfectedLion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the infected lion does most of in the day time: it hunts for
     * some/all type preys. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newLions, boolean isRain)
    {
        super.actDay(newLions, isRain);
    }
    
    /**
     * This is what the infected lion does most of in the night time: it hunts for
     * some/all type preys. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newLions, boolean isRain)
    {
        super.actNight(newLions, isRain);
    }
}
