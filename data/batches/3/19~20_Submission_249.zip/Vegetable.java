import java.util.List;

/**
 * A simple model of a vegetable.
 * Vegetable's action.
 * This class extends Plant class.
 *
 * @version 22.02.2020 
 */
public class Vegetable extends Plant
{
    private static final int MAXIMUM_AMOUNT = 5;
    
    /**
     * Creat a new vegetable.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Vegetable(Field field, Location location)
    {
       super(field, location);
    }
    
    /**
     * This is what the vegetable does most of in the day time - it grows slowly.
     * @param newVegetables A list to return newly born vegetables.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newVegetables, boolean isRain)
    {
        incrementAmount(1, isRain);
    }
    
    /**
     * This is what the vegetable does most of in the night time - it grows fast.
     * @param newVegetables A list to return newly born vegetables.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newVegetables, boolean isRain)
    {
        incrementAmount(2, isRain);
    }
    
    /**
     * Return the maximum amount of fruits on the vegetable.
     * @return The maximum amount of fruits on the vegetable.
     */
    public int getMaxiumAmount()
    {
        return MAXIMUM_AMOUNT;
    }
}
