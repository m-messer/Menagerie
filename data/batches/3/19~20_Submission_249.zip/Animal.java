import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 * This class implements Interface Actor.
 *
 * @version 22.02.2020 
 */
public abstract class Animal implements Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's current age.
    private int age;
    // The animal's current foodLevel indicating how hungry it is.
    private int foodLevel;
    // The animal's gender.
    private boolean isMale;
    // Whether the animal is infected. Using the boolean to distinguish the normarl and infected animals.
    private boolean isInfected;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.(cannot be actually created as an object)
     * @param ture if the age is set randomly.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        isInfected = false;
        setAge(0);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getMaxFoodLevel()));
        }
        else {
            setAge(0);
            setFoodLevel(getMaxFoodLevel());
        }
        isMale = rand.nextBoolean();
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Make the animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(location);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = getInstance(false,field, loc);
            newAnimals.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && isAbleMate() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= getBreedingAge();
    }
    
    /**
     * An animal are able to mate when it meets an animal of same species but with different gender.
     * @return true if the animal are able to mate, false otherwise.
     */
    public boolean isAbleMate()
    {
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            // Make sure the object met is an animal and they are the same species.
            // (write "actor instanceof Animal" in foront of "&&" to avoid NullPointerException error)
            if(actor instanceof Animal && (this.getClass() == actor.getClass() ||
            this.getClass() == actor.getClass().getSuperclass() || this.getClass().getSuperclass() == actor.getClass())) {
                Animal animal = (Animal) actor;
                if (isMale != animal.getGender()) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * The infected animal infects the animals in the adjecent locations
     * @param newAnimals A list to receive newly born animals.
     */
    protected void infect(List<Actor> newAnimals)
    {
        if(isInfected) {
            Field field = getField();
            // Get a list of adjacent locations.
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                // Get the adajcent actor in the location.
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                // Check if it is an animal.
                if(actor instanceof Animal) {
                    Animal animal = (Animal) actor;
                    if(!animal.getIsInfected()) {
                        animal.setInfected(newAnimals);
                    }
                }
            }
        }
    }
    
    /**
     * What would happen when an animal is infected.
     * Symptom: Increae age by 15.
     * (create a new infected animal object by using the same field of the normal one
     *  and delete the normal animal)
     * @param newAnimals A list to receive newly born animals.
     */
    public void setInfected(List<Actor> newAnimals)
    {
        int tempAge = age + 15;
        if (tempAge > getMaxAge()) {
           setDead();
        }
        else { 
           // Remember all the information of the normal animal.
           boolean tempIsMale = isMale;
           int tempFoodLevel = foodLevel;
           Location tempLocation = location;
           Field tempField = field;
           // Set the normal one dead.
           setDead();
           // Create a new infected animal and update its status.
           Animal newInfected = getInfectedInstance(false, tempField, tempLocation);
           newInfected.setAge(age);
           newInfected.setGender(isMale);
           newInfected.setFoodLevel(foodLevel);
           newInfected.setIsInfected();
           newAnimals.add(newInfected);
        }
    }
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the animal's gender.
     * @return ture if the animal is male.
     */
    public boolean getGender()
    {
        return isMale;
    }
    
    /**
     * Set up the animal's gender.
     * @param ture if the animal is male.
     */
    public void setGender(boolean isMale)
    {
        this.isMale =  isMale;
    }
    
    /**
     * Set up the animal's age.
     * @param The age of the animal.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * Set up the animal's food level.
     * @param The food level needed to be added.
     */
    protected void setFoodLevel(int addedFoodLevel)
    {
        int newFoodLevel = foodLevel + addedFoodLevel;
        if (newFoodLevel <= getMaxFoodLevel()) {
            foodLevel = newFoodLevel;
        }
        else {
            foodLevel = getMaxFoodLevel();
        }
    }
    
    /**
     * Return whether the animal is infected or not.
     * @return true if the animal is infected.
     */
    protected boolean getIsInfected()
    {
        return isInfected;
    }
    
    /**
     * Make the animal be infected and there is no way to end the disease,
     * so there is no parameter.
     */
    protected void setIsInfected() 
    {
        isInfected = true;
    }
    
    /**
     * Return whether the animal is hungry or not.
     * @return true if the animal is hungry.
     */
    protected boolean getDoesHungery()
    {
        return foodLevel < getMaxFoodLevel()*3/4;
    }
    
    
    // Some abstract methods.
    /**
     * An abstract method of getting the maxium age of the animal.
     * @return The maxium age of the animal.
     */
    abstract public int getMaxAge();
    
    /**
     * An abstract method of getting the maxium number of the animal can breed for one time.
     * @return The maxium number of the animal can breed for one time.
     */
    abstract public int getMaxLitterSize();
    
    /**
     * An abstract method of getting the breeding age of this animal.
     * @return The breeding age of the animal.
     */
    abstract public int getBreedingAge();
    
    /**
     * An abstract method of getting the maximum food level of this animal.
     * @return The maximum food level of the animal.
     */
    abstract public int getMaxFoodLevel();
    
    /**
     * An abstract method of getting the breeding probability of this animal.
     * @return The breeding probability of this animal.
     */
    abstract public double getBreedingProbability();
    
    /**
     * This method is mainly made for breeding.
     * Infected animals and the normal animals are belong to the same species.
     * An abstract method of getting and creating a new instance(normal animal) of the same species of this animal.
     * (Type of the new instance is same as the normal animal.)
     * @return an new animal instance of the same species of the animal calling this method.
     */
    abstract public Animal getInstance(boolean randomAge, Field field, Location loc);
    
    /**
     * This method is mainly made for infecting.
     *  * Infected animals and the normal animals are belong to the same species.
     * An abstract method of getting and creating a new instance(infected animal) of the same species of this animal.
     * (Type of the new instance is same as the infected animal.)
     * @return an new animal instance of the same species of the animal calling this method.
     */
    abstract public Animal getInfectedInstance(boolean randomAge, Field field, Location loc);
}
