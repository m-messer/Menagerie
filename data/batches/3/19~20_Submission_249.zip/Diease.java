import java.util.Random;
import java.util.Collections;
import java.util.List;
import java.util.Iterator;

/**
 * This class is about diease.
 * It includes the how the diease starts
 * and some important constants of the disease.
 *
 * @version 22.02.2020 
 */
public class Diease
{
    // Some constants.
    private static final double DISEASE_HAPPENING_PROBABILITY = 0.01; 
    private static final int MAXIMUM_FIRST_TIME_INFECTION = 3;
    // A boolean variable indicates whether the disease has happenend or not.
    private boolean isDiseaseHappened;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Creat a new diease that haven't happened.
     */
    public Diease()
    {
       isDiseaseHappened = false;
    }
    
    /**
     * When the diease happens, randomly choose a number of animals 
     * and turn them into infected animals.
     * @param actors List of actors in the field.
     * @param newActors A list to receive newly born actors.
     */
    public void setDisease(List<Actor> actors, List<Actor> newActors)
    {
        if(rand.nextDouble() <= DISEASE_HAPPENING_PROBABILITY && isDiseaseHappened == false) {
            // Update status'
            isDiseaseHappened = true;
            // Make suer randomly choose actors from the list.
            Collections.shuffle(actors, rand);
            Iterator<Actor> it = actors.iterator();
            int n = 0;
            while(it.hasNext() && n < MAXIMUM_FIRST_TIME_INFECTION) {
                Object actor = it.next();
                if(actor instanceof Animal) {
                    Animal animal = (Animal) actor;
                    animal.setInfected(newActors);
                    n++;
                }
            }
        }
    }
    
    /**
     * Update the disease.
     * @param True if the disease has happened.
     */
    public void setIsDiseaseHappened(boolean isDiseaseHappened)
    {
        this.isDiseaseHappened = isDiseaseHappened;
    }
}
