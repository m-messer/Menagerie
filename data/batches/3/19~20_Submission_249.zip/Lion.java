import java.util.List;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat preys, and die.
 * This class extends the Predator class.
 *
 * @version 22.02.2020 
 */
public class Lion extends Predator
{
    // Characteristics shared by all lions (class variables).
    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 14;
    // The age to which a lion can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.63;
    // The maximum number of births of a lion.
    private static final int MAX_LITTER_SIZE = 5;
    // The maxium number of food level of a lion.
    private static final int MAX_FOOD_LEVEL = 9;
    // Whether wolves eat zebras or not.
    private static final boolean DOES_EAT_ZEBRA = true;
    // Whether wolves eat elephants or not.
    private static final boolean DOES_EAT_ELEPHANT = true;
    // Whether wolves eat cattles or not.
    private static final boolean DOES_EAT_CATTLE = true;
   
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new lion. A lion may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the lion will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the lion does most of in the day time: it hunts for
     * some/all type preys. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newLions, boolean isRain)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect(newLions);
            giveBirth(newLions);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the lion does most of in the night time: it hunts for
     * some/all type preys. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newLions, boolean isRain)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            infect(newLions);
            giveBirth(newLions);
        }
    }
    
    /**
     * Return the maxium age of a lion.
     * @return The maxium age of a lion.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Return the maxium number of a lion can breed for one time.
     * @return The maxium number of a lion can breed for one time.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the breeding age of a lion.
     * @return The breeding age of a lion.
     */
    @Override
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Return the maximum food level of a lion.
     * @return The maximum food level of a lion.
     */
    @Override
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the breeding probability of a lion.
     * @return The breeding probability of a lion.
     */
    @Override
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return true if lions eat zebras(including infected zebras).
     */
    @Override
    public boolean getDoesEatZebra()
    {
        return DOES_EAT_ZEBRA;
    }
    
    /**
     * @return true if lions eat elephants(including infected elephants).
     */
    @Override
    public boolean getDoesEatElephant()
    {
        return DOES_EAT_ELEPHANT;
    }
    
    /**
     * @return true if lions eat cattles(including infected cattles).
     */
    @Override
    public boolean getDoesEatCattle()
    {
        return DOES_EAT_CATTLE;
    }
    
    /**
     * Return a normal animal object. The dynamic type is Lion.
     * @return an new animal instance of Lion.
     */
    @Override
    public Animal getInstance(boolean randomAge, Field field, Location loc)
    {
        return new Lion(randomAge, field, loc);
    }
    
    /**
     * Return an infected animal object. The dynamic type is InfectedLion.
     * @return an new animal instance of InfectedLion.
     */
    @Override
    public Animal getInfectedInstance(boolean randomAge, Field field, Location loc)
    {
        return new InfectedLion(randomAge, field, loc);
    }
}
