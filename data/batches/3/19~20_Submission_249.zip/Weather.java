import java.util.Random;

/**
 * This class is about weather.
 * It includes the how the weat strats
 * and some important constants of the weather.
 *
 * @version 22.02.2020 
 */
public class Weather
{   
    // The rate of rain happening.
    private static final double RAIN_HAPPENING_PROBABILITY = 0.20;
    
    private boolean isRain;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a weather which is not rainy.
     */
    public Weather()
    {
        isRain = false;
    }
    
    /**
     * Set up a rainy day.
     */
    public void setRain()
    {
        if(rand.nextDouble() <= RAIN_HAPPENING_PROBABILITY) {
            isRain = true;
        }
        else{
            isRain = false;
        }
    }
    
    /**
     * @return true if the current step is raining.
     */
    public boolean isRain()
    {
        return isRain;
    }
}
