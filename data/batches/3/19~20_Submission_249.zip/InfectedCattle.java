import java.util.List;

/**
 * A simple model of an infected Cattle.
 * Infected elephant's action.
 * This clsss extends Elephant class.
 *
 * @version 22.02.2020 
 */
public class InfectedCattle extends Cattle
{
    
    /**
     * Create a new infected cattle. An infected cattle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the infected cattle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public InfectedCattle(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the infected cattle does most of in the day time - it runs 
     * around and eat plants. Sometimes it will breed or die of old age.
     * @param newCattles A list to return newly born cattles.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newCattles, boolean isRain)
    {
        super.actDay(newCattles, isRain);
    }
    
    /**
     * This is what the infected cattle does most of in the night time - it sleeps
     * and eat plants. Sometimes it will breed or die of old age.
     * @param newCattles A list to return newly born cattles.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newCattles, boolean isRain)
    {
        super.actNight(newCattles, isRain);
    }
}
