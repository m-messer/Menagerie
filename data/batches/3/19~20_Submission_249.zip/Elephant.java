import java.util.List;
import java.util.Random;

/**
 * A simple model of an elephant.
 * Elephant's action.
 * This clsss extends Prey class.
 *
 * @version 22.02.2020 
 */
public class Elephant extends Prey
{
    // Characteristics shared by all elephants (class variables).
    // The age at which an elephant can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which an elephant can live.
    private static final int MAX_AGE = 30;
    // The likelihood of an elephant breeding of elephant.
    private static final double BREEDING_PROBABILITY = 0.58;
    // The maximum number of births of an elephant.
    private static final int MAX_LITTER_SIZE = 5;
    // The maxium number of food level of an elephant.
    private static final int MAX_FOOD_LEVEL = 9;
    // Whether elephants eat fruit trees or not.
    private static final boolean DOES_EAT_FRUITTREE = true;
    // Whether elephants eat vegetables or not.
    private static final boolean DOES_EAT_VEGETABLE = true;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new elephant. An elephant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the elephant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Elephant(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the elephant does most of in the day time - it runs 
     * around and eat plants. Sometimes it will breed or die of old age.
     * @param newElephants A list to return newly born elephants.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newElephants, boolean isRain)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // only do this action when the elephant is infected.
            infect(newElephants);
            
            giveBirth(newElephants);
            eatPlant();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
               setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the elephant does most of in the night time - it sleeps
     * and eat plants. Sometimes it will breed or die of old age.
     * @param newElephants A list to return newly born elephants.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newElephants, boolean isRain)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            // only do this action when the animal is infected.
            infect(newElephants);
            
            giveBirth(newElephants);
            eatPlant();
        }
    }
    
    /**
     * Return the maxium age of an elephant.
     * @return The maxium age of an elephant.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Return the maxium number of an elephant can breed for one time.
     * @return The maxium number of an elephant can breed for one time.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the breeding age of an elephant.
     * @return The breeding age of an elephant.
     */
    @Override
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Return the maximum food level of an elephant.
     * @return The maximum food level of an elephant.
     */
    @Override
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return the breeding probability of an elephant.
     * @return The breeding probability of an elephant.
     */
    @Override
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return true if elephants eat fruits of fruit trees.
     */
    @Override
    public boolean getDoesEatFruitTree()
    {
        return DOES_EAT_FRUITTREE;
    }
    
    /**
     * @return true if elephants eat fruits of vegetables.
     */
    @Override
    public boolean getDoesEatVegetable()
    {
        return DOES_EAT_VEGETABLE;
    }
    
    /**
     * Return a normal animal object. The dynamic type is Elephant.
     * @return an new animal instance of Elephant.
     */
    @Override
    public Animal getInstance(boolean randomAge, Field field, Location loc)
    {
        return new Elephant(randomAge, field, loc);
    }
    
    /**
     * Return an infected animal object. The dynamic type is InfectedElephant.
     * @return an new animal instance of InfectedElephant.
     */
    @Override
    public Animal getInfectedInstance(boolean randomAge, Field field, Location loc)
    {
        return new InfectedElephant(randomAge, field, loc);
    }
}