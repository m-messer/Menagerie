import java.util.List;

/**
 * This is an interface. An actor can be Animal, Hunter or Plant.
 * Class Animal, Hunter and Plant implement this interface.
 * We are using the type polymorphism here.
 *
 * @version 22.02.2020 
 */
public interface Actor
{
    
    /**
     * An abstract method about how the an actor acts in the day time.
     * @param newActors A list to receive newly born actors.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    void actDay(List<Actor> newActors, boolean isRain);
    
    /**
     * An abstract method about how the an actor acts in the night time.
     * @param newActors A list to receive newly born actors.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    void actNight(List<Actor> newActors, boolean isRain);
    
    /**
     * @return An boolean indicates weather the actor is alive.
     */
    boolean isAlive();
}
