import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a hunter.
 * Hunter's action.
 * This class implements Actor interface.
 *
 * @version 22.02.2020 
 */
public class Hunter implements Actor
{
    // Maximum number of animals that a hunter can kill.
    private static final int TARGET_NUMBER = 3;
    
    private Field field;
    private Location location;
    private boolean alive;
    private int animalKilled;
    
    /**
     * Create a new hunter at location in field.
     * @param randomAge If true, the hunter will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hunter(Field field,Location newLocation)
    {
        alive = true;
        animalKilled = 0;
        this.field = field;
        Object object = field.getObjectAt(newLocation);
        if(object != null) {
            if(object instanceof Animal) {
                animalKilled += 1;
                Animal animal = (Animal) object;
                animal.setDead();
            }
            else if(object instanceof Plant) {
                Plant plant = (Plant) object;
                plant.setDeadHunter();
            }
        }
        field.place(this, newLocation);
        location = newLocation;
    }
    
    /**
     * This is what a hunter do in the day time.
     * He/She will kill animals near him/her.
     * @param newHunters A list to return newly born lions.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newHunters, boolean isRain)
    {
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        while(animalKilled < TARGET_NUMBER) {
            if(it.hasNext()) {
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                if(actor instanceof Animal) {
                    animalKilled += 1;
                    Animal animal = (Animal) actor;
                    animal.setDead();
                }
            }
            else {
                break;
            }
        }
    }
    
    /**
     * This is what a hunter do in the night time.
     * He/She will move to an adjecent location. If there is an animal
     * or palnt in that place, he will kill/destory it.
     * @param newHunters A list to return newly born lions.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newHunters, boolean isRain)
    {
        animalKilled = 0;
        Location newLocation = field.freeAdjacentLocation(location);
        if(newLocation != null) {
            if(location != null) {
                field.clear(location);
            }
            location = newLocation;
            field.place(this, newLocation);
        }
        else {
            List<Location> adjacent = field.adjacentLocations(location);
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                if(location != null) {
                    field.clear(location);
                }
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                if(actor instanceof Animal) {
                    animalKilled += 1;
                    Animal animal = (Animal) actor;
                    animal.setDead();
                }
                else if(actor instanceof Plant) {
                    Plant plant = (Plant) actor;
                    plant.setDeadHunter();
                }
                location = where;
                field.place(this, where);
            }
        }
    }
    
    /**
     * @return An boolean indicates weather the hunter is alive.
     */
    @Override
    public boolean isAlive()
    {
        return alive;
    }
}
