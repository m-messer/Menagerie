import java.util.List;

/**
 * A class representing shared characteristics of plants.
 * Plant's action.
 * A plant has several fruits.
 * Plant grows in different rate in the  day and night time.
 * When fruit are all eaten, they dies.
 * Rain can help them to to have maximum ammount of fruit.
 * This class implements Actor interface.
 *
 * @version 22.02.2020 
 */
public abstract class Plant implements Actor
{
    private boolean alive;
    private Field field;
    private Location location;
    private int amount;
    // Counter
    public static int totalAmount = 0;
    
    /**
     * Creat a new plant.(cannot be actually created as an object)
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.amount = getMaxiumAmount();
        totalAmount += amount;
        this.location = location;
        field.place(this, location);
    }
    
    /**
     * Decrease the number of fruits of plants by 1.
     */
    public void decrementAmount()
    {
        totalAmount -= amount;
        amount--;
        if(amount <= 0) {
            setDead();
        }
        totalAmount += amount;
    }
    
    /**
     * Increase the number of fruits of plants under different weather by a certain amount.
     * @param n The number of fruits increased.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    public void incrementAmount(int n, boolean isRain)
    {
        totalAmount -= amount;
        if (isRain) {
            // Revive the plant.
            alive = true;
            amount = getMaxiumAmount();
        }
        else{
            if(alive) {
                // Make sure the amount <= maximum amount
                int newAmount = amount + n;
                if (newAmount <= getMaxiumAmount()) {
                    amount = newAmount;
                }   
                else {
                    amount = getMaxiumAmount();
                }
            }
        }
        totalAmount += amount;
    }
    
    /**
     * Check whether the plant is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    /**
     * The plant is dead because of no fruits.
     * It is would not really disapper on the map.
     */
    public void setDead()
    {
        alive = false;
        amount = 0; 
    }
    
    /**
     * The plant is dead because of the hunter.
     * It is would disapper on the map.
     */
    public void setDeadHunter()
    {
        alive = false;
        if(location != null) {
            location = null;
            field = null;
        }
    }
    
    /**
     * @return The amount of fruits currently on the plant.
     */
    public int getAmount()
    {
        return amount;
    }
    
    public Location getLocation()
    {
        return location;
    }
    
    // Some static methods
    /**
     * @return The total amount of fruits of all plants.
     */
    public static int getTotalAmount()
    {
        return totalAmount;
    }
    
    /**
     * Reset the amount of total fruits number.
     */
    public static void resetTotalAmount()
    {
        totalAmount = 0;
    }
    
    // abstract method
    /**
     * An abstract method of getting the maximum amount of fruits on the plant.
     * @return The maximum amount of fruits on the plant.
     */
    abstract public int getMaxiumAmount();
}
