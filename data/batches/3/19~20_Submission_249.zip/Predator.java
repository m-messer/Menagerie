import java.util.List;
import java.util.Iterator;
/**
 * A class representing shared characteristics of predators.
 * This class extends the Animal class.
 *
 * @version 22.02.2020 
 */
public abstract class Predator extends Animal
{
    // The value of different food to predators. Must be smaller than the maximum food value.
    private static final int ZEBRA_FOOD_VALUE = 9;
    private static final int ELEPHANT_FOOD_VALUE = 9;
    private static final int CATTLE_FOOD_VALUE = 9;
    
    /**
     * Create a new predator at location in field.(cannot be actually created as an object)
     * @param ture if the age is set randomly.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Look for preys adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        // Get adject object.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            // Check whether this Predator eat a specific type of prey or not and whether it is hungry or not.
            if(actor instanceof Zebra && getDoesEatZebra() && getDoesHungery()) {
                Zebra zebra = (Zebra) actor;
                if(zebra.isAlive()) { 
                    zebra.setDead();
                    setFoodLevel(ZEBRA_FOOD_VALUE);
                    return where;
                }
            }
            else if(actor instanceof Elephant && getDoesEatElephant() && getDoesHungery()) {
                Elephant elephant = (Elephant) actor;
                if(elephant.isAlive()) { 
                    elephant.setDead();
                    setFoodLevel(ELEPHANT_FOOD_VALUE);
                    return where;
                }
            }
            else if(actor instanceof Cattle && getDoesEatCattle() && getDoesHungery()) {
                Cattle cattle = (Cattle) actor;
                if(cattle.isAlive()) { 
                    cattle.setDead();
                    setFoodLevel(CATTLE_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    
    // Some abstract methods.
    /**
     * @return true if this predator eats zebras(including the infected zebras).
     */
    public abstract boolean getDoesEatZebra();
    
    /**
     * @return true if this predator eats elephants(including the infected elephants).
     */
    public abstract boolean getDoesEatElephant();
    
    /**
     * @return true if this predator eats cattles(including the infected cattles).
     */
    public abstract boolean getDoesEatCattle();
}
