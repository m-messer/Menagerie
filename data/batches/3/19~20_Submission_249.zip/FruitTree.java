import java.util.List;

/**
 * A simple model of a fruit tree.
 * FruitTree's action.
 * This class extends Plant class.
 *
 * @version 22.02.2020 
 */
public class FruitTree extends Plant
{
    private static final int MAXIMUM_AMOUNT = 5;
    
    /**
     * Creat a new fruit tree.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public FruitTree(Field field, Location location)
    {
       super(field, location);
    }
    
    /**
     * This is what the fruit tree does most of in the day time - it grows slowly.
     * @param newFruitTrees A list to return newly born fruit trees.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newFruitTrees, boolean isRain)
    {
        incrementAmount(1, isRain);
    }
    
    /**
     * This is what the fruit tree does most of in the night time - it grows fast.
     * @param newFruitTrees A list to return newly born fruit trees.
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newFruitTrees, boolean isRain)
    {
        incrementAmount(2, isRain);
    }
    
    /**
     * Return the maximum amount of fruits on the fruit tree.
     * @return The maximum amount of fruits on the fruit tree.
     */
    public int getMaxiumAmount()
    {
        return MAXIMUM_AMOUNT;
    }
}
