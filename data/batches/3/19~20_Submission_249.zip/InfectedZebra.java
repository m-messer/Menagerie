import java.util.List;

/**
 * A simple model of an infected zebra.
 * Infected zebra's action.
 * This clsss extends Zebra class.
 *
 * @version 22.02.2020 
 */
public class InfectedZebra extends Zebra
{
    
    /**
     * Create a new infected zebra. An infected zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the infected zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public InfectedZebra(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the infected zebra does most of in the day time - it runs 
     * around and eat plants. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born zebras.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actDay(List<Actor> newZebras, boolean isRain)
    {
        super.actDay(newZebras, isRain);
    }
    
    /**
     * This is what the infected zebra does most of in the night time - it sleeps
     * and eat plants. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born zebras.(children of infected animals are healthy)
     * @param isRain A boolean which represents whether the current step is raining or not.
     */
    @Override
    public void actNight(List<Actor> newZebras, boolean isRain)
    {
        super.actNight(newZebras, isRain);
    }
}
