import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of actors.
 * @version 2021.03.03
 */

public abstract class Actor {
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The actor's age.
    private int age;
    // Whether the actor is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The actor's position in the field.
    private Location location;
    // The actor's gender
    private final String gender;
    // A list for possible genders
    private final String[] arr = {"F","M"};
    // Checks if animal is infected
    private boolean infected = false;
    // Level of food stored in the animal
    private int foodLevel;


    /**
     * Create a new actor at location in field.
     * An actor can have an initial age of zero or a
     * random age.
     *
     * @param randomAge If true, the actor will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Actor(boolean randomAge, Field field, Location location) {
        if (randomAge) {
            age = rand.nextInt(getMaxAge());
        } else {
            age = 0;
        }
        alive = true;
        this.field = field;
        setLocation(location);
        this.gender = arr[rand.nextInt(2)];
    }


    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Increase the age. This could result in the actor's death.
     */
    protected void incrementAge() {
        age++;
        if (age > this.getMaxAge()) {
            setDead();
        }
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;

        }
    }

    /**
     * Check whether or not this actor is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOffspring A list of offspring to be born in a step.
     */
    protected void giveBirth(List<Actor> newOffspring)
    {
        // New actors are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newOffspring.add(createActor(false, field, loc));
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An actor can breed if it has reached the breeding age.
     * @return true if the actor can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Checks if there is an actor nearby to mate
     * @return true if there is an adjacent actor with
     * the same species but the opposite gender.
     *
     */
    protected boolean nextToMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if( actor instanceof Actor)  {
                Actor mate = (Actor) actor;
                if(mate.getClass().equals(getClass())) {   // if the two animals are the same species
                    if(mate.isAlive() && !(mate.getGender().equals(getGender()))) {  // if they are opposite genders
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Actor eats another actor and possibly gets infected
     * @param actor the actor that is eaten
     */
    protected void eat(Actor actor){
        int foodValue = actor.getFoodValue();
        setFoodLevel(foodLevel + foodValue);
        if(actor instanceof Animal && (actor).isInfected()){
            infect();
        }
    }

    /**
     * There are diseases in the ocean. If an actor gets a disease,
     * it halves its food level. Thus, the actor needs to find more
     * food to stay alive.
     */
    protected void infect(){
        infected = true;
        setFoodLevel(foodLevel/2);
    }

    /**
     * Checks if the actor is infected.
     * @return true if infected, else false.
     */
    protected boolean isInfected(){ return infected; }

    /**
     * Updates the food level of the actor
     * @param foodLevel food level stored in the actor
     */
    protected void setFoodLevel(int foodLevel) {
        if (foodLevel > this.getMaxHunger()) {
            this.foodLevel = this.getMaxHunger();
        } else {
            this.foodLevel = foodLevel;
        }
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    public abstract void act(List<Actor> newActors);

    protected abstract int getMaxHunger();

    protected abstract double getBreedingProbability();

    protected abstract int getMaxLitterSize();

    protected abstract int getBreedingAge();

    protected abstract Actor createActor(boolean randomAge, Field field, Location location);

    protected abstract int getFoodValue();

    protected abstract int getMaxAge();

    protected String getGender(){ return gender; }

    protected boolean isFemale(){ return gender.equals("F"); }

}
