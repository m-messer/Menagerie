import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.03
 */
public abstract class Animal extends Actor
{
    // Animal's current hunger.
    private int foodLevel;

    // The probability of a salmon getting infected with a disease.
    public static final double INFECTION_PROBABILITY = 0.001;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        if(randomAge) {
            foodLevel = rand.nextInt(getMaxHunger());
        }
        else {
            foodLevel = getMaxHunger();
        }
    }


    /**
     * This is what the animal does most of the time: it hunts for
     * food. In the process, it might breed,
     * die of hunger, or die of old age. Can also catch disease.
     * @param newAnimals A list to return newly born animals.
     */
    public void act(List<Actor> newAnimals)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(rand.nextDouble() <= INFECTION_PROBABILITY){ infect(); }
            else if(nextToMate() && isFemale()) {
                giveBirth(newAnimals);
            }
            else{move();}
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if(object instanceof Actor && getDiet().contains(object.getClass())) {
                Actor prey = (Actor) object;
                if(prey.isAlive()) {
                    eat(prey);
                    prey.setDead();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Animal moves to a different location if it is empty
     */
    protected void move(){

        // Move towards a source of food if found.
        Location newLocation = findFood();
        if(newLocation == null) {
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }


    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    protected abstract double getBreedingProbability();

    protected abstract int getMaxLitterSize();

    protected abstract int getBreedingAge();

    protected abstract Actor createActor(boolean randomAge, Field field, Location location);

    protected abstract List<Class<?>> getDiet();

}
