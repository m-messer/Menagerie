import java.util.List;
import java.util.Random;

/**
 * A simple model of a Plant.
 * Plants age, breed, and die.
 *
 * @version 2021.03.01
 */

public class Plant extends Actor{
    // The age at which a plant can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a plant can live.
    private static final int MAX_AGE = 44;
    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.0615;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final int MAX_HUNGER = 40;
    // The food value of a sardine.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a plant.
    private static final int FOOD_VALUE = 4;

    /**
     * Create a new plant. A plant may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);

    }
    /**
     * This is what the plant does most of the time - it ages
     * and breeds. Plants cannot move like animals and they
     * do not need other food sources to feed from.
     * @param newPlants A list to return newly born plants.
     */
    public void act(List<Actor> newPlants){
        incrementAge();
        if(isAlive()){
            giveBirth(newPlants);
        }
    }

    /**
     * Create an instance of plant for breeding.
     * @param randomAge If true, the plant will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    protected Actor createActor(boolean randomAge, Field field, Location location) {
        return new Plant(randomAge, field, location);
    }
    public int getMaxHunger(){ return MAX_HUNGER; }

    public int getMaxAge(){ return MAX_AGE; }

    public int getMaxLitterSize() { return MAX_LITTER_SIZE; }

    public int getBreedingAge() { return BREEDING_AGE; }

    public double getBreedingProbability(){ return BREEDING_PROBABILITY; }

    public int getFoodValue(){ return FOOD_VALUE; }
}
