import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Sardine.
 * Sardines age, move, breed, and die.
 *
 * @version 2021.03.1
 */
public class Sardine extends Animal {
    // Characteristics shared by all Sardines (class variables).

    // The age at which a sardine can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a sardine can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a sardine breeding.
    private static final double BREEDING_PROBABILITY = 0.11;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The max food value.
    private static final int MAX_HUNGER = 30;
    // The food value of a sardine.
    private static final int FOOD_VALUE = 10;
    // The diet of a sardine
    private static final List<Class<?>> diet = new ArrayList<>();

    /**
     * Create a new sardine. A sardine may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the sardine will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sardine(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        diet.add(Plant.class);
    }


    /**
     * Create an instance of sardine for breeding.
     * @param randomAge If true, the sardine will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    protected Actor createActor(boolean randomAge, Field field, Location location) {
        return new Sardine(randomAge, field, location);
    }

    public int getMaxAge(){ return MAX_AGE; }

    public int getMaxHunger(){ return MAX_HUNGER; }

    public int getMaxLitterSize() { return MAX_LITTER_SIZE; }

    public int getBreedingAge() { return BREEDING_AGE; }

    public double getBreedingProbability(){ return BREEDING_PROBABILITY; }

    public int getFoodValue(){ return FOOD_VALUE; }

    public List<Class<?>> getDiet(){ return diet; }

}


