import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a Whale.
 * Whales age, move, eat salmons and sardines, and die.
 *
 * @version 2021.03.01
 */
public class Whale extends Animal {
    // Characteristics shared by all whales (class variables).

    // The age at which a whale can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a whale can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a whale breeding.
    private static final double BREEDING_PROBABILITY = 0.079;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The max food value.
    private static final int MAX_HUNGER = 50;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a whale.
    private static final int FOOD_VALUE = 0;
    // The diet of a whale.
    private static final List<Class<?>> diet = new ArrayList<>();

    /**
     * Create a whale. A whale can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the whale will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Whale(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        diet.add(Salmon.class);
        diet.add(Sardine.class);

    }


    /**
     * Create an instance of whale for breeding.
     * @param randomAge If true, the whale will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    protected Actor createActor(boolean randomAge, Field field, Location location) {
        return new Whale(randomAge, field, location);
    }

    public int getMaxAge(){ return MAX_AGE; }

    public int getMaxHunger(){ return MAX_HUNGER; }

    public int getMaxLitterSize() { return MAX_LITTER_SIZE; }

    public int getBreedingAge() { return BREEDING_AGE; }

    public double getBreedingProbability(){ return BREEDING_PROBABILITY; }

    public int getFoodValue(){ return FOOD_VALUE; }

    public List<Class<?>> getDiet(){ return diet; }
}
