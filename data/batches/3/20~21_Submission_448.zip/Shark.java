import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a Shark.
 * Sharks age, move, eat salmons and sea basses, and die.
 *
 * @version 2021.03.01
 */
public class Shark extends Animal
{
    // Characteristics shared by all sharks (class variables).

    // The age at which a shark can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a shark can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a shark breeding.
    private static final double BREEDING_PROBABILITY = 0.0834;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The max food value.
    private static final int MAX_HUNGER = 40;
    // The food value of a shark.
    private static final int FOOD_VALUE = 0;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The diet of a shark.
    private static final List<Class<?>> diet = new ArrayList<>();

    /**
     * Create a shark. A shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the shark will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shark(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        diet.add(Salmon.class);
        diet.add(SeaBass.class);
    }


    /**
     * Create an instance of shark for breeding.
     * @param randomAge If true, the shark will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    protected Actor createActor(boolean randomAge, Field field, Location location) {
        return new Shark(randomAge, field, location);
    }

    public int getMaxAge(){ return MAX_AGE; }

    public int getMaxHunger(){ return MAX_HUNGER; }

    public int getMaxLitterSize() { return MAX_LITTER_SIZE; }

    public int getBreedingAge() { return BREEDING_AGE; }

    public double getBreedingProbability(){ return BREEDING_PROBABILITY; }

    public int getFoodValue(){ return FOOD_VALUE; }

    public List<Class<?>> getDiet(){ return diet; }


}
