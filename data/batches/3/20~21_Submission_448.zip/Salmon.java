import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Salmon.
 * Salmon age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Salmon extends Animal {
    // Characteristics shared by all Salmon (class variables).

    // The age at which a salmon can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a salmon can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a salmon breeding.
    private static final double BREEDING_PROBABILITY = 0.1745;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The max food value.
    private static final int MAX_HUNGER = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a salmon.
    private static final int FOOD_VALUE = 15;
    // The diet of a salmon
    private static final List<Class<?>> diet = new ArrayList<>();


    /**
     * Create a new salmon. A salmon may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the salmon will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Salmon(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        diet.add(Plant.class);

    }

    /**
     * Create an instance of salmon for breeding.
     * @param randomAge If true, the salmon will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    protected Actor createActor(boolean randomAge, Field field, Location location) {
        return new Salmon(randomAge, field, location);
    }

    public int getMaxAge(){ return MAX_AGE; }

    public int getMaxHunger(){ return MAX_HUNGER; }

    public int getMaxLitterSize() { return MAX_LITTER_SIZE; }

    public int getBreedingAge() { return BREEDING_AGE; }

    public double getBreedingProbability(){ return BREEDING_PROBABILITY; }

    public int getFoodValue(){ return FOOD_VALUE; }

    public List<Class<?>> getDiet(){ return diet; }


}

