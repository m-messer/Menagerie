import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of living organisms.
 * Organisms can either be plants or animals.
 *
 * @version 2022.02.28
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    
    // Whether the organism is active at daytime.
    private boolean isActiveDay;
    // Whether the organism is active at nighttime.
    private boolean isActiveNight;
    // Whether the organism is active in the rain.
    private boolean isActiveRain;
    // Whether the organism is active in the fog.
    private boolean isActiveFog;
    // Whether the organism is active in the storm.
    private boolean isActiveStorm;
    // The food value of the organism.
    // (how much food level would be filled if the organism was eaten)
    private int foodValue;
    
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this organism age incrementally.
     */
    abstract public void incrementAge();
    
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born organisms.
     */
    abstract public void act(List<Organism> newOrganisms);
    
    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Set the organism's field.
     * @return The organism's field.
     */
    protected void setField(Field field) 
    {
        this.field = field;
    }
    
    /**
     * Sets the food values of the organism.
     * @param The food value of the organism.
     */
    protected void setFoodValue(int foodValue)
    {
        this.foodValue = foodValue;
    }
    
    /**
     * Returns the food value of the organism.
     * @return The food value of the organism.
     */
    protected int getFoodValue()
    {
        return foodValue;
    }
    
    /**
     * Set the organism to be alive.
     * @param The organism's state of living.
     */
    protected void setAlive(boolean alive) 
    {
        this.alive = alive;
    }
    
    /**
     * Sets the organism to be active at day.
     */
    protected void setActiveDay()
    {
        isActiveDay = true;
    }
    
    /**
     * Sets the organism to be active at night.
     */
    protected void setActiveNight()
    {
        isActiveNight = true;
    }
    
    /**
     * Sets the organism to be active in the rain.
     */
    protected void setActiveRain()
    {
        isActiveRain = true;
    }
    
    /**
     * Sets the organism to be active in the fog.
     */
    protected void setActiveFog()
    {
        isActiveFog = true;
    }
    
    /**
     * Sets the organism to be active in the storm.
     */
    protected void setActiveStorm()
    {
        isActiveStorm = true;
    }
    
    /**
     * Returns whether the organism is active at day.
     * @return The boolean value of whether the animal is active at day.
     */
    protected boolean getActiveDay()
    {
        return isActiveDay;
    }
    
    /**
     * Returns whether the organism is active at night.
     * @return The boolean value of whether the animal is active at night.
     */
    protected boolean getActiveNight()
    {
        return isActiveNight;
    }
        
    /**
     * Returns whether the organism is active in the rain.
     * @return The boolean value of whether the animal is active in the rain.
     */
    protected boolean getActiveRain()
    {
        return isActiveRain;
    }
        
    /**
     * Returns whether the organism is active at fog.
     * @return The boolean value of whether the animal is active in the fog.
     */
    protected boolean getActiveFog()
    {
        return isActiveFog;
    }
        
    /**
     * Returns whether the organism is active at storm.
     * @return The boolean value of whether the animal is active in the storm.
     */
    protected boolean getActiveStorm()
    {
        return isActiveStorm;
    }
}
