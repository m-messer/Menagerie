
/**
 * This class keeps track of the disease spread of the simulation.
 *
 * @version 22.02.28
 */
public class Disease
{
    // Probability of disease spread.
    private static double SPREADING_PROBABILITY = 0.01;
    // Probability of recovering from disease.
    private static double RECOVERY_PROBABILITY = 0.3;

    /**
     * Constructor for objects of class Disease
     */
    public Disease()
    {
    }

    /**
     * Return the spreading probability.
     *
     * @return the probability of disease spread.
     */
    public double getSpreadingProbability()
    {
        return SPREADING_PROBABILITY;
    }
    
    /**
     * Return the recovery probability.
     *
     * @return the probability of recovering from disease.
     */
    public double getRecoveryProbability()
    {
        return RECOVERY_PROBABILITY;
    }

}
