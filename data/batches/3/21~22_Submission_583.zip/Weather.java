import java.util.Random;

/**
 * This class keeps track of the weather status of the simulation.
 * This includes a display string that mentions the weather throughout the simulation.
 *
 * @version 2022.02.22
 */
public class Weather
{
    // The probability that rain will be created in any given time.
    private static final double RAIN_CREATION_PROBABILITY = 0.20;
    // The probability that fog will be created in any given time.
    private static final double FOG_CREATION_PROBABILITY = 0.10;
    // The probability that thunderstorm will be created in any given time.
    private static final double STORM_CREATION_PROBABILITY = 0.05;
    
    // The current weather displayed in the simulation.
    private String displayWeather;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        // Weather is initialised to clear.
        displayWeather = "Clear";
    }

    /**
     * Generate a string regarding the current status for weather.
     * 
     * @return The weather status.
     */
    public String showWeather()
    {
        return displayWeather;
    }
    
    /**
     * Create a possibility of changing the weather status.
     * 
     * @param The total number of steps in the simulation.
     */
    public void changeWeather(int step)
    {
        Random rand = Randomizer.getRandom();
        
        // Creates a possibility of changing the weather every 25 steps.
        if (step % 25 == 0) {
            if (rand.nextDouble() <= RAIN_CREATION_PROBABILITY) {
                displayWeather = "Rain";
            }
            else if (rand.nextDouble() <= FOG_CREATION_PROBABILITY) {
                displayWeather = "Foggy";
            }
            else if (rand.nextDouble() <= STORM_CREATION_PROBABILITY) {
                displayWeather = "Thunderstorm";
            }
            else {
                displayWeather = "Clear";
            }
        }
    }
}
