import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A predator-prey simulator, based on a rectangular field
 * containing various animals and multiple external events.
 * 
 * Animals include rabbits, mice, foxes, snakes and owls.
 *
 * @version 2022.02.28
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.01;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.05;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.01;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.063;
    // The probability that an owl will be created in any given grid position.
    private static final double OWL_CREATION_PROBABILITY = 0.01;
    // The probability that a plant will be created in any given grid position.  
    private static final double PLANT_CREATION_PROBABILITY = 0.1;
    // The probability that an organism is infected with disease.
    private static final double INFECTION_PROBABILITY = 0.001;

    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The current time of the simulation.
    private Time time;  
    // The current weather of the simulation.
    private Weather weather;
    // The existence of disease.
    private Disease disease;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);
        time = new Time();
        weather = new Weather();
        disease = new Disease();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.BLUE);
        view.setColor(Fox.class, Color.ORANGE);
        view.setColor(Snake.class, Color.RED);
        view.setColor(Mouse.class, Color.CYAN);
        view.setColor(Owl.class, Color.PINK);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     */
    public void simulateOneStep()
    {
        step++;
        // Update the time of day.
        time.updateTimeStatus(step);
        // Update the weather status.
        weather.changeWeather(step);
        // Sets the time of day;   
        boolean isDay = time.getIsDay();
        
        Random rand = Randomizer.getRandom();
        
        // Creates probability for disease.
        double spread = disease.getSpreadingProbability(); 
        // Creates probability for an animal to recover from disease.
        double recover = disease.getRecoveryProbability();

        // Provide space for newborn animals.
        List<Organism> newOrganisms = new ArrayList<>();  

        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            // Determines behaviour of organisms that are active in the morning.
            if (isDay && organism.getActiveDay()) {
                // Determines behaviour of organisms that are active in the rain.
                if ("Rain".equals(weather.showWeather()) && organism.getActiveRain()) {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                        // Plant grows faster in rain
                        if (organism instanceof Plant) {    
                            organism.incrementAge();
                        }
                    }
                }
                // Determines behaviour of organisms that are active in the fog.
                else if ("Fog".equals(weather.showWeather()) && organism.getActiveFog()) {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                    }
                }
                // Determines behaviour of organisms that are active in the storm.
                else if ("Storm".equals(weather.showWeather()) && organism.getActiveStorm()) {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                        // Plant grows faster in storm
                        if (organism instanceof Plant) {    
                            organism.incrementAge();
                        }
                    }
                }
                // Behaviour for clear weather.
                else {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                    }
                }
            }
            // Determines behaviour of organisms that are active in the night.
            else if (!isDay && organism.getActiveNight()) {
                // Determines behaviour of organisms that are active in the rain.
                if ("Rain".equals(weather.showWeather()) && organism.getActiveRain()) {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                    }
                }
                // Determines behaviour of organisms that are active in the fog.
                else if ("Fog".equals(weather.showWeather()) && organism.getActiveFog()) {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                    }
                }
                // Determines behaviour of organisms that are active in the storm.
                else if ("Storm".equals(weather.showWeather()) && organism.getActiveStorm()) {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                    }
                    else {
                        organism.act(newOrganisms);
                        if(! organism.isAlive()) {
                            it.remove();
                        }
                    }
                }
                // Behaviour for clear weather.
                else {
                    organism.act(newOrganisms);
                    if(! organism.isAlive()) {
                        it.remove();
                    }
                }
            }
            // Animals age once per step if they are not active.
            else {
                if (organism instanceof Animal) {    
                    organism.incrementAge();
                }
            }
            // Creates a random chance of an animal being infected with disease.
            if (organism instanceof Animal) {
                Animal animal = (Animal) organism;
                if (rand.nextDouble() <= INFECTION_PROBABILITY) {
                    if (organism instanceof Animal) {
                        animal.infect();
                    }
                }
                // Creates a random chance of an animal recovering from disease.
                if (animal.getIsInfected()) {
                    if (rand.nextDouble() <= recover) {
                        animal.recover();
                    }
                    // When infected with disease, animals get twice the hunger.
                    animal.incrementHunger();
                    animal.incrementHunger();
                }
            }
        }

        // Add the newly born animals to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, time, weather, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, time, weather, field);
    }
    
    /**
     * Randomly populate the field with various animals.
     * Animals include rabbits, mice, foxes, snakes and owls.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    organisms.add(plant);
                }
                else if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    organisms.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    organisms.add(rabbit);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    organisms.add(snake);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    organisms.add(mouse);
                }
                else if(rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    organisms.add(owl);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
