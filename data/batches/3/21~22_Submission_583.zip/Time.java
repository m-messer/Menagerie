
/**
 * This class keeps track of the time of day of the simulation.
 * This includes a display string that mentions the time of day after a set 
 * amount of steps, as well as the current time in 24h time.
 *
 * @version 2022.02.18
 */
public class Time
{
    // The default number of steps that represent a day in the simulation.
    private static final int stepsPerDay = 10;
    
    // The current time of day displayed in the simulation.
    private String displayTime;
    // Whether the simulation is running in the day or night.
    private boolean isDay;
    // The integer number of the current time.
    private int currentStep;
    // The integer value of the currrent hour.
    private int hours;
    // The integer value of the current minute.
    private int minutes;
    
    /**
     * Construct a Time object.
     */
    public Time()
    {
        // Time is initialised to begin in the morning.
        displayTime = "Day";
        isDay = true;
    }

    /**
     * Checks if the time of day has changed and updates the status for time.
     *
     * @param step the current step of the simulation.
     */
    public void updateTimeStatus(int step)
    {
        currentStep = step;
        if (step % stepsPerDay == 0){
            switchTime(displayTime);
        }
    }
    
    /**
     * Returns the time in 24h time, day is 07:00 to 19:00 while 
     * the other half is night
     * @return the time in 24h time
     */
    public String getTime()
    {
        // Calculates the current time
        int timeMath = currentStep % (stepsPerDay * 2);
        int hoursMath = ((12 * 60) / stepsPerDay) / 60;
        int minutesMath = ((12 * 60) / stepsPerDay) % 60;
        // Initialises the clock
        hours = 7;
        minutes = 0;
        // The default display time
        String hoursTime = "07";
        String minutesTime = "00";
        // Extra variable to keep any carryovers
        int carryOverMinutes = 0;
        
        // Calculates the hours and minutes
        hours = hours + timeMath * hoursMath;
        minutes = minutes + timeMath * minutesMath;
        // Deals with the minutes and hours going over 60 and 24 respectively
        if (minutes >= 60) {
            carryOverMinutes = minutes / 60;
            minutes = minutes % 60;
            hours = hours + carryOverMinutes;
        }
        if (hours >= 24) {
            hours = hours % 24;
        }
        // The changes the display time
        if (hours < 10) {
            hoursTime = "0" + hours;
        }
        else{
            hoursTime = "" + hours;
        }
        if (minutes < 10) {
            minutesTime = "0" + minutes;
        }
        else {
            minutesTime = "" + minutes;
        }
        
        return hoursTime + ":" + minutesTime;        
    }
    
    /**
     * Switches the status of time between day and night.
     *
     * @param time the current state of day.
     */
    private void switchTime(String time)
    {   
        isDay = !isDay;
        if (time.equals("Day")){
            displayTime = "Night";
        }
        else if (time.equals("Night")){
            displayTime = "Day";
        }
    }
    
    /**
     * The status of time is either day or night.
     *
     * @return true if the current status for the time is morning.
     */
    public boolean getIsDay()
    {
        return isDay;
    }
    
    /**
     * Generate a string regarding the current status for time.
     *
     * @return Day or Night.
     */
    public String showTime()
    {   
        return displayTime;
    }
    
    /**
     * Generate the number of steps required to change the state of day.
     *
     * @return The number of steps per day.
     */
    public int getStepsPerDay()
    {   
        return stepsPerDay;
    }
}
