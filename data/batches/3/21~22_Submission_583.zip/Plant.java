import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2022.02.22
 */
public class Plant extends Organism
{
    // Characteristics shared by all plants (class variables).
    
    // The age to which a plant can live.
    private static final int MAX_AGE = 200;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The likelihood of a plant propagating.
    private static final double PROPAGATION_PROBABILITY = 0.05;
    // The maximum number of seeds released.
    private static final int MAX_SEED_COUNT = 3;
    // The age to which a plant can live.
    private static final int PROCREATING_AGE = 30;

    // Individual characteristics (instance fields).
    
    // The plant's age.
    private int age;
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        super.setActiveDay();
        super.setActiveRain();
        super.setActiveStorm();
        super.setAlive(true);
        super.setField(field);
        super.setLocation(location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
        calculateFoodValue(age);
    }
      
    /**
     * This is what the plant does most of the time: it propagates
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly grown plants.
     */
    public void act(List<Organism> newPlants)
    {
        incrementAge();
        if(isAlive()) {
            propagate(newPlants);            
        }
    }
    
    /**
     * This is whether the plant is active at day.
     * @return The boolean value whether the fox is active at daytime,
     */
    public boolean getActiveDay()
    {
        return super.getActiveDay();
    }
    
    /**
     * This is whether the plant is active at night.
     * @return The boolean value whether the fox is active at nighttime.
     */
    public boolean getActiveNight()
    {
        return super.getActiveNight();
    }
    
    /**
     * Increase the age. This could result in the plant's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
        calculateFoodValue(age);
    }
    
    /**
     * The plant is eaten by prey and loses it's food value each time.
     * Remove the plant from the field.
     */
    public void gotEaten()
    {
        super.setFoodValue(super.getFoodValue());
        if (super.getFoodValue() < 1) {
            setDead();
        }
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    public Field getField()
    {
        return super.getField();
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation()
    {
        return super.getLocation();
    }
    
    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isAlive()
    {
        return super.isAlive();
    }
    
    /**
     * Return the plant's food value.
     * @return The plant's food value.
     */
    public int getFoodValue()
    {
        return super.getFoodValue();
    }
    
        
    /**
     * Check whether or not this plant is to propagate at this step.
     * New plants will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     */
    private void propagate(List<Organism> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = procreate();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant == null) {
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    Plant young = new Plant(false, field, loc);
                    newPlants.add(young);
                }
            }
        }
    }
    
            
    /**
     * Generate a number representing the number of seeds,
     * if it can procreate.
     * @return The number of seeds (may be zero).
     */
    private int procreate()
    {
        int seeds = 0;
        if(canProcreate() && rand.nextDouble() <= PROPAGATION_PROBABILITY) {
            seeds = rand.nextInt(MAX_SEED_COUNT) + 1;
        }
        return seeds;
    }
    
    /**
     * A plant can procreate if it has reached the breeding age.
     * @return true if the plant can procreate, false otherwise.
     */
    private boolean canProcreate()
    {
        return age >= PROCREATING_AGE;
    }
    
    /**
     * A plant dies and is removed from the field.
     */
    public void setDead() 
    {
        super.setAlive(false);
        Field field = super.getField();
        Location location = super.getLocation();
        if(super.getLocation() != null) {
            super.getField().clear(super.getLocation());
            super.setLocation(null);
            super.setField(null);
        }
    }
    
    /**
     * Calculate a plant's food value.
     */
    private void calculateFoodValue(int age)
    {
        super.setFoodValue(1 + age / 25);
    }
    
}
