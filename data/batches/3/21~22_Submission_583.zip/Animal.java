import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.02.22
 */
public abstract class Animal extends Organism
{
    // The animal's sex. 
    private boolean isMale;
    // The probability of each sex.
    private double maleProbability = 0.5;
    // Randomizer for the animal's sex.
    private Random rand = Randomizer.getRandom();
    
    // Whether the animal is active at daytime.
    private boolean isActiveDay;
    // Whether the animal is active at nighttime.
    private boolean isActiveNight;
    // Whether the animal is infected.
    private boolean isInfected;
    // The disease.
    private Disease disease;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        super.setAlive(true);
        super.setField(field);
        super.setLocation(location);
        
        isMale = rand.nextDouble() <= maleProbability;
        isInfected = false;
    }
    
    /**
     * Increments the animal's hunger.
     */
    abstract public void incrementHunger();
    
    /**
     * Spread disease to adjacent animals.
     * @param spreadingProbability Probability of disease spread.
     */
    public void spreadDisease(double spreadingProbability)
    {
        // Get a list of adjacent organisms.
        Field field = getField();
        if(field == null) {
            return;
        }
        List<Location> adjacent = field.adjacentLocations(getLocation());
        
        // Get a chance of an infected organism spread disease to an adjacent organism.
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Animal) {
                Animal animal = (Animal) organism;
                if(rand.nextDouble() <= spreadingProbability) {
                    animal.infect();
                }
            }
        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return super.isAlive();
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        super.setAlive(false);
        Field field = super.getField();
        Location location = super.getLocation();
        if(super.getLocation() != null) {
            super.getField().clear(super.getLocation());
            super.setLocation(null);
            super.setField(null);
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return super.getLocation();
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return super.getField();
    }
    
    /**
     * Return the probability of a male.
     * @return The probability of a male
     */
    protected double getMaleProbability()
    {
        return maleProbability;
    }
    
    /**
     * Return whether the animal is a male.
     * @return The boolean value if the animal is a male.
     */
    protected boolean getIsMale()
    {
        return isMale;
    }
        
    /**
     * Whether the animal is infected or not.
     * @return Whether the animal is infected or not.
     */
    protected boolean getIsInfected()
    {
        return isInfected;
    }
    
    /**
     * Infects the animal with disease.
     */
    protected void infect()
    {
        isInfected = true;
    }
    
    /**
     * The animal recovers from disease.
     */
    protected void recover()
    {
        isInfected = false;
    }
    
    /**
     * Creates the probability of disease spread.
     * @return The probability of disease spread.
     */
    protected double spreadingProbability()
    {
        disease = new Disease();
        return disease.getSpreadingProbability();
    }
}
