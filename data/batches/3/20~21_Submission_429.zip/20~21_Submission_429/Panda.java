import java.util.*;
/**
 * A simple model of a panda
 * Pandas age, move, eat voles, and die.
 *
 * @version 02/03/2021
 */
public class Panda extends Animal
{
  private static final int BREEDING_AGE=8;
  private static final int MAX_AGE=130;
  private static final Random rand=Randomizer.getRandom();
  private static final int MAX_LITTER_SIZE=4;
  private static final double BREEDING_PROBABILITY=0.32;
  private static final int BAMBOO_FOOD_VALUE = 10;
  //set the hunger limit
  private static final int HUNGER_LIMIT = 85;
  private Weather season;
  
  // The Animal's food level counter
  public int foodLevel;
    
  public Panda(Field field,Location location)
  {
	  super(field,location);
	  season=new Weather();
	  foodLevel = 20;
  }
  
  public void act(List<Animal> newPandas)
  {
      incrementAge(MAX_AGE);
      decrementHunger(foodLevel);
      if(isAlive() && getField().dayStatus())
      {
          findFood();
          findMate(newPandas);
          manageDisease();//Panda has chance of getting disease
      }
      else if(isAlive() && !getField().dayStatus())
      {
          findMate(newPandas);
          findFood();
          manageDisease();//Panda has chance of getting disease
      }
  }
  
  private void giveBirth(List<Animal> newPandas)
  {
	  Field field=getField();
	  List<Location> free=field.getFreeAdjacentLocations(getLocation());
	  int births=breed();
	  for(int b=0;b<births && free.size()>0;b++)
	  {
		  Location loc=free.remove(0);
		  Panda young=new Panda(field,loc);
		  newPandas.add(young);
	  }
  }
  
  private int breed()
  {
	  int births=0;
	  if(canBreed() && rand.nextDouble()<=BREEDING_PROBABILITY)
	  {
		  births=rand.nextInt(MAX_LITTER_SIZE)+1;
	  }
	  return births;
  }
  
  private boolean canBreed()
  {
	  return getAge()>=BREEDING_AGE;
  }
  
  protected Location findFood()
  {
	  Field field=getField();
	  List<Location> adjacent=field.adjacentLocations(getLocation());
	  Iterator<Location> it=adjacent.iterator();
	  while(it.hasNext())
	  {
		  Location where=it.next();
		  Object plant=field.getObjectAt(where);
		  if(plant instanceof BambooPlant)
		  {
		      BambooPlant bplant=(BambooPlant) plant;
		      if(bplant.isAlive())
		      {
		          bplant.setDead();
		          eat(BAMBOO_FOOD_VALUE,HUNGER_LIMIT,foodLevel);
		          return where;
		      }
		  }
	  }
	  return null;
  }
  
  private void findMate(List<Animal> newPandas)
  {
      Field field = getField();
      List<Location> adjacent = field.adjacentLocations(getLocation());
      Iterator<Location> it = adjacent.iterator();
      while(it.hasNext()) {
          Location where = it.next();
          Object animal = field.getObjectAt(where);
          if(animal instanceof Panda && Simulator.getSeason()==season.getEnumByIndex(0)) {
              Panda panda = (Panda) animal;
              catchDisease();
              if (panda.animalsSex() != this.animalsSex()){
                  giveBirth(newPandas);
                  return;
              }
          }
      }
  }
}