import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a frog
 * Frogs age, move, eat voles, and die.
 *
 * @version 02/03/2021
 */
public class Frog extends Predator
{
    // Characteristics shared by all frogs (class variables).

    // The age at which a frog can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a frog can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a frog breeding.
    private static final double BREEDING_PROBABILITY = 0.52;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //set the hunger limit
    private static final int HUNGER_LIMIT = 20;
    // The food value of a single frog. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int CRICKET_FOOD_VALUE = 5;
    
    // Individual characteristics (instance fields)
    // The Animal's food level counter
    public int foodLevel;
    
    /**
     * Create a new Frog. A frog may be created with age
     * zero (a new born)
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog(Field field, Location location)
    {
        super(field, location,MAX_AGE,HUNGER_LIMIT);
        foodLevel = 50;
    }
    
    
    /**
     * This is what the Frog does most of the time
     * @param newFrog A list to return newly born frogs.
     */
    public void act(List<Animal> newFrog)
    {
        incrementAge(MAX_AGE);
        decrementHunger(foodLevel);
        if(isAlive() && getField().dayStatus())//don't move during the day
        {
            manageDisease();//Frog has chance of getting disease
            // Frog doesn't move during the day
        }
        else if(isAlive() && !getField().dayStatus())//act at night
        {
            // Becomes active at night
            hunt();
            findMate(newFrog);
            manageDisease();//Frog has chance of getting disease
        }
    }
    
    /**
     * Look for frogs adjacent to the current location.
     * Only the first live frog is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location hunt()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cricket) {
                Cricket cricket = (Cricket) animal;
                if(cricket.isAlive()) { 
                    cricket.setDead();
                    eat(CRICKET_FOOD_VALUE, HUNGER_LIMIT, foodLevel);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * The animal will look for any foxes next to its location
     * If a fox is found it will mate with it only if it's of the opposite sex.
     */
    private void findMate(List<Animal> newFrog)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                catchDisease();
                if (frog.animalsSex() != this.animalsSex()){
                    giveBirth(newFrog);
                    return;
                }
            }
        }
    }
    
    /**
     * Check whether or not this frog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newfrogs A list to return newly born frogs.
     */
    private void giveBirth(List<Animal> newFrog)
    {
        // New frogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Frog young = new Frog(field, loc);
            newFrog.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A frog can breed if it has reached the breeding age.
     * @return true if the frog can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
