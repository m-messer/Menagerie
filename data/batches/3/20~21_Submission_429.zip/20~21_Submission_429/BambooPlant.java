import java.util.Random;
import java.util.List;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * This class provides the methods for a Bamboo plant to grow and spread based on seasons
 *
 * @version 02/03/2021
 */
public class BambooPlant extends Plant
{
    // The height to which a Bamboo plant can grow
    private static final double MAX_HEIGHT=8;
    // The age where a Bamboo plant can start producing seeds
    private static final int SEED_PRODUCING_AGE=4;
    // The age to which a Bamboo plant can live
    private static final int MAX_AGE=100;
    // The set probability that a Bamboo plant produces seeds
    private static final double SEED_PRODUCING_PROBABILITY=0.25;
    // The number of seeds a Bamboo plant can produce
    private static final int MAX_SEEDS=6;
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();
    // A variable to hold the current height of the Bamboo Plant
    private double height;
    // A variable to hold the current level of water the Bamboo Plant has
    private int waterLevel;
    
    //lets plant keep track of seasons
    private static Weather season;
    
    /**
     * Sets an instance of a Bamboo plant.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public BambooPlant(Field field,Location location)
    {
        super(field,location);
        height=1;
        waterLevel = 8;
    }
    
    /**
     * Allows the plant to grow, age and spread based on season.
     * @param takes the current Bamboo from the list of plants.
     */
    public void act(List<Plant> newBamboo)
    {
        increaseHeight(MAX_HEIGHT);
        incrementAge(MAX_AGE);
        if (isAlive() && Simulator.getSeason() == Weather.Season.Spring)//Spring
        {
            getWaterAndNutrients(waterLevel);
            increaseHeight(MAX_HEIGHT);//start growing
            spread(newBamboo);
        }
        else if(isAlive() && Simulator.getSeason()== Weather.Season.Summer)//Summer
        {
            getWaterAndNutrients(waterLevel);
            increaseHeight(MAX_HEIGHT);//grow
        }
        else if(isAlive() && Simulator.getSeason()== Weather.Season.Autumn)//Autumn
        {
            decrementWaterLevel(waterLevel);
            spread(newBamboo);
        }
        else if(isAlive() && Simulator.getSeason()== Weather.Season.Winter)//Winter
        {
            decrementWaterLevel(waterLevel);
        }
    }
    
    /**
     * This method lets a plant spread it's seeds.
     * @param takes the current Bamboo from the list of plants.
     */
    public void spread(List<Plant> newBamboo)
    {
        Field field=getField();
        List<Location> free=field.getFreeAdjacentLocations(getLocation());
        int births=breed();
        for(int b=0;b<births && free.size()>0;b++)
        {
            Location loc=free.remove(0);
            BambooPlant bambooChute=new BambooPlant(field,loc);
            newBamboo.add(bambooChute);
        }   
    }
    
    /**
     * This method lets a plant breed using its seed producing probability.
     * @return the number of births to be made
     */
    private int breed()
    {
      int births=0;
      if(canBreed() && rand.nextDouble()<=SEED_PRODUCING_PROBABILITY)
      {
          births=rand.nextInt(MAX_SEEDS)+1;
      }
      return births;
    }
    
    /**
     * This method checks if the plant is able to breed at its current age
     * @return true if the current age is older or equal to the producing age
     */
    private boolean canBreed()
    {
        return getAge()>=SEED_PRODUCING_AGE;
    }
}