import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a hawk.
 * Hawkes age, move, eat rabbits, and die.
 *
 * @version 02/03/2021
 */
public class Hawk extends Predator
{
    // Characteristics shared by all hawkes (class variables).
    
    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a hawk can live.
    private static final int MAX_AGE = 56;
    // The likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single Frog
    private static final int FROG_FOOD_VALUE = 5;
    // The food value of a single Vole
    private static final int VOLE_FOOD_VALUE = 10;
    //set the hunger limit
    private static final int HUNGER_LIMIT = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The Animal's food level counter
    public int foodLevel;

    /**
     * Create a hawk. A hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hawk(Field field, Location location)
    {
        super(field, location,MAX_AGE,HUNGER_LIMIT);
        foodLevel = 30;
    }
    
    /**
     * This is what the hawk does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * die of old age or disease.
     * @param newhawkes A list to return newly born hawkes.
     */
    public void act(List<Animal> newHawk)
    {
        incrementAge(MAX_AGE);
        decrementHunger(foodLevel);
        if(isAlive() && getField().dayStatus()) {
            findMate(newHawk);
            hunt();
            manageDisease();//Hawk has chance of getting disease
            //hawk doesn't move at night
        }
        else if(isAlive() && !getField().dayStatus()) {
            manageDisease();//Hawk has chance of getting disease
        }
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live vole or frog is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location hunt()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Vole) {
                Vole vole = (Vole) animal;
                if(vole.isAlive()) { 
                    vole.setDead();
                    eat(VOLE_FOOD_VALUE, HUNGER_LIMIT,foodLevel);
                    return where;
                }
            }
            else if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isAlive()) { 
                    frog.setDead();
                    eat(FROG_FOOD_VALUE, HUNGER_LIMIT,foodLevel);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * The animal will look for any hawkes next to its location
     * If a hawk is found it will mate with it only if it's of the opposite sex.
     */
    private void findMate(List<Animal> newHawk)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hawk) {
                Hawk hawk = (Hawk) animal;
                catchDisease();
                if (hawk.animalsSex() != this.animalsSex()){
                    giveBirth(newHawk);
                    return;
                }
            }
        }
    }
    
    /**
     * Check whether or not this hawk is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newhawkes A list to return newly born hawkes.
     */
    private void giveBirth(List<Animal> newHawk)
    {
        // New hawkes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hawk young = new Hawk(field, loc);
            newHawk.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hawk can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
