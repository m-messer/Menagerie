import java.util.*;

/**
 * A simple predator-prey simulator, based on a rectangular field this class controls the weather withi the simulator
 *
 * @version 02/03/2021
 */
public class Weather
{
   
    /**
     * Use enum to determine season.
     */
    public enum Season
   {
	 Spring,Summer,Autumn,Winter
   }
   
   public Season currentSeason;
   
   /**
     * Sets the weather for the simulation
     * @param the current season.
     */
   public void setWeather(Season season)
   {
	   setSeason(season);
   }
   
   /**
     * Sets the season based of the cases
     * @param the current season.
     */
   public void setSeason(Season season)
   {
	   switch(season)
	   {
	       case Spring:
	       currentSeason=Season.Spring;
	       case Summer:
	       currentSeason=Season.Summer;
	       case Autumn:
	       currentSeason=Season.Autumn;
	       case Winter:
		  currentSeason=Season.Winter;
	   }
   }
   
   /**
     * gets the current season
     */
   public Season getSeason()
   {
	   return currentSeason;
   }
   
   /**
     * returns the season value by index
     * @return the season by index value.
     */
   public Season getEnumByIndex(int index)
   {
       return Season.values()[index];
   }
}