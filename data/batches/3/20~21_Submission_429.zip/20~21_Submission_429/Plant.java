import java.util.*;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2021.02.22
 */
public abstract class Plant 
{
    private static final Random rand=Randomizer.getRandom();
    
    // Whether the animal is alive or not.
    private boolean alive;
    // The plant's position on the field.
    private Location location;
    // The field occupied
    private Field field;
    //set the animal's age
    private int age;
    
    private double height;
    
    //The height to which a plant can grow
    private static final int MAX_HEIGHT=100;
    //The age to which a Bamboo plant can live
    private static final int MAX_AGE=100;
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field,Location location)
    {
    	alive = true;
    	height= 1.0;
    	age=0;
    	this.field=field;
    	setLocation(location);
    }
    
    /**
     * Returns whether or not the animal is alive.
     */
    protected boolean isAlive()
    {
    	return alive;
    }
    
    /**
     * Sets the animal as dead and deletes it from the field.
     */
    protected void setDead()
    {
        alive=false;
    	if(location!=null)
    	{
    	    field.clear(location);
    	    location=null;
    	    field=null;
    	}
    }
    
    /**
     * Increments the animal's age till it dies
     */
    protected void incrementAge(int maxAge)
    {
    	age++;
    	if(age>maxAge) {
    	    setDead();
    	}
    }
    
    /**
     * Returns the animal's current age
     * @return the animal's age
     */
    protected int getAge()
    {
    	return age;
    }
    
    /**
     * get the plant's location
     * @return The animal's location.
     */
    protected Location getLocation()
    {
    	return location;
    }
    
    /**
     * Increase the animal's height.
     * @param maxHeight The tallest a plant can grow.
     */
    protected void increaseHeight(double maxHeight)
    {
    	height++;
    	if(height>maxHeight)
    	{
    	    height=maxHeight;
    	}
    }
    
    /**
     * Gets plant's height.
     * @return height of plant.
     */
    protected double getHeight()
    {
    	return height;
    }
    
    
    /**
     * Chooses a new location for a new plant.
     * @param newLocation The location where the new plant will grow.
     */
    private void setLocation(Location newlocation)
    {
        if(location != null) {
            field.clear(newlocation);
        }
        location = newlocation;
        field.placePlant(this, newlocation);
    }
    
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
    	return field;
    }
    
    /**
     * Reduces the level of water a plant has.
     * @param waterLevel The current level of water the plant has.
     */
    public void decrementWaterLevel(int waterLevel)
    {
    	waterLevel--;
    	if(waterLevel<=0)
    		setDead();
    }
    
    /**
     * Gets the water and Nutrients for the plant
     * in turn increasing water levels.
     * @param waterLevel The current level of water the plant has.
     */
    public void getWaterAndNutrients(int waterLevel)
    {
    	waterLevel++;
    }
    
    abstract public void act(List<Plant> newPlants);
}