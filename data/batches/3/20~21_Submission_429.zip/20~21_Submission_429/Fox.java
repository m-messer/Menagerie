import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a fox.
 * Foxes age, move, eat voles, and die.
 *
 * @version 02/03/2021
 */
public class Fox extends Predator
{
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a fox can live.
    private static final int MAX_AGE = 55;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.28;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single vole
    private static final int VOLE_FOOD_VALUE = 5;
    // The food value of a single vole
    private static final int FROG_FOOD_VALUE = 10;
    //set the hunger limit
    private static final int HUNGER_LIMIT = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The Animal's food level counter
    public int foodLevel;

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(Field field, Location location)
    {
        super(field, location,MAX_AGE,HUNGER_LIMIT);
        foodLevel = 20;
    }
    
    /**
     * This is what the fox does most of the time: it hunts for
     * voles. In the process, it might breed, die of hunger,
     * die of old age or disease.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Animal> newFoxes)
    {
        incrementAge(MAX_AGE);
        decrementHunger(foodLevel);
        if(isAlive() && getField().dayStatus()) {
            manageDisease();//Fox has chance of getting disease
            //Fox doesn't move at night
        }
        else if(isAlive() && !getField().dayStatus()) {
            hunt();
            findMate(newFoxes);
            manageDisease();//Fox has chance of getting disease
        }
    }
    
    /**
     * Look for voles adjacent to the current location.
     * Only the first live vole is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location hunt()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Vole) {
                Vole vole = (Vole) animal;
                if(vole.isAlive()) { 
                    vole.setDead();
                    eat(VOLE_FOOD_VALUE, HUNGER_LIMIT, foodLevel);
                    return where;
                }
            }
            else if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isAlive()) { 
                    frog.setDead();
                    eat(FROG_FOOD_VALUE, HUNGER_LIMIT, foodLevel);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * The animal will look for any foxes next to its location
     * If a fox is found it will mate with it only if it's of the opposite sex.
     */
    private void findMate(List<Animal> newFoxes)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fox) {
                Fox fox = (Fox) animal;
                catchDisease();
                if (fox.animalsSex() != this.animalsSex()){
                    giveBirth(newFoxes);
                    return;
                }
            }
        }
    }
    
    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Animal> newFoxes)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fox young = new Fox(field, loc);
            newFoxes.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     * @return true if the fox can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
