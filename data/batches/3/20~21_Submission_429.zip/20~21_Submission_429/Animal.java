import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.02.22
 */
public abstract class Animal
{
    private static final Random rand = Randomizer.getRandom();
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's position on the field.
    private Location location;
    // The field occupied
    private Field field;
    // set the sex of the animal
    private boolean sex;
    //set the animal's age
    private int age;
    
    //check if animal is infected or not
    private boolean isInfected;
    // The probability of an animal becoming infected
    private static final double PROBABILITY_OF_INFECTION = 0.0045;
    // The probability that the animal will die of the infection
    private static final double DISEASE_DEATH_PROBABILITY = 0.026;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        age = 0;
        this.field = field;
        determineSex(); //set the animal's sex
        setLocation(location);
    }
    
    /**
     * Make this animal act - eat, procreate, hunt etc
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Returns whether or not the animal is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Sets the animal as dead and deletes it from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Checks to see the current state of the animal - Male or Female
     * @return true if Female or false if Male
     */
    protected boolean animalsSex()
    {
        return sex;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * This randomly generates the animal's sex and assigns it to the sex variable
     */
    private void determineSex()
    {
        sex = rand.nextBoolean();
    }
    
    /**
     * Increments the animal's age till it dies
     */
    protected void incrementAge(int maxAge)
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }
    
    
    /**
     * Returns the animal's current age
     * @return the animal's age
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * This method increases the animal's food level till it is full
     * @param food The energy given when the animal's food is consumed
     * @param hungerCap The maxium an animal can eat
     * @param foodLevel The current level of food the animal has consumed
     */
    protected void eat(int food, int hungerCap, int foodLevel)
    {
        if (food+foodLevel > hungerCap){
            foodLevel = hungerCap;
        }
        else{
            foodLevel += food;
        }
    }
    
    /**
     * This method decrements the animal's hunger levels till it dies
     */
    protected void decrementHunger(int foodLevel)
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Returns the animal's current food level
     * @return the food level of the current animal
     */
    protected int getfoodLevel(int foodLevel)
    {
        return foodLevel;
    }
    
    /**
     * A disease management method that checks if the animal
     * is infected so it can infect others or has the potential
     * to become infected
     */
    protected void manageDisease()
    {
        if(this.isInfected())
        {
            spreadDisease();
            manageDiseaseDeath();
        }
        else
        {
            catchDisease();
        }
    }
    
    /**
     * Checks whether the animal is infected or not
     * @return True if the animal is infected
     */
    protected boolean isInfected()
    {
        return isInfected;
    }
    
    /**
     * Sets the chance of the animal having a disease 
     */
    protected void setDisease() 
    {
        if(rand.nextDouble() <= PROBABILITY_OF_INFECTION) {
            isInfected = true;
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * Sets the chance of the animal catching the disease 
     */
    protected void catchDisease() 
    {
        if(rand.nextDouble() <= PROBABILITY_OF_INFECTION) {
            infect();
        }
        else{
            isInfected = false;
        }
    }
    
    /**
     * Sets the infected boolean statement to true
     */
    protected void infect()
    {
        isInfected = true;
    }
    
    /**
     * The infected animal checks for animals next to it and
     * tries to spread the disease
     */
    protected void spreadDisease()
    {
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal proxAnimal = (Animal) animal;
                if (!proxAnimal.isInfected()) {
                    proxAnimal.catchDisease();
                }
            }
        }
    }
    
    /**
     * manages death by disease based on the death probability
     */
    protected void manageDiseaseDeath()
    {
        if(isInfected() && rand.nextDouble() <= DISEASE_DEATH_PROBABILITY)
        {
            setDead();
        }
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.placeAnimal(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
