import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Write a description of class Cricket here.
 *
 * @version 02/03/2021
 */
public class Cricket extends Prey
{
    // Characteristics shared by all crickets (class variables).

    // The age at which a cricket can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a cricket can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a cricket breeding.
    private static final double BREEDING_PROBABILITY = 0.32;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields)
    
    /**
     * Create a new Cricket
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cricket(Field field, Location location)
    {
        super(field, location,MAX_AGE);
    }
    
    
    /**
     * This is what the Cricket does most of the time - it runs 
     * around, searches for a mate or may catch and die of disease
     * @param newCricket A list to return newly born crickets.
     */
    public void act(List<Animal> newCricket)
    {
        incrementAge(MAX_AGE);
        
        if(isAlive() && getField().dayStatus())
        {
            // Cricket doesn't move during the day
            manageDisease();//cricket has chance of getting disease
        }
        else if(isAlive() && !getField().dayStatus())
        {
            // Becomes active at night
            findMate(newCricket);
            manageDisease();//cricket has chance of getting disease
            //Assume it eats grass
        }
    }
    
    
    /**
     * The animal will look for any Crickets next to its location
     * It will mate if it is of the opposite sex
     */
    private void findMate(List<Animal> newCricket)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cricket) {
                Cricket cricket = (Cricket) animal;
                if (cricket.animalsSex() != this.animalsSex()){
                    giveBirth(newCricket);
                    return;
                }
            }
        }
    }
    
    /**
     * Checks to see if the cricket will give birth
     * @param takes the current cricket from the list of animals.
     */
    private void giveBirth(List<Animal> newCricket)
    {
        // New crickets are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cricket young = new Cricket(field, loc);
            newCricket.add(young);
        }
    }
        
    /**
     * This method lets a cricket breed using its breeding probability.
     * @return the number of births to be made
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Cricket can breed if it has reached the breeding age.
     * @return true if the Cricket can breed
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
