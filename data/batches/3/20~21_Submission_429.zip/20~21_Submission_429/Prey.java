import java.util.List;
import java.util.Random;
/**
 * Write a description of class Prey here.
 *
 * @version 02/03/2021
 */
public abstract class Prey extends Animal
{
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * This instantiates our prey and determines if it has a disease or not
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The maximum age the animal can live to.
     */
    public Prey(Field field, Location location, int maxAge)
    {
        super(field, location);
        setDisease();
    }
    
    abstract public void act(List<Animal> newAnimals);
}
