import java.util.List;
import java.util.Random;

/**
 * This is an abstract class that defines a predator's habits - 
 * The predator hunts its prey, with a mate of the opposite sex and eventually dies
 *
 * @version 02/03/2021
 */
public abstract class Predator extends Animal
{
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * This instantiates our predator
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The maximum age the animal can live to.
     * @param hungerLimit The most the animal can eat.
     */
    public Predator(Field field, Location location, int maxAge, int hungerLimit)
    {
        super(field, location);
        setDisease();
    }
    
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Predator will go searching for more food if still hungry
     */
    protected abstract Location hunt();
}