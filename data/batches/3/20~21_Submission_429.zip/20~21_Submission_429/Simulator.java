import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing voles and foxes.
 *
 * @version 02/03/2021
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.034;
    // The probability that a vole will be created in any given grid position.
    private static final double VOLE_CREATION_PROBABILITY = 0.042;
    // The probability that a Cricket will be created in any given grid position.
    private static final double CRICKET_CREATION_PROBABILITY = 0.059;
    // The probability that a frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.05;
    // The probability that a frog will be created in any given grid position.
    private static final double HAWK_CREATION_PROBABILITY = 0.031;
    // The probability that a panda will be created in any given grid position.
    private static final double PANDA_CREATION_PROBABILITY=0.04;
    // The probability that Bamboo will be created in any given grid position.
    private static final double BAMBOO_CREATION_PROBABILITY=0.06;
    
    // regulate the number of steps in a day
    private static final int DAY_STEPS = 24;

    // List of animals in the field.
    private List<Animal> animals;
    
    //Keep track of the number of plants in the field
    private List<Plant> plants;
    
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    //Add seasons to the simulator
    private static Weather season;
    //Use index to keep track of season
    private static int currentIndex;
    
    
    private int day;
    private int hour;
    private String dayNightStatus;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        season = new Weather();
        season.setSeason(Weather.Season.Spring);
        currentIndex=0;
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Vole.class, Color.GRAY);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Cricket.class, Color.YELLOW);
        view.setColor(Frog.class, Color.ORANGE);
        view.setColor(Hawk.class, Color.MAGENTA);
        view.setColor(Panda.class, Color.BLACK);
        view.setColor(BambooPlant.class,Color.GREEN);
        season = new Weather();
        season.setSeason(Weather.Season.Spring);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(40000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1,i=0; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            if(step%90==0)
            {
            	i++;
                currentIndex=i%4;
            }
            season.setSeason(season.getEnumByIndex(i%4));
            delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and vole.
     */
    public void simulateOneStep()
    {
        step++;
        hour++;
        incrementDay();
        checkTime();
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant=it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        // Add the new plants to the main lists.
        plants.addAll(newPlants);
        //Update the simulator
        view.showStatus(step, field, day,dayNightStatus);
    }
    
    /**
     * Keeps count of the day based on the number of steps taken 
     * in the simulator
     */
    private void incrementDay()
    {
        int time = hour % DAY_STEPS;
        if (time == 0){
            day++;
        }
    }
    
    private void checkTime()
    {
        int time = hour % DAY_STEPS;
        if ((time >= 21 && time <= 24) || (time >=0 && time <= 5)){
            dayNightStatus = "Night";
            if (field.dayStatus()){
               field.toggleDay(); 
            }            
        }
        else if (time >= 6 && time <= 20) {
            dayNightStatus = "Day";
            if (!field.dayStatus()) {
                field.toggleDay();
            }
        } 
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        day = 1;
        dayNightStatus = "Day";
        hour = 6;
        animals.clear();
        populate();
        checkTime();
        
        // Show the starting state in the view.
        view.showStatus(step, field, day,dayNightStatus);
    }
    
    
    public static Weather.Season getSeason()
    {
    	return season.getEnumByIndex(currentIndex);
    }
    
    /**
     * Randomly populate the field with foxes and voles.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(field, location);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= VOLE_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Vole vole = new Vole(field, location);
                    animals.add(vole);
                }
                else if(rand.nextDouble() <= CRICKET_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Cricket cricket = new Cricket(field, location);
                    animals.add(cricket);
                }
                
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(field, location);
                    animals.add(frog);
                }
                else if(rand.nextDouble() <= HAWK_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(field, location);
                    animals.add(hawk);
                }
                else if(rand.nextDouble()<=PANDA_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Panda panda = new Panda(field, location);
                    animals.add(panda);
                }
                else if(rand.nextDouble()<=BAMBOO_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    BambooPlant bplant = new BambooPlant(field, location);
                    plants.add(bplant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
