import java.util.Iterator;
import java.util.Random;
import java.util.*;
/**
* A simple model of a Duck.
* Ducks age, move, breed, and die.
*
* @version 2019.02.21
*/
public class Weather
{
  //Random generator to control weather
  private static final Random rand = Randomizer.getRandom();
  // the probability will be sunny day 0.3.
  private static final double SUNNY_PROBABILITY = 0.3;
  // The max number of step that sunnt day can last.
  private static final int MAX_SUNNY_DAY = 3;
  // the probability will be sunny day 0.5.
  private static final double RAIN_PROBABILITY = 0.8;
  // The max number of step that sunnt day can last.
  private static final int MAX_RAINING_DAY = 2;
  // the probability will be sunny day 0.4.
  private static final double FOG_PROBABILITY = 1.2;
  // The max number of step that sunnt day can last.
  private static final int MAX_FOGGY_DAY = 3;
  // the probability will be sunny day .
  private static final double SNOW_PROBABILITY = 1.35;
  // The max number of step that sunnt day can last.
  private static final int MAX_SNOW_DAY = 2;


  private static String currentWeather;
  //number of steps that weather can be changed.
  private static int changeWeather = 0;
  private static List<Grass> grassarea;
  private int x1,y1,x2,y2;
  private Field field;



  /**
  * Constructor
  * Creat the weather.
  */
  public Weather(Field f, List<Grass> g){
    grassarea=g;
    field=f;
    double random=rand.nextDouble()*1.35;
    if(SUNNY_PROBABILITY >= random){
      currentWeather = "Sunny";
      changeWeather = rand.nextInt(MAX_SUNNY_DAY) + 1;
    }
    else if(RAIN_PROBABILITY >= random){
      currentWeather = "Rain";
      changeWeather = rand.nextInt(MAX_RAINING_DAY) + 1;
    }
    else if(FOG_PROBABILITY >= random){
      currentWeather = "Fog";
      changeWeather = rand.nextInt(MAX_FOGGY_DAY) + 1;
    }
    else{
      currentWeather = "Snow";
      changeWeather = rand.nextInt(MAX_SNOW_DAY) + 1;
    }
  }

  /**
   * to set the weather change.
   */
  public static void updateWeather()
  {
    if(changeWeather>0){
      //affectSpecies all of them. x1,y1  x2,y2
      /*change object in the field which is affected by curreent weather.
      for(int i=x1;i<x2;i++){
      for(int j=y1;j<y2;j++){
      affectSpecies(field.getObjectAt(i,j));
    }
  }*/
  for(Iterator<Grass> it=grassarea.iterator();it.hasNext();){
    Grass t=it.next();
    //check if the grass is in the weather area.
    affectSpecies(t);
  }
  changeWeather--;
}else{
  double random=rand.nextDouble()*1.35;
  if(SUNNY_PROBABILITY >= random){
    currentWeather = "Sunny";
    changeWeather = rand.nextInt(MAX_SUNNY_DAY) + 1;
  }
  else if(RAIN_PROBABILITY >= random){
    currentWeather = "Rain";
    changeWeather = rand.nextInt(MAX_RAINING_DAY) + 1;
  }
  else if(FOG_PROBABILITY >= random){
    currentWeather = "Fog";
    changeWeather = rand.nextInt(MAX_FOGGY_DAY) + 1;
  }
  else{
    currentWeather = "Snow";
    changeWeather = rand.nextInt(MAX_SNOW_DAY) + 1;
  }
}
}

/**
 * Act wecther to affect the grow rate of Grass.
 */
public static void affectSpecies(Species species){
  if(currentWeather.equals("Rain")){
    Rain(species);
  }
  else if(currentWeather.equals("Sunny")){
    Sunny(species);
  }
  else if(currentWeather.equals("Fog")){
    Foggy(species);
  }
  else if(currentWeather.equals("Snow")){
    Snow(species);
  }
  changeWeather--;
}

/**
 * Get weather.
 */
public static String getWeather()
{
  return currentWeather;
}

/**
 * set the value to change the growing rate of garss when raining.
 */
public static void Rain(Species species)
{
  if(species instanceof Grass){
    ((Grass)species).breedRate(1.5);
  }
}

/**
 * set the value to change the growing rate of garss when snowing.
 */
public static void Snow(Species species)
{
  if(species instanceof Grass){
    ((Grass)species).breedRate(0.6);
  }
}

/**
 * set the value to change the growing rate of garss when the weather is fog.
 */
public static void Foggy(Species species)
{
  if(species instanceof Grass){
    ((Grass)species).breedRate(1.0);
  }
}

/**
 * set the value to change the growing rate of garss when sunny.
 */
public static void Sunny(Species species)
{
  if(species instanceof Grass){
    ((Grass)species).breedRate(0.9);
  }
}

}
