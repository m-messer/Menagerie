import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2019.02.21
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a human will be created in any given grid position.
    private static final double HUMAN_CREATION_PROBABILITY = 0.072;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.035;
    // The probability that a cow will be created in any given grid position.
    private static final double COW_CREATION_PROBABILITY = 0.081;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 1.00;
    // The probability that a zombie will be created in any given grid position.
    private static final double ZOMBIE_CREATION_PROBABILITY = 0.003;
    private static final double DUCK_CREATION_PROBABILITY = 0.042;

    //public static String debug;

    // List of animals in the field.
    private List<Species> species;
    private List<Grass> grassarea;
    private Weather cweather;
    // The current state of the field.
    private int grassx1;
    private int grassy1;
    private int grassx2;
    private int grassy2;

    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    private boolean stop;
    //check the time is day or night.
    private boolean isDay;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        species = new ArrayList<>();
        grassx1=0;
        grassy1=0;
        grassx2=DEFAULT_DEPTH;
        grassy2=DEFAULT_WIDTH;
        field = new Field(depth, width);
        grassarea = new ArrayList<Grass>((grassx2-grassx1)*(grassy2-grassy1));
        cweather=new Weather(field,grassarea);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Human.class, Color.ORANGE);
        view.setColor(Cow.class, Color.BLUE);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Wolf.class, Color.BLACK);
        view.setColor(Zombie.class, Color.RED);
        view.setColor(Duck.class, Color.PINK);


        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(40);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        //Change the weather
        step++;
        cweather.updateWeather();
        // Provide space for newborn animals.
        List<Species> newSpeciess = new ArrayList<>();
        // Let all rabbits act.
        for(Iterator<Species> it = species.iterator(); it.hasNext(); ) {
            Species animal = it.next();
            if(isDay==false && animal.NightActive() || isDay==true )
              animal.act(newSpeciess);
            if(animal instanceof Grass){
                if(((Grass)animal).finishedGrow()) it.remove();
            }
            else if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born species to the main lists.
        //udpate grass area and add new grass to plants.
        updategrass();
        species.addAll(newSpeciess);
        isDay();
        showWeather();

        view.showStatus(step, field);
    }

    /**
     * To update the grass.
     */
    private void updategrass(){
      for(Iterator<Grass> it=grassarea.iterator();it.hasNext();){
          Grass t=it.next();
          if(t.canView()){
              t.setLocation(t.getLocation());
          }
      }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        stop = false;
        species.clear();
        populate();
        showWeather();
        view.setTime(isDay);
        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        //int a=0,b=0,c=0,d=0,e=0,f=0;
        for(int i=grassx1;i<grassx2;i++){
            for(int j=grassy1;j<grassy2;j++){
                Grass young = new Grass(field,new Location(i,j));
                grassarea.add(young);
            }
        }
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if(rand.nextDouble() <= ZOMBIE_CREATION_PROBABILITY) {
                    //e++;
                    Zombie zombie = new Zombie(true, field, location);
                    species.add(zombie);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    //b++;
                    Wolf wolf = new Wolf(true, field, location);
                    species.add(wolf);
                }
                else if(rand.nextDouble() <= HUMAN_CREATION_PROBABILITY) {
                    //a++;
                    Human human = new Human(true, field, location);
                    species.add(human);
                }
                else if(rand.nextDouble() <= COW_CREATION_PROBABILITY) {
                    //c++;
                    Cow cow = new Cow(true, field, location);
                    species.add(cow);
                }else if(rand.nextDouble() <= DUCK_CREATION_PROBABILITY) {
                    //f++;
                    Duck duck = new Duck(true, field, location);
                    species.add(duck);
                }

                // else leave the location empty.
            }
        }
        //debug="|  Intially created, Human[Org]:"+a+", Wolf[Blk]:"+b+", Cow[Blu]:"+c+", Grass[Grn]:"+(DEFAULT_DEPTH*DEFAULT_WIDTH-a-b-c-e-f)+", Zombie[R]:"+e+", Duck[CY]:"+f+" |";
        //view.debug=debug;
        //view.setInfoText(debug);

    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * To set the timetick of day and night.
     */
    public void isDay()
    {
        if (step%2 == 1) {
            isDay = false;
        }
        else {
            isDay = true;
        }
        view.setTime(isDay);
    }

    public void showWeather(){
      view.setWeather(cweather.getWeather());
    }

    /**
     * Check weather is day or night.
     */
    public boolean getDay(){
        return isDay;
    }
}
