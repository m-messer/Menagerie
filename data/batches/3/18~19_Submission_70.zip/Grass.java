import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a grass.
 * grasss age, move, breed, and die.
 *
 * @version 2019.02.21
 */
public class Grass extends Species
{
    // Characteristics shared by all grasss (class variables).

    // The likelihood of a grass breeding.
    private static double BREEDING_PROBABILITY = 0.01;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The age to which a cow can live.
    private static final int GROWING_LIMIT = 50;
    // Individual characteristics (instance fields).

    private static final boolean active=true;
    
    private int growing_age;
    //Grass can be eat or not.
    private boolean eaten;
    private double growing_rate;


    /**
     * Create a new grass. A grass may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        super(field, location,active);
        growing_age=GROWING_LIMIT;
        eaten=false;
        growing_rate=1.0;
    }

    /**
     * This is what the grass does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newgrasss A list to return newly born grasss.
     */
    public void act(List<Species> newgrass)
    {
        if(!eaten) {
          //Alive & Eatable do nothing here.
        }else{
          //Has been eaten and now is growing.
          growing_age+=(10*growing_rate);
          if(growing_age>=GROWING_LIMIT) eaten=false;
        }
    }

    public void breedRate(double r){
      growing_rate=r;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        eaten = true;
        growing_age = 0;
    }

    /**
     * To check is the grass can be viewed or not.
     */
    public boolean canView(){
        if(eaten) return false;
        else{
            Species t=(Species) getField().getObjectAt(getLocation());
            if(t==null || t instanceof Grass) return true;
        }
        return false;
    }

    /**
     * To check the garss is alive or not.
     */
    public boolean isAlive(){
      return !eaten;
    }

    /**
     * To check the grass can be eaten or not.
     */
    public boolean finishedGrow(){
        if(eaten) return false;
        else return true;
    }
}
