import java.util.Random;
/**
* A class used to generate the weather state for the simulation
*
*
* 
*/
public class Weather
{
    //Contains the weather state
    private String weather ;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        weather = weather_randomlise();
    }

    /**
     *
     * @return a string containing a randomly generated weather state
     */
    public String weather_randomlise()
    {
        Random rand = new Random();
        int randm = rand.nextInt(6)+1;
        if (randm == 1)
        {
            return "Sunny";
        }
        else if (randm == 2 ||randm == 3)
        {
            return "foggy";
        }
        else 
        {
            return "rainy";
        }
        
    }
    
     /**
     * @return a string containing weather
     */
    
    public String getWeather()
    {
        return weather;
    }
}
