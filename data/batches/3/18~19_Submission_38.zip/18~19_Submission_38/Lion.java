
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
  * A simple model of a Lion.
 * Lions age, move, breed, and die.
 * Lions are also predators, they can eat Zebras and Girraffes
 *
 * @version (12/2/2019)
 */
public class Lion extends Predators
{
    // Characteristics shared by all Lions (class variables).
    
    // The age at which a Lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Lion can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a Lion breeding.
    private static final double BREEDING_PROBABILITY = 0.50;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    //The proprtion of female lions (out of 100)
    private static final int FEMALE_RATE = 52;
    // The food value of a single Zebra- The number of steps eating a Zebra enables the lion to move before it must eat again
    private static final int ZEBRA_FOOD_VALUE =9;
     // The food value of a single Giraffe- The number of steps eating a Giraffe enables the lion to move before it must eat again
    private static final int GIRAFFE_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Lion's age.
    private int age;
    // The Lion's food level, which is increased by eating its prey.
    private int foodLevel;
    // The Lion's Gender: A lion can be male or female.
    private String gender;

    /**
     * Constructor for objects of class lion. A lion may be created with age
     * zero (a new born) or with a random age at beginning of the simulator.
     * 
     * @param randomAge If true, the lion will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * 
     * 
     * 
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            //the foodLevel will be the random sum of all the preys' food level
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE)+rand.nextInt(GIRAFFE_FOOD_VALUE);
        }
        else {
            age = 0;
            //the foodLevel will be the sum of all the preys' food level
            foodLevel = ZEBRA_FOOD_VALUE + GIRAFFE_FOOD_VALUE;
        }
        int rand_gender;
        rand_gender = rand.nextInt(100)+1;
        //define lions' gender based on their female rate 
        if (rand_gender<FEMALE_RATE)
        {
            gender = "female";
        }
        else 
        {
            gender = "male";
        }

    }

    /**
     * The act method:
     * i)increases the age
     * ii)decreases the food level
     * iii)checks if the animal fullfills the conditions to give birth.
     * iv)checks adjacent locations for availible prey.
     * v)invokes the checkdisease method- Checks if the animal should be infected by a disease.
     * 
     * @override
     * @param  newLions: a list of newborn Lions
  
     */
    public void  act(List<Animal> newLions)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newLions);  

            // Move towards a source of food if found.
            if(time.equals("Evening"))
            {
            Location newLocation = findFood();

            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            }
            checkDisease(0.12,0.3);

        }
    }
    
    /**
     * Increase the age. This could result in the Lion's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Lion more hungry. This could result in the Lion's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * @return the Lion's gender.
     */
    
    private String getGender()
    {
        return gender;
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()&& !weather.equals("foggy")) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Zebra) {
                Zebra Zebra = (Zebra) animal;
                if(Zebra.isAlive()) { 
                    Zebra.setDead();
                    foodLevel = foodLevel + ZEBRA_FOOD_VALUE;
                    return where;
                }
            }    
            else if (animal instanceof Giraffe) {
                Giraffe Giraffe = (Giraffe) animal;
                if(Giraffe.isAlive()) { 
                    Giraffe.setDead();
                    foodLevel = foodLevel + GIRAFFE_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof ApricotTrees) {
                ApricotTrees ApricotTrees = (ApricotTrees) animal;
                if(ApricotTrees.isAlive()) { 
                    ApricotTrees.setDead();
                    return where;
                }

            }
            
        }
        return null;
    } 
    
    /**
     * Check whether or not this Lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born Lions.
     */
    private void giveBirth(List<Animal> newLions)
    {
        // New Lions are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Lion can breed if it has reached the breeding age, and meets another lion in an adjacent location of another gender.
     * @return boolean checkMeet true if the Lion meets a lion of the other gender.
     */
   
    private boolean checkMeet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        String gender_meet = "";
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Lion)
            {
                Lion Lion = (Lion) animal;
                gender_meet = Lion.getGender(); 
                //This is how living diseased Lions can infect other lions.
                if(disease = true)
                {
                    //Inserts a ratio of a Lion passing on a disease of 0.5
                    Lion.gainDisease(0.5);
                }
            }
        }
        return (gender_meet != gender);

    }
    

    
    /**
     *
     * @return boolean true if the Lion's age is above or equal to that of the the breeding age and checkmeet is true.
     */
    private boolean canBreed()
    {
    return (age >= BREEDING_AGE && checkMeet());
    }
}
