import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Tiger.
 * Tigers age, move, breed, and die.
 * Tigers are also predators, they can eat Zebras and Girraffes
 *
 * @version (12/2/2019)
 */
public class Tiger extends Predators
  {
    // Characteristics shared by all Tigers (class variables).
    
    // The age at which a tiger can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a tiger can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE =4;
    // The food value of a single Zebra- The number of steps eating a Zebra enables the Tiger to move before it must eat again
    private static final int ZEBRA_FOOD_VALUE =6;
    // The food value of a single Giraffe- The number of steps eating a Giraffe enables Tiger to move before it must eat again
    private static final int GIRAFFE_FOOD_VALUE =7;
    
    
    private static final int FEMALE_RATE = 51;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Tiger's age.
    private int age;
    // The Tiger's food level, which is increased by eating its prey.
    private int foodLevel;
    // The Tiger's Gender: A Tiger can be male or female. 
    private String gender;
    /**
     * Constructor for objects of class tiger. A tiger may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the tiger will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            //the foodLevel will be the random sum of all the preys' food level
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE) + rand.nextInt(GIRAFFE_FOOD_VALUE);
        }
        else {
            age = 0;
            //the foodLevel will be the sum of all the preys' food level
            foodLevel = ZEBRA_FOOD_VALUE +GIRAFFE_FOOD_VALUE;
        }
        int rand_gender;
        rand_gender = rand.nextInt(100)+1;
        //define tigers' gender based on their female rate 
        if (rand_gender<FEMALE_RATE)
        {
            gender = "female";
        }
        else 
        {
            gender = "male";
        }
    }

     /**
     * The act method:
     * i)increases the age
     * ii)decreases the food level
     * iii)checks if the animal fullfills the conditions to give birth.
     * iv)checks adjacent locations for availible prey.
     * v)invokes the chekdisease method- Checks if the Tiger should be infected by a disease.
     * 
     * @override
     * @param  newLions: a list of newborn Tigers
  
     */
    public void  act(List<Animal> newTigers)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newTigers);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            checkDisease(0.1,0.3);
        }
    }
    
    /**
     * Increase the age. This could result in the Tiger's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this tiger more hungry. This could result in the Tiger's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
          while(it.hasNext()&&!weather.equals("foggy")) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            Object plant = field.getObjectAt(where);
            if(animal instanceof Zebra) {
                Zebra Zebra = (Zebra) animal;
                if(Zebra.isAlive()) { 
                    Zebra.setDead();
                    foodLevel = foodLevel + ZEBRA_FOOD_VALUE;
                    return where;
                }
              }
            else if (animal instanceof Giraffe){
                Giraffe Giraffe = (Giraffe) animal;
                if(Giraffe.isAlive()) { 
                    Giraffe.setDead();
                    foodLevel =foodLevel + GIRAFFE_FOOD_VALUE;
                    return where;
                }
              }
            
              else if(animal instanceof ApricotTrees) {
                ApricotTrees ApricotTrees = (ApricotTrees) animal;
                if(ApricotTrees.isAlive()) { 
                    ApricotTrees.setDead();
                    return where;
                }
               }
        }
       
    return null;
    } 
    
    /**
     * Check whether or not this Tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTiger A list to return newly born Tigers.
     */
    private void giveBirth(List<Animal> newTiger)
    {
        // New tigers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tiger young = new Tiger(false, field, loc);
            newTiger.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    
    /**
     * @return the Tiger's gender.
     */
    
    private String getGender()
    {
        return gender;
    }
    
    /**
     * A Tiger can breed if it has reached the breeding age, and meets another Tiger in an adjacent location of another gender.
     * @return boolean checkMeet true if the Tiger meets a Tigrt of the other gender.
     */
    
    private boolean checkMeet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        int male_counter = 0;
        int female_counter = 0;
        Iterator<Location> it = adjacent.iterator();
        String gender_meet = "";
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Tiger)
            {
                Tiger Tiger = (Tiger) animal;
                gender_meet = Tiger.getGender(); 
                if(disease = true)
                {
                    Tiger.gainDisease(0.5);
                }
            }
        }
        return (gender_meet != gender);
    }
    
     /**
     *
     * @return boolean true if the Tiger's age is above or equal to that of the the breeding age and checkmeet is true.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && checkMeet());
    }
}

