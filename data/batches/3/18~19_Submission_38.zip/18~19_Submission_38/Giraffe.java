import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Giraffe
 * Giraffes age, move, breed, and die.
 *
 * @version (12/2/2019)
 */
public class Giraffe extends Prey
{
    // Characteristics shared by all Giraffes (class variables).

    // The age at which a Giraffe can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a Giraffe can live.
    private static final int MAX_AGE = 95;
    // The likelihood of a Giraffe breeding.
    private static final double BREEDING_PROBABILITY = 0.70;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of a single Apricot tree- The number of steps eating a Apricot tree enables the Giraffe to move before it must eat again
    private static final int APRICOT_TREES_FOOD_VALUE = 10;
    //The proprtion of female Giraffes (out of 100)
    private static final int FEMALE_RATE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Giraffe's age.
    private int age;
    // The Giraffe's food level, which is increased by eating its prey.
    private String gender;
    // The Giraffe's Gender: A lion can be male or female.
    private int foodLevel;
    /**
     * Create a new Giraffe. A Giraffe may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Giraffe will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Giraffe(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            //the foodLevel will be the random sum of all the preys' food level
            foodLevel = rand.nextInt(APRICOT_TREES_FOOD_VALUE);
        }
        else {
            age = 0;
            //the foodLevel will be the sum of all the preys' food level
            foodLevel = APRICOT_TREES_FOOD_VALUE;
        }
        
        int rand_gender;
        rand_gender = rand.nextInt(100)+1;
        //define tigers' gender based on their female rate 
        if (rand_gender<FEMALE_RATE)
        {
            gender = "female";
        }
        else 
        {
            gender = "male";
        }
    }
    
      /**
     * The act method:
     * i)increases the age
     * ii)decreases the food level
     * iii)checks if the animal fullfills the conditions to give birth.
     * iv)checks adjacent locations for availible prey.
     * v)invokes the checkdisease method- Checks if the animal should be infected by a disease.
     * 
     * @override
     * @param  newGiraffe: a list of newborn giraffes
  
     */
    public void act(List<Animal> newGiraffe)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (time.equals("Evening"))
            {
            giveBirth(newGiraffe);  
            }
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.

                //for giraffe leavecorpse substitude the method setDead 
                //since giraffe can leave corpses after they dead in a certain rate
                leaveCorpse();
            }
            
            checkDisease(0.075,0.51);
        }
    }

    /**
     * Increase the age.
     * This could result in the Giraffe's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            leaveCorpse();
        }
    }
     /**
     * Make this Giraffe more hungry. This could result in the Giraffe's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            leaveCorpse();
        }
    }
    /**
     * Check whether or not this Giraffe is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGiraffe A list to return newly born Giraffes.
     */
    private void giveBirth(List<Animal> newGiraffe)
    {
        // New Giraffes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Giraffe young = new Giraffe(false, field, loc);
            newGiraffe.add(young);
        }
    }
    
    /**
     * Look for Apricot Trees adjacent to the current location.
     * Only the first Tree is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof ApricotTrees) {
                ApricotTrees ApricotTrees = (ApricotTrees) plant;
                if(ApricotTrees.isAlive()) { 
                    ApricotTrees.setDead();
                    foodLevel = foodLevel + APRICOT_TREES_FOOD_VALUE;
                    return where;
                }

            }
        }
        return null;
    } 
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    /**
     * @return the Lion's gender.
     */
    private String getGender()
    {
        return gender;
    }
    
    /**
     * Method leaveCorpse() is called when Giraffe is going to die.
     * The method decides whether the Giraffe should leave a corpse when it 
     * dies using a random number generator and a set probibility.
     * 
     * The method also invokes the setDead() method to set the Giraffes alive status to dead.
     */
   
    protected void leaveCorpse()
    {   
        Random rand = new Random();
        double randm = rand.nextDouble();
        Field field = getField();
        Location location = getLocation();

        if(randm<0.05)
        {
            setDead();
            if (location!=null)
            {
            Corpse young = new Corpse(field,location);
            }
        }
        else
        {
            setDead();
        }

    }
     /**
     * A Giraffe can breed if it has reached the breeding age, and meets another giraffe in an adjacent location of another gender.
     * @return boolean checkMeet true if the giraffe meets a giraffe of the other gender.
     */
    
    private boolean checkMeet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        int male_counter = 0;
        int female_counter = 0;
        Iterator<Location> it = adjacent.iterator();
        String gender_meet = "";
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Giraffe)
            {
                Giraffe Giraffe = (Giraffe) animal;
                gender_meet = Giraffe.getGender(); 
                if(disease = true)
                {
                    Giraffe.gainDisease(0.5);
                }
            }
        }
        return (gender_meet != gender);
    }
    /**
     * A Giraffe can breed if it has reached the breeding age.
     * @return true if the Giraffe can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && checkMeet() );
    }
    


}
