
import java.util.List;
import java.util.Random;
/**
 * A simple model of an ApricotTree
 * ApricotTrees can breed. They die when they are eaten.
 * 
 *
 * @version (12/2/2019)
 */
public class ApricotTrees extends Plant
{
    
    
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;

    /**
     * Constructor for objects of class ApricotTress
     */
    public ApricotTrees(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * The act method invokes the giveBirth method if tree fullfills the 
     * conditions to give birth (the condition being a return value of
     * "true: from method isAlive()
    
     * @override
     * @param  newApricotTrees: a list of new Apricot Trees
  
     */
    
    public void  act(List<Plant> newApricotTrees)
    {
        if(isAlive()) {
        giveBirth(newApricotTrees);            
        }
    }
    /**
     * Check whether or not this Apricot Tree is to give birth at this step.
     * New births will be made into free adjacent locations.
     * New births will only take place if it weather is rainy or if it is the 
     * morning
     * @param newApricotTrees a list to return newly born Apricot Trees.
     */
    
    
    private void giveBirth(List<Plant> newApricotTrees)
    {
        Field field = getField();
        if (weather.equals("rainy")|| time.equals("Morning")){
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            ApricotTrees young = new ApricotTrees(field, loc);
            newApricotTrees.add(young);
           } 
        }
    }
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    
    
    private int breed()
    {
        int births = 0;
        if( rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
