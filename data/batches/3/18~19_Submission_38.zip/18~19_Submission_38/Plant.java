
import java.util.List;
/**
 * Write a description of class plants here.
 *
 * @version (12/2/2019)
 */
public abstract class Plant extends Species
{
     public  Plant (Field field, Location location)
    {
        super(field, location);
    }
    
    abstract protected void act(List<Plant> newPlants);
}
