import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Zebra.
 * Zebras age, move, breed, and die.
 *
 * @version (12/2/2019)
 */
public class Zebra extends Prey
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 11;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.65;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single Apricot tree- The number of steps eating a Apricot tree enables the Zebra to move before it must eat again
    private static final int APRICOT_TREES_FOOD_VALUE = 8;
    //The proprtion of female Zebras (out of 100)
    private static final int FEMALE_RATE = 47;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The zebra's age.
    private int age;
    // The Lion's food level, which is increased by eating its prey.
    private int foodLevel;
    // The Lion's Gender: A lion can be male or female.
    private String gender;

    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            //the foodLevel will be the random sum of all the preys' food level
            foodLevel =  rand.nextInt(APRICOT_TREES_FOOD_VALUE);
        }
        else {
            age = 0;
            //the foodLevel will be the sum of all the preys' food level
            foodLevel = APRICOT_TREES_FOOD_VALUE;
        }
        
        int rand_gender;
        rand_gender = rand.nextInt(100)+1;
        //define tigers' gender based on their female rate 
        if (rand_gender<FEMALE_RATE)
        {
            gender = "female";
        }
        else 
        {
            gender = "male";
        }
    }
    
     /**
     * The act method:
     * i)increases the age
     * ii)decreases the food level
     * iii)checks if the animal fullfills the conditions to give birth.
     * iv)checks adjacent locations for availible prey.
     * v)invokes the checkdisease method- Checks if the animal should be infected by a disease.
     * 
     * @override
     * @param  newZebra: a list of newborn Zebras
  
     */
    public void act(List<Animal> newZebra)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newZebra);       

            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                setDead();
            }
            
            checkDisease(0.09,0.55);
        }
    }

    /**
     * Increase the age.
     * This could result in the zebra's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
     /**
     * Make this Zebra more hungry. This could result in the Zebra's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    /**
     * Check whether or not this zebra is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newzebras a list to return newly born zebras.
     */
    private void giveBirth(List<Animal> newzebras)
    {
        // New zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Zebra young = new Zebra(false, field, loc);
            newzebras.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Look for Apricot Trees adjacent to the current location.
     * Only the first Tree is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    
    
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof ApricotTrees) {
                ApricotTrees ApricotTrees = (ApricotTrees) plant;
                if(ApricotTrees.isAlive()) { 
                    ApricotTrees.setDead();
                    foodLevel = foodLevel + APRICOT_TREES_FOOD_VALUE;
                    return where;
                }

            }
        }
        return null;
    } 
    
    /**
     * @return the Lion's gender.
     */
    
    private String getGender()
    {
        return gender;
    }
    
     /**
     * A Zebra can breed if it has reached the breeding age, and meets another Zebra in an adjacent location of another gender.
     * @return boolean checkMeet true if the Zebra meets a Zebra of the other gender.
     */
    
    
    private boolean checkMeet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        int male_counter = 0;
        int female_counter = 0;
        Iterator<Location> it = adjacent.iterator();
        String gender_meet = "";
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Zebra)
            {
                Zebra Zebra = (Zebra) animal;
                gender_meet = Zebra.getGender(); 
                if(disease = true)
                {
                    Zebra.gainDisease(0.5);
                }
            }
        }
        return (gender_meet != gender);
    }
    /**
     * A zebra can breed if it has reached the breeding age.
     * @return true if the zebra can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && checkMeet() );
    }
}
