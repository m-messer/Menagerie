
/**
 * A abstract superclass for the predators which which completes the structure 
 *
 * @version (12/2/2019)
 */
public abstract class Predators extends Animal
{


    /**
     * Create a Predator
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predators(Field field, Location location)
    {
        super(field, location);
    }

}
