
 import java.util.List;
/**
 * The Corpse class is a subclass of the superclass Species.
 * 
 *
 *
 * @version (a version number or a date)
 */
public class Corpse extends Species
{


    /**
     * Constructor for objects of class Corpse
     */
    public  Corpse(Field field, Location location)
    {
        super(field, location);

    }
     
     /**
     * @Override
     * The act method of the Corpse class overides the pre-defined act method 
     * given in the species superclass 
     * 
     * The act method is used to invoke the setDead(); method when certain
     * conditions are true.
     */

    
    
    public void  act (List<Corpse> newCorpses)
    {
        if (weather.equals("sunny") && time.equals("morning"))
        {
            setDead();
        }
    }

}
