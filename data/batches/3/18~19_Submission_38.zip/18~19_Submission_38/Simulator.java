 import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Lion, Hyena, Tiger, Zebra, Girraffe and ApricotTrees
 *
 * @version (14/2/2019)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that for each of the species, that one of them will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.01;
    private static final double TIGER_CREATION_PROBABILITY = 0.015;
 
    private static final double ZEBRA_CREATION_PROBABILITY = 0.05;    
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.04;  
    private static final double PLANTS_CREATION_PROBABILITY = 0.15;  
    private static final double HYENA_CREATION_PROBABILITY = 0.015;  
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    
    private List<Corpse> corpses;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    private String weather;

    private String time;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * Set colours for each animal in simulation tile.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        corpses = new ArrayList<>();
        field = new Field(depth, width);
        Location location = new Location(1, 1);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.cyan);
        view.setColor(Lion.class, Color.MAGENTA);
        view.setColor(Giraffe.class, Color.ORANGE);
        view.setColor(Tiger.class, Color.RED);
        view.setColor(ApricotTrees.class, Color.GREEN);
        view.setColor(Hyena.class, Color.BLUE);
        view.setColor(Corpse.class, Color.LIGHT_GRAY);
        weather = field.getWeather();
        time = field.getTime();
        


        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1500);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each individual species.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();   
        List<Plant> newPlants = new ArrayList<>(); 
        List<Corpse> newCorpses = new ArrayList<>();

        // Let all Animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        
        for(Iterator<Corpse> it = corpses.iterator(); it.hasNext(); ) {
            Corpse corpse = it.next();
            corpse.act(newCorpses);
            if(! corpse.isAlive()) {
                it.remove();
            }
        }        
        // Add the newly created animals and plans to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);
        
        // Every 5 steps the weather is updated.

        if (step % 5 ==0)
        {
            field.changeWeather();
            weather = field.getWeather();
            
        }
        
        // Every 50 steps the weather is updated.
        
        if (step % 50 ==0)
        {
            field.changeTime();
            time = field.getTime();
        }
        view.showStatus(step, field, weather,time); 

    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, weather,time);
    }
    
    /**
     * Randomly populate the field with Lion, Hyena, Tiger, Zebra, Girraffe and ApricotTrees
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);

                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Giraffe giraffe = new Giraffe(true, field, location);
                    animals.add(giraffe);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= PLANTS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant ApricotTrees = new ApricotTrees(field, location);
                    plants.add(ApricotTrees);
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena Hyena = new Hyena(true, field, location);
                    animals.add(Hyena);
                }
                // else leave the location empty.
            }
        }
    }
    


    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
