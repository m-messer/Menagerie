import java.util.List;
import java.util.Random;

/**
 * A abstract superclass for the preys which completes the structure 
 *
 * @version (12/2/2019)
 */
public abstract class Prey extends Animal
{
    /**
     * Create a Prey animal.
     
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location)
    {
        super(field, location);
    }
}
