 import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Hyena.
 * Hyenas age, move, breed, and die.
 * Hyenas are also predators, they can eat Corpses and Zebras
 *
 * @version (12/2/2019)
 */
public class Hyena extends Predators
{
    // Characteristics shared by all Hyenas (class variables).
    
    // The age at which a Hyena can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Hyena can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a Hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.60;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //The proprtion of female Hyenas (out of 100)
    private static final int FEMALE_RATE = 52;
    // The food value of a single Corpse- The number of steps eating a Corpse enables the Hyena to move before it must eat again
    private static final int CORPSE_FOOD_VALUE =25;
    // The food value of a single Zebra- The number of steps eating a Zebra enables the Hyena to move before it must eat again
    private static final int ZEBRA_FOOD_VALUE = 14;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Hyena's age.
    private int age;
    // The Hyena's food level, which is increased by eating its prey.
    private int foodLevel;
    // The Hyena's Gender: A Hyena can be male or female
    private String gender;

    /**
     * Constructor for objects of class lion.
     * A lion may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the lion will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            //the foodLevel will be the random sum of all the preys' food level
            foodLevel = rand.nextInt(CORPSE_FOOD_VALUE);
        }
        else {
            age = 0;
            //the foodLevel will be the sum of all the preys' food level
            foodLevel = CORPSE_FOOD_VALUE;
        }
        int rand_gender;
        rand_gender = rand.nextInt(100)+1;
        //define hyenas' gender based on their female rate 
        if (rand_gender<FEMALE_RATE)
        {
            gender = "female";
        }
        else 
        {
            gender = "male";
        }

    }

     /**
     * The act method:
     * i)increases the age
     * ii)decreases the food level
     * iii)checks if the animal fullfills the conditions to give birth.
     * iv)checks adjacent locations for availible prey.
     * v)invokes the checkdisease method- Checks if the animal should be infected by a disease.
     * 
     * @override
     * @param  newHyenas: a list of newborn Hyenas
  
     */
 
    public void  act(List<Animal> newHyenas)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHyenas);  

            // Move towards a source of food if found.
            Location newLocation = findFood();

            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
            checkDisease(0.12,0.3);

        }
    }
    
    /**
     * Increase the age. This could result in the Hyena's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Hyena more hungry. This could result in the Hyena's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * @return the Hyena's gender.
     */
    
    
    private String getGender()
    {
        return gender;
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        if (weather!=null){
        weather = field.getWeather();
        }
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()&& !weather.equals("foggy")) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Corpse) {
                Corpse Corpse = (Corpse) animal;
                if(Corpse.isAlive()) { 
                    Corpse.setDead();
                    foodLevel = foodLevel + CORPSE_FOOD_VALUE;
                    if(where!=null)
                    {
                        field.clear(where);
                    }
                    return where;
                }
            }    
            if(animal instanceof Zebra) {
                Zebra Zebra = (Zebra) animal;
                if(Zebra.isAlive()) { 
                    Zebra.setDead();
                    foodLevel = foodLevel + ZEBRA_FOOD_VALUE;
                    return where;
                }
              }
            else if(animal instanceof ApricotTrees) {
                ApricotTrees ApricotTrees = (ApricotTrees) animal;
                if(ApricotTrees.isAlive()) { 
                    ApricotTrees.setDead();
                    return where;
                }

            }            
        }
        return null;
    } 
    
    /**
     * Check whether or not this Hyena is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHyenas A list to return newly born Hyenas.
     */
    private void giveBirth(List<Animal> newHyenas)
    {
        // New Hyenas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hyena young = new Hyena(false, field, loc);
            newHyenas.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Hyena can breed if it has reached the breeding age, and meets another Hyena in an adjacent location of another gender.
     * @return boolean checkMeet true if the Hyena meets a Hyena of the other gender.
     */
   
    private boolean checkMeet()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        String gender_meet = "";
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Hyena)
            {
                Hyena Hyena = (Hyena) animal;
                gender_meet = Hyena.getGender(); 
                if(disease = true)
                {
                    Hyena.gainDisease(0.5);
                }
            }
        }
        return (gender_meet != gender);

    }
    

    /**
     *
     * @return boolean true if the Hyena's age is above or equal to that of the the breeding age and checkmeet is true.
     */
    
    private boolean canBreed()
    {
    return (age >= BREEDING_AGE && checkMeet());
    }
}