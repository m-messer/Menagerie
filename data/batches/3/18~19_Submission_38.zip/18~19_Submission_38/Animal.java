import java.util.Random;
import java.util.List;
import java.util.Iterator;
  /**
 * A class representing shared characteristics of animals.
 * 
 *
 */

public abstract class Animal extends Species
{

    protected boolean disease;
    private Random rand;
    
    
    public  Animal(Field field, Location location)
    {
        super(field, location);
        disease = false ;

    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract protected void act(List<Animal> newAnimals);
       

      /**
     * Method checkDisease uses a combination of random numbers, and 
     * liklihood of infection of the given species by the disease to determine
     * weather the animal should be infected. checkDisease itself does not infect
     * the animal. If the random number generated is smalled than the 
     * "diseasePossibility",  method gainDisease is called, and 
     *  diePossibility is passed forwards.
     * The repeated use of this method should in turn randomly infect a given 
     * proportion of the population, roughly in proportion to the expected value
     * according to diseasePossibility.
     * 
     * @param diseasePossibility is the probability that an animal will be 
     * infected at any one exposure to a given disease.
     * @param diePossibility is the probability that an animal will be 
     * die after infection.
     */
    protected void checkDisease(double diseasePossibility,double diePossibility)
    {
        Random rand = new Random();
        double randm = rand.nextDouble();
        if (randm<diseasePossibility)
        {

            gainDisease(diePossibility);
        }
        
    }
    
    
    
     /**
     * Method gainDisease takes the value diePossbility as a parameter. 
     * gainDisease will set the field disease to "true" .
     * 
     *  If the generated random number is smaller than diePossibility, the
     *  setDead() method will be invoked.
     * 
     *  @param diePossibility is the probability that an animal will be 
     * die after infection.
     */
    protected void gainDisease(double diePossibility)
    {
        Random rand = new Random();
        double randm = rand.nextDouble();
        disease = true;
        if(randm<diePossibility)
        {
            setDead();
        }

     }
    
}


