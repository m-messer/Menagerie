
/**
 * A new class that keeps track of the day and night cycle.
 *
 * @version 2021.03.03
 */

public class TimeTrack
{
    // time of the day: True - day, False - night;
    private boolean day;
    /**
     * Construct a Time tracker
     */
    public TimeTrack()
    {
        // simulation starts during the day
        day = true;
    }
    /**
     * One day is 24 cycles long. Check whether its day or night and update the state of day variable.
     * @param integer current step
     * @return 
     */
    public boolean isDay(int step)
    {
        int dayLength = 24;                
        if(step > 0 && (step % dayLength == 0)) {
            day = !day;
        }
        return day;
    }
}
