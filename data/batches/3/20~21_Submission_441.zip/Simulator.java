import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing following animal species and plants.
 * 
 * Predators: Fox, Bear
 * Preys: Hedgehog, Rabbit, Deer, Bison
 * Plants: Dandelion, Weed
 *
 * @version 2021.03.03 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.06;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.1;  
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.07;  
    // The probability that a bison will be created in any given grid position.
    private static final double BISON_CREATION_PROBABILITY = 0.19;  
    // The probability that a hedgehog will be created in any given grid position.
    private static final double HEDGEHOG_CREATION_PROBABILITY = 0.3; 
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.04;  

    // The probability that a weed seed will be planted in any given grid position.
    private static final double WEED_CREATION_PROBABILITY = 0.95; 
    // The probability that a dandelion seed will be planted in any given grid position.
    private static final double DANDELION_CREATION_PROBABILITY = 0.95;  

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;

    //  Night/day cycle tracker.
    private TimeTrack timetrack;

    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        this.step = step;
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        timetrack = new TimeTrack();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.BLUE);
        view.setColor(Fox.class, Color.ORANGE);
        view.setColor(Bear.class, Color.RED);
        view.setColor(Deer.class, Color.LIGHT_GRAY);
        view.setColor(Bison.class, Color.MAGENTA);
        view.setColor(Hedgehog.class, Color.DARK_GRAY);
        view.setColor(Weed.class, Color.GREEN);
        view.setColor(Dandelion.class, Color.YELLOW);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * Apply the delay if the Slow Mode is toggled via the GUI.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {

        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            boolean slowmode = view.getSlowModeButtonState();
            if (slowmode){
                delay(120);   
            }
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal or plant.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>(); 
        List<Plant> newPlants = new ArrayList<>(); 

        // Check and update conditions of the step.
        boolean day = timetrack.isDay(step);
        boolean drought = view.getWeatherButtonState();

        // Let all animals act.

        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();

            if ((animal instanceof Hedgehog) && day){
                // Hedgehogs sleep during the day.
            }

            else{
                animal.act(newAnimals);
            }

            if(! animal.isAlive()) {
                it.remove();

            }
        }

        // Let all plants grow.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            if(drought){
                // No plants grow during the drought
            }
            else{
                plant.grow(newPlants);

            }
            if(!plant.isAlive()) {
                it.remove();

            }
        }

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        // Add the newly grown plants to the main lists.
        plants.addAll(newPlants);

        view.showStatus(step, field);

    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                }

                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean isHealthy = rand.nextBoolean();
                    Deer deer = new Deer(true, field, location, isHealthy);
                    animals.add(deer);
                }

                else if(rand.nextDouble() <= BISON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bison bison = new Bison(true, field, location);
                    animals.add(bison);
                }

                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, field, location);
                    animals.add(bear);
                }

                else if(rand.nextDouble() <= HEDGEHOG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hedgehog hedgehog = new Hedgehog(true, field, location);
                    animals.add(hedgehog);
                }

                else if(rand.nextDouble() <= WEED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Weed weed = new Weed(true, field, location);
                    plants.add(weed);
                }

                else if(rand.nextDouble() <= DANDELION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dandelion dandelion = new Dandelion(true, field, location);
                    plants.add(dandelion);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

}
