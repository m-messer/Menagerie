import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a weed.
 * Weed age, seed, and die.
 *
 * @version 2021.03.03
 */
public class Weed extends Plant
{
    // Characteristics shared by all weed (class variables).

    // The age to which a weed can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a weed seeding.
    private static final double SEEDING_PROBABILITY = 1;
    // The maximum number of seeds.
    private static final int MAX_LITTER_SIZE = 300;
    // A shared random number generator to control seeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The weed's age.
    private int age;

    /**
     * Create a new weed. A weed may be created with age
     * zero (a new planted) or with a random age.
     * 
     * @param randomAge If true, the weed will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Weed(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }

    }
    /**
     * This is what the weed does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newWeed A list to return newly planted weed.
     */
    public void grow(List<Plant> newWeed)
    {
        incrementAge();
        if(isAlive()) {

            giveSeed(newWeed);

            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the weed's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this weed is to give seed at this step.
     * New seeds will be made into free adjacent locations.
     * @param newWeed A list to return newly planted weeds.
     */
    private void giveSeed(List<Plant> newWeed)
    {
        // New weeds are planted into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int seeds = breed();
        for(int b = 0; b < seeds && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gender = rand.nextBoolean();
            Weed young = new Weed(false, field, loc);
            newWeed.add(young);
        }

    }

    /**
     * Generate a number representing the number of seeds,
     * if it can breed.
     * @return The number of seeds (may be zero).
     */
    private int breed()
    {
        int seeds = 0;
        if(rand.nextDouble() <= SEEDING_PROBABILITY) {
            seeds = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return seeds;
    }
}

    