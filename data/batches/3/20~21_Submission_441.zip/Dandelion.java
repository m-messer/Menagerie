import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a dandelion.
 * Dandelions age, seed, and die.
 *
 * @version 2021.03.03
 */
public class Dandelion extends Plant
{
    // Characteristics shared by all dandelions (class variables).

    // The age to which a dandelion can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a dandelion seeding.
    private static final double SEEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 200;
    // A shared random number generator to control seeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The dandelion's age.
    private int age;

    /**
     * Create a new dandelion. A dandelion may be created with age
     * zero (a new planted) or with a random age.
     * 
     * @param randomAge If true, the dandelion will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Dandelion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }

    }
    /**
     * This is what the dandelion does most of the time - it runs 
     * around. Sometimes it will seed or die of old age.
     * @param newDandelions A list to return newly planted dandelions.
     */
    public void grow(List<Plant> newDandelions)
    {
        incrementAge();
        if(isAlive()) {

            giveSeeds(newDandelions);

            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the dandelion's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this dandelion is to give seeds at this step.
     * New seeds will be made into free adjacent locations.
     * @param newDandelions A list to return newly planted dandelions.
     */
    private void giveSeeds(List<Plant> newDandelions)
    {
        // New dandelions are planted into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int seeds = seed();
        for(int b = 0; b < seeds && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gender = rand.nextBoolean();
            Dandelion young = new Dandelion(false, field, loc);
            newDandelions.add(young);
        }

    }

    /**
     * Generate a number representing the number of seeds,
     * if it can seed.
     * @return The number of seeds (may be zero).
     */
    private int seed()
    {
        int seeds = 0;
        if(rand.nextDouble() <= SEEDING_PROBABILITY) {
            seeds = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return seeds;
    }
}

    
