package Climate;

import java.math.BigDecimal;

/**
 * The main climate class that encapsulates different factors such as wind, precipitation levels and average temperature.
 * Employing a factory method structure
 *
 * @version 2022-03-01
 */
public class Climate {
    private WeatherFactory weatherFactory;
    private Weather weather;
    private Season season;

    /**
     * Initialises the object according to the type of season
     * @param season the season to be the default
     */
    public Climate(Season season){
        weatherFactory = new WeatherFactory();
        if(season == null){
            //default season
            season = Season.WINTER;
        }
        this.season = season;
        weather = weatherFactory.getWeather(season);
    }


    /**
     * An arbitrary formula is used here:
     * In animals, summer generally means higher breeding rates, larger increases in animal value.
     * In winter, the animals have lower breeding rates and lower animal values
     * This has a knock on effect on the animals.
     */
    public double calculateBreedingFactor(){
        //Breeding factor to impact creatures
        double breedingFactor;
        //this shouldn't happen as precipitation should always be >= 0 - returns an error number
        if(weather.getPrecipitation() < 0 ){
            return -1;
        }
        //results in a division by 0 error in calculation.
        else if(weather.getTemperature() == 0){
            breedingFactor =  0.8;
        }else{
            breedingFactor =  (weather.getPrecipitation() + (weather.getTemperature()-15)/ weather.getPrecipitation());
            //e.g. rainfall of 210.2 and average temp of 10.1 gives 0.97
            if(breedingFactor > 1.1 || breedingFactor < 0.9){
                breedingFactor = 1;
            }
        }
        BigDecimal roundedBreedingFactor = new BigDecimal(breedingFactor);
        return roundedBreedingFactor.doubleValue();
    }

    /**
     * An arbitrary formula is used here:
     * In animals, summer generally means higher breeding rates, larger increases in animal value.
     * In winter, the animals have lower breeding rates and lower animal values
     * This has a knock on effect on the animals.
     */
    public double calculateBreedingFactorPlants(){
        //Breeding factor to impact creatures
        double breedingFactor;
        //this shouldn't happen as precipitation should always be >= 0 - returns an error number
        if(weather.getPrecipitation() < 0 ){
            return -1;
        }
        //results in a division by 0 error in calculation.
        else if(weather.getTemperature() == 0){
            breedingFactor =  0.8;
        }else{
            breedingFactor =  (weather.getPrecipitation() + 5*(weather.getTemperature()-15)/ weather.getPrecipitation());
            //e.g. rainfall of 210.2 and average temp of 10.1 gives 0.97
            if(breedingFactor > 1.25 || breedingFactor < 0.8){
                breedingFactor = 1;
            }
        }
        BigDecimal roundedBreedingFactor = new BigDecimal(breedingFactor);
        return roundedBreedingFactor.doubleValue();
    }


    /**
     * This method returns the current season
     * @return the current season
     */
    public Season getSeason(){
        return season;
    }


    /**
     * This method returns the current weather
     * @return the current weather
     */
    public Weather getWeather(){
        return weather;
    }

    /**
     * This method sets the current season to a new one
     * @param season the new season
     */
    public void setSeason(Season season){
        weather = weatherFactory.getWeather(season);
        this.season = season;
    }
}
