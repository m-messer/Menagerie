package Climate;

import SimulatorHelpers.Randomizer;

import java.util.Random;

/**
 * Conditions are in between Summer and Winter Weather
 * Autumn ranges from September - November
 * or from Harvestmath - Blooting
 *
 *@version 2022-03-01
 */

public class AutumnWeather extends Weather{
    // temperature in degrees celsius on Middle Earth - modelled to be similar to West Midlands
    private static double AUTUMN_TEMPERATURE = 10.1;

    //Amount of precipitation on Middle Earth in millimetres
    private static double AUTUMN_PRECIPITATION = 210.2;

    //The time at which the sun rises given the season
    //actual time is 7:45am.
    private static final int SUNRISE_TIME = 8;

    //The time at which the sun sets given the season
    //actual time is 7:17pm.
    private static final int SUNSET_TIME = 19;

    //Random object that is shared for all objects in autumn
    private static Random rand;
    /**
     * Initialised according to the time that the program is run
     */
    public AutumnWeather() {
        rand = Randomizer.getRandom();
    }

    /**
     *
     * @return the random temperature on a certain day in +- 3 range.
     */
    @Override
    public double getTemperature() {
        double temperature = rand.nextInt(6) + AUTUMN_TEMPERATURE-3.0;
        return temperature;
    }

    /**
     *
     * @return the random precipitation on a certain day in +- 6 range.
     */
    @Override
    public double getPrecipitation() {
        double precipitation = rand.nextInt(12) + AUTUMN_PRECIPITATION-6.0;
        return precipitation;
    }

    /**
     *
     * @return the time the Sun rises in Autumn
     */
    @Override
    public int getSunriseTime() {
        return SUNRISE_TIME;
    }
    /**
     *
     * @return the time the Sun sets in Autumn
     */
    @Override
    public int getSunsetTime() {
        return SUNSET_TIME;
    }
}
