package Climate;

import java.util.HashMap;
import java.util.Map;

/**
 * The seasons' enumeration type is created to check if a string belongs to a season.
 * Define the 4 seasons
 * @version 2022-03-01
 */
public enum Season {
    WINTER, SPRING, SUMMER, AUTUMN;
    private Map<Season, String> seasonMap;

    /**
     * Defualt Constrictor
     */
    Season() {
        seasonMap = new HashMap<Season, String>();
        setSeasons(seasonMap);
    }

    /**
     * Add the seasons to the Map
     * @param seasonMap
     */
    private void setSeasons(Map<Season, String> seasonMap) {
        seasonMap.put(WINTER, "Winter");
        seasonMap.put(SPRING, "Spring");
        seasonMap.put(SUMMER, "Summer");
        seasonMap.put(AUTUMN, "Autumn");
    }

    /**
     * Retrieve a particular season
     * @param season
     * @return the current seasson
     */
    public String getSeason(Season season) {
        return seasonMap.get(season);
    }

    /**
     *
     * @return the total number of seasons present
     */
    public static int getNumberOfSeasons() {
        return Season.values().length;
    }
}




