package Climate;

import SimulatorHelpers.Randomizer;

import java.util.Random;

/**
 * WINTER lasts from December - February
 *  Conditions are very cold - high precipitation levels and low temperatures
 *  Spring ranges from December - February
 *  OR from Yulemath-Solmath
 *  @version 2022-03-01
 */
public class WinterWeather extends Weather{
    //The coldest temperature in degrees celsius on Middle Earth - modelled to be similar to West Midlands
    private static final double WINTER_TEMPERATURE = -1;

    //Amount of precipitation on Middle Earth in millimetres
    private static final double WINTER_PRECIPITATION = 180;

    //The time at which the sun rises given the season
    //actual time is 8:04am
    private static final int SUNRISE_TIME = 8;

    //The time at which the sun sets given the season
    //actual time is 3:55pm

    private static final int SUNSET_TIME = 16;
    //Random object that is shared for all objects in autumn
    private static Random rand;

    /**
     * Default constructor
     */
    public WinterWeather() {
        rand = Randomizer.getRandom();
    }

    /**
     *
     * @return the random temperature on a certain day in +- 3 range.
     */
    @Override
    public double getTemperature() {
        double temperature = rand.nextInt(6) + WINTER_TEMPERATURE-3;
        return temperature;
    }

    /**
     *
     * @return the random precipitation on a certain day in +- 6 range.
     */
    @Override
    public double getPrecipitation() {
        double precipitation = rand.nextInt(12) + WINTER_PRECIPITATION-6.0;
        return precipitation;
    }

    /**
     *
     * @return the time the Sun rises in Autumn
     */
    @Override
    public int getSunriseTime() {
        return SUNRISE_TIME;
    }

    /**
     *
     * @return the time the Sun sets in Spring
     */
    @Override
    public int getSunsetTime() {
        return SUNSET_TIME;
    }
}
