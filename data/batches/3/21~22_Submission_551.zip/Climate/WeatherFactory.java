package Climate;

/**
 * The WeatherFactory determines which of the seasons are called depending on the monthTimer.
 *
 *  @version 2022-03-01
 */
public class WeatherFactory {

    /**
     * Default constructor
     */
    public WeatherFactory() {
    }

    /**
     * Gets corresponding class in accordance to the season.
     * @param season the current season
     * @return the current whether
     */
    public Weather getWeather(Season season) {
        if (season == Season.SUMMER) {
            return new SummerWeather();
        }
        else if (season == Season.WINTER) {
            return new WinterWeather();
        }else if (season == Season.SPRING) {
            return new SpringWeather();
        }else if (season == Season.AUTUMN) {
            return new AutumnWeather();
        }
        return null;
    }

}
