package Climate;

import SimulatorHelpers.Randomizer;

import java.util.Random;

/**
 * Conditions are in between Winter and Summer Weather
 * Spring ranges from March - May
 * OR from Rethe - Thrimidge
 * @version 2022-03-01
 */
public class SpringWeather extends Weather {
    //temperature in degrees celsius on Middle Earth - modelled to be similar to West Midlands
    private static final double SPRING_TEMPERATURE = 3.2;

    //Amount of precipitation on Middle Earth in millimetres
    private static final double SPRING_PRECIPITATION = 180;

    //The time at which the sun rises given the season
    //actual time is 7:11am.
    private static final int SUNRISE_TIME = 7;

    //The time at which the sun sets given the season
    //actual time is 5:28 pm.
    private static final int SUNSET_TIME = 17;

    //Random object that is shared for all objects in autumn
    private static Random rand;

    /**
     * Initialised according to the time that the program is run
     */
    public SpringWeather() {
        rand = Randomizer.getRandom();
    }

    /**
     *
     * @return the random temperature on a certain day in +- 3 range.
     */
    @Override
    public double getTemperature() {
        double temperature = rand.nextInt(6) + SPRING_TEMPERATURE-3;
        return temperature;
    }

    /**
     *
     * @return the random precipitation on a certain day in +- 6 range.
     */
    @Override
    public double getPrecipitation() {
        double precipitation = rand.nextInt(12) + SPRING_PRECIPITATION-6;
        return precipitation;
    }

    /**
     *
     * @return the time the Sun rises in Spring
     */
    @Override
    public int getSunriseTime() {
        return SUNRISE_TIME;
    }

    /**
     *
     * @return the time the Sun sets in Spring
     */
    @Override
    public int getSunsetTime() {
        return SUNSET_TIME;
    }
}
