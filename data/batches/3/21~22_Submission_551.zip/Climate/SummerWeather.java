package Climate;

import SimulatorHelpers.Randomizer;

import java.util.Random;

/**
 * Summer lasts from June - August
 * OR from Lithe - Wedmath
 * @version 2022-03-01
 */
public class SummerWeather extends Weather{
    //https://www.bristol.ac.uk/university/media/press/10013-english.pdf

    //The hottest temperature in degrees celsius Middle Earth - modelled to be similar to West Midlands
    private static final double SUMMER_TEMPERATURE = 16.8;

    //Amount of precipitation on Middle Earth in millimetres
    private static final double SUMMER_PRECIPITATION = 135.2;


    //Figure out a formula comparing temperature, precipitation,

    //The time at which the sun rises given the season
    //actual time is 4:45am.
    private static final int SUNRISE_TIME = 5;

    //The time at which the sun rises given the season
    //actual time is 11:22 pm.
    private static final int SUNSET_TIME = 23;

    //Random object that is shared for all objects in autumn
    private static Random rand;
    /**
     * Initialised according to the time that the program is run
     */
    public SummerWeather() {
        rand = Randomizer.getRandom();
    }

    /**
     *
     * @return the random temperature on a certain day in +- 3 range.
     */
    @Override
    public double getTemperature() {
        double temperature = rand.nextInt(6) + SUMMER_TEMPERATURE-3;
        return temperature;
    }

    /**
     *
     * @return the random precipitation on a certain day in +- 6 range.
     */
    @Override
    public double getPrecipitation() {
        double precipitation = rand.nextInt(12) + SUMMER_PRECIPITATION-6;
        return precipitation;
    }

    /**
     *
     * @return the time the Sun rises in Spring
     */
    @Override
    public int getSunriseTime() {
        return SUNRISE_TIME;
    }

    /**
     *
     * @return the time the Sun sets in Spring
     */
    @Override
    public int getSunsetTime() {
        return SUNSET_TIME;
    }


}
