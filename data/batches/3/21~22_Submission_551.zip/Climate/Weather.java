package Climate;

/**
 * Weather is dependent on several factors that are overridden in their respective seasons
 * @version 2022-03-01
 */
public abstract class Weather {


    /**
     * Change the average temperature depending on the type of season experienced
     */
    public abstract double getTemperature();

    /**
     * Change the amount of precipitation depending on the type of season
     *
     */
    public abstract double getPrecipitation();

    /**
     * The time at which the sun rises
     * @return the hour at which the sun rises
     */
    public abstract int getSunriseTime() ;

    /**
     * The time at which the sun sets
     * @return the hour at which the sun sets
     */
    public abstract int getSunsetTime();

}
