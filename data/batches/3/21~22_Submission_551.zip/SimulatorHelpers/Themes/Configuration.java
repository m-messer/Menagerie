package SimulatorHelpers.Themes;

import javafx.scene.paint.Color;

/**
 * This class is intended to be the coordinator of UI themes for the program. The tasks of this class is to provide style information about UI
 * for the intended classes. This class by default is set to dark mode.
 * @version 2022-03-01
 * */
public class Configuration {

    /**
     * Every element in the array represent the value of the item according, and its position indicate which theme it belongs too according
     * to the themes variable. For Example, in animalColors, 2 arrays, the 1st array represent the value in the 1st theme in themes array.
     */
    private static final String[] themes = {"Light Theme", "Dark Theme"};
    private static final Color[] defaultCellColors = {Color.WHITE, Color.GRAY};
    private static final Color[] simulatorBackgroundColor = {Color.BLACK, Color.BLACK};
    private static final Color[][] animalColors = {{new Color(74/255.0, 125/255.0, 226/255.0,1), new Color(108/255.0, 26/255.0, 175/255.0,1), new Color(223/255.0, 36/255.0, 36/255.0,1),new Color(94/255.0, 169/255.0, 67/255.0,1),new Color(48/255.0, 182/255.0, 160/255.0,1),new Color(206/255.0, 191/255.0, 116/255.0,1)},{new Color(66/255.0, 33/255.0, 0/255.0,1), new Color(21/255.0, 53/255.0,117/255.0,1), new Color(134/255.0, 30/255.0, 30/255.0,1),new Color(35/255.0, 0/255.0, 25/255.0,1),new Color(19/255.0, 80/255.0, 69/255.0,1),new Color(0/255.0,51/255.0,51/255.0,1)}};
    private static final Color[][] plantColors = {{new Color(102/255.0,102/255.0,255/255.0,1)}, {new Color(204/255.0,0/255.0,102/255.0,1)}};
    private static final Color[] heightBaseColor = {new Color(0/255.0, 138/255.0, 76/255.0,1), new Color(138/255.0, 0/255.0, 83/255.0,1)};
    private static final String[] simulatorFXPaths = {"res/Styles/SimulatorFXUI/light.css","res/Styles/SimulatorFXUI/dark.css"};
    private static final String[] aboutFXPaths = {"res/Styles/AboutFXUI/light.css","res/Styles/AboutFXUI/dark.css"};
    private static final String[] graphsFXPaths = {"res/Styles/Graphs/light.css","res/Styles/Graphs/dark.css"};
    private static int pointer = 1;

    // FontsPaths is the only exception to the above rule as fonts are part of the theme, hence the class and the package, but they are exact through all themes
    // Font references: https://www.fontspace.com/ringbearer-font-f2246/, https://www.freefonts.io/candara-font/
    private static final String[] fontsPaths = {"/res/Fonts/RingbearerMedium-51mgZ.ttf","/res/Fonts/Candara.ttf"};

        /**
         * This method sets the configuration pointer to either light mode when the user's local time in the device is between 6:00 to 19:00 EXCLUSIVE
         * and to dark mode between 19:00 to 6:00 INCLUSIVE
         */
    public static void setModeAccordingToDeviceTime() {
        //https://www.javatpoint.com/java-get-current-date
        if (java.time.LocalTime.now().getHour() > 19 || java.time.LocalTime.now().getHour() < 6)
            pointer = 1;
        else
            pointer = 0;
    }

    /**
     * This method sets the configuration to point to the next theme, rounding about if there is no next theme.
     */
    public static void nextPointer() {
        pointer = (pointer+1)%themes.length;
    }

    /**
     * This method returns the name of the next color theme that this class point to.
     * @return theme name
     */
    public static String getNextThemeName() {
        return themes[(pointer+1)%themes.length];
    }


    /**
     * This method returns the default color for an empty cell in the simulator.
     * @return default cell color
     */
    public static Color getDefaultCellColor() {
        return defaultCellColors[pointer];
    }

    /**
     * This method returns the simulator's background color according to the current theme.
     * @return simulator's background color
     */
    public static Color getSimulatorBackgroundColor() {
        return simulatorBackgroundColor[pointer];
    }


    /**
     * This method returns the colors that represents the animals IN the same order as they defined in the simulator class
     * @return animal colors array
     */
    public static Color[] getAnimalColors() {
        return animalColors[pointer];
    }

    /**
     * This method returns the colors that represents the plants IN the same order as they defined in the simulator class
     * @return plant colors array
     */
    public static Color[] getPlantColors() {
        return plantColors[pointer];
    }

    /**
     * This method returns the color that the height functionality would be based on according to the current theme
     * @return the height base color
     */
    public static Color getHeightBaseColor() {
        return heightBaseColor[pointer];
    }

    /**
     * This method returns the CSS stylesheet path that is used in the simulatorViewFX class according to the current theme.
     * @return CSS stylesheet path
     */
    public static String getCurrentSimulatorFXPaths() {
        return simulatorFXPaths[pointer];
    }


    /**
     * This method returns the CSS stylesheet path that is used in the aboutViewFX class according to the current theme.
     * @return CSS stylesheet path
     */
    public static String getCurrentAboutFXPaths() {
        return aboutFXPaths[pointer];
    }

    /**
     * This method returns the CSS stylesheet path that is used on Graphs classes according to the current theme.
     * @return CSS stylesheet path
     */
    public static String getCurrentGraphFXPaths() {
        return graphsFXPaths[pointer];
    }

    /**
     * This method returns an array with the paths for fonts
     * @return an array with the paths for fonts
     */
    public static String[] getFontsPaths() {
        return fontsPaths;
    }
}
