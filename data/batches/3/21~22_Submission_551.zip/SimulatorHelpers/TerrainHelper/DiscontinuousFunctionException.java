package SimulatorHelpers.TerrainHelper;

/**
 *
 * This class represent a possible exception when choosing values that are incompatible with the heightHelper nature.
 * Mainly, if a number is NaN or infinite.
 *
 * @version 2022-03-01
 */
public class DiscontinuousFunctionException extends Exception{

    /**
     * This method throws the designated exception.
     */
    public DiscontinuousFunctionException() {
        super("Illegal value. The function has to be continuous finite and a number. Infinity and NaN cannot be processed");
    }
}
