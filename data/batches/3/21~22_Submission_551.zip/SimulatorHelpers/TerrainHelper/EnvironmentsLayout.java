package SimulatorHelpers.TerrainHelper;

/**
 *
 * This class is part of the TerrainHelper package, which indicate that this class is intended to act as a helper class
 * to the simulator's terrain.
 *
 * This enum is intended to provide representation of the available layouts of the field view.
 *
 * @version 2022-03-01
 */
public enum EnvironmentsLayout {
    HEIGHT,
    PLANTS,
    ANIMALS;
}
