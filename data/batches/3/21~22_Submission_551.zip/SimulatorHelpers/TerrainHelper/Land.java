package SimulatorHelpers.TerrainHelper;

import Creatures.Animals.Animal;
import Creatures.Plants.Plant;

/**
 * This class is part of the TerrainHelper package, which indicate that this class is intended to act as a helper class
 * to the simulator's terrain.
 *
 * This class is intended to represent a cell in the simulator, where each cell is a land that can have some properties,
 * such as height, and can be occupied by some creatures depending on its layout. A land has a height property, and have
 * two layers, one for plants, and the other for animals.
 *
 * @version 2022-03-01
 */

public class Land {

    // Lands height
    private double height;
    // The occupies of the land
    private Plant plant;
    private Animal animal;

    /**
     * This method construct a land with all its necessary information
     * @param height Land's height
     */
    public Land(double height) {
        this.height = height;
    }

    /**
     * This method sets the animal in this land
     * @param animal the animal
     */
    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    /**
     * This method sets the plant in this land
     * @param plant the plant
     */
    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    /**
     * This method returns the animal that occupies this land
     * @return The animal that occupies this land
     */
    public Animal getAnimal() {
        return animal;
    }

    /**
     * This method returns the plant that occupies this land
     * @return The plant that occupies this land
     */
    public Plant getPlant() {
        return plant;
    }

    /**
     * This method returns the height in a presentable format. This method is created since height is not an object
     * that its toString can be overridden
     * @return the height in a representable format
     */
    public String getFormativeHeight() {
        return "Height: " + height;
    }

    /**
     * This method returns the height of the map
     * @return The height of the land
     */
    public double getHeight() {
        return height;
    }
}
