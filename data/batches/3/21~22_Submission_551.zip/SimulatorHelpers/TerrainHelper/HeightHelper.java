package SimulatorHelpers.TerrainHelper;

/**
 * This class is part of the TerrainHelper package, which indicate that this class is intended to act as a helper class
 * to the simulator's terrain.
 *
 * This class is intended to aid the field view by providing the heights of lands and their colors, according to the
 * difference in their heights.
 *
 * @version 2022-03-01
 */

public class HeightHelper {

    // The increase in alpha that correspond to an increase in 1 from the minimum height
    private double sigmaAlpha;
    // Minimum and Maximum height of the field
    private double minHeight, maxHeight;

    /**
     * This method construct this class with the necessary settings.
     */
    public HeightHelper() {
        sigmaAlpha = 0;
        minHeight = Double.MAX_VALUE;
        maxHeight = Double.MIN_VALUE;
    }

    /**
     * This method perform an additional check on the value that the function has provided in order to eliminate
     * illegal values that will cause unexpected faulty behaviour. This method throws an exception if the value is
     * NaN or the value's magnitude is infinite.
     * @param val the value to be checked.
     */
    private void checkVNumberValidity(double val) {
        if (Double.isInfinite(val) || Double.isNaN(val)) {
            try {
                throw new DiscontinuousFunctionException();
            } catch (DiscontinuousFunctionException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     *
     * This method returns the height of a function according to the pre-assigned continues function while performing
     * the required checks to validate the value.
     *
     * @param dDis depth displacement
     * @param wDis width displacement
     * @return the height
     */
    private double returnHeight(int dDis, int wDis) {
        double val = Double.NaN;
        try {
            val = ((int) ((Math.cos(1.435 * dDis) * Math.sin(dDis) * 0.3 * dDis + 0.09 * wDis) * 100)) / 100.0;
        }catch (ArithmeticException e) {
            try {
                throw new DiscontinuousFunctionException();
            } catch (DiscontinuousFunctionException ex) {
                ex.printStackTrace();
            }
        }

        checkVNumberValidity(val);

        return val;
    }

    /**
     *
     * This method returns the height of a function according to the pre-assigned continues function
     * and invoke the registerValues functions to update the class's setting.
     *
     * @param depth y position
     * @param width x position
     * @return the height
     */
    public double getHeightForPosition(int depth, int width) {
        double val = returnHeight(width,depth);
        registerValues(val);
        return val;
    }

    /**
     * This method updates the class's information, minimum and maximum values according to the generated value.
     * @param val height
     */
    private void registerValues(double val) {
        if (val < minHeight)
            minHeight = val;
        if (val > maxHeight)
            maxHeight = val;
    }

    /**
     * This method is used to determine the number of increase in alpha in a change of 1 height from the minimum.
     * The rationale behind the formula is the sum of the absolute values of maximum and minimum is the range of
     * heights, then, divided it by 255, the possible alphas in javaFX color class, will yield the required increase
     * in alpha per 1 change in height.
     */
    public void setSigmaAlpha() {
        sigmaAlpha = (Math.abs(maxHeight)+Math.abs(minHeight))/255;
    }

    /**
     *
     * This method returns the alpha of the provided height in the rational that every 1 difference from the
     * minimum height increases the alpha by sigmaAlpha, which is chosen to allow every possible alpha to be
     * a set of distinct heights
     *
     * @param height land's height
     * @return the alpha of that land [0-1]
     */
    public double getAlpha(double height) {
        int alpha = (int)((height+ Math.abs(minHeight))/sigmaAlpha);
        // For safety, although v's value should not be outside [1-255] according to the used formula
        alpha = Math.min(alpha, 255);
        alpha = Math.max(0, alpha);

        return alpha/255.0;
    }

    /**
     * This method returns the maximum height of land in the simulator
     * @return maximum height
     */
    public double getMaxHeight() {
        return maxHeight;
    }

    /**
     * This method returns the minimum height of land in the simulator
     * @return minimum height
     */
    public double getMinHeight() {
        return minHeight;
    }


}