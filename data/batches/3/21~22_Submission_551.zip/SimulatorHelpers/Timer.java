package SimulatorHelpers;

/**
 * Adapted from Clock Display method by David J.Barnes and Michael Kolling
 * Keeps track of the time
 * @version 2022-03-01
 */
public class Timer {
    //---- Value at which timer resets ----//
    private int limit;

    //---- Stores the current value ----//
    private int currentStep;

    /**
     * Initialising a new Timer object
     * @param rollOverLimit the limit at which the timer resets
     * Must not have an integer less than 0.
     */
    public Timer(int rollOverLimit) {
        limit = rollOverLimit;
    }

    /**
     * Empty constructor for timers without a limit
     */
    public Timer() {

    }

    /**
     * Returns the display value as a String
     * Adds a 0 if it's a single digit
     * @return the display value
     */
    public String getDisplayValue () {
        if (currentStep < 10) {
            return "0" + currentStep;
        }
        else {
            return "" + currentStep;
        }
    }

    /**
     * Returns the current step
     * @return the current step
     */
    public int getCurrentStep() {
        return currentStep;
    }

    /**
     * Checks to see if the step is about to roll over
     * @return whether or not the step is at the limit
     */
    public boolean rollingOver() {
        return currentStep % limit == 0;
    }

    /**
     * Increments the current step by 1
     * If the limit is reached, the steps rolls back to 0
     */
    public void increment() {
        currentStep = (currentStep + 1) % limit;
    }

    /**
     * Increments the currentStep by the given value
     * Must not be given a negative value
     * @param incrementBy the number of increments
     */
    public void increment(int incrementBy) {
        currentStep = (currentStep + incrementBy) % limit;
    }

    /**
     * Increments the step indefinitely
     */
    public void incrementWithoutLimit() {
        currentStep++;
    }

    /**
     * Resets the counter back to 0
     */
    public void reset() {
        currentStep = 0;
    }

}
