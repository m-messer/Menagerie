package SimulatorHelpers;

import SimulatorHelpers.StatisticsRegisters.CreatureRegister;
import SimulatorHelpers.TerrainHelper.Field;

import java.util.*;

/**
 * This class collects and provides some statistical data on the state 
 * of a field. It is flexible: it will create and maintain a counter 
 * for any class of object that is found within the field.
 *
 * @version 2022-03-01
 */
public class FieldStats {
    // Counters for each type of entity (orcs, hobbit, etc.) in the simulation.
    private final HashMap<Class, Counter> animalCounter;
    // Whether the counters are currently up to date.
    private boolean countsValid;

    /**
     * Construct a SimulatorHelpers.FieldStats object.
     */
    public FieldStats() {
        // Set up a collection for counters for each type of animal that
        // we might find
        animalCounter = new HashMap<>();
        countsValid = true;

    }

    /**
     *
     * This method returns the number of animals of the provided key
     *
     * @param key the requested animal
     * @param field the field of the animals
     * @return the count of a specific class
     */
    public int getPopulationClassCount(Class key, Field field) {
        if (!countsValid)
            generateCounts(field);
        checkCounter(key);

        return animalCounter.get(key).getCount();
    }

    /**
     * This method creates an animal counter for the key if the key is not on the animal counter
     * @param key the class to be checked against
     */
    private void checkCounter(Class key) {
        Counter count = animalCounter.get(key);
        if (count == null) {
            // We do not have a counter for this species yet.
            // Create one.
            count = new Counter(key.getName());
            animalCounter.put(key, count);
        }
    }


    
    /**
     * Invalidate the current set of statistics; reset all 
     * counts to zero.
     */
    public void reset() {
        countsValid = false;
        for (Class key : animalCounter.keySet()) {
            Counter count = animalCounter.get(key);
            count.reset();
        }
    }

    /**
     * Increment the count for one class of animal.
     * @param animalClass The class of animal to increment.
     */
    public void incrementCount(Class animalClass) {
        checkCounter(animalClass);
        animalCounter.get(animalClass).increment();
    }

    /**
     * Indicate that an animal count has been completed.
     */
    public void countFinished() {
        countsValid = true;
    }

    /**
     * This method register the current animal's statistics into the register
     */
    public void registerCreaturesValues() {
        CreatureRegister.registerValues(animalCounter);
    }

    /**
     * Determine whether the simulation is still viable.
     * I.e., should it continue to run.
     * @param field the field
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field) {
        // How many counts are non-zero.
        int nonZero = 0;
        if (!countsValid)
            generateCounts(field);

        for (Class key : animalCounter.keySet()) {
            Counter info = animalCounter.get(key);
            if (info.getCount() > 0) {
                nonZero++;
            }
        }
        return nonZero != 0;
    }
    
    /**
     * Generate counts of the number of orcs and hobbits.
     * These are not kept up to date as orcs and hobbits
     * are placed in the field, but only when a request
     * is made for the information.
     * @param field The field to generate the stats for.
     */
    private void generateCounts(Field field) {
        reset();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getLandAt(row, col).getPlant();
                if (animal != null) {
                    incrementCount(animal.getClass());
                }
            }
        }
        countsValid = true;
    }
}
