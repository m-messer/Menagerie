package SimulatorHelpers;

/**
 * Simulator class which defines the speed at which the Simulation should run
 * The faster the simulation, the lower the number
 * @version 2022-03-01
 */
public enum SimulatorSpeed {
    //---- Types of speeds available in the simulation ----//
    VERY_SLOW(0),
    SLOW(1),
    NORMAL(2),
    FAST(3),
    VERY_FAST(4);

    //---- Current value ----//
    private int currentValue;

    /**
     * Sets the current vale to the newValue
     * @param newValue the new speed
     */
    SimulatorSpeed(final int newValue) {
        this.currentValue = newValue;
    }

    /**
     * @return the current value
     */
    public int getValue() {
        return currentValue;
    }

}

