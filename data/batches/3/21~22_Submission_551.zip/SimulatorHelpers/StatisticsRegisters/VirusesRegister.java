package SimulatorHelpers.StatisticsRegisters;

import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder;
import org.apache.commons.lang3.tuple.MutablePair;

import java.util.Arrays;

import Simulator.Simulator;

/**
 *
 * This class is part of the StatisticsRegister package, which indicate that this class is specialized in storing data
 * that will be used for statistical purposes.
 *
 * This class stores the relevant data about viruses and their infection and mortality. This class is equipped to store
 * the infection and mortality numbers per step. This class uses ListMultiMap to store the data. Every key is the name
 * of the virus, and they map to a list of pairs, in which the left pair is the step, while the right is the total number
 * of mortality or infection.
 *
 * @version 2022-03-01
 * REFERENCE: https://github.com/google/guava/wiki/NewCollectionTypesExplained
 */
public class VirusesRegister {

    // Records variables, Viruses information, death records and infection records respectively
    private static ListMultimap<String, Double> registeredViruses = MultimapBuilder.treeKeys().arrayListValues().build();
    private static ListMultimap<String, MutablePair<Integer, Integer>> virusesDeathsRecords = MultimapBuilder.treeKeys().arrayListValues().build();
    private static ListMultimap<String, MutablePair<Integer, Integer>> virusesInfectionRecords = MultimapBuilder.treeKeys().arrayListValues().build();
    // The simulator
    private static Simulator simulator;

    /**
     * This method provides the register with the reference of the simulator in order to retrieve the current step.
     * @param simulator the simulator
     */
    public static void setSimulator(Simulator simulator) {
        VirusesRegister.simulator = simulator;
    }

    /**
     * This method register the viruses and its information in the viruses records
     * @param receptor the viruses receptor
     * @param information the viruses information
     */
    public static void registerVirus(int[] receptor, Double[] information) {
        registeredViruses.putAll(Arrays.toString(receptor), Arrays.asList(information));
    }

    /**
     * This method returns the number of distinct registered viruses
     * @return the number of distinct registered viruses
     */
    public static int getNumberOfRegisteredViruses() {
        return registeredViruses.keySet().size();
    }

    /**
     * This method return the record that contains the viruses information
     * @return viruses record
     */
    public static ListMultimap<String, Double> getVirusesInformation() {
        return registeredViruses;
    }

    /**
     * This method record an infection that caused by the provided virus into the records.
     * @param receptor the virus that caused infection
     */
    public static void recordInfection(int[] receptor) {

        String virusName = Arrays.toString(receptor);

        //Left is the steps, right is the number of deaths
        if (virusesInfectionRecords.containsKey(virusName))
            if (virusesInfectionRecords.get(virusName).get(virusesInfectionRecords.get(virusName).size()-1).getLeft() == simulator.getStep())
                virusesInfectionRecords.get(virusName).get(virusesInfectionRecords.get(virusName).size()-1).setRight(virusesInfectionRecords.get(virusName).get(virusesInfectionRecords.get(virusName).size()-1).getRight()+1);
            else
                virusesInfectionRecords.get(virusName).add(new MutablePair<>(simulator.getStep(), 1));
        else
            virusesInfectionRecords.put(virusName, new MutablePair<>(simulator.getStep(), 1));
    }

    /**
     * This method record a death that caused by the provided virus into the records.
     * @param receptor the virus that caused death
     */
    public static void recordDeath(int[] receptor) {

        String virusName = Arrays.toString(receptor);

        //Check if the virus is in the records to either increase the existed record (if it is on the same step) or create a new one.
        if (virusesDeathsRecords.containsKey(virusName))
            if (virusesDeathsRecords.get(virusName).get(virusesDeathsRecords.get(virusName).size()-1).getLeft() == simulator.getStep())
                virusesDeathsRecords.get(virusName).get(virusesDeathsRecords.get(virusName).size()-1).setRight(virusesDeathsRecords.get(virusName).get(virusesDeathsRecords.get(virusName).size()-1).getRight()+1);
            else
                virusesDeathsRecords.get(virusName).add(new MutablePair<>(simulator.getStep(), 1));
        else
              virusesDeathsRecords.put(virusName, new MutablePair<>(simulator.getStep(), 1));


    }

    /**
     * This method returns the death record from viruses
     * @return the death record
     */
    public static ListMultimap<String, MutablePair<Integer, Integer>> getVirusesDeathsRecords() {
        return virusesDeathsRecords;
    }

    /**
     * This method returns the infection record from viruses
     * @return the infection record
     */
    public static ListMultimap<String, MutablePair<Integer, Integer>> getVirusesInfectionRecords() {
        return virusesInfectionRecords;
    }

    /**
     * This method reset the records
     */
    public static void reset() {
        registeredViruses = MultimapBuilder.treeKeys().arrayListValues().build();
        virusesDeathsRecords = MultimapBuilder.treeKeys().arrayListValues().build();
        virusesInfectionRecords = MultimapBuilder.treeKeys().arrayListValues().build();
    }

}
