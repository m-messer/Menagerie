package SimulatorHelpers.StatisticsRegisters;

import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder;

import SimulatorHelpers.Counter;
import java.util.HashMap;

/**
 *
 * This class is part of the StatisticsRegister package, which indicate that this class is specialized in storing data
 * that will be used for statistical purposes.
 *
 * This class uses a listMultiMap to store the records. Every key in the hashmap a creature of type class, and it maps
 * to an ordered list that contains its count while indices of the list represents steps.
 *
 * @version 2022-03-01
 * REFERENCE: https://github.com/google/guava/wiki/NewCollectionTypesExplained
 */
public class CreatureRegister {

    // The data structure that will store the counts
    private static ListMultimap<String, Integer> creaturesRecords = MultimapBuilder.treeKeys().arrayListValues().build();

    /**
     * This method registers the provided values into the register
     * @param record the creatures' record
     */
    public static void registerValues(HashMap<Class, Counter> record) {
        for (Class counter : record.keySet()) {
            if (creaturesRecords.containsKey(counter.getName()))
                creaturesRecords.get(counter.getName()).add(record.get(counter).getCount());
            else
                creaturesRecords.put(counter.getName(), record.get(counter).getCount());
        }
    }

    /**
     * This method rest the creatures' count record.
     */
    public static void reset() {
        creaturesRecords = MultimapBuilder.treeKeys().arrayListValues().build();
    }

    /**
     * This method returns the creatures' count record of the simulator.
     * @return creatures' count record
     */
    public static ListMultimap<String, Integer> retrieveCreaturesStats() {
       return creaturesRecords;
    }
}
