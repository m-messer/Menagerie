import Simulator.Windows.SimulatorViewFX;
import Simulator.UIManagers.StageManager;
import SimulatorHelpers.Themes.Configuration;
import javafx.application.Application;

/**
 * This class is intended to be the start point of the program
 *
 * @version 2022-03-01
 */
public class Main {

    /**
     * This method is intended to run the program and set up the most fundamental calls for the UI
     * @param args arguments
     */
    public static void main(String[] args) {
        // Set the UI mode to user's device time
        Configuration.setModeAccordingToDeviceTime();
        new StageManager();
        // Reference: https://stackoverflow.com/questions/25873769/launch-javafx-application-from-another-class. User: ThisClark Date Apr 23, 2016
        // This check is intended to prevent multiple runs exceptions, which blueJ permits you to do.
        try {
            Application.launch(SimulatorViewFX.class, args);
        }catch (Exception exception){
            System.out.println("You cannot launch the application more than once. Please close the current one and ensure it closes from your JVM.");
        }
    }
}
