package Genes;

import SimulatorHelpers.StatisticsRegisters.VirusesRegister;

/**
 *
 * This class is part of the Genes package, which indicate that this class is mainly designed to perform or represent genes or their operations.
 *
 * This class is intended to represent viruses in the simulation, including all their specific properties. It is important to note
 * that a virus is only represented by one gene which include all the necessary information.
 *
 * Every virus does represent three distinct information in its genomic sequence.
 *      1- Receptor. Position 0-19 Inclusive
 *      2- Death probability. Position 20-24 Inclusive
 *      3- Infection probability. Position 25-32 Inclusive
 *
 * The receptor of the virus plays an important role in its identification in relation to other viruses. Death and infection probability indicates the effectiveness of the virus itself.
 *
 *
 * The values are being translated according to the logic that is elaborated in geneTranslator method in GeneTools.
 *
 * @version 2022-03-01
 */
public class Virus extends Gene{

    // The basic information of a virus. The position variables indicate the information bound on the gene itself
    // The base indicates which negative exponent the probability is going to start with for assigning the values or infection
    // and/or death. This is highly crucial, and it's role explained in full detail in geneTranslator method in GeneTools class.
    private final static int DAMAGE_BASE = 2;
    private final static int DAMAGE_START_POSITION = 20;
    private final static int DAMAGE_END_POSITION = 24;
    private final static int INFECTION_BASE = 2;
    private final static int INFECTION_START_POSITION = 25;
    private final static int INFECTION_END_POSITION = 32;


    /**
     *
     * This method construct a virus with assigning an infection probability and death probability in a genomic way.
     * Moreover, this class register the viruses' information into VirusesRegister class, which the rationale behind this
     * design decision is explained there.
     *
     * @param geneValue Gene values
     */
    public Virus(int[] geneValue) {
        super(GeneTools.concatenateGene(geneValue, GeneTools.GenerateGenes(false,1,12)[0].getGeneValue()));
        VirusesRegister.registerVirus(getReceptor(), new Double[]{getInfectionProbability(), getSicknessProbability()});
    }

    /**
     * This method returns the infection probability of a virus
     * @return the infection probability of a virus
     */
    public double getInfectionProbability() {
        return GeneTools.geneTranslator(getGeneValue(), INFECTION_BASE, INFECTION_START_POSITION, INFECTION_END_POSITION);
    }

    /**
     * This method returns the sickness probability of a virus
     * @return the sickness probability of a virus
     */
    @Override
    public double getSicknessProbability() {
        return GeneTools.geneTranslator(getGeneValue(), DAMAGE_BASE, DAMAGE_START_POSITION, DAMAGE_END_POSITION);
    }

}
