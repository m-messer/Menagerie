package Genes;

import SimulatorHelpers.Randomizer;

import java.util.Random;

/**
 *
 * This class is part of the Genes package, which indicate that this class is mainly designed to perform or represent genes or their operations.
 *
 * This class is intended to include tools that will be used by the Gene classes in order to perform basic operations. The main
 * reason of the existence of this class is provided help to other Gene classes with too fundamental operations. The factoring out
 * of this class allows to, when needed, to change the base operations in which the gene functionality works on.
 *
 * @version 2022-03-01
 */
public class GeneTools {

    /**
     *
     * This method translates a gene into a numeric value. The logic behind the translator is that the geneValue is perceived as a value in an unsigned
     *  binary format. This method uses the exact methodology the is being used in translating the decimal part of a binary number to its decimal format
     *  in a fixed point system. As a side note, the decimal part of a number is converted to its binary representation by multiplying the binary value by 1/2^p
     *  which p is the position of the number. In which, the provided base act as the new base, instead of the origin (1/2^p) base, in the negative number spectrum,
     *  the new value would be (1/2^base).
     *
     * For example, 1001  with base 2 would translate to
     *          1*(1/2^2) + 0*(1/2^3) + 0*(1/2^4) + 1*(1/2^5).
     *
     * @param geneValue the gene value
     * @param base the base of the translation
     * @param startPosition the start position of the targeted value
     * @param endPosition the end position of the targeted value
     * @return The value of the gene
     */
    public static double geneTranslator(int[] geneValue, int base, int startPosition, int endPosition) {
        double prob = 0;

        int counter = base;

        for (int i = startPosition; i < endPosition; i++) {
            prob += (geneValue[i] * (1.0 / Math.pow(2, counter)));
            counter++;
        }

        return prob;
    }

    /**
     * This method create an array of genes based on the provided specifications.
     *
     * @param sex Is this gene has sex or not
     * @param numberOfGenes Number of genes
     * @param codesPerGene Number of codes per gene
     * @return An array of genes
     */
    public static Gene[] GenerateGenes(boolean sex, int numberOfGenes, int codesPerGene) {
        Random rand = Randomizer.getRandom();
        Gene[] aj = new Gene[numberOfGenes];

        for (int i = 0; i < aj.length; i++) {
            if (i == 0 && sex) { // the first position is the sex gene
                aj[0] = new Gene(new int[]{rand.nextInt(2)});
            }else{
                int[] g = new int[codesPerGene];
                for (int j = 0; j < g.length; j++)
                    if (j == 20) // 20 is the position that will determine if the gene is harmful or not.
                        g[j] = 0;
                    else
                        g[j] = rand.nextInt(2);
                aj[i] = new Gene(g);
            }
        }

        return aj;
    }

    /**
     * This method return a genomic sequence that compromises of two genomic sequences
     *
     * @param g1 The first genomic sequence
     * @param g2 The second genomic sequence
     * @return A genomic sequence that has both genes in the same order of the parameters
     */
    public static int[] concatenateGene(int[] g1, int[] g2) {
        int[] concatenatedGene = new int[g1.length+ g2.length];

        System.arraycopy(g1, 0, concatenatedGene, 0, g1.length);
        System.arraycopy(g2, 0, concatenatedGene, g1.length, g2.length);

        return concatenatedGene;
    }

    /**
     * This method returns the complement of a genomic sequence. The complement operation is defined to be a bit flip for every element in the array.
     * For example, the complement of 101100 if 010011.
     *
     * @param values The binary gene sequence as an int array
     * @return The complement of the provided gene
     */
    public static int[] complement(int[] values) {
        int[] complement = new int[values.length];
        for (int i = 0; i < values.length; i++)
            complement[i] = (values[i] + 1)%2;

        return complement;
    }

}
