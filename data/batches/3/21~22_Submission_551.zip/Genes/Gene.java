package Genes;

import java.util.Arrays;

/**
 * This class is part of the Genes package, which indicate that this class is mainly designed to perform or represent genes or their operations.
 *
 * This class represent a single gene with all the information it needs to perform its functionality.
 *
 * Every gene does represent two distinct information in its genomic sequence.
 *      1- Receptor. Position 0-19 Inclusive
 *      2- A value. Position 20-32 Inclusive
 *
 * The receptor is used by viruses to attack. While the gene's value is the death probability that this genes caused if it endured a harmful
 * mutation. It is important to distinct between the value of a gene and the versus death probability.
 *
 * The values are being translated according to the logic that is elaborated in geneTranslator method in GeneTools.
 *
 * @version 2022-03-01
 */
public class Gene {

    //The position variables indicate the information bound on the gene itself.
    // The base indicates which negative exponent the probability is going to start with for assigning the values or infection
    // and/or death. This is highly crucial, and it's role explained in full detail in geneTranslator method in GeneTools class.
    private final static int BASE = 3;
    private final static int SICKNESS_START_POSITION = 20;
    private final static int SICKNESS_END_POSITION = 32;
    // The genomic sequence's information
    private final int[] geneValue;

    /**
     * This method construct a single Gene
     * @param geneValue the genomic sequence
     */
    public Gene(int[] geneValue) {
        this.geneValue = geneValue;
    }

    /**
     * This method returns the gene's genomic sequence
     * @return the genomic sequence
     */
    public int[] getGeneValue() {
        return geneValue;
    }

    /**
     * This Method returns the receptor of the gene.
     * @return An int array that represent a receptor
     */
    public int[] getReceptor() {
        return Arrays.stream(geneValue).limit(SICKNESS_START_POSITION).toArray();
    }

    /**
     * This method returns that starting position that the sickness probability is calculated on in the genomic sequence that matches the
     * rational in geneTranslator
     * @return the death probability starting position
     */
    public static int getSicknessStartPosition() {
        return SICKNESS_START_POSITION;
    }

    /**
     * This method returns the death probability from this gene. Note that this method is pre-assumed that it will only be called
     * in harmful genes.
     * @return the death probability from this gene.
     */
    public double getSicknessProbability() {
        return GeneTools.geneTranslator(geneValue, BASE, SICKNESS_START_POSITION, SICKNESS_END_POSITION);
    }
}
