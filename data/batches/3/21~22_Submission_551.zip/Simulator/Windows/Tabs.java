package Simulator.Windows;

/**
 * This enum's main functionality is to provide help when tracking the opened stages in the program
 * and provides id's to the items that trigger their opening
 *
 * @version 2022-03-01
 */
public enum Tabs {
    ABOUT_DEVELOPERS,
    ABOUT_SIMULATOR,
    CREATURES_STATISTICS,
    VIRUS_INFORMATION,
    VIRUS_PER_STEP_DEATHS,
    VIRUS_PER_STEP_INFECTIONS,
    VIRUS_TOTAL_DEATHS,
    VIRUS_TOTAL_INFECTIONS;

}
