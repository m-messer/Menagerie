package Simulator.Windows.Elements;

import SimulatorHelpers.Themes.Configuration;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * This class is part of Elements package, which indicate that this class is created as a helper class to explain, through graphical interface element, the
 * underling functionality or behaviour of the simulator.
 *
 * This class represents the field view of the simulator, in which the objects of the simulator are being represented. This class is designed to be responsive
 * and provides the needed functionality to preform this task. This class is highly inspired from the original field view that was coded by David J. Barnes and Michael KÃÂ¶lling dated on 2016.02.29,
 * however, this class was rewritten from scratch to accommodate with javaFX in the author's rational.
 *
 * @version 2022-03-01
 */

public class FieldView extends Canvas {

    // The graphics that will be used to draw
    private GraphicsContext gc = getGraphicsContext2D();
    // width and height of an arbitrary object on the field respectively
    private double xScale, yScale;
    // the number of cells on the horizontal and vertical axes respectively
    private final int totalXCells, totalYCells;

    /**
     * This method instantiate a canvas with providing the essential data the field needs to in order to be performs its tasks.
     *
     * @param depth number of cells on the vertical axes
     * @param width number of cells on the horizontal axes
     */
    public FieldView(int depth, int width) {
        super();
        totalXCells = width;
        totalYCells = depth;
        clear();
    }

    /**
     * This method transform a screen coordinates into a field coordinates
     * @param x x coordinate
     * @param y y coordinate
     * @return a double array with the new coordinates
     */
    public double[] onScale(double x, double y) {
        prepare();
        return new double[]{x/xScale, y/yScale};
    }

    /**
     * This method is intended to perform the subsequent tasks of changing the window's height. It is crucial that this method must not be removed
     * in favor of the overridden resize method as the overridden method does only the resize operation and does not clear the field to prepare it
     * for drawing with the new scale;
     *
     * @param width the new width
     * @param height the new height
     */
    public void onChange(double width, double height) {
        resize(width, height);
        clear();
    }

    /**
     * This method clear the simulator field from all drawings that represents objects.
     */
    public void clear() {
        gc.clearRect(0, 0, getWidth(), getHeight());
        gc.setFill(Configuration.getSimulatorBackgroundColor());
        gc.fillRect(0,0,getWidth(),getHeight());
    }

    /**
     * This method is intended to set the width and height of an object on the simulator in the rational that the width of an object would be the simulator field
     * width divided by the number of cells on the field and the same rational is applied to heights.
     */
    public void prepare() {
        xScale =  (getWidth()/totalXCells);
        yScale =  (getHeight()/totalYCells);
    }

    /**
     * This method performs the basic task of color a specific spot on the simulator field.
     *
     * @param x the x coordinate of the element
     * @param y the y coordinate of the element
     * @param color the color that the spot would have
     */
    public void draw(int x, int y, Color color) {
        gc.setFill(color);
        gc.fillRect(x*xScale,y*yScale,xScale-1,yScale-1);
    }


    /**
     * This method is intended to override the resizable attribute check on the parent class. Apparently, the default value the super method returns
     * for resizability is false, therefore, making the field not resizable.
     * @return True
     */
    @Override
    public boolean isResizable() {
        return true;
    }

    /**
     * This method is intended to override the superclass method for resizing, as the superclass is, apparently, is set to have a fix size.
     * @param width simulator's width
     * @param height simulator's height
     */
    @Override
    public void resize(double width, double height) {
        this.setWidth(width);
        this.setHeight(height);
    }
}
