package Simulator.Windows.Elements;

import SimulatorHelpers.Themes.Configuration;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * This class is part of Elements package, which indicate that this class is created as a helper class to explain, through graphical interface element, the
 * underling functionality or behaviour of the simulator.
 *
 * This class is intended to create the color bar of heights to indicate the variance of heights in the simulation. It's primary functionality is to
 * create a bar that varies in opacity of the same color as the main color. In which the nearer the color to black, the lower the value of the height.
 * It is highly crucial that the background color of the bar matches the simulator field background as expanded in the comments in the clear method.
 *
 * Note that this height bar is intended to be fixed in size in this simulator due to its being a sub layout in a layout, therefore, making it responsive
 * would need to change how the parent layout, and other nodes (label and radio buttons) specify there size in relation to each other and the layout itself.
 * On javaFX, these labels and radio buttons will not resize and adapt if the screen's size changes, therefore, making this class responsive will mostly
 * damage the current layout.
 *
 * @version 2022-03-01
 */
public class HeightBar extends Canvas {

     // The graphics that will be used to draw
     private GraphicsContext gc = getGraphicsContext2D();
     // The height of a single line on the bar
     private double yScale;

    /**
     * This method constructs a canvas with a specified height and width.
     *
     * @param width width
     * @param height height
     */
     public HeightBar(int width, int height) {
         super(width, height);
     }

    /**
     * This method clears the color bar. It is highly crucial that the same background color that is used in the simulator field is used here. The underlying
     * reason behind this is as the color becomes at its lowest due to opacity, it will take the color of the background behind it. If the field view and the
     * color bar have different background colors, the colors at the low range of brightness will be different from the displayed on the field view due to
     * the difference on the background.
     */
     public void clear() {
         gc.clearRect(0, 0, getWidth(), getHeight());
         gc.setFill(Configuration.getSimulatorBackgroundColor());
         gc.fillRect(0, 0, getWidth(), getHeight());
     }

    /**
     * This method sets the height of a line by calculating the current height with the number of possible colors, which will be always 255 as there only
     * 255 different opacity from the spectrum of a single color.
     */
    public void prepare() {
        yScale = getHeight()/255.0;
     }

    /**
     * This method draws 255 lines, in which every line indicates a different level of height. This method will use the default color for the height one
     * based on the current theme.
     */
    public void draw() {
        Color baseColor = Configuration.getHeightBaseColor();
        for (int i = 0; i <= 255; i++) {
            gc.setFill(new Color(baseColor.getRed(),baseColor.getGreen(),baseColor.getBlue(),i/255.0));
            gc.fillRect(0,yScale*i,getWidth(), yScale);
        }
     }

}
