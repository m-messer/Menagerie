package Simulator.Windows;

/**
 * The main purpose of this interface is to add the common functionality of reloading contents' styles when the theme has been
 * changed, which is a feature of tabs (stages) in this simulator. This interface reduces the amount of code needed when
 * reloading contents, instead of checking a line that calls a reload method, a for loop without casting would be sufficient.
 *
 * @version 2022-03-01
 */
public interface SimulatorExternalTab {
    /**
     * This method reload the contents' styles of the screen when needed.
     */
    void reloadContents();
}