package Simulator.Windows.Statistics;

import Simulator.Simulator;
import Simulator.UIManagers.StageManager;
import Simulator.Windows.SimulatorExternalTab;
import Simulator.Windows.SimulatorViewFX;
import Simulator.Windows.Tabs;
import SimulatorHelpers.StatisticsRegisters.CreatureRegister;
import SimulatorHelpers.Themes.Configuration;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import java.util.ArrayList;

/**
 * Generates the statistics for each type of creature in the simulation
 * A separate frame works in sync with the simulator to output data
 * @version 2022-03-01
 */
public class CreaturesStatistics extends Stage implements SimulatorExternalTab {
    //----ID of creature statistics----//
    private Tabs id;
    //----Simulator object at the current time----//
    private Simulator simulator;
    //----Main scene onto which the graph is added----//
    private Scene scene;
    //----SimulatorViewFX object at the current time----//
    private SimulatorViewFX view;
    //----Animal and Plant Series-----//
    private XYChart.Series hobbitSeries,orcSeries, morkSeries, elfSeries, dwarfSeries, holfSeries;
    //----Animal and Plant Arrays----//
    private ArrayList<XYChart.Series> animalSeriesArray;
    //----LineChart to display the information---//
    private final LineChart<Number, Number> creatureLineChart;
    //----The pointer to indicate the last graphed step---//
    private int stepPointer;


    /**
     * Initialises the state of the statistics window
     *
     * @param id the id of the creature statistics window
     * @param view the simulatorView at the current time
     * @param simulator the simulatorView at the current time
     */
    public CreaturesStatistics(Tabs id, SimulatorViewFX view, Simulator simulator) {
        this.id = id;
        this.view = view;
        this.simulator = simulator;

        stepPointer = 0;

        hobbitSeries = new XYChart.Series<>();
        orcSeries = new XYChart.Series<>();
        morkSeries = new XYChart.Series<>();
        elfSeries = new XYChart.Series<>();
        dwarfSeries = new XYChart.Series<>();
        holfSeries = new XYChart.Series<>();
        animalSeriesArray = new ArrayList<>();

        animalSeriesArray.add(hobbitSeries);
        animalSeriesArray.add(orcSeries);
        animalSeriesArray.add(morkSeries);
        animalSeriesArray.add(elfSeries);
        animalSeriesArray.add(dwarfSeries);
        animalSeriesArray.add(holfSeries);


        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        creatureLineChart = new LineChart<Number, Number>(xAxis, yAxis);
        creatureLineChart.setAnimated(false);
        creatureLineChart.setCreateSymbols(false);


        creatureLineChart.setTitle("Changes in Population of creatures over time");

        xAxis.setLabel("Step");
        yAxis.setLabel("Creature Count");


        for (int i = 0; i < view.getAnimalClasses().length; i++)
            animalSeriesArray.get(i).setName(view.getAnimalClasses()[i].getName().replace(view.getAnimalClasses()[i].getPackageName() + "." , "") + "    ");

        reloadGraph();

        for (XYChart.Series series : animalSeriesArray)
            creatureLineChart.getData().addAll(series);

        scene = new Scene(creatureLineChart, 800,600);
        setScene(scene);
        scene.getStylesheets().add(Configuration.getCurrentGraphFXPaths());

        setOnCloseRequest(this::stop);
    }

    /**
     * Updates the contents of the graph for every step
     */
    public void reloadGraph() {

        for (int i = 0; i < simulator.getStep()-stepPointer+1; i++)
            for (int j = 0; j < view.getAnimalClasses().length; j++)
                animalSeriesArray.get(j).getData().add(new XYChart.Data(i, CreatureRegister.retrieveCreaturesStats().get(view.getAnimalClasses()[j].getName()).get(i)));
    }


    /**
     * Clears all the data from the graph and resets it back to a reset state
     * Reference: https://stackoverflow.com/questions/30052685/recreate-bar-chart-without-it-remembering-data
     */
    public void resetGraph() {

        for (XYChart.Series value : animalSeriesArray)
            value.getData().clear();

        creatureLineChart.getData().clear();
        creatureLineChart.layout();

        for (XYChart.Series series : animalSeriesArray)
            creatureLineChart.getData().addAll(series);

        stepPointer = 0;
    }

    /**
     * This method reload the contents' styles of the screen when needed.
     */
    public void reloadContents() {
        this.getScene().getStylesheets().remove(0);
        this.getScene().getStylesheets().add(Configuration.getCurrentGraphFXPaths());
    }

    /**
     * This method calls the stageManager to update the tab's current status
     * @param windowEvent windowEvent
     */
    private void stop(WindowEvent windowEvent) {
        StageManager.affirmClose(id);
    }

}