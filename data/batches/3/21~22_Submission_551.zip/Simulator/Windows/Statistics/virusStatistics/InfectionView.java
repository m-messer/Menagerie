package Simulator.Windows.Statistics.virusStatistics;
import com.google.common.collect.ListMultimap;
import org.apache.commons.lang3.tuple.MutablePair;

import Simulator.Simulator;
import Simulator.Windows.Tabs;
import SimulatorHelpers.StatisticsRegisters.VirusesRegister;


/**
 *
 * This class is part of the virusStatistics package, which indicate that his class is highly focused on the viruses' statistics.
 *
 * This class represent the total deaths by viruses line chart.
 *
 * @version 2022-03-01
 */
public class InfectionView extends VirusStatistics{
    /**
     * This method construct the virus statistics line graph with all its necessary information
     * @param id The id of this view
     * @param simulator the simulator
     */
    public InfectionView(Tabs id, Simulator simulator) {
        super(id, simulator, "Step", "Infections", "Active Viruses Infections Per Time Statistics");
    }

    /**
     * This method returns the data to be processed from this class.
     * @return the required data
     */
    @Override
    protected ListMultimap<String, MutablePair<Integer, Integer>> getGraphData() {
        return VirusesRegister.getVirusesInfectionRecords();
    }
}
