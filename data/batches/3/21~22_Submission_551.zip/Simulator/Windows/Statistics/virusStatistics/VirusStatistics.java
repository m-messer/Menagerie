package Simulator.Windows.Statistics.virusStatistics;

import Simulator.Simulator;
import Simulator.UIManagers.StageManager;
import Simulator.Windows.SimulatorExternalTab;
import Simulator.Windows.Tabs;
import SimulatorHelpers.Themes.Configuration;
import com.google.common.collect.ListMultimap;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import org.apache.commons.lang3.tuple.MutablePair;

import java.util.HashMap;

/**
 *
 * This class is part of the virusStatistics package, which indicate that his class is highly focused on the viruses statistics.
 *
 * This class is the base class of line charts that only differs by the data. Instead of using if statement with the id,
 * it is created to be more tolerable to future extendability.
 *
 * @version 2022-03-01
 * REFERENCES: https://docs.oracle.com/javafx/2/charts/line-chart.htm
 */
public abstract class VirusStatistics extends Stage implements SimulatorExternalTab {

    // The id of this view
    private Tabs id;
    // The line chart
    private LineChart<Number, Number> lineChart;
    // A hashmap to store the data to every virus
    private HashMap<String, XYChart.Series> virusesSeries;
    // The simulator
    private Simulator simulator;
    //----The pointer to indicate the last graphed step---//
    private int stepPointer;

    /**
     * This method construct the virus statistics line graph with all its necessary information
     *
     * @param id The id of this view
     * @param simulator the simulator
     */
    public VirusStatistics(Tabs id, Simulator simulator, String xAxisTitle, String yAxisTitle, String title) {
        this.id = id;
        this.simulator = simulator;
        virusesSeries = new HashMap<>();
        stepPointer = 0;

        //Defining the X axis
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel(xAxisTitle);

        //Defining the Y axis
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel(yAxisTitle);

        lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle(title);

        lineChart.setAnimated(false);
        lineChart.setCreateSymbols(false);

        provideDate();
        stepPointer++;

        Scene scene = new Scene(lineChart, 900, 700);
        scene.getStylesheets().add(Configuration.getCurrentGraphFXPaths());

        setScene(scene);
        setOnCloseRequest(this::stop);

    }

    /**
     * This method reload the graph
     */
    public void reloadVirusStatistics() {
        provideDate();
        stepPointer++;
    }

    /**
     * This method updates the graph to accommodate the new data
     */
    protected void provideDate() {
        ListMultimap<String, MutablePair<Integer, Integer>> stats = getGraphData();

        for (String name : stats.keySet()) {

            // Check if the virus is not present on the graph
            if (!virusesSeries.containsKey(name)) {
                XYChart.Series series = new XYChart.Series();
                series.setName(name);
                virusesSeries.put(name, series);
                lineChart.getData().add(series);
            }

            for (int i = stepPointer; i <= simulator.getStep(); i++) {
                for (int j = 0; j < stats.get(name).size(); j++) {
                    if (stats.get(name).get(j).getLeft() == i) {
                        virusesSeries.get(name).getData().add(new XYChart.Data(i, assignValue(stats.get(name).get(j))));
                    }

                }
            }

        }
    }

    /**
     * This method reset the current graph by clearing all the data that are presented on it.
     */
    public void resetGraph() {

        for (XYChart.Series series : lineChart.getData())
            series.getData().clear();

        lineChart.getData().clear();
        virusesSeries.clear();
        lineChart.layout();

        stepPointer = 0;

    }

    /**
     *
     * This method returns the value to be presented on the graph. The purpose of this method is mainly to provide subclasses
     * a method to override how the values are calculated. For example, step by step, accumulative, 1 if more than 5, or 0 if less.
     *
     * @param pair the pair of data (Step, accumulated record)
     * @return the assigned value to the graph
     */
    protected int assignValue(MutablePair<Integer, Integer> pair) {
        return pair.getRight();
    }

    /**
     * This method reload the contents' styles of the screen when needed.
     */
    public void reloadContents() {
        this.getScene().getStylesheets().remove(0);
        this.getScene().getStylesheets().add(Configuration.getCurrentGraphFXPaths());
    }

    /**
     * This method returns the data to be processed from this class.
     * @return the required data
     */
    protected abstract ListMultimap<String, MutablePair<Integer, Integer>> getGraphData();

    /**
     * This method calls the stageManager to update the tab's current status
     * @param windowEvent windowEvent
     */
    private void stop(WindowEvent windowEvent) {
        lineChart = null;
        virusesSeries = null;
        simulator = null;
        StageManager.affirmClose(id);
    }
}
