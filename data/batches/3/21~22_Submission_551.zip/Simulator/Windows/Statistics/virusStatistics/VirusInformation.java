package Simulator.Windows.Statistics.virusStatistics;

import Simulator.UIManagers.StageManager;
import Simulator.Windows.SimulatorExternalTab;
import Simulator.Windows.Tabs;
import SimulatorHelpers.StatisticsRegisters.VirusesRegister;
import SimulatorHelpers.Themes.Configuration;
import com.google.common.collect.ListMultimap;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * This class in intended to represent viruses information, names, infection rate, and death rate, in a barchart that is
 * responsive with the changes.
 *
 *
 * @version 2022-03-01
 */
public class VirusInformation extends Stage implements SimulatorExternalTab {

    // The id of this view
    private Tabs id;
    // The barchart
    private BarChart<String, Number> barChart;
    // A hashset to ensure the data is unique
    private HashSet<String> representedViruses;

    /**
     * This method construct the windows that will include the barchart along with the necessary information and setups
     * for the barchart.
     *
     * @param id The id of this view
     */
    public VirusInformation(Tabs id) {
        this.id = id;
        representedViruses = new HashSet<>();

        //Defining the X axis
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Viruses");

        //Defining the Y axis
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Percentage");

        barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Viruses infection and death probabilities");

        barChart.getData().addAll(provideDate());

        Scene scene = new Scene(barChart, 900, 700);
        scene.getStylesheets().add(Configuration.getCurrentGraphFXPaths());


        setScene(scene);
        setOnCloseRequest(this::stop);
    }

    /**
     * This method adds the new viruses lively if there has been a new viruses in the simulation.
     */
    public void updateDate() {
        if (representedViruses.size() != VirusesRegister.getNumberOfRegisteredViruses()) {
            ArrayList<XYChart.Series<String, Number>> data = provideDate();
            barChart.getData().get(0).getData().addAll(data.get(0).getData());
            barChart.getData().get(1).getData().addAll(data.get(1).getData());
        }
    }

    /**
     * This method change the format of the copied data that will be extracted from VirusesRegister class to
     * the required format for the barchart.
     *
     * REFERENCES:
     * https://docs.oracle.com/javafx/2/charts/bar-chart.htm
     * https://www.tutorialspoint.com/javafx/bar_chart.htm
     * @return An arraylist that has the required data in a suitable format for the barchart
     */
    private ArrayList<XYChart.Series<String, Number>> provideDate() {

        ArrayList<XYChart.Series<String, Number>> data = new ArrayList<>();

        ListMultimap<String, Double> virusesInfo = VirusesRegister.getVirusesInformation();


        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        XYChart.Series<String, Number> series2 = new XYChart.Series<>();

        series1.setName("Infection Probability");
        series2.setName("Death Probability");


        for (String virusName : virusesInfo.keySet()) {
            if (!representedViruses.contains(virusName)) {
                series1.getData().add(new XYChart.Data<>(virusName, virusesInfo.get(virusName).get(0)));
                series2.getData().add(new XYChart.Data<>(virusName, virusesInfo.get(virusName).get(1)));
                representedViruses.add(virusName);
            }
        }

        data.add(series1);
        data.add(series2);

        return data;
    }

    /**
     * This method reset the barchart.
     */
    public void resetGraph() {
        // Do not use barChart.getData().clear as this would remove the series, which need to be kept or defined and added again every reset.
        for (XYChart.Series series : barChart.getData())
            series.getData().clear();
        representedViruses.clear();
    }

    /**
     * This method reload the contents' styles of the screen when needed.
     */
    public void reloadContents() {
        this.getScene().getStylesheets().remove(0);
        this.getScene().getStylesheets().add(Configuration.getCurrentGraphFXPaths());
    }

    /**
     * This method calls the stageManager to update the tab's current status
     * @param windowEvent windowEvent
     */
    private void stop(WindowEvent windowEvent) {
        StageManager.affirmClose(id);
    }

}
