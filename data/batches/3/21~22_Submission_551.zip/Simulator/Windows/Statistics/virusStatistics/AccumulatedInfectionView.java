package Simulator.Windows.Statistics.virusStatistics;

import Simulator.Simulator;
import Simulator.Windows.Tabs;
import SimulatorHelpers.StatisticsRegisters.VirusesRegister;
import com.google.common.collect.ListMultimap;
import org.apache.commons.lang3.tuple.MutablePair;

/**
 *
 * This class is part of the virusStatistics package, which indicate that his class is highly focused on the viruses' statistics.
 *
 * This class represent the accumulated infection graph, on this class, the represented value is the accumulated value of
 * infections per virus.
 *
 *
 * @version 2022-03-01
 */
public class AccumulatedInfectionView extends VirusStatistics{

    // The accumulator variable, used to store the total
    private int sum;

    /**
     * This method construct the virus statistics infection line graph with all its necessary information.
     *
     * @param id The id of this view
     * @param simulator The simulator
     */
    public AccumulatedInfectionView(Tabs id, Simulator simulator) {
        super(id, simulator, "Step", "Infections", "Accumulated Active Viruses - Infection Statistics");
        sum = 0;
    }

    /**
     * This method rest the accumulated number
     */
    public void resetSum() {
        sum = 0;
    }

    /**
     *
     * This method assign the value for the graphing function as the new value with the accumulated value and updates
     * the accumulator
     *
     * @param pair the pair of data (Step, accumulated record)
     * @return the sum
     */
    @Override
    protected int assignValue(MutablePair<Integer, Integer> pair) {
        sum += pair.getRight();
        return sum;
    }

    /**
     * This method returns the data to be processed from this class.
     * @return the required data
     */
    @Override
    protected ListMultimap<String, MutablePair<Integer, Integer>> getGraphData() {
        return VirusesRegister.getVirusesInfectionRecords();
    }
}
