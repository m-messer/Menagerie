package Simulator.Windows.AboutViews;

import Simulator.Windows.Tabs;

/**
 *
 * This class is part of the AboutViews package, which indicate that this class represent an about view.
 *
 * This class represent a simple instance of using the about abstract class to extend sustainability over time. This class
 * represent the about simulator view.
 *
 * @version 2022-03-01
 */
public class AboutSimulatorView extends AboutViewFX{
    /**
     * This method construct the about simulator view.
     *
     * @param id The id of this view
     */
    public AboutSimulatorView(Tabs id) {
        super(id);
    }

    /**
     * This method returns the text to be displayed on the view.
     * @return the displayed text
     */
    @Override
    protected String getText() {
        return "This simulator in intended to model a fictional environment, Solardia World, that is depicted to be in middle earth. While you may be familiar with some creatures, it is important to note that some of them are fictionally made for this assignment and do not correspond to any films or books.";
    }
}
