package Simulator.Windows.AboutViews;

import Simulator.UIManagers.StageManager;
import Simulator.Windows.SimulatorExternalTab;
import Simulator.Windows.Tabs;
import SimulatorHelpers.Themes.Configuration;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 *
 * This class is part of the AboutViews package, which indicate that this class represent an about view.
 *
 * This class represents the abouts view and their contents. Instead of using if statement with the id,
 * it is created to be more tolerable to future extendability. The usage of alerts were avoided as to gain
 * more control of the view.
 *
 * @version 2022-03-01
 */
public abstract class AboutViewFX extends Stage implements SimulatorExternalTab {

    // The id of this view
    private Tabs id;

    /**
     * This method construct an about view and its necessary elements.
     * @param id The id of this view
     */
    public AboutViewFX(Tabs id) {
        this.id = id;

        Label about = new Label(getText());

        Scene scene = new Scene(about, 500, 400);
        scene.getStylesheets().add(Configuration.getCurrentAboutFXPaths());

        setScene(scene);
        setOnCloseRequest(this::stop);

    }

    /**
     * This method reload the contents' styles of the screen when needed.
     */
    public void reloadContents() {
        this.getScene().getStylesheets().remove(0);
        this.getScene().getStylesheets().add(Configuration.getCurrentAboutFXPaths());
    }

    /**
     * This method calls the stageManager to update the tab's current status
     * @param windowEvent windowEvent
     */
    private void stop(WindowEvent windowEvent) {
        StageManager.affirmClose(id);
    }

    /**
     * This method returns the text to be displayed on the view.
     * @return the displayed text
     */
    protected abstract String getText();
}
