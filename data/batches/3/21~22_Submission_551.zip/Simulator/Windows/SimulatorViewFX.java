package Simulator.Windows;

import Climate.Season;
import Creatures.*;
import Creatures.Animals.*;
import Creatures.Plants.Elanor;
import Simulator.Windows.AboutViews.AboutDevelopersView;
import Simulator.Windows.AboutViews.AboutSimulatorView;
import Simulator.Windows.Statistics.*;
import Simulator.Windows.Statistics.virusStatistics.*;
import SimulatorHelpers.StatisticsRegisters.CreatureRegister;
import SimulatorHelpers.TerrainHelper.EnvironmentsLayout;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.FieldStats;
import Simulator.UIManagers.ServiceManager;
import Simulator.Simulator;
import Simulator.UIManagers.StageManager;
import Simulator.Windows.Elements.FieldView;
import Simulator.Windows.Elements.HeightBar;
import SimulatorHelpers.StatisticsRegisters.VirusesRegister;
import SimulatorHelpers.Themes.Configuration;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * This class is intended to act as the main UI interface that coordinated the simulator.
 *
 * @version 2022-03-01
 */
public class SimulatorViewFX extends Application {

    //----- Simulator Field dimensions -----//

    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 260;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 250;

    //----- Control (Information) Widget Definitions -----//

    private Label stepLabel, delayLabel, yearsLabel, daysLabel, monthsLabel, hoursLabel;
    private Label hobbitLabel, orcLabel,morkLabel, elfLabel, dwarfLabel, holfLabel, elanorLabel;
    private Label seasonLabel;
    private Label informationLabel;
    private Slider simulationSlider;

    //-----  Organism Arrays -----//

    private ArrayList<Label> animalLabels;
    private ArrayList<Label> plantLabels;

    //----- Organism Classes -----//
    private final Class[] animalClasses = {Hobbit.class, Orc.class, Mork.class, Elf.class, Dwarf.class, Holf.class};
    private final Class[] plantClasses = {Elanor.class};

    //----- Label prefixes -----//
    private final String STEP_PREFIX = "Step: ";
    private final String YEAR_PREFIX = "Years: ";
    private final String HOURS_PREFIX = "Hours: ";
    private final String DAYS_PREFIX = "Days: ";
    private final String MONTHS_PREFIX = "Months: ";
    private final String SEASON_PREFIX = "Season: ";
    private final String DELAY_LABEL_PREFIX = "Delay by ms:  ";

    //----- Colors information -----//
    private Map<Class, Color> colors;
    //----- Statistics information -----//
    private FieldStats stats;

    //----- Control Buttons -----//
    private Button one_step, longSimulation, reset, stop, themeBtn;

    //----- Simulator information -----//
    private Simulator simulator;
    private int height, width;

    //----- EnvironmentsLayout -----//
    private ToggleGroup layouts;
    private EnvironmentsLayout environmentsLayout;

    //----- FieldView -----//
    private FieldView fieldView;

    //----- Height Bar -----//
    private HeightBar hb;
    private Label minLabel;
    private Label maxLabel;

    //----- Height Bar -----//
    private final String MIN_HEIGHT_PREFIX = "Minimum Height : ";
    private final String MAX_HEIGHT_PREFIX = "Maximum Height : ";

    //----- The Long Simulation Service -----//
    private ServiceManager runLongSimulationService;

    //----- The Main Scene -----//
    private Scene scene;

    /**
     * This method in intended to serve the constructor role. During development, invoking the constructor for this class
     * proved to be unattainable. To circumvent this issue, this method was created to server the constructor's role.
     */
    private void initializer() {
        this.simulator = new Simulator(DEFAULT_DEPTH, DEFAULT_WIDTH, this);

        this.width = (int) Screen.getPrimary().getBounds().getWidth();
        this.height =  (int) Screen.getPrimary().getBounds().getHeight()-150;;

        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        // Animals
        animalLabels = new ArrayList<>();

        hobbitLabel = new Label();
        orcLabel = new Label();
        morkLabel = new Label();
        elfLabel = new Label();
        dwarfLabel = new Label();
        holfLabel = new Label();

        animalLabels.add(hobbitLabel);
        animalLabels.add(orcLabel);
        animalLabels.add(morkLabel);
        animalLabels.add(elfLabel);
        animalLabels.add(dwarfLabel);
        animalLabels.add(holfLabel);

        // Plants
        plantLabels = new ArrayList<>();
        elanorLabel = new Label();
        plantLabels.add(elanorLabel);


        // Timer

        yearsLabel = new Label(YEAR_PREFIX);
        daysLabel = new Label(DAYS_PREFIX);
        hoursLabel = new Label(HOURS_PREFIX);
        monthsLabel = new Label(MONTHS_PREFIX);

        // Seasons
        seasonLabel = new Label(SEASON_PREFIX  + simulator.getCurrentSeason());

        // InformationLabel
        informationLabel = new Label();

        // EnvironmentsLayout
        environmentsLayout = EnvironmentsLayout.ANIMALS;

    }

    /**
     * This method load fonts to the simulator. The avoidance of using CSS @font-face is to avoid a java bug
     * that impasses the loading of fonts if there exist a space in the absolute path (from the system directory) to the
     * css file, which is not guaranteed in every user.
     *
     * REFERENCE: https://code-examples.net/en/q/20759ef Author. Unknown. Date: n.d
     */
    private void loadFonts(){
        for (String path : Configuration.getFontsPaths())
            Font.loadFont(getClass().getResourceAsStream(path), 16);
    }


    /**
     * This method creates and fill the stage with the simulators UIs.
     * @param stage main stage
     */
    @Override
    public void start(Stage stage) {

        initializer();
        loadFonts();

        BorderPane main = new BorderPane();
        scene = new Scene(main, width, height);
        stage.setTitle("Solardia World Simulation");

        main.setRight(generateRightWidgets());
        main.setBottom(generateFooterWidgets());
        main.setTop(generateHeaderLayout());
        main.setCenter(generateCentralWidgets());

        stage.setScene(scene);
        scene.getStylesheets().add(Configuration.getCurrentSimulatorFXPaths());

        coloring();

        stage.widthProperty().addListener((o, old, newV) -> {
            fieldView.onChange(main.getRight().getLayoutX()-30, main.getBottom().getLayoutY()-70);
            //System.out.println(main.getBottom().getLayoutY());
            //System.out.println(main.getBottom());
            showStatus(simulator.getField());
            setLegend(simulator.getField());
        });
        stage.heightProperty().addListener((o, old, newV) -> {
            fieldView.onChange(main.getRight().getLayoutX()-30, main.getBottom().getLayoutY()-70);
            showStatus(simulator.getField());
            setLegend(simulator.getField());
        });

        stage.show();

        setTimeLabels(0);
        runLongSimulationService = new ServiceManager( new Button[]{longSimulation,one_step,reset},stop, simulator, 1000, simulator.getDelayMap().get((int) simulationSlider.getValue()), stats);

        stats.registerCreaturesValues();
    }

    /**
     * This method act as a coordinates for the menuBar and the header layout. It is intended to solve the issue of the
     * menuBar in WindowsOS. In macOS, the menuBar will be at the top of the screen, however, in Windows, a layout has
     * to be created. In this way, a layout will be created only if the OS is not Mac.
     * @return A layout that has all the widgets for the header
     */
    private VBox generateHeaderLayout() {
        VBox vBox = new VBox();
        vBox.getChildren().addAll(generateMenuBar(), generateHeaderWidgets());
        return vBox;
    }

    /**
     * This method create the menu bar for the simulator
     * @return the menuBar of the simulator
     */
    private MenuBar generateMenuBar() {
        MenuBar menuBar = new MenuBar();

        //---- About ----//
        Menu about = new Menu("About");

        MenuItem aboutDevelopers = new MenuItem("About Developers");
        aboutDevelopers.setId(Tabs.ABOUT_DEVELOPERS.toString());
        about.getItems().add(aboutDevelopers);

        MenuItem aboutSimulator = new MenuItem("About Simulator");
        aboutSimulator.setId(Tabs.ABOUT_SIMULATOR.toString());
        about.getItems().add(aboutSimulator);

        aboutDevelopers.setOnAction(this::openMenuItemManager);
        aboutSimulator.setOnAction(this::openMenuItemManager);

        //---- Statistics ----//
        Menu statistics = new Menu("Statistics");

        MenuItem creaturesStatistics = new MenuItem("Creatures Statistics");
        creaturesStatistics.setId(Tabs.CREATURES_STATISTICS.toString());
        statistics.getItems().add(creaturesStatistics);

        creaturesStatistics.setOnAction(this::openMenuItemManager);

        Menu virusStatistics = new Menu("Virus Statistics");

        MenuItem virusesInformation = new MenuItem("Active and Inactive Viruses Information");
        virusesInformation.setId(Tabs.VIRUS_INFORMATION.toString());
        virusStatistics.getItems().add(virusesInformation);

        virusesInformation.setOnAction(this::openMenuItemManager);

        MenuItem totalVirusesDeathsStatistics = new MenuItem("Active Viruses Deaths Per Time Statistics");
        totalVirusesDeathsStatistics.setId(Tabs.VIRUS_PER_STEP_DEATHS.toString());
        virusStatistics.getItems().add(totalVirusesDeathsStatistics);

        totalVirusesDeathsStatistics.setOnAction(this::openMenuItemManager);

        MenuItem totalVirusesInfectionStatistics = new MenuItem("Active Viruses Infections Per Time Statistics");
        totalVirusesInfectionStatistics.setId(Tabs.VIRUS_PER_STEP_INFECTIONS.toString());
        virusStatistics.getItems().add(totalVirusesInfectionStatistics);

        totalVirusesInfectionStatistics.setOnAction(this::openMenuItemManager);

        MenuItem accumulatedVirusesInfectionStatistics = new MenuItem("Accumulated Active Viruses - Infections Statistics");
        accumulatedVirusesInfectionStatistics.setId(Tabs.VIRUS_TOTAL_INFECTIONS.toString());
        virusStatistics.getItems().add(accumulatedVirusesInfectionStatistics);

        accumulatedVirusesInfectionStatistics.setOnAction(this::openMenuItemManager);

        MenuItem accumulatedVirusesDeathStatistics = new MenuItem("Accumulated Active Viruses - Death Statistics");
        accumulatedVirusesDeathStatistics.setId(Tabs.VIRUS_TOTAL_DEATHS.toString());
        virusStatistics.getItems().add(accumulatedVirusesDeathStatistics);

        accumulatedVirusesDeathStatistics.setOnAction(this::openMenuItemManager);

        statistics.getItems().add(virusStatistics);


        // https://stackoverflow.com/questions/22569046/how-to-make-an-os-x-menubar-in-javafx
        final String os = System.getProperty("os.name");
        if (os != null && os.startsWith("Mac"))
            menuBar.useSystemMenuBarProperty().set(true);

        menuBar.getMenus().addAll(about, statistics);

        return menuBar;
    }

    /**
     * This method acts as the coordinates for the menu bar actions
     * @param actionEvent actionEvent
     */
    private void openMenuItemManager(ActionEvent actionEvent) {

        if (!StageManager.isTabOpen(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()))) {
            SimulatorExternalTab stage;

            if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.ABOUT_DEVELOPERS.toString())) {
                stage = new AboutDevelopersView(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()));
            }else if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.ABOUT_SIMULATOR.toString())) {
                stage = new AboutSimulatorView(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()));
            }else if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.VIRUS_INFORMATION.toString())) {
                stage = new VirusInformation(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()));
            }else if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.VIRUS_PER_STEP_DEATHS.toString())) {
                stage = new DeathView(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()), simulator);
            }else if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.CREATURES_STATISTICS.toString())) {
                stage = new CreaturesStatistics(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()), this, simulator);
            }else if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.VIRUS_PER_STEP_INFECTIONS.toString())) {
                stage = new InfectionView(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()), simulator);
            }else if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.VIRUS_TOTAL_DEATHS.toString())) {
                stage = new AccumulatedDeathView(Tabs.VIRUS_TOTAL_DEATHS, simulator);
            }else if (((MenuItem)actionEvent.getSource()).getId().equals(Tabs.VIRUS_TOTAL_INFECTIONS.toString())) {
                stage = new AccumulatedInfectionView(Tabs.VIRUS_TOTAL_INFECTIONS, simulator);
            }else{
                return;
            }

            ((Stage) stage).setTitle(((MenuItem) actionEvent.getSource()).getText());
            ((Stage) stage).show();
            StageManager.affirmOpen(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()), stage);

        }else{
            StageManager.bringToFront(Tabs.valueOf(((MenuItem) actionEvent.getSource()).getId()));
        }

    }

    /**
     * This method returns a layout that has all the widgets for the header
     * @return  A layout that has all the widgets for the header
     */
    private HBox generateHeaderWidgets() {
        HBox hBox = new HBox();
        hBox.setId("headerLayout");

        // Information Labels & controls
        simulationSlider = new Slider(0,4,2);
        simulationSlider.setSnapToTicks(true);
        simulationSlider.setShowTickMarks(true);
        simulationSlider.setMinorTickCount(0);
        simulationSlider.setMajorTickUnit(1);
        simulationSlider.setBlockIncrement(1);
        simulationSlider.valueProperty().addListener(this::simulationSliderChangeAction);

        delayLabel = new Label( DELAY_LABEL_PREFIX + this.simulator.getDelayMap().get((int) simulationSlider.getValue()));
        stepLabel = new Label(STEP_PREFIX);

        delayLabel.getStyleClass().add("informationLabels");
        stepLabel.getStyleClass().add("informationLabels");

        hBox.getChildren().addAll(stepLabel, simulationSlider, delayLabel);
        return hBox;
    }

    /**
     * This method acts as the action method for the change of the slider's speed
     * @param observable observable
     */
    private void simulationSliderChangeAction(Observable observable) {
        delayLabel.setText(DELAY_LABEL_PREFIX + simulator.getDelayMap().get((int) simulationSlider.getValue()));
        runLongSimulationService.setSpeed(simulator.getDelayMap().get((int) simulationSlider.getValue()));
    }

    /**
     * This method returns a layout that has all the widgets for the footer
     * @return  A layout that has all the widgets for the footer
     */
    private HBox generateFooterWidgets() {
        HBox hBox = new HBox();
        hBox.setId("Legend");

        for (Label animal : animalLabels)
            hBox.getChildren().add(animal);

        for (Label plant : plantLabels)
            hBox.getChildren().add(plant);

        return hBox;
    }

    /**
     * This method creates the simulator field interview
     * @return the fieldView
     */
    private FieldView generateCentralWidgets() {
        fieldView = new FieldView(DEFAULT_DEPTH, DEFAULT_WIDTH);
        fieldView.setOnMouseClicked(this::onMouseMoveFieldViewAction);
        return fieldView;
    }

    /**
     * This method perform the task of presenting cell's information on the screen when clicked
     * @param mouseEvent mouseEvent
     */
    private void onMouseMoveFieldViewAction(MouseEvent mouseEvent) {
        double[] scaledCoordinates = fieldView.onScale(mouseEvent.getX(), mouseEvent.getY());
        int scaledHeight = (int) scaledCoordinates[0];
        int scaledDepth = (int) scaledCoordinates[1];

        if (simulator.getField().withinBound(scaledDepth, scaledHeight)) {

            if (environmentsLayout == EnvironmentsLayout.ANIMALS) {
                if (simulator.getField().getLandAt(scaledDepth, scaledHeight).getAnimal() != null)
                    informationLabel.setText("" + simulator.getField().getLandAt(scaledDepth, scaledHeight).getAnimal());
                else
                    informationLabel.setText("");

            }else if (environmentsLayout == EnvironmentsLayout.PLANTS) {
                if (simulator.getField().getLandAt(scaledDepth, scaledHeight).getPlant() != null)
                    informationLabel.setText("" + simulator.getField().getLandAt(scaledDepth, scaledHeight).getPlant());
                else
                    informationLabel.setText("");

            }else if (environmentsLayout == EnvironmentsLayout.HEIGHT) {
                    informationLabel.setText("" + simulator.getField().getLandAt(scaledDepth, scaledHeight).getFormativeHeight());
            }

        }
    }

    /**
     * This method creates the UI items for the right side
     * @return A layout that has all the widgets for the right side
     */
    private VBox generateRightWidgets() {
        VBox vBox = new VBox();
        vBox.setId("rightPane");

        VBox buttonLayout = new VBox();
        buttonLayout.getStyleClass().add("rightPaneLayouts");
        //----- Control Buttons
        one_step = new Button("Run one step");
        longSimulation = new Button("Run long simulation");
        reset = new Button("Reset");
        stop = new Button("Stop");
        themeBtn = new Button(Configuration.getNextThemeName());

        stop.setDisable(true);

        one_step.setOnAction(this::runOneStepSimulation);
        longSimulation.setOnAction(this::runLongSimulation);
        reset.setOnAction(this::restSimulationAction);
        stop.setOnAction(this::stopSimulationAction);
        themeBtn.setOnAction(this::changeThemeMode);

        buttonLayout.getChildren().addAll(one_step, longSimulation, reset, stop, themeBtn);

        //----- Field Layouts

        VBox fieldLayoutsLayout = new VBox();
        fieldLayoutsLayout.getStyleClass().add("rightPaneLayouts");

        //https://www.geeksforgeeks.org/javafx-radiobutton-with-examples/
        layouts = new ToggleGroup();
        RadioButton heightRadioButton = new RadioButton("Height");
        RadioButton plantsRadioButton = new RadioButton("Plants");
        RadioButton animalRadioButton = new RadioButton("Animal");
        heightRadioButton.setId("0");
        plantsRadioButton.setId("1");
        animalRadioButton.setId("2");

        animalRadioButton.fire();

        heightRadioButton.setToggleGroup(layouts);
        plantsRadioButton.setToggleGroup(layouts);
        animalRadioButton.setToggleGroup(layouts);

        layouts.selectedToggleProperty().addListener(this::layoutSelectorChanged);

        fieldLayoutsLayout.getChildren().addAll(heightRadioButton, plantsRadioButton, animalRadioButton);

        minLabel = new Label(MIN_HEIGHT_PREFIX + simulator.getHeightHelper().getMinHeight());
        maxLabel = new Label(MAX_HEIGHT_PREFIX + simulator.getHeightHelper().getMaxHeight());
        minLabel.getStyleClass().add("heightLabel");
        maxLabel.getStyleClass().add("heightLabel");

        minLabel.setVisible(false);
        maxLabel.setVisible(false);

        hb = new HeightBar(100,150);
        hb.setVisible(false);
        hb.clear();
        hb.prepare();
        hb.draw();
        fieldLayoutsLayout.getChildren().addAll(minLabel, hb, maxLabel);

        //----- Timer
        VBox timerLayout = new VBox();
        timerLayout.getStyleClass().add("rightPaneLayouts");
        hoursLabel.getStyleClass().add("informationLabels");
        daysLabel.getStyleClass().add("informationLabels");
        monthsLabel.getStyleClass().add("informationLabels");
        yearsLabel.getStyleClass().add("informationLabels");
        timerLayout.getChildren().addAll(hoursLabel, daysLabel, monthsLabel, yearsLabel);

        //----- Season Label
        VBox seasonLayout = new VBox();
        seasonLabel.getStyleClass().add("informationLabels");
        seasonLayout.getChildren().add(seasonLabel);

        // Information Label
        VBox informationLayout = new VBox();
        informationLayout.getStyleClass().add("rightPaneLayouts");
        informationLabel.getStyleClass().add("informationLabels");
        informationLayout.getChildren().add(informationLabel);

        vBox.getChildren().addAll(buttonLayout, fieldLayoutsLayout, timerLayout, seasonLayout, informationLayout);

        return vBox;
    }

    /**
     * This method act as the action when the layout is changed
     * @param observable observable
     */
    private void layoutSelectorChanged(Observable observable) {
        RadioButton rb = (RadioButton) layouts.getSelectedToggle();

        if (rb.getId().equals("0")) {
            environmentsLayout = EnvironmentsLayout.HEIGHT;
            hb.setVisible(true);
            minLabel.setVisible(true);
            maxLabel.setVisible(true);
        }else if  (rb.getId().equals("1")) {
            environmentsLayout = EnvironmentsLayout.PLANTS;
            hb.setVisible(false);
            minLabel.setVisible(false);
            maxLabel.setVisible(false);
        }else if (rb.getId().equals("2")) {
            environmentsLayout = EnvironmentsLayout.ANIMALS;
            hb.setVisible(false);
            minLabel.setVisible(false);
            maxLabel.setVisible(false);
        }


        showStatus(simulator.getField());
        reloadUI();
    }

    //----- Button Action Methods -----//


    /**
     * This button simulates one step in the simulator
     * @param actionEvent actionEvent
     */
    private void runOneStepSimulation(ActionEvent actionEvent) {
        simulator.simulateOneStep();
    }

    /**
     * This method perform the action of long simulation
     * @param actionEvent actionEvent
     */
    private void runLongSimulation(ActionEvent actionEvent) {
        stop.setDisable(false);
        longSimulation.setDisable(true);
        one_step.setDisable(true);
        reset.setDisable(true);

        runLongSimulationService = new ServiceManager(new Button[]{longSimulation,one_step,reset},stop, simulator, 1000, simulator.getDelayMap().get((int) simulationSlider.getValue()),stats);
        runLongSimulationService.serve();
    }

    /**
     * This method reset the simulator
     * @param actionEvent actionEvent
     */
    private void restSimulationAction(ActionEvent actionEvent) {
        simulator.reset();
        VirusesRegister.reset();
        CreatureRegister.reset();
        hoursLabel.setText(HOURS_PREFIX + "00");
        daysLabel.setText(DAYS_PREFIX + "00");
        monthsLabel.setText(MONTHS_PREFIX + "00");
        yearsLabel.setText(YEAR_PREFIX + "00");

        StageManager.restartStatisticsGraph();
        showStatus(simulator.getField());
        stats.registerCreaturesValues();
        setTimeLabels(0);
        reloadUI();
    }

    /**
     * This method stops the simulator
     * @param actionEvent actionEvent
     */
    private void stopSimulationAction(ActionEvent actionEvent) {
        runLongSimulationService.cancel();
    }

    /**
     * This method changes the current theme of the simulator into the next one with performing the necessary updating operations
     * @param actionEvent actionEvent
     */
    private void changeThemeMode(ActionEvent actionEvent) {
        Configuration.nextPointer();
        scene.getStylesheets().remove(0);
        scene.getStylesheets().add(Configuration.getCurrentSimulatorFXPaths());
        themeBtn.setText(Configuration.getNextThemeName());
        coloring();
        hb.clear();
        hb.draw();
        StageManager.reloadSheets();
        showStatus(simulator.getField());
        reloadUI();
    }


    /**
     * This method sets the coloring of the simulated object
     */
    private void coloring() {
        Color[] colorsAnimals = Configuration.getAnimalColors();

        for (int i = 0; i < animalClasses.length; i++)
            colors.put(animalClasses[i], colorsAnimals[i]);

        Color[] colorPlants = Configuration.getPlantColors();
        for (int i = 0; i < plantClasses.length; i++)
            colors.put(plantClasses[i], colorPlants[i]);
    }

    /**
     * Show the current status of the field.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(Field field) {
        stats.reset();

        fieldView.prepare();
        fieldView.clear();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {

                if (environmentsLayout == EnvironmentsLayout.HEIGHT) {
                    Color color = Configuration.getHeightBaseColor();
                    fieldView.draw(col, row, new Color(color.getRed(), color.getGreen(), color.getBlue(), simulator.getHeightHelper().getAlpha(field.getLandAt(row,col).getHeight())));

                } else {
                    Representable organism = null;

                    if (environmentsLayout == EnvironmentsLayout.ANIMALS)
                        organism = field.getLandAt(row, col).getAnimal();
                    else if (environmentsLayout == EnvironmentsLayout.PLANTS)
                        organism = field.getLandAt(row, col).getPlant();

                    if (organism != null) {
                        stats.incrementCount(organism.getClass());
                        fieldView.draw(col, row, colors.get(organism.getClass()));
                    } else {
                        fieldView.draw(col, row, Configuration.getDefaultCellColor());
                    }
                }
            }
        }
        stats.countFinished();

    }

    /**
     * This method reload the UI Tabs and stages to accommodate the change in the field view.
     */
    public void reloadUI() {
        StageManager.reloadCreatureCountGraph();
        StageManager.reloadVirusStatistics();
        StageManager.reloadVirusInformationStage();
        setLegend(simulator.getField());
    }

    /**
     * This method set the legends for the simulator
     * @param field the view field
     */
    public void setLegend(Field field) {
        for (int i = 0; i < animalClasses.length; i++) {
            animalLabels.get(i).setText(animalClasses[i].getName().replace(animalClasses[i].getPackageName()+".","")+ ": " + stats.getPopulationClassCount(animalClasses[i], field));
            animalLabels.get(i).setTextFill(colors.get(animalClasses[i]));
        }
        for (int i = 0; i < plantClasses.length; i++) {
            plantLabels.get(i).setText(plantClasses[i].getName().replace(plantClasses[i].getPackageName()+".","") + ": " + stats.getPopulationClassCount(plantClasses[i], field));
            plantLabels.get(i).setTextFill(colors.get(plantClasses[i]));
        }
    }

    /**
     * This method update the season label.
     * @param season the new seasons
     */
    public void setSeasonLabel(Season season) {
        seasonLabel.setText(SEASON_PREFIX + season);
    }

    /**
     * Define the values in the labels whenever the status is updated.
     */
    public void setTimeLabels(int step) {
        stepLabel.setText(STEP_PREFIX + step);
        hoursLabel.setText(HOURS_PREFIX + simulator.getDisplayedValueForHourTimer());
        daysLabel.setText(DAYS_PREFIX + simulator.getDisplayedValueFoDayTimer());
        monthsLabel.setText(MONTHS_PREFIX +  simulator.getDisplayedValueForMonthTimer());
        yearsLabel.setText(YEAR_PREFIX +  simulator.getDisplayedValueForYearTimer());
    }


    /**
     * This method returns the animal classes
     * @return Animal classes
     */
    public Class[] getAnimalClasses() {
        return animalClasses;
    }

    /**
     * This method returns the planet classes
     * @return Plant classes
     */
    public Class[] getPlantClasses() {
        return plantClasses;
    }

    /**
     * This method returns the statistics object
     * @return the statistics object
     */
    public FieldStats getStats() {
        return stats;
    }
}
