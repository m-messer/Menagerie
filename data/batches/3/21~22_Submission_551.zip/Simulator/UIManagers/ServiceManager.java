package Simulator.UIManagers;

import Simulator.Simulator;
import SimulatorHelpers.FieldStats;
import SimulatorHelpers.TerrainHelper.Field;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

/**
 *
 * This class is part of UIManagers package, which indicates that this class is intended to provide help with manging
 * the UI of the simulator.
 *
 * This class was created to accommodate the way that javaFX uses threads. Since JavaFX only allows its thread to update
 * UI, the usage of Thread.Sleep on javaFX thread does lead to the screen being not responsive, and nullifying to purpose of
 * long simulation as only the results of the last simulated step will be shown. For these reasons, the javaFX service
 * class was implemented to be in place of Thread.Sleep. However, due to the javaFX service class usage of thread pool in
 * order to execute the threads, creating a for loop that runs the simulator and then delay the screen will execute all
 * the services concurrently, leading to possible overlapping since these threads will be subjected to the device's
 * resources and the thread mechanism in Java, hence eliminating every guarantee that they will run in order. Although the
 * Thread.Sleep function will introduce a buffer between threads, ensuring order, this order depends on the unexpected
 * nature of threads, and it was shown that as the simulator speed increases, as the threads will be overlapping, causing
 * running issues in the simulator.
 *
 * For the above reasons, it was crucial to create this class to provide a mechanism of using an alternative way to deal
 * with thread other than JavaFX's thread pool. This class will only initiate a thread if the previous thread is completed,
 * and will ensure that if the delayed time was not enough for the thread to be completed, that it give it more time to
 * eliminate unexpected behaviours.
 *
 *
 * REFERENCES:
 * https://docs.oracle.com/javafx/2/threads/jfxpub-threads.htm
 * https://docs.oracle.com/javase/8/javafx/api/javafx/concurrent/Service.html
 * https://docs.oracle.com/javase/8/javafx/api/javafx/concurrent/package-summary.html
 *
 * @version 2022-03-01
 */

public class ServiceManager {

    // number of remained steps to be simulated
    private int remains;
    // The simulator
    private Simulator simulator;
    // An array contains all the to be updated buttons references
    private Button[] btnLst;
    // The stop button reference
    private Button stopBtn;
    // Simulator's speed
    private int speed;
    // Field stats
    private FieldStats stats;

    /**
     *
     * This method construct a serviceManager and all its necessary information
     *
     * The main reason of separating btnLst and stop is that the effects that will be applied on btnLst are exact, while
     * the effect that will be applied to the stop button is different.
     *
     * @param btnLst an array contains all the to be updated buttons references
     * @param stopBtn the stop button reference
     * @param simulator the simulator reference
     * @param numOfSteps number of steps to be simulated
     * @param speed the speed of the simulator
     * @param stats the reference to the statistics instance
     */
    public ServiceManager(Button[] btnLst, Button stopBtn, Simulator simulator, int numOfSteps, int speed, FieldStats stats) {
        remains = numOfSteps;
        this.simulator = simulator;
        this.btnLst = btnLst;
        this.stopBtn = stopBtn;
        this.speed = speed;
        this.stats = stats;
    }

    /**
     * This method updated the simulator's speed.
     * @param speed the new speed
     */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    /**
     * This method cancels the long simulator. This method makes the remaining steps to be served to zero instead of
     * interrupting the service as this method ensures that no thread is terminated without having completed its
     * effects, since it may cause some issues to future runs if its effects were not tacked back nd reversed.
     */
    public void cancel() {
        remains = 0;
    }

    /**
     * This method is intended to perform the main functionality of the simulation. This method coordinates the running
     * of the simulator and ensure the responsiveness of the UI.
     *
     * This method serve one service, and upon completion of the served one, it initiates the next service until simulating
     * the expected number of steps.
     *
     */
    public void serve() {

        if (remains > 0 && isViable(simulator.getField())) {
            RunSingleSimulation r = new RunSingleSimulation(speed);
            r.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
                @Override
                public void handle(WorkerStateEvent event) {
                    simulator.simulateOneStep();
                    remains--;
                    serve();
                }
            });
            r.start();
        } else {
            updateUI();
        }

    }

    /**
     * This method updates the control UI after the simulation is finished or stopped.
     */
    private void updateUI() {
        for (Button b : btnLst) {
            if (b != null)
                b.setDisable(false);
        }
        if (stopBtn != null)
            stopBtn.setDisable(true);
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is one or more species are presented in the simulator.
     */
    public boolean isViable(Field field) {
        return stats.isViable(field);
    }

    /**
     *
     * This class is intended to perform the functionality of delay in a way that accommodates javaFX thread.
     * The reasons of the existence of this class is mentioned on the documentation of ServiceManager class.
     *
     * @version 2022-03-01
     */
    private static class RunSingleSimulation extends Service<Boolean> {

        // Service's speed
        private int speed;

        /**
         * This method creates a service with the specified speed
         * @param speed the speed of the simulator
         */
        public RunSingleSimulation(int speed) {
            this.speed = speed;
        }

        /**
         * This method is intended to perform the task of sleeping
         * @return null.
         */
        @Override
        protected Task createTask() {
            return new Task() {
                @Override
                protected Object call() throws Exception {
                    Thread.sleep(speed);
                    return null;
                }
            };
        }

    }
}
