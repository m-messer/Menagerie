package Simulator.UIManagers;

import Simulator.Windows.*;
import Simulator.Windows.Statistics.CreaturesStatistics;
import Simulator.Windows.Statistics.virusStatistics.*;
import javafx.stage.Stage;

import java.util.HashMap;

/**
 *
 * This class is part of UIManagers package, which indicates that this class is intended to provide help with manging
 * the UI of the simulator.
 *
 * This class is intended to provide better control from the stages of the simulator. The class's main objectives
 * is to provide live updates to all the stages that supports it and ensure that only one stage  of the same kind
 * is opened, i.e, only one about developers tab, and one about simulator tab.
 *
 * The reason that this class was not incorporated at the main simulatorUI class is to ensure separation of tasks.
 *
 * @version 2022-03-01
 */
public class StageManager {

    //----- opened Tab -----//
    // The hashmap is intended to keep track of stages and their references.
    private static HashMap<Tabs, SimulatorExternalTab> openedStages;

    /**
     * This method construct the stage manager's hashmap, which is the basis of functionality of this class.
     */
    public StageManager() {
        openedStages = new HashMap<>();
        openedStages.put(Tabs.ABOUT_DEVELOPERS, null);
        openedStages.put(Tabs.ABOUT_SIMULATOR, null);
        openedStages.put(Tabs.CREATURES_STATISTICS, null);
        openedStages.put(Tabs.VIRUS_INFORMATION, null);
        openedStages.put(Tabs.VIRUS_PER_STEP_DEATHS, null);
        openedStages.put(Tabs.VIRUS_PER_STEP_INFECTIONS, null);
    }

    /**
     * This method reload the tabs in order to make them more responsive. E.g, when changing themes.
     */
    public static void reloadSheets() {
        for (Tabs tab : openedStages.keySet())
            if (openedStages.get(tab) != null)
                openedStages.get(tab).reloadContents();

    }


    /**
     * This method reload the viruses' statistics graph in order to make it more responsive
     */
    public static void reloadVirusStatistics() {
        if (openedStages.get(Tabs.VIRUS_PER_STEP_DEATHS) != null)
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_PER_STEP_DEATHS)).reloadVirusStatistics();

        if (openedStages.get(Tabs.VIRUS_PER_STEP_INFECTIONS) != null)
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_PER_STEP_INFECTIONS)).reloadVirusStatistics();

        if (openedStages.get(Tabs.VIRUS_TOTAL_DEATHS) != null)
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_TOTAL_DEATHS)).reloadVirusStatistics();

        if (openedStages.get(Tabs.VIRUS_TOTAL_INFECTIONS) != null)
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_TOTAL_INFECTIONS)).reloadVirusStatistics();
    }

    /**
     * This method reload the creatures' statistics graph in order to make it more responsive
     */
    public static void reloadCreatureCountGraph() {
        if (openedStages.get(Tabs.CREATURES_STATISTICS) != null)
            ((CreaturesStatistics) openedStages.get(Tabs.CREATURES_STATISTICS)).reloadGraph();
    }

    /**
     * This method reset the statistics graphs
     */
    public static void restartStatisticsGraph() {
        if (openedStages.get(Tabs.CREATURES_STATISTICS) != null)
            ((CreaturesStatistics) openedStages.get(Tabs.CREATURES_STATISTICS)).resetGraph();

        if (openedStages.get(Tabs.VIRUS_PER_STEP_DEATHS) != null)
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_PER_STEP_DEATHS)).resetGraph();

        if (openedStages.get(Tabs.VIRUS_PER_STEP_INFECTIONS) != null)
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_PER_STEP_INFECTIONS)).resetGraph();

        if (openedStages.get(Tabs.VIRUS_TOTAL_DEATHS) != null) {
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_TOTAL_DEATHS)).resetGraph();
            ((AccumulatedDeathView) openedStages.get(Tabs.VIRUS_TOTAL_DEATHS)).resetSum();
        }

        if (openedStages.get(Tabs.VIRUS_TOTAL_INFECTIONS) != null) {
            ((VirusStatistics) openedStages.get(Tabs.VIRUS_TOTAL_INFECTIONS)).resetGraph();
            ((AccumulatedInfectionView) openedStages.get(Tabs.VIRUS_TOTAL_INFECTIONS)).resetSum();
        }

        if (openedStages.get(Tabs.VIRUS_INFORMATION) != null)
            ((VirusInformation) openedStages.get(Tabs.VIRUS_INFORMATION)).resetGraph();
    }


    /**
     * This method is intended to provide the virusInformation tab with the ability to reload without
     * the need of reopening the tab.
     */
    public static void reloadVirusInformationStage() {
        if (openedStages.get(Tabs.VIRUS_INFORMATION) != null)
            ((VirusInformation) openedStages.get(Tabs.VIRUS_INFORMATION)).updateDate();
    }

    /**
     *
     * This method is intended to provide the functionality of bringing the tab, by its id, to the front.
     *
     * Reference: https://stackoverflow.com/questions/48784142/bringing-a-single-stage-to-the-front-in-windows-in-javafx. Name: DasMoeh. Date: Feb 15, 2018
     * @param id the id of the tab
     */
    public static void bringToFront(Tabs id) {
        ((Stage) openedStages.get(id)).setAlwaysOnTop(true);
        ((Stage) openedStages.get(id)).setAlwaysOnTop(false);
    }

    /**
     *
     * This method updates the stage manager states of the provided id tab to close and nullify its reference.
     * Reference: https://stackoverflow.com/questions/604424/how-to-get-an-enum-value-from-a-string-value-in-java. Name: Michael Myers. Date:Mar 2, 2009.
     * @param id the id of the tab
     */
    public static void affirmClose(Tabs id) {
        openedStages.put(id, null);
    }

    /**
     *
     * This method updates the stage manager states of the provided id tab to open and stores its reference.
     *
     * Reference: https://stackoverflow.com/questions/604424/how-to-get-an-enum-value-from-a-string-value-in-java. Name: Michael Myers. Date:Mar 2, 2009.
     * @param id the id of the tab
     * @param ref the reference of the stage
     */
    public static void affirmOpen(Tabs id, SimulatorExternalTab ref) {
        openedStages.put(id, ref);
    }

    /**
     *
     * This method checks if the tab with the specified id is closed or not
     *
     * @param id The id of the tab to be checked
     * @return true if the tab is open, false otherwise
     */
    public static boolean isTabOpen(Tabs id) {
        return null != openedStages.get(id);
    }
}
