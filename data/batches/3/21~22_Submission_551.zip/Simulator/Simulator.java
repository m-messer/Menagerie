package Simulator;

import Climate.*;
import Creatures.Animals.*;
import Creatures.Plants.Elanor;
import Creatures.Plants.Plant;
import Genes.GeneTools;
import SimulatorHelpers.*;
import SimulatorHelpers.StatisticsRegisters.VirusesRegister;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;
import SimulatorHelpers.TerrainHelper.HeightHelper;
import Simulator.Windows.SimulatorViewFX;
import SimulatorHelpers.Timer;


import java.util.*;

/**
 *
 * This class is part of Windows package, which indicates that this class is closely related
 * to running the UI.
 *
 * A predator-prey simulator, based on a rectangular field that represent an environment
 * containing fictional characters, animals and plants.
 *
 * The view field has three different layouts, the height layout which indicates the height of the cell,
 * the plant layout, which can be corresponded to the first visible layout, and the creature layout,
 * which are above the plants layout.
 *
 * @version 2022-03-01
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The probability that an orc will be created in any given grid position.
    private static final double ORC_CREATION_PROBABILITY = 0.08;
    // The probability that a hobbit will be created in any given grid position.
    private static final double HOBBIT_CREATION_PROBABILITY = 0.14;
    // The probability that a dwarf will be created in any given grid position.
    private static final double DWARF_CREATION_PROBABILITY = 0.13;
    // The probability that an elf will be created in any given grid position.
    private static final double ELF_CREATION_PROBABILITY = 0.12;
    // The probability that a holf will be created in any given grid position.
    private static final double HOLF_CREATION_PROBABILITY = 0.04;
    // The probability that a mork will be created in any given grid position.
    private static final double MORK_CREATION_PROBABILITY = 0.03;
    // The probability that an elanor will be created in any given grid position.
    private static final double ELANOR_CREATION_PROBABILITY = 0.95;

    // A list that include reference of animals in the field.
    private List<Animal> animals;
    // A list that include reference of plants in the field.
    private List<Plant> plants;

    // A reference to the functionality of assigning heights to the generated lands.
    private final HeightHelper heightHelper;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorViewFX view;
    //Map comparing speeds to delay times
    private Map<Integer, Integer> delayMap;
    // The climate of the simulator
    private Climate climate;

    //----- Timer information -----//
    private Timer hourTimer, dayTimer, monthTimer, yearTimer;
    private ArrayList<Timer> timer;

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width, SimulatorViewFX simulatorViewFX) {
        this.view = simulatorViewFX;

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        delayMap = new HashMap<Integer, Integer>();
        setDelayMap();

        hourTimer = new Timer(24);
        dayTimer = new Timer(30);
        monthTimer = new Timer(12);
        yearTimer = new Timer();

        timer = new ArrayList<Timer>();
        timer.add(hourTimer);
        timer.add(monthTimer);
        timer.add(dayTimer);
        timer.add(yearTimer);

        //Set the default season to winter
        climate = new Climate(Season.WINTER);

        heightHelper = new HeightHelper();

        // Create lands to be represented as the main core of the field view.
        generateLand();

        VirusesRegister.setSimulator(this);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * creature.
     */
    public void simulateOneStep() {
        step++;
        calculateTimings();
        view.setTimeLabels(step);

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            // nighttime - animals don't act during the night
            if(isDay(hourTimer)){
                animal.act(newAnimals, climate.getSeason());
            }else if(animal instanceof NightAnimal){
                ((NightAnimal) animal).nightAct(newAnimals, climate.getSeason());
            }

            if(!animal.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born animals and rabbits to the main lists.
        animals.addAll(newAnimals);

        // Provide space for newborn plants.
        List<Plant> newPlants = new ArrayList<>();
        // Let all hobbits act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            // nighttime - plants don't act during the night
            if(isDay(hourTimer)){
                plant.act(newPlants, climate);
            }
            if(!plant.isAlive()) {
                it.remove();
            }
        }
        plants.addAll(newPlants);

        // Update the UI
        view.showStatus(field);
        view.getStats().registerCreaturesValues();
        view.reloadUI();
    }

    /**
     * This method returns true if the timer object is day, false otherwise
     * @param hourTimer the hourTimer object
     * @return true if is day, false otherwise.
     */
    private boolean isDay(Timer hourTimer){
        return (hourTimer.getCurrentStep() >= climate.getWeather().getSunriseTime()
                && hourTimer.getCurrentStep() <= climate.getWeather().getSunsetTime());
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        for (Timer t : timer)
            t.reset();
        animals.clear();
        plants.clear();
        generateLand();
        populate();
    }

    /**
     * Setting up the delay Map to correspond to different timings.
     */
    private void setDelayMap(){
        delayMap.put(SimulatorSpeed.VERY_SLOW.getValue(), 1000);
        delayMap.put(SimulatorSpeed.SLOW.getValue(), 500);
        delayMap.put(SimulatorSpeed.NORMAL.getValue(), 250);
        delayMap.put(SimulatorSpeed.FAST.getValue(), 125);
        delayMap.put(SimulatorSpeed.VERY_FAST.getValue(), 0);
    }

    /**
     * This method returns the delay map that has the possible speeds of the simulator
     * @return the delay map of the simulator
     */
    public Map<Integer, Integer> getDelayMap(){
        return delayMap;
    }

    /**
     * This method returns the current step of the simulator
     * @return the current step
     */
    public int getStep() {
        return step;
    }

    /**
     * This method returns the field of the simulator.
     * @return The field of the simulator.
     */
    public Field getField() {
        return field;
    }

    /**
     * This method returns the HeightHelper object.
     * @return The HeightHelper object
     */
    public HeightHelper getHeightHelper() {
        return heightHelper;
    }

    /**
     * This method generates and assign land into the field view.
     */
    private void generateLand(){
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                field.placeLand(heightHelper.getHeightForPosition(row, col), location);
            }
        }

        // Invoke the method that determine the difference in alpha for heights to color the lands
        heightHelper.setSigmaAlpha();
        generatePlants();
    }

    /**
     * This method generated plans on the field.
     */
    private void generatePlants(){
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if (Randomizer.getRandom().nextDouble() <= ELANOR_CREATION_PROBABILITY) {
                    Elanor elanor = new Elanor(true, field, location);
                    plants.add(elanor);
                }
            }
        }
    }

    /**
     * This method randomly populates the field with a new population.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if(rand.nextDouble() <= ORC_CREATION_PROBABILITY) {
                    Animal orc = new Orc(GeneTools.GenerateGenes(true,23,32), field, location, true);
                    animals.add(orc);
                }
                else if (rand.nextDouble() <= HOBBIT_CREATION_PROBABILITY) {
                    Animal hobbit = new Hobbit(GeneTools.GenerateGenes(true,23,32), field, location, true);
                    animals.add(hobbit);
                }else if (rand.nextDouble() <= DWARF_CREATION_PROBABILITY){
                    Animal dwarf = new Dwarf(GeneTools.GenerateGenes(true,23,32), field, location, true);
                    animals.add(dwarf);
                }else if (rand.nextDouble() <= ELF_CREATION_PROBABILITY){
                    Animal elf = new Elf(GeneTools.GenerateGenes(true,23,32), field, location, true);
                    animals.add(elf);
                }else if (rand.nextDouble() <= HOLF_CREATION_PROBABILITY){
                    Animal holf = new Holf(GeneTools.GenerateGenes(true,23,32), field, location, true);
                    animals.add(holf);
                }else if (rand.nextDouble() <= MORK_CREATION_PROBABILITY){
                    Animal mork = new Mork(GeneTools.GenerateGenes(true,23,32), field, location, true);
                    animals.add(mork);
                }
                // else leave the location empty of animals.
            }
        }
    }

    /**
     * Increments timer and increments the next timer if there is a rollover.
     */
    private void calculateTimings(){
        hourTimer.increment(6);
        if(hourTimer.rollingOver()) {
            dayTimer.increment();
            if (dayTimer.rollingOver()) {
                monthTimer.increment();
                updateSeason();
                if (monthTimer.rollingOver()) {
                    yearTimer.incrementWithoutLimit();
                }
            }
        }
    }

    /**
     * This method updates the season of the simulator
     */
    private void updateSeason(){
        Season oldSeason = climate.getSeason();

        int month = monthTimer.getCurrentStep();
        if(month <= 2 || month == 12){
            climate.setSeason(Season.WINTER);
        }else if(month <= 5){
            climate.setSeason(Season.SPRING);
        }else if(month <= 8){
            climate.setSeason(Season.SUMMER);
        }else if(month <= 11){
            climate.setSeason(Season.AUTUMN);
        }
        Season newSeason = climate.getSeason();

        if (!newSeason.equals(oldSeason))
            view.setSeasonLabel(newSeason);

    }

    public Season getCurrentSeason(){
        return climate.getSeason();
    }

    /**
     * The method returns the displayed value for hours
     * @return The displayed value for hours
     */
    public String getDisplayedValueForHourTimer(){
        return hourTimer.getDisplayValue();
    }

    /**
     * The method returns the displayed value for days
     * @return The displayed value for days
     */
    public String getDisplayedValueFoDayTimer(){
        return dayTimer.getDisplayValue();
    }

    /**
     * The method returns the displayed value for months
     * @return The displayed value for months
     */
    public String getDisplayedValueForMonthTimer(){
        return monthTimer.getDisplayValue();
    }

    /**
     * The method returns the displayed value for years
     * @return The displayed value for years
     */
    public String getDisplayedValueForYearTimer(){
        return yearTimer.getDisplayValue();
    }


}