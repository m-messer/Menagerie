package Creatures.InternalSystems;

import Genes.Gene;
import SimulatorHelpers.Randomizer;

import java.util.Random;

/**
 * This class is part of Creatures.InternalSystems package, which indicate that this class in part of a system that can be implemented
 * in some, or all, the creatures. This package is inside the creatures' package since the internal system cannot exist without a creature.
 *  * And it is not inside the Animals package as plants and other creature may have internal systems.
 *
 * This class primarily serves as the reproductive system for some creatures. This class provides the essentials of the breading
 * mechanism to more complicated creatures.
 *
 *
 * This class was implemented to allow future variations that implements the reproductive system to be created and managed
 * smoothly. For this reason, some methods, e.g., crossover and mutate, were implemented in this class and were not included
 * in the geneTool class, as future extension would have more control in organizing alternative crossover and mutation mechanism.
 *
 * @version 2022-03-01
 */
public class ReproductiveSystem extends InternalSystem{

    // Mutate probability for genes
    private final static double MUTATE_PROBABILITY = 0.009;
    private final static Random rand = Randomizer.getRandom();

    /**
     * This method construct the reproductive system with its necessary information
     * @param genes the genes
     */
    public ReproductiveSystem(Gene[] genes) {
        super(genes);
    }

    /**
     * This method returns the gender of this creature.
     * @return 0 for Female, 1 for male.
     */
    public int getSex() {
        return getGenes()[0].getGeneValue()[0];
    }

    /**
     * This method flips the sex of an individual, which some animals have tha ability to do so.
     */
    public void flipSex() {
        getGenes()[0].getGeneValue()[0] = (getGenes()[0].getGeneValue()[0]+1)%2;
    }

    /**
     *
     * This method creates an offspring genes based on the parents' genes by coordinating this task,
     * which includes crossover and mutation as described on the crossover and mutation methods.
     *
     * @param g1 the first parents genes
     * @param g2 the second parents genes
     * @return the new offspring's genes
     */
    public Gene[] bread(Gene[] g1, Gene[] g2) {
        Gene[] newGene = new Gene[g1.length];

        // Determining the sex gene
        newGene[0] = new Gene(new int[] {rand.nextInt(2)});

        // Determining the other genes

        for (int i = 1; i < g1.length; i++) {
            newGene[i] = crossOver(g1[i],g2[i]);
            mutate(newGene[i]);
        }

        return newGene;
    }

    /**
     *
     * This method aims to introduce a mechanism for the offspring of creatures after breading. The new produced gene
     * is produced by splitting the parents' genes into half each, then the offspring would have the first half of
     * the first parent, and the second half from the second.
     *
     * @param g1 the first gene
     * @param g2 the second gene
     * @return a new gene
     */
    private Gene crossOver(Gene g1, Gene g2) {
        int[] geneDetails = new int[g1.getGeneValue().length];

        System.arraycopy(g1.getGeneValue(), 0, geneDetails, 0, g1.getGeneValue().length/2);
        System.arraycopy(g2.getGeneValue(), g1.getGeneValue().length/2, geneDetails, g1.getGeneValue().length/2, g1.getGeneValue().length/2);

        return new Gene(geneDetails);
    }

    /**
     * This method aims to serve the diversity of genes by introducing mutation mechanism in the reproductive system.
     *
     * The main reason that this method is not on the GeneTool class is that it depends on the mutation probability, which
     * is part of the reproductive system.
     * @param gene the gene to mutate
     */
    private void mutate(Gene gene) {

        for (int i = 0; i < gene.getGeneValue().length; i++)
            if (rand.nextDouble() <= MUTATE_PROBABILITY)
                gene.getGeneValue()[i] = (gene.getGeneValue()[i] + 1) % 2;

    }

}
