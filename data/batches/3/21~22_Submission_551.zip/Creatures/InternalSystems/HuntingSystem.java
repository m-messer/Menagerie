package Creatures.InternalSystems;

import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.*;

/**
 * This class is part of Creatures.InternalSystems package, which indicate that this class in part of a system that can be implemented
 * in some, or all, the creatures. This package is inside the creatures' package since the internal system cannot exist without a creature.
 * And it is not inside the Animals package as plants and other creature may have internal systems.
 *
 * This class is designed to act as the hunting system of predators. This class is implemented in order to provide predators a better
 * mechanism for hunting than random movement.
 *
 *
 * This class does not extend internalSystem class as this system in an external one.
 *
 *
 * @version 2022-03-01
 */
public class HuntingSystem {

    private Field field;
    private Location location;
    // The types of animals that this creature hunts
    private Class[] requiredTypes;

    /**
     *
     * This method construct the hunting system with its necessary information
     *
     * @param field the field of the simulator
     * @param location creature's location
     * @param requiredTypes the types of animals that this creature hunts
     */
    public HuntingSystem(Field field, Location location,  Class[] requiredTypes) {
        this.field = field;
        this.location = location;
        this.requiredTypes = requiredTypes;
    }

    /**
     * This method returns the best location to move to in order to hunt, or get closer, to the prey.
     * @return The best location to move to.
     */
    public Location getBestLocation(int visionScope) {
        Location prey = getBestPreyLocation(visionScope);
        if (prey == null)
            return null;

         Optional<Location> loc = field.adjacentLocations(location).stream()
                 .filter(i-> field.getLandAt(i).getAnimal() == null ||  ( field.getLandAt(i).getAnimal() != null && Arrays.asList(requiredTypes).contains(field.getLandAt(i).getAnimal().getClass())))
                 .min(Comparator.comparing(i->distance(i, prey)));

        return loc.orElse(null);
    }

    /**
     * This method returns the nearest location of prey according to creature's vision scope.
     * @return The nearest location of a prey.
     */
    private Location getBestPreyLocation(int visionScope) {
        LinkedList<Location> locs = field.getNBlockAdjacentLocations(location, visionScope, visionScope);
        Optional<Location> loc = locs.stream()
                .filter(i-> field.getLandAt(i).getAnimal() != null)
                .filter(i-> Arrays.asList(requiredTypes).contains(field.getLandAt(i).getAnimal().getClass()))
                .min(Comparator.comparing(this::distance));

        return loc.orElse(null);

    }

    /**
     * This method returns the distance between the current location of the predator and prey.
     *
     * @param prey prey's location
     * @return the distance between the current location of the predator and prey
     */
    private double distance(Location prey) {
        return Math.sqrt(Math.pow(location.getCol()-prey.getCol(),2)+Math.pow(location.getRow()-prey.getRow(),2));
    }

    /**
     *
     * This method returns the distance between a prey and a different location that aims to be the predator's. This method
     * is implemented in order to help to calculate the best immediate move that should make the predator nearer to the prey.
     *
     * @param predator A location that the  predator can move to
     * @param prey prey's location
     * @return the distance between the predator and prey
     */
    private double distance(Location predator, Location prey) {
        return Math.sqrt(Math.pow(predator.getCol()-prey.getCol(),2)+Math.pow(predator.getRow()-prey.getRow(),2));
    }

    /**
     * This method is intended to aid java garbage collector by nullifying objects
     */
    public void destruct() {
        field = null;
        location = null;
        requiredTypes = null;
    }

}
