package Creatures.InternalSystems;

import Genes.Gene;
import Genes.GeneTools;
import Genes.Virus;
import Creatures.Animals.Animal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.StatisticsRegisters.VirusesRegister;

/**
 * This class is part of Creatures.InternalSystems package, which indicate that this class in part of a system that can be implemented
 * in some, or all, the creatures. This package is inside the creatures' package since the internal system cannot exist without a creature.
 *  * And it is not inside the Animals package as plants and other creature may have internal systems.
 *
 * This class model an immune system of a creature. This class models the viruses that the immune system is fighting and the system's
 * developing immunity against them. Immunity can be developed gradually by the T-Cells, which reduce the danger of death from the virus.
 * However, the T-Cell does not reduce the infection danger. The viruses can only be developed if all of a creature's genes, except the
 * receptor, are all 1s. Viruses can be removed if, and only if, the complement of the virus does exist in one of the creature's genes.
 *
 *
 * @version 2022-03-01
 */

public class ImmuneSystem extends InternalSystem{

    // The viruses that the animal has
    private ArrayList<Virus> currentViruses = new ArrayList<>();
    // The T-Cell that the animal has
    private ArrayList<TCell> tCells = new ArrayList<>();

    /**
     * This method construct the immune system with its necessary information
     * @param genes the genes
     */
    public ImmuneSystem(Gene[] genes) {
        super(genes);
    }

    /**
     * This method invokes the attacking viruses and sickness methods, resulting in activate the immune system.
     * @param animal the creature that has this immune system instance.
     */
    public void invokeImmuneSystem(Animal animal) {
        attackViruses();
        sickness(animal);
    }

    /**
     *
     * This method perform the basic task of viruses and malfunctioning genes impacts on the creature. The impacts
     * could result in the animal's death. This method also invokes the method that is responsible for developing
     * viruses from genes as viruses are included as a sickness objects.
     *
     * @param animal the creature that has this immune system instance.
     */
    protected void sickness(Animal animal) {
        // Get the malfunctioning genes, which are identified by the 20th position if it is equal to 1.
        Object[] o = Arrays.stream(getGenes()).filter(i->i.getGeneValue().length > 1)
                .filter(i->i.getGeneValue()[20] == 1).map(Gene.class::cast).toArray();

        // This list will include all the malfunctioning genes and viruses
        ArrayList<Gene> genesList = new ArrayList<>();
        genesList.addAll(currentViruses);

        for (Object genO : o)
            genesList.add((Gene) genO);

        if (genesList.size() != 0)
            for (Gene geneObject : genesList) {
                // Getting the T-Cell immunity
                double tCellImmunity = 0;
                TCell tcell = getTCell(geneObject.getReceptor());
                if (tcell != null)
                    tCellImmunity += tcell.getReducedDanger();

                if (geneObject.getSicknessProbability() <= Randomizer.getRandom().nextDouble()-tCellImmunity) {
                    if (geneObject instanceof Virus)
                        VirusesRegister.recordDeath(geneObject.getReceptor());// Register the death from the virus

                    destruct();
                    animal.setDead();
                    return;
                }
                // Invoke the virus development mechanism since viruses can only be created by genes
                developingToVirus(geneObject);
            }
    }

    /**
     * This method perform the simple task of attacking viruses, resulting in either complete elimination of the virus, or developing
     * immunity against it.
     */
    private void attackViruses() {
        for (Iterator<Virus> it = currentViruses.iterator(); it.hasNext(); ) {
            Virus virus = it.next();
            if (isImmune(virus))
                it.remove();
            else
                developImmunity(virus);
        }
    }

    /**
     *
     * This method checks if the creature is immune against a certain virus or not. Complete immunity is achieved if the complement of
     * the virus's receptor exists in one of the creature's genes.
     *
     * @param virus the virus
     * @return true if this creature is immune, false otherwise
     */
    private boolean isImmune(Gene virus) {
        return Arrays.stream(getGenes()).map(Gene::getReceptor).anyMatch(i -> Arrays.equals(i, GeneTools.complement(virus.getReceptor())));
    }

    /**
     *
     * This method is intended to develop immunity against a certain virus. This method either increase the immunity
     * of the T-Cell if the T-Cell that attacks the virus exists, or it creates the T-Cell if the T-Cell does not exist.
     *
     * @param virus the virus to develop immunity against
     */
    private void developImmunity(Virus virus) {
        if (tCells.stream().map(TCell::getVirusReceptor).noneMatch(i -> i == virus.getReceptor())) {
            tCells.add(new TCell(virus.getReceptor()));
        }else {
            TCell cell = getTCell(virus.getReceptor());
            if (cell != null)
                cell.resistance();
        }
    }

    /**
     *
     * This method returns the T-Cell that attack the virus with the provided receptor
     *
     * @param receptor virus's receptor
     * @return the T-Cell that attacks this virus, null if the T-Cell does not exist
     */
    private TCell getTCell(int[] receptor) {
        for (TCell tCell : tCells)
            if (Arrays.equals(tCell.getVirusReceptor(), receptor))
                return tCell;

        return null;
    }

    /**
     *
     * This method acts as the main way to develop viruses from genes. Viruses on this simulation can only be created by genes if, and only if,
     * all the genomic information after the receptor are all 1s. The method checks if the virus does not exist, then check if that the gene have the
     * virus creation condition. The virus's receptor will be the gene's receptor.
     *
     * @param gene the gene to be used in order to create a virus
     */
    private void developingToVirus(Gene gene) {
        // Check if the creature does not have the viruses that is developed by this gene
        if (currentViruses.stream().map(Gene::getReceptor).noneMatch(i -> Arrays.equals(i, gene.getReceptor())))
            if (Arrays.stream(gene.getGeneValue()).skip(Gene.getSicknessStartPosition()).sum() == gene.getGeneValue().length - Gene.getSicknessStartPosition())
                currentViruses.add(new Virus(gene.getReceptor()));

    }

    /**
     *
     * This method returns a list of viruses that were released by the creature in order to infect other creatures according
     * to each virus's infection probability.
     *
     * @return A list of viruses that was released from the creature
     */
    public ArrayList<Virus> getReleasedViruses() {

        ArrayList<Virus> released = new ArrayList<>();

        for (Virus virus : currentViruses)
            if (virus.getInfectionProbability() <= Randomizer.getRandom().nextDouble())
                released.add(virus);

        return released;
    }

    /**
     * This method perform the simple tasks of infecting this creature and record the infected viruses.
     *
     * @param viruses the viruses that infected this creature
     */
    public void infect(ArrayList<Virus> viruses) {
        currentViruses.addAll(viruses);
        viruses.stream().map(Virus::getReceptor).forEach(VirusesRegister::recordInfection);
    }


    /**
     * This method is intended to aid java garbage collector by nullifying objects
     */
    public void destruct() {
        currentViruses = null;
        tCells = null;
    }

}
