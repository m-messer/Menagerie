package Creatures.InternalSystems;

import Genes.Gene;

/**
 * This class is part of Creatures.InternalSystems package, which indicate that this class in part of a system that can be implemented
 * in some, or all, the creatures. This package is inside the creatures' package since the internal system cannot exist without a creature.
 *  * And it is not inside the Animals package as plants and other creature may have internal systems.
 *
 * The internal system class is intended to serve as the basis for every internal system. In which, every system that will
 * serve an internal functionality, e.g, immune and reproductive systems, will implement this class as this class provides
 * the essence of these creatures, Genes.
 *
 *
 * @version 2022-03-01
 */
public abstract class InternalSystem {

    // The genes of the internal system
    private Gene[] genes;

    /**
     * This method construct the internal system object with its necessary information
     * @param genes System's gene
     */
    public InternalSystem(Gene[] genes) {
        this.genes = genes;
    }

    /**
     * This method returns the genes of the system
     * @return The genes of the internal system
     */
    public Gene[] getGenes() {
        return genes;
    }

    /**
     * This method is intended to aid java garbage collector by nullifying objects
     */
    protected void destruct() {
        genes = null;
    }



}
