package Creatures.InternalSystems;

/**
 *
 * This class is part of Creatures.InternalSystems package, which indicate that this class in part of a system that can be implemented
 * in some, or all, the creatures. This package is inside the creatures' package since the internal system cannot exist without a creature.
 *  * And it is not inside the Animals package as plants and other creature may have internal systems.
 *
 * This Class represent a T-Cell, which is the natural immune response for the system against viruses. Every T-Cell will
 * reduce one, and only one, virus death probability, which is the one that it has its receptor.
 *
 * @version 2022-03-01
 */
class TCell {
    // The receptor that this T-Cell are going to attack
    private final int[] virusReceptor;
    // The amount this T-Cell will reduce the efficacy of the virus death probability
    private double reducedDanger;

    /**
     * This method construct the T-Cell with the requred information
     * @param receptor virus's receptor
     */
    public TCell(int[] receptor) {
        this.virusReceptor = receptor;
        reducedDanger = 0;
    }

    /**
     * This method increase the resistance of the T-Cell against the virus
     */
    public void resistance() {
        if (reducedDanger < 1)
            reducedDanger += 0.019;
    }

    /**
     * This method returns the amount of danger that the tCell have
     * @return reducing danger probability
     */
    public double getReducedDanger() {
        return reducedDanger;
    }

    /**
     * This method returns the receptor that this T-Cell protects against
     * @return virus's receptor
     */
    public int[] getVirusReceptor() {
        return virusReceptor;
    }
}
