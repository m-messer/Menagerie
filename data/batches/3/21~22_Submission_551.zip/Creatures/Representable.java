package Creatures;

/**
 * This interface is intended to reduce the amount of codes needed to perform certain operation with representable objects.
 * For instance, accounting of assigning different objects (animal or plants) during run time. If this interface is deleted
 * a check for the instance is needed to cast. This approach will shorten the code. See SimulatorViewFX line 598.
 *
 * It is better in the previous case to choose a type that only contains both the animals and plants, and
 * only these.
 *
 * @version 2022-03-01
 */
public interface Representable {
}
