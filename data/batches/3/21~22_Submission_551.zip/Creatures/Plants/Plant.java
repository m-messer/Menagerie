package Creatures.Plants;

import Climate.Climate;
import Climate.Season;
import Creatures.Representable;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.HashMap;
import java.util.List;

/**
 * This class represents plants which can't move. They can self pollinate as a breeding mechanism.
 * Some plants are poisonous.
 *
 * @version 2022-03-01
 */
public abstract class Plant implements Representable {

    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;


    /**
     * This method creates the plant with its necessary information.
     *
     * @param field plant's field
     * @param location plant's location
     */
    public Plant(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * This method checks the plant is alive or not
     * @return true if the plant is alive, false otherwise.
     */
    public boolean isAlive() {
        return this.alive;
    }

    /**
     * This method sets the location of the plant
     * @param newLocation the new location
     */
    protected void setLocation(Location newLocation) {
        if (location != null)
            field.setPlant(null, location);
        location = newLocation;
        field.setPlant(this, newLocation);
    }

    /**
     * This method set the plant dead.
     */
    protected void setDead() {
        if (isAlive()) {
            alive = false;
            if (location != null) {
                field.setPlant(null, location);
                location = null;
                field = null;

            }
        }
    }

    /**
     * This method returns the field ob the plant
     * @return the field ob the plant
     */
    protected Field getField() {
        return field;
    }

    /**
     * This method returns the location of the plant
     * @return the location of the plant
     */
    protected Location getLocation() {
        return location;
    }


    /**
     * This method sets the breading probability for the plant depending on the season
     * @param breedingProbability breading probability collector
     */
    protected void setBreedingProbability(HashMap<Season, Double> breedingProbability) {
        for (Season s : Season.values()) {
            Climate climate = new Climate(s);
            breedingProbability.put(s, climate.calculateBreedingFactorPlants() * getBASE_BREEDING_PROBABILITY());
        }
    }

    /**
     * @param newPlants a reference to the plants to be added to the grid
     */
    public abstract void act(List<Plant>newPlants,Climate climate);

    /**
     * This method decrements plant's value, and it dies when it reaches 0
     */
    public abstract void decrementPlantValue();

    /**
     * This method returns tha value that is extracted by eating this plant
     * @return tha value that is extracted by eating this plant
     */
    public abstract int getPlantExtractedValue();

    /**
     * This method returns the plant's bade breeding probability
     * @return plant's bade breeding probability
     */
    abstract public double getBASE_BREEDING_PROBABILITY();

    /**
     * This method returns the plant's poisonous probability
     * @return plant's poisonous probability
     */
    abstract public double getPOISONOUS_PROBABILITY();

    /**
     * This method returns the plant's age
     * @return plant's age
     */
    abstract protected int getAge();

    /**
     * This method returns the plant's value
     * @return plant's value
     */
    abstract protected int getPlantEnergy();


    /**
     * This method aims to provide plant's information is representable form
     * @return plant's information
     */
    @Override
    public String toString() {
        return "Type: " + this.getClass().getName().replace(this.getClass().getPackageName() + ".", "") + "\n" +
                "Age: " + getAge() + "\n" +
                "Food Level: " + getPlantEnergy() + "\n" +
                "Location: " + location + "\n";
    }
}