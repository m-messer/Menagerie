package Creatures.Plants;

import Climate.Climate;
import Climate.Season;
import Climate.Weather;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.TerrainHelper.EnvironmentsLayout;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 *
 * This class represent an Elanor, which is a type of plant, in this simulation.
 *
 * @version 2022-03-01
 */
public class Elanor extends Plant{
    //Probability that a plant is poisonous - an animal dies when it eats this.
    private static final double POISONOUS_PROBABILITY = 0.01;
    //Probability that the plant breeds
    //Affected by the seasons a lot more than animals
    private static final double BASE_BREEDING_PROBABILITY = 0.8;
    private static HashMap<Season, Double> breedingProbability;
    //Maximum age that the plant lives for
    private static final int MAX_AGE = 55;
    //Minimum age before plant can begin breeding.
    private static final int BREEDING_AGE = 10;
    //Maximum number of seeds that can be produced by the plant
    private static final int MAX_LITTER_SIZE = 4;
    //The energy received by an animal after eating some part of the tree.
    private static final int GIVEN_ENERGY = 1;
    // Random variable to generate random numbers
    private static final Random rand = Randomizer.getRandom();
    //The energy gained by the plant after one cycle of photosynthesis
    private static final int PLANT_ENERGY = 1;
    //The nutritional value inside plant
    private int plantValue = 30;
    //Age at the current time
    private int age;


    /**
     * This method creates an Elanor instance with its necessary information
     *
     * @param randomAge true for random age, false otherwise
     * @param field the current field
     * @param location Elanor's location
     */
    public Elanor(boolean randomAge, Field field, Location location){
        super(field,location);
        breedingProbability = new HashMap<>();
        super.setBreedingProbability(breedingProbability);
        age = 0;

        if(randomAge)
            age = rand.nextInt(MAX_AGE);

    }


    /**
     *
     * This method acts as the main functionality that an Elanor has.
     *
     * @param newElanor a reference to the plants to be Elanors to the grid
     * @param climate the current climate
     */
    @Override
    public void act(List<Plant> newElanor, Climate climate) {
        incrementAge();
        if(isAlive()) {
            incrementPlantValue();
            produceSeeds(newElanor, climate.getSeason());
        }

    }

    /**
     * This method produces seed that act as plant's reproductive cycle.
     *
     * @param newPlants a reference to store the new plants
     */
    private void produceSeeds(List<Plant> newPlants, Season season){
        Field field = getField();
        List<Location> freeLocations = field.getFreeAdjacentLocations(getLocation(), EnvironmentsLayout.PLANTS);

        int births = breed(season);
        for (int i = 0; i < births && freeLocations.size() > 0; i++){
                Location loc = freeLocations.remove(0);
                Elanor elanor = new Elanor( false, field, loc);
                newPlants.add(elanor);
        }
    }

    /**
     * This method returns number of births in a litter depending on the season
     * @param season the current seasson
     * @return number of births in a litter depending on the season
     */
    private int breed(Season season) {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= breedingProbability.get(season))
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;

        return births;
    }

    /**
     * This method increments plant's age, and when it exceeds its maximum age, it dies.
     */
    private void incrementAge() {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * This method checks if a plant can bread
     * @return true if it can. false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }

    /**
     * This method increments plant's value
     */
    private void incrementPlantValue() {
        plantValue += PLANT_ENERGY;
    }


    /**
     * This method decrements plant's value, and it dies when it reaches 0
     */
    @Override
    public void decrementPlantValue(){
        plantValue-= GIVEN_ENERGY;
        if(plantValue == 0){
            setDead();
        }
    }

    /**
     * This method returns tha value that is extracted by eating this plant
     * @return tha value that is extracted by eating this plant
     */
    @Override
    public int getPlantExtractedValue(){
        return GIVEN_ENERGY;
    }

    /**
     * This method returns the plant's bade breeding probability
     * @return plant's bade breeding probability
     */
    @Override
    public double getBASE_BREEDING_PROBABILITY() {
        return BASE_BREEDING_PROBABILITY;
    }

    /**
     * This method returns the plant's poisonous probability
     * @return plant's poisonous probability
     */
    @Override
    public double getPOISONOUS_PROBABILITY() {
        return POISONOUS_PROBABILITY;
    }

    /**
     * This method returns the plant's age
     * @return plant's age
     */
    @Override
    protected int getAge() {
        return age;
    }

    /**
     * This method returns the plant's value
     * @return plant's value
     */
    @Override
    protected int getPlantEnergy(){
        return plantValue;
    }
}