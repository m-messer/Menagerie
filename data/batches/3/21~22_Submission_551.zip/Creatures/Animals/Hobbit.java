package Creatures.Animals;

import Climate.Season;
import Genes.Gene;
import SimulatorHelpers.TerrainHelper.EnvironmentsLayout;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.HashMap;
import java.util.List;

/**
 *
 * This class represents a hobbit. A hobbit can reproduce, eat during the day.
 *
 * @version 2022-03-01
 */
public class Hobbit extends Herbivores {

    // The age at which a hobbit can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a hobbit can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a hobbit breeding.
    private static final double BASE_BREEDING_PROBABILITY = 0.25;
    //Stores the breeding probability depending on the season
    private static HashMap<Season, Double> breedingProbability;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;

    // The maximum value for a hobbit's stomach
    private static final int MAX_STOMACH_VALUE = 15;
    // The value of food in a hobbit
    private static final int HOBBIT_FOOD_VALUE = 9;
    // The initial food level
    private static final int DEFAULT_LEVEL = 15;

    // Individual characteristics (instance fields).
    private int age;
    private int foodLevel;

    /**
     * Create a new hobbit. A hobbit may be created with age
     * zero (a new born) or with a random age.
     *
     * @param genes the genes assigned for each hobbit object
     * @param field The current state of the field
     * @param randomSettings If true, the hobbit will have random age and food level.
     * @param location The location where the new Elf should go
     */
    public Hobbit(Gene[] genes, Field field, Location location,  boolean randomSettings) {
        super(genes, field, location, randomSettings);
        breedingProbability = new HashMap<>();
        super.setBreedingProbability(breedingProbability);
    }
    
    /**
     * This is what the hobbit does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newHobbits A list to return newly born hobbits.
     * @param season the current season
     */
    @Override
    public void act(List<Animal> newHobbits, Season season) {
        incrementAge();
        incrementHunger();

        if (isAlive()) {

            if (super.getSex() == 0)
                reproduce(newHobbits, season);

            Location newLocation;
            if (foodLevel < MAX_STOMACH_VALUE) {
                // Try to move into a plant location.
                newLocation = eatPlants();
            }else{
                // See if it was possible to move.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if (newLocation == null) {
                // See if it was possible to move.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if (newLocation != null && isAlive()) {
                setLocation(newLocation);
            }else {
                // Overcrowding.
                if (isAlive())
                    setDead();
            }

            if (isAlive())
                super.invokeImmuneSystem();


        }
    }

    /**
     * Checks to see if adjacent mate of the opposite sex is there
     * and reproduces new elves in adjacent cells.
     * @param newHobbits the hobbits put into adjacent locations
     * @param season the current season
     */
    private void reproduce(List<Animal> newHobbits, Season season) {

        // New hobbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Animal mate = super.isAdjacentMateExists(this);

        if (mate != null) {

            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), EnvironmentsLayout.ANIMALS);
            int births = breed(season);
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Hobbit hobbit = new Hobbit(super.reproduceGenes(getGenes(), mate.getGenes()), field, loc, false);
                newHobbits.add(hobbit);
            }
        }
    }

    /**
     * Make this hobbit more hungry. This could result in the hobbit's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0 && isAlive()) {
            setDead();
        }
    }


    /**
     * Increase the age.
     * This could result in the hobbit's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE && isAlive()) {
            setDead();
        }
    }
    /**
     * This method returns animal's food value
     * @return animal's  food value
     */
    @Override
    protected int getFoodValue() {
        return HOBBIT_FOOD_VALUE;
    }


    /**
     * This method returns the animal's bade breeding probability
     * @return animal's bade breeding probability
     */
    @Override
    public double getBASE_BREEDING_PROBABILITY() {
        return BASE_BREEDING_PROBABILITY;
    }

    /**
     * This method returns animal's food level value
     * @return animal's food level value
     */
    @Override
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * This method sets animal's food level
     * @return the new food level
     */
    @Override
    protected void setFoodLevel(int level) {
        foodLevel = level;
    }

    /**
     * This method returns animal's maximum stomach value
     * @return animal's maximum stomach value
     */
    @Override
    protected int getMAX_STOMACH_VALUE() {
        return MAX_STOMACH_VALUE;
    }

    /**
     * This method returns animal's age
     * @return animal's age
     */
    @Override
    protected int getAge() {
        return age;
    }

    /**
     * This method returns animal's breading age
     * @return animal's beading age
     */
    @Override
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }


    /**
     * This method returns animal's maximum age
     * @return animal's maximum age
     */
    @Override
    protected int getMAX_AGE() {
        return MAX_AGE;
    }

    /**
     * This method returns animal's maximum litter size
     * @return animal's maximum litter size
     */
    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    /**
     * This method sets an animal's age to a new age
     * @param i the new age
     */
    @Override
    protected void setAge(int i) {
        if (i > 0) {
            age = i;
        }
    }

    /**
     * This method returns the breading probability list for an animal
     * @return the beading probability list for an animal
     */
    @Override
    protected HashMap<Season, Double> getBreedingProbabilityList() {
        return breedingProbability;
    }

    /**
     * This method returns the default food level for an animal
     * @return the default food level for an animal
     */
    @Override
    protected int getDEFAULT_LEVEL() {
        return DEFAULT_LEVEL;
    }
}
