package Creatures.Animals;

import Climate.Climate;
import Climate.Season;
import Creatures.Representable;
import Genes.Gene;
import Creatures.InternalSystems.ImmuneSystem;
import Creatures.InternalSystems.ReproductiveSystem;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.*;

/**
 * This class represent the basic characteristics that are shared between all animals in the simulation.
 *
 * @version 2022.03.1
 */
public abstract class Animal implements Representable{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The immune and reproductive systems.
    private ImmuneSystem immuneSystem;
    private ReproductiveSystem reproductiveSystem;

    /**
     * This method create a new animal at location in field.
     *
     * @param genes the genes of the animal
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomSettings If the animal will have a random age
     */
    public Animal(Gene[] genes, Field field, Location location, boolean randomSettings) {
        alive = true;
        immuneSystem = new ImmuneSystem(genes);
        reproductiveSystem = new ReproductiveSystem(genes);
        this.field = field;
        setLocation(location);
        if (randomSettings) {
            setAge(rand.nextInt(getMAX_AGE()));
            setFoodLevel(rand.nextInt(getMAX_STOMACH_VALUE()));
        }else {
            setAge(0);
            setFoodLevel(getDEFAULT_LEVEL());
        }
    }

    /**
     * This method sets the breading probability for the animal depending on the season
     * @param breedingProbability breading probability collector
     */
    public void setBreedingProbability(HashMap<Season, Double> breedingProbability) {
        for (Season s : Season.values()) {
            Climate climate = new Climate(s);
            breedingProbability.put(s, climate.calculateBreedingFactor() * getBASE_BREEDING_PROBABILITY());
        }
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param season the current season
     */
    abstract public void act(List<Animal> newAnimals, Season season);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    public void setDead() {
        if (isAlive()) {
            immuneSystem.destruct();
            immuneSystem = null;
            reproductiveSystem = null;
            alive = false;
            if (location != null) {
                field.setAnimal(null, location);
                location = null;
                field = null;
            }
        }
    }


    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(Season season) {
        int births = 0;

        if (canBreed() && rand.nextDouble() <= getBreedingProbabilityList().get(season))
            births = rand.nextInt(getMAX_LITTER_SIZE()) + 1;

        return births;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation() {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null)
            field.setAnimal(null, location);
        location = newLocation;
        field.setAnimal(this, newLocation);
    }

    /**
     * Return the animal's genes
     * @return the animal's genes
     */
    protected Gene[] getGenes() {
        return reproductiveSystem.getGenes();
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    public Field getField() {
        return field;
    }

    /**
     * Checks all adjacent locations for a mate and returns it if there
     * @param animal the animal looking for a mate
     * @return the mate of the animal or null if no adjacent mate exists
     */
    protected Animal isAdjacentMateExists(Animal animal) {

        //https://stackoverflow.com/questions/35743525/java-8-stream-cast-list-items-to-type-of-subclass
        Object[] o = animal.getField().adjacentLocations(getLocation()).stream()
                .map(i ->field.getLandAt(i).getAnimal())
                .filter(Objects::nonNull)
                .filter(i -> i.getClass() == animal.getClass())
                .filter(i->animal.getSex() != i.getSex()).toArray();

        if (o.length != 0)
            return (Animal) o[0];

        return null;
    }

    /**
     * This method returns a new genes based on the provided genes.
     *
     * @param parentA the first parent
     * @param parentB the second parent
     * @return the new genes
     */
    protected Gene[] reproduceGenes(Gene[] parentA, Gene[] parentB) {
        return reproductiveSystem.bread(parentA, parentB);
    }

    /**
     * This method invoke the immune system to perform its main tasks.
     */
    protected void invokeImmuneSystem() {
        immuneSystem.invokeImmuneSystem(this);
        if (isAlive()) {
            getField().adjacentLocations(getLocation()).forEach(this::exposeToInfection);
        }
    }

    /**
     * This method expose an animal to the released viruses from this animal.
     * @param location to be infected animal location
     */
    private void exposeToInfection(Location location) {
        if (location != null && getField().getLandAt(location).getAnimal() != null)
            getField().getLandAt(location).getAnimal().immuneSystem.infect(immuneSystem.getReleasedViruses());
    }

    /**
     * The method returns the sex of an animal instance
     * @return the sex of the individual. It is assumed that 1 maps to male, while 0 to female.
     */
    protected int getSex() {
        return reproductiveSystem.getSex();
    }

    /**
     * This method maps the assumed encodding, 1 maps to male, while 0 to female, to string.
     * @param sex 0 or 1
     * @return Male if sex is 1, Female otherwise. As assumed that there are only two sexes.
     */
    private String sexMapper(int sex) {
        return sex == 1? "Male" : "Female";
    }

    /**
     * This method invert the sex of an individual.
     */
    protected void flipSex() {
        reproductiveSystem.flipSex();
    }

    /**
     * This method checks if an animal can bread or not.
     * @return true if it can, false otherwise.
     */
    private boolean canBreed() {
        return getAge() >= getBreedingAge();
    }

    /**
     * This method returns animal's age
     * @return animal's age
     */
    protected abstract int getAge();

    /**
     * This method returns animal's breading age
     * @return animal's beading age
     */
    protected abstract int getBreedingAge();

    /**
     * This method returns animal's maximum age
     * @return animal's maximum age
     */
    protected abstract int getMAX_AGE();

    /**
     * This method returns animal's maximum litter size
     * @return animal's maximum litter size
     */
    protected abstract int getMAX_LITTER_SIZE();

    /**
     * This method sets an animal's age to a new age
     * @param i the new age
     */
    protected abstract void setAge(int i);

    /**
     * This method returns the breading probability list for an animal
     * @return the beading probability list for an animal
     */
    protected abstract HashMap<Season, Double> getBreedingProbabilityList();

    /**
     * This method returns the animal's bade breeding probability
     * @return animal's bade breeding probability
     */
    public abstract double getBASE_BREEDING_PROBABILITY();

    /**
     * This method returns animal's food value
     * @return animal's  food value
     */
    protected abstract int getFoodValue();

    /**
     * This method returns animal's food level value
     * @return animal's food level value
     */
    protected abstract int getFoodLevel();

    /**
     * This method sets animal's food level
     * @return the new food level
     */
    protected abstract void setFoodLevel(int level);

    /**
     * This method returns animal's maximum stomach value
     * @return animal's maximum stomach value
     */
    protected abstract int getMAX_STOMACH_VALUE();

    /**
     * This method returns the default food level for an animal
     * @return the default food level for an animal
     */
    protected abstract int getDEFAULT_LEVEL();

    /**
     * This method returns a representable string of an animal instance with the most important fields.
     * @return a representable string for animal object
     */
    @Override
    public String toString() {
        return "Type: " + this.getClass().getName().replace(this.getClass().getPackageName() + ".", "") + "\n" +
                "Age: " + getAge() + "\n" +
                "Sex: " + sexMapper(getSex()) + "\n" +
                "Food Level: " + getFoodLevel() + "\n" +
                "Location: " + location + "\n";
    }
}
