package Creatures.Animals;

import Climate.Season;
import Genes.Gene;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.TerrainHelper.EnvironmentsLayout;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.HashMap;
import java.util.List;
import java.util.Random;


/**
 * This class represents and model a holf. Holves are hunters that hunt for their prey. They also move, breed, and have some
 * special transformation during night.
 *
 * @version 2022-03-01
 */

public class Holf extends Hunters implements NightAnimal{

    // The age at which a holf can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a holf can live.
    private static final int MAX_AGE = 53;
    // The likelihood of a holf breeding.
    private static final double BASE_BREEDING_PROBABILITY = 0.25;
    //Stores the breeding probability for each respective season.
    private static HashMap<Season, Double> breedingProbability;
    // The probability that hold will transform to a hobbit at night
    private static final double TRANSFORMATION_PROBABILITY = 0.04;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // maximum food can a wolf have, i.e., the wolf can't eat because his is full
    private static final int MAX_STOMACH_VALUE = 50;
    // The probability of a hunt being successful
    private static final double HUNTING_PROBABILITY = 0.95;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The initial food level
    private static final int DEFAULT_LEVEL = 7;
    // The scope of vision
    private static final int BASE_SCOPE_VISION = 6;
    // Individual characteristics (instance fields).
    // The holf's age.
    private int age;
    // The holf's food level, which is increased by eating.
    private int foodLevel;

    /**
     * Create a new animal at location in field.
     *
     * @param genes the genes assigned for each holf object
     * @param field The current state of the field
     * @param randomSettings If true, the holf will have random age and food level.
     * @param location The location where the new Elf should go
     */
    public Holf(Gene[] genes, Field field, Location location, boolean randomSettings ) {
        super(genes, field, location, new Class[]{Dwarf.class, Elf.class, Hobbit.class}, randomSettings);
        breedingProbability =  new HashMap<>();
        super.setBreedingProbability(breedingProbability);
    }

    /**
     * This is what a holf does most of the time - it runs
     * around to find its prey. Sometimes it will breed or die of old age.
     * @param newHolves A list to return newly born holves.
     * @param season the current season
     */
    @Override
    public void act(List<Animal> newHolves, Season season) {

        incrementAge();
        incrementHunger();

        if (isAlive()) {

            if (super.getSex() == 0)
                reproduce(newHolves, season);

            Location newLocation;
            if (foodLevel < MAX_STOMACH_VALUE) {
                // Move towards a source of food if found.
                newLocation = eat(BASE_SCOPE_VISION + heightEffectsOnVisionScope());
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
            }else{
                // See if it was possible to move.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                super.destruct();
                setDead();
            }

            if (isAlive())
                super.invokeImmuneSystem();


        }
    }

    /**
     * At night the animals have a certain chance to turn into another species.
     * The animals can still do all the other things they could do before.
     * @param newHolves a reference to store new born holf
     * @param season the current season
     */
    @Override
    public void nightAct(List<Animal> newHolves, Season season) {
        if (isAlive()) {
            if (rand.nextDouble() < TRANSFORMATION_PROBABILITY) {
                Animal transformedAnimal = new Hobbit(getGenes(), getField(), getLocation(), false);
                getField().setAnimal(transformedAnimal, getLocation());
                newHolves.add(transformedAnimal);
            }

            if (super.getSex() == 0)
                reproduce(newHolves, season);

            Location newLocation;
            if (foodLevel < MAX_STOMACH_VALUE) {

                // Move towards a source of food if found.
                newLocation = eat(BASE_SCOPE_VISION + heightEffectsOnVisionScope());
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }

            }else{
                // Try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                super.destruct();
                setDead();
            }

            if (isAlive())
                super.invokeImmuneSystem();


        }

    }


    /**
     * Make this holf more hungry. This could result in the holf's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0 && isAlive()) {
            super.destruct();
            setDead();
        }
    }

    /**
     * Increase the age. This could result in the holf's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE && isAlive()) {
            super.destruct();
            setDead();
        }
    }


    /**
     * Check whether or not this holf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHolves A list to return newly born holf.
     * @param season the current season
     */
    private void reproduce(List<Animal> newHolves, Season season) {
        // New holf are born into adjacent locations.
        // Get a list of adjacent free locations.
        Animal mate = super.isAdjacentMateExists(this);

        if (mate != null) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), EnvironmentsLayout.ANIMALS);
            int births = breed(season);
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Holf young = new Holf(super.reproduceGenes(getGenes(), mate.getGenes()), field, loc, false);
                newHolves.add(young);
            }
        }
    }

    /**
     * This method returns animal's food value
     * @return animal's  food value
     */
    @Override
    protected int getFoodValue() {
        return 0;
    }


    /**
     * This method returns the animal's bade breeding probability
     * @return animal's bade breeding probability
     */
    @Override
    public double getBASE_BREEDING_PROBABILITY() {
        return BASE_BREEDING_PROBABILITY;
    }

    /**
     * This method returns animal's food level value
     * @return animal's food level value
     */
    @Override
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * This method sets animal's food level
     * @return the new food level
     */
    @Override
    protected void setFoodLevel(int level) {
        foodLevel = level;
    }

    /**
     * This method returns animal's maximum stomach value
     * @return animal's maximum stomach value
     */
    @Override
    protected int getMAX_STOMACH_VALUE() {
        return MAX_STOMACH_VALUE;
    }


    /**
     * This method returns animal's age
     * @return animal's age
     */
    @Override
    protected int getAge() {
        return age;
    }

    /**
     * This method returns animal's breading age
     * @return animal's beading age
     */
    @Override
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }


    /**
     * This method returns animal's maximum age
     * @return animal's maximum age
     */
    @Override
    protected int getMAX_AGE() {
        return MAX_AGE;
    }

    /**
     * This method returns animal's maximum litter size
     * @return animal's maximum litter size
     */
    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    /**
     * This method sets an animal's age to a new age
     * @param i the new age
     */
    @Override
    protected void setAge(int i) {
        if (i > 0) {
            age = i;
        }
    }


    /**
     * This method returns the breading probability list for an animal
     * @return the beading probability list for an animal
     */
    @Override
    protected HashMap<Season, Double> getBreedingProbabilityList() {
        return breedingProbability;
    }

    /**
     * this method returns the hunter's hunting probability
     * @return the hunter's hunting probability
     */
    @Override
    protected double getHUNTING_PROBABILITY() {
        return HUNTING_PROBABILITY;
    }


    /**
     * this method returns a random number
     * @return a random number
     */
    @Override
    protected double getNextProbability() {
        return rand.nextDouble();
    }

    /**
     * This method returns the default food level for an animal
     * @return the default food level for an animal
     */
    @Override
    protected int getDEFAULT_LEVEL() {
        return DEFAULT_LEVEL;
    }

    /**
     * This method returns the effects of the animal's height on its scope vision
     * @return an integer that represents effects of the animal's height on its scope vision
     */
    @Override
    protected int heightEffectsOnVisionScope(){
        return getField().getLandAt(getLocation()).getHeight() > 30? 1 : -1;
    };

}
