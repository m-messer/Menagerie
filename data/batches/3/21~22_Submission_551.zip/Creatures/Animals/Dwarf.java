package Creatures.Animals;

import Climate.Season;
import Genes.Gene;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.TerrainHelper.EnvironmentsLayout;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.HashMap;
import java.util.Random;
import java.util.List;

/**
 *
 * This class represents a dwarf. A dwarf can reproduce, eat during the day. The dwarf can also act at night where it
 * may transform into a Hobbit.
 *
 * @version 2022-03-01
 */
public class Dwarf extends Herbivores implements NightAnimal {

    //----Breeding age for dwarves----//
    private static final int BREEDING_AGE = 8;
    //----Transformation probability for dwarves----//
    private static final double TRANSFORMATION_PROBABILITY = 0.01;
    //----Maximum age for a dwarf----//
    private static final int MAX_AGE = 45;
    //----Breeding probability List depending on season---//
    private static HashMap<Season, Double> breedingProbability;
    private static final double BASE_BREEDING_PROBABILITY = 0.253;
    //----Maximum number of births----//
    private static final int MAX_LITTER_SIZE = 3;
    //----Shared random number generator to control breeding---//
    private static final Random rand = Randomizer.getRandom();
    //----Value gained after eating a dwarf-----//
    private static final int DWARF_FOOD_VALUE = 6;
    //---Maximum stomach capacity at any given time----//
    private static final int MAX_STOMACH_VALUE = 25;
    // The initial food level
    private static final int DEFAULT_LEVEL = 15;

    //Individual characteristics - think of others
    private int age;
    private int foodLevel;

    /**
     * Defines the parameters for every dwarf object.
     *
     * @param genes the genes assigned for each dwarf object
     * @param field The current state of the field
     * @param location The location where the new Dwarf should go
     * @param randomSettings If true, the dwarf will have random age and food level.
     */
    public Dwarf(Gene[] genes, Field field, Location location,  boolean randomSettings) {
        super(genes, field, location, randomSettings);
        breedingProbability = new HashMap<>();
        super.setBreedingProbability(breedingProbability);
    }

    /**
     * Controls the actions of a dwarf during the day
     * It ages, gets more hungry, can breed, eat plants and get ill
     * @param newDwarves A list to return newly born dwarves
     * @param season the current season
     */
    @Override
    public void act(List<Animal> newDwarves, Season season) {
        incrementAge();
        incrementHunger();

        if (isAlive()) {

            if (super.getSex() == 0)
                reproduce(newDwarves, season);

            if (foodLevel < MAX_STOMACH_VALUE) {
                // Try to move into a plant location.
                Location newLocation = eatPlants();
                if (newLocation == null) {
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }

                // See if it was possible to move.
                if (newLocation != null && isAlive()) {
                    setLocation(newLocation);
                }else {
                    // Overcrowding.
                    if (isAlive())
                        setDead();
                }
            }else {
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());

                // See if it was possible to move.
                if (newLocation != null && isAlive()) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }

            if (isAlive())
                super.invokeImmuneSystem();

        }

    }

    /**
     * Controls the actions of a dwarf during the night
     * It also ages, gets more hungry, can breed, eat plants and get ill
     * During the night, dwarfs can transform into Hobbits
     * @param newAnimals A list to return newly born dwarves
     * @param season the current season
     */
    @Override
    public void nightAct(List<Animal> newAnimals, Season season) {

        if (isAlive()) {
            if (rand.nextDouble() < TRANSFORMATION_PROBABILITY) {
                Animal transformedAnimal = new Hobbit(getGenes(),getField(), getLocation(), false);
                getField().setAnimal(transformedAnimal, getLocation());
                newAnimals.add(transformedAnimal);
            }
            if (super.getSex() == 0)
                reproduce(newAnimals, season);

            if (foodLevel < MAX_STOMACH_VALUE) {
                // Try to move into a free location.
                Location newLocation = eatPlants();
                if (newLocation == null) {
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }

                // See if it was possible to move.
                if (newLocation != null && isAlive()) {
                    setLocation(newLocation);
                }else {
                    // Overcrowding.
                    if (isAlive())
                        setDead();
                }
            }else {
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());

                // See if it was possible to move.
                if (newLocation != null && isAlive()) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    if (isAlive())
                        setDead();
                }
            }

            if (isAlive())
                super.invokeImmuneSystem();

        }
    }

    /**
     * Adds to age of animal
     * It dies if it's older than max age.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE && isAlive()) {
            setDead();
        }
    }

    /**
     * Checks to see if adjacent mate of the opposite sex is there
     * and reproduces new dwarves in adjacent cells.
     * @param newDwarves the dwarves put into adjacent locations
     */
    private void reproduce(List<Animal> newDwarves, Season season) {
        // New dwarf are born into adjacent locations.
        // Get a list of adjacent free locations.

        Animal mate = super.isAdjacentMateExists(this);

        if (mate != null) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), EnvironmentsLayout.ANIMALS);
            int births = breed(season);
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Dwarf dwarf = new Dwarf(super.reproduceGenes(getGenes(), mate.getGenes()), field, loc, false);
                newDwarves.add(dwarf);
            }
        }
    }


    /**
     * Decrements the foodLevel of the animal
     * Dies if food level reaches 0
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0 && isAlive()) {
            setDead();
        }
    }


    /**
     * This method returns animal's food value
     * @return animal's  food value
     */
    @Override
    protected int getFoodValue() {
        return DWARF_FOOD_VALUE;
    }


    /**
     * This method returns animal's food level value
     * @return animal's food level value
     */
    @Override
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * This method sets animal's food level
     * @return the new food level
     */
    @Override
    protected void setFoodLevel(int level) {
        foodLevel = level;
    }

    /**
     * This method returns animal's maximum stomach value
     * @return animal's maximum stomach value
     */
    @Override
    protected int getMAX_STOMACH_VALUE() {
        return MAX_STOMACH_VALUE;
    }

    /**
     * This method returns the animal's bade breeding probability
     * @return animal's bade breeding probability
     */
    @Override
    public double getBASE_BREEDING_PROBABILITY() {
        return BASE_BREEDING_PROBABILITY;
    }

    /**
     * This method returns animal's age
     * @return animal's age
     */
    @Override
    protected int getAge() {
        return age;
    }

    /**
     * This method returns animal's breading age
     * @return animal's beading age
     */
    @Override
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }


    /**
     * This method returns animal's maximum age
     * @return animal's maximum age
     */
    @Override
    protected int getMAX_AGE() {
        return MAX_AGE;
    }

    /**
     * This method returns animal's maximum litter size
     * @return animal's maximum litter size
     */
    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }


    /**
     * This method sets an animal's age to a new age
     * @param i the new age
     */
    @Override
    protected void setAge(int i) {
        if (i > 0) {
            age = i;
        }
    }

    /**
     * This method returns the breading probability list for an animal
     * @return the beading probability list for an animal
     */
    @Override
    protected HashMap<Season, Double> getBreedingProbabilityList() {
        return breedingProbability;
    }

    /**
     * This method returns the default food level for an animal
     * @return the default food level for an animal
     */
    @Override
    protected int getDEFAULT_LEVEL() {
        return DEFAULT_LEVEL;
    }
}
