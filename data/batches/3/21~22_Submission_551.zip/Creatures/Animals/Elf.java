package Creatures.Animals;

import Climate.Season;
import Genes.Gene;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.TerrainHelper.EnvironmentsLayout;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 *
 * This class represents an elf. An elf can reproduce, eat during the day. The elf can also act at night where it
 * may transform into a Hobbit.
 *
 * @version 2022-03-01
 */

public class Elf extends Herbivores implements NightAnimal {

    //breeding age for Elves
    private static final int BREEDING_AGE = 8;
    //largest age to which an elf can survive
    private static final int MAX_AGE = 70;
    //probability that an elf breeds
    private static final double BASE_BREEDING_PROBABILITY = 0.2519;
    private static final double TRANSFORMATION_PROBABILITY = 0.01;
    //Stores the breeding probability for each respective season.
    private static HashMap<Season, Double> breedingProbability;
    //maximum elves that can be laid by an elf
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single Creatures.Animals.Elf. In effect, this is the
    // number of steps a  can go before it has to eat again.
    private static final int ELF_FOOD_VALUE = 16;
    // The maximum value for an elf's stomach
    private static final int MAX_STOMACH_VALUE = 25;
    //----Shared random number generator to control breeding---//
    private static final Random rand = Randomizer.getRandom();
    // The initial food level
    private static final int DEFAULT_LEVEL = 10;

    //Individual characteristics - think of others
    private int age;
    private int foodLevel;

    /**
     * Defines the parameters for every Elf object.
     *
     * @param genes the genes assigned for each elf object
     * @param field The current state of the field
     * @param randomSettings If true, the elf will have random age and food level.
     * @param location The location where the new Elf should go
     */
    public Elf(Gene[] genes, Field field, Location location, boolean randomSettings) {
        super(genes, field, location, randomSettings);
        breedingProbability = new HashMap<>();
        super.setBreedingProbability(breedingProbability);
    }


    /**
     * Controls the actions of a elf during the day
     * It ages, gets more hungry, can breed, eat plants and get ill
     * @param newElves A list to return newly born dwarves
     * @param season The current season
     */
    @Override
    public void act(List<Animal> newElves, Season season) {
        incrementAge();
        incrementHunger();

        if (isAlive()) {

            if (super.getSex() == 0)
                reproduce(newElves, season);

            Location newLocation;
            if (foodLevel < MAX_STOMACH_VALUE) {
                // Try to move into a plant location.
                newLocation = eatPlants();
            }else{
                // Try to move into a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            // See if it was possible to move.
            if (newLocation == null) {
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if (newLocation != null && isAlive()) {
                setLocation(newLocation);
            }else {
                // Overcrowding.
                if (isAlive())
                    setDead();
            }

            if (isAlive())
                super.invokeImmuneSystem();


        }
    }

    /**
     * Controls the actions of an elf during the night
     * It also ages, gets more hungry, can breed, eat plants and get ill
     * During the night, an elf may transform into Hobbits
     * @param newElves A list to return newly born dwarves
     * @param season the current season
     */
    @Override
    public void nightAct(List<Animal> newElves, Season season) {

        if (isAlive()) {
            //Turning an Orc into an Elf
            if (rand.nextDouble() < TRANSFORMATION_PROBABILITY) {
                Animal transformedAnimal = new Hobbit(getGenes(),getField(), getLocation(), false);
                getField().setAnimal(transformedAnimal, getLocation());
            }
            if (super.getSex() == 0)
                reproduce(newElves, season);

            if (foodLevel < MAX_STOMACH_VALUE) {
                // Move towards a source of food if found.
                Location newLocation = eatPlants();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null && isAlive()) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    if (isAlive() && isAlive()) {
                        setDead();
                    }

                }
            }else{
                Location newLocation = getField().freeAdjacentLocation(getLocation());

                // See if it was possible to move.
                if (newLocation != null && isAlive()) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    if (isAlive())
                        setDead();
                }
            }

            if (isAlive())
                super.invokeImmuneSystem();

        }
    }


    /**
     * Make this Elf more hungry. This could result in the elf's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0 && isAlive()) {
            setDead();
        }
    }

    /**
     * Checks to see if adjacent mate of the opposite sex is there
     * and reproduces new elves in adjacent cells.
     * @param newElves the dwarves put into adjacent locations
     */
    private void reproduce(List<Animal> newElves, Season season) {
        // New elf are born into adjacent locations.
        // Get a list of adjacent free locations.
        Animal mate = super.isAdjacentMateExists(this);

        if (mate != null) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), EnvironmentsLayout.ANIMALS);
            int births = breed(season);
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Elf elf = new Elf(super.reproduceGenes(getGenes(), mate.getGenes()), field, loc, false);
                newElves.add(elf);
            }
        }
    }

    /**
     * Adds to age of animal
     * It dies if it's older than max age.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE && isAlive()) {
            setDead();
        }
    }

    /**
     * This method returns animal's food value
     * @return animal's  food value
     */
    @Override
    protected int getFoodValue() {
        return ELF_FOOD_VALUE;
    }


    /**
     * This method returns the animal's bade breeding probability
     * @return animal's bade breeding probability
     */
    @Override
    public double getBASE_BREEDING_PROBABILITY() {
        return BASE_BREEDING_PROBABILITY;
    }

    /**
     * This method returns animal's food level value
     * @return animal's food level value
     */
    @Override
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * This method sets animal's food level
     * @return the new food level
     */
    @Override
    protected void setFoodLevel(int level) {
        foodLevel = level;
    }

    /**
     * This method returns animal's maximum stomach value
     * @return animal's maximum stomach value
     */
    @Override
    protected int getMAX_STOMACH_VALUE() {
        return MAX_STOMACH_VALUE;
    }

    /**
     * This method returns animal's age
     * @return animal's age
     */
    @Override
    protected int getAge() {
        return age;
    }

    /**
     * This method returns animal's breading age
     * @return animal's beading age
     */
    @Override
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }


    /**
     * This method returns animal's maximum age
     * @return animal's maximum age
     */
    @Override
    protected int getMAX_AGE() {
        return MAX_AGE;
    }

    /**
     * This method returns animal's maximum litter size
     * @return animal's maximum litter size
     */
    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    /**
     * This method sets an animal's age to a new age
     * @param i the new age
     */
    @Override
    protected void setAge(int i) {
        if (i > 0) {
            age = i;
        }
    }

    /**
     * This method returns the breading probability list for an animal
     * @return the beading probability list for an animal
     */
    @Override
    protected HashMap<Season, Double> getBreedingProbabilityList() {
        return breedingProbability;
    }

    /**
     * This method returns the default food level for an animal
     * @return the default food level for an animal
     */
    @Override
    protected int getDEFAULT_LEVEL() {
        return DEFAULT_LEVEL;
    }
}

