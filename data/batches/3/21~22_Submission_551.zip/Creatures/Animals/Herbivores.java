package Creatures.Animals;

import Creatures.Plants.Plant;
import Genes.Gene;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Models herbivores
 * In addition to doing what animals can do they can also eat plants in the simulation
 * @version 2022-03-01
 */
public abstract class Herbivores extends Animal {

    // A random variable to generate random numbers
    private Random random;


    /**
     * Create a new herbivores with its necessarily information.
     *
     * @param genes the genes of the animal
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param randomSettings random settings for its information, age.
     */
    public Herbivores(Gene[] genes, Field field, Location location, boolean randomSettings) {
        super(genes, field, location, randomSettings);
        random = Randomizer.getRandom();;

    }

    /**
     * This method acts as the eating mechanism for all herbivores.
     * @return where the plant is.
     */
    protected Location eatPlants() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            if (field.getLandAt(where).getPlant() != null) {
                //Without the instance check the cast wouldn't be safe
                Plant plant = field.getLandAt(where).getPlant();
                if (plant.isAlive()) {
                    if (random.nextDouble() <= plant.getPOISONOUS_PROBABILITY()) {
                        if (this.isAlive())
                            setDead();
                    }else{
                        plant.decrementPlantValue();
                        this.setFoodLevel(getFoodLevel()+plant.getPlantExtractedValue());
                        if (this.getFoodLevel() > this.getMAX_STOMACH_VALUE())
                            this.setFoodLevel(this.getMAX_STOMACH_VALUE());
                    }

                    return where;
                }
            }

        }

        return null;

    }

}