package Creatures.Animals;

import Climate.Season;
import Genes.Gene;
import SimulatorHelpers.Randomizer;
import SimulatorHelpers.TerrainHelper.EnvironmentsLayout;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

import java.util.HashMap;
import java.util.List;
import java.util.Random;


/**
 * This class represents and model an orc. Orcs are hunters that hunt for their prey. They also move, breed, and have some
 * special transformation during night.
 *
 * @version 2022-03-01
 */
public class Orc extends Hunters implements NightAnimal {
    // Characteristics shared by all orcs (class variables).

    // The age at which an orc can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which an orc can live.
    private static final int MAX_AGE = 55;
    // The likelihood of an orc breeding.
    private static final double BASE_BREEDING_PROBABILITY = 0.25;
    private static final double TRANSFORMATION_PROBABILITY = 0.01;
    private static HashMap<Season, Double> breedingProbability;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // maximum food can an orc have, i.e., the orc can't eat because his is full
    private static final int MAX_STOMACH_VALUE = 40;
    // The probability of a hunt being successful
    private static final double HUNTING_PROBABILITY = 0.9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The value of food in one orc
    private static final int ORC_FOOD_VALUE = 16;
    // The initial food level
    private static final int DEFAULT_LEVEL = 12;
    // The scope of vision
    private static final int BASE_SCOPE_VISION = 6;


    // Individual characteristics (instance fields).
    // The orc's age.
    private int age;
    // The orc's food level, which is increased by eating hobbits.
    private int foodLevel;

    /**
     * Create an orc. An orc can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param genes the genes assigned for each orc object
     * @param randomSettings If true, the orc will have random age and food level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Orc(Gene[] genes, Field field, Location location, boolean randomSettings) {
        super(genes, field, location, new Class[]{Hobbit.class, Elf.class, Dwarf.class, Holf.class}, randomSettings);
        breedingProbability = new HashMap<>();
        super.setBreedingProbability(breedingProbability);

    }
    
    /**
     * This is what the orc does most of the time: it hunts for
     * hobbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newOrcs A list to return newly born orcs.
     * @param season the current season
     */
    @Override
    public void act(List<Animal> newOrcs, Season season) {
        incrementAge();
        incrementHunger();

        if (isAlive()) {

            if (super.getSex() == 0)
                reproduce(newOrcs, season);

            Location newLocation;
            if (foodLevel < MAX_STOMACH_VALUE) {
                // Move towards a source of food if found.
                newLocation = eat(BASE_SCOPE_VISION + heightEffectsOnVisionScope());
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }

            }else{
                // See if it was possible to move.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if (newLocation != null && isAlive()) {
                setLocation(newLocation);
            } else {
                if (isAlive()) {
                    // Overcrowding.
                    super.destruct();
                    setDead();
                }
            }

            if (isAlive())
                super.invokeImmuneSystem();



        }

    }

    /**
     * This method perform the orc's night act.
     * @param newOrcs a reference to store potential offspring
     * @param season the current season
     */
    @Override
    public void nightAct(List<Animal> newOrcs, Season season) {
        if (isAlive() && rand.nextDouble() < TRANSFORMATION_PROBABILITY)
            flipSex();
    }

    /**
     * Increase the age. This could result in the Orc's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE && isAlive()) {
            super.destruct();
            setDead();
        }
    }
    
    /**
     * Make this orc more hungry. This could result in the orc's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0 && isAlive()) {
            super.destruct();
            setDead();
        }
    }

    /**
     * Check whether or not this orc is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrcs A list to return newly born orcs.
     */
    private void reproduce(List<Animal> newOrcs, Season season) {
        // New orcs are born into adjacent locations.
        // Get a list of adjacent free locations.

        Animal mate = super.isAdjacentMateExists(this);

        if (mate != null) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation(), EnvironmentsLayout.ANIMALS);
            int births = breed(season);
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Orc young = new Orc(super.reproduceGenes(getGenes(), mate.getGenes()), field, loc, false);
                newOrcs.add(young);
            }
        }
    }

    /**
     * This method returns animal's food value
     * @return animal's  food value
     */
    @Override
    protected int getFoodValue() {
        return ORC_FOOD_VALUE;
    }


    /**
     * This method returns the animal's bade breeding probability
     * @return animal's bade breeding probability
     */
    @Override
    public double getBASE_BREEDING_PROBABILITY() {
        return BASE_BREEDING_PROBABILITY;
    }

    /**
     * This method returns animal's food level value
     * @return animal's food level value
     */
    @Override
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * This method sets animal's food level
     * @return the new food level
     */
    @Override
    protected void setFoodLevel(int level) {
        foodLevel = level;
    }

    /**
     * This method returns animal's maximum stomach value
     * @return animal's maximum stomach value
     */
    @Override
    protected int getMAX_STOMACH_VALUE() {
        return MAX_STOMACH_VALUE;
    }


    /**
     * This method returns animal's age
     * @return animal's age
     */
    @Override
    protected int getAge() {
        return age;
    }

    /**
     * This method returns animal's breading age
     * @return animal's beading age
     */
    @Override
    protected int getBreedingAge() {
        return BREEDING_AGE;
    }


    /**
     * This method returns animal's maximum age
     * @return animal's maximum age
     */
    @Override
    protected int getMAX_AGE() {
        return MAX_AGE;
    }

    /**
     * This method returns animal's maximum litter size
     * @return animal's maximum litter size
     */
    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    /**
     * This method sets an animal's age to a new age
     * @param i the new age
     */
    @Override
    protected void setAge(int i) {
        if (i > 0) {
            age = i;
        }
    }


    /**
     * This method returns the breading probability list for an animal
     * @return the beading probability list for an animal
     */
    @Override
    protected HashMap<Season, Double> getBreedingProbabilityList() {
        return breedingProbability;
    }

    /**
     * this method returns the hunter's hunting probability
     * @return the hunter's hunting probability
     */
    @Override
    protected double getHUNTING_PROBABILITY() {
        return HUNTING_PROBABILITY;
    }


    /**
     * this method returns a random number
     * @return a random number
     */
    @Override
    protected double getNextProbability() {
        return rand.nextDouble();
    }

    /**
     * This method returns the default food level for an animal
     * @return the default food level for an animal
     */
    @Override
    protected int getDEFAULT_LEVEL() {
        return DEFAULT_LEVEL;
    }

    /**
     * This method returns the effects of the animal's height on its scope vision
     * @return an integer that represents effects of the animal's height on its scope vision
     */
    @Override
    protected int heightEffectsOnVisionScope(){
        return getField().getLandAt(getLocation()).getHeight() > 30? 1 : -1;
    };
}