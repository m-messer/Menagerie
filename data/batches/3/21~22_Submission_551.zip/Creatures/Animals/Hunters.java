package Creatures.Animals;

import Genes.Gene;

import java.util.Arrays;

import Creatures.InternalSystems.HuntingSystem;
import SimulatorHelpers.TerrainHelper.Field;
import SimulatorHelpers.TerrainHelper.Location;

/**
 *
 * This class represents hunters. A hunter can hunt other animals, as they are the hunter's source of food.
 *
 * @version 2022-03-01
 */
public abstract class Hunters extends Animal {

    private HuntingSystem huntingSystem;
    private Class[] requiredTypes;

    /**
     * Create a new hunter at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Hunters(Gene[] genes, Field field, Location location, Class[] requiredTypes, boolean randomSettings) {
        super(genes, field, location, randomSettings);
        huntingSystem = new HuntingSystem(field, location, requiredTypes);
        this.requiredTypes = requiredTypes;
    }

    /**
     * This method acts as the eating mechanism for all hunters.
     * @return where the plant is.
     */
    protected Location eat(int visionScope) {

            Location loc = huntingSystem.getBestLocation(visionScope);
            if (loc == null)
                return null;

            Animal animal = getField().getLandAt(loc).getAnimal();

            if (animal != null) {
                if (getNextProbability() <= getHUNTING_PROBABILITY()) {
                    if (Arrays.asList(requiredTypes).contains(animal.getClass())) {
                        if (animal.isAlive()) {
                            animal.setDead();
                            setFoodLevel(animal.getFoodValue());
                            setFoodLevel(getFoodLevel() + animal.getFoodLevel());
                            if (getFoodLevel() > getMAX_STOMACH_VALUE())
                                setFoodLevel(getMAX_STOMACH_VALUE());
                            return loc;
                        }

                    }
                }
                return getLocation();
            }

        return loc;

    }

    /**
     * This method in intended to aid java garbage collector
     */
    protected void destruct() {
        huntingSystem.destruct();
        huntingSystem = null;
        requiredTypes = null;
    }

    /**
     * this method returns the hunter's hunting probability
     * @return the hunter's hunting probability
     */
    protected abstract double getHUNTING_PROBABILITY();

    /**
     * this method returns a random number
     * @return a random number
     */
    protected abstract double getNextProbability();

    /**
     * This method returns the effects of the animal's height on its scope vision
     * @return an integer that represents effects of the animal's height on its scope vision
     */
    protected abstract int heightEffectsOnVisionScope();


}
