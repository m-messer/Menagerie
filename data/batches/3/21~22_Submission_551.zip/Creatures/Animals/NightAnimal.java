package Creatures.Animals;

import Climate.Season;

import java.util.List;

/**
 * This interface provides a base for actions that only animals of the night can undertake. Animals that act at night
 * have to implement this interface
 *
 * @version 2022-03-01
 */
public interface NightAnimal {
    void nightAct(List<Animal> newAnimals, Season season);

}
