import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing wolves, snakes, deer, hedgehogs and squirrels.
 *
 * @version 2021.03.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.035;
    // The probability that a rabbit will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.045;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.035;
    // The probability that a hedgehog will be created in any given grid position.
    private static final double HEDGEHOG_CREATION_PROBABILITY = 0.045;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.045;
    // The probability that a plant will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.15;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The string for the current time of day (day or night).
    private String timeOfDay;
    // A graphical view of the simulation.
    private SimulatorView view;
    //The time of day. True if daytime, false otherwise.
    private boolean isDay;
    // The current weather.
    private Weather weather;
    // The string for the current weather.
    private String currentWeather; 

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Deer.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Snake.class, Color.BLACK);
        view.setColor(Hedgehog.class, Color.PINK);
        view.setColor(Squirrel.class, Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);

        isDay = true;

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(200);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actor.
     */
    public void simulateOneStep()
    {
        timeOfDay();
        step++;
        currentWeather = weather.getWeatherString();
        // Provide space for new actors.
        List<Actor> newActors = new ArrayList<>();

        // make all the new actors act based the time of day
        timeBehaviour(newActors);

        // Add the new actors to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field, getTimeOfDayString(), weather.getWeatherString());
    }

    /**
     * Return the current step of the simulation.
     * @return step The current step of the simulation.
     */
    public int getStep()
    {
        return step;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate(field, actors);

        // Show the starting state in the view.
        view.showStatus(step, field, getTimeOfDayString(), weather.getWeatherString());
    }

    /**
     * Randomly populate the field with actors.
     */
    private void populate(Field field, List<Actor> actors)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Actor wolf = new Wolf(true, field, location);
                    actors.add(wolf);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Actor deer = new Deer(true, field, location);
                    actors.add(deer);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Actor snake = new Snake(true, field, location);
                    actors.add(snake);
                }
                else if(rand.nextDouble() <= HEDGEHOG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Actor hedgehog = new Hedgehog(true, field, location);
                    actors.add(hedgehog);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Actor squirrel = new Squirrel(true, field, location);
                    actors.add(squirrel);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Actor grass = new Grass(true, field, location);
                    actors.add(grass);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Alternate between day and night every 5 steps.
     * (daytime for 5 steps and nighttime for 5 steps)
     */
    private void timeOfDay()
    {
        if(getStep() % 5 == 0){
            for(int i = 0; i<5;i++){
                isDay = !isDay;
            }
        }
    }

    /**
     * Return the boolean value for the time of day. True if daytime, false otherwise.
     * @return isDay Return true is day, false otherwise.
     */
    private boolean getIsDay()
    {
        return isDay;
    }

    /**
     * Return the string corresponding to the time of day.
     * @return timeOfDay Return "Day" if isDay is true, "Night" if false
     */
    private String getTimeOfDayString()
    {
        if(isDay){
            timeOfDay = "Day";
        }
        else{
            timeOfDay = "Night";
        }
        return timeOfDay;
    }

    /**
     * Make the actors act differently depending on the time of day.
     * The snakes and hedgehogs can act only during the day and sleep at night (don't move).
     * The wolves and deer can only act at night and slee during the day (don't move).
     * The squirrels act all the time.
     * The plants can only grow and propagate during the day.
     */
    private void timeBehaviour(List<Actor> newActors)
    {
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            String day = getTimeOfDayString();
            switch(day){
                case "Day":

                if(actor instanceof Snake || actor instanceof Squirrel || actor instanceof Hedgehog || actor instanceof Grass)
                {
                    actor.act(newActors,currentWeather);
                }
                if(! actor.isActive()) {
                    it.remove();
                }
                break;

                case "Night":

                if(actor instanceof Wolf || actor instanceof Squirrel || actor instanceof Deer)
                {
                    actor.act(newActors,currentWeather);
                }
                if(! actor.isActive()) {
                    it.remove();
                }
                break;
            }
        }
    }
}