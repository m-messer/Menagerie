import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a deer.
 * Deers age, move, breed, eat grass, and die.
 *
 * @version 2021.03.02
 */
public class Deer extends Animal
{
    // Characteristics shared by all deers (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a deer can live.
    private static final int MAX_AGE = 72;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //The food value of a single deer.
    private static final int FOOD_VALUE = 12;
    // The food value of a single plant. In effect, this is the
    // number of steps a deer can go before it has to eat again.
    private static final int MAX_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The deer's age.
    private int age;
    // The deer's food level, which is increased by eating plants.
    private int foodLevel;
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the deer does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newDeers A list to return newly born deers.
     * @param currentWeather The current weather in the simulator.
     */
    public void act(List<Actor> newDeers, String currentWeather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(meetOppositeGender()){
                giveBirth(newDeers);   
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Checks adjacent locations for an animal of the same species and opposite sex.
     * if true, the animals can breed.
     * @return true if the animals are of opposite sexes, false otherwise.
     */
    private boolean meetOppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Deer){
                Deer deer = (Deer) animal;
                if(this.isFemale() != deer.isFemale()){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    setFoodLevel(grass.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Returns the maximum age of the deer
     * @return MAX_AGE The maximum age of the deer
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

     /**
     * Return the age at which deer can breed
     * @return The age at which deer can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the maximum litter size of a deer
     * @return maxLitterSize The maximum litter size of a deer
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the deer's breeding probability.
     * @return BREEDING_PROBABILITY The breeding probability of a deer.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the deer's food value.
     * @return FOOD_VALUE the deer's food value.
     */
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * Return the deer's max food value.
     * @return MAX_FOOD_VALUE
     */
    protected int getMaxFoodValue()
    {
        return MAX_FOOD_VALUE;
    }

    /**
     * Create a deer. A deer can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the deer will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location)
    {
        return new Deer(randomAge, field, location);
    }
}
