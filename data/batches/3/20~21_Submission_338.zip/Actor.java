import java.util.List;

/**
 * Write a description of interface Actor here.
 *
 * @version (a version number or a date)
 */
public interface Actor
{
    /**
     * Perform the actor's regular behaviour.
     * @param newActors A list for receiving newly created actors.
     * @param currentWeather The current weather in the simulator
     */
    void act(List<Actor> newActors, String currentWeather);
    
    /**
     * Is the actor still active?
     * @return true if still active, false if not.
     */
    boolean isActive();
}
