import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * A simple model of a snake.
 * snakes age, move, eat hedgehogs and squirrels, and die.
 *
 * @version 2021.03.02
 */
public class Snake extends Animal
{
    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a snake can live.
    private static final int MAX_AGE = 168;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of a squirrel and a hedgehog. In effect, this is the
    // number of steps a snake can go before it has to eat again.
    private static final int MAX_FOOD_VALUE = 14;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The snake's age.
    private int age;
    // The snake's food level, which is increased by eating squirrels or hedgehogs.
    private int foodLevel;

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the snake does most of the time: it hunts for
     * squirrels or hedgehogs. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newSnakes A list to return newly born snakes.
     * @param currentWeather The current weather in the simulator
     */
    public void act(List<Actor> newSnakes, String currentWeather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(meetOppositeGender()){
                giveBirth(newSnakes);  
            }
            // Move towards a source of food if found.
            Location newLocation = findFood(currentWeather);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Checks for prey in adjacent locations. If the weather is foggy,
     * the snake can only check one adjacent location. Else, it checks all adjacent locations
     * @param String currentWeather The current weather.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(String currentWeather)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        Location where = null;
        if(currentWeather.equals("fog")){
            where = adjacent.get(0);
            checkForPrey(field,where);
        }else{
            while(it.hasNext()) {
                where = it.next();
                checkForPrey(field,where);
            }
        }
        return null;
    }

    /**
     * Look for squirrels or hedgehogs adjacent to the current location.
     * Only the first live squirrel or hedgehog is eaten.
     */
    private Location checkForPrey(Field field, Location where)
    {
        Object animal = field.getObjectAt(where);
        if(animal instanceof Squirrel) {
            Squirrel squirrel = (Squirrel) animal;
            if(squirrel.isAlive()) { 
                squirrel.setDead();
                foodLevel = squirrel.getFoodValue();
                return where;
            }
        }
        if(animal instanceof Hedgehog) {
            Hedgehog hedgehog = (Hedgehog) animal;
            if(hedgehog.isAlive()) { 
                hedgehog.setDead();
                foodLevel = hedgehog.getFoodValue();
                return where;
            }
        }
        return null;
    }

    /**
     * Checks adjacent locations for an animal of the same species and opposite sex.
     * if true, the animals can breed.
     * @return true if the animals are of opposite sexes, false otherwise.
     */
    private boolean meetOppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Snake){
                Snake snake = (Snake) animal;
                if(this.isFemale() != snake.isFemale()){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Return the maximum age snakes can live
     * @return The maximum age snakes can live
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return the age at which snakes can breed
     * @return The age at which snakes can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the maximum litter size of a snake
     * @return maxLitterSize The maximum litter size of a snake
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the snake's breeding probability.
     * @return BREEDING_PROBABILITY The breeding probability of a snake.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the snake's max food value.
     * @return MAX_FOOD_VALUE
     */
    protected int getMaxFoodValue()
    {
        return MAX_FOOD_VALUE;
    }

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location)
    {
        return new Snake(randomAge, field, location);
    }
}