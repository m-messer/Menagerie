import java.util.List;
import java.util.Random;
import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.02
 */
public abstract class Animal implements Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //The animal's age
    private int age;
    //The animal's food level
    private int foodLevel;
    //The animal's sex. True if the animal is female, false otherwise.
    private boolean female;
    //A shared random number generator to generate a random age and sex
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge If true, the animal will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     *
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getMaxFoodValue()));
        }
        else{
            setAge(0);
            setFoodLevel(getMaxFoodValue());
        }
        alive = true;
        this.field = field;
        setLocation(location);
        female = rand.nextBoolean();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param currentWeather The current weather in the simulator
     */
    abstract public void act(List<Actor> newAnimals, String currentWeather);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the actor is still active 
     * (this is when the animal is alive).
     * @return true if the actor is active, false otherwise.
     */
    public boolean isActive() 
    {
        return isAlive();
    }

    /**
     * Check whether the animal is female or not.
     * @return true If the animal is female.
     */
    protected boolean isFemale()
    {
        return female;
    }

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        setAge(getAge()+1);
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        setFoodLevel(getFoodLevel()-1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }

    /**
     * A animal can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return getAge() >= getBreedingAge();
    }

    /**
     * Create an animal. An animal can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    abstract protected Animal createAnimal(boolean randomAge, Field field, Location location);

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newborns A list to return newly born animals to.
     */
    protected void giveBirth(List<Actor> newborns)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newborns.add(createAnimal(false, field, loc));
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Returns the current age of the animal.
     * @return age The current age of the animal.
     */
    protected int getAge(){
        return age;
    }

    /**
     * Set the current age of the animal.
     * @param age Set the current age.
     */
    protected void setAge(int age){
        this.age = age;
    }

    /**
     *Returns the maximum age a specific animal can live.
     *@return The maximum age a specific animal can live.
     */
    abstract protected int getMaxAge();

    /**
     * Returns the breeding age of a specific animal.
     * @return The breeding age of a specific animal.
     */
    abstract protected int getBreedingAge();

    /**
     * Returns the breeding probability of a specific animal.
     * @return The animal's breeding probability.
     */
    abstract protected double getBreedingProbability();

    /**
     * Returns the maximum litter size of a specific animal
     * @return maxLitterSize The maximum litter size of a specific animal
     */
    abstract protected int getMaxLitterSize();

    /**
     * Return the food level of a specific animal.
     * @return foodLevel The food level of a specific animal.
     */
    protected int getFoodLevel()
    {
        return this.foodLevel;
    }

    /**
     * Set the food level of an animal.
     * @param foodLevel The new food level.
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }

    /**
     * Returns the max food value of an animal.
     * @return The animal's max food value.
     */
    abstract protected int getMaxFoodValue();
}
