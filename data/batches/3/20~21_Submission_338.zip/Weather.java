import java.util.ArrayList;
import java.util.Random;
/**
 * A class that simulates different types of weather
 *
 * @version 2021.03.02
 */
public class Weather
{
    //The string for the current weather.
    private String currentWeather;
    //An arrayList containing the different kinds of weather
    private ArrayList<String> allWeather;

    /**
     * Constructor for the Weather class.
     * Create a new ArrayList and add the different types of weather to it.
     */
    public Weather()
    {
        allWeather = new ArrayList<>();
        allWeather.add("dry");
        allWeather.add("rain");
        allWeather.add("fog");
        allWeather.add("snow");
        allWeather.add("wind");
    }

    /**
     * Returns a randomly selected weather as a String.
     * @return currentWeather Return a randomly selected weather as a String.
     */
    public String getWeatherString()
    {
        Random rand = new Random();
        String currentWeather = "";
        for(int i = 1; i<=5; i++){
            currentWeather = allWeather.get(rand.nextInt(allWeather.size()));
        }
        return currentWeather;
    }
}
