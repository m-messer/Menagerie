import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * wolves age, move, eat deer and squirrels, and die.
 *
 * @version 2021.03.02
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolfes (class variables).

    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 168;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a deer and a squirrel. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int MAX_FOOD_VALUE = 18;
    // Probability a wolf will get a disease
    private static final double DISEASE_PROBABILITY = 0.1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The wolf's age.
    private int age;
    // The wolf's food level, which is increased by eating deers or squirrels.
    private int foodLevel;
    //
    private boolean infected;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        infected = rand.nextBoolean();
    }

    /**
     * This is what the wolf does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newWolves A list to return newly born wolves.
     * @param currentWeather The current weather in the simulator
     */
    public void act(List<Actor>newWolves, String currentWeather)
    {
        incrementAge();
        incrementHunger();

        if(isAlive()) {
            spreadDisease();
            if(meetOppositeGender()){
                giveBirth(newWolves);  
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for deer or squirrels adjacent to the current location.
     * Only the first live rabbit or squirrel is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel = deer.getFoodValue();
                    return where;
                }
            }
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    squirrel.setDead();
                    foodLevel = squirrel.getFoodValue();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Checks adjacent locations for an animal of the same species and opposite sex.
     * if true, the animals can breed.
     * @return true if the animals are of opposite sexes, false otherwise.
     */
    private boolean meetOppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wolf){
                Wolf wolf = (Wolf) animal;
                if(this.isFemale() != wolf.isFemale()){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Checks surrounding locations. If they are also wolves then they may be randomly infected.
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wolf){
                Wolf wolf = (Wolf) animal;
                if(this.infected && rand.nextDouble() <= DISEASE_PROBABILITY){
                    wolf.setAge(getAge()+75);
                }
            }
        }
    }

    /**
     * Return the age at which wolves can breed
     * @return The age at which wolves can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the maximum age of the wolf
     * @return MAX_AGE The maximum age of the wolf
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the maximum litter size of a wolf
     * @return MAX_LITTER_SIZE The maximum litter size of a wolf
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the wolf's breeding probability.
     * @return BREEDING_PROBABILITY The breeding probability of a wolf.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the wolf's max food value.
     * @return MAX_FOOD_VALUE
     */
    protected int getMaxFoodValue()
    {
        return MAX_FOOD_VALUE;
    }

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location)
    {
        return new Wolf(randomAge, field, location);
    }
}
