import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a hedgehog.
 * Hedgehogs age, move, breed, and die.
 *
 * @version 2021.03.01
 */
public class Hedgehog extends Animal
{
    // Characteristics shared by all hedgehogs (class variables).

    // The age at which a hedgehog can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a hedgehog can live.
    private static final int MAX_AGE = 54;
    // The likelihood of a hedgehog breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single hedgehog.
    private static final int FOOD_VALUE = 8;
    // The food value of a single plant. In effect, this is the
    // number of steps a hedgehog can go before it has to eat again.
    private static final int MAX_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The hedgehog's age.
    private int age;
    // The hedgehog's food level, which is increased by eating plants.
    private int foodLevel;
    /**
     * Create a new hedgehog. A hedgehog may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the hedgehog will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hedgehog(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the hedgehog does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newHedgehogs A list to return newly born hedgehogs.
     * @param currentWeather The current weather in the simulator
     */
    public void act(List<Actor> newHedgehogs, String currentWeather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(meetOppositeGender()){
                giveBirth(newHedgehogs); 
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Checks adjacent locations for an animal of the same species and opposite sex.
     * if true, the animals can breed.
     * @return true if the animals are of opposite sexes, false otherwise.
     */
    private boolean meetOppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hedgehog){
                Hedgehog hedgehog = (Hedgehog) animal;
                if(this.isFemale() != hedgehog.isFemale()){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    setFoodLevel(grass.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Return the maximum age hedgehogs can live
     * @return The maximum age hedgehogs can live
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return the age at which hedgehogs can breed
     * @return The age at which hedgehogs can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the maximum litter size of a hedgehog
     * @return maxLitterSize The maximum litter size of a hedgehog
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Return the hedgehog's breeding probability.
     * @return BREEDING_PROBABILITY The breeding probability of a hedgehog.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the hedgehog's food value.
     * @return FOOD_VALUE the hedgehog's food value.
     */
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * Return the hedgehog's max food value.
     * @return MAX_FOOD_VALUE
     */
    protected int getMaxFoodValue()
    {
        return MAX_FOOD_VALUE;
    }

    /**
     * Create a hedgehog. A hedgehog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hedgehog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Animal createAnimal(boolean randomAge, Field field, Location location)
    {
        return new Hedgehog(randomAge, field, location);
    }
}
