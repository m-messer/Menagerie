import java.util.Random;
import java.util.List;

/**
 * A simple model of grass.
 * Grass can grow, propagate, be eaten, and die.
 *
 * @version 2021.03.02
 */
public class Grass extends Plant
{
    //the age at which a grass can be eaten by an animal
    private static final int MATURE_AGE = 4;
    //the maximum age of grass
    private static final int MAX_AGE = 15;
    // the maximum number of seeds.
    private static final int MAX_SEED_NUMBER = 15;
    //the probaility that a grass will propagate
    private static final double PROPAGATION_PROBABILITY = 0.05;
    //The food value of a single grass.
    private static final int FOOD_VALUE = 10;
    //the grass's age
    private int age;
    // a random number generator to determine the age of the grass
    private static final Random rand = Randomizer.getRandom();
    // The grass's field.
    private Field field;
    // The grass's position in the field.
    private Location location;
    /**
     * Create a new grass object. Grass can start at age 0 or have a random age
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * This is what the grass does most of the time. Grass ages with every step, 
     * and can sometimes drop seeds. Grass can also die of old age
     * @param newGrass A list to return the new grass objects.
     * @param currentWeather The current weather in the simulator
     */
    public void act(List<Actor> newGrass, String currentWeather)
    {
        incrementAge();
        if(isAlive()) {
            dropSeeds(newGrass, currentWeather);
        }
    }

    /**
     * Returns the food value of one square of grass.
     * @return FOOD_VALUE The food value of one square of grass
     */
    protected int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * Returns the mature age of grass.
     * @return MATURE_AGE The mature age of grass.
     */
    protected int getMatureAge()
    {
        return MATURE_AGE;
    }    

    /**
     *Returns the maximum age grass can live.
     *@return MAX_AGE The maximum age grass can live.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the maximum number of seeds grass can drop.
     * @return MAX_SEED_NUMBER The maximum number of seeds grass can drop.
     */
    protected int getMaxSeedNumber()
    {
        return MAX_SEED_NUMBER;
    }
    
    /**
     * Returns the propagation probability of grass.
     * @return PROPAGATION_PROBABILITY The propagation probability of grass.
     */
    protected double getPropagationProbability()
    {
        return PROPAGATION_PROBABILITY;
    }
    
    /**
     * Create a plant. A plant can be created as a new born (age zero)
     * or with a random age
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    protected Plant createPlant(boolean randomAge, Field field, Location location)
    {
        return new Grass(randomAge, field, location);
    }
}
