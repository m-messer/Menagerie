import java.util.Random;
import java.util.List;

/**
 * A class representing the shared characteristics of plants.
 *
 * @version 2021.03.02
 */
public abstract class Plant implements Actor
{
    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    //The plant's age
    private int age;
    //A shared random number generator to generate a random age
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new plant at a location in the field
     * 
     * @param randomAge If true, the plant will have a random age.
     * @param field The field currently occupied
     * @param location The location of the plant within the field
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
        }
        else{
            setAge(0);
        }
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     * @param currentWeather The current weather in the simulator
     */
    abstract public void act(List<Actor> newPlants, String currentWeather);

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive, false otherwise.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the actor is still active 
     * (this is when the plant is alive).
     * @return true if the actor is active, false otherwise.
     */
    public boolean isActive()
    {
        return isAlive();
    }

    /**
     * Increase the age. This could result in the plant's death.
     */
    protected void incrementAge()
    {
        setAge(getAge()+1);
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }

    /**
     * A grass can propagate if it has reached the mature stage.
     * @return true if it can propagate, false otherwise.
     */
    private boolean canPropagate()
    {
        return getAge() >= getMatureAge();
    }

    /**
     * Generate a number representing the number of seeds,
     * if it can propagate.
     * @return The number of seeds (may be zero).
     */
    protected int propagate()
    {
        int seeds = 0;
        if(canPropagate() && rand.nextDouble() <= getPropagationProbability()) {
            seeds = rand.nextInt(getMaxSeedNumber()) + 1;
        }
        return seeds;
    }

    /**
     * CHeck whether this plant is to propagate at this step.
     * New seeds will be dropped into free adjacent locations.
     * @param newSeeds A list to add the new seeds to.
     */
    protected void dropSeeds(List<Actor> newSeeds, String currentWeather)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int seeds = propagate();

        if(currentWeather.equals("snow")){
            seeds = 0;
        }
        else if(currentWeather.equals("wind")){
            seeds = propagate()*2;
        }

        for(int i = 0; i < seeds && free.size() > 0; i++) {
            Location loc = free.remove(0);
            newSeeds.add(createPlant(false, field, loc));
        }
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Returns the current age of the plant.
     * @return age The current age of the plant.
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Set the current age of the plant.
     * @param age Set the current age.
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     *Returns the maximum age a specific plant can live.
     *@return The maximum age a specific plant can live.
     */
    abstract protected int getMaxAge();

    /**
     * Returns the mature age of a specific plant.
     * @return The mature age of a specific plant.
     */
    abstract protected int getMatureAge();

    /**
     * Returns the propagation probability of a specific plant.
     * @return The plant's propagation probability.
     */
    abstract protected double getPropagationProbability();

    /**
     * Returns the maximum number of seeds a plant can drop
     * @return The maximum number of seeds a plant can drop
     */
    abstract protected int getMaxSeedNumber();

    /**
     * Returns the food value of a single plant.
     * @return The food value of a single plant
     */
    abstract protected int getFoodValue();

    /**
     * Create a plant. A plant can be created as a new born (age zero)
     * or with a random age
     * 
     * @param randomAge If true, the animal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    abstract protected Plant createPlant(boolean randomAge, Field field, Location location);
}
