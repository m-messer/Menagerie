import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Weasel.
 * Weaseles age, move, eat gophers, and die.
 *
 * @version 19/02/2020
 */
public class Weasel extends Animal
{
    // Characteristics shared by all Weasels (class variables).

    // The age at which a Weasel can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a Weasel can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a Weasel breeding.
    private static final double BREEDING_PROBABILITY = 0.181;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Weasel can go before it has to eat again.
    private static final int GOPHER_FOOD_VALUE = 10;
    // The likelihood of a Weasel having a virus
    private static final double VIRUS_PROBABILITY = 0.135;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Weasel's food level, which is increased by eating rabbits.
    private int foodLevel;
    private double Virus;
    private boolean isMale;

    /**
     * Create a Weasel. A Weasel can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Weasel will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Weasel(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GOPHER_FOOD_VALUE);
        }
        else {
            age =0;
            foodLevel = GOPHER_FOOD_VALUE;
        }
        Virus = rand.nextDouble();
        isMale= rand.nextBoolean();
    }

    /**
     * This is what the Weasel does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWeasels A list to return newly born Weasels.
     * @override from actor super-class
     */
    public void act(List<Actor> newWeasels)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWeasels);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(isAlive()){
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }            
        }
    }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     *  @override from actor super-class
     */
    public Location findFood()
    {
        Field field = getField();
        if(this.isAlive()){
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Gopher) {
                    Gopher gopher = (Gopher) animal;
                    if(gopher.getVirus()>=Virus && gopher.isAlive())
                    {
                        gopher.setDead();
                        this.setDead();
                    }
                    if(gopher.isAlive()) { 
                        gopher.setDead();
                        foodLevel = GOPHER_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Weasel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWeasels A list to return newly born Weaseles.
     */
    protected void giveBirth(List<Actor> newWeasel)
    {
        // New weasels are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Weasel young = new Weasel(true, field, loc);
            newWeasel.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     * @overrdie from actor super-class
     */
    protected int breed()
    {
        int births=0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Weasel) {
                Weasel weasel = (Weasel) animal;                
                //check of the mate or this animal itself has more virus than the thresold
                //if true then kill both animals
                if (weasel.VIRUS_PROBABILITY>=weasel.Virus || VIRUS_PROBABILITY>=Virus){
                    setDead();
                    weasel.setDead();
                }else{
                    if(getWhetherAMale() && !weasel.getWhetherAMale()){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }else if(!getWhetherAMale() && weasel.getWhetherAMale()){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }
                }
            }
        }
        return births;
    }

    /**
     * Return the breeding age of the weasel
     * @return the breeding age of the weasel
     * @override from actor super-class
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     * @override from animal class
     */
    protected boolean canBreed()
    {
        return age>= getBreedingAge();
    }

    /**
     * Return Weasel's max age.
     * @return Weasel's max age.
     * @override from animal class
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Retun true if weasel is alive, false otherwise
     * @retun true if weasel is alive, false otherwise
     * @override from actor super-class
     */
    public boolean isActive()
    {
        return isAlive();
    }

    /**
     * Return food value of Weasel
     * @return food value of Weasel
     * @override from animal class
     */
    protected int getFoodValue(){
        return GOPHER_FOOD_VALUE; 
    }

    /**
     * Return gender of gopher
     * @return gender of gopher
     */ 
    private boolean getWhetherAMale()
    {
        return isMale;
    }

    /**
     * Return virus probability of gopher
     * @return virus probability of gopher
     */
    public double getVirus()
    {
        return Virus;
    }    
}
