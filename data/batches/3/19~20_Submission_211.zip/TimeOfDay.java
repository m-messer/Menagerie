
/**
 * Write a description of class TimeOfDay here.
 *
 * @version (a version number or a date)
 */
public abstract class TimeOfDay
{
    protected Simulator sim;
    //100 steps is an hour
    private String timeLabel;

    /**
     * Constructor for objects of class TimeOfDay
     */
    public TimeOfDay(Simulator sim)
    {
        // initialise instance variables
        this.sim = sim;
        //currentWeather = 0; 
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public abstract int getCurrentStep();
    // {
        // // // put your code here
        // // return sim.getSteps();
    // }

    public abstract String Interval();
    
    
    public abstract String TimeLabel();
    
    public abstract String getRandomWeather();
}
