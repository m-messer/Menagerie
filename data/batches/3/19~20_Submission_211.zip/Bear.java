import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Bears eat weasels
 * @version 19/02/2020
 */
public class Bear extends Animal
{
    // Characteristics shared by all es (class variables).

    // The age at which a  can start to breed.
    private static final int BREEDING_AGE = 14;
    // The age to which a  can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a  breeding.
    private static final double BREEDING_PROBABILITY = 0.2101;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single bear. In effect, this is the
    // number of steps a  can go before it has to eat again.
    private static final int WEASEL_FOOD_VALUE = 10;
    // The likelihood of a weasel having a virus
    private static final double VIRUS_PROBABILITY = 0.25;
    // The likelihood of a weasel having a virus
    private static final double WEATHER_HUNTING_PROBABILITY = 0.095;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The 's age.
    // The 's food level, which is increased by eating bears.
    private int foodLevel;
    private double Virus;
    private boolean isMale;
    // the actual simulator
    private Simulator simulator;
    // a weather counter to keep track of weather
    private Weather weather;
    private double huntProbability;
    /**
     * Create a . A  can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the  will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bear(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(WEASEL_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = WEASEL_FOOD_VALUE;
        }
        Virus = rand.nextDouble();
        isMale= rand.nextBoolean();
        huntProbability=rand.nextDouble();
        weather= new Weather(simulator);
    }

    /**
     * Return true if bear is a male
     * @return true if bear is a male
     */
    private boolean getWhetherAMale()
    {
        return isMale;
    }

    /**
     * This is what the  does most of the time: it hunts for
     * bears. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newes A list to return newly borns.
     * @override from actor super-class
     */
    public void act(List<Actor> newBear)
    {   incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newBear);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(isAlive()){
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for bears adjacent to the current location.
     * Only the first live bear is eaten.
     * @return Where food was found, or null if it wasn't.
     *  @override from actor super-class
     */
    public Location findFood()
    {
        if((weather.getRandomWeather().matches("Normal|Sunny")) ||(weather.getRandomWeather().matches("Rainy|Foggy") &&  huntProbability>WEATHER_HUNTING_PROBABILITY)){
            Field field = getField();
            if (this.isAlive()){
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Weasel) {
                        Weasel weasel= (Weasel) animal;
                        if(weasel.getVirus()>=Virus && weasel.isAlive()){
                            weasel.setDead();
                            this.setDead();
                        }
                        if(weasel.isAlive()) { 
                            weasel.setDead();
                            foodLevel = WEASEL_FOOD_VALUE;
                            return where;
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this  is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newes A list to return newly born es.
     * 
     */
    protected void giveBirth(List<Actor> newBear)
    {
        // New es are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bear young = new Bear(true, field, loc);
            newBear.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     * @overrdie from actor super-class
     */
    protected int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bear) {
                Bear bear = (Bear) animal;
                //check of the mate or this animal itself has more virus than the thresold
                //if true then kill both animals
                if (bear.VIRUS_PROBABILITY>=bear.Virus || VIRUS_PROBABILITY>=Virus){
                    setDead();
                    bear.setDead();
                }else{
                    if(getWhetherAMale() && !bear.getWhetherAMale()){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }else if(!getWhetherAMale() && bear.getWhetherAMale()){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }
                }
            }
        }
        return births;
    }

    /**
     * A bear can breed if it has reached the breeding age.
     * @return true if the bear can breed, false otherwise.
     * @override from animal class
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * A bear can breed if it has reached the breeding age.
     * @return true if the bear can breed, false otherwise.
     * @override from animal class
     */
    protected boolean canBreed()
    {
        return age>= getBreedingAge();
    }

    /**
     * Return Bear's max age.
     * @return Bear's max age.
     * @override from animal class
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**   
     * Return true if Bear is alive, false otherwise
     * @return true if Bear is alive, false otherwise
     * @override from actor super-class
     */
    public boolean isActive()
        {
            return isAlive();
        }

        /**
         * Return food value of the weasel
         * @return food value of the weasel
         * @override from actor super-class
         */
        protected int getFoodValue(){
            return WEASEL_FOOD_VALUE; 
        }

        /**
         * Return Virus probability of Bear.
         * @return Virus probability of Bear.
         */
        public double getVirus()
        {
            return Virus;
        }   

    }