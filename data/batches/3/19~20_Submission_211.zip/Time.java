/**
 * This class models the Time throughout the simulation
 * The Time is based on the numberOfSteps and thus the dayNumber also changes.
 * In this class, it obtains the currentStep from the Simualtor object reference
 * @version 19/02/2020
 */
public class Time
{
    public int dayNumber = 0;
   
    public static int numberOfSteps;
    //creating an object reference of the Simulator, so that the number of steps can be obtained
    public static Simulator sim;
    
    /**
     * Constructor for objects of class Time
     * @ param sim - object reference of Simulator.
     * this was done so that the current Simulator is made, not a new object
     */
    public Time(Simulator sim)
    {
        this.sim= sim;
    }
    
    /**
     * This method get the currentStep from the simulator class
     * @return int- returns the currentNumber of steps from the simulator class
     */
    private static int getCurrentStep()
    {
        return sim.getSteps();
    }
    
    /**
     * This method takes the modulo of the currentStep
     * Whenever it reaches 200, this method becomes zero
     * @return int- returns the modulo of the currentStep from the Simulator class
     */
    private static int getNumberOfSteps()
    {
        return (getCurrentStep() % 200);
    }
    
    
    /**
     * This method returns the dayNumber
     * @return int- returns the dayNumber
     */
    private int getDay(){
        return dayNumber;
    }
    
    /**
     * @return int- returns the Time of the day: Night_Time/ Day_Time
     * If it is night time, it returns Night_Time, otherwise Day_Time 
     */
    public String getTimeOfTheDayLabel(){
        if (isNight() == true){
            return "Night_Time";
        }
        else{
            return "Day_Time";
        }
    }
    
    /**
     * This method returns a boolean and if the number of steps is greater than 100, it will return true.
     * if number of steps is less than 100, it will return false
     * @return boolean- returns whether isNight
     */
     public static boolean isNight(){
        if (getNumberOfSteps() > 100){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * This methods updates, so when the numberOfSteps is 0; the dayNumber increments
     * by 1 and the numberofSteps is set to 0
     * @return boolean- returns whether isNight
     */
    private void update(){
        if (getNumberOfSteps() == 0)
        {
            dayNumber+=1;
            numberOfSteps = 0;
        }
    }
    
    /**
     * @return String- retruns a string with the time of day and day Number
     */
    public String TimeLabel(){
        update();
        String returnString = getTimeOfTheDayLabel() + "   DAY :" + getDay();
        return returnString; 
    }
    
    
}
