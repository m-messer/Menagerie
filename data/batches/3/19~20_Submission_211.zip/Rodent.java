import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a rodent.
 *
 * @version 19/02/2020
 */
public class Rodent extends Animal
{
    // Characteristics shared by all s (class variables).

    // The age at which a  can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a  can live.
    private static final int MAX_AGE = 14;
    // The likelihood of a  breeding.
    private static final double BREEDING_PROBABILITY = 0.22;
    // The likelihood of a rodent having a virus
    private static final double VIRUS_PROBABILITY = 0.180005;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // number of steps a rodent can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The rodent's food level, which is increased by eating s.
    private int foodLevel;
    // The rodent's gender
    private boolean isMale;
    //The probability of a rodent having a virus 
    private double Virus; 
    /**
     * Create a new . A  may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the  will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rodent(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = (rand.nextInt(MAX_AGE));
        }else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
        foodLevel = PLANT_FOOD_VALUE;
        isMale= rand.nextBoolean();
        Virus = rand.nextDouble();
    }

    /**
     * This is what the  does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param news A list to return newly born s.
     * @override from actor super-class
     */
    public void act(List<Actor> newRodents)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newRodents);  
            if(isAlive()){
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether or not this  is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param news A list to return newly born s.
     */
    protected void giveBirth(List<Actor> newRodents)
    {
        // New s are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rodent young = new Rodent(true, field, loc);
            newRodents.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     * @overrdie from actor super-class
     */
    protected int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rodent) {
                Rodent rodent = (Rodent) animal;                
                //check of the mate or this animal itself has more virus than the thresold
                //if true then kill both animals
                if ((rodent.VIRUS_PROBABILITY >=rodent.Virus)||(VIRUS_PROBABILITY>= Virus)){ 
                    rodent.setDead();
                    setDead();
                }else if(getWhetherAMale() && !rodent.getWhetherAMale()){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }else if(!getWhetherAMale() && rodent.getWhetherAMale()){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }
                }
            }
        
        return births;
    }

    /**
     * Return the breeding age of the rodent.
     * @return the breeding age of the rodent.
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * A Rodent can breed if it has reached the breeding age.
     * @return true if the rodent can breed, false otherwise.
     * @override from animal class
     */
    protected boolean canBreed()
    {
        return age>= getBreedingAge();
    }

    /**
     * Return s max age.
     * @return s max age.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return true if rodent is alive, false otherwise.
     * @return true if rodent is alive, false otherwise.
     * @override from actor super-class
     */
    public boolean isActive()
    {
        return isAlive();
    }

    /**
     * Look for s adjacent to the current location.
     * Only the first live  is eaten.
     * @return Where food was found, or null if it wasn't.
     * @override from actor super-class
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Plant) {
                Plant plant = (Plant) actor;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }

        return null;
    }

    /**
     * Return true if the rodent's gender is male, false otherwise.
     * @return true if the rodent's gender is male, false otherwise.
     */
    private boolean getWhetherAMale()
    {
        return isMale;
    }

    /**
     * Return the rodent's food level, which is increased by eating.
     * @return the rodent's food level, which is increased by eating.
     */
    protected int getFoodValue(){
        return PLANT_FOOD_VALUE; 
    }

    /**
     * Return Virus probability of Gopher.
     * @return Virus probability of Gopher.
     */
    public double getVirus()
    {
        return Virus;
    }    
}
