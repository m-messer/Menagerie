import java.util.List;
import java.util.Iterator;
/**
 * Write a description of class Grass here.
 *
 * @version 19/02/2020
 */
public abstract class Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's age.
    private int age;

    public Actor(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * set the age of an animal
     */
    protected void setAge(int animalAge)
    {
        age=animalAge;
    }

    /**
     * Return the animal's age.
     * @return The animal's age.
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Increase the age of the anial
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    protected abstract int breed();

    protected abstract void act(List<Actor> newActors);

    protected abstract boolean isActive();

    abstract protected int getBreedingAge();

    protected abstract boolean canBreed();

    protected abstract int getMaxAge(); 
}
