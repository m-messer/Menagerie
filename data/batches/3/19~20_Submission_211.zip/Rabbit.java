import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Rabbit extends Animal
implements Prey
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.75;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // number of steps a fox can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 20;
    // The likelihood of a rabbit having a virus
    private static final double VIRUS_PROBABILITY = 0.45;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The fox's food level, which is increased by eating rabbits.
    private int foodLevel;
    private boolean isMale;
    private double Virus;
    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = (rand.nextInt(MAX_AGE));
        }else {
            age = 0;
            //foodLevel = PLANT_FOOD_VALUE;
        }
        foodLevel = PLANT_FOOD_VALUE;
        isMale= rand.nextBoolean();
        Virus = rand.nextDouble();
    }

    /**
     * This is what the rabbit does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Actor> newRabbits)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newRabbits);            
            // Try to move into a free location.
            Location newLocationa = getField().freeAdjacentLocation(getLocation());
            if(newLocationa != null) {
                setLocation(newLocationa);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    protected void giveBirth(List<Actor> newRabbits)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Rabbit young = new Rabbit(false, field, loc);
            newRabbits.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if (rabbit.VIRUS_PROBABILITY>=rabbit.Virus || VIRUS_PROBABILITY>=Virus){
                    rabbit.setDead();
                }else{
                    if(getWhetherAMale() && !rabbit.isMale){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }else if(!getWhetherAMale() && rabbit.isMale){
                        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }
                    }
                    return births;
                }
            }
        }
        return 0;
    }

    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age>= getBreedingAge();
    }

    /**
     * Return rabbits max age.
     * @return rabbits max age.
     */

    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    public boolean isActive()
    {
        return isAlive();
    }

    // private boolean setisMale(boolean animalisMale)
    // {

    // }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Plant) {
                Plant plant = (Plant) actor;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    private boolean getWhetherAMale()
    {
        return isMale;
    }

    protected int getFoodValue(){
        return PLANT_FOOD_VALUE; 
    }
    
    public double getVirus()
    {
        return Virus;
    }    
}
