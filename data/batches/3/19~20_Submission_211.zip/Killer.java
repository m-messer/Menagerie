import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Write a description of class Killer here.
 *
 * @version (a version number or a date)
 */
public class Killer extends Actor
{
    private static final int BREEDING_AGE = 14;
    // The age to which a  can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a  breeding.
    private static final double BREEDING_PROBABILITY = 0.2101;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single killer. In effect, this is the
    // number of steps a  can go before it has to eat again.
    private static final int WEASEL_FOOD_VALUE = 10;
    // The likelihood of a weasel having a virus
    private static final double VIRUS_PROBABILITY = 0.25;
    // The likelihood of a weasel having a virus
    private static final double WEATHER_HUNTING_PROBABILITY = 0.095;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The 's food level, which is increased by eating killers.
    private int foodLevel;
    private int age;
    /**
     * Constructor for objects of class Killer
     */
    public Killer(Field field, Location location)
    {
        super(field, location);   
    }

    /**
     * This is what the  does most of the time: it hunts for
     * killers. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newes A list to return newly borns.
     * @override from actor super-class
     */
    public void act(List<Actor> newBear)
    {   incrementAge();
        if(isAlive()) {
            giveBirth(newBear);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(isAlive()){
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for killers adjacent to the current location.
     * Only the first live killer is eaten.
     * @return Where food was found, or null if it wasn't.
     *  @override from actor super-class
     */
    public Location findFood()
    {
        if (this.isAlive()){
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Actor) {
                    if(isAlive()) { 
                        setDead();
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this  is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newes A list to return newly born es.
     * 
     */
    protected void giveBirth(List<Actor> newKiller)
    {
        // New es are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Killer young = new Killer(field, loc);
            newKiller.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     * @overrdie from actor super-class
     */
    protected int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Killer) {
                Killer killer = (Killer) actor;
            }else{
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;

            }
        }
        return births;
    }

    /**
     * A killer can breed if it has reached the breeding age.
     * @return true if the killer can breed, false otherwise.
     * @override from animal class
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * A killer can breed if it has reached the breeding age.
     * @return true if the killer can breed, false otherwise.
     * @override from animal class
     */
    protected boolean canBreed()
    {
        return age>= getBreedingAge();
    }

    /**
     * Return Bear's max age.
     * @return Bear's max age.
     * @override from animal class
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**   
     * Return true if Bear is alive, false otherwise
     * @return true if Bear is alive, false otherwise
     * @override from actor super-class
     */
    public boolean isActive()
    {
        return isAlive();
    }

    /**
     * Return food value of the weasel
     * @return food value of the weasel
     * @override from actor super-class
     */
    protected int getFoodValue(){
        return WEASEL_FOOD_VALUE; 
    }

}
