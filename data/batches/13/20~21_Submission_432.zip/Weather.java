import java.util.Random;
/**
 * Write a description of class Weather here.
 *
 * @version (a version number or a date)
 */
public class Weather
{
    // instance variables - replace the example below with your own
    private int weather;
    
    private static final int numOfWeatherTypes = 3;
    
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        weather = rand.nextInt(numOfWeatherTypes);
    }
    
    /**
     * Return the Weather integer
     */
    public int getWeather() 
    {
        return weather;
    }

    /**
     * Reset the weather to a random value
     */
    public void setWeather()
    {
        weather = rand.nextInt(numOfWeatherTypes);
    }
}
