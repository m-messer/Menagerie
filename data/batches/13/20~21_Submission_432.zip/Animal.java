import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 03.03.21 
 */
public abstract class Animal extends Organism
{
    private static final Random rand = Randomizer.getRandom();

    private boolean gender;

    protected int disease;

    /**
     * Create a new animal at location in field.
     * 
     * @param randomGender Whether a gender of an animal is random.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomGender, Field field, Location location)
    {
        super(field,location);
        alive = true;
        this.field = field;
        setLocation(location);
        disease = rand.nextInt(11);
        if(randomGender) {
            gender = rand.nextBoolean();
        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Retrieves the disease.
     * @return disease variable.
     */
    protected int getDisease()
    {
        return disease;  
    }

    /**
     * Sets the disease variable back to zero.
     */
    protected void setDisease()
    {
        disease = 0;
    }

    /**
     * Kill a percentage of animals with the disease.
     */
    protected void diseaseKill()
    {
        if(disease == 0){
            if(rand.nextInt(50) == 0){
                setDead();
            }
        }
    }
    
    /**
     * Kill a percentage of animals in a storm due to a lightning strike.
     * @param  weather  Integer that describes when the weather is stormy.
     */
    protected void lightningKill(int weather)
    {
        int lightningStrike = 1000;
        if(weather == 2){
            if (rand.nextInt(lightningStrike) == 0){
                setDead();
            }
        }
    }

    /**
     * Make this jaguar more hungry. This could result in the jaguar's death.
     * 
     * @param  foodLevel  Integer for the level food each animal has.
     * @return  the food level after it has been decremented 
     */
    protected int incrementHunger(int foodLevel)
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
        return foodLevel;
    }

    /**
     * Retrieves the gender of the animal.
     * @return  Boolean value for animal.
     */
    protected boolean getGender() 
    {
        return gender;
    }

    /**
     * A monkey can breed if it has reached the breeding age.
     * 
     * @param  age  The current age of the animal.
     * @param  BREEDING_AGE  An integer that holds the the age that an animal can begin 
     * breeding.
     * @return true if the monkey can breed, false otherwise.
     */
    protected boolean canBreed(int age, int BREEDING_AGE)
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @param  age  The current age of the animal.
     * @param  BREEDING_AGE  An integer that holds the the age that an animal can begin 
     * breeding.
     * @param  BREEDING_PROBABILITY  The probability that two animals of the opposite sex 
     * will breed when they meet.
     * @param  MAX_LITTER_SIZE  The maximum number of offspring a animal can breed.  
     * @return The number of births (may be zero). 
     */
    protected int breed(int age, int BREEDING_AGE, double BREEDING_PROBABILITY,  int MAX_LITTER_SIZE)
    {
        int births = 0;
        if(canBreed(age, BREEDING_AGE) && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Produces newly created instances of the corresponding animal subclass
     * and places them at free locations surrounding the animal.
     * @param newTortoises List that stores newly created tortoises.
     * @param newSloth List that stores newly created sloths.
     * @param newMonkey List that stores newly created monkeys.
     * @param newAnaconda List that stores newly created anacondas
     * @param newJaguar List that stores newly created jaguars.
     * @param age Stores the age of the animal attempting to give birth.
     * @param BREEDING_AGE Stores the minimum age at which this animal can give birth.
     * @param BREEDING_PROBABILITY Stores the probability of a successful birth.
     * @param MAX_LITTER_SIZE Stores the maximum number of young that can be born at a time.
    
     */
    protected void giveBirth(List<Organism> newTortoises, List<Organism> newSloth, List<Organism> newMonkey, List<Organism> newAnaconda, List<Organism> newJaguar, int age, int BREEDING_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(age, BREEDING_AGE, BREEDING_PROBABILITY,  MAX_LITTER_SIZE);
        Object animal = field.getObjectAt(getLocation());
        if(animal instanceof Tortoise)
        {
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Tortoise young = new Tortoise(false, field, loc);//i changed the 1st parameter
                newTortoises.add(young);
            }
        }
        else if(animal instanceof Sloth)
        {
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Sloth young = new Sloth(false, field, loc);//i changed the 1st parameter
                newSloth.add(young);
            }
        }
        else if(animal instanceof Monkey)
        {
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Monkey young = new Monkey(false, field, loc);//I changed the first parameter
                newMonkey.add(young);

            }
        }
        else if(animal instanceof Jaguar)
        {
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Jaguar young = new Jaguar(false, field, loc); //I changed 1st parameter
                newJaguar.add(young);

            }
        }
        else if(animal instanceof Anaconda)
        {
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Anaconda young = new Anaconda(false, field, loc); //I changed 1st parameter
                newAnaconda.add(young);
            } 
        }
    }

    /**
     * Look for partners adjacent to the current location.
     * Only the first live partner is bred with
     * @param  newTortoises  A list where new tortoises are stored when they are born.
     * @param  newSloth  A list where new sloths are stored when they are born.
     * @param  newMonkey  A list where new monkeys are stored when they are born.
     * @param  newAnaconda  A list where new anacondas are stored when they are born.
     * @param  newJaguar  A list where new jaguars are stored when they are born.
     * @param  foodLevel  An integer that holds the food level of the animal.
     * @param  ANIMAL_FOOD_VALUE  The animal's maximum possible food value.
     * @param  age  The current age of the animal.
     * @param  BREEDING_AGE  An integer that holds the the age that an animal can begin 
     * breeding.
     * @param  BREEDING_PROBABILITY  The probability that two animals of the opposite sex 
     * will breed when they meet.
     * @param  MAX_LITTER_SIZE  The maximum number of offspring a animal can breed.
     * @return  where  The next available free location.
     */
    protected Location findPartner(List<Organism> newTortoises, List<Organism> newSloth, List<Organism> newMonkey, List<Organism> newAnaconda, List<Organism> newJaguar,int foodLevel, int ANIMAL_FOOD_VALUE, int age, int BREEDING_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        boolean animalGender = getGender();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if((disease == 0 && organism instanceof Monkey)){
                if(rand.nextInt(5) == 0){
                    Animal animal = (Animal) organism;
                    animal.setDisease();
                }
            }
            if(organism instanceof Anaconda) {
                Anaconda anaconda = (Anaconda) organism;
                boolean adjacentGender = anaconda.getGender();
                //System.out.println("animalGender: " + animalGender);
                //System.out.println("adjacentGender: " + adjacentGender);
                if(anaconda.isAlive()) {
                    if(adjacentGender != animalGender) {
                        //System.out.println("Got this far");
                        giveBirth(newTortoises, newSloth, newMonkey, newAnaconda, newJaguar, age, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
                        //foodLevel = Sloth_FOOD_VALUE;
                        //foodLevel = ANIMAL_FOOD_VALUE;
                        return where;
                    }
                }
            }
            else if(organism instanceof Tortoise) {
                Tortoise tortoise = (Tortoise) organism;
                boolean adjacentGender = tortoise.getGender();
                if(tortoise.isAlive()) {
                    if(adjacentGender != animalGender) {
                        giveBirth(newTortoises, newSloth, newMonkey, newAnaconda, newJaguar, age, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
                        //foodLevel = Sloth_FOOD_VALUE;
                        return where;
                    }
                }
            }
            else if(organism instanceof Jaguar) {
                Jaguar jaguar = (Jaguar) organism;
                boolean adjacentGender = jaguar.getGender();
                if(jaguar.isAlive()) {
                    if(adjacentGender != animalGender) {
                        giveBirth(newTortoises, newSloth, newMonkey, newAnaconda, newJaguar, age, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
                        //foodLevel = Sloth_FOOD_VALUE;
                        //foodLevel = ANIMAL_FOOD_VALUE;
                        return where;
                    }
                }
            }
            else if(organism instanceof Monkey) {
                Monkey monkey = (Monkey) organism;
                boolean adjacentGender = monkey.getGender();
                if(monkey.isAlive()) {
                    if(adjacentGender != animalGender) {
                        giveBirth(newTortoises, newSloth, newMonkey, newAnaconda, newJaguar, age, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
                        //foodLevel = Sloth_FOOD_VALUE;
                        //foodLevel = Monkey_FOOD_VALUE;
                        return where;
                    }
                }
            }
            else if(organism instanceof Sloth) {
                Sloth sloth = (Sloth) organism;
                boolean adjacentGender = sloth.getGender();
                if(sloth.isAlive()) {
                    if(adjacentGender != animalGender) {
                        giveBirth(newTortoises, newSloth, newMonkey, newAnaconda, newJaguar, age, BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE);
                        //foodLevel = Sloth_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }
}
