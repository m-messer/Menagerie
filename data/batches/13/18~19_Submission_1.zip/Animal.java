import java.util.*;

/**
 * A class representing shared characteristics of animals. This is the SuperClass of all individual animals, all animals inherited fields and methods of this class, it is an abstract class and no object can be 
 * created from Animal class
 * 
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    //Gestation period for Animal
    private final int gestationPeriod = 2;
    // probability an Animal is born with disease
    private final double diseaseProbability = 0.12; 
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's gender
    private boolean isMale;
    // The animals' age
    private int age;
    //A variable to hold a weather object
    private Weather weather;
    //Does animal has disease
    private boolean hasDisease;
    //a random number machine
    private Random rand;
    // Days of getting disease
    private int counter;
    //Days of pregancy
    private int pregnancy;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        setGender();
        age = 0;
        weather = new Weather();
        hasDisease = false;
        rand = new Random();
        bornDisease();
        counter = 0;
        pregnancy = 0;

    }
    
    /**
     * probability of an animal born with disease
     */
    
    protected void bornDisease()
    {
        if(rand.nextDouble() <= diseaseProbability) {
            setTrueDisease();
        }
    }
    
    protected int getCounter()
    {
        return counter;
    }

    protected void incrementCounter()
    {   
        counter++;

    }

    protected int getPregnancy()
    {
        return pregnancy;
    }

    protected void incrementPregnancy()
    {
        pregnancy ++;
    }

    protected boolean getDisease()
    {
        return hasDisease;
    }

    protected void setTrueDisease()
    {
        hasDisease = true;
    }

    protected Weather getWeather()
    {
        return weather;
    }

    /**
     * returns the current weather of the day
     */
    protected Weather getCurrentWeather()
    {
        return weather.getWeather();
    }

    /**
     * return a random number from list [0,1]
     */
    public int getRandomNumber()
    {
        Random generator = Randomizer.getRandom();
        return generator.nextInt(2);
    }

    /**
     * It spreads the disease from this animal to neibouring animal
     */
    public void catchDisease()
    {
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Animal){
                Animal neighbour = (Animal) animal;

                if(neighbour.getDisease() == true) {

                    this.setTrueDisease();
                }
            }

        }
    }

    public boolean getGender()
    {
        return isMale;
    }

    /**
     * If animal has disease for more 50 steps, it will be killed
     */
    protected void killByDisease()
    {
        if(hasDisease == true && counter > 50) {

            setDead();
        }
    }

    /**
     * animal is either male or female depending on whether the number is 0 or 1
     */
    public void setGender()
    {
        if(getRandomNumber() == 0){
            isMale = true;
        } else {
            isMale = false;
        }
    }

    public int getAge()
    {
        return age;
    }

    public void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Provide a framework for each animal define their own breeding age in their subclass.
     */
    abstract protected int getBreedingAge();

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Provide a framwork for each animal to define their own MaxAge
     */
    abstract int getMaxAge();

    /**
     * It gives 2 steps delay before animal give birth to its offspring, this method check whether 2 steps has passed since animal got pregnant
     */
    protected boolean canGiveBirth()
    {
        return(pregnancy  >= gestationPeriod);
    }

    /**
     * Increase the age. This could result in the Animal's death.
     */
    public void incrementAge()
    {
        setAge(getAge()+1);
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * A Animal can breed if it has reached the breeding age.
     */
    abstract public boolean canBreed();
}
