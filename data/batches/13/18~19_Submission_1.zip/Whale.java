import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 *This is the whale class and it is a predator that eats starfish and crab
 */
public class Whale extends Animal
{
    // The age at which shark can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a shark can live.
    private static final int MAX_AGE = 39;
    // The likelihood of a shark breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // number of steps a whale can go before it has to eat again.
    private static final int FOOD_VALUE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The fox's food level, which is increased by eating rabbits.
    private int foodLevel;
    
    /**
     * This is the constructor for a whale
     */
    public Whale(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            setAge(0);
            foodLevel = FOOD_VALUE;
        }
    }
    
    /**
     * A Whale can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Whale) {
                Whale whale = (Whale) animal;
                
                if(getAge() >= getBreedingAge() && whale.getGender() != this.getGender()) { 
                    return true;
                    
                    
                }
            }}
         return false;    
    }
    
    /**
     * This is the act method for Whales, it describes a whale's life cycle.
     */
    public void act(List<Animal> newWhale)
    {
        incrementAge();
        incrementHunger();
        
        if(getDisease()) {
            incrementCounter();
            
        }
        if(getCounter()>50) {
            killByDisease();
        }
        if(isAlive()) {
            giveBirth(newWhale);
            catchDisease();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     *  return whale's breeding age
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Make this Whale more hungry. This could result in the Whale's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for Starfish adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if(getCurrentWeather() == getWeather().getSun() || getCurrentWeather() == getWeather().getRain())
        { 
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
           
            if(animal instanceof Starfish) {
                Starfish starfish = (Starfish) animal;
                if(starfish.isAlive()) { 
                    starfish.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }                
            }
        }
    }
        return null;
    }
    
    /**
     * return max age of whale
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Check whether or not this whale is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWhaless A list to return newly born whales.
     */
    private void giveBirth(List<Animal> newWhales)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        if(getPregnancy() > 50) {
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Whale young = new Whale(false, field, loc);
            newWhales.add(young);
        }}
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        incrementPregnancy();
        return births;
    }

    
}

