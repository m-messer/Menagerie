
/**
 * Returns the weather of the current simulation.
 *
 */
public class Weather
{
    // Describes whether the weather is sunny.
    private Weather isSunny;
    // Describes whether the weather is raining.
    private Weather isRain;
    // Describes whether the weather is foggy
    private Weather isFog;
    // Describes the current weather
    private Weather currentWeather;
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        isSunny = null;
        isRain = null;
        isFog = null;
        currentWeather = null;
    }
    
    public Weather getSun()
    {
        return isSunny;
    }
    
    public Weather getRain()
    {
        return isRain;
    }
    
    public Weather getFog()
    {
        return isFog;
    }
    
    public Weather getWeather()
    {
        return currentWeather;
    }
}
