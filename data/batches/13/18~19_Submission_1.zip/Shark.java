import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Shark.
 * Sharkss age, move, eat starfishs and crabs, and die.
 */
public class Shark extends Animal
{
    // The age at which a Shark can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a shark can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a shark breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // number of steps a shark can go before it has to eat again.
    private static final int FOOD_VALUE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // a random number generator use for different methods
    private Random genderRandom;
    // The Shark's food level, which is increased by eating rabbits.
    private int foodLevel;
    
    /**
     * Create a Shark. A Shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Shark will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shark(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        genderRandom = new Random();

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            setAge(0);
            foodLevel = FOOD_VALUE;
        }
    }
    
 
    /**
     * This is what the sharks does most of the time: it hunts for
     * starfish and crab. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born sharks.
     */
    public void act(List<Animal> newSharks)
    {
        incrementAge();
        incrementHunger();
        
        if(getDisease()) {
            incrementCounter();
            
        }
        if(getCounter()>50) {
            killByDisease();
        }
        if(isAlive()) {
            giveBirth(newSharks); 
            catchDisease();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
   
    /**
     * A shark can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shark) {
                Shark shark = (Shark) animal;
                
                if(getAge() >= getBreedingAge() && shark.getGender() != this.getGender()) { 
                    return true;
                    
                    
                }
            }}
         return false;    
    }
    
    /**
     * Make this shark more hungry. This could result in the shark's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for foods adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {   if(getCurrentWeather() == getWeather().getSun() || getCurrentWeather() == getWeather().getRain()){ 
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Crab) {
                Crab crab = (Crab) animal;
                if(crab.isAlive()) { 
                    crab.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Starfish) {
                Starfish starfish = (Starfish) animal;
                if(starfish.isAlive()) {
                    starfish.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        
    }
        return null;
    }
    
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    public int getBreedingAge()
    {
        return BREEDING_AGE;
        
    }
    
    
    /**
     * Check whether or not this shark is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newShars A list to return newly born sharks.
     */
    private void giveBirth(List<Animal> newSharks)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        if(getPregnancy() > 50) {
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Shark young = new Shark (false, field, loc);
            newSharks.add(young);
        }}
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        incrementPregnancy();
        return births;
    }

   
}