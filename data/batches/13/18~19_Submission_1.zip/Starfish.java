import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Starfish are the main food source of predator shark and whale, like crab they also feed on seaweed.
 */ 
public class Starfish extends Animal
{
    // instance variables - replace the example below with your own
    private static final int BREEDING_AGE = 3;
    // The age to which a fox can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20;
    // The food value of a single Seaweed.
    private static final int FOOD_VALUE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //Percentage of Population carries disease
    private static final double diseaseRate = 0.23; 
    // The fox's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Constructor for objects of class Starfish
     */
    public Starfish(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        foodLevel = 2;
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        }
    }

    /**
     * Describes the actions of a Starfish. Starfish can die of old age and disease, they move around hunting for seaweed.
     */
     public void act(List<Animal> newStarfish)
    {
        incrementAge();
        
        if(getDisease()) {
            incrementCounter();
            
        }
        if(getCounter()>50) {
            killByDisease();
        }
        if(foodLevel<0) {
        
            setDead();
        }
        if(isAlive()) {
            giveBirth(newStarfish);
            catchDisease();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
   /**
     * Check whether or not this Starfish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newStarfish A list to return newly born rabbits.
     */
    private void giveBirth(List<Animal> newStarfish)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        if(getPregnancy() > 50) {
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Starfish young = new Starfish(false, field, loc);
            newStarfish.add(young);
        }}
    }
    
    private void setDisease()
    {
        if(rand.nextDouble() <= diseaseRate) {
            setTrueDisease();
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            setDisease();
        }
        incrementPregnancy();
        return births;
    }
    
    /**
     * A Starfish can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Starfish) {
                Starfish starfish= (Starfish) animal;
                
                if(getAge() >= getBreedingAge() && starfish.getGender() != this.getGender()) { 
                    return true;
                    
                    
                }
            }}
         return false;    
    }
    
    /**
     * Starfish prey on seaweed
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Seaweed) {
                Seaweed seaweed = (Seaweed) animal;
                if(seaweed.isAlive()) { 
                    seaweed.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
           
        }
        return null;
    }
    
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}
