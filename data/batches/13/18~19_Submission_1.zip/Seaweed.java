import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * This is the plant class, it cannot move or die of disease. It needs sun and rain for food and water respectively.
 * They possess some of behaviour common to other animal species.
 * 
 */
public class Seaweed extends Animal
{
    
    // The age to which a Seaweed can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a seaweed breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    //Plant's breeding age
    private static final int BREEDING_AGE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //The plant's food value
    private int foodValue;
    //The plant's water Value
    private int waterValue;
   
    
    
    /**
     * This is a constructor for Seaweed
     */
    public Seaweed(Field field, Location location)
    {
        super(field, location);
        foodValue = 2;
        waterValue = 5;
        
    }
    
    /**
     * This is the act method for Seaweeds, its main methods are incrementing and decrementing food and water level
     */
    public void act(List<Animal> newSeaweeds)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newSeaweeds);
            
        }
        if(getAge()>getMaxAge() || foodValue<0 || waterValue<0) {
            setDead();
            
        }
        else if(getCurrentWeather() == getWeather().getSun()) {
            foodValue ++;
        }
        else if(getCurrentWeather() == getWeather().getRain()) {
        
            waterValue ++;}
        else if(getCurrentWeather() == getWeather().getFog()){    
            foodValue --;
        }
    }
   
    /**
     * this method create new animals of class Seaweeds and store them in the list
     */
    private void giveBirth(List<Animal> newSeaweeds)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seaweed young = new Seaweed ( field, loc);
            newSeaweeds.add(young);
        }
    }
    
    /**
     * Describe the condition for breeding
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    public boolean canBreed()
    {
        return isAlive();
        
    }
}
