import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 *  
 * @version 2020.02.21 
 */
public abstract class Animal extends Organism
{
    //The animal's gender
    private boolean isFemale; 

    /**
     * Create a new animal at location in field.
     * Also assigns a random gender to the animal.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        if (getRandom().nextInt(2) == 0) {
            isFemale = true;
        }
        else {
            isFemale = false;
        }
    }

    /**
     * Returns the gender of the animal.
     * 
     * @return true if the animal is a female.
     */
    protected boolean isFemale()
    {
        return isFemale;
    }
}
