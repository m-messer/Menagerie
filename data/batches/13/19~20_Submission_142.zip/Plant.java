import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a plant.
 *
 * @version 2020.02.13 
 */
public class Plant extends Organism
{
    //The food value of a single plant.
    private static final int PLANT_FOOD_VALUE = 100;
    
    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;

    // The age to which a plant can live.
    private static final int MAX_AGE = 400;
    
    /**
     * Constructor for the class Plant.
     */
    public Plant(Field field, Location location){
        super(field, location);
    }
   
    /**
     * Returns the plant's max age.
     * 
     * @return the plant's max age.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Makes the plants act (they give birth). 
     * 
     * @param newPlants a list of new plants.
     */
    public void act(List<Organism> newPlants) {
        incrementAge();
        
        if (isAlive()) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocationsPlant(getLocation());
            int births = getRandom().nextInt(MAX_LITTER_SIZE );
            if(getRandom().nextDouble() <= getBreedingProbability()){
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    Plant young = new Plant(field, loc);
                    newPlants.add(young);
                }
            }
        }
    }

    /**
     * Returns the plant's food value.
     * 
     * @return the plant's food value.
     */
    public static int getFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }
    
    /**
     * Checks if the plant can breed.
     * 
     * @return true.
     */
    protected boolean canBreed() 
    {
        return true;
    }

    /**
     * Returns the plant's breeding probability.
     * 
     * @return the plant's breeding probability.
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the plant's max litter size.
     * 
     * @return the plant's max litter size.
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
