import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an eagle.
 * Eagles age, move, eat squirrels, and die.
 *
 * @version 2016.02.29 (2)
 *  
 * @version 2020.02.21
 */
public class Eagle extends Animal
{
    // Characteristics shared by all eagles (class variables).

    // The age at which an eagle can start to breed.
    private static final int BREEDING_AGE = 600;

    // The age to which an eagle can live.
    private static final int MAX_AGE = 3000;

    // The likelihood of an eagle breeding.
    private static final double BREEDING_PROBABILITY = 0.06;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;

    // The food value of a single eagle.
    private static final int EAGLE_FOOD_VALUE = 628;

    //Stores the ability of the animal to perform it's actions according to the weather.
    private double ability;

    /**
     * Create an eagle. An eagle can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the eagle will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Eagle(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        if(randomAge) {
            setAge(getRandom().nextInt(getMaxAge()));
            setFoodLevel(getRandom().nextInt(Squirrel.getFoodValue()));
        }
        else {
            setAge(0);
            setFoodLevel(Squirrel.getFoodValue());
        }
    }

    /**
     * Returns the eagle's max litter size.
     * 
     * @return the eagle's max litter size.
     */
    protected  int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the eagle's breeding probability.
     * 
     * @return the eagle's breeding probability.
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the food value of an eagle.
     * 
     * @return the food value of an eagle.
     */
    public static int getFoodValue(){
        return EAGLE_FOOD_VALUE;
    }

    /**
     * Return the eagle's max age.
     * 
     * @return the eagle's max age.
     */
    protected  int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * This is what the eagle does most of the time: it hunts for
     * squirrels. In the process, it might breed, die of hunger, old age, disease or overcrowding.
     * 
     * @param field The field currently occupied.
     * @param newEagles A list to return newly born eagles.
     */
    public void act(List<Organism> newEagles)
    {
        incrementAge();
        incrementHunger();

        //checks if the animal has a disease (checkDisease() also checks if the animal will die from it).
        //If true, the animal is set to dead.
        if(checkDisease()){
            setDead(); 
        }

        if(isAlive()) {
            ability = getField().getWeather().getMultiplier();

            //Eagles act during the day and sleep (do nothing) at night.
            if (getField().getTime().isDay() && getRandom().nextDouble() <= ability) {
                giveBirth(newEagles);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
            //else it's sleeping
        }

    }

    /**
     * Look for squirrels adjacent to the current location.
     * Only the first live squirrel is eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    squirrel.setDead();
                    setFoodLevel(squirrel.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this eagle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newEagles A list to return newly born eagles.
     */
    private void giveBirth(List<Organism> newEagles)
    {
        // New eagles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Eagle young = new Eagle(false, field, loc);
            newEagles.add(young);
        }
    }

    /**
     * An eagle can breed if it has reached the breeding age and has a mate.
     * 
     * @return true if the eagle can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        Boolean hasMate = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location where : adjacent) {
            Object animal = field.getAnimalAt(where);
            if(animal instanceof Eagle) {
                Eagle eagle = (Eagle) animal;
                if(!eagle.isFemale()) { 
                    hasMate = true;
                }
            }
        }   

        //isFemale() checked first for shortcutting
        return ( isFemale() &&getAge() >= BREEDING_AGE && hasMate);
    }
}

