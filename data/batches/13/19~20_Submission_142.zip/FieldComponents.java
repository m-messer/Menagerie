
/**
 * The representation of components that can exist in a single location
 * of a field. Composed of a foliageLayer and animalLayer for plants and
 * animals repectively. 
 *
 * @version 2020.02.21
 */
public class FieldComponents
{
    //The animal layer.
    private Object animalLayer;

    //The plants (foliage) layer.
    private Object foliageLayer;

    /**
     * Construct an empty field component object.
     */
    public FieldComponents()
    {
        animalLayer = null;
        foliageLayer = null;
    }

    /**
     * Returns the the animal in the animalLayer.
     * @return animal in animalLayer, null if empty.
     */
    public Object getAnimal()
    {
        return animalLayer;
    }

    /**
     * Returns the the plant in the plantLayer.
     * @return plant in plantLayer, null if empty.
     */
    public Object getPlant()
    {
        return foliageLayer;
    }

    /**
     *  Set the animalLayer to an Animal object
     *  @param object to set in animalLayer.
     */
    public void setAnimal(Object animal)
    {
        if(animal instanceof Animal && animal != null) {
            animalLayer = animal;
        }
    }

    /**
     *  Set the foliageLayer to a plant object
     *  @param object to set in foliageLayer.
     */
    public void setPlant(Object plant)
    {
        if(plant instanceof Plant && plant != null) {
            foliageLayer = plant;
        }
    }

    /**
     * Clear both layers of the fieldcomponent object
     */
    public void clear()
    {
        animalLayer = null;
        foliageLayer = null;
    }

    /**
     * Clear a specific layer from the field component object based on the
     * class of the parameter object.
     * @param Object to be cleared from the field component.
     */
    public void clear(Object object)
    {
        if (object instanceof Animal)
        {
            animalLayer = null;
        }
        else if (object instanceof Plant)
        {
            foliageLayer = null;
        }
    }
}
