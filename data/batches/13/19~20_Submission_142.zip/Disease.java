import java.util.Random;

/**
 * Represents a disease.
 *
 * @version 2020.02.21 
 */
public class Disease
{
    //The likely hood the animal will die from the disease.
    private double mortalityRate;
    
    //The likely hood the disease will occur.
    private double occurrenceProb;
    
    //Checks if the disease is active.
    private boolean isActive;
    
    private static final Random rand = Randomizer.getRandom();

    /**
     * Created a new disease.
     * 
     * @param mortalityRate the mortality rate of this disease.
     * @param occurenceProb the occurence probability of this disease.
     */
    public Disease(double mortalityRate, double occurrenceProb)
    {
        isActive = false;
        this.mortalityRate = mortalityRate;
        this.occurrenceProb = occurrenceProb;
    }

    /**
     * Checks if the disease is active
     * 
     * @return true if it is active.
     */
    public boolean isActive()
    {
        return isActive;
    }
    
    /**
     * De-activates the disease.
     */
    public void deActive(){
        isActive = false;
    }
    
    /**
     * Makes the disease active if the random number generated is less than it's occurence probability.
     */
    public void step(){
        if(rand.nextDouble() < occurrenceProb){
            isActive = true;
        }
    }
    
    /**
     * Returns the disease's mortality rate.
     * 
     * @return the mortality rate of the disease
     */
    public double getMortalityRate(){
        return mortalityRate;
    }
}
