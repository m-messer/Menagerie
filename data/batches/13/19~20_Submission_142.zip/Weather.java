
import java.util.Random;
import java.util.List;
import java.util.ArrayList;

/**
 * A class representing weather. It stores an ArrayList of weather conditions as well as
 * how they affect the organisms.
 *
 * @version 2020.02.21 
 * 
 * 0 - clear
 * 1 - fog
 * 2 - rain
 */
public class Weather
{
    private int weather;
    //The index refers to the weather condition and the coresponding element stores the probability that the animal can carry out 
    //its day to day actions
    private ArrayList<Double> multiplierTable = new ArrayList<>();
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Constructor for the class Weather 
     * 
     */
    public Weather()
    {
        weather = rand.nextInt(3);
        
        //clear
        multiplierTable.add(1.0);
        //fog
        multiplierTable.add(0.6);
        //rain
        multiplierTable.add(0.8);
    }
    
    /**
     * Changes the weather conditions
     */
    public void step()
    {
        weather = rand.nextInt(3);
    }
    
    /**
     * Returns the the probability that the animal can carry out its day to day actions.
     * 
     * @return the probability
     */
    public double getMultiplier()
    {
        return multiplierTable.get(weather);
    }
    
}
    
