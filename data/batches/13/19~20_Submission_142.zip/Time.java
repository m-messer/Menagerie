
/**
 * This class represents time of day. 
 * 
 * 1 means it's day 
 * 0 means it's night
 *
 * @version 2020.02.21 
 * 
 */
public class Time
{
    private int time;

    /**
     * Constructor for the Time class.
     */
    public Time()
    {
        //initially set to day time.
        time = 1;
    }

    /**
     * Changes the time of day.
     */
    public void step()
    {
        if (time == 0){
            time = 1;
        } else if(time == 1) {
            time = 0;
        }
    }

    /**
     * Checks if it is day time.
     * 
     * @return true if it is daytime.
     */
    public boolean isDay()
    {
        return (time == 1);
    }
}
