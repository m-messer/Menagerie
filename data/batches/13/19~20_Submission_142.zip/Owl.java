import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an owl.
 * Owls age, move, eat squirrels or scorpions , and die.
 *
 * @version 2016.02.29 (2)
 *  
 * @version 2020.02.21
 */
public class Owl extends Animal
{
    // Characteristics shared by all owls (class variables).

    // The age at which an owl can start to breed.
    private static final int BREEDING_AGE = 752;
    
    // The age to which an owl can live.
    private static final int MAX_AGE = 3768;
    
    // The likelihood of an owl breeding.
    private static final double BREEDING_PROBABILITY = 0.025;
    
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    
    // The food value of a single owl.
    private static final int OWL_FOOD_VALUE = 3200;

    //Stores the ability of the animal to perform it's actions according to the weather.
    private double ability;

    /**
     * Create an owl. An owl can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the owl will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Owl(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        if(randomAge) {
            setAge(getRandom().nextInt(getMaxAge()+1));
            setFoodLevel(getRandom().nextInt(Squirrel.getFoodValue()));
        }
        else {
            setAge(0);
            
            //Randomly sets the owl's food level to a squirrel or spider.
            if (getRandom().nextInt(2) == 0) {
                setFoodLevel(Squirrel.getFoodValue());
            }
            else {
                setFoodLevel(Scorpion.getFoodValue());
            }
        }
    }

    /**
     * Returns the owl's max litter size.
     * 
     * @return the owl's max litter size.
     */
    protected  int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the owl's breeding probability.
     * 
     * @return the owl's breeding probability.
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the food value of an owl.
     * 
     * @return the food value of an owl.
     */
    public static int getFoodValue(){
        return OWL_FOOD_VALUE;
    }

    /**
     * Return the owl's max age.
     * 
     * @return the owl's max age.
     */
    protected  int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * This is what the owl does most of the time: it hunts for
     * scorpions. In the process, it might breed, die of hunger, old age, disease or overcrowding.
     * 
     * @param field The field currently occupied.
     * @param newEagles A list to return newly born owls.
     */
    public void act(List<Organism> newOwls)
    {
        incrementAge();
        incrementHunger();
        
        //checks if the animal has a disease (checkDisease() also checks if the animal will die from it).
        //If true, the animal is set to dead.
        if(checkDisease()){
            setDead(); 
        }

        if(isAlive()) {
            ability = getField().getWeather().getMultiplier();

            //Owls act during the night and sleep (do nothing) during the day.
            if (!getField().getTime().isDay() && getRandom().nextDouble() <= ability) {
                giveBirth(newOwls);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        //else do nothing
    }

    /**
     * Look for scorpions or squirrels adjacent to the current location.
     * The owl tries to eat a squirrel or a scorpion but not both at the
     * same time.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    squirrel.setDead();
                    setFoodLevel(squirrel.getFoodValue());
                    return where;
                }
            }

            if(animal instanceof Scorpion) {
                Scorpion scorpion = (Scorpion) animal;
                if(scorpion.isAlive()) { 
                    scorpion.setDead();
                    setFoodLevel(scorpion.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this owl is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newEagles A list to return newly born owls.
     */
    private void giveBirth(List<Organism> newOwls)
    {
        // New owls are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Owl young = new Owl(false, field, loc);
            newOwls.add(young);
        }
    }

    /**
     * An owl can breed if it has reached the breeding age and has a mate.
     */
    protected boolean canBreed()
    {
        Boolean hasMate = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location where : adjacent) {
            Object animal = field.getAnimalAt(where);
            if(animal instanceof Owl) {
                Owl owl = (Owl) animal;
                if(!owl.isFemale()) { 
                    hasMate = true;
                }
            }
        }

        //isFemale() checked first for shortcutting
        return ( isFemale() && getAge() >= BREEDING_AGE && hasMate);
    }

}
