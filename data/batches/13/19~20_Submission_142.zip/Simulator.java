import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field.
 *
 * @version 2016.02.29 (2)
 *  
 * @version 2020.02.21
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.

    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;

    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // The probability that an eagle will be created in any given grid position.
    private static final double EAGLE_CREATION_PROBABILITY = 0.007;

    // The probability that an owl will be created in any given grid position.
    private static final double OWL_CREATION_PROBABILITY = 0.005;

    // The probability that a scorpion will be created in any given grid position.
    private static final double SCORPION_CREATION_PROBABILITY = 0.015;

    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.05; 

    // The probability that a spider will be created in any given grid position.
    private static final double SPIDER_CREATION_PROBABILITY = 0.075;

    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 1;

    // List of animals in the field.
    private List<Animal> animals;

    // The current state of the field.
    private Field field;

    // The current step of the simulation.
    private int step;

    // A graphical view of the simulation.
    private SimulatorView view;

    //List of plants in the field.
    private List<Plant> plants;

    //List of organisms in the field.
    private List<Organism> organisms;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * 
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();

        organisms = new ArrayList<>();
        field = new Field(depth, width);

        //These are the default (day) colors of the simulation.
        view = new SimulatorView(depth, width);
        view.setColor(Plant.class, new Color(167, 245, 66));
        view.setColor(Owl.class, new Color(43, 30, 230));
        view.setColor(Eagle.class, new Color(235, 19, 19));
        view.setColor(Scorpion.class, new Color(35, 221, 235));
        view.setColor(Spider.class, new Color(190, 32, 214));
        view.setColor(Squirrel.class, new Color(245, 139, 10));

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * 
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        //one day is 50 steps. 25 steps day 25 night
        if(step%25 == 0){
            field.getTime().step();
            field.getWeather().step();
        }

        if(field.getTime().isDay()){ 
            view.setColor(Plant.class, new Color(167, 245, 66));
            view.setColor(Owl.class, new Color(43, 30, 230));
            view.setColor(Eagle.class, new Color(235, 19, 19));
            view.setColor(Scorpion.class, new Color(35, 221, 235));
            view.setColor(Spider.class, new Color(190, 32, 214));
            view.setColor(Squirrel.class, new Color(245, 139, 10));
        }

        if(!field.getTime().isDay()){
            view.setColor(Plant.class, new Color(68, 117, 4));
            view.setColor(Owl.class, new Color(9, 0, 133));
            view.setColor(Eagle.class, new Color(110, 1, 1));
            view.setColor(Scorpion.class, new Color(3, 95, 102));
            view.setColor(Spider.class, new Color(84, 2, 97));
            view.setColor(Squirrel.class, new Color(161, 88, 0));
        }

        // Provide space for newborn animals.
        List<Organism> newOrganisms = new ArrayList<>(); 
        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms);
            if((! organism.isAlive())) {
                it.remove();
            }
        }

        // Add the new organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;

        animals.clear();
        plants.clear();
        organisms.clear();

        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();

        //populating the animals
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    organisms.add(squirrel);
                }
                else if(rand.nextDouble() <= SPIDER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Spider spider = new Spider(true, field, location);
                    organisms.add(spider);
                }
                else if(rand.nextDouble() <= SCORPION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Scorpion scorpion = new Scorpion(true, field, location);
                    organisms.add(scorpion);
                }
                else if(rand.nextDouble() <= EAGLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(true, field, location);
                    organisms.add(eagle);
                }
                else if(rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    organisms.add(owl);
                }
                // else leave the location empty.
            }
        }

        //populating the plants
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    organisms.add(plant);
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * 
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
