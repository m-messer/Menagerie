import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * Represents all organisms in the field.
 *
 * @version 2020.02.21 
 */
public abstract class Organism
{
    private static final Random rand = Randomizer.getRandom();
    
    // Whether the actor is alive or not.
    private boolean alive;
    
    // The actor's field.
    private Field field;
    
    // The actor's position in the field.
    private Location location;
    
    // The actors's age.
    private int age;
    
    // The actor's food level, which is increased by eating.
    private int foodLevel;
    
    /**
     * Constructor for the class Organism.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location); 
    }
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location, this);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location, this);
        }
        location = newLocation;
        if (this instanceof Animal) {
            field.place(this, newLocation);
        } else if (this instanceof Plant) {
            field.place(this, newLocation);
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Sets the organism's age.
     */
    protected void setAge(int age){
        this.age = age;
    }
    
    /**
     * Returns the organism's age.
     * 
     * @return age The age of the organism.
     */
    protected int getAge(){
        return age;   
    }
    
    /**
     * Increments the age of the organism (this can result in the organism's death).
     * 
     */
    protected void incrementAge(){
        setAge(getAge()+1);
        if(getAge()>getMaxAge()){
            setDead();
        }
    }
    
    /**
     * Abstract method that returns the organism's maximum age.
     */
    protected abstract int getMaxAge();
    
    /**
     * Sets the food level of the organism.
     * 
     * @param foodLevel the organism's new food level.
     */
    protected void setFoodLevel(int foodLevel){
        this.foodLevel = foodLevel;
    }
    
    /**
     * Returns the food value of the organism.
     * 
     * @return the food level.
     */
    protected int getFoodLevel(){
        return foodLevel;   
    }
    
    /**
     * Increments the organism's hunger (this may result in its death).
     */
    protected void incrementHunger(){
        setFoodLevel(getFoodLevel()-1);
        if(getFoodLevel() < 0) {
            setDead();
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Organism> newActors);

    /**
     * Checks if the organisms can breed.
     * 
     * @return true if the organism can breed.
     */
    protected abstract boolean canBreed();
    
    /**
     * Returns the breeding probability of the organism.
     * 
     * @return the breeding probability.
     */
    protected abstract double getBreedingProbability();

    /**
     * Returns the organism's max litter size.
     * 
     * @return the max litter size.
     */
    protected abstract int getMaxLitterSize();
    
    /**
     * Allows organisms to breed.
     * 
     * @return the number of births the organism will have.
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Checks the field for existing diseases. A random number is generated to see if the animal will die from the disease.
     * 
     * @return true if the animal dies from the disease.
     */
    protected boolean checkDisease(){
        ArrayList<Disease> existingDiseases = new ArrayList<>();
        if (isAlive()) {
            existingDiseases = getField().getDiseases();
        }
        for(Disease disease : existingDiseases){
            if(disease.isActive()){
                if(rand.nextDouble() < disease.getMortalityRate()){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Returns a random number.
     * 
     * @return a random number.
     */
    protected Random getRandom()
    {
        return rand;
    }
}
