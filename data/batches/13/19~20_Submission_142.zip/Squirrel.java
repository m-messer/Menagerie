import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a squirrel.
 * Squirrels age, move,eat plants, and die.
 *
 * @version 2016.02.29 (2)
 *  
 * @version 2020.02.13 
 */
public class Squirrel extends Animal
{
    // Characteristics shared by all squirrels (class variables).

    // The age at which a squirrel can start to breed.
    private static final int BREEDING_AGE = 480;
    
    // The age to which a squirrel can live.
    private static final int MAX_AGE = 2400;
    
    // The likelihood of a squirrel breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    
    // The food value of a single squirrel.
    private static final int SQUIRREL_FOOD_VALUE = 500;
    
    //Stores the ability of the animal to perform it's actions according to the weather.
    private double ability;

    /**
     * Create a new squirrel. A squirrel may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the squirrel will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Squirrel(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        if(randomAge) {
            setAge(getRandom().nextInt(getMaxAge()+1));
            setFoodLevel(getRandom().nextInt(Plant.getFoodValue()));
        }
        else {
            setAge(0);
            setFoodLevel(Plant.getFoodValue());
        }
    }

   /**
     * Returns the squirrel's max litter size.
     * 
     * @return the squirrel's max litter size.
     */
    protected  int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the squirrel's breeding probability.
     * 
     * @return the squirrel's breeding probability.
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the food value of a squirrel.
     * 
     * @return the food value of a squirrel.
     */
    public static int getFoodValue(){
        return SQUIRREL_FOOD_VALUE;
    }

    /**
     * Return the squirrel's max age.
     * 
     * @return the squirrel's max age.
     */
    protected  int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * This is what the squirrel does most of the time - it eats plants. 
     * Sometimes it will breed or die of old age.
     * 
     * @param newSquirrels A list to return newly born squirrels.
     */
    public void act(List<Organism> newSquirrels)
    {
        incrementAge();
        incrementHunger();
        
        //checks if the animal has a disease (checkDisease() also checks if the animal will die from it).
        //If true, the animal is set to dead.
        if(checkDisease()){
            setDead(); 
        }
        
        if(isAlive()) {
            ability = getField().getWeather().getMultiplier();
            
            //Squirrels act during the day and sleep (do nothing) at night.
            if (getField().getTime().isDay() && getRandom().nextDouble() <= ability) {               
                giveBirth(newSquirrels);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
            //else it's sleeping
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getPlantAt(where);
            if(obj instanceof Plant) {
                Plant plant = (Plant) obj;
                if(plant.isAlive()) { 
                    plant.setDead();
                    setFoodLevel(plant.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this squirrel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newSquirrels A list to return newly born squirrels.
     */
    private void giveBirth(List<Organism> newSquirrels)
    {
        // New squirrels are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Squirrel young = new Squirrel(false, field, loc);
            newSquirrels.add(young);
        }
    }

    /**
     * A squirrel can breed if it has reached the breeding age.
     * 
     * @return true if the squirrel can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        Boolean hasMate = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location where : adjacent) {
            Object animal = field.getAnimalAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(!squirrel.isFemale()) { 
                    hasMate = true;
                }
            }
        }

        //isFemale() checked first for shortcutting
        return (isFemale() && getAge() >= BREEDING_AGE && hasMate);
    }
}
