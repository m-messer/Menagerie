import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a scorpion.
 * Scorpion age, move, eat spiders, and die.
 *
 * @version 2016.02.29 (2)
 *  
 * @version 2020.02.21
 */
public class Scorpion extends Animal
{
    // Characteristics shared by all scorpions (class variables).

    // The age at which a scorpion can start to breed.
    private static final int BREEDING_AGE = 600;
    
    // The age to which a scorpion can live.
    private static final int MAX_AGE = 3000;
    
    // The likelihood of a scorpion breeding.
    private static final double BREEDING_PROBABILITY = 0.95;
    
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    
    // The food value of a single scorpion.
    private static final int SCORPION_FOOD_VALUE = 628;
    
    //Stores the ability of the animal to perform it's actions according to the weather.
    private double ability;;


    /**
     * Create a scorpion. A scorpion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the scorpion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Scorpion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        if(randomAge) {
            setAge(getRandom().nextInt(getMaxAge()+1));
            setFoodLevel(getRandom().nextInt(Spider.getFoodValue()));
        }
        else {
            setAge(0);
            setFoodLevel(Spider.getFoodValue());
        }
    }

    /**
     * Returns the scorpion's max litter size.
     * 
     * @return the scorpion's max litter size.
     */
    protected  int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the scorpion's breeding probability.
     * 
     * @return the scorpion's breeding probability.
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the food value of a scorpion.
     * 
     * @return the food value of a scorpion.
     */
    public static int getFoodValue(){
        return SCORPION_FOOD_VALUE;
    }

    /**
     * Return the scorpion's max age.
     * 
     * @return the scorpion's max age.
     */
    protected  int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * This is what the scorpion does most of the time: it hunts for
     * spiders. In the process, it might breed, die of hunger, old age, disease or overcrowding.
     * 
     * @param field The field currently occupied.
     * @param newSpiders A list to return newly born scorpions.
     */
    public void act(List<Organism> newScorpions)
    {
        incrementAge();
        incrementHunger();

        //checks if the animal has a disease (checkDisease() also checks if the animal will die from it).
        //If true, the animal is set to dead.
        if(checkDisease()){
            setDead(); 
        }

        if(isAlive()) {
            ability = getField().getWeather().getMultiplier();
            
            //Scorpions act during the day and night
            if (getRandom().nextDouble() <= ability) {
                giveBirth(newScorpions);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
            
        }
    }

    /**
     * Look for spiders adjacent to the current location.
     * Only the first live spider is eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            if(animal instanceof Spider) {
                Spider spider = (Spider) animal;
                if(spider.isAlive()) { 
                    spider.setDead();
                    setFoodLevel(spider.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this scorpion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * 
     * @param newScorpions A list to return newly born scorpions.
     */
    private void giveBirth(List<Organism> newScorpions)
    {
        // New scorpions are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Scorpion young = new Scorpion(false, field, loc);
            newScorpions.add(young);
        }
    }

    /**
     * A scorpion can breed if it has reached the breeding age and has a mate.
     */
    protected boolean canBreed()
    {
        Boolean hasMate = false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location where : adjacent) {
            Object animal = field.getAnimalAt(where);
            if(animal instanceof Scorpion) {
                Scorpion scorpion = (Scorpion) animal;
                if(!scorpion.isFemale()) { 
                    hasMate = true;
                }
            }
        }

        //isFemale() checked first for shortcutting
        return (isFemale() && getAge() >= BREEDING_AGE && hasMate);
    } 
}
