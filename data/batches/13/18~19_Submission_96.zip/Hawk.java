import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a hawk.
 * Snakes age, move, eat deers, and die.
 *
 * @version 2019.02.21
 */
public class Hawk extends Organism
{    
    // Characteristics shared by all hawks (class variables).
    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 40;
    // The age to which a hawk can live.
    private static final int MAX_AGE = 180;
    // The likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.03;
    // The maximum number of births.
    private static final double RESISTANCE_PROBABILITY = 0.5;
    // The likelihood of resisting the disease
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single mice. In effect, this is the
    // number of steps a hawk can go before it has to eat again.
    private static final int MICE_FOOD_VALUE = 10;
    // The food value of a single deer. In effect, this is the
    // number of steps a hawk can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 25;
    // The food value of a single snake. In effect, this is the
    // number of steps a hawk can go before it has to eat again.
    private static final int SNAKE_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The hawk's age.
    private int age;
    // The hawk's food level, which is increased by eating deers.
    private int foodLevel;

    
    /**
     * Create a hawk. A hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hawk will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hawk(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(DEER_FOOD_VALUE);
            infected = rand.nextBoolean();
            // some might have disease at it is created with a 50% chance of being infected.
            // if infected will them age faster.
            if (infected == true)
            {
                age = age + rand.nextInt(50);
            }
        }
        else {
            age = 0;
            foodLevel = DEER_FOOD_VALUE;
        }
        
    }

 
    /**
     * It hunts for deers,mice and snake during the day. In the process, it might breed, die of hunger,
     * or die of old age. Also increse the time counter.
     * @param field The field currently occupied.
     * @param newHawls A list to return newly born hawks.
     */
    public void act(List<Organism> newHawks)
    {
        if (isDay())
        {
            incrementAge();
            incrementHunger();
            if(isAlive()) {
            giveBirth(newHawks);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            }
        }
        else if (isDay() == false)
        {
            //do nothing
        }        
        incrementTime();
    }

    /**
     * Increase the age. This could result in the hawk's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    
    /**
     * Make this hawk more hungry. This could result in the hawk's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for deers adjacent to the current location.
     * Only the first live deer, snake or mice is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Deer) {
                Deer deer = (Deer) organism;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel = DEER_FOOD_VALUE;
                    return where;
                }
            }
            else if(organism instanceof Mice) {
                Mice mice = (Mice) organism;
                if(mice.isAlive()) { 
                    mice.setDead();
                    foodLevel = MICE_FOOD_VALUE;
                    return where;
                }
            }
            else if(organism instanceof Snake) {
                Snake snake = (Snake) organism;
                if(snake.isAlive()) {
                    snake.setDead();
                    foodLevel = SNAKE_FOOD_VALUE;
                    return where;
                }
        }
    }
    return null;
    }
    
    /**
     * Check whether or not this hawk is to give birth at this step.
     * New births will be made into free adjacent locations. New birth might have resistance to disease
     * @param newHawks A list to return newly born hawks.
     */
    private void giveBirth(List<Organism> newHawks)
    {
        // New hawks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hawk young = new Hawk(false, field, loc);
            newHawks.add(young);
            young.setResistance();
        }
    }
    
    /**
     * Give the hawk resistance to disease. Having it will cause them die from premature death by 
     * increasing their age by a random number.
     */
    private void setResistance()
    {
        if (rand.nextDouble() <= RESISTANCE_PROBABILITY)
       {
         resistance = true;
         infected = false;
       }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hawk can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}

