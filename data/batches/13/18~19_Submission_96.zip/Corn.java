import java.util.List;
import java.util.Random;

/**
 * 
 * A simple model of a corn.
 * Corn reproduce and get eaten.
 *
 * @version 2019.02.21
 */
public class Corn extends Organism
{
    // The likelihood of a corn reproducing.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of new corn.
    private static final int MAX_REPRODUCTION_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

     /**
     * Create a corn.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Corn(Field field, Location location)
    {
        super(field, location);
       
    }

    /**
     * This is what the Corn does most of the time. It stays in place and multiply to occupy adjacent
     * spots.
     * The corn will only reproduce during the day and if it is alive. Also will increment the time
     * counter.
     * @param newGrass A list to return newly grown corn.
     */
    public void act(List<Organism> newCorn)
    {
        if (isDay()){
           if (isAlive()){
           addCorn(newCorn);
          }
       }
       else if (isDay() == false){
        //do nothing
       }
      incrementTime();
    }
    
     /**
     * Check whether or not this grass is to reproduce at this step.
     * New grass will be made into free adjacent locations.
     * @param newGrass A list to return newly made grass.
     */
    public void addCorn(List<Organism> newCorn)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Corn young = new Corn(field, loc);
            newCorn.add(young);
        }
    }
    
    /**
    * Generate a number representing the number of births,
    * if it can breed.
    * @return The number of births (may be zero).
    */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_REPRODUCTION_SIZE) + 1;
        }
        return births;
    }
}
