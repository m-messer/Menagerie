import java.util.List;

/**
 * A class representing shared characteristics of organisms.
 *
 * @version 2019.02.21
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;
    // Whether the organism has disease or not.
    protected boolean infected;
    // Whether it has resistance against disease or not
    protected boolean resistance;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    //determines the gender of the animals
    private int gender;
    //determines the time of day
    protected int time;
    
    
    
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Returns the gender of the animal
     */
    public int getGender()
    {
        return gender;
    }
    
    /**
     * Set the gender of the animal 
     * @param whichGender determines the gender. 0 if it is a male and 1 if it is a female
     */
    public void setGender(int whichGender)
    {
        gender = whichGender;
    }
    
    /**
     * Set the range of day time using number from 0 to 39. Daytime is from 20-39 that will return
     * true. Else in nighttime and will return false.
     */
    protected boolean isDay()
    {
        if(time >= 20 && time <=39){
             return true;
          }
          else {
             return false;
          }
    }
    
    /**
     * Increase the time counter. Resets to zero if more than 39.
     */
    protected void incrementTime()
    {
       time++;
       if (time>39){
           time=0;
       }
    }

    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born organisms.
     */
    abstract public void act(List<Organism> newOrganisms);

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Checks if the organism has disease or not. The disease can only spread to the same species
     * @return true if it has disease
     */
    protected boolean hasDisease()
    {
        return infected;
    }
    
    /**
     * Checks if the organism has resistance to disease or not.
     * @return true if it has resistance to disease
     */
    protected boolean hasResistance()
    {
        return resistance;
    }
    
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
}
