import java.util.Random;

/**
 * Creates the weather in the simulation.
 * Weather can be sunny, foggy or rainy
 *
 * @version 2022.03.02
 */
public class Weather
{
    private static final double rainProbability = 0.4;
    
    private boolean isRainy;
    
    private static final double fogProbability = 0.3;
    
    private boolean isFoggy;
    
    private static final double sunProbability = 0.3;
    
    private boolean isSunny;
    
    Random rand = Randomizer.getRandom();

    /**
     * Creates weather,can be sunny, foggy or rainy
     * 
     */
    public Weather(boolean rain, boolean fog, boolean sun)
    {
        isRainy = rain;
        isFoggy = fog;
        isSunny = sun;
    }
    
    
    
    /**
     * Uses random generated number to create weather accordingly.
     */
    public void createWeather(){
        
        if(rand.nextDouble() <= rainProbability){
            //System.out.println("Rain");
            Weather weather = new Weather(true,false,false);
        }
        else if(!isRainy && rand.nextDouble() <= fogProbability){
            //System.out.println("Fog");
            Weather weather = new Weather(false,true,false);
        }
        else if(!isRainy && !isFoggy){
            //System.out.println("Sun");
            Weather weather = new Weather(false,false,true);
        }
    
    }
    
    
    
    /**
     * @return true if rainy 
     */
    public boolean isRainy(){
        return isRainy;
    }
    
    
    
    /**
     * @return true if foggy 
     */
    public boolean isFoggy(){
        return isFoggy;
    }
    
    
    
    /**
     * @return true if sunny 
     */
    public boolean isSunny(){
        return isSunny;
    }
}
