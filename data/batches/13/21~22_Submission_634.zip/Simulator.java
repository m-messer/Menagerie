import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sheeps, cows, pigs, wolfs, bears and plants.
 *
 * @version 2022.03.02 
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.05;
    // The probability that a sheep will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.1;   
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.2; 
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.08; 
    // The probability that a cow will be created in any given grid position.
    private static final double COW_CREATION_PROBABILITY = 0.07;  
    // The probability that a pig will be created in any given grid position.
    private static final double PIG_CREATION_PROBABILITY = 0.1; 
    // The probability that an animal will be created as female.
    private static final double FEMALE_PROBABILITY = 0.5;
    // The probability that an animal will be created as diseased.
    private static final double DISEASE_PROBABILITY = 0.001;
    
    
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    private SimTime time;
    
    private Weather weather;
    
    private int previousHour;
    
    private int currentHour;
    
    private int stepDuration;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        previousHour = 0;
        currentHour = 0;
        stepDuration = 0;
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        time = new SimTime();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        view.setColor(Bear.class, Color.MAGENTA);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Sheep.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Cow.class, Color.BLACK);
        view.setColor(Pig.class, Color.PINK);
        
        // Setup a valid starting point.
        reset();
    }
    
    
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 0; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }
    
    
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        Random rand = Randomizer.getRandom();
        currentHour = time.getHour(1, 70);
        
        //System.out.println(currentHour);
        stepDuration = currentHour - previousHour;
        
        //new day has begun 
        if(previousHour > currentHour){
            stepDuration = 24 + stepDuration;
        }

        // Provide space for newborn animals an plants.
        List<Plant> newPlants = new ArrayList<>();
        List<Animal> newAnimals = new ArrayList<>(); 
        
        
        // Let all plants and animals act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        
        
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            //creates diseased animals
            if(rand.nextDouble() <= DISEASE_PROBABILITY && !animal.getDisease()){
                animal.setDisease(true);
            }
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
           
        
        
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);
        
        view.showStatus(step, field);

        previousHour = currentHour;
        
        if(currentHour == 0){
            time.incrementDayCount();
        }
        
        //time.simTimerHeartBeat(10);       
    }
        
    
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    
                    if(rand.nextDouble() <= FEMALE_PROBABILITY){
                        Wolf wolf = new Wolf(true, field, location);
                        wolf.setGender(false);
                        animals.add(wolf); 
                    }
                    else{
                        Wolf wolf = new Wolf(true, field, location);
                        wolf.setGender(true);
                        animals.add(wolf); 
                    }
                }
                else if(rand.nextDouble() <= COW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if(rand.nextDouble() <= FEMALE_PROBABILITY){
                       Cow cow = new Cow(true, field, location);
                       cow.setGender(false);
                       animals.add(cow); 
                    }
                    else{
                       Cow cow = new Cow(true, field, location);
                       cow.setGender(true);
                       animals.add(cow); 
                    }
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if(rand.nextDouble() <= FEMALE_PROBABILITY){
                       Bear bear = new Bear(true, field, location);
                       bear.setGender(false);
                       animals.add(bear); 
                    }
                    else{
                       Bear bear = new Bear(true, field, location);
                       bear.setGender(true);
                       animals.add(bear); 
                    }
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if(rand.nextDouble() <= FEMALE_PROBABILITY){
                      Sheep sheep = new Sheep(true, field, location);
                      sheep.setGender(false);
                      animals.add(sheep);  
                    }
                    else{
                      Sheep sheep = new Sheep(true, field, location);
                      sheep.setGender(true);
                      animals.add(sheep);                     
                    }
                 }
                else if(rand.nextDouble() <= PIG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    if(rand.nextDouble() <= FEMALE_PROBABILITY){
                        Pig pig = new Pig(true, field, location);
                        pig.setGender(false);
                        animals.add(pig);
                    }
                    else{
                        Pig pig = new Pig(true, field, location);
                        pig.setGender(true);
                        animals.add(pig);
                    }
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true,field, location, 150); 
                    plants.add(plant);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    
}