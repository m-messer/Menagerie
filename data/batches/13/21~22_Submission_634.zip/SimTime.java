
/**
 * SimTime class represents the time in the simulation.
 * When it is day time isDay = true, at night isDay = false.
 * Beginning of each day weather is also generated
 *
 * @version 2022.03.02
 * 
 */
public class SimTime
{   
    // true if day, false if night
    private boolean isDay;
    
    private Simulator simulator;
    //count for days 
    private int dayCount = 0;
    
    private Weather weather;
    
    /**
     * Constructor for objects of class Time
     */
    public SimTime()
    {   
     isDay = true; 
     weather = new Weather(false,false,false);
    }

    
    
    /**
     * Calculate current time.
     * @param timeScale ,how many millisceonds (70) --> hour (1) 
     * @return currentTimeTB
     */
    public long simTimerHeartBeat(long timeScale){
        // System.out.println(time);
        long currentTimeTB = System.currentTimeMillis() / timeScale; //timeScale= 70        
        //setTime(hours,minutes);
        return currentTimeTB;
    }
    
    
    
    /**
     * Get current time.
     * @param timeScale, 1hour
     * @param timeHour, 70millisecond
     * @return currentHour
     */
      public int getTime(long timeScale, long timeHour){
        // World time : timeScale = 1 , timeHour = 3600000
        // Sim time : timeSclae = 1 , timeHour = 70
        long currentTimeTB = simTimerHeartBeat(timeScale);
        
        long currentHours = (long) currentTimeTB / timeHour;
        
        //long currentDays  = (long) currentHours / 24;
        
        int currentHour = (int) currentHours % 24;
        
        //int currentMinute = (int) currentHour % 60;
        
        return currentHour;
        
        //System.out.println("hour : " + hour + "min : " + min );
    }
    
    
    
    /**
     * Gets the hour.
     * @param timeScale, 1hour
     * @param timeHour, 70millisecond
     * @return currentHour
     */
      public int getHour(long timeScale, long timeHour){
        // World time : timeScale = 1 , timeHour = 3600000
        // Sim time : timeSclae = 1 , timeHour = 10
        long currentTimeTB = simTimerHeartBeat(timeScale);
        
        long currentHours = (long) currentTimeTB / timeHour;
        int currentHour = (int) currentHours % 24;
        
        return currentHour;
    }
    
    
    
    /**
     * Checks if it is day time or night.
     * @param timeScale, 1hour
     * @param timeHour, 70millisecond
     * @return isDay, true if morning false if night 
     */
    public boolean isDay(long timeScale, long timeHour){
        int currentHour = this.getHour(timeScale, timeHour);
                
        if(currentHour <= 12 ){
            isDay = true;
            //System.out.println("Morning");
        }
        else if(currentHour > 12){
            isDay = false;
            //System.out.println("Night");
        }
        return isDay;
    }

    
    /**
     * Gets the day count.
     * @return int dayCount
     */
    public int getDayCount(){
        return dayCount;
    }
    
    
    /**
     * Increments day count.
     * Generates weather when new day starts.
     */
    public void incrementDayCount(){
        dayCount++;
        //System.out.println("day count : " + dayCount);
        weather.createWeather();
    }

}
