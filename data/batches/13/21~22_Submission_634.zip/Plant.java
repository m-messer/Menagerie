import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A model of a plant.
 * Plants age, and die.
 * They move and eat only when it is daytime..
 *
 * @version 2022.03.02
 * 
 */
public class Plant
{
    private Field field;
    
    private Location location;
    // The age at which a plant can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a plant can live.
    private static final int MAX_AGE = 40; 
    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.5; 
    // The maximum number of seeds.
    private static final int MAX_LITTER_SIZE = 3;
    //The food value of a plant
    private int foodValue;
    //Initial food level of a plant when age = 0
    private static final int PLANT_NUTRITION = 30;
    //Growth rate of plant 
    private static final int PLANT_GROW_VALUE = 2;
    // The wolf's age.
    private int age;
    // The plant's food level
    private int foodLevel;
    
    private boolean alive;
    //used to calculate 1 bite's food value 
    private int bite = 0 ;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private SimTime time;
    
    private Weather weather;

    /**
     * Create a plant. A plant can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the plant will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location, int foodValue )
    {
        alive = true;
        this.field = field;
        this.foodValue = foodValue;
        weather = new Weather(false,false,false);
        setLocation(location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_NUTRITION) + 3;
        }
        else {
            age = 0;
            foodLevel = PLANT_NUTRITION + 3;
        }
        //used for calculating food value of a single bite of plant
        bite = (int) Math.ceil(foodValue/3.0);
    }
    
    
    
    /**
     * This is what the plant does most of the time: grow and give birth.
     * @param newPlants.
     */
    public void act(List<Plant> newPlants)
    {
        growPlant();
        if(isAlive()) {
            giveBirth(newPlants);            
    
        }
    }

    
    
    /**
     * Decreases the food level of a plant. 
     * If the food level is 0 or less the plant dies.
     */
    public void decreaseFoodLevel(){
        foodLevel -= bite;
        if(foodLevel <= 0){
            setDead();
        }
    }
    
    
    /**
     * Returns the single value of a bite
     * @return int bite
     */
    public int getBite(){
        return bite;
    }
    
    
    
    /**
     * Increase the age. This could result in the plant's death.
     */
    private void growPlant()
    {
        if(weather.isSunny()){
           age = age * (PLANT_GROW_VALUE); 
        }
        else{
            age++;
        }
        
        //System.out.println("age " + age);  
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    
    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    
    
   /**
     * Check whether or not this plant can seed at this step.
     * New seeds will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     */
    private void giveBirth(List<Plant> newPlants)
    {
        // New plants are born into adjacent locations.
        Field field = getField();
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc,150);
            newPlants.add(young);
            //System.out.println("new plant created");
        }
    }
      
    
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
   private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    
    
   /**
     * A plant can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
    return age >= BREEDING_AGE;
    }
    
    
    
   private void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    
    
   /**
     * Return the plant's field.
     * @return The plant's field.
     */
   public Field getField()
    {
        return field;
    }
    
    
    
   /**
     * Return the plant's location.
     * @return The plant's location.
     */
   public Location getLocation()
    {
        return location;
    }
}
