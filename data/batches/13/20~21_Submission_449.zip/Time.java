/**
 * Keep track of the time of day for a simulation. Base task 4
 *
 * 
 */
public class Time
{
    private int hour;
    private int minute;
    
    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        // initialise instance variables
        hour = 0;
        minute = 0;
    }

    /**
     * Increment the minute of day
     *
     */
    public void incrementMinute()
    {
        int minutesInHour = 60;
        
        minute = (minute+1) % minutesInHour;
        
        if (minute == 0) {
            incrementHour();
        }
    }
    
    /**
     * Get hour of the day
     * @return the hour of the day
     */
    public int getHour() 
    {
        return hour;
    }
    
    /**
     * Increment hour of the day
     *
     */
    private void incrementHour() 
    {
        int hourInDay = 24;
        
        hour = (hour+1) % hourInDay;
    }
}
