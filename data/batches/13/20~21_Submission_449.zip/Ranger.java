import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Ranger monitors the safari park and releases animals in the simulation when the population becomes low.
 * Rangers can move around the simulation. A fixed number of rangers in the simulation.
 * @version March 2021
 */
public class Ranger extends Drawable 
{
    // No instance variable
    
    /**
     * Constructor for objects of class Ranger
     */
    public Ranger(Field field, Location location)
    {
        super(field,location);
    }
    
    /**
     * The ranger acts by releasing animals to the wild
     * 
     * @param the list of new actors 
     * @param the hour of day in simulation
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newActors, int hourOfDay, ArrayList<Class<?>> animals) 
    {
        Random rand= new Random();
        
        releaseAnimal(animals.get(rand.nextInt(animals.size())));
        
        Location newLocation = getField().freeAdjacentLocation(getLocation()); 
            
        if (newLocation != null) {
            setLocation(newLocation);
        }
    }
    
    /**
     * Place animals if there are no animals nearby ranger
     * 
     * @param the class associated with the animal chosen randomly from act method
     */
    protected void releaseAnimal(Class<?> animalClass) 
    {
       int distanceFromCurrentPosition = 2;
       
       Field field = getField(); 
       
       List<Location> adjacentLocations = field.adjacentLocations(getLocation(), distanceFromCurrentPosition);
                      
       List<Animal> nearbyAnimals = findNearbyAnimals(animalClass, distanceFromCurrentPosition);
       
       List<Location> adjLocation = new ArrayList<>();
       adjacentLocations.forEach(location -> adjLocation.add(location));
       
       // ranger places animals into positions don't know how to create objects dynamically
       placeActors(adjLocation, nearbyAnimals);
    }
    
    
    /**
     * Place random animals in the simulation, that are released by the ranger
     * 
     * @param the list of adjacent locations to current position of animal in simulation
     * @param the list of nearby animals to current position
     */
    private void placeActors(List<Location> adjLocation, List<Animal> nearbyAnimal) 
    {
       Field field = getField();
       if (nearbyAnimal.size() == 0) {
           field.place(new Cheetah(true, field, adjLocation.get(0)), adjLocation.get(0));
           field.place(new Giraffe(true, field, adjLocation.get(1)), adjLocation.get(1));
           field.place(new Zebra(true, field, adjLocation.get(2)), adjLocation.get(2));
           field.place(new Lion(true, field, adjLocation.get(3)), adjLocation.get(3));
           field.place(new Hyena(true, field, adjLocation.get(4)), adjLocation.get(4));
           field.place(new Plant(field, adjLocation.get(5)), adjLocation.get(5));
       }
    }
}
