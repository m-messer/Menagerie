import java.util.List;
import java.util.Random;
import java.util.ArrayList;
/**
 * The weather class is a non-drawable actor which influences if animal can move or not
 * Does not appear in the simulation, is an external factor. 
 *
 * @version March 2021
 */
public class Weather implements Actor
{
    // likelihood of raining
    private double rainProbability;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Creates a weather object and sets all initial probabilities of weather 
     * 
     */
    public Weather()
    {
        rainProbability = 0;
    }

    /**
     * When the act method is triggered the weather sets the rainProbability
     * 
     * @param the list of new actors 
     * @param the hour of day in simulation
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newActors, int hourOfDay, ArrayList<Class<?>> animals)
    {
        Random rand = new Random();
        rainProbability = rand.nextFloat();
    }
    
    /**
     * 
     * Check is actor is active in simulation
     * 
     * @return true if active
     */
    public boolean isActive() 
    {
        return false;
    }
    
    /**
     * Gets the probability of rain in a step of simulation 
     * 
     * @return the value of the probability
     */
    public double getRainProbability() 
    {
        return rainProbability;
    }
}
