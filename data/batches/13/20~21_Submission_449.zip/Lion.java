import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
/**
 * Model of a Lion within the simulator - this models the Lion's actions
 * including hunting prey and reproducing. Lions eat cheetah and giraffe
 *
 * @version March 2021
 *
 */
public class Lion extends Animal
{
    //The youngest age a Lion can breed
    private static final int BREEDING_AGE = 3;
    //The max age a Lion can live to
    private static final int MAX_AGE = 90;
    //The probability of producing young at breeding point
    private static final double BREEDING_PROBABILITY = 0.2;
    //The max number of young that can be produced at any one time
    private static final int MAX_LITTER_SIZE = 2;
     //The value of each of its prey in terms of food supply
    private static final int CHEETAH_FOOD_VALUE =200;
    private static final int GIRAFFE_FOOD_VALUE = 100;
    private static final Random rand = Randomizer.getRandom();
    //The current age of a Lion
    private int age;
    //The current food level based on what they've eaten
    private int foodLevel;
    
    /**
     * This constructor creates a new Lion and adds it to the field at a 
     * set location.
     * @param randomAge true causes age to be randomly asigned otherwise 0
     * @param field The field to which the Lion will be added
     * @param location The coordinates within the field that the Lion will
     * be placed.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location, true, true);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CHEETAH_FOOD_VALUE + GIRAFFE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = CHEETAH_FOOD_VALUE +GIRAFFE_FOOD_VALUE;
        }
    }
    
    /**
     * This method is executed aas one step of the Lion's life. It is responsible
     * for incrementing the age and hunger and checking if breeding can happen
     * in addition to moving the Lion.
     * @param newLions The list of new Lions born.
     * @param hourOfDay The hour within the day so that we can check if the Lion
     * is asleep
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newLions, int hourOfDay, ArrayList<Class<?>> animals)
    {
        incrementAge();
        incrementHunger();
        if (isAlive() && canMove()) {
           
            if ((hourOfDay < 22 || hourOfDay >= 23) && isAsleep()) {
                return;
            }
            
            if (isFemale() && isNearbyMaleAnimals(Lion.class)) {
                giveBirth(newLions);  
            }
                       
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This method is responsible for making the Lion older and checking
     * it is not past the maximum age.
     */
    private void incrementAge()
    {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * This method decrements the foodLevel instance variable with each step.
     * This monitors whether a Lion is hungry and sets it to be dead of
     * hunger if necessary.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * This method checks the locations around the Lion for food so that the 
     * Lion can eat and increase its food level. It checks for Cheetahs or 
     * Girafes nearby and hunts them if it finds them.
     * @return where Location of prey.
     * @return null If no prey found.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Cheetah) {
                Cheetah cheetah = (Cheetah) animal;
                if (cheetah.isAlive()) { 
                    cheetah.setDead();
                    foodLevel = CHEETAH_FOOD_VALUE;
                    return where;
                }
            } else if (animal instanceof Giraffe) {
                Giraffe giraffe = (Giraffe) animal;
                if(giraffe.isAlive()) { 
                    giraffe.setDead();
                    foodLevel = GIRAFFE_FOOD_VALUE;
                    return where;
                }
            }
        }   
        return null;
    }
    
    /**
     * This method creates the new young if the Lions are able to breed. It
     * calls the breed method to check if breeding is possible and creates 
     * the correct number of young in a list.
     * @param newLions The list of new Lions.
     */
    private void giveBirth(List<Actor> newLions)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }
    
    /**
     * This method calculates the nunber of births that will be had by a Lion.
     * @reutrn The number of young to be born.
     */
    private int breed()
    {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * @return If the Lion is old enough to breed.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}