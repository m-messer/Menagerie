import java.util.List;
import java.util.Random;
import java.util.ArrayList;
/**
 * The plant class adds simulated plants to the project which rangers can 
 * lay and some animals can eat.
 *
 * @version March 2021
 */
public class Plant extends Drawable
{
    // instance variables
    private int age;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Creates a plant and sets it to be growing in a specific location
     * within the field.
     * @param field The field being simulated
     * @param location The location of this growth
     */
    public Plant(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * When the act method is triggered the age of the plant increments and it
     * grows.
     * 
     * @param the list of new actors 
     * @param the hour of day in simulation
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newActors, int hourOfDay, ArrayList<Class<?>> animals)
    {
        grow(newActors);
        age++;
    }
    
    /**
     * The plant randomly grows if active is set to be true.
     * @param newPlants list of new plants.
     */
    private void grow(List<Actor> newPlants)
    {
        Random rand = new Random();
        Field field = getField();
        if (isActive() && (rand.nextInt(2000) == 0)) {
            List<Location> adjacentSquares = field.getFreeAdjacentLocations(getLocation());
            while (adjacentSquares.size() > 0) {
                Location loc = adjacentSquares.remove(0);
                Plant newPlant = new Plant(field, loc);
                newPlants.add(newPlant);
            }
        }
    }
    
}