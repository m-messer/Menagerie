import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
/**
 * The Giraffe class simulates the actions of a Giraffe within the simulator.
 * It is a prey class hunted by lion.
 *
 * @version March 2021
 */
public class Giraffe extends Animal
{
    // The age at which a giraffe can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a giraffe can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a giraffe breeding
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The age of the Giraffe
    private int age;
    
    /**
     * This is the constructor method for the Giraffe class responsible for 
     * creating new instances of Giraffes with either a random age or starting
     * from 0.
     * @param randomAge If true, sets age to a random age.
     * @param field The field to which the Giraffe will be added.
     * @param location The coordinates within the field the Giraffe will be added to
     */
    public Giraffe(boolean randomAge, Field field, Location location)
    {
        super(field, location, true, true);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * The act method responsible implementing one step for the Giraffes in the
     * simulator. This increments the age of the Giraffe, moves the Giraffe and
     * triggers the reproduction process.
     * @param newGiraffes List of new young giraffes.
     * @param hourOfDay
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newGiraffes, int hourOfDay, ArrayList<Class<?>> animals)
    {
        incrementAge();
        
        if (isAlive() && canMove()) {
            if (isFemale() && isNearbyMaleAnimals(Giraffe.class)) {
                giveBirth(newGiraffes); 
            }
            
            Location  newLocation = getField().freeAdjacentLocation(getLocation());
            
            if (newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        } 
    }
    
    /**
     * This method adds 1 to the age in each step and sets the Giraffe as dead
     * if the maximum age is reached.
     */
    private void incrementAge()
    {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * This method is responsible for creating the new young of the giraffes.
     * @param newGiraffes the list of new giraffes to be added.
     */
    private void giveBirth(List<Actor> newGiraffes)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b<births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Giraffe young = new Giraffe(false, field, loc);
            newGiraffes.add(young);
        }
    }
    
    /**
     * @return births The number of offspring to be born in this step.
     */
    private int breed()
    {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        
        return births;
    }
    
    /**
     * @return true If the Giraffe is old enough to have young.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
