import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
/**
 * Model of the Hyena animal within the simulator.
 * Hyena move, breed and eat cheetahs and zebras
 *
 * @version March2021
 *
 */
public class Hyena extends Animal
{
    //This is the age at which a Hyena can begin breeding
    private static final int BREEDING_AGE = 3;
    //The maximum age before a Hyena dies of old age
    private static final int MAX_AGE = 90;
    //The probability that a Hyena has young
    private static final double BREEDING_PROBABILITY = 0.2;
    //The max number of children a Hyena can have in one step
    private static final int MAX_LITTER_SIZE = 2;
    
    //The respective food values of the Hyena's prey
    private static final int ZEBRA_FOOD_VALUE = 100;
    private static final int CHEETAH_FOOD_VALUE = 200;
    
    private static final Random rand = Randomizer.getRandom();
    //The Hyena's age
    private int age;
    //Monitors Hyena's hunger during simulation
    private int foodLevel;
 
    /**
     * This is the constructor for the Hyenas, responsible for creating new
     * instances of Hyenas with either a random age or starting from 0.
     * 
     * @param randomAge If true, a random age is set.
     * @param field The field in which the simulation is running.
     * @param location The location within the field the Hyena is created.
     */
    public Hyena(boolean randomAge, Field field, Location location)
    {
        super(field, location,true,true);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE + CHEETAH_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ZEBRA_FOOD_VALUE+CHEETAH_FOOD_VALUE;
        }
    }
    
    /**
     * The Hyena act method - responsible for implementing one step of simulation
     * for the Hyena animals active. This includes checking if they are sleeping
     * as well as incrementing hunger and age.
     * 
     * @param newHyenas Any new Hyenas born.
     * @param hourOfDay The time of day used to check sleeping.
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newHyenas,  int hourOfDay, ArrayList<Class<?>> animals)
    {
        incrementAge();
        incrementHunger();
        if (isAlive() && canMove()) {
            if ((hourOfDay < 22 || hourOfDay >= 23) && isAsleep()) {
                return;
            }
            
            // base task 3
            if (isFemale() && isNearbyMaleAnimals(Hyena.class)) {
                giveBirth(newHyenas);  
            }
            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This method increases the age of the Hyena and checks it is not too old
     * to die of old age.
     */
    private void incrementAge()
    {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * This method increases the hunger of the Hyena at each step and sets it
     * to die of hunger if there is no food supply.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * This method is responsible for checking if there are Zebra or Cheetah
     * animals next to the Hyena's so that the Hyena can prey on them.
     * @return where Location of prey.
     * @reutrn null If no prey nearby.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if (zebra.isAlive()) { 
                    zebra.setDead();
                    foodLevel = ZEBRA_FOOD_VALUE;
                    return where;
                }
            } else if (animal instanceof Cheetah) {
                Cheetah cheetah = (Cheetah) animal;
                if (cheetah.isAlive()) { 
                    cheetah.setDead();
                    foodLevel = CHEETAH_FOOD_VALUE;
                    return where;
                }  
            }
        }
        return null;
    }
        
    /**
     * This method is responsible for creating the new young of Hyenas and 
     * adding them to the field.
     * @param newHyenas A list of new animals given birht to.
     */
    private void giveBirth(List<Actor> newHyenas)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hyena young = new Hyena(false, field, loc);
            newHyenas.add(young);
        }
    }
    
    /**
     * @return number of births to happen in this instance.
     */
    private int breed()
    {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * @return true if Hyena is of the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}