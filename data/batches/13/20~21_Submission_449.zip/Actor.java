import java.util.List;
import java.util.ArrayList;
/**
 * The actor can act in the simulation but doesn't necessarily have to be
 * seen on the screen
 *
 * @version March 2021
 */
public interface Actor
{
    /**
     * The actor can act in simulation. E.g a hunter can shoot animals
     *
     * @param list of new actors incase they grow in numbers in simulation
     * @param the hour of day in simulation
     * @param the list of animals in simulation
     *
     */
    void act(List<Actor> newActors, int hourOfDay, ArrayList<Class<?>> animals);
    
    /**
     * The actor is alive or not alive
     *
     * @return true if actor is active
     *
     */
    boolean isActive();
}
