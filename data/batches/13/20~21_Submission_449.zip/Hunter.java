import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * A hunter can shoot animals that are nearby to them. 
 * Hunters can move around the simulation but there are a fixed number of hunters. Can hunt between 3am 
 * and 6pm.
 *
 * @version March 2021
 */
public class Hunter extends Drawable
{
    // No instance variables
    
    /**
     * Constructor for objects of class Hunter
     */
    public Hunter(Field field, Location location)
    {
        super(field,location);
    }
    
    /**
     * Hunter shoots animals between 3am and 6pm and can move around the field
     * 
     * @param the list of new actors that could breed
     * @param the hour of day in simulation
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newActors, int hourOfDay, ArrayList<Class<?>> animals) 
    {
        Random rand= new Random();
        
        // Between 3am and 6pm exclusive can shoot
        if ((hourOfDay > 3 || hourOfDay < 18)) {
            shootAnimal(animals.get(rand.nextInt(animals.size())));
        } else {
            return;
        }
        
        Location newLocation = getField().freeAdjacentLocation(getLocation()); 
            
        if (newLocation != null) {
            setLocation(newLocation);
        }
    }
    
    /**
     * Set the animals to be destroyed adjacent with specified distance to hunter
     * 
     * @param the random animal to be shot. 
     */
    protected void shootAnimal(Class<?> animalClass) 
    {
       int distanceFromCurrentPostion = 1;
       List<Animal> nearbyAnimal = findNearbyAnimals(animalClass, distanceFromCurrentPostion);
     
       // Hunter kills nearby animals
       nearbyAnimal.forEach(animals -> animals.setDead());
    }
}
