import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A class representing shared characteristics of animals.
 *
 * @version March 2021
 */
public abstract class Animal extends Drawable 
{
    private boolean isFemale;
    private boolean isAsleep;
    private static final Random random = new Random();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location,boolean randomGender, boolean randomBehaviour)
    {
        super(field,location);
        if (randomGender) {
            isFemale = random.nextBoolean(); 
        }
        
        if (randomBehaviour) {
            isAsleep = random.nextBoolean();
        }
    }
    
    /**
     * Check if animal is female
     * @return true if female
     */
    protected boolean isFemale() 
    {
        return isFemale;
    }
    
    /**
     * Check if animal is asleep
     * @return true if is asleep
     */
    protected boolean isAsleep() 
    {
        return isAsleep;
    }
    
    /**
     * Base Task 3: 
     * 
     * Check if there are male animals of same "type" near female 
     * 
     * @param the class associated with the female animal object 
     * @return true if female is nearby male animal of the same type
     *
     */
    protected boolean isNearbyMaleAnimals(Class<?> animalClass) 
    {
       int distanceFromCurrentPostion = 1;
       List<Animal> nearbyAnimal = findNearbyAnimals(animalClass, distanceFromCurrentPostion);
                                   
       nearbyAnimal.removeIf(animals -> animals.isFemale());
      
       if (!nearbyAnimal.isEmpty()) {
           return true; 
       } 
       return false;
    }
    
    /**
     * If weather conditions are perfect then animals can move
     * 
     * @return true so animal can move if raining probability is less than 0.95
     */
    protected boolean canMove()
    {
        Weather weather = new Weather();
        if (weather.getRainProbability() > 0.95) {
            return false;
        } else {
            return true;
        }
    }
}
