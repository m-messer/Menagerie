import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
/**
 * Model of the Cheetah animal within the simulator.
 * Cheetahs move, breed and are hunted by Lions, hyenas and eat plants
 *
 * @version March2021
 */
public class Cheetah extends Animal
{
    // The age at which a cheetah can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a cheetah can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a cheetah breeding.0.12, 0.3, 0.9
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    private static final int PLANT_FOOD_VALUE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //How many steps the animal has been around
    private int age;
    private int foodLevel;
    
    /**
     * Create a new Cheetah with a random or given age.
     * 
     * @param randomAge true means the age and hunger will be randomised.
     * @param field The field in which the animals are staying.
     * @param location The coordinates of an animal within the field.
     */
    public Cheetah(boolean randomAge, Field field, Location location)
    {
        super(field, location,true, true);
        
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * This method is implemented each time a step is made by the application.
     * The animal looks for food nearby or could die of hunger, overcrowding
     * or old age aswell as breeding young.
     * 
     * @param newCheetahs This is the list of new animals that will be born
     * @param hourOfDay
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newCheetahs, int hourOfDay, ArrayList<Class<?>> animals)
    {
        incrementAge();
        incrementHunger();
        if (isAlive() && canMove()) {
            
            if (isFemale() && isNearbyMaleAnimals(Cheetah.class)) {
                giveBirth(newCheetahs);  
            }   
            
            Location newLocation = eatPlants();
            if (newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This method increments the age.
     * If the max age is reached it is set to dead.
     */
    private void incrementAge()
    {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Decrease food level of cheetah
     */
    private void incrementHunger()
    {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * This method creates implements the creation of new Cheetahs to model
     * them breeding. It checks the locations for breeding and triggers 
     * the breed method.
     * 
     * @param newCheetahs The list of new Cheetahs given birth to.
     */
    private void giveBirth(List<Actor> newCheetahs)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cheetah young = new Cheetah(false, field, loc);
            newCheetahs.add(young);
        }
    }
    
    /**
     * This method takes the Breeding Probability and checks if the animal
     * can breed in order to give the number of births which will happen.
     * 
     * @return births The number of births to be executed.
     */
    private int breed()
    {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * This method allows the Cheetahs to eat plants in order to stop them
     * from becoming overgrown.
     * 
     * @return the location of the cheetah
     */
    private Location eatPlants()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if (plant instanceof Plant) {
                Plant currentPlant = (Plant) plant;
                if (currentPlant.isActive()) {
                    currentPlant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * @return true if the Cheetah is old enough to breed.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
