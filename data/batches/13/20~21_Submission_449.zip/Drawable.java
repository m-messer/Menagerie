import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.stream.Collectors;
/**
 * Drawable are actors which appears on the screen when simulation is run. 
 *
 * @version March 2021
 */
public abstract class Drawable implements Actor
{
    // Whether the actor is alive or not.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    private Location location;
    private static final Random random = new Random();
    /**
     * Create a new actor at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Drawable(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Check is actor is active in simulation
     * 
     * @return true if active
     */
    public boolean isActive() {
        return isAlive();
    }

    /**
     * Check whether the drawable actor is alive or not.
     * @return true if the actor is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the actor location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actors new location.
     */
    protected void setLocation(Location newLocation)
    {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Base Task 3: 
     * 
     * Get a list of nearby animals from a current position in the simulation
     * 
     * @param the class associated with the animal
     * @param the distance from current position
     * @return List of nearby animals relative to the current position in simulation
     *
     */
    protected List<Animal> findNearbyAnimals(Class<?> animalClass, int distanceFromCurrentPosition) 
    {
       List<Location> adjacentLocations = field.adjacentLocations(getLocation(), distanceFromCurrentPosition);
       
       // each location adjacent to animal may have an object
       List<Object> nearbyObjects = adjacentLocations.stream()
                                                     .map(location -> field.getObjectAt(location))
                                                     .filter(obj -> obj != null)
                                                     .collect(Collectors.toList());
       
       //Remove objects that are not animals and animals cannot mate with different type e.g a cheetah and giraffe
       nearbyObjects.removeIf(obj -> obj.getClass() != animalClass);     
       
       List<Animal> nearbyAnimals = nearbyObjects.stream()
                                                 .map(objects -> (Animal) objects)
                                                 .collect(Collectors.toList());
       
       return nearbyAnimals;
    }
    
}
