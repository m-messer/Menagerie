import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * Zebras are prey to other animals so have higher breeding rates in order
 * to survive. They move and reproduce within the simulator. Hunted by hyena
 *
 * @version March 2021
 */
public class Zebra extends Animal
{
    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a rabbit breeding.0.12, 0.3
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private int age;
    
    /**
     * Constructor for objects of class Zebra
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location, true, true);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * Zebra acts by only giving birth
     * 
     * @param the list of new actors that could breed
     * @param the hour of day in simulation
     * @param the list of the classes associated with the animals
     */
    public void act(List<Actor> newZebras, int hourOfDay, ArrayList<Class<?>> animals)
    {
        incrementAge();
        
        if (isAlive() && canMove()) {
            
            if (isFemale() && isNearbyMaleAnimals(Zebra.class)) {
                giveBirth(newZebras);
            } 
            
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            
            if (newLocation != null) {
                setLocation(newLocation);
            } 
            else {
                setDead();
            }
        }
    }
    
    /**
     * This increases the age of a Zebra and sets it to die of old age if
     * appropriate.
     */
    public void incrementAge()
    {
        age++;
        if (age>MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * This method creates the new young for Zebras as they are born as well
     * as checking the conditions for birth.
     * 
     * @param newZebras The list of new Zebras being born.
     */
    private void giveBirth(List<Actor> newZebras)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b<births && free.size()>0; b++) {
            Location loc = free.remove(0);
            Zebra young = new Zebra(false, field, loc);
            newZebras.add(young);
        }
    }
    
    /**
     * This method is responsible for checking the probability and calculating
     * the number of Zebras to be born during this step.
     * 
     * @return births The number of Zebras to be born.
     */
    private int breed()
    {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Check  if zebra can breed 
     * 
     * @return true If the Zebra has reached the minimum breeding age.
     */
    private boolean canBreed()
    {
        return age>=BREEDING_AGE;
    }
}
