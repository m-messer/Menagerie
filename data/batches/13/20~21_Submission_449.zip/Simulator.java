import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing lions, cheetah, hyenas, giraffe, zebra, hunters, rangers and plants
 *
 * @version March 2021
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    // The probability that an animal will be created in any given grid position.
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.05;
    private static final double ZEBRA_CREATION_PROBABILITY = 0.05;
    private static final double CHEETAH_CREATION_PROBABILITY = 0.1;
    private static final double HYENA_CREATION_PROBABILITY = 0.01;
    private static final double LION_CREATION_PROBABILITY = 0.01;
    private static final double HUNTER_CREATION_PROBABILITY = 0.001;
    private static final double RANGER_CREATION_PROBABILITY = 0.001;
    private static final double PLANT_CREATION_PROBABILITY = 0.001;
    
    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // List of animals in the field
    private ArrayList<Class<?>> animals;
    // base task 4: keep track of time of day
    private Time time; 
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if (width <= 40 || depth <= 40) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Giraffe.class, Color.ORANGE);
        view.setColor(Zebra.class, Color.BLUE);
        view.setColor(Lion.class, Color.BLACK);
        view.setColor(Hyena.class, Color.GREEN);
        view.setColor(Cheetah.class, Color.RED);
        view.setColor(Hunter.class, Color.YELLOW);
        view.setColor(Ranger.class, Color.PINK);
        view.setColor(Plant.class, Color.MAGENTA);
        
        animals = new ArrayList<>();
        time = new Time();
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            time.incrementMinute();
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * actor.
     */
    public void simulateOneStep()
    {
        step++;
        
        int hourOfDay = time.getHour();
        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all actors act.
        actors.forEach(actor -> actor.act(newActors, hourOfDay, animals));
        actors.removeIf(actor -> !actor.isActive());
        
        // Add the newly born actors to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Lion(true, field, location));
                    animals.add(Lion.class);
                }
                else if (rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Hyena(true, field, location));
                    animals.add(Hyena.class);
                }
                else if (rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Cheetah(true, field, location));
                    animals.add(Cheetah.class);
                }
                else if (rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Giraffe(true, field, location));
                    animals.add(Giraffe.class);
                }
                else if (rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Zebra(true, field, location));
                    animals.add(Zebra.class);
                }
                else if(rand.nextDouble() <= HUNTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Hunter(field, location));
                }
                else if (rand.nextDouble() <= RANGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Ranger(field, location));
                }
                else if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    actors.add(new Plant(field, location));
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
