import java.util.List;
import java.util.Iterator;
import java.util.Random;

//CHEETAH CLASS

public class Cheetah extends Animal
{
    // Characteristics shared by all cheetas (class variables).
    private static final int BREEDING_AGE = 15;
    public static int MAX_AGE = 40;
    public static double BREEDING_PROBABILITY = 0.3;
    private static final int MAX_LITTER_SIZE = 15;
    private static final int WOLF_FOOD_VALUE = 20;
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The fox's age.
    private int age;
    // The fox's food level, which is increased by eating rabbits.
    private int foodLevel;
    private boolean gender;
    private boolean isInfected;
    private double infectedProbability;
    private double spreadProbability;

 
    public Cheetah(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(WOLF_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = WOLF_FOOD_VALUE;
        }
        gender = rand.nextBoolean();//random gender
        //animals are not infected by default
        isInfected = false;
    }
    
  
    public void act(List<Animal> newCheetahs)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newCheetahs);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    //checks and infects some cheetas randomly during the first step
    public void checkInfected(List<Animal> newCheetahs){
        double infectedProbability = Math.random();
        if(infectedProbability < 0.02){
            BREEDING_PROBABILITY = 0.15;
            MAX_AGE = 30;
            isInfected = true;
        }
        
    }

  
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
  
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    private int getFoodValue(){
        return foodLevel;
    }
    
  
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(weatherCalculate().equals("fog")){//kill fox ONNLY when it is foggy as they hunt during foggy times
                if(animal instanceof Wolf) {
                    Wolf wolf = (Wolf) animal;
                    if(wolf.isAlive()) { 
                        wolf.setDead();
                        foodLevel = getFoodValue() + WOLF_FOOD_VALUE;
                        return where;
                    }
                }
            }
            
            //spreads disease to only cheetas and wolves if they are close
            double spreadProbability = Math.random();
            if(isInfected && spreadProbability<0.2){
                if(animal instanceof Cheetah) {
                    Cheetah cheetah = (Cheetah) animal;
                    cheetah.BREEDING_PROBABILITY = 0.15;
                    cheetah.MAX_AGE = 30;
                }
                else if(animal instanceof Wolf) {
                    Wolf wolf = (Wolf) animal;
                    wolf.BREEDING_PROBABILITY = 0.2;
                    wolf.MAX_AGE = 40;
                }
            }
        }
        return null;
    }
    
    
 
    private void giveBirth(List<Animal> newCheetahs)
    {
        // New cheetahs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cheetah young = new Cheetah(false, field, loc);
            newCheetahs.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && breedCheck()) {//breedcheck() used as a second condition to see if they can breed
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    private boolean breedCheck(){//check if they they can breed (opposite gender)
        Field field = getField();
        boolean breedBooleanReturn=false;
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cheetah) {//check if it is actually the same animal
                Cheetah cheetah = (Cheetah) animal;
                if(this.gender != cheetah.gender) { //check for opposite gender
                     breedBooleanReturn = true;
                     break;
                } else{
                     breedBooleanReturn= false;
                     break;
                }
            }
        }
        return breedBooleanReturn;
    }
    
    /**
     * A fox can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
