import java.util.List;
import java.util.Random;
import java.util.Iterator;

//GRASS CLASS

public class Grass extends Animal
{
    private static final int BREEDING_AGE = 2;
    private static int MAX_AGE = 5;
    private static double BREEDING_PROBABILITY = 0.15;
    private static final int MAX_LITTER_SIZE = 50;
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    private int age;

    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    public void act(List<Animal> newGrass)
    {
        rainAct();
        incrementAge();
        if(isAlive()) {
            giveBirth(newGrass);            
        }
    }
    
    //no disease spread through grass
    public void checkInfected(List<Animal> newGrass){
    }
    
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    private void giveBirth(List<Animal> newGrass)
    {
        // New grass are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
    
    //rain causes grass to grow at a faster rate
    public void rainAct()
    {
        if(weatherCalculate().equals("rain")){
            BREEDING_PROBABILITY = 0.2;
        }else{
            BREEDING_PROBABILITY = 0.15;
        }
    }
        
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}