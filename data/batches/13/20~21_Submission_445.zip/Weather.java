import java.util.*;

public class Weather
{
    // instance variables
    private List<String> myList;
    private static String selectedWeather; 
    private static String selectedWeatherReturn;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        //---- No need to init
    }

    //selecting the weather method
    public void weatherSelection(){
        List<String> climate = new ArrayList<>();//array list used to store the types of weather
        climate.add("rain");
        climate.add("sunny");
        climate.add("thunder");
        climate.add("fog");
        int index = new Random().nextInt(climate.size());//random int between the size of the list
        selectedWeather = climate.get(index);//index the list through the random number generated
        selectedWeatherReturn = selectedWeather;// assign new variable
        
        System.out.println("IT IS " + selectedWeather);//debug
        }
        
    public String weatherSelectionReturn(){
        return selectedWeatherReturn;//return the weather
    }
    }
 
