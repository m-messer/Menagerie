
public class Time
{
    // instance variables
    public static boolean isItDayFinal;
    public static boolean test;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        //-- Nothing to init
    }
    
    public boolean isItDaySimulatorReturn(boolean dayBooleanReturn){
        isItDayFinal = dayBooleanReturn;//assign variable
        //System.out.println("IsItDaySimulatorReturn is: " +isItDayFinal);
        return isItDayFinal;
    }
    
    public boolean isItDayReturn(){
        //System.out.println("On isItDayReturn() it is : "+isItDayFinal);
        return isItDayFinal;// return variable
    }
}
