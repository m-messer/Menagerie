import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;


/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Gophers and Wolfes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 140;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a Wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.07;
    // The probability that a gopher will be created in any given grid position.
    private static final double GOPHER_CREATION_PROBABILITY = 0.13;
    // The probability that a cheeta will be created in any given grid position.
    private static final double CHEETAH_CREATION_PROBABILITY = 0.05;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.6;
     // The probability that a cow will be created in any given grid position.
    private static final double COW_CREATION_PROBABILITY = 0.2;
    
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    private int stepTime;
    private boolean timeOfDay;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Gopher.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Cheetah.class, Color.RED);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Cow.class, Color.BLACK);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    public void runMiddleSimulation(){//used to test 20 steps
        simulate(20);
    }
        
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
        
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Wolf and Gopher.
     */
    public void simulateOneStep()
    {
        //weather changes every 24 steps
        if (step==0 || step%12==0){
            weatherSimulation();
        }
        
        step++;
        timeCalc();
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();    
        
        // Let all Animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if (!(step > 1)){
                animal.checkInfected(newAnimals);
            }
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born Wolfes and Gophers to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
        
        
    }
    
    Time time = new Time();
    Weather weather = new Weather();
    
    public void timeCalc(){
        //works out whether it's day or night
        stepTime = step/12;
        
        if ((stepTime&1)==1){
            System.out.println("night");
            timeOfDay = false;
            time.isItDaySimulatorReturn(timeOfDay);
        }
        else {
            System.out.println("day");
            timeOfDay= true;
            time.isItDaySimulatorReturn(timeOfDay);
            
        }
        //one step is one hour        
    }
    
    
    public void weatherSimulation(){
        weather.weatherSelection();
    }
  
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with Wolfes and Gophers.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= GOPHER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Gopher gopher = new Gopher(true, field, location);
                    animals.add(gopher);
                }
                else if (rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah = new Cheetah(true, field, location);
                    animals.add(cheetah);
                }
                else if (rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    animals.add(grass);
                }
                else if (rand.nextDouble() <= COW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cow cow = new Cow(true, field, location);
                    animals.add(cow);
                }
                // else leave the location empty.
            }
        }

    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
