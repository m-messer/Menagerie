import java.util.List;
import java.util.Iterator;
import java.util.Random;

//Rabbit Class

public class Gopher extends Animal
{
    private static final int BREEDING_AGE = 6;
    public static int MAX_AGE = 30;
    public static double BREEDING_PROBABILITY = 0.8;
    private static final int MAX_LITTER_SIZE = 15;
    private static final int GRASS_FOOD_VALUE = 10;
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    private int age;
    private int foodLevel;
    private boolean gender;
    private boolean isInfected;
    private double infectedProbability;
    private double spreadProbability;

    public Gopher(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
            
        }
        gender = rand.nextBoolean();//random gender
        //animals are not infected by default
        isInfected = false;
    }
    
    public void act(List<Animal> newGophers)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newGophers);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    //checks and infects some gophers randomly during the first step only
    public void checkInfected(List<Animal> newGophers){
        double infectedProbability = Math.random();
        if(infectedProbability < 0.01){
            BREEDING_PROBABILITY = 0.05;
            MAX_AGE = 20;
            isInfected = true;
        }
    }

    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    private int getFoodValue(){
        return foodLevel;
    }
    
    private Location findFood()// find food method
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Grass) { // check if it is actually the correct animal/plant
                Grass grass = (Grass) animal;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = getFoodValue()+GRASS_FOOD_VALUE;
                    return where;
                }
            }
            
            //spreads disease to only gophers and cows if they are close
            double spreadProbability = Math.random();
            if(isInfected && spreadProbability<0.2){
                if(animal instanceof Gopher) {
                    Gopher gopher = (Gopher) animal;
                    gopher.BREEDING_PROBABILITY = 0.05;
                    gopher.MAX_AGE = 20;
                }
                else if(animal instanceof Cow) {
                    Cow cow = (Cow) animal;
                    cow.BREEDING_PROBABILITY = 0.2;
                    cow.MAX_AGE = 30;
                }
            }
        }
        return null;
    }

    private void giveBirth(List<Animal> newGophers)
    {
        // New Gophers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Gopher young = new Gopher(false, field, loc);
            newGophers.add(young);
        }
    }
        
    private int breed()// breed method
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && breedCheck() ) {// && breedcheck() used as a second condition
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    private boolean breedCheck(){//check if they can breed (male/female)
        Field field = getField();
        boolean breedBooleanReturn=false;//return variable
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Gopher) {//check if it is the same animal first
                Gopher gopher = (Gopher) animal;
                if(this.gender != gopher.gender) { //check if it is the opposite gender
                     breedBooleanReturn = true;
                     break;
                } else{
                     breedBooleanReturn= false;
                     break;
                }
            }
        }
        return breedBooleanReturn;
    }

    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
}