/**
 * Enumeration class Weather - Defines the different values the weather can take, 
 * which will later be randomly chosen following a uniform distribution
 *
 * @version 1.0
 */
public enum Weather
{
    SUNNY,
    SNOW,
    RAIN,
    CLOUD
}
