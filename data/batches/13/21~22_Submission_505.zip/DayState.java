/**
 * Enumeration class DayState - The different state of the days
 *
 * @version 1.0
 */
public enum DayState
{
    DAYLIGHT,
    NIGHT,
}
