
/**
 * Enumeration class Gender - Defines the values an animal gender can take
 *
 * @version 1.0
 */
public enum Gender
{
    FEMALE,
    MALE
}
