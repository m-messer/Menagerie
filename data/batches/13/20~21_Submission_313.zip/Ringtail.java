import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
/**
 * A simple model of a ringtail.
 * Ringtails age, move, breed, and die.
 *
 * @version1.0 2021.02.27
 */
public class Ringtail extends Animal
{
    // Characteristics shared by all ringtails (class variables).

    // The age at which a ringtail can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a ringtail can live.
    private static final int MAX_AGE = 65;
    // The likelihood of a ringtail breeding.
    private static final double BREEDING_PROBABILITY = 0.82;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum food level a ringtail can have.
    private static final int MAX_FOOD_LEVEL = 6;
    // When food value is lower the minimum food value, it can eat again.
    private static final int MIN_FOOD_LEVEL = 3;
    // The active time for a ringtail is night.
    private static final boolean ACTIVE_AT_NIGHT = true;
    // The type of animal the ringtail eats and the food value of that animal.
    private static final HashMap<Class, Integer> FOOD_VALUES = new HashMap<>();
    
    /**
     * Create a ringtail. A ringtail can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the ringtail will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Ringtail(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        // The food level a ringtail can get when it eats a rat.
        FOOD_VALUES.put(Rat.class, 6);
        isPredator = true;
    }
        
    /**
     * @return the breeding probability of the ringtail.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age a ringtail can live.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probabilitu of the ringtail.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the maximum number of births.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the maximum food level of a ringtail.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return the minimum food level of a ringtail.
     */
    public int getMinFoodLevel()
    {
        return MIN_FOOD_LEVEL;
    }
    
    /**
     * @return the active time of the ringtail.
     */
    public boolean getActiveTime()
    {
        return ACTIVE_AT_NIGHT;
    }
    
    /**
     * @return the type of food the ringtail eats and the food value of it.
     */
    public HashMap<Class, Integer> getFoodValues()
    {
        return FOOD_VALUES;
    }
    
    /**
     * Creates a ringtail offspring.
     * @param randomAge If true, the animal will be born with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @return a newBorn ringtail.
     */
    public Animal createYoung(boolean randomAge, Field field, Location loc)
    {
        Animal newAnimal = new Ringtail(randomAge, field, loc);
        setDisease(Simulator.BORN_WITH_DISEASE_PROBABILITY);
        return newAnimal;
    }    
}
