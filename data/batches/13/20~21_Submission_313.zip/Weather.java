import java.util.Random;
/**
 * A simple model of the weather.
 *
 * @version1.0 2021.02.27
 */
public class Weather
{
    // Whether it is rainning right now.
    private boolean isRainy;
    // Whether it is foggy right now.
    private boolean isFoggy;
    // The probability of a rainy day.
    private double rainyProbability;
    // The probability of a foggy day.
    private double foggyProbability;
    // The default probability of a rainy day.
    private static final double DEFAULT_RAINY_PROBABILITY = 0.08;
    // The default probability of a foggy day.
    private static final double DEFAULT_FOGGY_PROBABILITY = 0.04;
    /**
     * Constructor of objects of class Weather with default values.
     */
    public Weather()
    {
        this(DEFAULT_RAINY_PROBABILITY, DEFAULT_FOGGY_PROBABILITY);
    }

    /**
     * Set the probability for the weather.
     * @param rainyProbability the rainy probability for the simulation.
     * @param foggyProbability the foggy probability for the simulation.
     */
    public Weather(double rainyProbability, double foggyProbability)
    {
        this.rainyProbability = rainyProbability;
        this.foggyProbability = foggyProbability;
    }
    
    /**
     * @return the default rainy probability
     */
    public static double getDefaultRainyProbability(){
        return DEFAULT_RAINY_PROBABILITY;
    }
    
    /**
     * @return the default foggy probability
     */
    public static double getDefaultFoggyProbability(){
        return DEFAULT_FOGGY_PROBABILITY;
    }
    
    /**
     * Set the weather to rainy.
     */
    public void setRainy(){
        Random rand = Randomizer.getRandom();
        if(rand.nextDouble() <= rainyProbability){
            isRainy = true;
        }else{
            isRainy = false;
        }        
    }
    
    /**
     * @return whether the weather is rainy.
     */
    public boolean getIsRainy(){
        if(isRainy){
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * @return the string for whether it is rainy or sunny.
     */
    public String getIsRainyString(){
        if(isRainy){
            return "Rainy";
        }else{
            return "Sunny";
        }
    }
    
    /**
     * Set the weather to foggy
     */
    public void setFoggy(){
        Random rand = Randomizer.getRandom();
        if(rand.nextDouble() <= foggyProbability){
            isFoggy = true;
        }else{
            isFoggy = false;
        }  
    }
    
    /**
     * @return whether the weather is foggy.
     */
    public boolean getIsFoggy(){
        if(isFoggy){
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * @return the string for whether it is foggy or clear.
     */
    public String getIsFoggyString(){
        if(isFoggy){
            return "Foggy";
        }else{
            return "Clear";
        }
    }
}
