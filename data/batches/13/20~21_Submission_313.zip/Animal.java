import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.HashMap;
/**
 * A class representing shared characteristics of animals.
 *
 * @version1.0 2021.02.27
 */
public abstract class Animal
{
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's age.
    protected int age;
    // The animal's food level.
    protected double foodLevel;
    // The animal's gender.
    protected boolean isFemale;
    // Whether this animal is a predator.
    protected boolean isPredator;
    // Whether this animal has disease.
    protected boolean hasDisease;

    /**
     * Create a new animal at location in field.
     * An animal may be created with age zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the animal will be born with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);

        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(getMaxFoodLevel()+1);
        }
        else {
            age = 0;
            foodLevel = getMaxFoodLevel();
        }

        // the probabilities for creating a female and a male are equal.
        int x = new Random().nextInt(2);
        if(x == 0){
            isFemale = false;
        }else{
            isFemale = true;
        }
    }

    /**
     * @return the breeding age of the animal.
     */
    abstract public int getBreedingAge();

    /**
     * @return the maximum age of the animal.
     */
    abstract public int getMaxAge();

    /**
     * @return the breeding probability of the animal.
     */
    abstract public double getBreedingProbability();

    /**
     * @return the maximum number of births.
     */
    abstract public int getMaxLitterSize();

    /**
     * @return the type of food the animal eats and the food value of it.
     */
    abstract public HashMap<Class, Integer> getFoodValues();

    /**
     * @return the maximum food level of the animal.
     */
    abstract public int getMaxFoodLevel();

    /**
     * @return the minimum food level of the animal.
     */
    abstract public int getMinFoodLevel();

    /**
     * @return the active time of the animal.
     */
    abstract public boolean getActiveTime();

    /**
     * @return the current food level of the animal.
     */
    public double getFoodLevel(){
        return foodLevel;
    }

    /**
     * @return the gender of the animal.
     * True if it is a female, false if it is a male.
     */
    public boolean getGenderFemale(){
        return isFemale;
    }

    /**
     * Set the healthy animal to sick.
     * If the animal has the disease, it will be 5 steps older, 
     * and the current food level will decrease by 3.
     * 
     * @param diseaseProbability The probability that the animal will be infected.
     */
    public void setDisease(double diseaseProbability){
        if(rand.nextDouble() <= diseaseProbability){
            hasDisease = true;
            age += 5;
            foodLevel -= 3;
        }
    }

    /**
     * Cure the sick animal.
     */
    public void cureDisease(){
        if(rand.nextDouble() <= Simulator.DISEASE_CURING_PROBABILITY){
            hasDisease = false;
        }
    }

    /**
     * @return whether this animal has disease.
     */
    public boolean getDisease(){
        return hasDisease;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param time The time of the simulator, true if it is day.
     * @param newAnimals A list to receive newly born animals.
     * @param isFoggy The fogginess of the field, true if it is foggy.
     */
    public void act(boolean time, List<Animal> newAnimals, boolean isFoggy)
    {
        incrementAge();

        // The animal can act only when the current time is its active time.
        if((getActiveTime() && time) || (!getActiveTime() &&! time)){
            incrementHunger(1.0);
            if(isAlive()) {               
                // If it it not foggy, the animal can meet and give birth to new animals.      
                if(!isFoggy){
                    meet(newAnimals);   
                }

                // If the animal is sick, it can be cured.
                if(hasDisease){
                    cureDisease();
                }

                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }else{
            incrementHunger(0.1); // When the animal is sleeping, the food level will decrease by 0.1.
        }
    }

    /**
     * Increment the age of the animal. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     * @param num The number of food level that decreases in each step.
     */
    private void incrementHunger(double num)
    {
        foodLevel -= num;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first live animal or the nearest plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        if(isPredator && foodLevel < getMinFoodLevel()){
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()){
                Location where = it.next();           
                Object object = field.getObjectAt(where);
                if(object != null){
                    Animal animal = (Animal) object;            
                    for(Class className: getFoodValues().keySet()){  
                        if(animal.getClass().equals(className) && animal.isAlive()){
                            animal.setDead();
                            foodLevel += getFoodValues().get(className);
                            if(foodLevel > getMaxFoodLevel()){
                                foodLevel = getMaxFoodLevel();
                            }
                            return where;
                        }
                    }
                } 

            }
        }// find food method for herbivores
        else if(!isPredator && foodLevel < getMinFoodLevel()){
            Object object = field.getObjectAt(location.getRow(), location.getCol(), field.getPlantLayer());
            if(object != null){
                Plant plant = (Plant) object;
                for(Class className: getFoodValues().keySet()){
                    if(plant.getClass().equals(className) && plant.getHeight() > 10) { 
                        plant.getShorter(10);                  
                        foodLevel += getFoodValues().get(className);
                        if(foodLevel > getMaxFoodLevel()){
                            foodLevel = getMaxFoodLevel();
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Disease can be spread when animals meet.
     * Look for the same type of animal adjacent to the current location to breed. 
     * @param newAnimals A list that will contain new animals 
     */
    public void meet(List<Animal> newAnimals)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if(object != null && !(object instanceof Plant)){
                Animal animal = (Animal) object;
                // Spread disease.
                if(hasDisease && !animal.hasDisease){
                    animal.setDisease(Simulator.DISEASE_SPREADING_PROBABILITY);
                }
                // Try to find a mate.
                if(getClass().equals(animal.getClass()) && (getGenderFemale() != animal.getGenderFemale())
                && canBreed() && animal.canBreed()){                
                    giveBirth(newAnimals);                    
                }
            }
        }
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = createYoung(false, field, loc);
            newAnimals.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Creates a new young animal
     * @param randomAge If true, the animal will be born with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    abstract public Animal createYoung(boolean randomAge, Field field, Location loc);

    /**
     * An animal can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.placeAnimal(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

}
