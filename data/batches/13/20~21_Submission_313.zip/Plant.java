import java.util.Random;
import java.util.List;
/**
 * A simple model of a Plant.
 * Plants can grow and can be eaten by preys.
 *
 * @version1.0 2021.02.27
 */
abstract public class Plant
{
    // A plant grows 5cm a a time.
    private static final int growth_rate = 20;
    // The maximum height for the plant is 100cm.
    private static final int MAX_HEIGHT = 100;
    // A plant is considered tall if it is at least 90 cm tall.
    private static final int TALL_HEIGHT = 90;
    // The maximum age for the plant is 100.
    protected static final int MAX_AGE = 50;
    // The new plant creation probability
    protected static final double NEW_PLANT_PROBABILITY = 0.02;
    // A shared random number generator to control initial height.
    protected static final Random rand = Randomizer.getRandom();

    // The current height of the plant.
    private int height;
    // The current age of the plant.
    private int age;
    // The status if the plant is alive.
    private boolean alive;
    // The plant's field.
    protected Field field;
    // The plant's location.
    private Location location;

    /**
     * Constructor for objects of class Plant
     * @param randomHeight If true, the plant will be born with a random height.
     * @param field The field currently occupied.
     * @param loc The location within the field.
     */
    public Plant(boolean randomHeight, Field field, Location loc)
    {
        alive = true;
        this.field = field;
        setLocation(loc);
        if(randomHeight) {
            age = rand.nextInt(getMaxAge());
            height = rand.nextInt(getMaxHeight());
        }
        else {
            age = 0;
            height = getMaxHeight();
        }
    }

    /**
     * Increase the plant height when it is raining.
     * @param isRainy True if the weather is rainy.
     */
    public void grow(boolean isRainy){
        if(isRainy){
            height += growth_rate;
        }       
    }

    /**
     * Increment the age of the plant. This could result in the plant's death.
     */
    public void incrementAge(){
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.placePlant(this, newLocation);
    }

    /**
     * When a plant is eaten, it will get shorter.
     * @param cutHeight The plant's length that the herbivore eats.
     */
    public void getShorter(int cutHeight){
        height -= cutHeight;
        if(height == 0){
            setDead();
        }
    }

    /**
     * @return the maximum height that a plant can grow.
     */
    private int getMaxHeight(){
        return MAX_HEIGHT;
    }

    /**
     * @return the current height of this plant.
     */
    public int getHeight(){
        return height;
    }

    /**
     * @return the height that is considered tall for a plant.
     */
    public int getTallHeight(){
        return TALL_HEIGHT;
    }
    
    /**
     * @return the maximum age of a plant.
     */
    private int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * @return the current age of this plant.
     */
    public int getAge(){
        return age;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;        
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * @return The plant's location.
     */
    protected Location getLocation(){
        return location;
    }
    
    /**
     * @return True if the plant is alive.
     */
    protected boolean isAlive(){
        return alive;
    }
    
    /**
     * Creates new plants at adjacent locations.
     * @param newPlants The lists that contains new plants
     */
    abstract protected void growNew(List<Plant> newPlants);
}
