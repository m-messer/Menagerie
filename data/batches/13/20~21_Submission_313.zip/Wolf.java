import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
/**
 * A simple model of a wolf.
 * Wolves age, move, breed, and die.
 *
 * @version1 2021.02.27
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).

    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.75;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The maximum food level a wolf can have.
    private static final int MAX_FOOD_LEVEL = 6;
    // When food value is lower the minimum food value, it can eat again.
    private static final int MIN_FOOD_LEVEL = 2;
    // The active time for a wolf is night.
    private static final boolean ACTIVE_AT_NIGHT = true;
    // The type of animal the wolf eats and the food value of that animal.
    private static final HashMap<Class, Integer> FOOD_VALUES = new HashMap<>();
    
    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        FOOD_VALUES.put(Ringtail.class, 5);
        //FOOD_VALUES.put(Deer.class, 6);
        FOOD_VALUES.put(Rat.class, 5);
        isPredator = true;
    }   
        
    /**
     * @return the breeding probability of the wolf.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age a wolf can live.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of the wolf.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the maximum number of births.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the maximum food level of a wolf.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return the minimum food level of a wolf.
     */
    public int getMinFoodLevel()
    {
        return MIN_FOOD_LEVEL;
    }
    
    /**
     * @return the active time of the wolf.
     */
    public boolean getActiveTime()
    {
        return ACTIVE_AT_NIGHT;
    }
    
    /**
     * @return the type of food the wolf eats and the food value of it.
     */
    public HashMap<Class, Integer> getFoodValues()
    {
        return FOOD_VALUES;
    }
    
    /**
     * Create a wolf offspring
     * @param randomAge If true, the animal will be born with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @return a newBorn wolf.
     */
    public Animal createYoung(boolean randomAge, Field field, Location loc)
    {
        Animal newAnimal = new Wolf(randomAge, field, loc);
        setDisease(Simulator.BORN_WITH_DISEASE_PROBABILITY);
        return newAnimal;
    }    
}
