import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
/**
 * A simple model of a rat.
 * Rats age, move, breed, and die.
 *
 * @version1.0 2021.02.27
 */
public class Rat extends Animal
{
    // Characteristics shared by all rats (class variables).

    // The age at which a rat can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a rat can live.
    private static final int MAX_AGE = 8;
    // The likelihood of a rat breeding.
    private static final double BREEDING_PROBABILITY = 0.87;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum food level a rat can have.
    private static final int MAX_FOOD_LEVEL = 6;
    // When food value is lower the minimum food value, it can eat again.
    private static final int MIN_FOOD_LEVEL = 3;
    // The active time for a rat is night.
    private static final boolean ACTIVE_AT_NIGHT = true;
    // The type of plant the rat eats and the food value of that plant.
    private static final HashMap<Class, Integer> FOOD_VALUES = new HashMap<>();
    
    /**
     * Create a new rat. A rat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rat(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
        FOOD_VALUES.put(PlantR.class, 3);
        isPredator = false;
    }
    
    /**
     * @return the breeding probability of the rat.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age a rat can live.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of the rat.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the maximum number of births.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the maximum food level of a rat.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return the minimum food level of a rat.
     */
    public int getMinFoodLevel()
    {
        return MIN_FOOD_LEVEL;
    }
    
    /**
     * @return the active time of the rat.
     */
    public boolean getActiveTime()
    {
        return ACTIVE_AT_NIGHT;
    }
    
    /**
     * @return the type of food the rat eats and the food value of it.
     */
    public HashMap<Class, Integer> getFoodValues()
    {
        return FOOD_VALUES;
    }
    
    /**
     * Create a rat offspring.
     * @param randomAge If true, the animal will be born with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @return a newBorn rat.
     */
    public Animal createYoung(boolean randomAge, Field field, Location loc)
    {
        Animal newAnimal = new Rat(randomAge, field, loc);
        setDisease(Simulator.BORN_WITH_DISEASE_PROBABILITY);
        return newAnimal;
    }    
}
