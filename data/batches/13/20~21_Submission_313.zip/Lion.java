import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
/**
 * A simple model of a lion.
 * Lions age, move, breed, and die.
 *
 * @version1.0 2021.02.27
 */
public class Lion extends Animal
{   
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a lion can live.
    private static final int MAX_AGE = 55;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.75;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The maximum food level a lion can have.
    private static final int MAX_FOOD_LEVEL = 6;
    // When food value is lower the minimum food value, it can eat again.
    private static final int MIN_FOOD_LEVEL = 3;
    // The active time for a lion is day.
    private static final boolean ACTIVE_AT_NIGHT = false;
    // The type of animal the lion eats and the food value of that animal.
    private static final HashMap<Class, Integer> FOOD_VALUES = new HashMap<>();
    
    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        FOOD_VALUES.put(Deer.class, 6);
        FOOD_VALUES.put(Ringtail.class, 6);
        //FOOD_VALUES.put(Rat.class, 30);
        //FOOD_VALUES.put(Wolf.class, 6);
        isPredator = true;
    }
        
    /**
     * @return the breeding probability of the lion.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age a lion can live.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of the lion.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the maximum number of births.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the maximum food level of a lion.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return the minimum food level of a lion.
     */
    public int getMinFoodLevel()
    {
        return MIN_FOOD_LEVEL;
    }
    
    /**
     * @return the active time of the lion.
     */
    public boolean getActiveTime()
    {
        return ACTIVE_AT_NIGHT;
    }
    
    /**
     * @return the type of food the lion eats and the food value of it.
     */
    public HashMap<Class, Integer> getFoodValues()
    {
        return FOOD_VALUES;
    }
    
    /**
     * Create a lion offspring
     * @param randomAge If true, the animal will be born with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @return a newBorn lion.
     */
    public Animal createYoung(boolean randomAge, Field field, Location loc)
    {
        Animal newAnimal = new Lion(randomAge, field, loc);
        setDisease(Simulator.BORN_WITH_DISEASE_PROBABILITY);
        return newAnimal;
    }    
}
