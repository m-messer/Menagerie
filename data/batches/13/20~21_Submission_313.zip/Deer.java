import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
/**
 * A simple model of a deer.
 * Deer age, move, breed, and die.
 *
 * @version1.0 2021.02.27
 */
public class Deer extends Animal
{
    // Characteristics shared by all deers (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a deer can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.95;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum food level a deer can have
    private static final int MAX_FOOD_LEVEL = 6;
    // The active time for a deer is day.
    // When food value is lower the minimum food value, it can eat again.
    private static final int MIN_FOOD_LEVEL = 6;
    private static final boolean ACTIVE_AT_NIGHT = false;
    // The type of plant the deer eats and the food value of that plant.
    private static final HashMap<Class, Integer> FOOD_VALUES = new HashMap<>();
    
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field, location);
        FOOD_VALUES.put(PlantD.class, 3);
        isPredator = false;
    }
       
    /**
     * @return the breeding probability of the deer.
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age a deer can live.
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of the deer.
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * @return the maximum number of births.
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the maximum food level of a deer.
     */
    public int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return the minimum food level of a deer.
     */
    public int getMinFoodLevel()
    {
        return MIN_FOOD_LEVEL;
    }
    
    /**
     * @return the active time of the deer.
     */
    public boolean getActiveTime()
    {
        return ACTIVE_AT_NIGHT;
    }
    
    /**
     * return the type of food the deer eats and the food value of it.
     */
    public HashMap<Class, Integer> getFoodValues()
    {
        return FOOD_VALUES;
    }
    
    /**
     * Creates a deer offspring.
     * @param randomAge If true, the animal will be born with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @return a newBorn deer.
     */
    public Animal createYoung(boolean randomAge, Field field, Location loc)
    {
        Animal newAnimal = new Deer(randomAge, field, loc);
        setDisease(Simulator.BORN_WITH_DISEASE_PROBABILITY);
        return newAnimal;
    }    
    
}
