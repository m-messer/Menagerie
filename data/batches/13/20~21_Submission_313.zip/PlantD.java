import java.util.List;
import java.util.Random;
/**
 * A simple model of a PlantD.
 * PlantD can only be eaten by deer.
 *
 * @version1.0 2021.02.27
 */
public class PlantD extends Plant
{
    /**
     * Constructor for objects of class PlantD
     * @param randomHeight If true, the plantD will be born with a random height.
     * @param field The field currently occupied.
     * @param loc The location within the field.
     */
    public PlantD(boolean randomHeight, Field field, Location loc)
    {
        super(randomHeight, field, loc);
    }
    
    /**
     * Create new plants at the adjacent location in the field.
     * @param newPlants A list that contains new plants.
     */
    protected void growNew(List<Plant> newPlants){
        if(rand.nextDouble() <= NEW_PLANT_PROBABILITY) {
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            if(free.size() > 0){
                Location loc = free.remove(0);
                PlantD plantD = new PlantD(false, field, loc);
                newPlants.add(plantD);
            }
        }
    }
}

