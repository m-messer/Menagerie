import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rats, deer, ringtails, lions and wolves.
 *
 * @version1.0 2021.02.27
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a ringtail will be created in any given grid position.
    private static final double RINGTAIL_CREATION_PROBABILITY = 0.15;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.13;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.11;
    // The probability that a rat will be created in any given grid position.
    private static final double RAT_CREATION_PROBABILITY = 0.25;  
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.35;   
    // The probability that a plant will be created in any given grid position.
    private static final double PLANTR_CREATION_PROBABILITY = 0.2;
    private static final double PLANTD_CREATION_PROBABILITY = 0.2;
    // The born with disease probability for all the animals.
    public static final double BORN_WITH_DISEASE_PROBABILITY = 0.01;
    // The disease spreading probability for all the animals.
    public static final double DISEASE_SPREADING_PROBABILITY = 0.02;
    // The disease curing probability for all the animals.
    public static final double DISEASE_CURING_PROBABILITY = 0.05;
    // List of animals in the field.
    private List<Animal> animals;
    // List of sick animals in the field.
    protected List<Animal> sickAnimals;
    // List of animals in the field.
    private List<Plant> plants;
    // Number of tall plant in the field.
    private int tallPlantCount;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // Number of steps half of a day has.
    private int halfDay = 5;
    // Whether the current time is night.
    private boolean isNight = false;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The weather of the field.
    private Weather weather;

    /**
     * Construct a simulation field with default size, raining probability and foggy probability.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH,
            Weather.getDefaultRainyProbability(), Weather.getDefaultFoggyProbability());
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * @param rainyProbability The probability that the rain will fall in each step.
     * @param foggyProbability The probability that the fog will occur in each step.
     */
    public Simulator(int depth, int width, double rainyProbability, double foggyProbability)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        sickAnimals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather(rainyProbability, foggyProbability);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rat.class, Color.ORANGE);
        view.setColor(Ringtail.class, Color.BLUE);
        view.setColor(Wolf.class, Color.CYAN);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Deer.class, Color.PINK);
        view.setColor(PlantR.class, Color.GREEN);
        view.setColor(PlantD.class, Color.GRAY);

        //Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(100);   // uncomment this to run more slowly
        }
    }    

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal and each plant.
     */
    public void simulateOneStep()
    {
        step++;
        weather.setRainy();
        weather.setFoggy();
        setTime();
        tallPlantCount = 0;
        sickAnimals.clear();

        // Provide space for newborn plants.
        List<Plant> newPlants = new ArrayList<>();        
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            if(plant.isAlive()) {
                plant.grow(weather.getIsRainy());
                if(plant.getClass().equals(PlantR.class)){
                    PlantR plantR = (PlantR) plant;
                    plantR.growNew(newPlants);
                }else{
                    PlantD plantD = (PlantD) plant;
                    plantD.growNew(newPlants);
                }
                plant.incrementAge();
                if(plant.getHeight() >= plant.getTallHeight()){
                    tallPlantCount++;                   
                }               
            }else{
                it.remove();    
            }
        }
 
        // Add the newly born animals to the main lists.
        plants.addAll(newPlants);

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            //animal.setDisease();
            animal.act(getTime(), newAnimals, weather.getIsFoggy());

            if(animal.getDisease()){
                sickAnimals.add(animal);
            }

            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field, getTimeString(), weather.getIsRainyString(), 
            weather.getIsFoggyString(), sickAnimals.size(), tallPlantCount);
    }

    /**
     * one day has 4 steps.
     * If the number of steps is even, it is night.
     * If the number of steps is odd, it is day.
     */
    private void setTime(){
        int num = step / halfDay;  
        if(num % 2 == 0){
            isNight = false; 
        }else{
            isNight = true;
        }
    }

    /**
     * @return whether the current time is night.
     */
    private boolean getTime(){
        return isNight;
    }

    /**
     * @return the string of the current time.
     */
    private String getTimeString(){
        if(isNight){
            return "night";    
        }else{
            return "day";
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        tallPlantCount = 0;
        animals.clear();
        sickAnimals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, getTimeString(), weather.getIsRainyString(), 
            weather.getIsFoggyString(), sickAnimals.size(), tallPlantCount);
    }

    /**
     * Randomly populate the field with ringtails, wolves, lions,rats,deer and plants
     * in the beginning of the simulator.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();        
        field.clear();
        // Populate the field with animals.
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) { 
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, field.getAnimalLayer());
                    Lion lion = new Lion(true, field, location);
                    lion.setDisease(BORN_WITH_DISEASE_PROBABILITY);
                    lion.getDisease();
                    if(lion.getDisease()){
                        sickAnimals.add(lion);
                    }
                    animals.add(lion);
                }

                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, field.getAnimalLayer());
                    Wolf wolf = new Wolf(true, field, location);
                    wolf.setDisease(BORN_WITH_DISEASE_PROBABILITY);
                    wolf.getDisease();
                    if(wolf.getDisease()){
                        sickAnimals.add(wolf);
                    }
                    animals.add(wolf);
                }

                else if(rand.nextDouble() <= RINGTAIL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, field.getAnimalLayer());
                    Ringtail ringtail = new Ringtail(true, field, location);
                    ringtail.setDisease(BORN_WITH_DISEASE_PROBABILITY);
                    if(ringtail.getDisease()){
                        sickAnimals.add(ringtail);
                    }
                    animals.add(ringtail);
                }

                else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, field.getAnimalLayer());
                    Rat rat = new Rat(true, field, location);
                    rat.setDisease(BORN_WITH_DISEASE_PROBABILITY);
                    if(rat.getDisease()){
                        sickAnimals.add(rat);
                    }
                    animals.add(rat);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, field.getAnimalLayer());
                    Deer deer = new Deer(true, field, location);
                    deer.setDisease(BORN_WITH_DISEASE_PROBABILITY);
                    if(deer.getDisease()){
                        sickAnimals.add(deer);
                    }
                    animals.add(deer);
                }

                // else leave the location empty.
            }
        }

        // Populate the field with plants.
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) { 
                if(rand.nextDouble() <= PLANTR_CREATION_PROBABILITY){
                    Location location = new Location(row, col, field.getPlantLayer());
                    PlantR plantR = new PlantR(true, field, location);
                    plants.add(plantR);
                    if(plantR.getHeight() >= plantR.getTallHeight()){
                        tallPlantCount ++;
                    }
                }

                else if(rand.nextDouble() <= PLANTD_CREATION_PROBABILITY){
                    Location location = new Location(row, col, field.getPlantLayer());
                    PlantD plantD = new PlantD(true, field, location);
                    plants.add(plantD);
                    if(plantD.getHeight() >= plantD.getTallHeight()){
                        tallPlantCount ++;
                    }
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            //wake up
        }
    }
}
