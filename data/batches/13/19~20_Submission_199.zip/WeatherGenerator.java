import java.util.ArrayList;
import java.util.Random;

/**
 * A class that is used to generate the weather within the simulation
 *
 * @version 2020.02.21
 */

public class WeatherGenerator
{
    protected String weathertype;
    protected ArrayList<String> weatherlist = new ArrayList<String>();
    private Random rand = new Random();

    public WeatherGenerator() {
        weatherlist.add("Rain");
        weatherlist.add("Sunny");
        weatherlist.add("Foggy");
    }

    /**
     * Decides the weather within the simulation. Should only be used at the start of a new day.
     */
    public void decideWeather() {
        weathertype = weatherlist.get(rand.nextInt(weatherlist.size()));
    }


    /**
     * Returns the current weather within the simulation
     */
    public String getWeather() {
        return weathertype;
    }
}
