 


/**
 * This class is an abstract Prey class to provide a better inheritance structure
 * for added prey-specific functionality.
 * @version 20.02.2020
 */
public abstract class Prey extends Animal {
    public Prey(boolean randomAge, Field field, Location location) {
        super(field, location);

    }


}
