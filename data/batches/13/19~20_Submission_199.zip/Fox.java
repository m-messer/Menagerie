import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a fox. Foxes age, move, eat rabbits, and die.
 *
 * @version 2020.02.20
 */
public class Fox extends Predator {

    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a fox can live.
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int FOX_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The fox's age.
    private int age;
    // The fox's food level, which is increased by eating rabbits.


    /**
     * Create a fox. A fox can be created as a new born (age zero and not hungry) or
     * with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location) {
        super(field, location);
        this.MAX_AGE = 502;
        age = 0;
        this.foodLevel = 10;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOX_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = FOX_FOOD_VALUE;
        }
    }

    /**
     * Look for rabbits adjacent to the current location. Only the first live rabbit
     * is eaten.
     * Fox only hunts during daytime.
     * @param newPredator list of new animals made.
     * @param weatherGenerator field's weather
     * @return Where food was found, or null if it wasn't.
     */

    public void act(List<Organism> newPredator, WeatherGenerator weatherGenerator) {
        if (isAlive()) {
            giveBirth(newPredator);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null || Timer.isNight()) {
                // No food found or it's Nighttime and no hunting happens!
                newLocation = field.freeAdjacentLocation(getLocation());
            }

            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            }

        }

    }

    /**
     * Check whether or not this fox is to give birth at this step. New births will
     * be made into free adjacent locations.
     *
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Organism> newFoxes) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fox young = new Fox(false, field, loc);
            newFoxes.add(young);
            System.out.println("I gave birth as a fox");
        }
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    private boolean canBreed() {
        if (this.getGender() == Animal.genders.FEMALE && age >= BREEDING_AGE) {
            for (Location location : field.adjacentLocations(this.location)) {
                if (location.getObject() instanceof Fox) {
                    //       System.out.println("Foxes can breed!");
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    /**
     * Looks for rabbits in adjacent locations to the current location, kills the rabbit and increases food level.
     *
     * @return the food location where it starts moving.
     */
    @Override
    public Location findFood() {
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if (rabbit.isAlive()) {
                    rabbit.setDead();
                    foodLevel = FOX_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
