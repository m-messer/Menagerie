import java.util.List;
import java.util.Random;

/**
 * Cods are a simple species. They live in shallow or deep water and swim around relentlessly,
 * reproducing when possible, even by themselves.
 * They age, can be eaten, die, breed. That's about it.
 *
 * @version 20.02.2020
 */
public class Cod extends Prey {

    // The age at which a Cod can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a Cod can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a Cod breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The Cod's age.
    private int age;


    /**
     * Constructor for objects of class Cod
     * For initial generation, map will be populated with randomly aged cods.
     */
    public Cod(boolean randomAge, Field field, Location location) {
        super(true, field, location);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        this.foodLevel = 10;
    }

    /**
     * This is what the cod does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     *  It checks if the place where it wants to move is Shallow or Deep water.
     *  Cods can't walk!
     * @param newCod A list to return newly born cods.
     * @param weatherGenerator

     */
    public void act(List<Organism> newCod, WeatherGenerator weatherGenerator) {
        if (isAlive()) {
            giveBirth(newCod);
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if (newLocation != null && (newLocation.getCellType().equals("Shallow") ||
                    newLocation.getCellType().equals("Water"))) {
                setLocation(newLocation);
            }
        }
    }

    /**
     * Check whether or not this cod is to give birth at this step.
     * New births will be made into free adjacent locations that are in water.
     * @param newCod A list to return newly born cods.
     */
    private void giveBirth(List<Organism> newCod) {

        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (loc.getCellType().equals("Water") || loc.getCellType().equals("Shallow")) {
                System.out.println("Cod just gave birth");
                newCod.add(new Cod(false, field, loc));
            }
        }
    }


    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && (rand.nextDouble() <= BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A cod can breed if it has reached the breeding age.
     * Cods are asexual reproducers in this simulation!
     *
     * @return true if the cod can breed, false otherwise.
     */
    private boolean canBreed() {

        if (age >= BREEDING_AGE) {
            for (Location location : field.adjacentLocations(this.location)) {
                if (location.getObject() instanceof Cod) {
                    System.out.println("its possible!");
                    return true;
                }
            }
            return false;
        }
        return false;
    }

}
