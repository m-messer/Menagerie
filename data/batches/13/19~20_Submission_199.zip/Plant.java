import java.util.List;
import java.util.Random;

/**
 *Plants are simple element that can be eaten. It grows / multiplies and dies only if eaten.
 * It only grows during the day.
 * @version 20.02.2020
 */
public class Plant extends Organism {
    private int size;

    private static final double GROWTH_RATE = 0.01;

    private static final int MAX_GROWTH = 2;

    private int age;
    private static final int MAX_AGE = 30;
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor that has plants inital size and location
     *
     * @param field    - field of the organisms
     * @param location - specific location of the Plant
     * @param size     - size of the plant.
     */
    public Plant(Field field, Location location, int size) {
        super(field, location);
        age = 0;
        this.size = size;
        if (location != null) {
            setLocation(location);
        }

    }

    /**
     * Plant acts if alive - multiplies.
     * It only grows if it multiplies
     */
    public void act(List<Organism> newPlant, WeatherGenerator weatherGenerator) {
        if (isAlive() && weatherGenerator.getWeather().equals("Rain")) {
            multiply(newPlant);
        }

    }


    /**
     * Check whether or not this Plant can grow in this step.
     * New growths will be made into free adjacent locations that are on grass or on shallow water.
     *
     * @param newPlant A list to return newly born growths.
     */
    private void multiply(List<Organism> newPlant) {

        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int growths = Grow();
        for (int b = 0; b < growths && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (loc.getCellType().equals("Grass") || loc.getCellType().equals("Shallow")) {
                newPlant.add(new Plant(field, loc, rand.nextInt(3) + 1));
            }
        }
    }

    /**
     * Plant grows or has "children" if it can
     * @return the number int of children it can grow
     */

    public int Grow() {
        int growths = 0;
        if (canGrow() && (rand.nextDouble() <= GROWTH_RATE)) {
            growths = rand.nextInt(MAX_GROWTH) + 1;
        }
        return growths;
    }


    /**
     * Check if it is day
     * @return boolean true if it is day, false otherwise.
     */
    private boolean canGrow() {
        return Timer.isDay();
    }
}
