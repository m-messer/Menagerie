/**
 * A class that is used to decide the time within the simulation
 *
 * @version 2020.02.21
 */

public class Timer {
    // instance variables - replace the example below with your own
    private static int timeOfDay;
    private static int incrementer = 1000;

    public Timer() {

    }

    /**
     * Increments the timer and returns true if the simulation has started a new day
     */
    public boolean Increment() {
        timeOfDay = (timeOfDay + incrementer) % 86400;
        return timeOfDay < incrementer;
    }

    /**
     * Returns the current time within the simulation
     */
    public int getTime() {
        return timeOfDay;
    }


    /**
     * Returns whether or not the simulation is in daytime
     */
    public static boolean isDay() {
        return (timeOfDay >= 18000 && timeOfDay <= 40000);
    }

    /**
     * Returns whether or not the simulation is in nighttime
     */
    public static boolean isNight() {
        return !isDay();
    }

}
