import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 250;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 250;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.03;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.15;
    private static final double PLANT_CREATION_POSSIBILITY = 0.3;
    private static final double COD_CREATION_POSSIBILITY = 0.3;
    private static final double HERON_CREATION_POSSIBILITY = 0.01;
    private static final double TIGER_CREATION_POSSIBILITY = 0.01;
    private static final double FROG_CREATION_POSSIBILITY = 0.02;

    private int timeIncrement = 60;


    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    private Timer timer = new Timer();

    //Weather generator
    private WeatherGenerator weathergenerator = new WeatherGenerator();

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();
        field = new Field(depth, width);

        weathergenerator = new WeatherGenerator();
// TODO: DIsplay all animals and optimise colours.
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Plant.class, Color.RED);
        view.setColor(Cod.class, Color.PINK);
        view.setColor(Heron.class, Color.white);
        view.setColor(Tiger.class, Color.yellow);
        view.setColor(Frog.class, Color.CYAN);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        System.out.println(view.isViable(field));
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(1);   // uncomment this to run more slowly

        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep() {
        step++;
        boolean isNewDay = timer.Increment();

        if (isNewDay) {
            weathergenerator.decideWeather();
            for (Organism organism : organisms) {
                organism.incrementAge();
                if (organism instanceof Animal) {
                    Animal animal = (Animal) organism;
                    animal.incrementHunger();
                }
            }
        }

        // Provide space for newborn organisms.
        List<Organism> neworganisms = new ArrayList<>();

        // Let all organisms act.
        for (Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(neworganisms, weathergenerator);

            if (!organism.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals to the main lists.
        organisms.addAll(neworganisms);
        view.repaint();
        view.showStatus(step, field, weathergenerator);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        weathergenerator.decideWeather();
        step = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, weathergenerator);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        System.out.println("Populate");
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Location location = field.getLocationFromCoords(row, col);
                if (!location.getCellType().equals("Mountain") && !location.getCellType().equals("Water")) {
                    if (rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                        organisms.add(new Fox(true, field, location));
                    } else if (rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                        organisms.add(new Rabbit(true, field, location));
                    } else if (rand.nextDouble() <= PLANT_CREATION_POSSIBILITY) {
                        organisms.add(new Plant(field, location, 2));
                    } else if (rand.nextDouble() <= TIGER_CREATION_POSSIBILITY) {
                        organisms.add(new Tiger(true, field, location));
                    }
                } else if (location.getCellType().equals("Water") || location.getCellType().equals("Shallow")) {
                    if (rand.nextDouble() <= COD_CREATION_POSSIBILITY) {
                        organisms.add(new Cod(true, field, location));
                    } else if (rand.nextDouble() <= FROG_CREATION_POSSIBILITY) {
                        organisms.add(new Frog(true, field, location));
                    }
                }
//                Heron can be generated anywhere, because they can fly.
                if (rand.nextDouble() <= HERON_CREATION_POSSIBILITY) {
                    organisms.add(new Heron(true, field, location));
                }


            }
        }
        System.out.println("Number of organisms: " + organisms.size());
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    public static void main(String[] args) {
        Simulator me = new Simulator();
        me.simulate(100000000);
        // me.runLongSimulation();
    }
}
