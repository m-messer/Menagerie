import java.util.List;

/**
 * Write a description of class Organism here.
 *
 * @version (a version number or a date)
 */
public class Organism {
    // instance variables - replace the example below with your own
    protected boolean alive;
    protected Field field;
    protected Location location;
    protected int age;
    protected int MAX_AGE = 10;
    protected int foodLevel = 10;
    protected int foodincrementer = 1;

    public Organism(Field field, Location location) {
        this.field = field;
        this.location = location;
        this.alive = true;
    }

    public void act(List<Organism> organisms, WeatherGenerator weatherGenerator) {
    }

    public boolean isAlive() {
        return alive;
    }

    public void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    protected Location getLocation() {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        //  System.out.println(newLocation);
        location = newLocation;
        //   System.out.println(field);
        this.field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }

}
