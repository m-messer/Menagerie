import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Heron. Herons age, move (fly), breed, and die.
 * They are the only animals that can go everywhere.
 * @version 20.02.2020
 */
public class Heron extends Predator {

    // Characteristics shared by all herons.

    // The age at which a heron can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a heron can live.
    private static int MAX_AGE;
    // The likelihood of a heron breeding.
    private static final double BREEDING_PROBABILITY = 0.68;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single Heron. In effect, this is the
    // number of steps a heron can go before it has to eat again.
    private static final int HERON_FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The heron's age.
    private int age;
    // The heron's food level, which is increased by eating frogs.
    private int foodLevel;

    /**
     * Create a heron. A heron can be created as a new born (age zero and not
     * hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the heron will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Heron(boolean randomAge, Field field, Location location) {
        super(field, location);
        MAX_AGE = 40;
        this.foodLevel = 20;

        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(HERON_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = HERON_FOOD_VALUE;
        }


    }

    /**
     * Look for rabbits adjacent to the current location. Only the first live rabbit
     * is eaten.
     * Heron can move anywhere, because it's flying!
     *
     */

    public void act(List<Organism> newPredator, WeatherGenerator weatherGenerator) {
        if (isAlive()) {
            giveBirth(newPredator);
            // Move towards a source of food if found. Can't see food with foggy weather.
            Location newLocation = null;
            if (!weatherGenerator.getWeather().equals("Foggy")) {
                newLocation = findFood();
            }

            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            }
        }
    }

    /**
     * Looks for plants in adjacent locations to the current location, kills the frog and increases food level.
     *
     * @return the food location where it starts moving.
     */
    @Override
    public Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Fox) {
                Fox fox = (Fox) animal;
                if (fox.isAlive()) {
                    fox.setDead();
                    foodLevel = HERON_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this heron is to give birth at this step. New births
     * will be made into free adjacent locations.
     * 
     * @param newHeron A list to return newly born herones.
     */
    private void giveBirth(List<Organism> newHeron) {
        // New herones are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Heron young = new Heron(false, field, loc);
            newHeron.add(young);
        }
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A heron can breed if it has reached the breeding age and if it has a Heron of an opposite gender next to it.
     */
    private boolean canBreed() {
        if (this.getGender() == Animal.genders.FEMALE && age >= BREEDING_AGE) {
            for (Location location : field.adjacentLocations(this.location)) {
                if (location.getObject() instanceof Heron
                        && ((Animal) location.getObject()).getGender() != this.getGender()) {
                    System.out.println("Heron can breed");
                    return true;
                }
            }
            return false;
        }
        return false;
    }
}
