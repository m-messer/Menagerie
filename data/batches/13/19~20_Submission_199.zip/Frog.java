 



import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a rabbit. Rabbits age, move, breed, and die.
 * They only eat during the day. They also eat plants, they're a new generation of vegan frogs.
 * @version 20.02.2020
 */
public class Frog extends Prey {
    // The age at which a frog can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a frog can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a frog breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private Random rand = new Random();
    // The frog's age.
    private int age;
    private int FROG_FOOD_VALUE;

    /**
     * Create a new frog. A frog may be created with age zero (a new born) or with a
     * random age.
     *
     * @param randomAge If true, the frog will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Frog(boolean randomAge, Field field, Location location) {
        super(true, field, location);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the Frog does most of the time - it runs around. Sometimes it
     * will breed or die of old age. It can move only move on Grass or shallow water.
     *
     * @param newfrogs List of new frogs made by reproduction.
     * @param weatherGenerator
     */
    public void act(List<Organism> newfrogs, WeatherGenerator weatherGenerator) {
        if (isAlive()) {
            giveBirth(newfrogs);
            // Try to move into a free location.
            Location newLocation = findFood();
            if (newLocation != null && (newLocation.getCellType().equals("Shallow") || newLocation.getCellType().equals("Grass"))) {
                setLocation(newLocation);
            }
        }
    }

    /**
     * Looks for plants in adjacent locations to the current location, kills the plant and increases food level.
     *
     * @return the food location where it starts moving.
     */
    @Override
    public Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if (Organism instanceof Plant) {
                Plant plant = (Plant) Organism;
                if (plant.isAlive()) {
                    plant.setDead();
                    foodLevel = FROG_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Frog is to give birth at this step. New births will
     * be made into free adjacent locations.
     *
     * @param newfrogs A list to return newly born Frog.
     */
    private void giveBirth(List<Organism> newfrogs) {
        // New frogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Frog young = new Frog(false, field, loc);
            newfrogs.add(young);
        }
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Frog can breed if it has reached the breeding age AND it is close by with
     * the seperate gendered frog.
     *
     * @return true if the frog can breed, false otherwise.
     */
    private boolean canBreed() {
        if (this.getGender() == Animal.genders.FEMALE && age >= BREEDING_AGE) {
            for (Location location : field.adjacentLocations(this.location)) {
                if (location.getObject() instanceof Frog
                        && ((Animal) location.getObject()).getGender() != this.getGender()) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }
}
