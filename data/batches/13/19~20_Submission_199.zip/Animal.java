import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 * 
 * @version 20.02.2020
 */
public abstract class Animal extends Organism {
    // Whether the animal is alive or not.
    protected boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;

    protected enum genders {
        MALE, FEMALE
    };

    protected genders myGender;

    protected Random random = new Random();

    /**
     * Create a new animal at location in field.
     * 
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * Randomly randomly assign gender.
     */
    public Animal(Field field, Location location) {
        super(field, location);
        genders myGender = genders.values()[random.nextInt(genders.values().length)];
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Decrease food level and check if animal is dead because of hunger.
     */

    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Make this animal act - that is: make it do whatever it wants/needs to do.
     *
     * @param newAnimals A list to receive newly born animals.
     * @param weatherGenerator
     */
    public void act(List<Organism> newAnimals, WeatherGenerator weatherGenerator) {
        if (isAlive()) {
            // giveBirth(newAnimals);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {

                setLocation(newLocation);
            }
        }
    }

    /**
     * Animal finds food. If animal doesn't need a specific food, it just lives from air and love.
     *
     * @return null
     */
    public Location findFood() {
        return null;
    }

    /** Return Animal's gender.
     * @return myGender
     */
    public genders getGender() {
        return myGender;
    }

}
