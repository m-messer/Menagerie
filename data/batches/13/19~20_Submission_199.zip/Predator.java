import java.util.List;

/**
 * This class is an abstract Predator class to provide a better inheritance structure
 * for added predator-specific functionality.
 *
 * @version 20.02.2020
 */

public abstract class Predator extends Animal {

    /**
     * Constructor to define the position of the Predator
     *
     * @param field    - organisms on the grid
     * @param location - specific position of this organism.
     */
    public Predator(Field field, Location location) {
        super(field, location);
    }

    /**
     * Abstract class for finding food.
     * @return Location of the food
     */
    public abstract Location findFood();

    /**
     * Main "acting" element that makes the Predators act a certain way.
     * @param newPredator list of new animals made.
     * @param weatherGenerator field's weather
     */
    public abstract void act(List<Organism> newPredator, WeatherGenerator weatherGenerator);


}
