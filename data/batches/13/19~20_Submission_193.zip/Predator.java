import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Abstract class Predator 
 * A class representing shared characteristics of predators.
 *
 * @version 2020.02
 */
public abstract class Predator extends Animal
{
   
    private static final Random rand = Randomizer.getRandom();
   
    /**
     * Create a new predator at location in field.
     * 
     * @param randomAge It will generate random age of animals.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        //inherited fields from the super class Animal
        super(field, location);
        //set random age true
        randomAge = true;
  
    }
   
    /**
     * Make this animal act - that is: make it do
     * It will be implemented in the subclass
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals, boolean dayTime, boolean isRain,boolean isCold);
    /**
     * Make this animal find food;
     * It will be implemented in the subclasses
     */
    abstract public Location findFood();
    /**
     * Make this animal act - that is: make it do
     * It will be implemented in the subclasses
     * @param newPredator A list to receive newly born predators.
     */
    abstract public void giveBirth(List<Animal> newPredator);
    /**
     * Make this animal breed;
     * It will be implemented in the subclasses
     */
    abstract public int breed();
    
    /**
     * Check whether this predator can breed.
     * Return true if it can breed
     */
    protected boolean canBreed()
    {
       return true; 
    }
    
}
 
    
    