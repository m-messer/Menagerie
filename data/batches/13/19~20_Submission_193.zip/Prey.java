import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Abstract class Prey - write a description of the class here
 *
 * @version 2020.02
 */
public abstract class Prey extends Animal
{
  private static final Random rand = Randomizer.getRandom();
  /**
  * Create a new prey at location in field.
  * 
  * @param randomAge It will generate random age of animals.
  * @param field The field currently occupied.
  * @param location The location within the field.
  */
  public Prey(boolean randomAge, Field field, Location location)
  {
      //inherited fields from the super class Animal
      super(field, location);
      //set random age true
      randomAge = true;
     
     
    }
  /**
  * Make this prey act - that is: make it do
  * It will be implemented in the subclasses
  * @param newAnimals A list to receive newly born animals.
  */
  abstract public void act(List<Animal> newAnimals, boolean dayTime, boolean isRain,boolean isCold);
 
}
    
        
   

