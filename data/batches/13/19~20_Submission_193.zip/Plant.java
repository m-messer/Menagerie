import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a plant
 * plant age, grow and die
 *
 * @version 2020.02
 */
public class Plant extends Animal
{
    //Characteristics shared by all plants
    //The age at which a plant can start to breed
    private static final int BREEDING_AGE = 2;
    //The age to which a plant can live
    private static final int MAX_AGE = 100;
    //The likelihood of a plant breeding
    private static final double BREEDING_PROBABILITY = 0.7;
    //The maximum number of births
    private static final int MAX_LITTER_SIZE = 20;
    //A shared random generator to control breeding
    private static final Random rand = Randomizer.getRandom(); 
    
    //The plant's age
    private int age;
    //The plant's field
    private Field field;

    
  /**
   * Constructor for objects of class plant
   */
  public Plant(boolean randomAge, Field field, Location location)
  {
     super(field, location);
        randomAge = true;
        if(randomAge){
            age = rand.nextInt(MAX_AGE);
            
        }
        else{
            age = 0;
        }
    
    }
  
   /**
   * This is what the plant does for most of the time-it cannot move
   * Sometimes it will breed or die of old age
   * It will be affected by the weather 
   * @param newPlants A list to return newly born plants
   */
    public void act(List<Animal> newAnimals, boolean dayTime, boolean isRain,boolean isCold)
  {
        incrementAge();
        if(isAlive() && isRain){
            giveBirth(newAnimals,true, true);
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null){
                setLocation(newLocation);
            }
            else{
                //Overcrowding
                setDead();
            }
            if(!isRain)
            {
                incrementAge();
            }
            
        }
    
    }

   /**
    * Check whether or not this plant is give birth at this step
    * New births will be made to free adjacent locations
    * @param newPlants A list to return newly born plants
    */
    private void giveBirth(List<Animal> newPlant, boolean dayTime, boolean isRain)
    {
        // New plants born into adjacent locations.
        // Get a list of adjacent free locations
        Field field = getField();
        List<Location> free = field.getRandomAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size()>0; b++){
            Location loc = free.remove(0);
            Plant young = new Plant(true, field, loc);
            newPlant.add(young);
        }
       
    }
    
    /**
     * Find mate for this plant
     */
    public boolean findMate()
    {
       
        return false;
    }
    
    /**
     * Generate a number representing the number of births
     * if it can breed
     * @return The number of births
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY){
            births = rand.nextInt(MAX_LITTER_SIZE)+1;
        }
        return births;
    }
    
    /**
     * A plant can reproduce if it has reached the breeding age
     * @return true if the plant can reproduce, false otherwise
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    /**
     * increase the age.
     * This may result in the plant's death
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE){
            setDead();
        }
    }
}


    
    