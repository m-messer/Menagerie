import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing a number of animals
 *
 * @version 2020.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double WHITESHARK_CREATION_PROBABILITY = 0.02;
    // The probability that a rabbit will be created in any given grid position.
    private static final double FISH_CREATION_PROBABILITY = 0.02;    
    // The probability that a rabbit will be created in any given grid position.
    private static final double SEAL_CREATION_PROBABILITY = 0.04;    
    // The probability that a rabbit will be created in any given grid position.
    private static final double SHRIMP_CREATION_PROBABILITY = 0.04;    
    // The probability that a rabbit will be created in any given grid position.
    private static final double DOLPHIN_CREATION_PROBABILITY = 0.05;    
    // The probability that a rabbit will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.06; 
    private static final Random rand = Randomizer.getRandom();

    
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current time of the simulation.
    private boolean dayTime;
    private boolean isRain;
    private boolean isCold;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        isRain = true;
        isCold = false;
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, dayTime);
        view.setColor(Dolphin.class, Color.PINK);
        view.setColor(WhiteShark.class, Color.RED);
        view.setColor(Seal.class, Color.BLUE);
        view.setColor(Shrimp.class, Color.YELLOW);
        view.setColor(Fish.class, Color.ORANGE);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }
   
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        Random rand = Randomizer.getRandom();
        isRain = rand.nextBoolean();
        isCold = rand.nextBoolean();
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>(); 
        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals,dayTime,isRain,isCold);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);
       
        updateTime();
        updateWeather();
        updateTemperature();

        view.showStatus(step, field, dayTime,isRain,isCold);
    }
    /**
     * Update the time
     */
    public void updateTime() {
        int timeOfDay = step % 14;
        if (timeOfDay <= 7){
          dayTime = true;
        }
        else 
        {
           dayTime = false;
            
        }
            
        }
    /**
     * Update the weather
     */
        public void updateWeather(){
        int weatherOfDay = step % 14;
        if (weatherOfDay <= 7){
          isRain = true;
        }
        else 
        {
           isRain = false;
            
        }
        
    }
    /**
     * Update the temperature
     */
    public void updateTemperature(){
        int weatherOfDay = step % 14;
        if (weatherOfDay <= 7){
          isCold = false;
        }
        else 
        {
           isCold = true;
            
        }
        
    }
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        updateTime();
        updateWeather();
        updateTemperature();
        
        // Show the starting state in the view.
        view.showStatus(step, field, dayTime, isRain,isCold);
    }
    
    /**
     * Get the time of the day
     */
    public boolean getTime()
    {
        return dayTime;
    
    }
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WHITESHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    WhiteShark whiteshark = new WhiteShark(true, field, location);
                    animals.add(whiteshark);
                }
                else if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fish fish = new Fish(true, field, location);
                    animals.add(fish);
                }
                else if(rand.nextDouble() <= DOLPHIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dolphin dolphin = new Dolphin(true, field, location);
                    animals.add(dolphin);
                }
                 else if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location);
                    animals.add(seal);
                }
                 else if(rand.nextDouble() <= SHRIMP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shrimp shrimp = new Shrimp(true, field, location);
                    animals.add(shrimp);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY){
                    Location location = new Location(row,col);
                    Plant plant = new Plant(true, field, location);
                    animals.add(plant);
                }
                
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
