import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * A simple model of a shrimp
 * Shrimp age, move,eat plant, and die
 *
 * @version 2020.02
 */
public class Shrimp extends Prey
{
   // Characteristics shared by all shrimps (class variables).

    // The age at which a shrimp can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a shrimp can live.
    private static final int MAX_AGE = 110;
    // The likelihood of a shrimp breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
     // The food value of a single plant. In effect, this is the
    // number of steps a shrimp can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 14;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The shrimp's age.
    private int age;
    //The shrimp's foodlevel
    private int foodLevel;
    //The sex of the shrimp
    private boolean isFemale;
    //the infection status of the shrimp
    private boolean infected;
    

    /**
     * Create a new shrimp. A shrimp may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the shrimp will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shrimp(boolean randomAge, Field field, Location location)
    {
        super(true,field, location);
        infected = false;
        isFemale = rand.nextBoolean();

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    /**
     * Look for plants adjacent to current location
     * Only the first live plant is eaten
     * @return Where the plant was found, or null if it wasn't
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant){
                Plant plant = (Plant) animal;
                if(plant.isAlive()){
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                    }
            }
        }
        return null;
    }
    /**
     * This is what the shrimp does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newShrimps A list to return newly born shrimps.
     */
    public void act(List<Animal> newAnimals, boolean dayTime, boolean isRain,boolean isCold)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()&& dayTime) {
            giveBirth(newAnimals);            
            // Move towards a source of food if found
            Location newLocation = findFood();
            if(newLocation == null){
                //No food found - try to move to a free location
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            //see if it is possible to move
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
     
    /**
     * make this shrimp more hungry. 
     * decrease the food level of shrimp
     * This could result in the shrimp's death
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0){
            setDead();
        }
    }
    
    /**
     * Increase the age.
     * This could result in the shrimp's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newShrimps A list to return newly born rabbits.
     */
    private void giveBirth(List<Animal> newAnimals)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        if(isFemale){
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Shrimp young = new Shrimp(false, field, loc);
            newAnimals.add(young);
        }
        }
    }
   
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Find mate for this shrimp
     * If the animals adjacent to each other are of opposite sex,
     * then they can mate
     */
    public boolean findMate()
    {
        if(isFemale){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shrimp) {
                Shrimp shrimp = (Shrimp) animal;
                if(shrimp.isAlive() &&!shrimp.isFemale()) { 
                  
                    return true;
               }
            }
        }
    }
    return false;
    }
    /**
     * A shrimp can breed if it has reached the breeding age.
     * @return true if the shrimp can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
     /**
     * infect the adjacent shrimp
     */
    public void infectingAdjacent()
    {
        if(infected){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
           while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setInfected();
               }
            }
        }
    }
    }
    /**
     * set the shrimp infected
     */
    public void setInfected()
    {
        infected = true;
    
    }
    
    /**
     * return whether the shrimp is infected
     */
    public boolean isInfected()
    {
        return infected;
      
    }
    
    /**
    * return whether the shrimp is infected
    */
    public boolean isFemale()
    {
        return isFemale;
      
    }
}
