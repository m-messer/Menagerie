/**
 * Main class contains the launchSimulation method that launches the simulation by creating a simulator object and running the WeatherSimulation class.
 *
 * @version 02/03/2022
 */


import processing.core.PVector;
import processing.core.PApplet;


public class Main {
    
    static public void launchSimulation(int hours) {
        String[] appletArgs = new String[] {"WeatherSimulator"};
        PApplet.main(appletArgs);
     

        Simulator simulation = new Simulator(100, 100);
        simulation.simulate(hours);
    }
}

 