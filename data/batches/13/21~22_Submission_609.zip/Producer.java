import java.util.List;
/**
 * A class representing shared characteristics and behaviours of Producers.
 *
 * @version 02/03/2022
 */
public class Producer extends Organism {

    private double mass;
    private static double GROWTH_RATE;
    private static double LIGHT_INTENSITY;
    private static double MAX_MASS = 5000.00;

    public Producer(Field field, Location location, String species, int maxAge) {
        super(field, location, species, maxAge);
        mass = 1;
    }
    /**
	 * 
	 * Make the producers act
	 * @param newProducers    The list of new born producers.
	 */
    public void act(List<Organism> newOrganisms, boolean isNight) {
        incrementAge();
        incrementHunger(0.1);
        setGrowthRate(WeatherSimulator.getDensity());
        mass += addProducerFoodLevel(GROWTH_RATE);
        if (!isNight && isAlive()) {
            reproduce(newOrganisms);
        }
    }
        /**
	 * 
	 * Make the producers reproduce
	 * @param newProducers    The list of new born producers.
	 */
    private void reproduce(List<Organism> newOrganisms) {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        for (int b = 0; b < getFoodLevel() && free.size() > 0; b++) {
            Location loc = free.remove(0);
            // each producer has a life span of 5 days
            Producer young = new Producer(field, loc, getSpecies(), (3 * 1440));
            newOrganisms.add(young);

        }

    }

   /**
	 * 
	 * @return the current light intensity
	 */
    public static double getLightIntensity(Field field, double hour) {
        // Luminous flux is modelled by a sin wave, constant allows real world values
        // light intensity is calculated, the constant c means that the maximum light
        // intensity during the day is 10752 no matter what the area of the field is
        int area = (field.getDepth() * field.getWidth());
        int c = (area * 10752);
        double luminousFlux = Math.sin(hour * (Math.PI / 24));

        LIGHT_INTENSITY = (c * luminousFlux / area);
        return LIGHT_INTENSITY;
    }
    /**
	 * 
	 * Set the growth rate for all producers
	 */
    private void setGrowthRate(float temperature) {
        GROWTH_RATE = (LIGHT_INTENSITY / 10752) + (0.01 * temperature);
    }
    /**
	 * 
        @return the representation of the transparency of the plant
	 */
    public float getShade() {
        if (mass >= MAX_MASS) {
            return 1;
        } else {
            return (float) (mass / MAX_MASS);
        }
    }
}