import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import processing.core.PApplet;

/**
 * A simple predator-prey simulator, based on a rectangular field containing
 *  producers and consumers.
 *
 * @version 02/03/2022
 */
public class Simulator {
	// Constants representing configuration information for the simulation.
	// The default width for the grid.
	private static final int DEFAULT_WIDTH = 120;
	// The default depth of the grid.
	private static final int DEFAULT_DEPTH = 120;
	// The probability that a consumer will be created in any given grid position.
	private static final double CONSUMER_CREATION_PROBABILITY = 0.08;
	// The probability that a producer will be created in any given grid position.
	private static final double PRODUCER_CREATION_PROBABILITY = 0.02;
        //All consumer species
	private static final ArrayList<String> consumerList = new ArrayList<>(Arrays.asList("Lynx", "Grizzly Bear", "Wolf",
			"Coyote", "Red Fox", "Weasel", "Marten", "Red Squirrel", "Shrew", "Beaver"));
        //All producer species
	private static final ArrayList<String> producerList = new ArrayList<>(
			Arrays.asList("Cranberries", "Heaths", "Lichens"));

	// List of organisms in the field.
	private List<Organism> organisms;
	// The current state of the field.
	private Field field;
	// A graphical view of the simulation.
	private SimulatorView view;
	// clock
	private ClockDisplay clock;
	
	private int step;
	

	/**
	 * Construct a simulation field with default size.
	 */
	public Simulator() {
		this(DEFAULT_DEPTH, DEFAULT_WIDTH);
	}

	/**
	 * Create a simulation field with the given size.
	 * 
	 * @param depth Depth of the field. Must be greater than zero.
	 * @param width Width of the field. Must be greater than zero.
	 */
	public Simulator(int depth, int width) {
		if (width <= 0 || depth <= 0) {
			System.out.println("The dimensions must be greater than zero.");
			System.out.println("Using default values.");
			depth = DEFAULT_DEPTH;
			width = DEFAULT_WIDTH;
		}

		organisms = new ArrayList<>();
		field = new Field(depth, width);
		clock = new ClockDisplay();
		step = -1;
		

		// define the colors that are going to be used

		Color lynxColor = new Color(205, 133, 63);
		Color wolfColor = new Color(105, 105, 105);
		Color bearColor = new Color(139, 69, 19);
		Color coyoteColor = new Color(119, 136, 153);
		Color redFoxColor = new Color(128, 0, 0);
		Color weaselColor = new Color(218, 165, 32);
		Color martenColor = new Color(255, 160, 122);
		Color redSquirrelColor = new Color(255, 0, 0);
		Color shrewColor = new Color(184, 134, 11);
		Color beaverColor = new Color(210, 105, 30);

		// Create a view of the state of each location in the field.
		view = new SimulatorView(depth, width);

		view.setColor("lynx", lynxColor);
		view.setColor("wolf", wolfColor);
		view.setColor("grizzly bear", bearColor);
		view.setColor("coyote", coyoteColor);
		view.setColor("red fox", redFoxColor);
		view.setColor("weasel", weaselColor);
		view.setColor("marten", martenColor);
		view.setColor("red squirrel", redSquirrelColor);
		view.setColor("shrew", shrewColor);
		view.setColor("beaver", beaverColor);
		// Setup a valid starting point.
		reset();
	}

	/**
	 * Run the simulation from its current state for a reasonably long period, (5
	 * days).
	 */
	public void runLongSimulation() {
		simulate(7200);
	}

	/**
	 * Run the simulation from its current state for the given number of steps. Stop
	 * before the given number of steps if it ceases to be viable.
	 * 
	 * @param numSteps The number of steps to run for.
	 */
	public void simulate(int numOfHours) {
		for (int min = 1; min <= (numOfHours * 60) && view.isViable(field); min++) {
			simulateOneMin();
			delay(60); // uncomment this to run more slowly
		}
	}

	/**
	 * Run the simulation from its current state for a single step. Iterate over the
	 * whole field updating the state of each producer and consumer.
	 */
	public void simulateOneMin() {
		step++;
		// Provide space for newborn animals.
		List<Organism> newOrganisms = new ArrayList<>();
		// Let all organism act.
		for (Iterator<Organism> it = organisms.iterator(); it.hasNext();) {
			Organism organism = it.next();
			organism.act(newOrganisms, clock.isNight());

			if (!(organism.isAlive())) {
				it.remove();
			}
		}

		// Add the newly born consumers and producers to the main lists.
		organisms.addAll(newOrganisms);
		//increment the clock
		clock.timeTick();
		view.showStatus(field, clock.getTime(), clock.getDay(), clock.getHour());
			
	}

	/**
	 * Reset the simulation to a starting position.
	 */
	public void reset() {
		organisms.clear();
		populate();

		// Show the starting state in the view.
		view.showStatus(field, clock.getTime(), clock.getDay(), clock.getHour());
	}

	/**
	 * Randomly populate the field with producers and consumers.
	 */
	private void populate() {
		Random rand = Randomizer.getRandom();
		field.clear();
		for (int row = 0; row < field.getDepth(); row++) {
			for (int col = 0; col < field.getWidth(); col++) {
				if (rand.nextDouble() <= CONSUMER_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Consumer consumer = new Consumer(field, location,
							consumerList.get(Randomizer.getRandomNumber(0, consumerList.size())).toLowerCase(),
							(3 * 1440));
					organisms.add(consumer);
				} else if (rand.nextDouble() <= PRODUCER_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Producer producer = new Producer(field, location,
							producerList.get(Randomizer.getRandomNumber(0, producerList.size())).toLowerCase(),
							(3 * 1440));
					organisms.add(producer);
				}
				// else leave the location empty.
			}
		}
	}

	/**
	 * Pause for a given time.
	 * 
	 * @param millisec The time to pause for, in milliseconds
	 */
	private void delay(int millisec) {
		try {
			Thread.sleep(millisec);
		} catch (InterruptedException ie) {
			// wake up
		}
	}
}