import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of Organisms.
 *
 * @version 02/03/2022
 */
public abstract class Organism {
	// Whether the organism is alive or not.
	private boolean alive;
	// The organism's field.
	private Field field;
	// The organism's position in the field.
	private Location location;
        // The age of the organism.
	private int age;
        // The maximum age of the organism.
	private int maxAge;
        // The species of the organism
	private String species;
        // The food level of the organsim
	private double foodLevel;
        // The gender of the organism
	private boolean isMale;

	private Random rand;
	/**
	 * Create a new organism at location in field.
	 * 
	 * @param field    The field currently occupied.
	 * @param location The location within the field.
	 */
	public Organism(Field field, Location location, String species, int maxAge) {
		rand = Randomizer.getRandom();
		alive = true;
		this.field = field;
		this.species = species;
		this.maxAge = maxAge;
		setLocation(location);
		//food level is set to 43 so that organsims are able to survive the night
		foodLevel = 43;
		age = 1;
		//gender is random
		isMale = rand.nextBoolean();

	}

	/** 
	 * Make this organism act that is: make it do whatever it wants/needs to do.
	 * 
	 * @param newOrganisms A list to receive newly born organisms.
	 */
	abstract public void act(List<Organism> newOrganisms, boolean isNight);

	/**
	 * Check whether the oragnism is alive or not.
	 * 
	 * @return true if the organism is still alive.
	 */
	protected boolean isAlive() {
		return alive;
	}

	/**
	 * Indicate that the organism is no longer alive. It is removed from the field.
	 */
	protected void setDead() {
		alive = false;
		if (location != null) {
			field.clear(location);
			location = null;
			field = null;
		}
	}

	/**
	 * Return the organism's location.
	 * 
	 * @return The organism's location.
	 */
	protected Location getLocation() {
		return location;
	}

	/**
	 * Place the organism at the new location in the given field.
	 * 
	 * @param newLocation The organism's new location.
	 */
	protected void setLocation(Location newLocation) {
		if (location != null) {
			field.clear(location);
		}
		location = newLocation;
		field.place(this, newLocation.getRow(), newLocation.getCol());
	}

	/**
	 * Return the organism's field.
	 * 
	 * @return The organism's field.
	 */
	protected Field getField() {
		return field;
	}
	/**
	 * Return the organism's age.
	 * 
	 * @return The organism's age.
	 */

	protected int getAge() {
		return age;
	}

	/**
	 * Add age of one to organism, set dead if it's over max age.
	 * 
	 */
	protected void incrementAge() {
		age++;
		if (age > maxAge) {
			setDead();
		}
	}
        
	/**
	 *set the age of the organism
	 * 
	 */
	protected void setAge(int age) {
		this.age = age;
	}
        
	/**
	 *@return max age of the organism
	 * 
	 */
	protected int getMaxAge() {
		return maxAge;
	}

	/**
	 *@return random breeding probability
	 * 
	 */
	
	protected Random breedingRandomizer() {
		return Randomizer.getRandom();
	}

	/**
	 *@return species of the organism
	 * 
	 */
	
	protected String getSpecies() {
		return species;
	}
	
	/**
	 * @param mins The minutes of the organism's life
	 *Increase hunger by a set of minutes, take away an amount of minutes from the life of the organism by doing so.
	 *
	 * 
	 */

	protected void incrementHunger(double mins) {
		foodLevel -= mins;
		if (foodLevel <= 0.00) {
			setDead();
		}
	}
	
	/**
	 *@return foodLevel
	 * 
	 */

	protected double getFoodLevel() {
		return foodLevel;
	}

	/**
	 * @param prey The organism that the consumer has eaten
	 *Add food level to the consumer after eating prey
	 * 
	 */
	protected void addConsumerFoodLevel(Organism prey) {
        	//10% of the food level of the prey is passed onto the predator just like between trophic levels in real life
		foodLevel += (0.1 * prey.getFoodLevel());
	}
	
	/**
	 *@param GROWTH_RATE growth rate constant for producers
	 *@return foodLevel
	 *
	 *Add food level to the producer, by adding its growth rate
	 */
	
	protected double addProducerFoodLevel(double GROWTH_RATE) {
		foodLevel += GROWTH_RATE;
		return foodLevel;
	}
	/**
	 *@return whether the organism is a male
	 * 
	 */
	public boolean getIsMale() {
		return isMale;
	}
}