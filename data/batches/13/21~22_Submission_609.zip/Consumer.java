import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics and behaviours of Consumers.
 *
 * @version 02/03/2022
 */
public class Consumer extends Organism {
    //List of prey of the consumer
    private ArrayList<String> prey;
    private Random rand;
    private int breedingAge;
    private boolean isMale;

    public Consumer(Field field, Location location, String species, int maxAge) {
        super(field, location, species, maxAge);
        rand = Randomizer.getRandom();
        breedingAge = 30;
        prey = new ArrayList<>();
        //add the list of prey 
        if (species.equals("lynx")) {
            Collections.addAll(prey, "red fox", "weasel", "marten", "red squirrel", "shrew", "beaver");
        }
        if (species.equals("wolf")) {
            Collections.addAll(prey, "red fox", "weasel", "marten", "red squirrel", "shrew", "beaver", "lynx",
                    "coyote");
        }
        if (species.equals("grizzly bear")) {
            Collections.addAll(prey, "red fox", "weasel", "marten", "red squirrel", "shrew", "beaver", "cranberries");
        }
        if (species.equals("coyote")) {
            Collections.addAll(prey, "red fox", "weasel", "marten", "red squirrel", "shrew", "beaver");
        }
        if (species.equals("red fox")) {
            Collections.addAll(prey, "weasel", "marten", "red squirrel", "shrew", "beaver");
        }
        if (species.equals("weasel")) {
            Collections.addAll(prey, "red squirrel", "shrew", "beaver", "cranberries", "heaths");
        }
        if (species.equals("marten")) {
            Collections.addAll(prey, "red squirrel", "cranberries", "heaths", "lichens");
        }
        if (species.equals("red squirrel")) {
            Collections.addAll(prey, "heaths", "lichens");
        }
        if (species.equals("shrew")) {
            Collections.addAll(prey, "heaths", "lichens", "cranberries");
        }
        if (species.equals("beaver")) {
            Collections.addAll(prey, "heaths", "lichens", "cranberries");
        }
    }
    /**
	 * Create a new organism at location in field.
	 * 
	 * @param newConsumers    The list of new born consumers.
	 * @param isNight boolean for whether it is night.
	 */
    public void act(List<Organism> newConsumers, boolean isNight) {
        incrementAge();
        //If it's night the tertiary consumers fall asleep, while the others move, yet no one reproduces
        //During the day everyone is able to move, eat and reproduce
        if (!(isNight)) {
            incrementHunger(0.1);
            if (isAlive()) {
                giveBirth(newConsumers);
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }

        if (isNight && getSpecies().matches("beaver|shrew|red squirrel|marten|weasel|red fox")) {
            incrementHunger(0.1);
            if (isAlive()) {
                // giveBirth(newConsumers);
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    setDead();
                }
            }
        }
    }
     /**
	 * @return the Location of any food that is near
	 */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if (organism != null) {
                //if the organism is in the species list it is eaten
                if (prey.contains(((Organism) organism).getSpecies())) {
                    Organism prey = (Organism) organism;
                    if (prey.isAlive()) {
                        prey.setDead();
                        addConsumerFoodLevel(prey);
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this organism is to give birth at this step. New births will
     * be made into free adjacent locations.
     * 
     * @param newOrganisms A list to return newly born foxes.
     */
    private void giveBirth(List<Organism> newOrganisms) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();

        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if ((organism != null) && (((Organism) organism).getIsMale() != isMale)) {
                List<Location> free = field.getFreeAdjacentLocations(getLocation());

                int births = breed();
                for (int b = 0; b < births && free.size() > 0; b++) {
                    incrementHunger(0.6);
                    Location loc = free.remove(0);
                    Consumer young = new Consumer(field, loc, getSpecies(), (3 * 1440));
                    newOrganisms.add(young);
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births, if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= getBreedingProb(getFoodLevel())) {
            int maxLitterSize = (int) Math.ceil(getFoodLevel());
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * A consumer can breed if it has reached the breeding age. The price to give one
     * birth is food level 6, which is equivalent to an hour of life.
     */
    private boolean canBreed() {
        return ((getAge() >= breedingAge) && (getFoodLevel() >= 0.6));
    }
     /**
     * @return the breeding probability based of food level
     */
    private double getBreedingProb(double foodLevel) {
        return foodLevel * 0.1;
    }
}