
import java.util.List;
/**
 * Abstract class Plant - write a description of the class here
 *
 * @version (version number or date here)
 */
public abstract class Plant implements Actor
{
    // instance variables - replace the example below with your own
    protected int size;
    protected int growRate;
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    /**
     * Constructor for objects of plants
     * @param size, the plant's size, 
     * @param growRate, the grow rate every step
     * @param field, at plant field
     * @param location, the location of it
     */
    public Plant(int size, int growRate, Field field, Location location)
    {
      alive=true;
      this.size=size;
      this.growRate=growRate;
      this.field = field;
      setLocation(location);
    }

    /**
     * when a plant is eaten, the data of it changes
     * @param food needed from the animal eating it
     */
    public abstract int eat(int animalFoodNeed);
    /**
     * basiclly what a plant does
     * it grows...
     * @param the list of Grass
     * @param daytime,weather, and season of a day
     */
    public abstract void act(List<Actor> newPlants,Simulator.time dayTime,
    Simulator.weather dayWeather, Simulator.season daySeason);
    /**
     * @return true if it's alive
     */
    public boolean isAlive()
    {
        return alive;
    }
    /**
     * kills a plant and removes it from field
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    /**
     * @return the location of the plant
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The plant's location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
}