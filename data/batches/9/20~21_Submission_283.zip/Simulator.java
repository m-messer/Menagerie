import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing all animals and plants.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.015;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.1; 
    //probability of lion will be created
    private static final double LION_CREATION_PROBABILITY = 0.01;
    //probability of deer will be created.
    private static final double DEER_CREATION_PROBABILITY = 0.13;
   //probability of wolf will be created
    private static final double WOLF_CREATION_PROBABILITY = 0.02;
    //probability of grass will be created
    private static final double GRASS_CREATION_PROBABILITY= 0.7;
    //probability of tree will be created
    private static final double TREE_CREATION_PROBABILITY=0.7;
    //the list containing all actors including animals and plants
    private List <Actor> actors;
    
    // List of animals in the field.

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //enums containing states of time, weather and season
    public enum time {MORNING, EVENING, NIGHT};
    public enum weather{RAINY, SUNNY, FOGGY};
    public enum season{SPRING,SUMMER,FALL,WINTER};
    //fields of time weather and season.
    private time timeOfDay;
    private weather weatherOfDay;
    private season seasonOfDay;
    public Random rand = new Random();
    //count step in order to change day, weather and season later on.
    private int countstep;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        timeOfDay=time.MORNING;
        weatherOfDay = weather.RAINY;
        seasonOfDay = season.SPRING;
        countstep =0;
    }

    /**
     * Create a simulation field with the given size.
     * setting color for all actors
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        field = new Field(depth, width);
        actors = new ArrayList<>();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Wolf.class, Color.YELLOW);
        view.setColor(Deer.class, Color.PINK);
        view.setPlantColor(Grass.class, Color.GREEN);
        view.setPlantColor(Tree.class, Color.CYAN);
        
        

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60); // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actor
     * including animals and plant, the time,weather and season changes
     * by how many steps. e.g every 20 steps, the daytime changes
     * 
     */
    public void simulateOneStep()
    {
        step++;
        countstep++;
        

        // Provide space for newborn animals.
        List<Actor> newActor = new ArrayList<>();

        // // Let all rabbits act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActor, timeOfDay, weatherOfDay, seasonOfDay);
            if(! actor.isAlive()) {
                it.remove();
            }
        }




        // Add the newly born foxes and rabbits to the main lists.
        actors.addAll(newActor);

        view.showStatus(step, field);
        if (countstep % 20 ==0)
        {
            if(timeOfDay==time.MORNING){
                timeOfDay=time.EVENING;
            }
            else if(timeOfDay==time.EVENING){
                timeOfDay=time.NIGHT;
            }
            else{
                timeOfDay=time.MORNING;
            }
            System.out.println("The day time is now the "+timeOfDay);
        }
        
        if (countstep % 30==0){
            int index = rand.nextInt(3);
            weatherOfDay = weather.values()[index];
            System.out.println("The weather changed to " +weatherOfDay);
        }
        
        if (countstep % 40 ==0){
            if (seasonOfDay == season.SPRING){
                seasonOfDay = season.SUMMER;
            }
            else if (seasonOfDay == season.SUMMER){
                seasonOfDay = season.FALL;
            }
            else if (seasonOfDay == season.FALL){
                seasonOfDay = season.WINTER;
            }
            else{
                seasonOfDay = season.SPRING;
            }
            System.out.println("the season changed to " + seasonOfDay);
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with all actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    field.place(fox, location);
                    
                    actors.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    field.place(rabbit, location);
                    actors.add(rabbit);
                    
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    field.place(lion, location);
                    actors.add(lion);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    field.place(wolf, location);
                    actors.add(wolf);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    field.place(deer, location);
                    actors.add(deer);
                }
                else if(rand.nextDouble()<= GRASS_CREATION_PROBABILITY){
                    Location location= new Location (row, col);
                    Grass grass= new Grass(50,100, field, location);
                    field.placePlant(grass, location);

                    actors.add(grass);
                }
                else if(rand.nextDouble()<= TREE_CREATION_PROBABILITY){
                    Location location= new Location (row, col);
                    Tree tree= new Tree(50,100, field, location);
                    field.placePlant(tree, location);
                    actors.add(tree);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    public static void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

}