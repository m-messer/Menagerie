import java.util.List;
/**
 * Write a description of class Grass here.
 *
 * @version (a version number or a date)
 */
public class Grass extends Plant
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Grass
     * @param size, the plant's size, 
     * @param growRate, the grow rate every step
     * @param field, at plant field
     * @param location, the location of it
     */
    public Grass(int size, int growRate, Field field, Location location)
    {
        // initialise instance variables
        super(50,100, field, location);
    }
    
    /**
     * the act of grass. they just grow..
     * @param the list of Grass
     * @param daytime,weather, and season of a day
     */
    public void act(List<Actor> newGrass,Simulator.time dayTime,
    Simulator.weather dayWeather, Simulator.season daySeason)
    {
        size+=growRate;
    }
     /**
     * the plant is being eaten by the animal who wants it.
     * the size decreases
     * if the size gets to zero, it's dead.
     * @param animalFoodNeed, food need for the animal
     * @return
     */
    public int eat(int animalFoodNeed)
    {
        if(size>=animalFoodNeed)
        {
            size-=animalFoodNeed; 
        }
        else{
            animalFoodNeed=size;
            size=0;
            this.makeDead();
        }
        
        return animalFoodNeed;
    }
     /**
     * make this plant die
     */
    public void makeDead()
    {
        if(size==0){
            setDead();
        }
    }
}
