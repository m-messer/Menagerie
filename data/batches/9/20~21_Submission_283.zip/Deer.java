import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * /**
 * A simple model of a Deer.
 * Deers age, move, breed, and die and feed(eat)
 * 
 *
 * @version (a version number or a date)
 */
public class Deer extends Animal
{
    // instance variables - replace the example below with your own
    // Characteristics shared by all deers (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 50;
    // The age to which a deer can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //the deer's foodlevel which is increase by eating trees.
    //This is the number of steps a deer can go
    private int foodLevel;
    private static final int PLANT_NEED= 18;

    // Individual characteristics (instance fields).

    // The deer's age.
    private int age;

    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        foodLevel = 30;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    } 

    /**
     * This is what the deer does most of the time - it runs 
     * around and eats trees. Sometimes it will breed or die of old age.
     * @param newDeers A list to return newly born deers.
     * @param daytime,weather, and season of a day
     * 
     */
    public void act(List<Actor> newDeers,Simulator.time dayTime,
    Simulator.weather dayWeather, Simulator.season daySeason)
    {
        incrementAge();
        if(isAlive()&& dayTime != dayTime.NIGHT) {
            if (dayWeather != dayWeather.RAINY&&daySeason!=daySeason.WINTER){
                if (findMate()){
                    giveBirth(newDeers);
                }
            }

            Location newLocation = findFood();

            if(newLocation == null) { 
                    // No food found - try to move to a free location.
                  newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                 setLocation(newLocation);
            }
            else {
                    // Overcrowding.
                  setDead();
            }
                incrementHunger();
            }
    }
     /**
     * look for trees to eat and move to the location where tree was at
     * when tree is eaten, set tree to die and it disapper
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Plant plant= field.getPlantAt(where);
            if(plant instanceof Tree) {
                Tree tree = (Tree) plant;
                if(tree!=null &&tree.isAlive()) { 
                    int plantLevel=tree.eat(PLANT_NEED);
                    foodLevel =plantLevel;
                    return where;
                }
            }
        }
        return null;
    }
    
     /**
     * Make this deer more hungry. This could result in the deer's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    /**
     * find mate and this restriction on give birth.
     * only when a true and false(male and female) are next to each other, 
     * it can give birth
     * @return boolean (whether it found a mate)
     */
    private Boolean findMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive() && deer.whatGender()!=this.whatGender()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Increase the age.
     * This could result in the deer's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeers A list to return newly born deer.
     */
    private void giveBirth(List<Actor> newDeers)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc);
            newDeers.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A deer can breed if it has reached the breeding age.
     * @return true if the deer can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}