import java.util.List;
import java.util.ArrayList;
/**
 * Write a description of interface Actor here.
 *
 * @version (a version number or a date)
 */
public interface Actor
{
    /**
     * An example of a method header - replace this comment with your own
     *
     * @param  y a sample parameter for a method
     * @return   the result produced by sampleMethod
     */
    void act(List<Actor> newActors,Simulator.time dayTime,
    Simulator.weather dayWeather, Simulator.season daySeason);
    
    boolean isAlive();
}
