import java.util.Random;

/**
 * This class is used for conditions that will influence the acts 
 * of creatures. Weather, Time
 * @version 2020/02/20 
 */
public class Condition
{
    // Current time is day or night
    private static boolean dayTime;
    // Hours of the day, initialize at morning
    private static double hours = 6;
    // Time elapses for one step
    private static double timePerStep = 0.25;
    // int value for weather. 0 for drought, 1 for normal, 2 for wet
    private static int weather = 1;
    // generate Random value for weather
    private static Random rand = Randomizer.getRandom();
    
    /**
     * update time and weather when this is called, 
     * each update is 15 minutes.
     * weather changes each day
     */
    public static void update()
    {
        hours += timePerStep;
        if((hours >= 6) && (hours <= 18))
            dayTime = true;
        else
            dayTime = false;
        
        if(hours == 24) 
        {
            hours = 0;
            double weatherDouble = rand.nextDouble();
            if(weatherDouble < 0.25)
                weather = 0;
            else if(weatherDouble > 0.75)
                weather = 2;
            else
                weather = 1;
        }
        
    }
    
    /**
     * @return int value represents weather condition 
     */
    public static int getWeather()
    {
        return weather;
    }
    
    /**
     * @return a boolean value, true for day and false for night
     */
    public static boolean getIfDay()
    {
        return dayTime;
    }
    
    /**
     * @return an int value for hour of the day, 24 hours representation
     */
    public static int getHours()
    {
        return (int)hours;
    }
}
