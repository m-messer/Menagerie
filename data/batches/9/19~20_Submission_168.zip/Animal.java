import java.util.*;
import java.util.Random;
import javafx.util.Pair;
/**
 * this class is to represent common characteristics and acts for animals
 */
public abstract class Animal extends Creature
{
    //The gender of the animal
    protected boolean isMale;
    //Whether the animal is infected by disease
    protected boolean ill = false;
    //Random generator
    private static final Random rand = Randomizer.getRandom();
    //The probability that this animal is the source of disease.
    protected static final double ILL_PROBABILITY = 0.005;
    //The probability that infected animal can cure themselves is one step.
    protected static final double CURE_PROBABILITY = 0.01;
    //the steps take of an infected animal die.
    protected static final int KILLED_BY_DISEASE = 7;
    //the gender probability is even as male or female
    private static final double MALE_PROBABILITY = 0.5;
    //all the animals are created with zero ill level
    protected int illLevel = 0;
    //current foodlevel of animals, die if it reaches 0
    protected int foodLevel;
    
    /**
     * @param Field and location of this animal
     */
    public Animal(Field field , Location location )
    {
        super(field , location);
        double ran = rand.nextDouble();
        //gender of new born animal
        if(ran <= MALE_PROBABILITY)
        {
            isMale = true;
        }
        else
        {
            isMale = false;
        }
    }
    
    /**
     * @return boolean value true for male and false for female
     */
    protected boolean getGender()
    {
        return isMale;
    }
    
    /**
     * this animal is infected by the disease
     */
    protected void setIll()
    {
        ill = true;
    }
    
    /**
     * the animal is cured.
     */
    protected void cure()
    {
        ill = false;
        illLevel = 0;
    }
    
    /**
     * @return boolean value whether animal is infected by the disease
     */
    protected boolean isIll()
    {
        return ill;
    }
    
    /**
     * Check if illLevel reach the limit and kill the animal, 
     * and there's a possibility an animal is cured by itself.
     */
    protected void illness()
    {
        if(isAlive())
        {
            if(isIll())
            {
                illLevel++;
                if(illLevel > KILLED_BY_DISEASE)
                {
                setDead();
                }
                else
                {
                findInfect(); 
                if(rand.nextDouble() < CURE_PROBABILITY)
                {
                    cure();
                }
             }
        }
            else
            {
                if(rand.nextDouble() < ILL_PROBABILITY)
                {
                    setIll();
                }
            }
        }
        else 
            return;
    }
    
    /**
     * @return a iterator of locations around where this animal is located
     */
    protected Iterator<Location> adjacentIterator()
    {
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        return it;
    }
    
    /**
     * Make this Dragonfly more hungry. This could result in the Dragonfly's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) 
        {
            setDead();
        }
    }
    public abstract void act(List<Creature> animal);
    
    public abstract void findInfect();
}
