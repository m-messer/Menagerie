import java.util.Random;

/**
 * A simple model of a fish.
 * Fish age, move, breed, eat fish and die.
 *
 * @version 2016.02.29 (2)
 */
public class Fish extends Animal {
    // Characteristics shared by all fish (class variables).

    // The age at which a fish can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a fish can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a fish breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // number of steps an animal can go after eating fish
    private static final int FOOD_VALUE = 20;
    // The maximum foodLevel an animal can have
    private static final int MAX_FOOD = 80;
    // The probability that a fish will be created in any given grid position.
    protected static final double CREATION_PROBABILITY = 0.1;
    // Do fish sleep
    private static final boolean ANIMAL_SLEEPS = false;
    // Individual characteristics (instance fields).

    /**
     * Create a new fish. A fish may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the fish will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Fish(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD);
        } else {
            age = 0;
            foodLevel = MAX_FOOD;
        }
    }

    /**
     * Get the animal's max age before it dies.
     *
     * @return MAX_AGE for this animal
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Get the animal's food_value.
     *
     * @return FOOD_VALUE for this animal
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * Get if animal sleeps.
     *
     * @return ANIMAL_SLEEPS for this animal
     */
    protected boolean getDoesAnimalSleep() {
        return ANIMAL_SLEEPS;
    }

    /**
     * See if the organism is edible.
     *
     * @param organismToCheck  The organism being checked.
     * @return true if the organism is edible
     */
    protected boolean isEdible(Organism organismToCheck) {
        if (organismToCheck instanceof Plant) {
            Plant plant = (Plant) organismToCheck;
            return plant.isAlive();
        }
        return false;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fish can breed if it has reached the breeding age.
     *
     * @return true if the fish can breed, false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
}
