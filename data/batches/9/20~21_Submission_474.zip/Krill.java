import java.util.Random;

/**
 * A simple model of a krill.
 * Krill age, move, breed, eat plants, and die.
 *
 * @version 2021.02.25
 */
public class Krill extends Animal {
    // Characteristics shared by all krill (class variables).

    // The age at which a krill can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a krill can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a krill breeding.
    private static final double BREEDING_PROBABILITY = 0.70;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // number of steps an animal can go after eating krill
    private static final int FOOD_VALUE = 10;
    // The maximum foodLevel an animal can have
    private static final int MAX_FOOD = 80;
    // The probability that a krill will be created in any given grid position.
    protected static final double CREATION_PROBABILITY = 0.05;
    // Do the krill sleep
    private static final boolean ANIMAL_SLEEPS = false;
    // Individual characteristics (instance fields).


    /**
     * Create a new krill. A krill may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the krill will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Krill(boolean randomAge, Field field, Location location) {
        super(field, location);
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD);
        } else {
            age = 0;
            foodLevel = MAX_FOOD;
        }
    }

    /**
     * See if the organism is edible.
     *
     * @param organismToCheck  The organism being checked.
     * @return true if the organism is edible
     */
    protected boolean isEdible(Organism organismToCheck) {
        if (organismToCheck instanceof Plant) {
            Plant plant = (Plant) organismToCheck;
            return plant.isAlive();
        }
        return false;
    }

    /**
     * Get the animal's max age before it dies.
     *
     * @return MAX_AGE for this animal
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Get the animal's food_value.
     *
     * @return FOOD_VALUE for this animal
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * Get if animal sleeps.
     *
     * @return ANIMAL_SLEEPS for this animal
     */
    protected boolean getDoesAnimalSleep() {
        return ANIMAL_SLEEPS;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A krill can breed if it has reached the breeding age.
     *
     * @return true if the krill can breed, false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
}
