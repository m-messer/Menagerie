import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Organism {
    // Probability of finding food at night
    private static final double NIGHT_EAT_PROBABILITY = 0.05;
    // Probability of finding food in the day
    private static final double DAY_EAT_PROBABILITY = 0.9;
    // Reducing probability
    private static final double BREEDING_FOOD_REDUCTION = 0.4;
    // Radius within which animals will search for mates
    private static final int BREEDING_RADIUS = 4;
    // Radius within which animals will search for food
    private static final int FEEDING_RADIUS = 2;
    // Multiplier of breeding occurring during a storm
    private static final double STORMY_BREEDING_MULTIPLIER = 0.7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The animal's food level, which is increased by eating.
    protected int foodLevel;
    // The animal's age.
    protected int age;
    // If the animal can give birth.
    protected boolean female;

    /**
     * Create a new animal at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        super(field, location);
        setLocation(location);
        // 0.5 probability to be male/female.
        female = rand.nextBoolean();
    }

    /**
     * Looks at the animal and conducts operations such as breeding, eating,
     * moving and dying.
     *
     * @param newAnimals A list to return newly born penguins.
     * @param isNight A boolean value of if it is day or night.
     * @param isStormy A boolean value of if it is stormy.
     */
    public void act(List<Animal> newAnimals, boolean isNight, boolean isStormy) {
        if (isAlive()) {
            if (shouldBreed(isStormy)) {
                giveBirth(newAnimals);
            }
            // if the animal is not asleep
            if (!isNight || !getDoesAnimalSleep()) {
                Organism organismToEat = null;
                if (isNight && rand.nextDouble() <= NIGHT_EAT_PROBABILITY) {
                    // looks for food at night
                    organismToEat = findFood();
                } else if (!isNight && rand.nextDouble() <= DAY_EAT_PROBABILITY) {
                    // looks for food in the day
                    organismToEat = findFood();
                }

                Location newLocation;
                if (organismToEat != null) {
                    // checks for any organisms to eat
                    newLocation = organismToEat.location;
                    eat(organismToEat);
                } else {
                    // if no food found
                    newLocation = field.freeAdjacentLocation(location);
                }

                if (newLocation != null) {
                    // move to new location
                    setLocation(newLocation);
                    incrementHunger();
                } else {
                    // nowhere to move
                    setDead();
                }
            }
            incrementAge();
        }
    }

    /**
     * Are the breeding conditions for the animal met.
     *
     * @param isStormy A boolean value of if it is stormy.
     * @return true if the animal can breed.
     */
    private boolean shouldBreed(boolean isStormy) {
        return (female && !isStormy) || (female && rand.nextDouble() <= STORMY_BREEDING_MULTIPLIER);
    }

    /**
     * The animal eats the organism.
     *
     * @param organismToEat The organism to set dead.
     */
    private void eat(Organism organismToEat) {
        foodLevel += organismToEat.getFoodValue();
        organismToEat.setDead();
    }

    /**
     * Look for food adjacent in radius to the current location.
     * Only the first alive food is eaten.
     *
     * @return The organism to be eaten.
     */
    private Organism findFood() {
        List<Location> adjacent = field.adjacentLocations(location, FEEDING_RADIUS);
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Organism organism = field.getObjectAt(where);
            if (isEdible(organism)) {
                return organism;
            }
        }
        return null;
    }

    /**
     * Get if the organism is edible.
     *
     * @return true if organism is edible
     */
    abstract boolean isEdible(Organism organismToCheck);

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newAnimals A list to return newly born animal(s).
     */

    private void giveBirth(List<Animal> newAnimals) {
        if (proportionHealth() > BREEDING_FOOD_REDUCTION) {
            Class animalType = this.getClass();
            Constructor[] constructors = animalType.getConstructors();
            try {
                List<Location> free = field.getFreeAdjacentLocations(location);
                List<Location> mates = field.getAdjacentLocationsWithAnimal(location, BREEDING_RADIUS, animalType);
                int births = breed();
                if (mates.size() > 0) {
                    // Food level reduces when breeding
                    foodLevel *= (1 - BREEDING_FOOD_REDUCTION);
                    for (int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Animal young = (Animal) constructors[0].newInstance(false, field, loc);
                        newAnimals.add(young);
                    }
                }
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Get the health proportion.
     *
     * @return health proportion for the animal.
     */
    private double proportionHealth() {
        return (double) foodLevel / getFoodValue();
    }

    /**
     * Get the animals food value.
     *
     * @return default FOOD_VALUE
     */
    abstract int getFoodValue();

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    abstract int breed();

    /**
     * Get a boolean value representing if an animal sleeps,
     *
     * @return ANIMAL_SLEEPS for the animal.
     */
    abstract boolean getDoesAnimalSleep();

    /**
     * Get the animals max age before it dies.
     *
     * @return default MAX_AGE
     */
    abstract int getMaxAge();

    /**
     * Increment the age. This could result in the animal's death.
     */
    protected void incrementAge() {
        age++;
        if (age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Increment animals hunger. This could result in the animal's death.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    public boolean getIsFemale() { return female; }

    /**
     * Place the animal at the new location in the given field.
     *
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
}
