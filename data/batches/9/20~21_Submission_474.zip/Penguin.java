import java.util.Random;

/**
 * A simple model of a penguin.
 * Penguin age, move, eat fish or krill, and die.
 *
 * @version 2021.02.25
 */
public class Penguin extends Animal {
    // Characteristics shared by all penguins (class variables).

    // The age at which a penguin can start to breed.
    private static final int BREEDING_AGE = 40;
    // The age to which a penguin can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a penguin breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // number of steps an animal can go after eating a penguin
    private static final int FOOD_VALUE = 80;
    // The maximum foodLevel an animal can have
    private static final int MAX_FOOD = 300;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The probability that a penguin will be created in any given grid position.
    protected static final double CREATION_PROBABILITY = 0.01;
    // Do penguins sleep
    private static final boolean ANIMAL_SLEEPS = false;

    /**
     * Create a penguin. A penguin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the penguin will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Penguin(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD);
        } else {
            age = 0;
            foodLevel = MAX_FOOD;
        }
    }

    /**
     * Get the animal's max age before it dies.
     *
     * @return MAX_AGE for this animal
     */
    protected int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Get the animal's food_value.
     *
     * @return FOOD_VALUE for this animal
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * See if the organism is edible.
     *
     * @param organismToCheck  The organism being checked.
     * @return true if the organism is edible
     */
    protected boolean isEdible(Organism organismToCheck) {
        if (organismToCheck instanceof Fish) {
            Fish fish = (Fish) organismToCheck;
            return fish.isAlive() && foodLevel < MAX_FOOD;
        } else if (organismToCheck instanceof Krill) {
            Krill krill = (Krill) organismToCheck;
            return krill.isAlive() && foodLevel < MAX_FOOD;
        }
        return false;
    }

    /**
     * Get if animal sleeps.
     *
     * @return ANIMAL_SLEEPS for this animal
     */
    protected boolean getDoesAnimalSleep() {
        return ANIMAL_SLEEPS;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A penguin can breed if it has reached the breeding age.
     */
    protected boolean canBreed() {
        return age >= BREEDING_AGE;
    }

}
