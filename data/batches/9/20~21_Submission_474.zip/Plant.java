/**
 * A simple model of a plant.
 * Plants spawn randomly on the grid for animals to consume.
 *
 * @version 2021.02.26
 */
public class Plant extends Organism{
    // Counts the amount of plants created, used to create required number of plants
    private static int totalPlants = 0;
    // number of steps an animal can go after eating a plant
    private static final int FOOD_VALUE = 50;

    /**
     * Create a new plant at location in field
     *
     * @param field Grid on which the plant lies.
     * @param location Location within the grid.
     */
    public Plant(Field field, Location location) {
        super(field, location);
        totalPlants++;
    }

    /**
     * get the total number of plants in the simulation.
     *
     * @return number of plants.
     */
    public static int getTotalPlants() { return totalPlants; }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    @Override
    protected void setDead() {
        super.setDead();
        totalPlants--;
    }

    /**
     * get the plant's food value.
     *
     * @return The plant's foodValue.
     */
    protected int getFoodValue() {
        return FOOD_VALUE;
    }

    /**
     * return false as plants are neither male or female.
     *
     * @return true if plants female.
     */
    protected boolean getIsFemale() { return false; }
    
    /**
     * resets totalPlants
     */
    protected static void resetTotalPlant() {
        totalPlants = 0;
    }
}
