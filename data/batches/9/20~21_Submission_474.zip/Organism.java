public abstract class Organism {

    // Whether the organism is alive or not.
    private boolean isAlive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;

    /**
     * Create a new organism at location in field
     *
     * @param field Grid on which the organism lies.
     * @param location Location within the grid.
     */
    public Organism(Field field, Location location)
    {
        this.field = field;
        this.location = location;
        isAlive = true;
    }

    /**
     * Return the organism's field.
     *
     * @return The organism's field.
     */
    protected boolean isAlive() {
        return isAlive;
    }

    /**
     * get the organism's food value.
     *
     * @return The organism's foodValue.
     */
    abstract int getFoodValue();

    /**
     * return if organism is male or female.
     *
     * @return true if the organism is female.
     */
    abstract boolean getIsFemale();

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        isAlive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
}
