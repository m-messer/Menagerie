import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 *
 * @version 2016.02.29 (2)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The default steps for one day.
    private static final int STEPS_IN_DAY = 50;
    // Maximum amount of plants in the simulation.
    private static final int MAX_PLANTS = 3000;
    // Minimum storm length
    private static final int MIN_STORM_LENGTH = 40;
    // Maximum storm length
    private static final int MAX_STORM_LENGTH = 80;
    // Chance of storm starting
    private static final double STORM_START_CHANCE = 0.005;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Amount of time until storm stops
    private int stormTimeRemaining = 0;

    /**
     * Run the simulator with 10000 steps.
     */
    public static void main(String[] args) {
        Simulator sim = new Simulator();
        sim.simulate(10000);
    }

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        view.setColor(Krill.class, new Color(255, 0, 0));
        view.setColor(Fish.class, Color.ORANGE);
        view.setColor(Penguin.class, new Color(0, 138, 165));
        view.setColor(Albatross.class, new Color(155, 155, 0));
        view.setColor(KillerWhale.class, new Color(0, 0, 0));
        view.setColor(Plant.class, new Color(0, 255, 0));

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
              simulateOneStep();
        //delay(1000);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public void simulateOneStep() {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Let all animals act.
        for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();

            animal.act(newAnimals, isNight(), isStormy());
            if (!animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born penguins and Fish to the main lists.
        animals.addAll(newAnimals);

        plantSpread();

        stormTick();

        view.showStatus(step, isNight(), isStormy(), field);
    }

    /**
     * Increments the storm or may create a storm if its not stormy.
     */
    private void stormTick() {
        if (!isStormy() && rand.nextDouble() <= STORM_START_CHANCE) {
            stormTimeRemaining = MIN_STORM_LENGTH + rand.nextInt(MAX_STORM_LENGTH - MIN_STORM_LENGTH);
        }
        stormTimeRemaining--;
    }

    /**
     * Grows MAX_PLANTS plants in the simulation.
     */
    private void plantSpread() {
        List<Location> emptyLocations = field.getEmptyLocations();
        while (Plant.getTotalPlants() < MAX_PLANTS && !emptyLocations.isEmpty()) {
            field.place(new Plant(field, emptyLocations.get(0)), emptyLocations.get(0));
            emptyLocations.remove(0);
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        Plant.resetTotalPlant();
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, isNight(), isStormy(), field);
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if (rand.nextDouble() <= KillerWhale.CREATION_PROBABILITY) {
                    animals.add(new KillerWhale(true, field, location));
                } else if (rand.nextDouble() <= Albatross.CREATION_PROBABILITY) {
                    animals.add(new Albatross(true, field, location));
                } else if (rand.nextDouble() <= Penguin.CREATION_PROBABILITY) {
                    animals.add(new Penguin(true, field, location));
                } else if (rand.nextDouble() <= Fish.CREATION_PROBABILITY) {
                    animals.add(new Fish(true, field, location));
                } else if (rand.nextDouble() <= Krill.CREATION_PROBABILITY) {
                    animals.add(new Krill(true, field, location));
                }
                // else leave the location empty.
            }
        }
        // add plants
        plantSpread();
    }

    /**
     * Pause for a given time.
     *
     * @param millisecond The time to pause for, in milliseconds
     */
    private void delay(int millisecond) {
        try {
            Thread.sleep(millisecond);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Is simulation day or night.
     *
     * @return true for night, false for day
     */
    private boolean isNight() {
        return step % STEPS_IN_DAY <= STEPS_IN_DAY / 2;
    }

    /**
     * Is simulation stormy.
     *
     * @return true for stormy, false for not stormy
     */
    private boolean isStormy() {
        return stormTimeRemaining > 0;
    }
}
