import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
/**
 * The class plants holds information regarding the plants, food for prey.
 *
 * @version 2019.02.17 (2)
 */
public class Plants 
{   
    //the food value of a plant
    private static final int FOOD_VALUE = 10; 
    private Location location; 
    private Field field; 
    private boolean alive; 
    /**
     * Constructor of class Plants.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(Field field, Location location)
    {
        this.field = field; 
        setLocation(location);
        alive = true; 
    }
 
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    { 
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     *  Return the food value of a plant.
     */
    public int FoodValue()
    { return FOOD_VALUE;}
    
    /**
     *  Make the plants fields grow.
     *  @param newPlants The list for new plants created.
     *  @param weather The current weather type.
     */
    public List<Plants> grow(Weather weather)
    {  
        List<Plants> newPlants = new ArrayList<>();
        int growthRate = 0; 
        if(isAlive())
        {
            List<Location> free = field.getFreeAdjacentLocations(location);
            if(weather instanceof Rain)   
                {growthRate = 5;}
            else if (weather instanceof Sunny){ growthRate = 3; }
        
            for(int b = 0; b < growthRate && free.size() > 0; b++) {
              Location loc = free.remove(0);
              Plants plant = new Plants(field, loc); 
              newPlants.add(plant);
             }
            }
          return newPlants;
    }
    
    /**
     *  Set the plant to dead when it has been eaten.
     */
    public void SetDead()
    {
        alive = false; 
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     *  @return true if plant is alive and false otherwise. 
     */
    public boolean isAlive()
    {
        return alive; 
    }
}