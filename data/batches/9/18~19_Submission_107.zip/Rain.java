/**
 * A class that implements the Weather interface, it is a type of weather. 
 *
 * @version (2019.02.21)
 */
public class Rain implements Weather
{
    /**
     * Constructor for objects of class Rain
     */
    public Rain()
    {
    }
 
    /**
     *  @return true if the animal can act during the day on the specific weather, false if not.
     */
    public boolean DayTime(Field field, Location location)
    {
        Object object = field.getObjectAt(location);
        if(object instanceof Animal){ Animal animal = (Animal) object; 
        if(animal instanceof Snake || animal instanceof Sparrow) return false;}
        return true;  
    }
    
    /**
     *  @return true if the animal can act during the night on the speicific weather, false if not.
     */
    public boolean NightTime(Field field, Location location)
    {
        Object object = field.getObjectAt(location);
        if(object instanceof Animal) {Animal animal = (Animal) object; 
        if(animal instanceof Cat || animal instanceof Sparrow ) return false;} 
        return true;
    }
}