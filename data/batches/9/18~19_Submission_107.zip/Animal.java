import java.util.List;
import java.util.Random; 
import java.util.ArrayList; 
import java.util.Iterator;
import java.lang.instrument.ClassDefinition;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;
    private String gender; 
    private static final Random rand = Randomizer.getRandom();
    private int age; 
    private int foodLevel;
    private boolean healthy;
    private Simulator simulator;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param RandomAge Tells if the age is chosen randomly or specified 
     * @param infectedFromBirth Tells if the animal is infected from birth 
     * or not (born from an infected mother).
     */
    public Animal(boolean infectedFromBirth,boolean RandomAge,Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        gender = Gender(); 
        if(RandomAge) { this.age = rand.nextInt(MaxAge()); 
                 foodLevel = rand.nextInt(FoodValue());}
        foodLevel = FoodValue(); 
        gender = GetGender();
        if(!infectedFromBirth) healthy=Healthy();
        else healthy = false;
    }
    
   /**
     * This is what the predator does most of the time: it searches for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @return the list of new born animals
     */
    public List<Animal> act()
    {   
        List<Animal> newAnimals = new ArrayList<>();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
           newAnimals.addAll(giveBirth());            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(location);
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        
        }
       return newAnimals; 
    }
    
    /**
     *  @param day Determine if it's day or night
     *  @param weather The current type of weather 
     *  @return true if can move and false otherwise.
     */
    public boolean CanMove(Weather weather, boolean day)
    {
        if(day && weather.DayTime(getField(), getLocation())) return true; 
        if(!day && weather.NightTime(getField(), getLocation())) return true; 
        return false; 
    }
    
    /**
     *  The abstract methods of the class.
     */
    abstract protected double BreedingProbability();
    
    abstract protected int BreedingAge();
    
    abstract protected Location findFood();
    
    abstract protected int LitterSize();
    
    abstract protected int FoodValue();
    
    abstract protected boolean testNeighbor(Animal animal);
    
    abstract protected int MaxAge();
    
    abstract protected Animal newBaby(Location location, Field field);

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @return the list of new animals
     */
    public List<Animal> giveBirth()
    {
        // New preys are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Animal> newAnimals = new ArrayList<>();
        List<Location> free = field.getFreeAdjacentLocations(location);
        int births = NrOfBirths();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newAnimals.add(newBaby(loc, field));
        }
        return newAnimals;
    }
    
   /**
    * @returns true of an adjacent partner for breeding. The 
    * partner must be of opposite gender and breeding age and the same type of animal. 
    */
   public boolean FindAdjacentPartner()
    {   
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object neighbor = field.getObjectAt(where);
            if(neighbor != null && neighbor instanceof Animal)
              {  
                  Animal partner = (Animal) neighbor;
                  if(testNeighbor(partner))
               {   
                if(partner.GetGender() != GetGender() && 
                   partner.getAge()>= partner.BreedingAge())
                { partner.SetHealthy(GetHealthy()); return true;}
               }
            }
           }
        return false; 
    }
    
    /**
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     *  @return true if it is over breeding age and found a suitable partner 
     */
    private boolean CanGetPregnant()
    {   
      if(getAge()>BreedingAge() && FindAdjacentPartner())
      { return true; }
      return false;
    }
    
    /**
     * @return The number of possible births (may be zero).
     */
    protected int NrOfBirths()
    {
        int births = 0;
        if(CanGetPregnant() && rand.nextDouble() <= BreedingProbability()) {
            births = rand.nextInt(LitterSize()) + 1;
        }
        return births;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MaxAge()) {
            setDead();
        }
    }
    
    /**
     * @return the age of the animal.
     */
    public int getAge()
    {return age;}
    
    /**
     *  Set the food value to the one of the eaten food.
     */
    protected void SetFoodValue(int food)
    {
        foodLevel += food; 
    }
    
    /**
     *  Increments the hunger of the animal.
     */
    protected void incrementHunger()
    { 
      foodLevel --;
      if(foodLevel<=0) setDead();
    }

    /**
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    { 
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Choose the animal's gender.
     */
    private String Gender()
    {
        Random ran = new Random(); 
        if(ran.nextInt(2) == 0) return "female"; 
        return "male"; 
    }
    
    /**
     * @return true if animal is healthy and false otherwise.
     */
    protected boolean Healthy()
    {
        if(location.getRow()== 1 && location.getCol() == 1) return false; 
        return true; 
    }
    
    /**
     *  @return the animal's gender.
     */
    public String GetGender()
    {return gender;}
      
    /**
     * @return the health status of the animal.
     */
    protected boolean GetHealthy()
    {
        return healthy; 
    }
    
    /**
     *  Set the healthy variable when meeting another animal.
     */
    protected void SetHealthy(boolean health)
    {
        healthy = health;
    }
}
