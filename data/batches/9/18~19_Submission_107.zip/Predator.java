import java.util.ArrayList; 
import java.util.Random; 
import java.util.List; 
import java.util.Iterator;
/**
 * Abstract class Predator - This class is characteristic for all predatos, it
 * includes functions that apply to all predators. 
 *
 * @version (2019.02.08)
 */
public abstract class Predator extends Animal
{
   /** 
     *  This is the constructor of the abstract class Predator.
     *  @param infectedFromBirth Specify if animal is infected at birth.
     *  @param RandomAge Specify if the age is random or not.
     *  @param field The field currently occupied. 
     *  @param location The location currently occupied.
     */
    public Predator(boolean infectedFromBirth, boolean RandomAge, Field field, Location location)
    {
        super(infectedFromBirth, RandomAge,field, location); 
    }
    
   /**
     * Look for rats adjacent to the current location.
     * Only the first alive rat is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.isAlive()) { 
                    rat.setDead();
                    SetFoodValue(rat.FoodValue());
                    return where;
                }
            }
            if(animal instanceof Sparrow) {
                Sparrow spr = (Sparrow) animal;
                if(spr.isAlive()) { 
                    spr.setDead();
                    SetFoodValue(spr.FoodValue());
                    return where;
                }
            }
        }
        return null;
    }
}
