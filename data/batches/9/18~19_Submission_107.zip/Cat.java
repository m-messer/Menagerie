import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * The class cat holds characteristics for the type cat of predator. 
 *
 * @version 2016.02.29 (2)
 */
public class Cat extends Predator
{
    // Characteristics shared by all cats (class variables).
    
    // The age at which a cat can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a cat can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a cat breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single cat. In effect, this is the
    // number of steps a cat can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    /**
     *  This is the constructor of the class Cat, inherited from Predator.
     *  @param infectedFromBirth Specify if animal is infected at birth.
     *  @param RandomAge Specify if the age is random or not.
     *  @param field The field currently occupied. 
     *  @param location The location currently occupied.
     */
    public Cat(boolean infectedFromBirth, boolean RandomAge, Field field, Location location)
    {
        super(infectedFromBirth, RandomAge, field, location);
    }
    
    /**
     *  @param An animal to be tested 
     *  @return true if the parameter is of class Cat
     */
    public boolean testNeighbor(Animal animal)
    {
        if(animal instanceof Cat) return true;
        return false; 
    }
    
    /**
     *  @return a new cat.
     */
    public Cat newBaby(Location location, Field field)
    {
        return new Cat(!GetHealthy(), false, field, location);
    }
    
    /**
     * @return maximum living age of a cat.
     */
    public int MaxAge()
    {return MAX_AGE;}
    
    /**
     * @return the food value of a cat.
     */
    public int FoodValue()
    { return FOOD_VALUE;}
    
    /** 
     * @return the breeding age of a cat.
     */
    public int BreedingAge()
    { return BREEDING_AGE;}
    
    /**
     *  @return the breeding probability of a cat.
     */
    public double BreedingProbability()
    {return BREEDING_PROBABILITY;}
    
    /**
     * @return the litter size of a cat.
     */
    public int LitterSize()
    {return MAX_LITTER_SIZE;}
}
