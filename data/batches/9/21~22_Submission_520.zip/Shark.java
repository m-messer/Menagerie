import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a shark.
 * shark age, move, eat tunas, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Shark extends Animal
{
    // Characteristics shared by all shark (class variables).
    
    // The age at which a shark can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a shark can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a shark breeding.
    private static final double BREEDING_PROBABILITY = 0.65;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single tuna. In effect, this is the
    // number of steps a shark can go before it has to eat again.
    private static final int TUNA_FOOD_VALUE = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    private int age;
    private int foodLevel;
    private boolean IS_FEMALE;
    /**
     * Create a shark. A shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level. it may also be created with a random sex
     * it also has a chance of having a disease when it spawns, unless its parent
     * already had the disease when it bred it.
     * 
     * @param randomAge If true, the shark will have a random age.
     * @param randomSex If true, the shark will have a random sex.
     * @param randomDisease If true, the shark will have a random chance of having a disease.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shark(boolean randomAge,boolean randomSex,Boolean randomDisease, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(TUNA_FOOD_VALUE);
        }
        
        if(randomSex) {
            int sex = rand.nextInt(2);
            if(sex == 1){
                IS_FEMALE = true;
            }
            else{
                IS_FEMALE = false;
            }
        }
        
        if (randomDisease) {
            int diseaseChance = rand.nextInt(1000);
            if (diseaseChance == 0) {
                disease = true;
            }
            else {
                disease = false;
            }
        }
        else{
            disease = true;
        }
            foodLevel = TUNA_FOOD_VALUE;
    }
    
    
    /**
     * This is what the shark does most of the time: it hunts for
     * tuna. In the process, it might breed, die of hunger,
     * or die of old age. when moving it can replace plankton if they occupy a spot
     * 
     * @param field The field currently occupied.
     * @param newSharks A list to return newly born sharks.
     */
    public void act(List<Animal> newSharks)
    {   
        actDisease();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSharks);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().randomAdjacentLocation(getLocation());
                if(getField().getObjectAt(newLocation) == null){
                    setLocation(newLocation);
                }
                else {
                    boolean plankLocation = checkPlankton(newLocation);
                    if (plankLocation == true) {
                        setLocation(newLocation);
                    }
                    else{
                        setDead();
                    }
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the sharks's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this shark more hungry. This could result in the shark's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Make this shark suffer from the disease.this will make them more hungry and age them quicker
     * resulting in a quicker death.
     */
    private void actDisease(){
        if(this.disease == true){
            incrementAge();
            incrementAge();
            incrementHunger();
        }

    }
    
    /**
     * Look for tuna adjacent to the current location.
     * Only the first live tuna is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Tuna) {
                Tuna tuna = (Tuna) animal;
                if(tuna.isAlive()) { 
                    if(tuna.disease == true){
                        this.disease = true;
                    }
                    tuna.setDead();
                    foodLevel = TUNA_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this shark is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSharks A list to return newly born sharks.
     */
    private void giveBirth(List<Animal> newSharks)
    {
        // New sharks are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Shark> adjacentSharks = new ArrayList<>();
        Field field = getField();
        List<Location> sharkCheck = field.adjacentLocations(getLocation());
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for (int i = 0; i < sharkCheck.size(); i++) {  
            if(field.getObjectAt(sharkCheck.get(i)) instanceof Shark) {
                Shark newShark = Shark.class.cast(field.getObjectAt(sharkCheck.get(i)));
                adjacentSharks.add(newShark);
            }
        }
               
        for (int j = 0; j < adjacentSharks.size(); j++) {            
            if (adjacentSharks.get(j).IS_FEMALE != this.IS_FEMALE) {
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    if(this.disease == true){
                        Shark young = new Shark(false, true, false, field, loc);
                        newSharks.add(young);
                    }
                    else{
                        Shark young = new Shark(false, true, true, field, loc);
                        newSharks.add(young);
                    }
                }    
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A shark can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
