import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a whale.
 * whale age, move, eat squids, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Whale extends Animal
{
    // Characteristics shared by all whale (class variables).
    
    // The age at which a whale can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a whale can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a whale breeding.
    private static final double BREEDING_PROBABILITY = 0.65;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single squid. In effect, this is the
    // number of steps a whale can go before it has to eat again.
    private static final int SQUIDZINO_FOOD_VALUE = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    private int age;
    private int foodLevel;
    private boolean IS_FEMALE;
    /**
     * Create a octopus. A octopus can be created as a new born (age zero
     * and not hungry) or with a random age and food level. it may also be created with a random sex
     * it also has a chance of having a disease when it spawns, unless its parent
     * already had the disease when it bred it.
     * 
     * @param randomAge If true, the octopus will have a random age.
     * @param randomSex If true, the octopus will have a random sex.
     * @param randomDisease If true, the octopus will have a random chance of having a disease.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Whale(boolean randomAge,boolean randomSex, boolean randomDisease, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SQUIDZINO_FOOD_VALUE);
        }
        
        if(randomSex) {
            int sex = rand.nextInt(2);
            if(sex == 1){
                IS_FEMALE = true;
            }
            else{
                IS_FEMALE = false;
            }
        }
        
        if (randomDisease) {
            int diseaseChance = rand.nextInt(1000);
            if (diseaseChance == 0) {
                disease = true;
            }
            else {
                disease = false;
            }
        }
        else{
            disease = true;
        }
        foodLevel = SQUIDZINO_FOOD_VALUE;
    }
    
    /**
     * This is what the whale does most of the time: it hunts for
     * squid. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param field The field currently occupied.
     * @param newWhales A list to return newly born whales.
     */
    public void act(List<Animal> newCumWhales)
    {   
        actDisease();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newCumWhales);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().randomAdjacentLocation(getLocation());
                if(getField().getObjectAt(newLocation) == null){
                   setLocation(newLocation);
                }
                else {
                    boolean plankLocation = checkPlankton(newLocation);
                    if (plankLocation == true) {
                        setLocation(newLocation);
                    }
                    else{
                        setDead();
                    }
                }                   
            }
        }
    }

    /**
     * Increase the age. This could result in the whale's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this whale more hungry. This could result in the whale's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Make this whale suffer from the disease.this will make them more hungry and age them quicker
     * resulting in a quicker death.
     */
    private void actDisease(){
        if(this.disease == true){
            incrementAge();
            incrementAge();
            incrementHunger();
        }

    }
    
    /**
     * Look for squid adjacent to the current location.
     * Only the first live squid is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squidzino) {
                Squidzino squidzino = (Squidzino) animal;
                if(squidzino.isAlive()) { 
                    if(squidzino.disease == true){
                        this.disease = true;
                    }
                    squidzino.setDead();
                    foodLevel = SQUIDZINO_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this whale is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWhale A list to return newly born foxes.
     */
    private void giveBirth(List<Animal> newWhale)
    {
        // New whales are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Whale> adjacentWhale = new ArrayList<>();
        Field field = getField();
        List<Location> WhaleCheck = field.adjacentLocations(getLocation());
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int i = 0; i < WhaleCheck.size(); i++) {  
            if(field.getObjectAt(WhaleCheck.get(i)) instanceof Whale) {
                Whale whale = Whale.class.cast(field.getObjectAt(WhaleCheck.get(i)));
                adjacentWhale.add(whale);            
            }
        }
               
        for (int j = 0; j < adjacentWhale.size(); j++) {            
            if (adjacentWhale.get(j).IS_FEMALE != this.IS_FEMALE) {
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    if(this.disease == true){
                        Whale young = new Whale(false, true, false, field, loc);
                        newWhale.add(young);
                    }
                    else{
                        Whale young = new Whale(false, true, true, field, loc);
                        newWhale.add(young);
                    }
                }    
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A whale can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
