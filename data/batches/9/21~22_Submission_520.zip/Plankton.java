import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a plankton.
 * plankton age, reproduce and die.
 *
 * @version 2016.02.29 (2)
 */
public class Plankton extends Plant
{
    private static final int MAX_AGE = 10;
    private static final int SPAWNING_AGE = 4;
    private int age;
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a plankton. A plankton can be created as a new born (age zero
     * and not hungry) or with a random age.
     * 
     * @param randomAge If true, the plankton will have a random age.
     */
    public Plankton(boolean randomAge,Field field, Location location)
    {
        super(field,location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }
    
    /**
     * This is what the plankton does most of the time: it will die of old age, and when it does
     * it spawns another plankton
     * 
     * @param field The field currently occupied.
     * @param newPlankton A list to return newly born plankton.
     */
    public void act(List<Plant> newPlanktons)
    {
        incrementAge();
        if(isAlive()) { 
            if(age == SPAWNING_AGE){
                spawnPlankton(newPlanktons);   
            } 
        }
    }
    
    /**
     * the location of the current plankton is used to check adjacent free spaces for the new plankton
     * to be spawned into
     * 
     * @param newPlanktons A list to return newly born Planktons.
     */
    public void spawnPlankton(List<Plant> newPlanktons)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        if (free.size() > 0) {
            Location loc = free.remove(0);
            Plankton young = new Plankton(false, field, loc);
            newPlanktons.add(young);
        }
    }  
    
    /**
     * Increase the age. This could result in the plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
}
