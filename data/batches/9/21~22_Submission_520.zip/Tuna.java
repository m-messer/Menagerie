import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * A simple model of a tuna.
 * tuna age, move, eat, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Tuna extends Animal
{
    // Characteristics shared by all tuna (class variables).

    // The age at which a tuna can start to breed.
    private static final int BREEDING_AGE = 6;
    
    // The age to which a tuna can live.
    private static final int MAX_AGE = 35;
    // The likelihood of a tuna breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // a food value given to a tuna when it eats a plankton
    private static int PLANKTON_FOOD_VALUE = 13;
    
    // Individual characteristics (instance fields).
    private int age;
    private int foodLevel;
    private boolean IS_FEMALE;
    /**
     * Create a new tuna. A tuna may be created with age
     * zero (a new born) or with a random age. it may also be created with a random sex
     * it also has a chance of having a disease when it spawns, unless its parent
     * already had the disease when it bred it.
     * 
     * @param randomAge If true, the tuna will have a random age.
     * @param randomSex If true, the tuna will have a random sex.
     * @param randomDisease If true, the tuna will have a random chance of having a disease.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tuna(boolean randomAge,boolean randomSex,Boolean randomDisease, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANKTON_FOOD_VALUE);
        }
        
        if(randomSex) {
            int sex = rand.nextInt(2);
            if(sex == 1){
                IS_FEMALE = true;
            }
            else{
                IS_FEMALE = false;
            }
        }
        
        if (randomDisease) {
            int diseaseChance = rand.nextInt(1000);
            if (diseaseChance == 0) {
                disease = true;
            }
            else {
                disease = false;
            }
        }
        else{
            disease = true;
        }
        foodLevel = PLANKTON_FOOD_VALUE;
    }
    
    /**
     * This is what the tuna does most of the time: it hunts for
     * plankton. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param field The field currently occupied.
     * @param newTunas A list to return newly born tuna.
     */
    public void act(List<Animal> newTunas)
    {   
        actDisease();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            findFood();
            giveBirth(newTunas);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Make this tuna older. This could result in the tuna's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this tuna more hungry. This could result in the tuna's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Make this tuna suffer from the disease.this will make them more hungry and age them quicker
     * resulting in a quicker death.
     */
    private void actDisease(){
        if(this.disease == true){
            incrementAge();
            incrementAge();
            incrementHunger();
        }
    }
    
    /**
     * Look for plankton adjacent to the current location.
     * Only the first live plankton is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plankton) {
                Plankton plankton = (Plankton) plant;
                if(plankton.isAlive()) { 
                    plankton.setDead();
                    foodLevel = PLANKTON_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * first it checks whether the tuna can breed(if of age or has exceeded allowed births). if yes
     * it then gets the current tuna and checks adjacent locations for any opposite gender tuna
     * and breeds with the first available one. if current tuna has a disease, it passes it onto its
     * offspring.
     * @param newTunas A list to return newly born sharks.
     */
    private void giveBirth(List<Animal> newTunas)
    {
        // New tuna are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Tuna> adjacentTunas = new ArrayList<>();
        Field field = getField();
        List<Location> tunaCheck = field.adjacentLocations(getLocation());
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for (int i = 0; i < tunaCheck.size(); i++) {  
            if(field.getObjectAt(tunaCheck.get(i)) instanceof Tuna) {
                Tuna newTuna = Tuna.class.cast(field.getObjectAt(tunaCheck.get(i)));
                adjacentTunas.add(newTuna);
            }
        }
               
        for (int j = 0; j < adjacentTunas.size(); j++) {            
            if (adjacentTunas.get(j).IS_FEMALE != this.IS_FEMALE) {
                for(int b = 0; b < births && free.size() > 0; b++) {
                    Location loc = free.remove(0);
                    if(this.disease == true){
                        Tuna young = new Tuna(false, true, false, field, loc);
                        newTunas.add(young);
                    }
                    else{
                        Tuna young = new Tuna(false, true, true, field, loc);
                        newTunas.add(young);
                    }
                }    
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A tuna can breed if it has reached the breeding age.
     * @return true if the tuna can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}

