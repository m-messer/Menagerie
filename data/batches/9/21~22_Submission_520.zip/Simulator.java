import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing a foodchain of the ocean.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    //creation probabilities of the entities
    private static final double PLANKTON_CREATION_PROBABILITY = 0.08;
    private static final double TUNA_CREATION_PROBABILITY = 0.08;
    private static final double SQUIDZINO_CREATION_PROBABILITY = 0.08;
    private static final double WHALE_CREATION_PROBABILITY = 0.04;
    private static final double SHARK_CREATION_PROBABILITY = 0.04;
    private static final double OCTOPUS_CREATION_PROBABILITY = 0;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private List<Plant> plants;
    
    private Field field;
    // The current step of the simulation.
    public int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Plankton.class,Color.GREEN);
        view.setColor(Tuna.class,Color.RED);
        view.setColor(Whale.class,Color.BLACK);
        view.setColor(Squidzino.class,Color.MAGENTA);
        view.setColor(Shark.class,Color.BLUE);
        view.setColor(Octopus.class,Color.YELLOW);
       
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * entity.
     */
    public void simulateOneStep()
    {
        step++;
        //simulates day time. all entity are only active in the day
        boolean isActive = isAM();
        if (isActive == true) {
            List<Animal> newAnimals = new ArrayList<>(); 
            List<Plant> newPlants = new ArrayList<>();
            // Let all animals act.
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                animal.act(newAnimals);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
            //let all plankton act
            for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
                Plant plant = it.next();
                plant.act(newPlants);
                if(! plant.isAlive()) {
                    it.remove();
                }
            }
            //tries to spawn 10 plankton every step in the day time
            spawnPlanktonRandomly(10);
            // Add the newly born animals and plants to the main lists.
            animals.addAll(newAnimals);
            plants.addAll(newPlants);
            
        }
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with the entities.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANKTON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plankton plankton = new Plankton(true,field, location);
                    plants.add(plankton);
                }
                else if(rand.nextDouble() <= TUNA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tuna tuna = new Tuna(true,true,true, field, location);
                    animals.add(tuna);
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Whale cumWhale = new Whale(true,true,true,field, location);
                    animals.add(cumWhale);
                }
                
                else if(rand.nextDouble() <= SQUIDZINO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squidzino squidzino = new Squidzino(true,true,true,field, location);
                    animals.add(squidzino);
                }
                else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true,true,true,field, location);
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= OCTOPUS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Octopus octopus = new Octopus(true,true,true,field, location);
                    animals.add(octopus);
                }
                }
                // else leave the location empty.
            }
        }
    
    /**
     * generate random coordinates for the plankton to spawn. it checks whether the current location
     * is occupiued. if yes it doesnt spawn, else it spawns. 
     * 
     * @param num. tells it how much times to run.
     */
    private void spawnPlanktonRandomly(int num){
        for (int i=0; i < num;i++){
            Random randRow = Randomizer.getRandom();
            Random randCol = Randomizer.getRandom();
            int row = randRow.nextInt(field.getDepth());
            int col = randCol.nextInt(field.getWidth());
            if (field.getObjectAt(row, col) == null){
                Location location = new Location(row, col);
                Plankton plankton = new Plankton(true,field, location);
                plants.add(plankton);
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * uses the steps to check whether its am or pm.
     */
    private boolean isAM() {
        int check = step/12;
        if (check%2 == 0) {
            return false;
        }
        else {
            return true;
        }
    }
}
