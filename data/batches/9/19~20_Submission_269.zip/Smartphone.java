import java.util.List;

/**
 * A simple model of a smartphone.
 * Smartphones age, move, consume power banks, and die.
 * 
 * @version 2020.02.03 (3)
 */
public class Smartphone extends Predator {
    // Characteristics shared by all smarthphones (class variables).
   
    // The age at which a smartphone can start to breed.
    private static final int BREEDING_AGE = 12;
    // The endurance of a smartphone.
    private static final int ENDURANCE = 100;
    // The likelihood of a smartphone breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The energy value of a single power bank. In effect, this is the
    // number of steps a smartphone can go before it has to consume again.
    private static final int ENERGY_VALUE = 10;
    
    /**
     * Create a smartphone. A smartphone can be created as a new born 
     * (age zero and not hungry) or with a random age and battery electricity
     * level.
     * 
     * @param randomTech If true, the smartphone will have random age 
     * and the hunger level will be randomized.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Smartphone(boolean randomTech, Field field, Location location) {
        super(randomTech, field, location); 
    }
       
    /**
     * Return a new object of type Smartphone
     * @param field The field of the new object
     * @param location The location of the new object
     * @return Newly created object of type Smartphone
     */
    @Override
    public Gadget getChild(Field field, Location location) {
        return new Smartphone(false, field, location);
    }
    
    /**
     * Returns true if the parameter object is consumable by a smartphone.
     * That is the parameter object is of class PowerBank.
     * @param gadget The gadget to be checked. 
     * @return true if the parameter is consumable, false otherwise
     */
    @Override
    public boolean isConsumable(Object gadget) {
        return gadget instanceof PowerBank;        
    }
    
    //Getter methods for static variables
    /**
     * Returns endurance of the smartphone
     * @return the endurance
     */
    @Override
    public int getEndurance() {
        return ENDURANCE;
    }
    
    /**
     * Returns the breeding age of the smartphone
     * @return the minimal age for breeding
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Returns the breeding probability of the smartphone
     * @return the probability of breeding
     */
    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the maximum number of litter of the smartphone
     * @return the maximum number for one litter
     */
    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Returns the energy value, the number of steps a 
     * smartphone has to make before it has to consume 
     * @return the energy value of a smartphone
     */
    @Override
    public int getEnergyValue() {
        return ENERGY_VALUE;
    }
}
