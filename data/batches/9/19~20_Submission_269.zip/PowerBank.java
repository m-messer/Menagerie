import java.util.List;

/**
 * A simple model of a power bank.
 * Power banks age, move, breed if a female meets a male, and die.
 *
 * @version 2020.02.03 (3)
 */
public class PowerBank extends Prey {
    // Characteristics shared by all power banks (class variables).

    // The age at which a power bank can start to breed.
    private static final int BREEDING_AGE = 4;
    // The endurance of a battery.
    private static final int ENDURANCE = 80;
    // The likelihood of a power bank breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The likelihood of a new gadget to be female.
    private static final double FEMALE_PROBABILITY = 0.6;

    /**
     * Create a new power bank. A power bank may be created with age
     * zero (a new born) or with a random age. 
     * A power bank can be female or male.
     * 
     * @param randomTech If true, the power bank will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale If true, the power bank will be female
     */
    public PowerBank(boolean randomTech, Field field, Location location, 
            boolean isFemale) {
        super(randomTech, field, location, isFemale);
    }

    /**
     * Return a new object of type PowerBank
     * @param field The field of the new object
     * @param location The location of the new object
     * @return Newly created object of type PowerBank
     */
    @Override
    public Gadget getChild(Field field, Location location) {
        if (rand.nextDouble() <= FEMALE_PROBABILITY) {
            return new PowerBank(false, field, location, true);
        }
        return new PowerBank(false, field, location, false);
    }
    
     //Getter methods for static variables
    /**
     * Returns the endurance of the power bank
     * @return the endurance
     */
    @Override
    public int getEndurance() {
        return ENDURANCE;
    }

    /**
     * Returns the breeding age of the power bank
     * @return the minimal age for breeding
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Returns the breeding probability of the power bank
     * @return the probability of breeding
     */
    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the maximum number of litter of the power bank
     * @return the maximum number for one litter
     */
    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
}
