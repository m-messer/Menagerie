import java.util.List;
/**
 *  This class creates power sockets which don't move in the field.
 *  A power socket recharges gadgets of type Prey 
 *  that are located in adjacent positions if a power cut has not occurred.
 *
 * @version 2020.02.10 (1)
 */
public class PowerSocket extends Tech {
    /**
     * Initialize a power socket's location and field .
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public PowerSocket(Field field, Location location) {
        super(field, location);        
    }
    
    /**
     * Make the power socket charge every prey next to it
     */
    public void charge() {    
        List<Location> adjacentLocations = 
                getField().adjacentLocations(getLocation());
        for (Location adjacentLocation : adjacentLocations) {
            Tech otherTech = (Tech) getField().getObjectAt(adjacentLocation);
            if (otherTech != null && otherTech instanceof Prey) {
                Prey prey = (Prey) otherTech; 
                prey.recharge();
            }
        } 
    }
}
