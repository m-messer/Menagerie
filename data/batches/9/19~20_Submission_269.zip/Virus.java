import java.util.List;
/**
 * Create a new virus. A virus has a step on which it stops infecting and a period, 
 * after which the infected gadgets are killed.
 *
 * @version 2020.02.10 (1)
 */
public class Virus {
    // number of steps a gadget can go before it dies if infected.
    private int gadgetsRemainingLife;
    // the step on which the virus stops infecting.
    private int endStep;

    /**
     * Create a virus with a specific duration 
     * and remaining life for the infected gadgets.
     */
    public Virus(int gadgetsRemainingLife, int endStep) {
        this.gadgetsRemainingLife = gadgetsRemainingLife;
        this.endStep = endStep;
    }
    
    /**
     * Return the step on which the contagious period ends.
     * @return the step on which the virus stops infecting.
     */
    public int getEndStep() {
        return endStep;
    }
    
    /**
     * Infect all the gadgets that have been in contact with contagious gadgets.
     * @param gadgets A list of all the gadgets to be infected.
     */
    public void infect(List<Gadget> gadgets) {
        for(Gadget gadget : gadgets) {
            gadget.setInfected(true);
            gadget.setAgeToDieFromDisease(gadgetsRemainingLife);
        }
        gadgets.clear();
    }
}
