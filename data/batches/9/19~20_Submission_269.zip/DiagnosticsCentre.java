import java.util.List;
/**
 * A diagnostics centre doesn't move but cures infected gadgets in its adjacent locations. 
 *
 * @version 2020.02.12 (1)
 */
public class DiagnosticsCentre extends Tech {
    /**
     * Initialize a diagnostics centre's location and field .
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public DiagnosticsCentre(Field field, Location location) {
        super(field, location);        
    }
    
    /**
     * Make the diagnostics centre cure every infected gadget near it. 
     */
    public void cure() {
        List<Location> adjacentLocations = 
                getField().adjacentLocations(getLocation());
        for (Location adjacentLocation : adjacentLocations) {
            Tech otherTech = (Tech) getField().getObjectAt(adjacentLocation);
            if (otherTech != null && otherTech instanceof Gadget) {
                Gadget otherGadget = (Gadget) otherTech; 
                if (otherGadget.isInfected()) {
                    otherGadget.setInfected(false);
                }
            }        
        }  
    }
}
