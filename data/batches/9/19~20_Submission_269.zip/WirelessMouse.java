import java.util.List;

/**
 * A simple model of a wireless mouse.
 * Wireless mice age, move, consume batteries, breed and die.
 * 
 * @version 2020.02.03 (3)
 */
public class WirelessMouse extends Predator {
    // Characteristics shared by all wireless mice (class variables).
    
    // The age at which a wireless mouse can start to breed.
    private static final int BREEDING_AGE = 12;
    // The endurance of a wireless mouse.
    private static final int ENDURANCE = 150;
    // The likelihood of a wireless mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The energy value of a single battery. In effect, this is the
    // number of steps a wireless mouse can go before it has to consume again.
    private static final int ENERGY_VALUE = 12;

    /**
     * Create a wireless mouse. 
     * A wireless mouse can be created as a new born (age zero and not hungry)
     * or be a wireless mouse with random age and energy level.
     * 
     * @param randomTech If true, the wireless mouse will have random age
     * and the hunger level will be randomized.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public WirelessMouse(boolean randomTech, Field field, Location location) {
        super(randomTech, field, location);
    }
          
    /**
     * Return a new object of type WirelessMouse
     * @param field The field of the new object
     * @param location The location of the new object
     * @return Newly created object of type WirelessMouse
     */
    @Override
    public Gadget getChild(Field field, Location location) {
        return new WirelessMouse(false, field, location);
    }
    
    /**
     * Returns true if the parameter object is consumable.
     * @param gadget The gadget to be checked. 
     * @return true if the parameter is consumable, false otherwise
     */
    @Override
    public boolean isConsumable(Object gadget) {
        return gadget instanceof Battery;        
    }  
    
    //Getter methods for static variables
    /**
     * Returns endurance of the wireless mouse
     * @return the endurance
     */
    @Override
    public int getEndurance() {
        return ENDURANCE;
    }
    
    /**
     * Returns the breeding age of the wireless mouse
     * @return the minimal age for breeding
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Returns the breeding probability of the wireless mouse
     * @return the probability of breeding
     */
    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the maximum number of litter of the wireless mouse
     * @return the maximum number for one litter
     */
    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Returns the energy value, the number of steps a 
     * speaker has to make before it has to consume 
     * @return the energy value of a speaker
     */
    @Override    
    public int getEnergyValue() {
        return ENERGY_VALUE;
    }
}
