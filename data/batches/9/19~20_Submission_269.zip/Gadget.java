import java.util.List;
import java.util.ArrayList;
import java.util.Random;
/**
 * A class representing shared characteristics of gadgets.
 *
 * @version 2020.02.03 (3)
 */
public abstract class Gadget extends Tech {
    // Whether the gadget is alive or not.
    private boolean alive;
    // The gadget's age.
    protected int age;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    // Indicates whether the gadget is infected.
    protected boolean infected;
    // The age at which the gadget will die if infected and not healed.
    protected int ageToDieFromDisease;
    
    /**
     * Define the new gadget's age, and initialize its location and field.
     * 
     * @param randomTech If true, the gadget will have random age. 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gadget(boolean randomTech, Field field, Location location) {
        super(field, location);
        alive = true;
        age = randomTech
            ? rand.nextInt(getEndurance())
            : 0;
    }
    
    /**
     * Check whether the gadget is alive.
     * @return true if the gadget is still alive (not drained).
     */
    protected boolean isAlive() {
        return alive;
    }
    
    /**
     * Indicate that the gadget is dead.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if(getLocation() != null) {
            getField().clear(getLocation());
            setNullLocation();
            setField(null);
        }
    }
         
    /**
     * Increase the age. This could result in the gadget's death, either from
     * old age or disease.
     */
    protected void incrementAge() {
        age++;
        if (age > getEndurance() || (infected && age >= ageToDieFromDisease)) {
            setDead();
        }
    }
      
    /**
     * Check whether or not this gadget is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGadgets A list to return newly born gadgets.
     */
    protected void giveBirth(List<Gadget> newGadgets) {
        // New gadgets are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Gadget young = getChild(field, loc);
            newGadgets.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    //Methods to infect the gadgets with a virus
    /**
     * Return a list of all adjacent gadgets that later will be infected
     * @return list of gadgets to be infected
     */
    public List<Gadget> toInfect() {
       List<Gadget> gadgetsToBeInfected = new ArrayList<>();
       if (isAlive()) {
           List<Location> adjacentLocations =
                    getField().adjacentLocations(getLocation());
           for (Location adjacentLocation : adjacentLocations) {
               Tech otherTech = 
                        (Tech) getField().getObjectAt(adjacentLocation);
               if (otherTech != null && otherTech instanceof Gadget) {
                   Gadget otherGadget = (Gadget) otherTech;
                   if (!otherGadget.isInfected()) {
                       gadgetsToBeInfected.add(otherGadget);
                   }
               }               
           }
       }
       return gadgetsToBeInfected;
    }    
 
    
    /**
     * Return whether the gadget is infected.
     * @return true if the gadget is infected, false otherwise.
     */
    public boolean isInfected() {
        return infected;
    }
    
    /**
     * Set the infection status of the gadget.
     * @param infected indicates whether the gadget is infected.
     */
    public void setInfected(boolean infected) {
        this.infected = infected;
    }
    
    /**
     * Set the endurance of the gadget if infected.
     * @param remainingLife indicates whether the gadget is infected.
     */
    public void setAgeToDieFromDisease(int remainingLife) {
        ageToDieFromDisease = age + remainingLife;
    }
        
    //Abstract methods
    /**
     * Make this gadget act - that is: make it do
     * whatever it wants/needs to do.
     * @param newGadgets A list to receive newly created gadgets.
     */
    abstract public void act(List<Gadget> newGadgets);
    
    /**
     * A gadget can breed if it has reached the breeding age.
     */
    public abstract boolean canBreed();
    
    //Abstract getter methods for static variables in subclasses    
    /**
     * Returns the endurance of the gadget
     * @return the endurance
     */
    public abstract int getEndurance();
    
    /**
     * Returns the breeding age
     * @return the minimal age for breeding
     */
    public abstract int getBreedingAge();
    
    /**
     * Returns the breeding probability
     * @return the probability of breeding
     */
    public abstract double getBreedingProbability();
    
    /**
     * Returns the maximum number of litter
     * @return the maximum number for one litter
     */
    public abstract int getMaxLitterSize();
        
    /**
     * Returns a newly created object
     * @param field The field of the new object
     * @param location The location of the new object
     * @return Newly created object of static type Gadget
     */
    public abstract Gadget getChild(Field field, Location location);
}
