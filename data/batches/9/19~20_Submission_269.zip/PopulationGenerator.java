import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * Populate the grid.
 *
 * @version 2020.02.12 (1)
 */
public class PopulationGenerator {
    // The probability that a smartphone 
    // will be created in any given grid position.
    private static final double SMARTPHONE_CREATION_PROBABILITY = 0.005; 
    // The probability that a speaker 
    // will be created in any given grid position.
    private static final double SPEAKER_CREATION_PROBABILITY = 0.005;  
    // The probability that a wireless mouse
    // will be created in any given grid position.
    private static final double WIRELESSMOUSE_CREATION_PROBABILITY = 0.005;
    // The probability that a battery 
    // will be created in any given grid position.
    private static final double BATTERY_CREATION_PROBABILITY = 0.02;
    // The probability that a power bank
    // will be created in any given grid position.
    private static final double POWERBANK_CREATION_PROBABILITY = 0.03;
    // The probability that a power socket 
    // will be created in any given grid position.
    private static final double POWERSOCKET_CREATION_PROBABILITY = 0.0007; 
    // The probability that a diagnostics centre 
    // will be created in any given grid position.
    private static final double DIAGNOSTICSCENTRE_CREATION_PROBABILITY = 0.0005; 
    // The maximum number of power sockets to be created on the grid
    private static final int MAX_POWER_SOCKETS = 200;    
    // The maximum number of diagnostics centers to be created on the grid  
    private static final int MAX_DIAGNOSTICS_CENTRES = 200;
    
    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Create a population generator with the given field and view.
     * @param field The field to be occupied.
     * @param view The graphical view.
     */
    public PopulationGenerator(Field field, SimulatorView view) {
        this.field = field;
        this.view = view;
    }
    
    /**
     * Set the colors of each class occupying the field.
     */
    public void createView() {
        view.setColor(Smartphone.class, Color.YELLOW);
        view.setColor(Speaker.class, Color.BLUE);
        view.setColor(WirelessMouse.class, Color.MAGENTA);
        view.setColor(Battery.class, Color.GREEN);        
        view.setColor(PowerBank.class, Color.RED); 
        view.setColor(PowerSocket.class, Color.BLACK); 
        view.setColor(DiagnosticsCentre.class, Color.PINK); 
    }
    
    /**
     * Randomly populate the field with tech.
     * @param gadgets The list of gadgets to be created.
     * @param centres The list of centres to be created.
     * @param powerSockets The list of powerSockets to be created.
     */
    public void populate(
        List<Gadget> gadgets, 
        List<DiagnosticsCentre> centres,
        List<PowerSocket> powerSockets) {
       
        Random rand = Randomizer.getRandom();
        field.clear();
        int socketCounter = 0;
        int diagnosticsCounter = 0;
        int maxNumberOfSockets = rand.nextInt(MAX_POWER_SOCKETS);
        int maxNumberOfDiagnosticsCentres = 
        rand.nextInt(MAX_DIAGNOSTICS_CENTRES);        
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= SMARTPHONE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Smartphone smartphone = 
                            new Smartphone(true, field, location);
                    gadgets.add(smartphone);
                } else if (rand.nextDouble() <= SPEAKER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Speaker speaker = 
                            new Speaker(true, field, location);
                    gadgets.add(speaker);
                } else if (rand.nextDouble() <= 
                        WIRELESSMOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    WirelessMouse wirelessMouse = 
                            new WirelessMouse(true, field, location);
                    gadgets.add(wirelessMouse);
                } else if (rand.nextDouble() <= BATTERY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Battery battery = new Battery(true, 
                            field, location, rand.nextBoolean());
                    gadgets.add(battery);
                } else if (rand.nextDouble() <= POWERBANK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    PowerBank powerBank = new PowerBank(true,
                            field, location, rand.nextBoolean());
                    gadgets.add(powerBank);
                } else if (rand.nextDouble() <= POWERSOCKET_CREATION_PROBABILITY 
                                && socketCounter < maxNumberOfSockets) {
                    Location location = new Location(row, col);
                    PowerSocket powerSocket = 
                            new PowerSocket(field, location);
                    powerSockets.add(powerSocket);
                    socketCounter++;
                } else if (rand.nextDouble() <= 
                        DIAGNOSTICSCENTRE_CREATION_PROBABILITY 
                        && diagnosticsCounter < maxNumberOfDiagnosticsCentres) {
                    Location location = new Location(row, col);
                    DiagnosticsCentre diagnosticsCentre = 
                            new DiagnosticsCentre(field, location);
                    centres.add(diagnosticsCentre);
                    diagnosticsCounter++;
                }  
                // else leave the location empty.
            }
        }  
    }
}



