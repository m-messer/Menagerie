import java.util.List;

/**
 * A simple model of a battery.
 * Batteries age, move, breed if a female meets a male, and die. 
 *
 * @version 2020.02.03 (3)
 */
public class Battery extends Prey {
    // Characteristics shared by all batteries (class variables).

    // The age at which a battery can start to breed.
    private static final int BREEDING_AGE = 5;
    // The endurance of a battery.
    private static final int ENDURANCE = 100;
    // The likelihood of a battery breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The likelihood of a new battery to be female.
    private static final double FEMALE_PROBABILITY = 0.6;

    /**
     * Create a new battery. A battery may be created with age
     * zero (a new born) or with a random age. A battery also has a gender.
     * 
     * @param randomTech If true, the battery will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale If true, the battery will be female
     */
    public Battery(boolean randomTech, Field field, Location location, 
            boolean isFemale) {
        super(randomTech, field, location, isFemale);
    }

    /**
     * Create and return a new object of type Battery
     * @param field The field of the new object
     * @param location The location of the new object
     * @return Newly created object of type Battery
     */
    @Override
    public Gadget getChild(Field field, Location location) {
        if (rand.nextDouble() <= FEMALE_PROBABILITY) {
            return new Battery(false, field, location, true);
        }
        return new Battery(false, field, location, false);
    }
    
    //Getter methods for static variables
    /**
     * Returns the endurance of the battery
     * @return the endurance
     */
    @Override
    public int getEndurance() {
        return ENDURANCE;
    }
    
    /**
     * Returns the breeding age of the battery
     * @return the minimal age for breeding
     */
    @Override
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    
    /**
     * Returns the breeding probability of the battery
     * @return the probability of breeding
     */
    @Override
    public double getBreedingProbability() {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the maximum number of litter of the battery
     * @return the maximum number for one litter
     */
    @Override
    public int getMaxLitterSize() {
        return MAX_LITTER_SIZE;
    }
}
