import java.util.List;
/**
 * Abstract class Predator representing the shared characteristics of all predators -
 * all gadgets that consume other gadgets
 *
 * @version 2020.02.13
 */
public abstract class Prey extends Gadget {
    // The amount of energy a prey gets from recharging
    public static final int CHARGE_VALUE = 9;
    //The gender of a prey: true for female, false for male.
    private boolean female;
    
    /**
     * Initialize the age, field, location of a new prey 
     * and determine the gender.
     * 
     * @param randomTech If true, the prey will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomTech, Field field, Location location, 
            boolean isFemale) {
        super(randomTech, field, location);
        female = isFemale;
    }

    /**
     * Make this prey act - that is: make it do
     * whatever it wants/needs to do.
     * @param newGadgets A list to receive newly created gadgets.
     */
    @Override
    public void act(List<Gadget> newGadgets) {
        incrementAge(); 
        if (!isAlive()) {
            return;
        } else {
            giveBirth(newGadgets);
            // Try to move into a free location.
            Location newLocation = 
                    getField().freeAdjacentLocation(getLocation());
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Return whether the prey is female.
     * @return true if the current prey is female, false otherwise
     */
    public boolean isFemale() {
        return female;
    } 

    /**
     * A gadget can breed if it has reached the breeding age.
     * @return true if the prey is able to breed, false otherwise
     */
    @Override
    public boolean canBreed() {
        if (age >= getBreedingAge() && female){
            List<Location> adjacentLocations = 
                    getField().adjacentLocations(getLocation());
            for (Location adjacentLocation : adjacentLocations) {
                Tech otherTech = (Tech) getField().getObjectAt(adjacentLocation);
                if (otherTech != null 
                        && this.getClass() == otherTech.getClass()){
                    Prey otherPrey = (Prey) otherTech;
                    if (!otherPrey.isFemale()) {
                        return true;
                    }
                }            
            }
        }
        return false;
    }

    /**
     * Recharge the prey, that is extend the remaining life of the prey
     * If the current age of the prey is below the charge value,
     * the age is set to 0
     */
    public void recharge() {
        if (age >= CHARGE_VALUE) {
            age -= CHARGE_VALUE;
        } else {
            age = 0;
        }
    }
}

