import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing different kinds of tech. 
 * It also manages the tech's actions during the time of the day, 
 * power cut and virus occurrences.
 *
 * @version 2020.02.10 (3)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;
    
    // The probability that a powercut occurs.
    private static final double POWERCUT_PROBABILITY = 0.05;    
    // The probability that a virus occurs.
    private static final double VIRUS_PROBABILITY = 0.05;
    // The duration of the day.
    private static final int DAY_DURATION = 20;
    
    //The maximum longevity of a power cut
    private static final int MAX_POWER_CUT_LONGEVITY = 20;
    //The maximum longevity of a virus
    private static final int MAX_VIRUS_LONGEVITY = 20;
    //The maximum steps a gadget can make while infected before dying
    private static final int MAX_REMAINING_LIFE = 50;
    
    // List of gadgets in the field.
    private List<Gadget> gadgets;
    // List of power sockets in the field.
    private List<PowerSocket> powerSockets;
    // List of diagnostics centres in the field.
    private List<DiagnosticsCentre> diagnosticsCentres; 
    
    // The current step of the simulation.
    private int step;
    // The current presence of a virus
    private boolean isVirusPresent;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current state of the field.
    private Field field;
    // The end step of the power cut
    private int powerCutEndStep;
   
    // The current virus.
    private Virus virus = null;  
    //The population generator.
    private PopulationGenerator generator;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        gadgets = new ArrayList<>();
        field = new Field(depth, width);
        powerSockets = new ArrayList<>();
        diagnosticsCentres = new ArrayList<>();
        view = new SimulatorView(depth, width);        
        generator = new PopulationGenerator(field, view);

        generator.createView();
        
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * tech.
     */
    public void simulateOneStep() {
        step++;
        
        managePowerCut();
        manageVirus();
        manageAction();
        
        view.showStatus(step, field, DAY_DURATION, isVirusPresent);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        gadgets.clear();
        generator.populate(gadgets, diagnosticsCentres, powerSockets);
        // Show the starting state in the view.
        view.showStatus(step, field, DAY_DURATION, isVirusPresent);
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Turn off/on the electricity
     * @return true if a power cut has occurred, false otherwise.
     */
    private boolean hasPowerCutOccurred() {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= POWERCUT_PROBABILITY) {          
            powerCutEndStep = step + rand.nextInt(MAX_POWER_CUT_LONGEVITY);
            return true;
        }
        return false;
    }
    
    /**
     * Create virus if the probability is high enough.
     * @return true if a virus has occurred, false otherwise.
     */
    private boolean hasVirusOccurred() {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= VIRUS_PROBABILITY) {
            virus = new Virus(rand.nextInt(MAX_REMAINING_LIFE), 
            step + rand.nextInt(MAX_VIRUS_LONGEVITY)); 
            return true;
        }
        return false;
    }
    
    /**
     * Make the power sockets charge preys, 
     * if a power cut is not present in the current step.
     * If a power cut has occurred and not ended, do nothing.
     */
    private void managePowerCut() {
        if (step < powerCutEndStep) {
            return;
        } else {
            if (step == powerCutEndStep) {
                view.setColor(PowerSocket.class, Color.BLACK); 
            }
            if (!hasPowerCutOccurred()) {
                powerSockets.forEach(ps -> ps.charge());
            } else {
                view.setColor(PowerSocket.class, Color.CYAN);
            }
        }
    }
    
    /**
     * If a virus has occurred, let the infection spread 
     * until the end of the contagious period.
     * Also, make all diagnostics centres cure their adjacent infected gadgets.
     */
    private void manageVirus() {
        Random rand = Randomizer.getRandom();
        List<Gadget> gadgetsToBeInfected = new ArrayList<>();
        if (virus == null && hasVirusOccurred() 
                && gadgets.size() != 0) {           
            gadgetsToBeInfected.add(gadgets.get(rand.nextInt(gadgets.size())));
            virus.infect(gadgetsToBeInfected);
            isVirusPresent = true;
        } else if (virus != null) {
            if (step < virus.getEndStep()) {
                gadgets.stream()
                        .filter(g -> g.isInfected())
                        .forEach(g -> virus.infect(g.toInfect()));
            } else {
                virus = null;
                isVirusPresent = false;
            }
        }
        //Cure all gadgets near a diagnostics centre
        diagnosticsCentres.forEach(dc -> dc.cure());
    }
    
    /**
     * Make the gadgets act and update the current state of the population.
     */
    private void manageAction() {
        // Provide space for newborn gadgets.
        List<Gadget> newGadgets = new ArrayList<>();        
        for (Iterator<Gadget> it = gadgets.iterator(); it.hasNext(); ) {
            Gadget gadget = it.next();
            if ((step / DAY_DURATION) % 2 == 0) { 
                gadget.act(newGadgets);
            } else if(gadget instanceof Prey) {
                gadget.act(newGadgets);
            } else { 
                gadget.incrementAge();
            }
            if (!gadget.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born gadgets to the main list.
        gadgets.addAll(newGadgets);
    }
}
