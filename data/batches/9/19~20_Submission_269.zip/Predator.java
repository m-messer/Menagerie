import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.HashMap;
/**
 * Abstract class Predator representing the shared characteristics of all predators -
 * all gadgets that consume other gadgets
 *
 * @version 2020.02.10 (1)
 */
public abstract class Predator extends Gadget {
    // The predator's energy level, which is increased by consuming prey.
    protected int energyLevel;  
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Initialize the age, field and location of a new predator.
     * 
     * @param randomTech If true, the predator will have random age
     * and the hunger level will be randomized.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomTech, Field field, Location location) {
        super(randomTech, field, location);
        energyLevel = randomTech
           ? rand.nextInt(getEnergyValue())
           : getEnergyValue();
    }
    
    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age/disease.
     * @param field The field currently occupied.
     * @param newGadgets A list to return newly born gadgets of type predator.
     */
    @Override
    public void act(List<Gadget> newGadgets) {
        incrementAge();
        decreaseEnergy();
        
        if (!isAlive()) {
            return;
        } else {
            giveBirth(newGadgets);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }   
    }
    
    /**
     * Make the predator hungrier. This could result in the predator's death.
     */
    public void decreaseEnergy() {
        energyLevel--;
        if (energyLevel <= 0) {
            setDead();
        }
    }
     
    /**
     * Look for prey adjacent to the current location.
     * Only the first prey that is alive is consumed.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object gadget = field.getObjectAt(where);
            if (isConsumable(gadget)) {
                Prey prey = (Prey) gadget;
                if (prey.isAlive()) { 
                    prey.setDead();
                    energyLevel = getEnergyValue();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * A gadget can breed if it has reached the breeding age.
     * @return true if the gadget is above the breeding age, false otherwise
     */
    @Override
    public boolean canBreed() {
        return age >= getBreedingAge();
    }
    
    /**
     * Returns the energy value of the predator, the number of steps a 
     * predator has to make before it has to consume again.
     * @return the energy value of the predator
     */
    public abstract int getEnergyValue();
    
    /**
     * Returns true if the parameter object is consumable -
     * if the parameter object is specified as the predator's prey.
     * @param gadget The gadget to be checked. 
     * @return true if the parameter is consumable, false otherwise
     */
    public abstract boolean isConsumable(Object gadget);
}
