/**
 * A class representing shared characteristics of all kinds of tech.
 * A tech has a location and a field.
 *
 * @version 2020.02.10 (1)
 */
public class Tech {
    // The tech's field.
    private Field field;
    // The tech's position in the field.
    private Location location;

    /**
     * Create a tech with the given location and field.
     */
    public Tech(Field field, Location location) {
        this.field = field;
        setLocation(location);
    }

    /**
     * Return the tech's location.
     * @return The tech's location.
     */
    protected Location getLocation() {
        return location;
    }
    
    /**
     * Place the tech at the new location in the given field.
     * @param newLocation The tech's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the tech's field.
     * @return The tech's field.
     */
    protected Field getField() {
        return field;
    }
    
    /**
     * Set the tech's field
     * @param field The field to put the tech in.
     */
    protected void setField(Field field) {
        this.field = field;
    }
    
    /**
     * Set the tech's location to null
     */
    protected void setNullLocation() {
        location = null;
    }
}
