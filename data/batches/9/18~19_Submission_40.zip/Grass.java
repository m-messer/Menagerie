import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Grass type. They grow and can die when they reach a certain age and can be eaten.
 *
 * @version 2019.02.21
 */
public class Grass extends Plant {

	// The age to which grass can live.
	private static final int MAX_AGE = 5;
	// The maximum caloric value grass has to offer
	private static final int CALORIC_VALUE = 1000;
	// The probability of growing into a new square
	private static final double GROW_PROBABILITY = 0.9;
	// A shared random number generator to control movement.
	private static final Random rand = Randomizer.getRandom();
	// The age of the grass
	private int age;

	public Grass(Field field, Location location) {
		super(field, location);
		age = 0;
	}

	public Grass(boolean randomAge, Field field, Location location) {
		super(field, location);
		if (randomAge) {
			age = rand.nextInt(MAX_AGE);
		} else {
			age = 0;
		}
	}

	@Override
	public void act(List<Actor> newActors, int dayQuarter) {

        if (isAlive())
            grow(newActors);
        incrementAge();
        if (age > MAX_AGE) {
            setDead();
        }
	}
	
	/**
	 * Spawns new grass around the currently existing grass.
	 * @param newActors List of actors - born actors are inserted into this list
	 */

	private void grow(List<Actor> newActors) {
		Location currentGrassLocation = getLocation();
		Field currentField = getField();
		List<Location> freeLocationsAndGrass = currentField.getFreeAdjacentLocations(currentGrassLocation);
		List<Location> freeLocations = new ArrayList<>();
		for (int i = 0; i < freeLocationsAndGrass.size(); i++) {
			if (this.getField().getActorAt(freeLocationsAndGrass.get(i)) == null)
				freeLocations.add(freeLocationsAndGrass.get(i));
		}
		if (freeLocations.isEmpty()) {
			return;
		}

		double probabilityPerSpace = GROW_PROBABILITY / (double) freeLocations.size();
		for (Location freeLocation : freeLocations) {
			if (rand.nextDouble() <= probabilityPerSpace) {
				newActors.add(new Grass(currentField,freeLocation));
				return;
			}
		}
	}

	@Override
	protected int getCaloricValue() {
		return CALORIC_VALUE;
	}

	/**
	 * Increase the age. This could result in the fox's death.
	 */
	private void incrementAge() {
		age++;
		if (age > MAX_AGE) {
			setDead();
		}
	}

}
