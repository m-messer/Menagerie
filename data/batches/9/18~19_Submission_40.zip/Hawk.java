
import java.util.List;
import java.util.Random;

/**
 * A simple model of a hawk. Hawks age, move, eat rabbits, and die.
 *
 * @version 2019.02.21
 */
public class Hawk extends Animal {
	// Characteristics shared by all hawks (class variables).

	// The age at which a hawk can start to breed.
	private static final int BREEDING_AGE = 4;
	// The age to which a hawk can live.
	private static final int MAX_AGE = 40;
	// The likelihood of a hawk breeding.
	private static final double BREEDING_PROBABILITY = 0.2;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 4;
	// The caloric value a hawk has to offer
	private static final int HAWK_CALORIC_VALUE = 30;
	// The maximum amount of food a hawk can eat
	private static final int MAX_FOOD_LEVEL = 50;
	// the types of animals a hawk can eat
	private static final Class[] EATABLES = { Hamster.class, Mouse.class };
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	// The amount the hunger increases for every child born.
	private static final double FOOD_LOST_PER_BIRTH = 5;
	// The distance an animal can move in one step.
	private static final double MOVE_DISTANCE = 2;

	public Hawk(Field field, Location location) {
		super(field, location);
		setAge(0);
		setFoodLevel(MAX_FOOD_LEVEL);
	}

	/**
	 * Create a hawk. A hawk can be created as a new born (age zero and not hungry)
	 * or with a random age and food level.
	 *
	 * @param randomAge
	 *            If true, the hawk will have random age and hunger level.
	 * @param field
	 *            The field currently occupied.
	 * @param location
	 *            The location within the field.
	 */
	public Hawk(boolean randomAge, Field field, Location location) {
		super(field, location);
		setAge(0);
		if (randomAge) {
			setAge(rand.nextInt(MAX_AGE));
		}
		setFoodLevel(MAX_FOOD_LEVEL);
	}

	/**
	 * This is what the hawk does most of the time. In the process, it might breed,
	 * die of hunger, or die of old age.
	 * 
	 * @param newHawks
	 *            A list to return newly born foxes.
	 */
	@Override
	public void act(List<Actor> newHawks, int dayQuarters) {
		super.act(newHawks);
		if (dayQuarters != 1) {
			if (isAlive())
				giveBirth(newHawks);
			if (isAlive()) {
				Location newLocation = move();
				// See if it was possible to move.
				if (newLocation == null)
					// Overcrowding.
					setDead();
			}
		}
	}

	@Override
	protected int getCaloricValue() {
		return HAWK_CALORIC_VALUE;
	}

	@Override
	protected Class[] getAllEatables() {
		return EATABLES;
	}

	@Override
	protected int getMaxAge() {
		return MAX_AGE;
	}

	@Override
	protected double getFoodForBirth() {
		return FOOD_LOST_PER_BIRTH;
	}

	/**
	 * Gets us the likelihood that an animal with give birth
	 *
	 * @return the likelihood that an animal with give birth
	 */
	@Override
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Get the maximum number of births an animal can give
	 *
	 * @return the maximum number of births an animal can give.
	 */
	@Override
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * A hawk can breed if it has reached the breeding age.
	 */
	protected boolean canBreed() {
		return isAlive() && getAge() >= BREEDING_AGE;
	}

	@Override
	protected Animal getOffspring(Location location) {
		return new Hawk(false, getField(), location);
	}

	/**
	 * @return The maximum distance a hawk can move in a given step.
	 */
	protected double getMoveDistance() {
		return MOVE_DISTANCE;
	}

}
