/**
 * The generic plant type.
 *
 * @version 2019.02.21
 */

public abstract class Plant extends Actor {

	public Plant(Field field, Location location) {
		setAliveStatus(true);
		setField(field);
		setLocation(location);
		setImmortal(false);
	}
	
	
	@Override
	public boolean isPlant() {
		return true;
	}
}
