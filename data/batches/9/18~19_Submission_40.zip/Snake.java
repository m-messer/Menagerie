
import java.util.List;
import java.util.Random;

/**
 * A simple model of a snake. Snakes age, move, eat mice, give birth and die.
 *
 * @version 2019.02.21
 */

public class Snake extends Animal {
	// Characteristics shared by all snakes (class variables).

	// The age at which a snake can start to breed.
	private static final int BREEDING_AGE = 14;
	// The age to which a snake can live.
	private static final int MAX_AGE = 30;
	// The likelihood of a snake breeding.
	private static final double BREEDING_PROBABILITY = 0.47;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 5;
	// The caloric value a snake has to offer
	private static final int SNAKE_CALORIC_VALUE = 30;
	// The maximum amount of food a snake can eat
	private static final int MAX_FOOD_LEVEL = 45;
	// the types of animals a snake can eat
	private static final Class[] EATABLES = { Mouse.class };
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	// The amount the hunger increases for every child born.
	private static final double FOOD_LOST_PER_BIRTH = 2;
	// The amount the animal can move in a step
	private static final double MOVE_DISTANCE = 1.5;

	public Snake(Field field, Location location) {
		super(field, location);
		setAge(0);
		setFoodLevel(MAX_FOOD_LEVEL);
	}

	/**
	 * Create a snake. A snake can be created as a new born (age zero and not
	 * hungry) or with a random age and food level.
	 *
	 * @param randomAge
	 *            If true, the snake will have random age and hunger level.
	 * @param field
	 *            The field currently occupied.
	 * @param location
	 *            The location within the field.
	 */
	public Snake(boolean randomAge, Field field, Location location) {
		super(field, location);
		setAge(0);
		if (randomAge) {
			setAge(rand.nextInt(MAX_AGE));
		}
		setFoodLevel(MAX_FOOD_LEVEL);
	}

	/**
	 * This is what the snake does most of the time. In the process, it might breed,
	 * die of hunger, or die of old age.
	 * 
	 * @param newSnakes
	 *            A list to return newly born snakes.
	 */
	public void act(List<Actor> newSnakes, int dayQuarter) {
		super.act(newSnakes);
		if (isAlive())
			giveBirth(newSnakes);
		if (isAlive() && dayQuarter!=1) {
			Location newLocation = move();
			// See if it was possible to move.
			if (newLocation == null)
				// Overcrowding.
				setDead();
		}
	}

	@Override
	protected double getFoodForBirth() {
		return FOOD_LOST_PER_BIRTH;
	}

	/**
	 * Gets us the likelihood that an animal with give birth
	 *
	 * @return the likelihood that an animal with give birth
	 */
	@Override
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Get the maximum number of births an animal can give
	 *
	 * @return the maximum number of births an animal can give.
	 */
	@Override
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * A snake can breed if it has reached the breeding age.
	 */
	@Override
	protected boolean canBreed() {
		return isAlive() && getAge() >= BREEDING_AGE;
	}

	/**
	 * Get the offspring of an animal
	 *
	 * @param location where the animal is supposed to spawn
	 */
	@Override
	protected Animal getOffspring(Location location) {
		return new Snake(false, getField(), location);
	}

	@Override
	protected int getCaloricValue() {
		return SNAKE_CALORIC_VALUE;
	}

	@Override
	protected Class[] getAllEatables() {
		return EATABLES;
	}

	@Override
	protected int getMaxAge() {
		return MAX_AGE;
	}

	protected double getMoveDistance() {
		return MOVE_DISTANCE;
	}
}
