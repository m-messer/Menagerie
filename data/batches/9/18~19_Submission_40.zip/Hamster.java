import java.util.List;
import java.util.Random;

/**
 * A simple model of a hamster. Hamster age, move, breed, and die.
 *
 * @version 2019.02.21
 */
public class Hamster extends Animal {
	// Characteristics shared by all hamster (class variables).

	// The age at which a mouse can start to breed.
	private static final int BREEDING_AGE = 2;
	// The age to which a mouse can live.
	private static final int MAX_AGE = 10;
	// The likelihood of a mouse breeding.
	private static final double BREEDING_PROBABILITY = 0.56;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 3;
	// The caloric value a mouse has to offer
	private static final int HAMSTER_CALORIC_VALUE = 15;
	// The maximum amount of food a mouse can eat
	private static final int MAX_FOOD_LEVEL = 40;
	// the types of animals a mouse can eat
	private static final Class[] eatables = { Grass.class };
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	// The amount the hunger increases for every child born.
	private static final double FOOD_LOST_PER_BIRTH = 5;
	// The distance an animal can move in one step.
	private static final double MOVE_DISTANCE = 1.5;

	public Hamster(Field field, Location location) {
		super(field, location);
		setAge(0);
		setFoodLevel(MAX_FOOD_LEVEL);
	}

	/**
	 * Create a new hamster. A hamster may be created with age zero (a new born) or
	 * with a random age.
	 * 
	 * @param randomAge
	 *            If true, the hamster will have a random age.
	 * @param field
	 *            The field currently occupied.
	 * @param location
	 *            The location within the field.
	 */
	public Hamster(boolean randomAge, Field field, Location location) {
		super(field, location);
		setAge(0);
		if (randomAge) {
			setAge(rand.nextInt(MAX_AGE));
		}
		setFoodLevel(MAX_FOOD_LEVEL);
	}

	/**
	 * This is what the hamster does most of the time - it runs around. Sometimes it
	 * will breed or die of old age.
	 * 
	 * @param newHamster
	 *            A list to return newly born hamster.
	 */
	public void act(List<Actor> newHamster, int dayQuarter) {
		super.act(newHamster);
		if (dayQuarter == 1 || dayQuarter == 2) {
			if (isAlive())
				giveBirth(newHamster);
			if (isAlive()) {
				Location newLocation = move();
				if (newLocation == null)
					// Overcrowding.
					setDead();
			}
		}
	}

	@Override
	protected double getFoodForBirth() {
		return FOOD_LOST_PER_BIRTH;
	}

	/**
	 * Gets us the likelihood that an animal with give birth
	 *
	 * @return the likelihood that an animal with give birth
	 */
	@Override
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Get the maximum number of births an animal can give
	 *
	 * @return the maximum number of births an animal can give.
	 */
	@Override
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * A hamster can breed if it has reached the breeding age.
	 */
	@Override
	protected boolean canBreed() {
		return isAlive() && getAge() >= BREEDING_AGE;
	}

	@Override
	protected Animal getOffspring(Location location) {
		return new Hamster(false, getField(), location);
	}

	@Override
	protected int getCaloricValue() {
		return HAMSTER_CALORIC_VALUE;
	}

	@Override
	protected Class[] getAllEatables() {
		return eatables;
	}

	@Override
	protected int getMaxAge() {
		return MAX_AGE;
	}

	protected double getMoveDistance() {
		return MOVE_DISTANCE;
	}

}
