
import java.util.List;
import java.util.Random;

/**
 * A simple model of a mouse. mice age, move, eat grass, give birth and die.
 *
 * @version 2019.02.21
 */
public class Mouse extends Animal {
	// Characteristics shared by all mice (class variables).
	// The age at which a mouse can start to breed.
	private static final int BREEDING_AGE = 3;
	// The age to which a mouse can live.
	private static final int MAX_AGE = 15;
	// The likelihood of a mouse breeding.
	private static final double BREEDING_PROBABILITY = 0.65;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 4;
	// The caloric value a mouse has to offer
	private static final int MOUSE_CALORIC_VALUE = 20;
	// The maximum amount of food a mouse can eat
	private static final int MAX_FOOD_LEVEL = 40;
	// the types of animals a mouse can eat
	private static final Class[] eatables = { Grass.class };
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	// The amount the hunger increases for every child born.
	private static final double FOOD_LOST_PER_BIRTH = 5;
	// The distance an animal can move in one step.
	private static final double MOVE_DISTANCE = 1.5;

	/*
	 * public Mouse(Field field, Location location) { super(field, location);
	 * setAge(0); setFoodLevel(MAX_FOOD_LEVEL); }
	 */

	/**
	 * Create a mouse. A mosuse can be created as a new born (age zero and not
	 * hungry) or with a random age and food level.
	 *
	 * @param randomAge
	 *            If true, the mouse will have random age and hunger level.
	 * @param field
	 *            The field currently occupied.
	 * @param location
	 *            The location within the field.
	 */
	public Mouse(boolean randomAge, Field field, Location location) {
		super(field, location);
		setAge(0);
		if (randomAge) {
			setAge(rand.nextInt(MAX_AGE));
		}
		setFoodLevel(MAX_FOOD_LEVEL);
	}

	/**
	 * This is what the mouse does most of the time. In the process, it might breed,
	 * die of hunger, or die of old age.
	 * 
	 * @param newMice
	 *            A list to return newly born foxes.
	 */
	public void act(List<Actor> newMice, int dayQuarter) {
		super.act(newMice);
		if (dayQuarter != 1 || dayQuarter != 2) {
			if (isAlive())
				giveBirth(newMice);
			if (isAlive()) {
				Location newLocation = move();
				// See if it was possible to move.
				if (newLocation == null)
					// Overcrowding.
					setDead();
			}
		}
	}

	@Override
	protected double getFoodForBirth() {
		return FOOD_LOST_PER_BIRTH;
	}

	/**
	 * Gets us the likelihood that an animal with give birth
	 *
	 * @return the likelihood that an animal with give birth
	 */
	@Override
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}

	/**
	 * Get the maximum number of births an animal can give
	 *
	 * @return the maximum number of births an animal can give.
	 */
	@Override
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * A mouse can breed if it has reached the breeding age.
	 */
	@Override
	protected boolean canBreed() {
		return isAlive() && getAge() >= BREEDING_AGE;
	}

	@Override
	protected Animal getOffspring(Location location) {
		return new Mouse(false, getField(), location);
	}

	@Override
	protected int getCaloricValue() {
		return MOUSE_CALORIC_VALUE;
	}

	@Override
	protected Class[] getAllEatables() {
		return eatables;
	}

	@Override
	protected int getMaxAge() {
		return MAX_AGE;
	}

	protected double getMoveDistance() {
		return MOVE_DISTANCE;
	}

}
