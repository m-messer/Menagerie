/**
 * Enumerations of weather types.
 *
 * @version 2019.02.21
 */

public enum Weather{
    SUNNY, // kills trees
    STORMY; // kills animals

    /**
     * Returns a random weather from the enumeration
     * @return Random weather
     */
    public static Weather getRandomWeather(){
        // A random number generator for providing random locations.
        int index = Randomizer.getRandom().nextInt(values().length);
        return values()[index];
    }
}
