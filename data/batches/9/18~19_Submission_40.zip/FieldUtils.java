import java.util.List;
import java.util.function.Predicate;

/**
 * A class that would otherwise clutter up the Field class with methods that
 * aren't necessarily relevant to the field itself and only the animals who are
 * on it. It is used for basic searching so an actor can move towards what they
 * are looking for.
 * 
 * @version 2019.02.21
 */

public class FieldUtils {

	/**
	 * Provides the actor with the furthest location away from something that they
	 * can move to is. Useful for fleeing predators.
	 * 
	 * @param location
	 *            Location of the actor wishing to move
	 * @param locationDirection
	 *            Location of the actor that it is moving away from.
	 * @param moveDistance
	 *            The largest distance to which the actor can move.
	 * @param field
	 *            The field that the actors are on
	 * @return The location the actor should move to
	 */
	public static Location getFurthestLocationAway(Location location, Location locationDirection, double moveDistance,
			Field field) {

		List<Location> availableLocationsAway = getLocationsNotInDirection(location, locationDirection, moveDistance,
				field);

		if (availableLocationsAway == null || availableLocationsAway.size() == 0) {
			return null;
		}

		Location furthest = availableLocationsAway.get(0);
		int furthestDistance = (int) Math.floor(getDistance(furthest, location));

		for (int i = 1; i < availableLocationsAway.size(); i++) {
			int distance = (int) Math.floor(getDistance(availableLocationsAway.get(i), location));
			if (distance > furthestDistance) {
				furthest = availableLocationsAway.get(i);
				furthestDistance = distance;
			}
		}

		return furthest;
	}

	/**
	 * Returns locations that an actor can move to that will not bring it closer to
	 * an actor on the field.
	 * 
	 * @param location
	 *            The location of the moving actor.
	 * @param locationDirection
	 *            The location of the actor that the moving actor is avoiding.
	 * @param distance
	 *            The distance that the actor that is moving can move.
	 * @param field
	 *            The field that the actors are on.
	 * @return The suggested locations.
	 */
	private static List<Location> getLocationsNotInDirection(Location location, Location locationDirection,
			double distance, Field field) {
		List<Location> availableLocations = field.getFreeAdjacentLocations(location, (int) Math.ceil(distance));

		if (availableLocations.size() == 0)
			return null;
		double oldDistance = getDistance(location, locationDirection);
		for (int i = 0; i < availableLocations.size(); i++) {
			double newDistance = getDistance(availableLocations.get(i), locationDirection);
			if (newDistance < oldDistance)
				availableLocations.remove(i); // remove locations that would be closer to the locationDirection than the
												// current location
		}
		return availableLocations;
	}

	/**
	 * Returns the nearest food item within a moving range of the eater.
	 * 
	 * @param eater
	 *            The actor that is eating the food
	 * @param moveDistance
	 *            The largest distance the actor can move
	 * @param field
	 *            The field that the actor is on.
	 * @return The location of the nearest food, null if there isn't any
	 */

	public static Location getNearestFood(Actor eater, double moveDistance, Field field) {
		Predicate<Actor> condition = (Actor item) -> isFood(item, eater);
		return getNearestItemOnCondition(eater, moveDistance, field, condition);
	}

	/**
	 * Returns the nearest mate that the moving actor can mate with.
	 * 
	 * @param actor
	 *            The actor wishing to mate.
	 * @param mateDistance
	 *            The maximum distance to which a mate is returned.
	 * @param field
	 *            The field that actors are on.
	 * @return The location of the nearest mate, null if not found.
	 */
	public static Location getNearestMate(Actor actor, double mateDistance, Field field) {
		Predicate<Actor> condition = (Actor potentialMate) -> isMate(actor, potentialMate);
		return getNearestItemOnCondition(actor, mateDistance, field, condition);
	}

	/**
	 * Returns the nearest predator to an actor.
	 * 
	 * @param prey
	 *            The actor looking for a predator.
	 * @param viewDistance
	 *            The maximum distance a predator is returned.
	 * @param field
	 *            The field that the actors are on.
	 * @return The location of the nearest predator, null if one is not found.
	 */
	public static Location getNearestPredator(Actor prey, double viewDistance, Field field) {
		Predicate<Actor> condition = (Actor actor) -> isPredator(prey, actor);
		return getNearestItemOnCondition(prey, viewDistance, field, condition);
	}

	/**
	 * Returns the nearest item to the actor given a condition that the item must
	 * fulfill. The condition is set out by a predicate from
	 * java.util.function.Predicate and it is recommended that a lamda (accepting an
	 * Actor type and returning a boolean) is used here.
	 * 
	 * @param actor
	 *            The actor searching.
	 * @param viewDistance
	 *            The maximum distance to which the location of another actor is
	 *            returned.
	 * @param field
	 *            The field the actors are on.
	 * @param condition
	 *            The predicate that is tested for each item. Null is returned if
	 *            the condition is never met.
	 * @return The location of the nearest item meeting the condition.
	 */

	private static Location getNearestItemOnCondition(Actor actor, double viewDistance, Field field,
			Predicate<Actor> condition) {
		return getNearestItemOnCondition(actor.getLocation(), viewDistance, field, condition);
	}

	/**
	 * Returns the nearest item to the actor given a condition that the item must
	 * fulfill. The condition is set out by a predicate from
	 * java.util.function.Predicate and it is recommended that a lamda (accepting an
	 * Actor type and returning a boolean) is used here.
	 * 
	 * @param actorLocatiion
	 *            The locaton of the actor searching.
	 * @param viewDistance
	 *            The maximum distance to which the location of another actor is
	 *            returned.
	 * @param field
	 *            The field the actors are on.
	 * @param condition
	 *            The predicate that is tested for each item. Null is returned if
	 *            the condition is never met.
	 * @return The location of the nearest item meeting the condition.
	 */

	private static Location getNearestItemOnCondition(Location actorLocation, double viewDistance, Field field,
			Predicate<Actor> condition) {
		List<Location> adjacentLocations = field.adjacentLocations(actorLocation, (int) Math.ceil(viewDistance));
		if (adjacentLocations.size() == 0) {
			return null;
		}

		Location closestActorLocation = null;

		for (int i = 0; i < adjacentLocations.size(); i++) {
			Actor queriedActor = field.getActorAt(adjacentLocations.get(i));
			if (queriedActor != null && condition.test(queriedActor)) {
				Location nextActorLocation = adjacentLocations.get(i);
				if (closestActorLocation == null) {
					closestActorLocation = nextActorLocation;
				} else {
					double nextActorDistance = getDistance(nextActorLocation, actorLocation);
					if (nextActorDistance <= viewDistance) // if within sight
						if (nextActorDistance < getDistance(closestActorLocation, actorLocation)) // if closer
							closestActorLocation = nextActorLocation; // update closestActorLocation if this one is
																		// closer
				}
			}
		}
		return closestActorLocation;
	}

	/**
	 * Gives the distance between two field locations. The order of input does not
	 * matter.
	 * 
	 * @param locationA
	 *            The location of the first actor.
	 * @param locationB
	 *            The location of the second actor.
	 * @return The distance.
	 */

	public static double getDistance(Location locationA, Location locationB) {
		double xDistance = getXDistance(locationA, locationB);
		double yDistance = getYDistance(locationA, locationB);
		return Math.sqrt(Math.pow(xDistance, 2) + Math.pow(yDistance, 2));
	}

	/**
	 * Returns the horizontal distance between two locations. The order of input
	 * does not matter.
	 * 
	 * @param locationA
	 *            The location of the first actor.
	 * @param locationB
	 *            The location of the second actor.
	 * @return The horizontal distance.
	 */

	private static int getXDistance(Location locationA, Location locationB) {
		int Ax = locationA.getCol();
		int Bx = locationB.getCol();
		return Math.abs(Ax - Bx);
	}

	/**
	 * Returns the vertical distance between two locations. The order of input does
	 * not matter.
	 * 
	 * @param locationA
	 *            The location of the first actor.
	 * @param locationB
	 *            The location of the second actor.
	 * @return The vertical distance.
	 */

	private static int getYDistance(Location locationA, Location locationB) {
		int Ay = locationA.getRow();
		int By = locationB.getRow();
		return Math.abs(Ay - By);
	}

	/**
	 * Gives whether the given actor is a predator of the other given actor. The
	 * order of input DOES matter - you must give the tested actor first and its
	 * potential predator second.
	 * 
	 * @param potentialPrey
	 *            The actor that might be the prey.
	 * @param potentialPredator
	 *            The actor that might be a predator.
	 * @return Whether the 'potentialPredator' is a predator of the given actor.
	 */

	public static boolean isPredator(Actor potentialPrey, Actor potentialPredator) {
		if (potentialPrey == null || potentialPredator == null) {
			return false;
		}
		if (!potentialPredator.isAnimal()) {
			return false;
		}
		Class[] predatorsFood = ((Animal) potentialPredator).getAllEatables();
		for (int i = 0; i < predatorsFood.length; i++) {
			if (predatorsFood[i] == potentialPrey.getClass()) {
				return true;
			}
		}
		return false; // it isn't a predator if it doesn't eat this class
	}

	/**
	 * Gives whether the given actor is a food item (or prey) from the point of view
	 * of the second actor. The potential food item / prey must be given first and
	 * the eating actor second.
	 * 
	 * @param item The actor that we are testing.
	 * @param eater The actor that is doing the eating.
	 * @return Whether the actor 'item' is eatable by the actor 'eater'.
	 */

	public static boolean isFood(Actor item, Actor eater) {
		if (item == null || eater == null) {
			return false;
		}
		Animal animal;
		try {
			animal = (Animal) eater;
		} catch (Exception e) {
			return false; // it isn't food if the actor cannot eat
		}

		Class[] eatersFood = animal.getAllEatables();
		for (int i = 0; i < eatersFood.length; i++) {
			if (eatersFood[i] == item.getClass())
				return true;
		}
		return false;
	}

	/**
	 * Gives whether the given actors can mate.
	 * Due to the symmetry of the relation, order of input does not matter.
	 * @param actorA The first actor.
	 * @param actorB The second actor.
	 * @return Whether the given actors can mate.
	 */
	
	public static boolean isMate(Actor actorA, Actor actorB) {
		if (actorA == null || actorB == null) {
			return false;
		}
		Animal animalA = null;
		Animal animalB = null;
		try {
			animalA = (Animal) actorA;
			animalB = (Animal) actorB;
		} catch (Exception e) {
			return false; // they cannot mate if both aren't an animal.
		}

		boolean sameType = actorB.getClass().equals(actorA.getClass());
		if (!sameType)
			return false;

		boolean differentGenders = (!animalA.isFemale() && animalB.isFemale())
				|| (animalA.isFemale() && !animalB.isFemale());
		if (!differentGenders)
			return false;

		boolean bothCanBreed = (animalA.canBreed() && animalB.canBreed());
		if (!bothCanBreed)
			return false;

		return true; // they didn't fail under any of the conditions - they are mates
	}
}
