import java.util.List;

/**
 * Tree type. They are static do nothing but can be destroyed by weather and spawned in.
 * @version 2019.02.21
 */
public class Tree extends Plant {
	
	public Tree(Field field, Location location) {
		super(field,location);
		setImmortal(true); // trees cannot die in this simulation
	}
	
	@Override
	public void act(List<Actor> newActors, int dayQuarter) {
		// do nothing
	}

	@Override
	protected int getCaloricValue() {
		return -1; // cannot be eaten
	}

}
