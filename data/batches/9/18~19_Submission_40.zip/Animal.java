
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.21
 */
public abstract class Animal extends Actor {

	// Individual characteristics (instance fields).
	// The animal's age.
	private int age;
	// The animal's food level, which is increased by eating prey/plants.
	private double foodLevel;

	// Whether the animal is female or not
	private boolean female;
	// random object for sex designation
	private static final Random rand = Randomizer.getRandom();
	// a hashmap keeping track of diseases an animal has and a disease.getValue()
	// associated with it.
	private HashMap<Disease, Integer> diseases;
	// The distance an animal can see.
	private static final double VIEW_DISTANCE = 3;

	public Animal(Field field, Location location) {
		setAliveStatus(true);
		setField(field);
		setLocation(location);
		setImmortal(false); // all animals are not immortal by default.
		diseases = new HashMap<>();

		female = rand.nextDouble() <= 0.5;

		for (Disease dis : Disease.values())
			if (rand.nextDouble() <= 0.005)
				diseases.put(dis, rand.nextInt(10));
	}

	/**
	 * Returns an array of all the animal types that our instance can consume
	 *
	 * @return Array of all the animal types that our instance can consume
	 */
	abstract protected Class[] getAllEatables();

	/**
	 * Returns the maximum age the animal is allowed to get to;
	 *
	 * @return The maximum age.
	 */

	abstract protected int getMaxAge();

	/**
	 * Default implementation of the act method. All animals by default age and get
	 * hungry unless overriden. Parameters are ignored.
	 *
	 * @param animals
	 */

	public void act(List<Actor> animals) {
		incrementAge();
		incrementHunger();
		processDisease();
	}

	protected abstract double getFoodForBirth();

	/**
	 * Gets us the likelihood that an animal with give birth
	 *
	 * @return the likelihood that an animal with give birth
	 */
	abstract protected double getBreedingProbability();

	/**
	 * Get the maximum number of births an animal can give
	 *
	 * @return the maximum number of births an animal can give.
	 */
	abstract protected int getMaxLitterSize();

	/**
	 * Check whether or not this animal is to give birth at this step. New births
	 * will be made into free adjacent locations.
	 *
	 * @param newOffspring
	 *            A list to return newly born rabbits.
	 */
	protected void giveBirth(List<Actor> newOffspring) {
		// New animals are born into adjacent locations.
		// Get a list of adjacent free locations.
		List<Location> free = getField().getFreeAdjacentLocations(getLocation(),
				(int) Math.ceil(this.getMoveDistance()));
		if (getMateLocation() == null)
			return;
		int maxBirths = this.getMaxNumberOfBirths();
		for (int b = 0; b < maxBirths && free.size() > 0; b++) {
			if (foodLevel < getFoodForBirth() || !isAlive())
				return; // cannot give birth anymore if it doesn't have the food available or if dead
			Location loc = free.remove(0);
			Animal young = this.getOffspring(loc);

			// Uncomment to add hunger loss on birth: very difficult to get stable
			// parameters
			// young.setFoodLevel(getFoodForBirth()); // their default food level is this
			// value
			// this.incrementHunger(getFoodForBirth());

			newOffspring.add(young);
		}
	}

	/**
	 * Tells us whether the animal can breed or not Ideally, it should account into
	 * factors such as age or disease
	 *
	 * @return boolean value that is true if the animal can breed
	 */
	abstract protected boolean canBreed();

	/**
	 * Location the animal has moved to. The location is based on nearby predators
	 * and food and mates.
	 * 
	 * @return The location that the animal moved to. Null if it didn't move.
	 */
	protected Location move() {
		Location newLocation = findFood();
		if (newLocation != null)
			return newLocation;
		newLocation = fleeNearestPredator();
		if (newLocation != null)
			return newLocation;
		// Else move in a random direction
		// List<Location> availableLocations =
		// getField().getFreeAdjacentLocations(this.getLocation());
		// if (availableLocations.size() > 0) {
		// this.setLocation(availableLocations.get(0));
		// return availableLocations.get(0);
		// }
		return null;
	}

	/**
	 * Source code for this method used from
	 * https://stackoverflow.com/questions/1066589/iterate-through-a-hashmap
	 */
	protected void processDisease() {

		Iterator<Map.Entry<Disease, Integer>> it = diseases.entrySet().iterator();
		while (it.hasNext() && isAlive()) {
			Map.Entry<Disease, Integer> disease = it.next();
			switch (disease.getKey()) {
			case TUBERCULOSIS:
				if (disease.getValue() <= 0)
					setDead();
				break;
			case FEVER:
				if (disease.getValue() <= 0)
					it.remove();
				else // set food level somewhere from (2+0) to (2+4)
					incrementHunger(1);
				break;
			}
			// make the countdown value go down to zero
			disease.setValue(disease.getValue() - 1);
		}
	}

	private void catchDiseases(Set<Disease> diseases) {
		for (Disease disease : diseases) {
			if (!this.diseases.containsKey(disease)) {
				// 5+rand(6) = a number from 5+0 to 5+5 i.e. a value from 5 to 10
				this.diseases.put(disease, 5 + rand.nextInt(6));
			}
		}
	}
	
	/**
	 * @return The diseases the animal has.
	 */

	private Set<Disease> getDiseases() {
		return diseases.keySet();
	}

	/**
	 * @return Whether the animal is female.
	 */
	public boolean isFemale() {
		return female;
	}

	/**
	 * @return The age of the animal.
	 */
	protected int getAge() {
		return age;
	}

	/**
	 * @param age
	 *            The age to set the animal to.
	 */
	protected void setAge(int age) {
		this.age = age;
	}

	/**
	 * Increase the age. This could result in the animal's death.
	 */
	protected void incrementAge() {
		age++;
		if (age > this.getMaxAge()) {
			setDead();
		}
	}

	/**
	 * Make this animal more hungry. This could result in the animal's death.
	 *
	 * @param amount
	 *            The amount to decrease the food level by.
	 */
	protected void incrementHunger(double amount) {
		foodLevel -= amount;
		if (foodLevel <= 0) {
			setDead();
		}
	}

	/**
	 * Make this animal more hungry. This could result in the animal's death.
	 */
	private void incrementHunger() {
		double agePercentage = ((double) age) / ((double) getMaxAge()); // in the interval [0,1]
		incrementHunger(Math.pow(agePercentage, 1.3d));
	}

	/**
	 * Get the offspring of an animal
	 */
	abstract protected Animal getOffspring(Location location);

	/**
	 * Set food level
	 */
	protected void setFoodLevel(double level) {
		foodLevel = level;
	}

	/**
	 * Look for prey adjacent to the current location. Only the first live prey is
	 * eaten.
	 *
	 * @return Where food was found, or null if it wasn't.
	 */
	protected Location findFood() {

		// Get nearest food in view range
		Location foodLocation = FieldUtils.getNearestFood(this, this.getMoveDistance(), this.getField());
		if (foodLocation == null)
			return null; // no food visible
		// If the food location doesn't contain food then it must be the nearest
		// location
		// to the food the animal can get to.
		if (!FieldUtils.isFood(this.getField().getActorAt(foodLocation), this)) {
			this.setLocation(foodLocation);
			return foodLocation;
		}
		Actor prey = this.getField().getActorAt(foodLocation);
		if (prey.isAlive()) {
			prey.setDead();
			if (prey instanceof Animal) {
				this.catchDiseases(((Animal) prey).getDiseases());
				incrementHunger(-prey.getCaloricValue());
			}
			this.setLocation(foodLocation);
			return foodLocation;
		}
		return null;
	}

	/**
	 * Move away from the nearest predator and return the location moved to.
	 * @return Location moved to - null if it didn't move.
	 */
	protected Location fleeNearestPredator() {
		Location predatorLocation = FieldUtils.getNearestPredator(this, VIEW_DISTANCE, this.getField());
		if (predatorLocation == null)
			return null;
		Location newLocation = FieldUtils.getFurthestLocationAway(this.getLocation(), predatorLocation,
				this.getMoveDistance(), this.getField());
		if (newLocation != null)
			setLocation(newLocation);
		return newLocation;
	}

	/**
	 * @return the maximum number of animals the animal will give birth to.
	 */

	private int getMaxNumberOfBirths() {
		int maxBirths = 0;
		if (rand.nextDouble() <= getBreedingProbability())
			maxBirths = rand.nextInt(getMaxLitterSize()) + 1;
		return maxBirths;
	}

	/**
	 * @return The location of the nearest mate.
	 */
	protected Location getMateLocation() {
		Location mateLocation = FieldUtils.getNearestMate(this, this.getMoveDistance(), this.getField());
		if (mateLocation == null || this.getField().getActorAt(mateLocation) == null)
			return null;
		return mateLocation;
	}

	/**
	 * @return The maximum distance an animal can move in a given step.
	 */
	abstract protected double getMoveDistance();

	/**
	 * @return true always.
	 */
	@Override
	protected boolean isAnimal() {
		return true;
	}

}