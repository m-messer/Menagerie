import java.util.List;
import java.util.Random;

/**
 * 
 * A simple model of a jackal. Jackales age, move, eat rabbits, and die.
 *
 * @version 2019.02.21
 */

public class Jackal extends Animal {
	// Characteristics shared by all jackals (class variables).

	// The age at which a jackal can start to breed.
	private static final int BREEDING_AGE = 15;
	// The age to which a jackal can live.
	private static final int MAX_AGE = 150;
	// The likelihood of a jackal breeding.
	private static final double BREEDING_PROBABILITY = 0.81;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 4;
	// The caloric value a jackal has to offer
	private static final int JACKAL_CALORIC_VALUE = 30;
	// The maximum amount of food a jackal can eat
	private static final int MAX_FOOD_LEVEL = 30;
	// the types of animals a jackal can eat
	private static final Class[] eatables = { Hamster.class };
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	// The amount the hunger increases for every child born.
	private static final double FOOD_LOST_PER_BIRTH = 2;
	// The distance an animal can move in one step.
	private static final double MOVE_DISTANCE = 1.5;

	/**
	 * Create a jackal. A jackal can be created as a new born (age zero and not hungry) or
	 * with a random age and food level.
	 *
	 * @param randomAge
	 *            If true, the jackal will have random age and hunger level.
	 * @param field
	 *            The field currently occupied.
	 * @param location
	 *            The location within the field.
	 */
	public Jackal(boolean randomAge, Field field, Location location) {
		super(field, location);
		if (randomAge) {
			setAge(rand.nextInt(MAX_AGE));
			setFoodLevel(rand.nextInt(MAX_FOOD_LEVEL));
		} else {
			setAge(0);
			setFoodLevel(MAX_FOOD_LEVEL);
		}
	}

	/**
	 * This is what the jackal does most of the time: it hunts for rabbits. In the
	 * process, it might breed, die of hunger, or die of old age.
	 *
	 * @param newJackals
	 *            A list to return newly born jackals.
	 */
	public void act(List<Actor> newJackals, int dayQuarter) {
		super.act(newJackals);
		if (dayQuarter == 1 || dayQuarter == 2 || dayQuarter == 3) {
			if (isAlive())
				giveBirth(newJackals);
			if (isAlive()) {
				Location newLocation = move();
				// See if it was possible to move.
				if (newLocation == null)
					// Overcrowding.
					setDead();
			}
		}
	}

	/**
	 * A jackal can breed if it has reached the breeding age.
	 */
	protected boolean canBreed() {
		return getAge() >= BREEDING_AGE && isAlive();
	}

	/**
	 * The caloric value of a jackal
	 * 
	 * @return caloric value of a jackal
	 */
	protected int getCaloricValue() {
		return JACKAL_CALORIC_VALUE;
	}

	/**
	 * Return an array of all the food items a jackal can eat
	 */
	protected Class[] getAllEatables() {
		return eatables;
	}

	@Override
	protected int getMaxAge() {
		return MAX_AGE;
	}

	/**
	 * Gives us the offspring of this animal
	 * 
	 * @param location
	 *            spawn location
	 * @return offspring
	 */
	protected Animal getOffspring(Location location) {
		return new Jackal(false, getField(), location);
	}

	/**
	 * Get the maximum childbirths a jackal can have
	 * 
	 * @return maximum litter size of a jackal
	 */
	protected int getMaxLitterSize() {
		return MAX_LITTER_SIZE;
	}

	/**
	 * Get the probability of a jackal having children
	 * 
	 * @return probablity of a jackal having children
	 */
	protected double getBreedingProbability() {
		return BREEDING_PROBABILITY;
	}
	
	/**
	 * @return The amount of food the child gets and the adult loses when giving birth.
	 */

	protected double getFoodForBirth() {
		return FOOD_LOST_PER_BIRTH;
	}

	/**
	 * @return The maximum distance the animal can move in a given step.
	 */
	protected double getMoveDistance() {
		return MOVE_DISTANCE;
	}

}