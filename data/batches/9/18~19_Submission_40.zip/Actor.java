import java.util.List;

/**
 * A class that describes any living creature that can exist on a field.
 * @version 2019.02.21
 */

public abstract class Actor {

	// The actor's field.
	private Field field;
	// The actor's position in the field.
	private Location location;
	// Whether the actor is alive or not.
	private boolean alive;
	// Whether the actor is killable.
	private boolean immortal;

	/**
	 * Make this entity act - that is: make it do whatever it wants/needs to do.
	 *
	 * @param animals
	 *            A list to receive newly born animals.
	 */
	abstract public void act(List<Actor> animals, int dayQuarter);

	/*
	 * Getters and Setters
	 */

	/**
	 * Check whether the actor is alive or not.
	 * 
	 * @return true if the actor is still alive.
	 */
	public boolean isAlive() {
		return alive;
	}

	/**
	 * Says whether the actor is killable.
	 *
	 * @return Whether the actor is killable.
	 */
	public boolean isImmortal() {
		return immortal;
	}

	/**
	 * Manually set the alive status
	 * 
	 * @param isAlive
	 *            Whether the actor is being killed or spawned
	 */
	protected void setAliveStatus(boolean isAlive) {
		this.alive = isAlive;
	}

	/**
	 * Indicate that the actor is no longer alive. It is removed from the field.
	 */
	protected void setDead() {
		setAliveStatus(false);
		if (getLocation() != null) {
			getField().clear(getLocation());
			setLocation(null);
			setField(null);
		}
	}

	/**
	 * Return the actor's caloric value
	 * 
	 * @return Actor's caloric value
	 */
	abstract protected int getCaloricValue();

	/**
	 * Return the actor's field.
	 * 
	 * @return The actor's field.
	 */
	protected Field getField() {
		return field;
	}

	/**
	 * Return the actor's location.
	 * 
	 * @return The actor's location.
	 */
	protected Location getLocation() {
		return location;
	}

	/**
	 * Place the actor at the new location in the given field.
	 * 
	 * @param newLocation
	 *            The actor's new location.
	 */
	protected void setLocation(Location newLocation) {
		if (location != null) {
			field.clear(location);
		}
		location = newLocation;
		if (newLocation != null) {
			field.place(this, newLocation);
		}
	}

	/**
	 * Set the current field of the actor.
	 * 
	 * @param field
	 *            The new field.
	 */

	protected void setField(Field field) {
		this.field = field;
	}

	/**
	 * Set whether the actor is killable.
	 * 
	 * @param immortal
	 *            Wether the actor is killable.
	 */

	protected void setImmortal(boolean immortal) {
		this.immortal = immortal;
	}

	/**
	 * @return Whether the actor is a plant.
	 */
	protected boolean isPlant() {
		return false;
	}

	/**
	 * @return Whether the actor is an animal.
	 */

	protected boolean isAnimal() {
		return false;
	}

}
