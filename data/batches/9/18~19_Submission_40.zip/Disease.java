/**
 * Enumeration of disease types.
 *
 * @version 2019.02.21
 */

public enum Disease {
    TUBERCULOSIS,
    FEVER
}
