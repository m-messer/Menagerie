import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a buffalo.
 * buffalos age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class buffalo extends Prey
{
    // Characteristics shared by all buffalos (class variables).

    // The age at which a buffalo can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a buffalo can live.
    private static final int MAX_AGE = 65;
    // The likelihood of a buffalo breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_BABIES = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //Buffalos food level
    private int foodLevel;
    // The buffalo's gender.
    private boolean genderMale;
    /**
     * Create a new buffalo. A buffalo may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the buffalo will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public buffalo(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_BABIES);
    }
    
    /**
     * Check whether or not this buffalo is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newbuffalos A list to return newly born buffalos.
     */
    public void giveBirth(List<Organism> newbuffalos)
    {
        // New buffalos are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            Location loc = free.remove(0);
            buffalo young = new buffalo(false, field, loc);
            newbuffalos.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)
        {
            births = rand.nextInt(MAX_BABIES) + 1;
        }
        return births;
    }
 
    /**
     * A buffalo can breed if it has reached the breeding age.
     * @return true if the buffalo can breed, false otherwise.
     */
    public boolean canBreed()
    {
        boolean canBreed = false; 
        Field field = getField();
        for (Location i : field.adjacentLocations(getLocation()))
        {
            if (field.getObjectAt(i) instanceof buffalo)
            {
                buffalo buff = (buffalo) field.getObjectAt(i);
                if ((age >= BREEDING_AGE) && (buff.getGenderMale() != getGenderMale()))
                {
                    canBreed = true;
                }
            }
        }
        return canBreed;
    }    
}
