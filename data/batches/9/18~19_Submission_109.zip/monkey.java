import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a monkey.
 * monkeys age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class monkey extends Prey
{
    // Characteristics shared by all monkeys (class variables).

    // The age at which a monkey can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a monkey can live.
    private static final int MAX_AGE = 65;
    // The likelihood of a monkey breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_BABIES = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //monkeys food level
    private int foodLevel;   
    // The monkey's gender.
    private boolean genderMale;
    /**
     * Create a new monkey. A monkey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the monkey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public monkey(boolean randomAge, Field field, Location location)
    {
       super(randomAge, field, location, MAX_AGE, BREEDING_AGE, BREEDING_PROBABILITY, MAX_BABIES);
    }
    
    /**
     * Check whether or not this monkey is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newmonkeys A list to return newly born monkeys.
     */
    public void giveBirth(List<Organism> newmonkeys)
    {
        // New monkeys are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            Location loc = free.remove(0);
            monkey young = new monkey(false, field, loc);
            newmonkeys.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) 
        {
            births = rand.nextInt(MAX_BABIES) + 1;
        }
        return births;
    }

    /**
     * A monkey can breed if it has reached the breeding age.
     * @return true if the monkey can breed, false otherwise.
     */
    public boolean canBreed()
    {
        boolean canBreed = false; 
        Field field = getField();
        for (Location i : field.adjacentLocations(getLocation()))
        {
            if (field.getObjectAt(i) instanceof monkey)
            {
                monkey mon = (monkey) field.getObjectAt(i);
                if ((age >= BREEDING_AGE) && (mon.getGenderMale() != getGenderMale()))
                {
                    canBreed = true;
                }
            }
        }
        return canBreed;
    }
}
