
/**
 * Write a description of class Time here.
 *
 */
public class Time
{
    private int hours;
    private int displayTime;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        hours = 0;
        displayTime = 1200;
    }

    /**
     */
    public int getTime()
    {
        return displayTime;
    }
    
    public void timePassed(int hour)
    {
        hours = hours + hour;
        if (displayTime == 2400)
        {
            displayTime = 0;
        }
        displayTime = displayTime + (hour*100);
    }
    
    public boolean isEvening()
    {
        while ((displayTime >= 2200) || (displayTime <= 700))
        {
            return true;
        }
        return false;
    }
}
