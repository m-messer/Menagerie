import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Write a description of class Plant here.
 *
 */
public class plant extends Organism
{
    // instance variables - replace the example below with your own
    private int plant_FOOD_VALUE;
    private int age;
    private static int MAX_AGE;
    private static double REGROWTH_PROBABILITY;
    private static final Random rand = Randomizer.getRandom();
    

    /**
     * Constructor for objects of class Plant
     */
    public plant(Field field, Location location)
    {
        // initialise instance variables
        super(field,location);
        age = 0;
        MAX_AGE = 100;
        REGROWTH_PROBABILITY = 0.9;
        Weather weather = new Weather();
        plant_FOOD_VALUE = 30;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    private void incrementAge()
    {
        age = age + 1;
        
        if (age>MAX_AGE)
        {   
            setDead();
        }
    }
    
    private void regrow(List<Organism> newPlants, String weather)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocationsForPrey(getLocation());
        int grow = growth(weather);
        for (int g = 0; g < grow && free.size() > 0; g++)
        {
            Location loc = free.remove(0);
            plant newplant = new plant(field, loc);
            newPlants.add(newplant);
        }
    }
    
    public int growth(String weather)
    {
        int grow = 0;
        if (rand.nextDouble()<=REGROWTH_PROBABILITY)
        {
            if (!isRaining(weather))
            {
                grow = rand.nextInt(2)+1;
            }
            else
            {
                grow = rand.nextInt(4)+1;
            }
        }
        return grow;
    }
    
    public void act(List<Organism> newPlants, String weather)
    {
        incrementAge();
        if(isAlive())
        {
                regrow(newPlants, weather);
        }
    }
    
    public boolean isRaining(String weather)
    {
        if (weather.equals("rain"))
        {
           return true;
        }
        else
        {
           return false;
        }
    }
}
