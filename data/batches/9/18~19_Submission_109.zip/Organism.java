import java.util.List;

/**
 * A class representing shared characteristics of Organisms.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Organism
{
    // Whether the Organism is alive or not.
    private boolean alive;
    // The Organism's field.
    private Field field;
    // The Organism's position in the field.
    private Location location;
    //String to label which disease an animal has
    private String disease;
    
    /**
     * Create a new Organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this Organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born Organisms.
     */
    abstract public void act(List<Organism> newOrganisms, String weather);

    /**
     * Check whether the Organism is alive or not.
     * @return true if the Organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the Organism is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) 
        {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the Organism's location.
     * @return The Organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the Organism at the new location in the given field.
     * @param newLocation The Organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) 
        {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the Organism's field.
     * @return The Organism's field.
     */
    protected Field getField()
    {
        return field;
    }
}
