import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing buffalos and tigeres.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 250;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 175;
    // The probability that a tiger will be created in any given grid position.
    private static final double tiger_CREATION_PROBABILITY = 0.03;
    // The probability that a buffalo will be created in any given grid position.
    private static final double buffalo_CREATION_PROBABILITY = 0.08;    
    // The probability that a lion will be created in any given grid position.
    private static final double lion_CREATION_PROBABILITY = 0.03;
    // The probability that a monkey will be created in any given grid position.
    private static final double monkey_CREATION_PROBABILITY = 0.07;
    // The probability that a zebra will be created in any given grid position.
    private static final double zebra_CREATION_PROBABILITY = 0.07;
    // The probability that a plant will be created in any given grid position.
    private static final double plant_CREATION_PROBABILITY = 0.09;
    // List of Organisms in the field.
    private List<Organism> Organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Time stored in variable time of type Time
    private static Time time;
    //Day numbers passed is stored
    private int day;
    //Current weather is stored
    private Weather weather;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        weather = new Weather();
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        Organisms = new ArrayList<>();
        field = new Field(depth, width);
        day = 0;
        time = new Time();
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(buffalo.class, Color.ORANGE);
        view.setColor(tiger.class, Color.BLUE);
        view.setColor(lion.class, Color.RED);
        view.setColor(monkey.class, Color.YELLOW);
        view.setColor(zebra.class, Color.BLACK);
        view.setColor(plant.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (500 steps).
     */
    public void runLongSimulation()
    {
        simulate(500);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   //delay to make the simulation go slower
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * tiger and buffalo.
     */
    public void simulateOneStep()
    {
        step++;
        if (!time.isEvening()){
            // Provide space for newborn Organisms.
            List<Organism> newOrganisms = new ArrayList<>();        
            // Let all buffalos act.
            for(Iterator<Organism> it = Organisms.iterator(); it.hasNext(); ) {
                Organism Organism = it.next();
                Organism.act(newOrganisms, weather.getWeather());
                if(! Organism.isAlive()) {
                    it.remove();
                }
            }
            // Add the newly born tigeres and buffalos to the main lists.
            Organisms.addAll(newOrganisms);
        }
        weather.changeWeather();
        //change the weather
        view.showStatus(step, field, weather.getWeather());
     
        time.timePassed(1);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        Organisms.clear();
        populate();
        Weather weather = new Weather();
        weather.changeWeather();
        
        // Show the starting state in the view.
        view.showStatus(step, field, weather.getWeather());
    }
    
    /**
     * Randomly populate the field with all animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        //add animals to some rows and columns depending on their probability
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= tiger_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    tiger tiger = new tiger(true, field, location);
                    Organisms.add(tiger);
                }
                else if(rand.nextDouble() <= buffalo_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    buffalo buffalo = new buffalo(true, field, location);
                    Organisms.add(buffalo);
                }
                else if(rand.nextDouble() <= lion_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    lion lion = new lion(true, field, location);
                    Organisms.add(lion);
                }
                else if(rand.nextDouble() <= monkey_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    monkey monkey = new monkey(true, field, location);
                    Organisms.add(monkey);
                }
                else if(rand.nextDouble() <= zebra_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    zebra zebra = new zebra(true, field, location);
                    Organisms.add(zebra);
                }
                else if(rand.nextDouble() <= plant_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    plant plant = new plant(field, location);
                    Organisms.add(plant);
                }
            }
       }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Increment the number of days.
     */
    private void nextDay()
    {
        if (time.getTime() == 0)
        {
            day = day + 1;
        }
    }
}
