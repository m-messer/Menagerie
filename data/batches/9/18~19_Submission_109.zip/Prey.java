import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a prey.
 * preys age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Prey extends Organism
{
    // Characteristics shared by all preys (class variables).

    // The age at which a prey can start to breed.
    private int BREEDING_AGE;
    // The age to which a prey can live.
    private int MAX_AGE;
    // The likelihood of a prey breeding.
    private double BREEDING_PROBABILITY;
    // The maximum number of births.
    private int MAX_BABIES;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Value if a plant is eaten
    private static final int plant_FOOD_VALUE = 15;
    // The prey's food level, which is increased by eating plants
    private int foodLevel;
    // The prey's age.
    protected int age;
    // The prey's gender.
    private boolean genderMale;
    //Probability of being a male
    private static double male_CREATION_PROBABILITY = 0.5;
    //Toggle for whether the animal has this disease
    private boolean hasZoonosis;
    
    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Field field, Location location, int MAX_AGE, int BREEDING_AGE, double BREEDING_PROBABILITY, int MAX_BABIES)
    {
        //initialise all fields and set gender as well as age
        super(field, location);
        this.BREEDING_AGE = BREEDING_AGE;
        this.MAX_AGE = MAX_AGE;
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        this.MAX_BABIES = MAX_BABIES;
        if(rand.nextDouble() <= male_CREATION_PROBABILITY) 
        {
            genderMale = true;
        }
        else{
            genderMale = false;
        }
        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(20);
        }
        else 
        {
            age = 0;
            foodLevel = plant_FOOD_VALUE;
        }
        Random rand2 = Randomizer.getRandom();
        int temp2 = rand2.nextInt(100);
        if (temp2==1)
        {
            hasZoonosis = true;
        }
        else
        {
            hasZoonosis = false;
        }
    }
    
    /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newpreys A list to return newly born preys.
     */
    public void act(List<Organism> newpreys, String weather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) 
        {
            giveBirth(newpreys); 
            hasZoonosis();
            checkDisease();
            Location newLocation = findFood();
            if(newLocation == null)
            { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // Try to move into a free location.
            if(newLocation != null) 
            {
                setLocation(newLocation);
            }
            else 
            {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the prey's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE)
        {
            //Dies of old age
            setDead();
        }
    }
    
    /**
     * Increase the hunger.
     * This could result in the prey's death if they run out of food.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) 
        {
            //Dies of hunger
            setDead();
        }
    }
    
    abstract public void giveBirth(List<Organism> newPreys);
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        
        Field field = getField();
        List<Location> free = field.adjacentLocations(getLocation());
        Iterator<Location> it = free.iterator();
        //System.out.println("free locations iterator size" + free.size());
        while(it.hasNext()) 
        {
            //System.out.println("begin while loop");
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof plant) 
            {
                plant plantt = (plant) Organism;
                if(plantt.isAlive()) 
                { 
                    plantt.setDead();
                    foodLevel = plant_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check if the ajacent animals have the disease, if they do, then the animal
     * that is close id also infected
     */
    private void checkDisease()
    {
        Field field = getField();
        List<Location> free = field.adjacentLocations(getLocation());
        Iterator<Location> it = free.iterator();
        while(it.hasNext()) 
        {
            Location where = it.next();
            Object Organism = field.getObjectAt(where);
            if(Organism instanceof Prey) 
            {
                Prey prey = (Prey) Organism;
                if(prey.isAlive()) 
                { 
                    if (prey.checkZoonosis())
                    {
                        hasZoonosis = true;
                    }
                }
            }
        }
    }

    /**
     * Check for the gender of the animal
     */
    public boolean getGenderMale(){
        return genderMale;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    abstract public int breed(); 

    /**
     * A prey can breed if it has reached the breeding age.
     */
    abstract public boolean canBreed();
    
    /**
     *If the prey has been infected, their food level is decreased to simulate
     *the toll of the disease
     */
    public void hasZoonosis()
    {
        if (hasZoonosis)
        {
            foodLevel = foodLevel -2;
            hasZoonosis = true;
        }
    }
    
    /**
     * Check if the animal has the disease
     */
    public boolean checkZoonosis()
    {
        return hasZoonosis;
    }
}