import java.util.Random;

/**
 * Write a description of class Weather here.
 *
 */
public class Weather
{
    private static String currentWeather;
    private static final Random rand = Randomizer.getRandom();
    
    public Weather()
    {
        currentWeather = "Sunny";
    }
    
    public String changeWeather()
    {
        int randomNo = rand.nextInt(4);
        if ((randomNo == 0)||(randomNo==1))
        {
            currentWeather = "Sunny";
        }
        else if (randomNo == 2)
        {
            currentWeather = "Raining";
        }
        else if (randomNo == 3)
        {
            currentWeather = "Foggy";
        }
        return currentWeather;
    }
    
    public String getWeather()
    {
        return currentWeather;
    }
}
