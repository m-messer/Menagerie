import java.util.*;

/**
 * A simple model of a humans.
 * humans age, move, breed, and die.
 *
 * @version 2020.02.22 
 */
public class Humans extends Species
{
    // Characteristics shared by all humans (class variables).

    // The age at which a humans can start to breed.
    private static final int BREEDING_AGE = 10; // 10    
    // The age to which a humans can live.
    private static final int MAX_AGE = 60;
    
    // The likelihood of a humans breeding.
    private static final double BREEDING_PROBABILITY = 0.18;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3; 
    
    private static final int Plant_FOOD_VALUE = 3;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The humans's age.
    private int age;
    //The humans Food Level
    private int foodLevel;

    /**
     * Create a new humans. A humans may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the humans will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Humans(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
           foodLevel = rand.nextInt(10);
        }
        else { 
            age = 0;
            foodLevel = 10;
        }
    }
    
    /**
     * This is what the humans does most of the time - it runs 
     * around and eats plants. Sometimes it will breed or die of old age.
     * @param newhumans A list to return newly born humans.
     */
    public void act(List<Species> newhumans)
    {
        age = incrementAgee(age ,MAX_AGE); //increments the age
        if(isAlive()) {
            giveBirth(newhumans);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        
    }
    
    /**
     * Look for plant adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof Plants) {
                Plants plant = (Plants) species;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel  += Plant_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this humans is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newhumans A list to return newly born humans.
     */
    protected void giveBirth(List<Species> newhumans)
    {
        // New humans are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(age , BREEDING_AGE , BREEDING_PROBABILITY ,MAX_LITTER_SIZE);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Humans young = new Humans(false, field, loc);
            newhumans.add(young);
        }
    }
        
}

