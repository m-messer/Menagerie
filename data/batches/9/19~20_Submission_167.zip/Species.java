import java.util.*;

/**
 * A class representing shared characteristics of species.
 *
 * @version 2020.02.22 
 */
public abstract class Species
{ 
    // Whether the species is alive or not.
    private boolean alive;
    // The species's field.
    private Field field;
    // The species's position in the field.
    private Location location;
    // Variable to keep track of foodlevel
    private int foodLevel;
    // Variable to get location of food
    private Location FoodLocation;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new species at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Species(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this species act - that is: make it do
     * whatever it wants/needs to do.
     * @param newSpeciess A list to receive newly born Speciess.
     */
    abstract public void act(List<Species> newSpecies);

    /**
     * Check whether the specie is alive or not.
     * @return true if the specie is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the specie is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the specie's location.
     * @return The specie's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the specie at the new location in the given field.
     * @param newLocation The specie's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the specie's field.
     * @return The specie's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Increase the age. This could result in the species's death.
     */
    protected int incrementAgee(int age,int MAX_AGE)
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
        return age;
    }

    /**
     * Make this species more hungry. This could result in the species's death.
     */
    protected int incrementHunger(int foodLevel)
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
        return foodLevel;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(int age, int BREEDING_AGE , double BREEDING_PROBABILITY , int MAX_LITTER_SIZE)
    {
        int births = 0;
        if(canBreed(age,BREEDING_AGE) && rand.nextDouble() <= BREEDING_PROBABILITY) 
        {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A humans can breed if it has reached the breeding age.
     * @return true if the humans can breed, false otherwise.
     */
    private boolean canBreed(int age, int BREEDING_AGE)
    {
        return age >= BREEDING_AGE;
    }
}
