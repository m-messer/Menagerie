import java.util.*;
/**
 * Class to implement diffrent types of behaviour for weather .
 *
 * @version 2020.02.22 
 */
public class CurrentWeather
{
    // Variable of type weather
    Weather weather;
    // Variable to assign random weather
    private int WeatherIndex = 0;
    private static final Random rand = Randomizer.getRandom();
    /**
     * Constructor for objects of class CurrentWeather
     */
    public CurrentWeather()
    {
        weather = Weather.CLEAR;
    }
    
    /**
     * Method to change the Weather
     */
    private void setWeather(Weather newWeather)
    {
        weather = newWeather;
    }

    /**
     * Method to return the weather as a string
     */
    public String getWeather()
    {
        if(weather == Weather.CLEAR)
        {
            return "CLEAR"; 
        }
        else 
        {
            return "RAIN";
        }   
    }
    
    /**
     * Method to return the current weather
     */
    public Weather getCurrentWeather()
    {
        if(weather == Weather.CLEAR)
        {
            return Weather.CLEAR;
        }
        else
        {
            return Weather.RAIN;
        }
    }

    /**
     * Method to change the weather
     */
    public void ChangeWeather(int Wcheck)
    {
        if(Wcheck % 100 == 0)
        {
            WeatherIndex = rand.nextInt(2);
            if(WeatherIndex == 0)
            {
                setWeather(Weather.CLEAR);
            }
            else 
            {
                setWeather(Weather.RAIN);
            }
        }
    }
}
