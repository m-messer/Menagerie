import java.util.List;
import java.util.Random;

/**
 * A simple model of a Animals.
 * Animals age, move, breed, and die.
 *
 * @version 2020.02.22 
 */
public class Animals extends Species
{
    // Characteristics shared by all Animals (class variables).

    // The age at which a Animals can start to breed.
    private static final int BREEDING_AGE = 7; //7
    // The age to which a Animals can live.
    private static final int MAX_AGE = 50;  //50
    // The likelihood of a Animals breeding.
    private static final double BREEDING_PROBABILITY = 0.40;  //0.40
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20; //
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //Random index for gender 
    private int GiveGender;
    //Assign a gender 
    private Gender gender;
    // Individual characteristics (instance fields).

    // The Animals's age.
    private int age;

    /**
     * Create new Animals. A Animals may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Animals will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animals(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        GiveGender =  rand.nextInt(2);
        
        if(GiveGender == 0)
        {
            gender = Gender.MALE;
        }
        else
        {
            gender = Gender.FEMALE;
        }

        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the Animals does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newAnimals A list to return newly born Animals.
     */
    public void act(List<Species> newAnimals)
    {
        age = incrementAgee(age ,MAX_AGE); //Increments the age of animals
        if(isAlive()) {
            giveBirth(newAnimals);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this Animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Also checs if there is an animal of the opposite gender 
     * in the adjecent location before mating
     * @param newAnimals A list to return newly born Animals.
     */
    private void giveBirth(List<Species> newAnimals)
    {
        // New Animals are born into adjacent locations.
        // Get a list of adjacent free locations.

        Field field = getField();
        List<Location> adjecent = field.adjacentLocations(getLocation());
        for(Location location : adjecent)
        {
            Object obj = field.getObjectAt(location);
            //Checks if there is an animal of the opposite  gender 
            if(obj instanceof Animals)
            {
                Animals partner = (Animals) obj;
                if(partner.gender != this.gender)
                {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed(age , BREEDING_AGE , BREEDING_PROBABILITY ,MAX_LITTER_SIZE);
                    for(int b = 0; b < births && free.size() > 0; b++) 
                    {
                        Location loc = free.remove(0);
                        Animals young = new Animals(false, field, loc);
                        newAnimals.add(young);
                    }
                }
            }
        }

    }

}
