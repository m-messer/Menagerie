
/**
 * Enumeration class Gender - Gender is either Male or Female
 *
 * @version 2020.02.22 
 */
public enum Gender
{
    MALE , FEMALE 
}
