import java.util.*;

/**
 * A simple model of a AlphaPredator.
 * AlphaPredators age, move, eat animal, and die.
 *
 * @version 2020.02.22 
 */
public class AlphaPredator extends Species 
{
    // Characteristics shared by all AlphaPredators (class variables).

    // The age at which a AlphaPredator can start to breed.
    private static int BREEDING_AGE = 15; //15
    // The age to which a AlphaPredator can live.
    private static int MAX_AGE = 220;  //150
    // The likelihood of a AlphaPredator breeding.
    private static double BREEDING_PROBABILITY = 0.08; //08
    // The maximum number of births.
    private static  int MAX_LITTER_SIZE = 5; //5
    // The food value of a single animal. In effect, this is the
    // number of steps a AlphaPredator can go before it has to eat again.
    private static  int animal_FOOD_VALUE = 9;

    private static  int BetaPredator_FOOD_VALUE = 9;

    private static  int Human_FOOD_VALUE = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The AlphaPredator's age.
    private int age;
    // The AlphaPredator's food level, which is increased by eating animal.
    private int foodLevel;

    /**
     * Create a AlphaPredator. A AlphaPredator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the AlphaPredator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public AlphaPredator(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(10);
        }
        else {
            age = 0;
            foodLevel = 10;
        }
    }

    /**
     * This is what the AlphaPredator does most of the time: it hunts for
     * animal. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newAlphaPredators A list to return newly born AlphaPredators.
     */
    public void act(List<Species> newAlphaPredators)
    {
        age = incrementAgee(age ,MAX_AGE); //increments age
        foodLevel = incrementHunger(foodLevel); //changes the food level
        if(isAlive()) {
            giveBirth(newAlphaPredators);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            //foodLevel = GetFoodLevel();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    } 

    /**
     * Look for food adjacent to the current location.
     * Only the first live food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);

            if(species instanceof Humans)
            {
                Humans human = (Humans) species;
                if(human.isAlive()) { 
                    human.setDead();
                    foodLevel = Human_FOOD_VALUE;
                    return where;
                }
            }

            if(species instanceof Animals) {
                Animals animal = (Animals) species;
                if(animal.isAlive()) { 
                    animal.setDead();
                    foodLevel = animal_FOOD_VALUE;
                    return where;
                }
            }

            if(species instanceof BetaPredator)
            {
                BetaPredator bpredator = (BetaPredator) species;
                if(bpredator.isAlive()) { 
                    bpredator.setDead();
                    foodLevel = BetaPredator_FOOD_VALUE;
                    return where;
                }
            }  

        }
        return null;
    }

    /**
     * Check whether or not this AlphaPredator is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAlphaPredators A list to return newly born AlphaPredators.
     */
    private void giveBirth(List<Species> newAlphaPredators)
    {
        // New AlphaPredators are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(age , BREEDING_AGE , BREEDING_PROBABILITY ,MAX_LITTER_SIZE);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            AlphaPredator young = new AlphaPredator(false, field, loc);
            newAlphaPredators.add(young);
        }
    }    

}