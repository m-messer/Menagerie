import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple simulator, based on a rectangular field
 * containing all species.
 * @version 2020.02.22 
 */  
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 220;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a AlphaPredator will be created in any given grid position.
    private static final double Predat0r_CREATION_PROBABILITY = 0.04; //0.04
    // The probability that a animals will be created in any given grid position.
    private static final double animals_CREATION_PROBABILITY = 0.07; //07

    private static final double BPredat0r_CREATION_PROBABILITY = 0.04; //0.04

    private static final double Human_CREATION_PROBABILITY = 0.04; //04

    private static final double Plant_CREATION_PROBABILITY = 0.08; 
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // List of species in the field. 
    private List<Species> species;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //Variable to check for night time
    private boolean night = false;
    //Variable to keep track of time with steps
    private int TimeCheck = 0;
    //Variable to track weather
    private CurrentWeather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) 
        {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        species = new ArrayList<>();
        field = new Field(depth, width);
        weather = new CurrentWeather();
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Animals.class, Color.ORANGE);
        view.setColor(AlphaPredator.class, Color.RED);
        view.setColor(BetaPredator.class , Color.CYAN);
        view.setColor(Humans.class , Color.MAGENTA);
        view.setColor(Plants.class , Color.GREEN);
        // Setup a valid starting point. 
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) 
        {
            simulateOneStep();
            //delay(30);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * AlphaPredator and animals.
     */
    public void simulateOneStep()
    {
        step++;
        makeNight(); //To check for night 
        weather.ChangeWeather(step); //To change weather
        //Check if not night then make all the species act 
        if(night == false)
        {
            // Provide space for newborn species.
            List<Species> newSpecies = new ArrayList<>();        
            // Let all animals act.
            for(Iterator<Species> it = species.iterator(); it.hasNext(); ) 
            {
                Species species = it.next();
                //Increase the growth rate of plants in the rain 
                if(weather.getCurrentWeather() == Weather.RAIN && species instanceof Plants)
                {
                    Plants plant = (Plants) species;
                    plant.PlantGrowthRate(0.06 ,20);
                    plant.act(newSpecies);
                }
                else if(species instanceof Plants)
                {
                    Plants plant = (Plants) species;
                    plant.PlantGrowthRate(0.03 ,10);
                    plant.act(newSpecies);
                }
                //If not plants then normal Species act 
                else
                {
                    species.act(newSpecies);
                }

                if(! species.isAlive()) 
                {
                    it.remove();
                }
            }

            // Add the newly born AlphaPredators and animals to the main lists.
            species.addAll(newSpecies);

            view.showStatus(step, field ,weather);
        }
        //If night make only the alpha predators act
        else
        {
            List<Species> newSpecies = new ArrayList<>();        
            // Let all animals act.
            for(Iterator<Species> it = species.iterator(); it.hasNext(); ) 
            {
                Species species = it.next();
                if(species instanceof AlphaPredator )
                {
                    species.act(newSpecies);
                }

                if(! species.isAlive()) 
                {
                    it.remove();
                }
            }

            // Add the newly born AlphaPredators and animals to the main lists.
            species.addAll(newSpecies);
            view.showStatus(step, field , weather);
        }

    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        species.clear();
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field ,weather);
    }

    /**
     * Randomly populate the field with Species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Predat0r_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    AlphaPredator predator = new AlphaPredator(true, field, location);
                    species.add(predator);
                }
                else if(rand.nextDouble() <= animals_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Animals animals = new Animals(true, field, location);
                    species.add(animals);
                }
                else if(rand.nextDouble() <=  BPredat0r_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    BetaPredator Bpredator = new BetaPredator(true , field , location);
                    species.add(Bpredator);
                }
                else if(rand.nextDouble() <=  Human_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Humans human = new Humans(true , field , location);
                    species.add(human);
                }
                else if(rand.nextDouble() <= Plant_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Plants plant = new Plants(true , field , location);
                    species.add(plant);
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Increment Tcheck and make night true 
     */
    private void makeNight()
    {
        TimeCheck++;
        if(TimeCheck>=50 && TimeCheck<=100)
        {
            view.Night();
            night = true;
        }
        else if(TimeCheck > 100)
        {
            view.Day();
            night = false;
            TimeCheck=0;
        }
    }

    /**
     * Return the truth value of night
     */
    public boolean checkNight()
    {
        return night;
    }

}
