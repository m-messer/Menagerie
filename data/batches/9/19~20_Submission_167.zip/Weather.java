
/**
 * Enumeration class Weather - Weather is either clear or sunny
 *
 * @version 2020.02.22 
 */
public enum Weather
{
    CLEAR, RAIN;
}
