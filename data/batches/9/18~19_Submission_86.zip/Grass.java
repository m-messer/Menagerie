import java.util.List;
import java.util.Random;

/**
 * A simple model of Grass.
 * Grass age, spread seeds, breed, and die.
 *
 * @version 2019.02.19 (3)
 */
public class Grass extends Plant {

    // The age to which a grass can live.
    private static final int MAX_AGE = 5;
    // The likelihood of grass releasing seeds.
    private static final double SEED_PROBABILITY = 0.05;
    // The minimum age at which grass can release seeds.
    private static final int FERTILE_AGE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The maximum amount of seeds a square if grass can release.
    private static final int MAX_SEEDS_RELEASED = 4;

    // The age of the plant
    private int age;

    /**
     * Create Grass. Grass can be created as a new born (age zero)
     * or with a random age.
     *
     * @param randomAge If true, the Grass will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the grass does most of the time.
     * Sometimes it will release seeds or wither of old age.
     * @param newGrass A list to return newly seeded grass.
     */
    public void act(List<Plant> newGrass, String weather, boolean night)
    {
        incrementAge();
        if(isAlive() && weather.equals("sunny") && !night) {
            spreadSeeds(newGrass);
        }
    }

    /**
     * Increase the age.
     * This could result in the grass' death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not the grass is mature enough to release seeds.
     * New seeds will grow into free adjacent locations.
     * @param newGrass A list to return newly grown grass.
     */
    private void spreadSeeds(List<Plant> newGrass)
    {
        // New grass grows into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentPlantLocations(getLocation());
        int seeds = growSeeds();
        for(int b = 0; b < seeds && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass seed = new Grass(false, field, loc);
            newGrass.add(seed);
        }
    }

    /**
     * Generate a number representing the number of seeds spread,
     * if it can release seeds.
     * @return The number of seeds spread (may be zero).
     */
    private int growSeeds()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= SEED_PROBABILITY) {
            births = rand.nextInt(MAX_SEEDS_RELEASED) + 1;
        }
        return births;
    }

    /**
     * Grass can release seeds if it has reached the fertile age.
     * @return true if grass can spreadSeeds, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= FERTILE_AGE;
    }
}
