import java.util.List;
import java.util.Iterator;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.19 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's gender.
    private String gender;
    // Whether or not the animal is infected with an STD
    private boolean std;
    // Whether or not the animal has eaten a poisonous food source
    private boolean poisoned = false;
    // The animal's food level
    private int foodLevel;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);

        if (Math.random() > 0.48) {
            gender = "F";
        } else gender = "M";

        if (Math.random() > 0.99) std = true;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newAnimals, boolean night) {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newAnimals);

            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    };

    /**
     * Increase the age.
     * This could result in the Animal's death.
     */
    abstract protected void incrementAge();

    /**
     * Make this Animal more hungry. This could result in the Animal's death.
     */
    abstract  protected void incrementHunger();

    /**
     * Check whether or not this Animal is able to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born Animals.
     */
    abstract protected void giveBirth(List<Animal> newAnimals);

    /**
     * Look for food.
     * @return Where food was found, or null if it wasn't.
     */
    abstract protected Location findFood();

    /**
     * Return whether or not the Animal has STDs
     * @return the STD status of the Animal.
     */
    public boolean getSTD()
    {
        return std;
    }

    /**
     * Give STDs to this Animal.
     */
    protected void giveSTD()
    {
        std = true;
    }

    /**
     * Return whether or not the Animal is poisoned.
     * @return the poison status of the Animal.
     */
    public boolean getPoisoned()
    {
        return poisoned;
    }

    /**
     * Set the poisoned value of this Animal.
     * @param poisoned the boolean value to be set.
     */
    public void setPoisoned(boolean poisoned)
    {
        this.poisoned = poisoned;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clearActor(location);
            location = null;
            field = null;
        }
    }

    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clearActor(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the Animal's gender.
     * @return the Animal's gender.
     */
    private String getGender()
    {
        return gender;
    }

    /**
     * Checks if the animal is next to one of the same species
     * but of different genders and if breeder is a female.
     * Potential spreading of STDs involved.
     * @param breederClass the sub-class of the this Animal.
     * @return whether or not this Animal can breed.
     */
    protected boolean canBreed(Class breederClass)
    {
        if (gender.equals("M")){
            return false;
        }
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (breederClass.isInstance(animal)) {
                Animal partner = (Animal) animal;
                if (partner.getClass().equals(breederClass)) {
                    if (!partner.getGender().equals(gender) ) {
                        // Chance of transmitting STD upon breeding attempt
                        if (Math.random() > 0.95 && std) {
                            partner.giveSTD();
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Get the food value of the animal if it is eaten.
     * @return the food value of the animal.
     */
    abstract public int getFoodValue();

    /**
     * Set the Animal's foodLevel.
     * Set to max if arg is 0.
     * @param foodLevel value to add.
     */
    abstract public void setFoodLevel(int foodLevel);
}
