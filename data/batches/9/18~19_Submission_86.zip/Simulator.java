import java.util.*;
import java.awt.Color;
import java.util.ArrayList;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing mice, lions, condors, gazelles and coyotes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a Lion will be created in any given grid position.
    private static final double Lion_CREATION_PROBABILITY = 0.02;
    // The probability that a Mouse will be created in any given grid position.
    private static final double Mouse_CREATION_PROBABILITY = 0.08; //change
    // The probability that a Gazelle will be created in any given grid position.
    private static final double Gazelle_CREATION_PROBABILITY = 0.04; //change
    // The probability that a Condor will be created in any given grid position.
    private static final double Condor_CREATION_PROBABILITY = 0.1; //change
    // The probability that a Coyote will be created in any given grid position.
    private static final double Coyote_CREATION_PROBABILITY = 0.08; //change
    // The probability that grass will be created in any given grid position.
    private static final double Grass_CREATION_PROBABILITY = 0.3;
    // The probability that ivy will be created in any given grid position.
    private static final double Ivy_CREATION_PROBABILITY = 0.05;
    // The different weather types in the game.
    private static final String[] WEATHER = {"sunny", "rain", "thunder", "wind"};
    // The plants' growth probability mapped to the weather
    // in WEATHER at same index (i.e 0.05 on sunny days)
    private static final double[] PLANT_GROWTH_PROBABILITY = {0.05, 0.035, 0, 0.025};
    

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the plant field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current weather.
    private String currentWeather;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Mouse.class, Color.YELLOW);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Coyote.class, Color.CYAN);
        view.setColor(Condor.class, Color.BLUE);
        view.setColor(Gazelle.class, Color.PINK);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(PoisonIvy.class, Color.RED);
        
        // Setup a valid starting point.
        reset();
        
        // Start the simulation on a sunny day
        currentWeather = WEATHER[0];
    }

    public static void main(String[] args)
    {
        Simulator sim = new Simulator();
        sim.simulate(400);
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    
    private boolean nightTime()
    {
        // Alternate between night/day (true/false) every 12 steps (full day = 24 steps)
        // if (step%24 < 12) return false; // Uncomment for a 24 step long day.
        if (step%2 < 1) return false;
        else return true;
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all Animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, nightTime());
            if (animal.getSTD()) {
                if (Math.random() > 0.9) animal.setDead();
            }
            if (animal.getPoisoned()) {
                if (Math.random() > 0.95) animal.setDead();
            }
            if (!animal.isAlive()) {
                it.remove();
            }
        }

        // Provide space for newborn plants.
        List<Plant> newPlants = new ArrayList<>();
        // Let all Plants act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants, currentWeather, nightTime());
            if(! plant.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals and newly grown plants to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);

        randomPlantGrowth();

        view.showStatus(step, field);
        
        changeWeather();
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with the animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Lion_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion Lion = new Lion(true, field, location);
                    animals.add(Lion);
                }
                else if(rand.nextDouble() <= Mouse_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse Mouse = new Mouse(true, field, location);
                    animals.add(Mouse);
                }
                else if(rand.nextDouble() <= Coyote_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Coyote Coyote = new Coyote(true, field, location);
                    animals.add(Coyote);
                }
                else if(rand.nextDouble() <= Condor_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Condor Condor = new Condor(true, field, location);
                    animals.add(Condor);
                }
                else if(rand.nextDouble() <= Gazelle_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Gazelle Gazelle = new Gazelle(true, field, location);
                    animals.add(Gazelle);
                }
                if (rand.nextDouble() <= Grass_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass Grass = new Grass(true, field, location);
                    plants.add(Grass);
                }
                else if (rand.nextDouble() <= Ivy_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    PoisonIvy Ivy = new PoisonIvy(true, field, location);
                    plants.add(Ivy);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Randomly grow plants on the field. This avoids groups of
     * herbivore animals creating an entire area void of plants.
     * Random plant growth is dependent on the weather. Plants
     * should grow fastest during sunny days and not at all during
     * thunderstorms.
     */
    private void randomPlantGrowth()
    {
        double growthProbability = PLANT_GROWTH_PROBABILITY[Arrays.asList(WEATHER).indexOf(currentWeather)];
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if (field.getPlantAt(row, col) == null) {
                    if (rand.nextDouble() <= growthProbability) {
                        Location location = new Location(row, col);
                        Grass Grass = new Grass(false, field, location);
                        plants.add(Grass);
                    }
                    else if (rand.nextDouble() <= growthProbability/4) {
                        Location location = new Location(row, col);
                        PoisonIvy Ivy = new PoisonIvy(false, field, location);
                        plants.add(Ivy);
                    }
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Change the weather. There cannot be two
     * consecutive days of thunder.
     */
    private void changeWeather()
    {
        // We can have maximum one consecutive day of thunder.
        if (currentWeather.equals("thunder")) {
            while (currentWeather.equals("thunder")) {
                Random rand = new Random();
                currentWeather = WEATHER[rand.nextInt(WEATHER.length)];
            }
            return;
        }
        Random rand = new Random();
        currentWeather = WEATHER[rand.nextInt(WEATHER.length)];

        // Set the weather to the field so it can be accessed by the GUI.
        field.setWeather(currentWeather);
    }
}
