import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing predators (Sharks, Blue Whales and Groupers), prey (Clown fish, Flounder and Bluetang) and Plants (Seaweed).
 * There is also a diver.
 *
 * The simulator is influenced by a day/night rhythm, changing weather and spreading diseases.
 *
 * @version 2019.02.22
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a bluetang will be created in any given grid position.
    private static final double BLUETANG_CREATION_PROBABILITY = 0.4;
    // The probability that a bluewhale will be created in any given grid position.
    private static final double BLUEWHALE_CREATION_PROBABILITY = 0.2;
    //The probability that a clownfish will be created in any given grid position
    private static final double CLOWNFISH_CREATION_PROBABILITY = 0.4;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.1;
    // The probability that a grouper will be created in any given grid position.
    private static final double GROUPER_CREATION_PROBABILITY = 0.1;
    // The probability that a flounder will be created in any given grid position.
    private static final double FLOUNDER_CREATION_PROBABILITY = 0.5;
    // The probability that seaweed will be created in any given grid position
    private static final double SEAWEED_CREATION_PROBABILITY = 0.05;
    // The probability that a living being can be created
    private static final double LIVING_BEING_CREATION_PROBABILITY = 0.9;
    private static final double DISEASE_PROBABILITY = 0.01;
    // The default probability that a bluetang will breed
    private static final double BLUETANG_BREEDING_PROBABILITY = 1;
    // The default probability that a bluewhale will breed
    private static final double BLUEWHALE_BREEDING_PROBABILITY = 0.3;
    //The default probability that a clownfish will breed
    private static final double CLOWNFISH_BREEDING_PROBABILITY = 1;
    // The the default probability that a shark will breed
    private static final double SHARK_BREEDING_PROBABILITY = 0.4;
    // The default probability that a grouper will breed
    private static final double GROUPER_BREEDING_PROBABILITY = 0.35;
    // The default probability that a flounder will breed
    private static final double FLOUNDER_BREEDING_PROBABILITY = 1;

    // Amount of steps per day/night
    private static final int STEPS_PER_DAY = 100;

    // instance fields
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Steps left in current day
    private int daySteps;
    // Day or Night
    private boolean day;
    // Current weather: CALM, STORM, BOILING, FREEZING
    private Weather currentWeather;
    // Steps left for current weather
    private int weatherSteps;
    // breeding probability shark
    private double probShark;
    // breeding probability bluewhale
    private double probBlueWhale;
    // breeding probability bluetang
    private double probBlueTang;
    // breeding probability grouper
    private double probGrouper;
    // breeding probability clownfish
    private double probClownFish;
    // breeding probability flounder
    private double probFlounder;

    /**
     * Construct a simulation field with default size and the default breeding probabilities.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH, SHARK_BREEDING_PROBABILITY, BLUETANG_BREEDING_PROBABILITY, BLUETANG_BREEDING_PROBABILITY, GROUPER_BREEDING_PROBABILITY,
                CLOWNFISH_BREEDING_PROBABILITY, FLOUNDER_BREEDING_PROBABILITY);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * @param breeding probability sharks
     * @param breeding probability bluewhales
     * @param breeding probability bluetang
     * @param breeding probability grouper
     * @param breeding probability clownfish
     * @param breeding probability flounder
     */
    public Simulator(int depth, int width, double probShark, double probBlueWhale, double probBlueTang, double probGrouper, double probClownFish, double probFlounder) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        // initialize breeding probabilities
        this.probShark = probShark;
        this.probBlueWhale = probBlueWhale;
        this.probBlueTang = probBlueTang;
        this.probGrouper = probGrouper;
        this.probClownFish = probClownFish;
        this.probFlounder = probFlounder;

        // list for all living animals and plants
        this.animals = new ArrayList<>();
        this.plants = new ArrayList<>();
        this.field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        // set colors for prey and predators
        view.setColor(BlueTang.class, Color.CYAN);
        view.setColor(BlueWhale.class, Color.BLUE);
        view.setColor(ClownFish.class, Color.ORANGE);
        view.setColor(Shark.class, Color.RED);
        view.setColor(Grouper.class, Color.BLACK);
        view.setColor(Flounder.class, Color.MAGENTA);
        view.setColor(Diver.class, Color.LIGHT_GRAY);
        view.setColor(Seaweed.class, Color.GREEN);

        // starts with daylight
        this.day = true;
        // amount of steps in a day
        this.daySteps = STEPS_PER_DAY;
        // default weather is calm
        this.currentWeather = Weather.CALM;
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000, false);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     * @param boolean If true the window will get destroyed after the simulation.
     */
    public int simulate(int numSteps, boolean destroyView) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // uncomment this to run more slowly
            //delay(200);
        }

        if(destroyView){
            // closes window
            view.dispose();
        }

        // returns number of steps
        return step;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * member of the simulation.
     */
    public void simulateOneStep() {
        step++;
        // tries to change day/night
        setDayNight();
        // tries to update weather
        setWeather();

        // if there is a storm shuffles the population
        if (currentWeather == Weather.STORM && ((step % 15) == 0)) {
            repopulate();
        } else if (((step % 15) < 10 && (step % 15) >= 0) || currentWeather != Weather.FREEZING) { // when it's freezing it only acts 10 out of 15 steps
            // Provide space for newborn animals.
            List<Animal> newAnimals = new ArrayList<>();
            List<Plant> newPlants = new ArrayList<>();
            // Let all animals act.
            for (Iterator<Animal> it = animals.iterator(); it.hasNext();) {
                Animal animal = it.next();
                animal.act(newAnimals, day);
                if (!animal.isAlive()) {
                    it.remove();
                }
            }
            // Let all plants act.
            for (Iterator<Plant> it = plants.iterator(); it.hasNext();) {
                Plant plant = it.next();
                plant.act(newPlants, day);
                if (plant.isEaten()) {
                    it.remove();
                }
            }

            // Add the newly born animals and plants to the main list.
            animals.addAll(newAnimals);
            plants.addAll(newPlants);
        } else if (currentWeather == Weather.BOILING) { // if weather is boiling then kills a random number of animals and plants
            Random rand = Randomizer.getRandom();
            int animalsRange = 100 + (rand.nextInt(100-10) + 1);
            int plantsRange = 150 + (rand.nextInt(150-100) + 1);
            if (animalsRange < animals.size()) {
                for (int i = 0; i < animalsRange && !animals.isEmpty(); i++) {
                    Animal randomAnimal = animals.get(rand.nextInt(animals.size()));
                    randomAnimal.setDead();
                    animals.remove(randomAnimal);
                }
            }
            if (plantsRange < plants.size()) {
                for (int i = 0; i < plantsRange && !plants.isEmpty(); i++) {
                    Plant randomPlant = plants.get(rand.nextInt(plants.size()));
                    randomPlant.setEaten();
                    plants.remove(randomPlant);
                }
            }
        }
        // shows variables in GUI
        view.showStatus(step, field, day, currentWeather.getName(), weatherSteps);
    }

    /**
     * Changes day/night after a number of steps and changes color of background.
     */
    public void setDayNight() {
        daySteps--;
        // if number of steps are done; change day/night
        if (daySteps == 0) {
            daySteps = STEPS_PER_DAY;
            day =! day;
            view.setEmptyColor(day);

        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        // repopulates the field
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field, day, currentWeather.getName(), weatherSteps);
    }

    /**
     * Calculates if a newborn animals has a disease or not.
     * @return boolean true if it has a disease, false if not
     */
    private boolean diseaseProb() {
        Random rand = Randomizer.getRandom();
        return (rand.nextDouble() < DISEASE_PROBABILITY);
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        // clears field
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                // check if any animal or plant should be created
                if (rand.nextDouble() <= LIVING_BEING_CREATION_PROBABILITY) {
                    int livingBeingNumber = rand.nextInt(7);
                    // randomly decides which animal or plant to create
                    switch (livingBeingNumber) {
                        case 0:
                            if (rand.nextDouble() <= BLUETANG_CREATION_PROBABILITY) {
                                Location location = new Location(row, col);
                                BlueTang blueTang = new BlueTang(false, field, location, rand.nextBoolean(), diseaseProb(), probBlueTang);
                                animals.add(blueTang);
                            }
                            break;
                        case 1:
                            if (rand.nextDouble() <= BLUEWHALE_CREATION_PROBABILITY) {
                                Location location = new Location(row, col);
                                BlueWhale blueWhale = new BlueWhale(false, field, location, rand.nextBoolean(), false, probBlueWhale);
                                animals.add(blueWhale);
                            }
                            break;
                        case 2:
                            if (rand.nextDouble() <= CLOWNFISH_CREATION_PROBABILITY) {
                                Location location = new Location(row, col);
                                ClownFish clownFish = new ClownFish(false, field, location, rand.nextBoolean(), probClownFish);
                                animals.add(clownFish);
                            }
                            break;
                        case 3:
                            if (rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                                Location location = new Location(row, col);
                                Shark shark = new Shark(false, field, location, rand.nextBoolean(), false, probShark);
                                animals.add(shark);
                            }
                            break;
                        case 4:
                            if (rand.nextDouble() <= GROUPER_CREATION_PROBABILITY) {
                                Location location = new Location(row, col);
                                Grouper grouper = new Grouper(false, field, location, rand.nextBoolean(), false, probGrouper);
                                animals.add(grouper);
                            }
                            break;
                        case 5:
                            if (rand.nextDouble() <= FLOUNDER_CREATION_PROBABILITY) {
                                Location location = new Location(row, col);
                                Flounder flounder = new Flounder(false, field, location, rand.nextBoolean(), diseaseProb(), probFlounder);
                                animals.add(flounder);
                            }
                            break;
                        case 6:
                            if (rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY) {
                                Location location = new Location(row, col);
                                Seaweed seaweed = new Seaweed(field, location, diseaseProb());
                                plants.add(seaweed);
                            }
                            break;
                        default:
                            break;
                    }
                }
                // else leave the location empty.
            }
        }
        // a single diver is always created, there is only one diver
        Diver diver = new Diver(field, new Location(rand.nextInt(field.getDepth()), rand.nextInt(field.getWidth())));
        animals.add(diver);
    }

    /**
     * Shuffles all animals and plants in the field and assigns them new random locations.
     */
    private void repopulate() {
        Random rand = Randomizer.getRandom();
        List<Animal> prevAnimals = new ArrayList<>(animals);
        List<Plant> prevPlants = new ArrayList<>(plants);
        // iterates through all animals and create an animal with the same attributes at a new location
        prevAnimals.forEach(animal -> {
            String animalType = animal.getClass().getSimpleName();
            animal.setDead();
            animals.remove(animal);
            Location location = new Location(rand.nextInt(field.getDepth()), rand.nextInt(field.getWidth()));
            switch (animalType)  {
                case "BlueTang":
                    BlueTang blueTang = new BlueTang(false, field, location, animal.isMale(), animal.isDiseased(), probBlueTang);
                    animals.add(blueTang);
                    break;
                case "BlueWhale":
                    BlueWhale blueWhale = new BlueWhale(false, field, location, animal.isMale(), animal.isDiseased(), probBlueWhale);
                    animals.add(blueWhale);
                    break;
                case "ClownFish":
                    ClownFish clownFish = new ClownFish(false, field, location, animal.isMale(), probClownFish);
                    animals.add(clownFish);
                    break;
                case "Shark":
                    Shark shark = new Shark(false, field, location, animal.isMale(), animal.isDiseased(), probShark);
                    animals.add(shark);
                    break;
                case "Grouper":
                    Grouper grouper = new Grouper(false, field, location, animal.isMale(), animal.isDiseased(), probGrouper);
                    animals.add(grouper);
                    break;
                case "Flounder":
                    Flounder flounder = new Flounder(false, field, location, animal.isMale(), animal.isDiseased(), probFlounder);
                    animals.add(flounder);
                    break;
                case "Diver":
                    Diver diver = new Diver(field, location);
                    animals.add(diver);
                    break;
                default:
                    break;
            }
        });
        // iterates through all plants and create a plant with the same attributes at a new location
        prevPlants.forEach(plant -> {
            Location location = new Location(rand.nextInt(field.getDepth()), rand.nextInt(field.getWidth()));
            plant.setEaten();
            plants.remove(plant);
            Seaweed seaweed = new Seaweed(field, location, plant.isDiseased());
            plants.add(seaweed);
        });
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Updates the current weather to a random weather enum value with a set probability to update
     */
    public void setWeather() {
        if (weatherSteps == 0) {
            Random rand = Randomizer.getRandom();
            Weather[] weatherTypes = Weather.values();
            // chooses random weather
            Weather weather = weatherTypes[rand.nextInt(weatherTypes.length)];
            // decides with certain probability if there is a weather change
            if (rand.nextDouble() <= weather.getProbability()) {
                currentWeather = weather;
            } else {
                currentWeather = Weather.CALM; // Calm is the default weather
            }
            // random number how long this weather phase takes
            weatherSteps = 25 + (rand.nextInt(25-10) + 1);
        }
        weatherSteps--;
    }
}
