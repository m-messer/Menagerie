import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Flounder.
 * Flounders age, move, eat Seaweed, and die.
 * They can get infected with a disease, then they will die after some time.
 * There is also Weather and Day/Night circle changing their behavior.
 * Bluetangs breed less at night.
 * @version 2019.02.22
 */

public class Flounder extends Animal {
    // Characteristics shared by all Flounders (class variables).

    // The age at which a Flounder can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Flounder can live.
    private static final int MAX_AGE = 300;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The steps a Flounder will survive after it got infected by the disease
    private static final int LIVING_DAYS = 5;
    // The food value of plants. In effect, this is the
    // number of steps a Flounder can go before it has to eat again.
    private static final int FOOD_VALUE = 25;

    // Individual characteristics (instance fields).

    // The Flounder's age.
    private int age;
    // The Flounder's food level, which is increased by eating plants.
    private int foodLevel;
    // Boolean, saying if flounder has a disease or not
    private boolean disease;
    // Stores the amount of steps a flounder is already infected by the disease
    private int diseaseCounter;
    // The likelihood of a Flounder breeding.
    private double breedingProb;

    /**
     * Create a new Flounder. A Flounder may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Flounder will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param boolean True if male
     * @param boolean True if it has a disease, false if not
     * @param double The breeding probability of this animal.
     */
    public Flounder(boolean randomAge, Field field, Location location, boolean male, boolean disease, double breedingProb) {
        super(field, location, male, disease);
        this.breedingProb = breedingProb;
        // start healthy
        diseaseCounter = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * This is what the Flounder does most of the time - it eats plants.
     * Sometimes it will breed, die of hunger, die of a disease or die of old age.
     * @param newFlounders A list to return newly born Flounders.
     * @param boolean True if it is daytime, false at night.
     */
    public void act(List<Animal> newFlounders, boolean day) {
        // increments the age, hunger
        incrementAge();
        incrementHunger();
        // checks if disease is affecting it
        daysLeft();
        if (isAlive()) {
            // if it is female tries to breed, at night it is less likely that they breed
            if ((day && !isMale()) || (!isMale() && rand.nextDouble() <= 0.1))  {
                giveBirth(newFlounders);
            }
            // Try to find food.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Flounder's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Flounder more hungry. This could result in the Flounder's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * If flounder is diseased, counts the days it still has to live.
     */
    private void daysLeft() {
        if (disease) {
            diseaseCounter++;
            if (diseaseCounter == LIVING_DAYS) {
                setDead();
            }
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        // gets adjacent fields
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // iterates through adjacent fields
        while (it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            // if occupied field is found, check if is acceptable food
            // if plant is not eaten, set it to eaten and add food value
            // if plant has disease set disease to true
            if (plant instanceof Seaweed) {
                Plant seaweed = (Plant) plant;
                if (!seaweed.isEaten()) {
                    seaweed.setEaten();
                    foodLevel = FOOD_VALUE;
                    if (seaweed.isDiseased() && (rand.nextDouble() <= seaweed.getDiseaseProbability())) {
                        disease = true;
                    }
                    return where;
                }
            }
        }
        return null;
    }





    /**
     * Check whether or not this Flounder is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFlounders A list to return newly born Flounders.
     */
    private void giveBirth(List<Animal> newFlounders) {
        // New Flounders are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // gets amount of new flounders and adds as many flounders.
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean diseased = rand.nextDouble() <= getDiseaseProbability();
            Flounder young = new Flounder(false, field, loc, rand.nextBoolean(), diseased, breedingProb);
            newFlounders.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // check if there is a partner in an adjacent location
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            // checks if it is also of type flounder
            if (animal instanceof Flounder) {
                Flounder flounder = (Flounder) animal;
                // checks if both flounders have different genders, are alive and can breed.
                // randomizer to make sure they only breed certain times
                if (flounder.isAlive() && flounder.canBreed() && flounder.isMale() && canBreed() && (rand.nextDouble() <= breedingProb)) {
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                    return births;
                }
            }
        }
        return births;
    }

    /**
     * A Flounder can breed if it has reached the breeding age.
     * @return true if the Flounder can breed, false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
}
