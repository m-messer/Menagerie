import java.util.List;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2019.02.22
 */
public abstract class Plant {
    private final double DISEASE_PROBABILITY = 0.05;
    // Whether the plant is eaten or not.
    private boolean eaten;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // Whether the plant has a disease or not
    private boolean disease;

    /**
     * Create a new plant at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param boolean True if has disease, false if not.
     */
    public Plant(Field field, Location location, boolean disease) {
        // initilize field
        this.eaten = false;
        this.field = field;
        this.disease = disease;
        setLocation(location);
    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants.
     * @param boolean True if day, false if night
     */
    abstract public void act(List<Plant> newPlants, boolean day);

    /**
     * Check whether the plant has disease or not.
     * @return true if the plant has disease.
     */
    protected boolean isDiseased() {
        return disease;
    }

    /**
     * Check whether the plant is eaten or not.
     * @return true if the plant is eaten.
     */
    protected boolean isEaten() {
        return eaten;
    }

    /**
     * Indicate that the plant is eaten.
     * It is removed from the field.
     */
    protected void setEaten() {
        eaten = true;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Return the plant's disease probability.
     * @return double The probability that the plant gets infected with the disease.
     */
    protected double getDiseaseProbability() {
        return DISEASE_PROBABILITY;
    }
}
