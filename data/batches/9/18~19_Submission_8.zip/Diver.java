import java.util.List;
import java.util.Iterator;
/**
 *
 * A simple model of a Diver.
 * The diver moves, kills everything and can only die because of weather.
 * There is never more than one diver present at any time.
 *
 *
 * @version 2019.02.22
 */

public class Diver extends Animal {

    /**
     * Create a Diver. A Diver can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * Set constant age, not random
     *
     * @param randomAge If true, the Diver will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Diver(Field field, Location location) {
        super(field, location, true, false);
    }

    /**
     * This is what the Diver does most of the time: it hunts for
     * everything.
     * @param field The field currently occupied.
     * @param newDivers A list to return newly born Divers.
     * @param Weather The current weather.
     */
    public void act(List<Animal> newDivers, boolean day) {
        if (isAlive()) {
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            } else if (newLocation != null) {
                setLocation(newLocation);
            }
        }
    }

    /**
     * Look for animals and plants adjacent to the current location.
     * Only the first animal/plant found is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // iterates through all free locations, checks if animal/plant is there, sets it to dead
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Animal) {
                Animal food = (Animal) animal;
                if (food.isAlive()) {
                    food.setDead();
                    return where;
                }
            } else if (animal instanceof Plant) {
                Plant food = (Plant) animal;
                if (food.isEaten()) {
                    food.setEaten();
                    return where;
                }

            }
        }
        return null;
    }
}
