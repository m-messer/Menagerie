/**
 * A class to run the simulation.
 * There are two options:
 * If there are no command line arguments in the runs a normal simulation with default values specified in Simulator.
 * If the user types TEST, it will run n random breeding probability configurations and print the configuration and
 * the average number of steps the simulation survives.
 * Allows to test code outside of BlueJ.
 * @version 2019.02.22
 */
import java.util.ArrayList;
import java.util.Random;

public class Builder {
    private static final Random rand = Randomizer.getRandom();

    public static void main(String[] args) {

        ArrayList<Integer> allsteps = new ArrayList<>();

        // default only runs one simulation
        int usecase = 0;

        // if command line argument is TEST runs different test cases
        if (args.length > 0) {
            if (args[0].equals("TEST")) {
                usecase = 1;
            } else {
                // wrong argument, gives options
                System.out.println("Argument must be 'TEST'");
            }
        }

        // standard usecase, run one simulation
        if (usecase == 0) {
            Simulator sim = new Simulator();
            sim.simulate(2000, false);
        } else { // tests 1000 random values of breeding probabilities and returns the amount of steps survived

            double bluewhale = rand.nextDouble();
            double shark = rand.nextDouble();
            double grouper = rand.nextDouble();
            double flounder = rand.nextDouble();
            double bluetang = rand.nextDouble();
            double clownfish = rand.nextDouble();

            int i = 0;

            while (i < 1000) {

                // runs every config 5 times and gets average
                for (int j = 0; j < 5; j++) {

                    Simulator sim = new Simulator(100, 100, bluewhale, bluetang, clownfish, flounder, grouper, shark);
                    int steps = sim.simulate(2000, true);
                    allsteps.add(steps);
                }
                // prints out the probabilities and the steps the simulation survived
                System.out.println(shark + " " + clownfish + " " + bluetang + " " + flounder + " " + bluewhale + " " + grouper + " " +
                        calcAverage(allsteps));

                // clears the list
                allsteps.clear();
                // assigns new random values
                bluetang = rand.nextDouble();
                bluewhale = rand.nextDouble();
                clownfish = rand.nextDouble();
                flounder = rand.nextDouble();
                grouper = rand.nextDouble();
                shark = rand.nextDouble();
                i++;
            }
        }
    }

    /**
     * Calculates the average amount of steps for the same configuration.
     * @param List with the number of steps
     * @return double the average number of steps
     */
    private static double calcAverage(ArrayList<Integer> allsteps) {

        int sum = 0;
        for(int i : allsteps) {
            sum += i;
        }
        return sum / (allsteps.size());
    }
}
