import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Grouper.
 * Groupers age, move, eat Clownfish, Bluetangs and Flounders, and die.
 * They can get infected with a disease, then they will die after some time.
 * There is also Weather and Day/Night circle changing their behavior.
 * Grouper move less at night.
 * @version 2019.02.22
 */
public class Grouper extends Animal {
    // Characteristics shared by all Groupers (class variables).

    // The age at which a Grouper can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Grouper can live.
    private static final int MAX_AGE = 80;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of its prey. In effect, this is the
    // number of steps a Grouper can go before it has to eat again.
    private static final int FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The steps a grouper will survive after it got infected by the disease
    private static final int LIVING_DAYS = 5;

    // Individual characteristics (instance fields).

    // The Grouper's age.
    private int age;
    // The Grouper's food level, which is increased by eating rabbits.
    private int foodLevel;
    // Boolean, saying if grouper has a disease or not
    private boolean disease;
    // Stores the amount of steps a grouper is already infected by the disease
    private int diseaseCounter;
    // The likelihood of a Grouper breeding.
    private double breedingProb;

    /**
     * Create a Grouper. A Grouper can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Grouper will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param boolean True if male
     * @param boolean True if has disease, false if not
     * @param double The breeding probability of this animal.
     */
    public Grouper(boolean randomAge, Field field, Location location, boolean male, boolean disease, double breedingProb) {
        super(field, location, male, disease);
        this.breedingProb = breedingProb;
        // grouper start healthy
        diseaseCounter = 0;
        // if there is an age provided grouper is that old, otherwise group is newly born
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * This is what the Grouper does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger, die of a disease
     * or die of old age.
     * @param newGroupers A list to return newly born Groupers.
     * @param boolean True if it is daytime, false at night
     */
    public void act(List<Animal> newGroupers, boolean day) {
        // increments the age, hunger
        incrementAge();
        incrementHunger();
        // checks if disease is affecting it
        daysLeft();
        // checks if grouper is alive
        if (isAlive()) {
            // if it is female tries to breed
            if (!isMale()) {
                giveBirth(newGroupers);
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // moves less at night
            if (day || rand.nextDouble() <= 0.5) {
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the Grouper's death.
     */
    private void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Grouper more hungry. This could result in the Grouper's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * If Grouper is diseased, counts the day it still has to live.
     */
    private void daysLeft() {
        if(disease) {
            diseaseCounter++;
            if(diseaseCounter == LIVING_DAYS) {
                setDead();
            }
        }
    }

    /**
     * Look for prey adjacent to the current location.
     * Only the prey alive is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        // gets adjacent fields
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // iterates through adjacent fields
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            // if occupied field is found, check if is acceptable food
            // if prey is alive, set it to dead and add food value
            // if prey has disease set disease to true
            if (animal != null) {
                switch (animal.getClass().getSimpleName()) {
                    case "ClownFish":
                        ClownFish clownFish = (ClownFish) animal;
                        if (clownFish.isAlive()) {
                            clownFish.setDead();
                            foodLevel = FOOD_VALUE;
                        }
                        break;
                    case "BlueTang":
                        BlueTang blueTang = (BlueTang) animal;
                        if (blueTang.isAlive()) {
                            blueTang.setDead();
                            foodLevel = FOOD_VALUE;
                            if (blueTang.isDiseased() && (rand.nextDouble() <= getDiseaseProbability())) {
                                disease = true;
                            }
                            return where;
                        }
                        break;
                    case "Flounder":
                        Flounder flounder = (Flounder) animal;
                        if (flounder.isAlive()) {
                            flounder.setDead();
                            foodLevel = FOOD_VALUE;
                            if (flounder.isDiseased() && (rand.nextDouble() <= getDiseaseProbability())) {
                                disease = true;
                            }
                            return where;
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Grouper is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGroupers A list to return newly born Groupers.
     */
    private void giveBirth(List<Animal> newGroupers) {
        // New Groupers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // gets amount of new groupers and adds as many groupers.
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grouper young = new Grouper(false, field, loc, rand.nextBoolean(), false, breedingProb);
            newGroupers.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // check if there is a partner in an adjacent location
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            // checks if it is also a grouper
            if (animal instanceof Grouper) {
                Grouper grouper = (Grouper) animal;
                // checks if both grouper have different gender are alive and can breed
                // randomizer to make sure they only breed certain times
                if (grouper.isAlive() && grouper.canBreed() && grouper.isMale() && canBreed() && (rand.nextDouble() <= breedingProb)) {
                    births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                    return births;
                }
            }
        }
        return births;
    }

    /**
     * A Grouper can breed if it has reached the breeding age.
     * @return true if the grouper can breed, false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
}
