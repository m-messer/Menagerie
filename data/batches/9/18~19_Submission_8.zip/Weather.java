/**
 * A simple enum providing the probabilities
 * for the different weather.
 *
 * Methods to get probability and name of weather.
 *
 * @version 2019.02.22
 */

public enum Weather {
    // weather states available
    CALM ("Calm", 0.8),
    STORM ("Storm", 0.1),
    BOILING ("Boiling", 0.3),
    FREEZING ("Freezing", 0.4);

    // name of weather
    private String name;
    // probability that weather changes to this weather
    private double probability;

    /**
     * Values in enum weather consist of:
     * @param name of the weather
     * @param probability that the weather changes to it
     */
    private Weather(String name, double probability) {
        this.name = name;
        this.probability = probability;
    }

    /**
     * @return probability that the weather changes
     */
    public double getProbability() {
        return probability;
    }

    /**
     * @return name of weather
     */
    public String getName() {
        return name;
    }
}
