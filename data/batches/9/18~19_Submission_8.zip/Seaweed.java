import java.util.List;
import java.util.Random;

/**
 * A simple model of Seaweed.
 * Seaweed gets eaten and can grow to adjacent locations.
 * I can also have a disease and spread it to animals eating it.
 *
 * @version 2019.02.22
 */
public class Seaweed extends Plant {

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create Seaweed.
     *
     * @param randomAge If true, the seaweed will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param boolean True if seaweed has disease, false if not.
     */
    public Seaweed(Field field, Location location, boolean disease) {
        super(field, location, disease);
    }

    /**
     * This is what seaweed does most of the time - it moves.
     * It can grow to adjacent fields.
     *
     * @param newSeaweed A list to return new seaweed.
     * @param boolean True if daylight, false if night.
     */
    public void act(List<Plant> newSeaweed, boolean day) {
        if (!isEaten()) {
            // at night grows slower
            if (day || rand.nextDouble() <= 0.4) {
                grow(newSeaweed);
            }
        }
    }

    /**
     * Let's seaweed grow to free adjacent locations.
     * @param newWeed A list to return newly created seaweed.
     */
    private void grow(List<Plant> newWeed) {
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // number of new seaweed
        int births = create();
        // creates new seaweed
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seaweed young = new Seaweed(field, loc, (rand.nextDouble() <= getDiseaseProbability()));
            newWeed.add(young);
        }
    }

     /**
     * Generate a number representing the number of new seaweed;
     * if it can create.
     * @return The number of new seaweed (may be zero).
     */
    private int create() {
        int newSeaweed = 0;
        // probability new seaweed gets created
        if (rand.nextDouble() <= 0.15) {
            newSeaweed = 1;
        }
        return newSeaweed;
    }
}
