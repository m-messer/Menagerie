import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    
    //Whether the animal is sleeping
    public boolean sleeping;
    
    //Whether the animal is male 
    private boolean male;
    
    //Whether the animal is next to the opposite gender of the same species
    private boolean meet;
    
    //Whether the animal can see
    protected boolean see;
    
    //Whether the animal is touching another animal
    private boolean touch;
    
    //Whether the animal is diseased
    private boolean diseased;
    
    //Probability of disease
    private static final double DISEASE_PROBABILITY = 0.0005;
    
    //Probability of spreading disease
    private static final double TRANSMISSION_PROBABILITY = 0.035;
    
    //Max age of animal
    protected int MAX_AGE;
    
    //Animal's food level (how many steps it has before it need to eat again)
    protected double foodLevel;
    
    //Animal's age
    protected int age;
    
    //Animal's breeding age
    protected int breedingAge;
    
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        chooseGender();
        checkDisease();
        sleeping = false;
        see = true;
    }
    
    /**
     * Set the max age of an animal
     * @param age The age to be set
     */
    protected void setMaxAge(int age)
    {
        MAX_AGE = age;
    }

    /**
     * Make this animal more hungry. This could result in it's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Increase the age. This could result in it's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Animals need to sleep to rest
     * @param hour The current hour of the day
     */
    abstract public void sleep(int hour);
    
    /**
     * Make the animal sleep indefinitely (until otherwise changed)
     */
    public void sleepLong()
    {
        sleeping = true;
    }
    
    /**
     * Randomly set an animal to be diseased or not
     */
    protected void checkDisease()
    {
        if (rand.nextDouble() <= DISEASE_PROBABILITY){
            diseased = true;
            age = MAX_AGE - 5;
        }
        else{
            diseased = false;
        }
    }
    
    /**
     * Check whether an animal is diseased
     * @return True if animal is diseased
     */
    public boolean getDiseased()
    {
        return diseased;
    }
    
    /**
     * Set the animal to be diseased
     */
    protected void setDiseased()
    {
        diseased = true;
    }
    
    /**
     * Check if an animal has passed on disease to another
     */
    protected void checkTransmission()
    {
        //Iterate through the field
        Field field = getField();
        List<Location> loc = field.adjacentLocations(getLocation());
        Iterator<Location> it = loc.iterator();
        while(it.hasNext()) {
            //Obtain object at location in field
            Location where = it.next();
            Object object = field.getObjectAt(where);
            //Check whether object is an animal and if current animal is diseased
            if (object instanceof Animal && this.getDiseased()){
                Animal animal = (Animal) object;
                Random rand = Randomizer.getRandom();
                //Randomly set next animal to be diseased
                if (rand.nextDouble() <= TRANSMISSION_PROBABILITY){
                    animal.setDiseased();
                }
            }
        }
    }
    

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Check whether the animal is male 
     * @return true if the animal is male
     */
    protected boolean isMale()
    {
        return male;
    }

    
    /**
     * Allow animal to be able to see normal
     * @return boolean see to be true
     */
    protected boolean canSee()
    {
        return see = true;
    }
    
    /**
     * Don't allow animal to see normally
     * @return booelan see to be false
     */
    protected boolean canNotSee()
    {
        return see = false;
    }
    
    /**
     * Get random number
     * @return 0 or 1
     */
    protected int random()
    {
        Random rand = Randomizer.getRandom();
        return rand.nextInt(2);
    }
    
    /**
     * Choose gender of animal
     */
    protected void chooseGender()
    {
        random();
        if (random() == 0){
            male = true;
        }
        else{
            male = false;
        }
    }
    
    /**
     * Set the age of which the animal can start breeding
     * @param age Age of which it can breed
     */
    protected void setBreedingAge(int age)
    {
        breedingAge = age;
    }
    
    /**
     * Check whether animal can breed or not
     * @return True if it can breed
     */
    protected boolean canBreed()
    {
        if (age >= breedingAge && getMeet()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Check whether animal has met opposite gender of its species
     */
    protected boolean getMeet()
    {
        //Iterate through field
        Field field = getField();
        List<Location> loc = field.adjacentLocations(getLocation());
        Iterator<Location> it = loc.iterator();
        while(it.hasNext()) {
            //Obtain animal at location in field
            Location where = it.next();
            Object object = field.getObjectAt(where);
            //Check if animal obtained and current animal are of same species
            if (object instanceof Animal){
                if (object.getClass().equals(getClass())){
                    Animal animal = (Animal) object;
                    //Check if genders are opposite
                    if (animal.isMale() != this.isMale()){
                        meet = true;
                    }
                    else{
                        meet = false;
                    }
                }
            }
        }
        return meet;
    }
    
     /**
     * Check whether the animal is sleeping or not.
     * @return true if the animal is still sleeping.
     */
    protected boolean isSleeping()
    {
        return sleeping;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Get free locations in field
     */
    protected void getFreeLoc()
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
}
