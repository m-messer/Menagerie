
/**
 * Displays the clock 
 *
 * @version 2022.02.23 
 */
public class ClockWork
{
    //The limit of the clockwork
    private int limit;
    //The value of the clockwork
    private int value;

    /**
     * Constructor for the clockwork
     * @param rollOverLimit The desired limit of the clockwork
     */
    public ClockWork(int rollOverLimit)
    {
        limit = rollOverLimit;
        value = 0;
    }

    /**
     * @return the current value.
     */
    public int getValue()
    {
        return value;
    }
    
    /**
     * Set the value 
     * @param num The desired value to be set
     */
    public int setValue(int num)
    {
        value = num;
        return value;
    }

    /**
     * @return the value of the time
     * If it is a single digit then the number will have a 0 in front of it
     */
    public String getDisplayValue()
    {
        if(value < 10) {
            return "0" + value;
        }
        else {
            return "" + value;
        }
    }

    /**
     * Increment the hour value by one
     * Roll over to zero if the limit is reached.
     */
    public void incrementHour()
    {
        value = (value + 1) % limit;
    }
    
    /**
     * Increment the minute value by 10
     * Roll over to zero if the limit is reached
     */
        public void incrementMinute()
    {
        value = (value + 10) % limit;
    }

}
