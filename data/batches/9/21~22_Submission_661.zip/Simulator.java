import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import javax.swing.JOptionPane;     // imported this library to allow the use of pop up dialog boxes.
import java.util.concurrent.TimeUnit;      //to delay the code
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 110;
    
    // The probability that different forms of life
    //will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.023;
    private static final double RABBIT_CREATION_PROBABILITY = 0.08;  
    private static final double WOLF_CREATION_PROBABILITY = 0.022;
    private static final double MOUSE_CREATION_PROBABILITY = 0.06;
    private static final double DEER_CREATION_PROBABILITY = 0.05;
    private static final double PLANT_CREATION_PROBABILITY = 0.05;
    
    // List of animals in the field.
    private List<Animal> animals;
    private List<Plant> plants;
    private List<Animal> diseased;
    
    // The current state of the field.
    private Field field;
    
    // The current step of the simulation.
    private int step;
    
    // A graphical view of the simulation.
    private SimulatorView view;
    private FieldStats stats;
    private Weather weather;
    private Clock clock;
    private String displayString;
    
    
    private int bpressed;
    private int pause;
    private boolean running;
    
    private int numberofsteps;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        stats = new FieldStats();
        clock = new Clock();
        weather = new Weather();
        running = true;
        buttonPressed();
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        //create lists of living entities
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        diseased = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Mouse.class, Color.MAGENTA);
        view.setColor(Deer.class, Color.CYAN);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
    
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>(); 
        //Provide space for plants
        List<Plant> newPlants = new ArrayList<>();
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
        
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
            if (animal.getDiseased()){
                diseased.add(animal);
            }
        }
        
        //Let all plants grow
        for (Iterator<Plant> it = plants.iterator(); it.hasNext();){
            Plant plant = it.next();
            plant.grow(newPlants);
        }
        
        //events to happen as time passes
        clock.timeTick();
        dayPassed();
        checkWeather();
        
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals); 
        plants.addAll(newPlants);
        view.showStatus(clock.getTime(),weather.getWeather(), step, field);

    }
    
    /**
     * Check for a button press
     * Execute command depending on which button is pressed
     */  
    public void buttonPressed()
    {
        while(running) {
            bpressed = view.getButtonPressed();
            
            if (bpressed == (0)) {
                try
                    {
                    Thread.sleep(500);
                    }
                catch(InterruptedException ex)
                    {
                       Thread.currentThread().interrupt();
                    }
            }
            
            if (bpressed != 0)   {
                break;
            }
            
        }
        
        if (bpressed == 1)  {
            reset();
            clock.resetClock();
            view.noButtonPressed();
            buttonPressed();
        }
        
        if (bpressed == 2)  {
            runLongSimulation();
            view.noButtonPressed();
            buttonPressed();
        }
        
        if (bpressed == 3)  {
            String s = JOptionPane.showInputDialog(null,"How many steps do you want to simulate?","Input",1);
            simulate(Integer.parseInt(s));
            view.noButtonPressed();
            buttonPressed();
        }
        
        if (bpressed == 4)  {
            simulateOneStep();
            view.noButtonPressed();
            buttonPressed();
        }
        
    }
    
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {   
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus (displayString, "clear", step, field);
    }
    
    /**
     * Randomly populate the field with all life.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    animals.add(deer);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    plants.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    
    /**
     * Randomly pick the weather every 24 hours
     */
    public void dayPassed()
    {
        if (clock.getDayPassed()){
            weather.chooseWeather();
        }
        clock.resetDay();
    }
    
    /**
     * Affect the life in the field depending on the weather
     */
    public void checkWeather()
    {
        //All animals sleep until snow stops
        if (weather.getWeather() == "snow"){
            for(int i = 0; i < animals.size(); i++ ) {
                animals.get(i).sleepLong();
            } 
        }
        
        //Plants grow faster in the rain
        else if (weather.getWeather() == "rain"){
            fastGrowPlant();
            normalActAnimal();
        }
        
        //Predators have less visibility in the fog
        else if (weather.getWeather() == "fog"){
            for (int i = 0; i < animals.size(); i++){
                animals.get(i).canNotSee();
            }
            normalActAnimal();
        }
        
        //Normal actions when weather is clear
        else{
            normalActAnimal();
        }
    }
    
    /**
     * The normal actions of animals 
     */
    public void normalActAnimal()
    {
        for(int i = 0; i < animals.size(); i++ ){
            animals.get(i).sleep(clock.getHour());
        } 
    }
    
    /**
     * Allow plants to grow faster
     */
    public void fastGrowPlant()
    {
        for (int i = 0; i < plants.size(); i++){
            plants.get(i).growTwice();
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
