import java.util.List;
import java.util.Random;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Deer extends Prey
{
    // Characteristics shared by all deer (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a deer can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.64;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;

    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setMaxAge(MAX_AGE);
        setBreedingAge(BREEDING_AGE);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = PLANT_FOOD_VALUE;
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the deer does most of the time - it runs 
     * around. Sometimes it will breed, eat plants or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Animal> newDeer)
    {
        //Whilst awake
        if (! isSleeping())  {
            incrementAge();
            incrementHunger();
            if(isAlive()) {
                giveBirth(newDeer);   
                checkTransmission();
                // Try to move into a free location.
                moveToFood();
            }
        }
    }
    
    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeer A list to return newly born deer.
     */
    private void giveBirth(List<Animal> newDeer)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Deer young = new Deer(false, field, loc);
            young.chooseGender();
            young.checkDisease();
            newDeer.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * The deer sleeps from 10pm to 6am
     * @param hour The current hour of the day
     */
    public void sleep(int hour)
    {
        if (6 < hour && hour < 22)    {
            sleeping = false;
        }
        
        else    {
            sleeping = true;
        }
    }
}
