
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of predators
 *
 * @version (1)
 */
public abstract class Predator extends Animal
{
    //Food values of different species
    protected static final int RABBIT_FOOD_VALUE = 8;
    protected static final int MOUSE_FOOD_VALUE = 6;
    protected static final int DEER_FOOD_VALUE = 10;

    /**
     * Create a new predator at location in field
     * @param field The current field 
     * @param location The location in the field
     */
    public Predator(Field field, Location location)
    {
        super(field, location);
    }
    

    
    
    /**
     * Look for food adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        //Iterate through field 
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            //Obtain object at location in field 
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            //Check what species object is, kill the animal and set food value accordingly
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    rabbit.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
           else if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) { 
                    mouse.setDead();
                    foodLevel = MOUSE_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Deer){
                Deer deer = (Deer) animal;
                if(deer.isAlive()){
                    deer.setDead();
                    foodLevel = DEER_FOOD_VALUE;
                    return where;
                }
            }
            
            //Animal is hungrier because it can't see and catch prey as easily
            if (!see){
                foodLevel = foodLevel / 2;
            }
        }
        return null;
    }
    
    /**
     * Move towards source of food if found, otherwise into free location
     */
    protected void moveToFood()
    {
        Location newLocation = findFood();
        if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    
    }
}
