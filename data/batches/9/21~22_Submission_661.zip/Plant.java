import java.util.List;

/**
 * The characteristics of a plant
 *
 * @version (1)
 */
public class Plant
{
    // instance variables
    private Field field;
    private Location location;
    
    //Set the plant to alive
    private boolean alive = true;
    
    //Whether the colour of the plant should be darker
    private boolean darker;
    
    //Set plant height to 10
    private double height = 10;
    
    //Set max height to 20
    private double maxHeight = 20;
    
    /**
     * Constructor for objects of class Plant
     */
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Place the plant at a location in the given field.
     * @param newlocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * @return the plant's height
     */
    public double getHeight()
    {
        return height;
    }

    /**
     * Indicate that the plant has been eaten and is at its lowest height
     * It is removed from the field.
     */
    protected void setBack()
    {
        height = 1;
    }
    
    /**
     * @return regen The percentage of regeneration the plant will give
     * to an animal's food level
     */
    public double regen()
    {
        return height/maxHeight;
    }
    
    /**
     * Make the plant grow faster
     */
    public void growTwice()
    {
        height = height * 1.5;
    }
    
    /**
     * @return darker Whether the plant should be darker or not
     */
    public boolean getDarker()
    {
        return darker;
    }
    
    /**
     * Indicate that the plant shouldn't be darker
     */
    public void notDarker()
    {
        darker = false;
    }
    
    /**
     * Make this plant grow
     * @param  newPlants  a list to return new plants
     */
    public void grow(List<Plant> newPlants)
    {
        // plant grows at a rate of 1cm a day up to the max height
        if (height < maxHeight){
            height += 1;
            if (height >= 6){
                darker = true;
            }
            else{
                darker = false;
            }
        }
        else{
        height = maxHeight;
    }
    }
}
