import java.util.Random;
import java.util.List;
import java.util.ArrayList;

/**
 * Initiate different weather types
 *
 * @version (1)
 */
public class Weather
{
    //Instance variables
    private Field field;
    private List<String> weatherTypes;
    
    private int count;
    
    //The string to be returned, states what type of weather it is
    private String finalWeather;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        weatherTypes = new ArrayList<>();
        addWeather();
        finalWeather = "clear";
    }
    
    /**
     * Add different weather types to the list
     */
    public void addWeather()
    {
        weatherTypes.add("clear");
        weatherTypes.add("rain");
        weatherTypes.add("snow");
        weatherTypes.add("fog");
    }

    /**
     * Randomly choose the type of weather
     */
    public void chooseWeather()
    {
        Random rand = Randomizer.getRandom();
        double x = rand.nextDouble();
        if (x <= 0.6){
           count = 0; 
        }
        else if (x > 0.6 && x <= 0.85){
            count = 1;
        }
        else if (x > 0.85 && x < 0.9){
            count = 2;
        }
        else{
            count = 3;
        }
        //Set final weather to whichever type of weather has been chosen
        finalWeather = weatherTypes.get(count);
    }
    
    /**
     * @return finalWeather The type of weather
     */
    public String getWeather()
    {
        return finalWeather;
    }
}
