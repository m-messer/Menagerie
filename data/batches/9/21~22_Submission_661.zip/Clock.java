import java.util.List;

/**
 * Displays the clock 
 *
 * @version 2022.02.23 
 */
public class Clock
{
    //Hours and minutes
    private ClockWork hours;
    private ClockWork minutes;
    
    //Time string to be displayed
    private String displayString;
    
    //Hour number
    private int hour;
    //Minute number
    private int minute;
    
    //Whether 24 hours has passed or not
    private boolean dayPassed;
    
    /**
     * Constructor for the Clock class
     */
    public Clock()
    {
        hours = new ClockWork(24);
        minutes = new ClockWork(60);
        createString();
    }
    
    /**
     * Reset the clock to 0 hours and 0 minutes
     */
    public void resetClock()
    {
     minutes.setValue(0);
     hours.setValue(0);
    }

    /**
     * Makes the clock tick forward
     */
    public void timeTick()
    {
        minutes.incrementMinute();
        if(minutes.getValue() == 0) {  // it just rolled over!
            hours.incrementHour();
        }
        createString();
    }

    /**
     * @eturn the current time of this display in the format HH:MM.
     */
    public String getTime()
    {
        return displayString;
    }
    
    /**
     * @return if 24 hours has passed or not
     */
    public boolean getDayPassed()
    {
        checkDay();
        return dayPassed;
    }
    
    /**
     * Check if a day has passed 
     */
    private void checkDay()
    {
         if (getHour() == 23 && getMinute() == 50){
                dayPassed = true;
        }
    }
    
    /**
     * Allow check of time from a new day (0 days has passed from current day)
     */
    public void resetDay()
    {
        dayPassed = false;
    }

    
    /**
     * Creates a string by adding the hours and minutes together
     */
    private void createString()
    {
        displayString = hours.getDisplayValue() + ":" + 
                        minutes.getDisplayValue();
    }
    
    /**
     * @return the hour as an integer
     */
    public int getHour()
    {   
        return hour = Integer.parseInt(hours.getDisplayValue());
    }

    /**
     * @return the minute as an integer
     */
    public int getMinute()
    {   
        return minute = Integer.parseInt(minutes.getDisplayValue());
    }
           
}
    

