

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * The shared charateristics of prey
 *
 * @version (1)
 */
public abstract class Prey extends Animal
{
    //Food values of plants
    protected static final double PLANT_FOOD_VALUE = 150;
    
    /**
     * Create new prey at location in field
     * @param field The current field 
     * @param location The location in the field
     */
    public Prey(Field field, Location location)
    {
        super(field, location);
    }
    
    
    /**
     * Look for plants adjacent to the current location.
     * Only the first plant rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        //Iterate through field
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            //Obtain object at location in field
            Location where = it.next();
            Object object = field.getObjectAt(where);
            //Check if object is a plant 
            if (object instanceof Plant){
                Plant plant = (Plant) object;
                plant.setBack();
                //Food value of plant varies depending on the height
                foodLevel = PLANT_FOOD_VALUE * plant.regen();
            }
        }
        return null;
    }
    
    /**
     * Move towards source of food if found, otherwise into free location
     */
    protected void moveToFood()
    {
        Location newLocation = findFood();
        if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

}