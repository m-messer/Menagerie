import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Write a description of class Snake here.
 *
 * @version (02/03/2022)
 */
public class Snake extends Animal
{

    private static final int MAX_STRENGTH = 100;

    private static final int BREEDING_AGE = 15;

    private static final int MAX_AGE = 150;

    private static final double BREEDING_PROBABILITY = 0.19;

    private static final int MAX_LITTER_SIZE = 3;

    private static final int MAX_FOOD_VALUE = 15;

    private int foodLevel;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class snake
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            this.foodLevel = rand.nextInt(MAX_FOOD_VALUE);
        }
        else {
            this.foodLevel = MAX_FOOD_VALUE;
        }
    }

    /**
     * What the snake does for most of the time in the simulation; it either hunts, breeds, or dies.
     * @param newSnakes A list to return all the newborn snakes.
     */
    public void act(List<Organism> newSnakes, Weather weather, Time time)
    {
        incrementAge();
        decrementFoodLevel();
        decrementPower();
        if (isAlive()) {
            giveBirth(newSnakes);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            // Check if the snake is still alive
            if (newLocation == null && isAlive()) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
                if(isInfected()) {
                    infectOthers();
                }
            } else {
                // Overcrowding.
                setDead();
            }
        }

        heal();
    }

    /**
     * Look for food in adjacent locations.
     * @param Null if no food is found, not null if found.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        //Random worm created as backup food
        Worm randomWorm = null;

        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);

            if (animal instanceof Mice) {
                Mice mice = (Mice) animal;
                if (mice.isAlive()) {
                    mice.setDead();
                    this.foodLevel = MAX_FOOD_VALUE;
                    this.incrementPower(5);
                    return where;
                }
            } else if (animal instanceof Worm) {
                Worm worm = (Worm) animal;
                if (worm.isAlive()){
                    worm.setDead();
                    this.foodLevel = MAX_FOOD_VALUE;
                    this.incrementPower(5);
                    return where;
                }
            }
        }

        if (this.foodLevel <= 2 && randomWorm != null) {
            Location where = randomWorm.getLocation();
            randomWorm.setDead();
            this.incrementFoodLevel(5);
            this.incrementPower(4);

            return where;
        }

        return null;

    }

    /**
     * Checks if this animal can give birth at this step; if it can new animal 
     * will be born in free adjacent locations.
     * @param A list to return newly born animals.
     */
    private void giveBirth(List<Organism> newSnakes)
    {
        // New snake are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), 2);
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Snake young = new Snake(false, field, loc);
            newSnakes.add(young);
        }
    }

    /**
     * Increase this animal's hunger.
     * @param foodLevel Return the current food level.
     */
    protected void incrementFoodLevel(int foodLevel)
    {
        this.foodLevel = this.foodLevel + foodLevel;
        if (this.foodLevel > MAX_FOOD_VALUE) {
            this.foodLevel = MAX_FOOD_VALUE;
        }
    }

    /**
     * Increases animal's age and sets dead if current age exceeds maximum age.
     */
    protected void incrementAge()
    {
        super.incrementAge();
        if (getAge() > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this snake more hungry. This could result in the snake's death.
     */
    private void decrementFoodLevel()
    {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Returns the maximum power level indicated at start.
     */
    protected int getMaxPower()
    {
        return MAX_STRENGTH;
    }

    /**
     * Return the maximum allowed age for a snake.
     *
     * @return MAX_AGE
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return max food level.
     *
     * @return int MAX_FOOD_LEVEL
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_VALUE;
    }

    /**
     * Returns the snake's breeding age
     *
     * @return boolean if the animal can breed
     */
    private boolean canBreed()
    {
        List<Location> potentialMateLocations = getField().adjacentLocations(getLocation());
        return mateCheck(potentialMateLocations) && getAge() >= BREEDING_AGE;
    }

    /**
     * Generate a number representing the number of births 
     * if this animal is at breeding age and can breed.
     */
    private int breed()
    {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)
        { 
            births = rand.nextInt(MAX_LITTER_SIZE)+1;
        }
        return births;

    }

}


