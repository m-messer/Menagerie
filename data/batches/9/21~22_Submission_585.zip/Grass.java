import java.util.List;
import java.util.Random;

/**
 * Write a description of class Squirrels here.
 *
 * @version (a version number or a date)
 */
public class Grass extends Organism
{
    private static final int BREEDING_AGE=200;

    private static final int MAX_AGE=1000;

    private static final int EDIBLE_AGE = 100;

    private static final double PROPAGATION_PROBABILITY=0.13;

    private static final int MAX_PROPAGATION=4; 

    private static final int GROWTH_PERIOD = 5;

    private static final Random rand = Randomizer.getRandom();

    private Growth growth;

    /**
     * Constructor for objects of class Grass
     */
    public Grass(boolean randomAge, Field field, Location location) {
        super(field, location);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            for(int i = 0; i < getAge() / GROWTH_PERIOD; i++) {
                growth = Growth.grow();
            }
        } else {
            growth = Growth.PLANTLETTE;
        }
    }

    /**
     * What the grass does for most of the time in the simulation; it propagates.
     * @param newGrass A list to return all the fresh grass.
     */
    public void act (List<Organism> newGrass, Weather weather, Time time)
    {
        incrementAge();
        if(isAlive()) {
            propagation(newGrass, weather);
        }
    }

    /**
     * Increases grass age and sets dead if current age exceeds maximum age.
     */
    protected void incrementAge()
    {
        super.incrementAge();
        if (getAge() > MAX_AGE) {
            setDead();
        }
        if (getAge() > 0 && getAge() % GROWTH_PERIOD == 0) {
            Growth.grow();
        }
    }

    /**
     * Checks if grass can propagate at this step; if it can grass 
     * will grow in free adjacent locations.
     * @param newGrass A list to return all the fresh grass.
     */
    private void propagation (List<Organism> newGrass, Weather weather)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), 2);
        int propagations = propagate();

        if (weather != Weather.SNOWING){
            for (int b=0; b<propagations && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Grass young = new Grass(false, field, loc);
                newGrass.add(young);
            }
        }

    }

    /**
     * Generate a number representing the number of propagations and 
     * if this animal is at propagation age and can breed.
     */
    public int propagate()
    {
        int plantlettes = 0;
        if (canBreed() && rand.nextDouble() <= PROPAGATION_PROBABILITY)
        {
            plantlettes = rand.nextInt(MAX_PROPAGATION) + 1;
        }
        return plantlettes;
    }

    protected boolean canBreed()
    {
        return BREEDING_AGE <= getAge();
    }

    protected int getMaxAge()
    { 
        return MAX_AGE;
    }

    protected boolean isEdibleAge()
    {
        return EDIBLE_AGE <= getAge();
    }

}
