import java.util.List;
import java.util.Random;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Organism
{
    // The power of the animal
    protected int power;

    // Randomiser to allow all animals to access the ransom value
    private static final Random rand = Randomizer.getRandom();

    // The chance of an animal being created with an infection, and the chance it can get infection
    protected final static double INITIAL_INFECTION_CHANCE = 0.2;
    protected final static double INFECTION_CHANCE = 0.05;

    // Integer value of the infection - 0 means the animal is not infected
    private int infection;

    // The time an infection lasts
    private final static int INFECTION_TIME = 10;

    private final Sex sex;

    /**
     * Create an animal. An animal. can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);

        //The animal is uninfected when it is born.
        infection = 0;

        //Assigns randomized sex to animal
        sex = Sex.randomSex();

        if (rand.nextDouble() <= INITIAL_INFECTION_CHANCE)
        {
            infect();
        }

    }

    /**
     * Infects the organism
     */
    protected void infect()
    {
        infection = INFECTION_TIME;
    }

    /**
     *  Removes the animals infection.
     */
    protected void healed()
    {
        infection = 0;
    }

    /**
     * Checks if the animal is infected
     * @return a boolean as to if the animal is infected
     */
    public boolean isInfected()
    {
        return infection > 0;
    }

    /**
     * A procedure to check for any animals near the current animal, and sets the animal to be infected if infection
     * chance is reached.
     */
    protected void infectOthers()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());

        for (Location where : adjacent) {
            Object organism = field.getObjectAt(where);

            // The animal searches for another animal in all nearby locations
            if (organism instanceof Animal) {
                Animal animal = (Animal) organism;
                if (animal.isAlive() && rand.nextDouble() < INFECTION_CHANCE) {
                    animal.infect();
                }
            }
        }

    }

    /**
     * Slowly heals the animal.
     */
    public void heal()
    {
        if (isInfected()) {
            infection--;
            if (infection ==0) {
                healed();
            }
        }

    }

    /**
     * Returns the power level of the animal. 
     */
    protected int getPower()
    { 
        return this.power;
    }

    /**
     * Sets the specified power level of the animal.
     * @param power An integer that is set out to be the power level.
     */
    protected void setPower(int power)
    {
        this.power = power;
    }

    abstract protected int getMaxPower();

    /**
     * Increases power. If power is already at max state, leaves it as it is.
     * @param level Amount that will be added to current state.
     */

    protected void incrementPower(int level)
    {
        this.power = this.power + level;
        if (this.power > getMaxPower()) {
            this.power = getMaxPower();
        }

    }

    /**
     * Decreases power.
     */
    protected void decrementPower()
    {
        this.decrementPower(1);
    }

    /**
     * Decrements the current power level.
     * @param level The amount that is entered to be decreased from the current state.
     */
    protected void decrementPower(int level)
    {
        if (this.power - level < 0)
            this.power = 0;
        else
            this.power = this.power - level;
    }

    /**
     * Pulled out into each animal class to allow varying distances to mate.
     * Gets all locations around the fox, each needs to be checked, this can be 
     * done one more time in order to increase area of potential mates.
     * @param potentialMateLocations Returns a list of all the possible adjacent locations 
     * containing a member of the opposite sex.
     */
    protected boolean mateCheck(List<Location> potentialMateLocations) {

        // Loops through all locations and gets the object at that loation
        for(Location location: potentialMateLocations) {
            Object animal = getField().getObjectAt(location);

            // If there is an object, we check if it is of the same type as the current animal
            if(animal != null && 
            (animal.getClass().getName().equals(getClass().getName()))) {
                Animal potentialMate = (Animal) animal;

                // We check if the animals are different sexes, if so, they can breed
                if(potentialMate.getSex() != this.getSex()) {
                    return true;
                }
            }
        }

        // No animal of the same type and opposite sex was found
        return false;
    }

    public Sex getSex() {
        return sex;
    }
}

    

