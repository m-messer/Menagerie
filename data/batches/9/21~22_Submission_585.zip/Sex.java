import java.util.Random;

/**
 * Enumeration that stores the different sexes the animals can be.
 */
public enum Sex {
    UNDEFINED, 
    FEMALE, 
    MALE;

    public static Sex randomSex() {
        Random random = new Random();
        return random.nextInt(2) == 0 ? FEMALE : MALE;
    }
}

