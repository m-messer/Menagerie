import java.util.Random;

/**
 * Enumeration that stores the different weather conditions that can occur in the simulation.
 */
public enum Weather {
    RAINING,
    SNOWING,
    SUNNY;

    private static Weather currentWeather = RAINING;
    private static int stepsOfWeather = 0;

    private static final Random random = new Random();

    public static Weather getWeather() {
        // randomly decides if weather should change, but doesn't allow weather to stay consistent for over 10 days.
        if(random.nextInt(2) == 1 || stepsOfWeather > 10){
            currentWeather = Weather.values()[random.nextInt(Weather.values().length)];
            stepsOfWeather = 0;
            return currentWeather;
        }

        stepsOfWeather++;
        return currentWeather;
    }
}
