import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Write a description of class Worm here.
 *
 *  @version (02/03/2022)
 */
public class Worm extends Animal
{

    private static final int MAX_STRENGTH = 100;
    
    private static final int BREEDING_AGE = 15;
    
    private static final int MAX_AGE = 150;
    
    private static final double BREEDING_PROBABILITY = 0.5;
    
    private static final int MAX_LITTER_SIZE = 15;

    private static final int MAX_FOOD_VALUE = 30;
    
    private int foodLevel;
    
    private static final Random rand = Randomizer.getRandom();
    

    /**
     * Constructor for objects of class worm
     */
    public Worm(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            this.foodLevel = rand.nextInt(MAX_FOOD_VALUE);
        }
        else {
            this.foodLevel = MAX_FOOD_VALUE;
        }
    }
    
    /**
     * What the worm does for most of the time in the simulation; it either eats, breeds, or dies.
     * @param newWorm A list to return all the newborn worms.
     */
    public void act(List<Organism> newWorms, Weather weather, Time time)
    {
        incrementAge();
        decrementFoodLevel();
        decrementPower();
        if (isAlive()) {
            giveBirth(newWorms);
            // Move towards a source of food if found.
            Location newLocation = null;
            // only when getting hungry
            newLocation = findFood();
            
            if (newLocation == null && isAlive()) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
                if(isInfected()) {
                    infectOthers();
                }
            } else {
                // Overcrowding.
                setDead();
            }
        }
        
        heal();
    }
    
    /**
     * Finds some food and eats it
     * @return the location it found food
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();


        while (it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);

            // The worm searches for grass in all nearby locations.
             if (food instanceof Grass) {
                    Grass grass = (Grass) food;
                    if (grass.isAlive() && grass.isEdibleAge()) {
                        grass.setDead();
                        this.foodLevel = MAX_FOOD_VALUE;
                        this.incrementPower(6);

                        return where;
                    }
             }
         }
         
         return null;
   }   
   
    /**
     * Gives birth to new organisms by checking conditions and appending any new borns to new worms
     * @param newWorms List of animals born this step
     */
    private void giveBirth(List<Organism> newWorms)
    {
        // New worms are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), 2);
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Worm young = new Worm(false, field, loc);
            newWorms.add(young);
        }
    }

    /**
     * Increases animal's age and sets dead if current age exceeds maximum age.
     */
    protected void incrementAge()
    {
        super.incrementAge();
        if (getAge() > MAX_AGE) {
            setDead();
        }
    }
    
     /**
     * Increase this animal's hunger.
     * @param foodLevel Return the current food level.
     */
    protected void incrementFoodLevel(int foodLevel)
    {
        this.foodLevel = this.foodLevel + foodLevel;
        if (this.foodLevel > MAX_FOOD_VALUE) {
            this.foodLevel = MAX_FOOD_VALUE;
        }
    }

    /**
     * Make this worms more hungry. This could result in the worm's death.
     */
    private void decrementFoodLevel()
    {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Returns the maximum power level indicated at start.
     */
    protected int getMaxPower()
    {
        return MAX_STRENGTH;
    }

    /**
     * Return the maximum allowed age for a worm.
     *
     * @return MAX_AGE
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return max food level.
     *
     * @return int MAX_FOOD_LEVEL
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_VALUE;
    }

    /**
     * Returns the worm's breeding age
     *
       * @return boolean if the animal can breed
     */
    private boolean canBreed()
    {
        List<Location> potentialMateLocations = getField().adjacentLocations(getLocation(), 3);
        return mateCheck(potentialMateLocations) && getAge() >= BREEDING_AGE;
    }

    /**
     * Generate a number representing the number of births 
     * if this animal is at breeding age and can breed.
     */
    private int breed()
    {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY)
         { 
             births = rand.nextInt(MAX_LITTER_SIZE)+1;
         }
         return births;
    
    }

}



