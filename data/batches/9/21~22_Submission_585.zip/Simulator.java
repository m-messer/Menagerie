import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing preys and predators in a food chain.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // ------------------ Creation Probabilities -------------------

    private static final double SQUIRREL_CREATION_PROBABILITY = 0.12;

    private static final double MICE_CREATION_PROBABILITY = 0.12;

    private static final double WORM_CREATION_PROBABILITY = 0.12;

    private static final double SNAKE_CREATION_PROBABILITY = 0.1;

    private static final double HAWK_CREATION_PROBABILITY = 0.1;

    private static final double OWL_CREATION_PROBABILITY = 0.1;

    private static final double GRASS_CREATION_PROBABILITY = 0.15;

    // --------------------------------------------------------------
    // List of animals in the field.
    private final List<Organism> organisms;
    // The current state of the field.
    private final Field field;
    // The current step of the simulation.
    private int step;

    private boolean showSquirrels = true, showMice = true, showWorms = true, showSnakes = true, showHawks = true, showOwls = true, showGrass = true;
    // A graphical view of the simulation.
    private final SimulatorView view;

    private boolean isRunning;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<Organism>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Squirrel.class, Color.ORANGE);
        view.setColor(Mice.class, Color.BLUE);
        view.setColor(Worm.class, Color.PINK);
        view.setColor(Snake.class, Color.MAGENTA);
        view.setColor(Hawk.class, Color.RED);
        view.setColor(Owl.class, Color.YELLOW);
        view.setColor(Grass.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its currefieldnt state for a reasonably long period,
     * (4000 steps).
     */
    public synchronized void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public synchronized void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
        stop();
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     */
    public synchronized void simulateOneStep()
    {
        if(isRunning) {
            return;
        }

        isRunning = true;
        step++;

        Weather weather = Weather.getWeather();
        Time time = Time.getTimeOfDay(step);

        // Provide space for newborn organisms.
        List<Organism> newOrganisms = new ArrayList<Organism>();        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms, weather, time);
            if(! organism.isAlive()) {
                it.remove();
            }
        }

        // Add the newly organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
        isRunning = false;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public synchronized void reset()
    {
        stop();
        step = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Ensures the simulation is in a stopped state
     */
    public synchronized void stop() {
        isRunning = false;
    }

    /**
     * Sets whether the squirrels should be shown in the simulation or not.
     * @param showSquirrels true or false.
     */
    public void showSquirrels (boolean showSquirrels)
    {
        this.showSquirrels = showSquirrels;
    }

    /**
     * Sets whether the mice should be shown in the simulation or not.
     * @param showMice true or false.
     */
    public void showMice (boolean showMice)
    {
        this.showMice = showMice;
    }

    /**
     * Sets whether the worms should be shown in the simulation or not.
     * @param showWorms true or false.
     */
    public void showWorms(boolean showWorms)
    {
        this.showWorms = showWorms;
    }

    /**
     * Sets whether the snakes should be shown in the simulation or not.
     * @param showSnakes true or false.
     */
    public void showSnakes (boolean showSnakes)
    {
        this.showSnakes = showSnakes;
    }

    /**
     * Sets whether the hawks should be shown in the simulation or not.
     * @param showHawks true or false.
     */
    public void showHawks (boolean showHawks)
    {
        this.showHawks = showHawks;
    }

    /**
     * Sets whether the owls should be shown in the simulation or not.
     * @param showOwls true or false.
     */
    public void showOwls (boolean showOwls)
    {
        this.showOwls = showOwls;
    }

    /**
     * Sets whether the grass should be shown in the simulation or not.
     * @param showGrass true or false.
     */
    public void showGrass (boolean showGrass)
    {
        this.showGrass = showGrass;
    }

    /**
     * Randomly populate the field with all the organisms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(this.showSquirrels && rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    organisms.add(squirrel);
                }
                else if(this.showMice && rand.nextDouble() <= MICE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mice mice = new Mice(true, field, location);
                    organisms.add(mice);
                }
                else if(this.showWorms && rand.nextDouble() <= WORM_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Worm worm = new Worm(true, field, location);
                    organisms.add(worm);
                }
                else if(this.showSnakes && rand.nextDouble() <= SNAKE_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Snake snake= new Snake(true, field, location);
                    organisms.add(snake);
                }
                else if(this.showHawks && rand.nextDouble() <= HAWK_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(true, field, location);
                    organisms.add(hawk);
                }
                else if(this.showOwls && rand.nextDouble() <= OWL_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    organisms.add(owl);
                }
                else if(this.showGrass && rand.nextDouble() <= GRASS_CREATION_PROBABILITY)
                {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    organisms.add(grass);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
