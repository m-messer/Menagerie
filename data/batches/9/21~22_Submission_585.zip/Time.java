/**
 * Enumeration that stores the different times of the day.
 */
public enum Time {
    DAY,
    NIGHT;

    /**
     * Gets the current time of day based on the steps through the simulation.
     * Each simulation step progresses the time by one unit.
     * e.g. Given times DAY and NIGHT, the simulation step at STEP 0 will return DAY, 
     * and the simulation at step 1 will return NIGHT.
     * @return The current time of day.
     */
    public static Time getTimeOfDay(int step) {
        return Time.values()[step % Time.values().length];
    }
}

