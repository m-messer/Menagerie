import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a mice.
 * Mice age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 *  
 */
public class Mice extends Herbivorous
{

    /**
     * Create a new mice. A mice may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the mice will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mice (boolean randomAge,boolean isMale, Field field, Location location)
    {
        super(field, location);
        // The age of breed.
        BREEDING_AGE = 4;
        // The age to which a mice can live.
        MAX_AGE = 22;
        // The likelihood of a mice breeding.
        BREEDING_PROBABILITY = 0.15;
        // The maximum number of births.
        MAX_LITTER_SIZE = 8;
        // The number of grasses that mice eat.
        GRASS_FOOD_VALUE = 9;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            this.isMale = rand.nextBoolean();
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            this.isMale = rand.nextBoolean();
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * This is what the mice does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMice A list to return newly born rabbits.
     */
    public void act(List<Animal> newMice, List<Vrius> newInfected)
    {
        super.act(newMice,newInfected);
    }

    /**
     * Check whether or not this mice is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born mice.
     */
    public void giveBirth(List<Animal> newHerbivorous)
    {
        if(!isMale){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);

                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Mice) {
                        Mice mice = (Mice) animal;
                        if(mice.getGender()){
                            isMale = rand.nextBoolean();
                            Mice young = new Mice(false, isMale, field, loc);
                            newHerbivorous.add(young);
                        }
                    }
                }

            }
        }
    }

    /**
     * Look for grass adjacent to the current location.
     * Only the first grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
