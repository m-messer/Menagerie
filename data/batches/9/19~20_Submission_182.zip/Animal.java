import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{
    protected boolean isMale;
    protected static final double INFECT_PROBABILITY = 0.01;
    protected static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newActor, List<Vrius> newInfected);

    protected boolean getGender()
    { 
        return isMale;
    }

    protected void getDisease(List<Vrius> newInfected)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(rand.nextDouble() <= INFECT_PROBABILITY) {
                if(animal instanceof Rabbit) {
                    Rabbit rabbit = (Rabbit) animal;
                    if(rabbit.isAlive()) { 
                        rabbit.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newInfected.add(newinfected);
                    }
                }
                else if(animal instanceof Snake) {
                    Snake snake = (Snake) animal;
                    if(snake.isAlive()) { 
                        snake.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newInfected.add(newinfected);
                    }
                }

                else if(animal instanceof Mice) {
                    Mice mice = (Mice) animal;
                    if(mice.isAlive()) { 
                        mice.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newInfected.add(newinfected);
                    }
                }
                else if(animal instanceof Fox) {
                    Fox fox = (Fox) animal;
                    if(fox.isAlive()) { 
                        fox.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newInfected.add(newinfected);
                    }
                }
            }
        }
    }
}
