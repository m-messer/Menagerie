import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 *  
 */
public class Rabbit extends Herbivorous
{

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge,boolean isMale, Field field, Location location)
    {
        super(field, location);
        // The age of breed.
        BREEDING_AGE = 4;
        // The age to which a rabbit can live.
        MAX_AGE = 48;
        // The likelihood of a rabbit breeding.
        BREEDING_PROBABILITY = 0.08;
        // The maximum number of births.
        MAX_LITTER_SIZE = 20;
        // The number of grass eat.
        GRASS_FOOD_VALUE = 10;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            this.isMale = rand.nextBoolean();
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            this.isMale = rand.nextBoolean();
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * This is what the rabbit does most of the time - it runs 
     * around and find grass ton eat. Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Animal> newRabbits, List<Vrius> newInfected)
    {
        super.act(newRabbits,newInfected);
    }

    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void giveBirth(List<Animal> newHerbivorous)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(!isMale){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);

                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Rabbit) {
                        Rabbit rabbit = (Rabbit) animal;
                        if(rabbit.getGender()){
                            isMale = rand.nextBoolean();
                            Rabbit young = new Rabbit(false, isMale, field, loc);
                            newHerbivorous.add(young);
                            
                        }
                    }
                }

            }
        }
    }

    /**
     * Look for grass adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

}
