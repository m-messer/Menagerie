import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 *  
 */
public class Fox extends Predators
{
    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * 
     * eidted by Ziyou Song, Pinfu Wu
     */
    public Fox(boolean randomAge,boolean isMale, Field field, Location location)
    {
        super(field, location);
        // The age of breed.
        BREEDING_AGE = 5;
        // The maximum age of fox.
        MAX_AGE = 90;
        // The likelihood  of breed.
        BREEDING_PROBABILITY = 0.06;
        // The maximum number of birth.
        MAX_LITTER_SIZE = 7;
        // The number of rabbits eat.
        RABBIT_FOOD_VALUE = 30;
        // The number of snakes eat.
        SNAKE_FOOD_VALUE = 40;
        // The number of mice eat.
        MICE_FOOD_VALUE = 30;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            this.isMale = rand.nextBoolean();
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            age = 0;
            this.isMale = rand.nextBoolean();
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits and mice. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Animal> newFoxes, List<Vrius> newInfected)
    {
        super.act(newFoxes,newInfected);
    }

    /**
     * Look for rabbits and mice adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            Object plant = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    rabbit.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if(snake.isAlive()) { 
                    snake.setDead();
                    foodLevel = SNAKE_FOOD_VALUE;
                    return where;
                }
            }

            else if(animal instanceof Mice) {
                Mice mice = (Mice) animal;
                if(mice.isAlive()) { 
                    mice.setDead();
                    foodLevel = MICE_FOOD_VALUE;
                    return where;
                }
            }
            else if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) {
                    grass.setDead();
                    foodLevel --;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     */
    public void giveBirth(List<Animal> newPredators)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(!isMale){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);

                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                while(it.hasNext()) {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Fox) {
                        Fox fox = (Fox) animal;
                        if(fox.getGender()){
                            isMale = rand.nextBoolean();
                            Fox young = new Fox(false, isMale, field, loc);
                            newPredators.add(young);
                        }
                    }
                }
            }
        }
    }

    /**Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
