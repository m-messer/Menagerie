import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 *  
 * 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.02;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.05;  
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.02; 
    // The probability that a mcie will be created in any given grid position.
    private static final double MICE_CREATION_PROBABILITY = 0.05;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.3;
    // The probability that a infected species will be created in any given grid position.
    private static final double INFECT_CREATION_PROBABILITY = 0.01;
    // List of herbivorous in the field.
    private List<Animal> herbivorous;
    // List of predators in the field.
    private List<Animal> predators;
    // List of plants in the field.
    private List<Plant> grass;
    // List of virus in the field.
    private List<Vrius> disease;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private List<SimulatorView> views;
    // To use method in class GridView.
    private GridView view1;
    // To use method in class GraphView.
    private GraphView view2;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        herbivorous = new ArrayList<>();
        predators = new ArrayList<>();
        grass = new ArrayList<>();
        disease = new ArrayList<>();
        views = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view1 = new GridView(depth, width);
        view1.setColor(Rabbit.class, Color.ORANGE);
        view1.setColor(Fox.class, Color.BLUE);
        view1.setColor(Snake.class, Color.CYAN);
        view1.setColor(Mice.class, Color.GRAY);
        view1.setColor(Grass.class, Color.GREEN);
        view1.setColor(Disease.class, Color.RED);
        views.add(view1);
        // Create a view of the graph which shows number of species.
        view2 = new GraphView(500, 150, 500);
        view2.setColor(Rabbit.class, Color.ORANGE);
        view2.setColor(Fox.class, Color.BLUE);
        view2.setColor(Snake.class, Color.CYAN);
        view2.setColor(Mice.class, Color.GRAY);
        view2.setColor(Grass.class, Color.GREEN);
        view2.setColor(Disease.class, Color.RED);
        views.add(view2);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && views.get(0).isViable(field); step++) {
            simulateOneStep();
            delay(10);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * species.
     */
    public void simulateOneStep()
    {
        //increment of step
        step++;
        // Assign value of count number to time.
        int Time = view1.GetCountTime();
        // Provide space for newborn animals.
        List<Animal> newPredators = new ArrayList<>();
        List<Animal> newHerbivorous = new ArrayList<>();
        List<Plant> newGrass = new ArrayList<>();
        List<Vrius> newInfected = new ArrayList<>();

        // Whatever the time is, virus will spread.
        for(Iterator<Vrius> it = disease.iterator(); it.hasNext(); ) {
            Vrius patient = it.next();

            patient.act(newInfected);
            if(! patient.isAlive()) {
                it.remove();
            }
        }
        disease.addAll(newInfected);
        // Whenweather is rainy, new grass breed.
        if(Time % 3 == 0 || Time == 1){
            for(Iterator<Plant> it = grass.iterator(); it.hasNext(); ) {
                Plant grass = it.next();

                grass.act(newGrass);
                if(! grass.isAlive()) {
                    it.remove();
                }
            }
            grass.addAll(newGrass);

        }
        // At night, some animals will not move.
        if (Time % 2 == 0){
            for(Iterator<Animal> it = predators.iterator(); it.hasNext(); ) {
                Animal predator = it.next();

                predator.act(newPredators,newInfected);
                if(! predator.isAlive()) {
                    it.remove();
                }
            }

            predators.addAll(newPredators);
            disease.addAll(newInfected);

        }
        // In daytime, some animals will not move.
        else{
            for(Iterator<Animal> it = herbivorous.iterator(); it.hasNext(); ) {
                Animal herbivorou = it.next();

                herbivorou.act(newHerbivorous,newInfected);
                if(! herbivorou.isAlive()) {
                    it.remove();
                }
            }

            herbivorous.addAll(newHerbivorous);
            disease.addAll(newInfected);

        }

        // Add the newly born foxes and rabbits to the main lists.

        updateViews();
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        herbivorous.clear();
        predators.clear();
        grass.clear();
        disease.clear();

        for (SimulatorView view : views) {
            view.reset();
        }

        populate();

        // Show the starting state in the view.
        updateViews();
    }

    /**
     * Update all existing views.
     */
    private void updateViews()
    {
        for (SimulatorView view : views) {
            view.showStatus(step, field);
        }
    }

    /**
     * Randomly populate the field with species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender = rand.nextBoolean();
                    Fox fox = new Fox(true, gender, field, location);

                    predators.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender = rand.nextBoolean();
                    Rabbit rabbit = new Rabbit(true, gender, field, location);

                    herbivorous.add(rabbit);
                }
                else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender = rand.nextBoolean();
                    Snake snake = new Snake(true, gender, field, location);

                    herbivorous.add(snake);
                }
                else if(rand.nextDouble() <= MICE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender = rand.nextBoolean();
                    Mice mice = new Mice(true, gender, field, location);

                    predators.add(mice);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grasses = new Grass(true, field, location);

                    grass.add(grasses);
                }
                else if(rand.nextDouble() <= INFECT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Disease diseases = new Disease(true, field, location);

                    disease.add(diseases);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
