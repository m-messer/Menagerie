import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of herbivorous.
 * 
 */
public abstract class Herbivorous extends Animal
{
    // Characteristics shared by all rabbits (class variables).
    protected int foodLevel;
    protected int GRASS_FOOD_VALUE;
    // The age at which a rabbit can start to breed.
    protected   int BREEDING_AGE;
    // The age to which a rabbit can live.
    protected   int MAX_AGE;
    // The likelihood of a rabbit breeding.
    protected  double BREEDING_PROBABILITY;
    protected double D_PROBABILITY = 0.06;
    // The maximum number of births.
    protected   int MAX_LITTER_SIZE;
    // A shared random number generator to control breeding.
    protected  Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The rabbit's age.
    protected int age;
    
    /**
     * Constructor for objects of class Herbivorous
     */
    public Herbivorous(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * This is what the herbivorous does most of the time - it runs 
     * around and find food. Sometimes it will breed or die of old age.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Animal> newHerbivorous, List<Vrius> newInfected)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive()) {
            giveBirth(newHerbivorous); 
            if(rand.nextDouble() <= D_PROBABILITY){
                getDisease(newInfected);}
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }

        }    
    }

    /**
     * Increase the age.
     * This could result in the herbivorous's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this herbivorous more hungry. This could result in the herbivorous's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * An abstract method for inherence of find food
     */
    abstract public Location findFood();
    
    /**
     * Check whether or not this herbivorous is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRabbits A list to return newly born rabbits.
     */
    abstract public void giveBirth(List<Animal> newHerbivorous);
    
    /**
     * A herbivorous can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}



