import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of virus.
 * 
 * 
 */
public abstract class Vrius extends Actor
{
    // The age of virus that can infect.
    protected int INFECT_AGE;
    // The age to which a rabbit can live.
    protected int MAX_AGE;
    // The likelihood of a virus infect.
    protected double INFECT_PROBABILITY = 0.01;
    // The likelihood of a virus generate at the start.
    protected double D_PROBABILITY = 0.05;
    // The maximum number of infection.
    protected int MAX_LITTER_SIZE;
    // A shared random number generator to control breeding.
    protected Random rand = Randomizer.getRandom();
    protected int age;

    /**
     * Constructor for objects of class Herbivorous
     */
    public Vrius(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * This is what the virus does most of the time - it spreads 
     * around. Sometimes it will breed or die of old age.
     * @param newInfected A list to return infeted animals.
     */
    public void act(List<Vrius> newInfected)
    {
        incrementAge();
        if(isAlive()) {
            if(rand.nextDouble() <= D_PROBABILITY){
                Infected(newInfected);}
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
        }
    }
       
    /**
     * Increase the age.
     * This could result in the virus's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this virus is to spread at this step.
     * If yes, it will spread to adjacent animal.
     */
    private void Infected(List<Vrius> newPatient)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            if(rand.nextDouble() <= INFECT_PROBABILITY) {
                if(animal instanceof Rabbit) {
                    Rabbit rabbit = (Rabbit) animal;
                    if(rabbit.isAlive()) { 
                        rabbit.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newPatient.add(newinfected);
                        
                    }
                }
                else if(animal instanceof Snake) {
                    Snake snake = (Snake) animal;
                    if(snake.isAlive()) { 
                        snake.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newPatient.add(newinfected);
                        
                    }
                }

                else if(animal instanceof Mice) {
                    Mice mice = (Mice) animal;
                    if(mice.isAlive()) { 
                        mice.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newPatient.add(newinfected);
                        
                    }

                }
                else if(animal instanceof Fox) {
                    Fox fox = (Fox) animal;
                    if(fox.isAlive()) { 
                        fox.setDead();
                        Disease newinfected = new Disease(false, field, where);
                        newPatient.add(newinfected);
                        
                    }
                }
            }
        }
    }
   
}

