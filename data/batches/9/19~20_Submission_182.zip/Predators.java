import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of predators.
 *
 * @version (a version number or a date)
 *  
 */
public abstract class Predators extends Animal
{
    // The current age of predator.
    protected int age;
    // The predator's food level, which is increased by eating rabbits.
    protected int foodLevel;
    // The age to which a predator can live.
    protected int MAX_AGE;
    // The age to which a predator can breed.
    protected int BREEDING_AGE;
    // The likelihood of a predator breeding.
    protected double BREEDING_PROBABILITY;
    // The likelihood of a predator getting disease.
    protected double D_PROBABILITY = 0.04;
    // The maximum number of births.
    protected int MAX_LITTER_SIZE;
    // The food value of a single predator. In effect, this is the
    // number of steps a predator can go before it has to eat again.
    protected int RABBIT_FOOD_VALUE;
    protected int FOX_FOOD_VALUE;
    protected int SNAKE_FOOD_VALUE;
    protected int MICE_FOOD_VALUE;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Predators
     */
    public Predators(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * This is what a predator do in each step: eat herbivorous.
     */
    public void act(List<Animal> newPredators, List<Vrius> newInfected)
    {
        incrementAge();
        incrementHunger();

        if(isAlive()) {
            giveBirth(newPredators);
            if(rand.nextDouble() <= D_PROBABILITY){
                getDisease(newInfected);}
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }

        }
    }
    
    /**
     * An abstract method for inherence of find food.
     */
    abstract public Location findFood();

    /**
     * Increase the age. This could result in the predator's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this predator more hungry. This could result in the fox's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * An abstract method for inherence of create food
     */
    abstract public void giveBirth(List<Animal> newPredators);
    
    /**
     * determine whether an animal can breed
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
