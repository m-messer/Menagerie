import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A model of disease.
 *  
 */
public class Disease extends Vrius
{

    /**
     * Constructor for objects of class Disease
     */
    public Disease(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        INFECT_AGE = 10;
        MAX_AGE = 15;
        INFECT_PROBABILITY = 0.1;
        MAX_LITTER_SIZE = 3;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }

    }
    
    /**
     * This is what the disease does most of the time - it spread 
     * Sometimes it die of old age.
     */
    public void act(List<Vrius> newPatient)
    {
        super.act(newPatient);
    }

}
