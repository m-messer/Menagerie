import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a squirrel.
 * Squirrels age, eat, move, breed, and die.
 *
 * @version 2019.02.18
 */
public class Squirrel extends Animal
{
    // Characteristics shared by all squirrels (class variables).

    // The maximum food value of a squirrel.
    private static final int FOOD_VALUE = 15;
    // The food value of a plant.
    private static final int PLANT_FOOD_VALUE= 10;

    // The squirrel's food level.
    private int foodLevel;
    /**
     * Create a new squirrel. A squirrel may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the squirrel will have a random starting food value and age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Squirrel(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, 2, 60, 0.22, 6);
        if(randomAge) {
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * This is what the squirrel does most of the time - it runs 
     * around and eats plants. Sometimes it will breed or die of old age.
     * @param newSquirrels A list to return newly born squirrels.
     */
    public void act(List<Actor> newSquirrels)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSquirrels);

            if(diseaseNearby()==true){
                Random rand = new Random();                
                // Even if there's a disease nearby, the squirrel isn't neccessarily always
                // infected, there's a 10% chance the squirrel gets infected in this case.
                if(rand.nextInt(10)/7==1){
                    makeInfected();
                }
            }      

            if(isInfected()){
                incrementStepCounter();
            }

            // if the squirrel has been infected for 50 or more steps, it will die.             
            if(getStepsInfected()>=50){
                setDead();
                return;
            }    

            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }          
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());

        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;                
                if(plant.isAlive()) { 
                    // the squirrel eats the plant.
                    plant.setDead();
                    foodLevel += PLANT_FOOD_VALUE;
                    // if the squirrel reaches a food value more than it's intended
                    // max food value, it will cut off the extra, a squirrel can't eat more
                    // than what it's stomach can handle.
                    if(foodLevel>FOOD_VALUE){
                        int extraFood = Math.abs(FOOD_VALUE-foodLevel);
                        foodLevel -= extraFood;
                    }
                    return where;
                }
            }
        }

        // If there is no food.
        return null;
    }

    /**
     * Make this squirrel more hungry. This could result in the squirrel's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this squirrel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSquirrels A list to return newly born squirrels.
     */
    private void giveBirth(List<Actor> newSquirrels)
    {
        // New squirrels are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Squirrel young = new Squirrel(false, field, loc);
            newSquirrels.add(young);
        }
    }

    /**
     * Check whether or not this squirrel is adjacent to another squirrel of the opposite gender.
     * @return true if there's a squirrel of the opposite gender adjacent to it's location.
     */
    private boolean mateNearby(){
        boolean mateNearby = false;
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        for(int i = 0; i < adjacent.size(); i++){
            Object nearbyAnimal = getField().getObjectAt(adjacent.get(i));
            if (nearbyAnimal instanceof Squirrel) {
                Animal nearbyAnimal2 = (Squirrel) nearbyAnimal;
                if (isMale() != nearbyAnimal2.isMale()){
                    mateNearby= true;
                }
            }
        }
        return mateNearby;
    }

    /**
     * A squirrel can breed if it has reached the breeding age.
     * @return true if the squirrel can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return (mateNearby() && getAge() >= getBreedingAge());
    }

}
