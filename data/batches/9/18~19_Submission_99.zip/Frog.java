import java.util.List;
import java.util.Random;

/**
 * A simple model of a frog.
 * Frogs age, move, breed, and die.
 *
 * @version 2019.02.18
 */
public class Frog extends Animal
{
    /**
     * Create a new frog. A frog may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the frog will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog (boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, 2, 55, 0.22, 5);
    }

    /**
     * This is what the squirrel does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newFrogs A list to return newly born frogs.
     */
    public void act(List<Actor> newFrogs)
    {
        incrementAge();

        if(isAlive()) {
            giveBirth(newFrogs);  

            if(diseaseNearby()==true){
                Random rand = new Random();                
                // Even if there's a disease nearby, the frog isn't neccessarily always
                // infected, there's a 50% chance the frog gets infected in this case.
                if(rand.nextInt(10)%2==1){
                    makeInfected();
                }
            }      

            if(isInfected()){
                incrementStepCounter();
            }

            // if the frog has been infected for 20 or more steps, it will die.
            // it is more suceptible to diseases than other animals.
            if(getStepsInfected()>=20){
                setDead();
                return;
            }               
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this frog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFrogs A list to return newly born frogs.
     */
    private void giveBirth(List<Actor> newFrogs)
    {
        // New frogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Frog young = new Frog(false, field, loc);
            newFrogs.add(young);
        }
    }

    /**
     * Check whether or not this frog is adjacent to another frog of the opposite gender.
     * @return true if there's a frog of the opposite gender adjacent to it's location.
     */
    private boolean mateNearby(){
        boolean mateNearby = false;
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        for(int i = 0; i < adjacent.size(); i++){
            Object nearbyAnimal = getField().getObjectAt(adjacent.get(i));
            if (nearbyAnimal instanceof Frog) {
                Animal nearbyAnimal2 = (Frog) nearbyAnimal;
                if (isMale() != nearbyAnimal2.isMale()){
                    mateNearby= true;
                }
            }
        }
        return mateNearby;
    }

    /**
     * A frog can breed if it has reached the breeding age.
     * @return true if the frog can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return (mateNearby() && getAge() >= getBreedingAge());
    }

}
