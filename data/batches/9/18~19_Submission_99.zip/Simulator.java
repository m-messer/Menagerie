import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing several animals.
 *
 * @version 2019.02.18
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.09;
    // The probability that a hare will be created in any given grid position.
    private static final double HARE_CREATION_PROBABILITY = 0.065;
    // The probability that a cat will be created in any given grid position.
    private static final double CAT_CREATION_PROBABILITY = 0.09;
    // The probability that a frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.05;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.05;
    // The probability that a plant will be created in any given grid position.    
    private static final double PLANT_CREATION_PROBABILITY = 0.01;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The audio of the simulation.
    private SimulatorSound sound;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Hare.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Cat.class, Color.RED);
        view.setColor(Frog.class, Color.CYAN);
        view.setColor(Squirrel.class, Color.MAGENTA);
        view.setColor(Plant.class, Color.GREEN);

        // Create the audio for the game.
        sound = new SimulatorSound();

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (200 steps).
     */
    public void runLongSimulation()
    {
        simulate(200);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        if(view.isViable(field)){
            sound.play();
            for(int step = 1; step <= numSteps && view.isViable(field); step++) {
                simulateOneStep();
                delay(50);   // comment this to run faster
            }
            sound.stopSound();
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actor.
     */
    private void simulateOneStep()
    {
        step++;
        if(step % 20 == 0) {
            //every 20 steps change from day to night or vice versa.
            FieldStats.changeTime(); 
        }

        if(step % 50 == 0) {
            String temp = FieldStats.getWeather();
            //every 50 steps randomly select one of the 4 weather conditions
            FieldStats.changeWeather();

            //update sound clip being played only if the weather has actually changed
            if (FieldStats.getWeather() != temp){                
                // Stop any previous sound which was playing. This stops overlapping of audio clips.
                sound.stopSound();
                sound.play();
            }
        }

        //ensures there's always plants present on the field for the prey to eat
        if(!actors.contains(Plant.class)){
            populatePlants();
        }

        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors);
            if(! actor.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born actors to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // if the next random double that is produced by rand is less than
                // or greater to the wolf creation probability, create a wolf at that location.
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    actors.add(wolf);
                }
                else if(rand.nextDouble() <= HARE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hare hare = new Hare(true, field, location);
                    actors.add(hare);
                }
                else if(rand.nextDouble() <= CAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cat cat= new Cat(true, field, location);
                    actors.add(cat);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    actors.add(frog);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    actors.add(squirrel);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    actors.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Randomly populate the field with plants.
     */
    private void populatePlants()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY + 0.1) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    actors.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
