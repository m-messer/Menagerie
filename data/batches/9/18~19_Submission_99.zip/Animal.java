import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.18
 */
public abstract class Animal extends Actor
{
    // Characteristics shared by all animal (class variables).

    // The age at which a animal can start to breed.
    private int breedingAge;
    // The age to which a animal can live.
    private int maxAge;
    // The likelihood of a animal breeding.
    private double breedingProbability;
    // The maximum number of births.
    private int maxLitterSize;
    // The animal's age.
    private int age;
    // A shared random number generator to control breeding.
    protected Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // Whether the animal is infected or not.
    private boolean isInfected;
    // Whether the animal is male or not.
    private boolean isMale;
    // counts the amount of steps an animal has been infected for.
    private int stepInfected;

    /**
     * Create a new animal at location in field with the characteristics passed from the
     * parameter.
     * 
     * @param randomAge If true, the animal will have a random age. 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param breedingAge The age at which a animal can start to breed.
     * @param maxAge The age to which an animal can live.
     * @param breedingProbability The likelihood of a animal breeding.
     * @param maxLitterSize The maximum number of births.
     */
    public Animal(boolean randomAge, Field field, Location location, int breedingAge, int maxAge, 
    double breedingProbability, int maxLitterSize)
    {
        // pass the paramaters to the superclass constructor.
        super(field, location);
        // A number generator to determine whether the animal will have a characteristic.
        AnimalCharacteristics animalCharacteristics= new AnimalCharacteristics();
        // using a method from the AnimalCharacteristics class to determine whether animal has
        // a disease or not.
        isInfected = animalCharacteristics.assignRandomDisease();
        // using a method from the AnimalCharacteristics class to determine the animal's gender.
        isMale = animalCharacteristics.assignRandomGender();
        if(randomAge) {
            age = rand.nextInt(maxAge);
        }
        else {
            age = 0;
        }
        // assign all the paramaters to the fields within this class.
        this.breedingAge=breedingAge;
        this.maxAge=maxAge;
        this.breedingProbability=breedingProbability;
        this.maxLitterSize=maxLitterSize;        
        stepInfected = 0;
    }

    /**
     * Increments the stepInfected counter by 1. 
     */
    protected void incrementStepCounter()
    {
        stepInfected++;
    }

    /**
     * @return An int which is the amount of steps the animal has been infected for. 
     */
    protected int getStepsInfected()
    {
        return stepInfected;
    }

    /**
     * @return An int which is the age of the animal. 
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * @return An int which is the breeding age of the animal. 
     */
    protected int getBreedingAge()
    {
        return breedingAge;
    }

    /**
     * @return An int which is the max age of the animal. 
     */
    protected int getMaxAge()
    {
        return maxAge;
    }

    /**
     * @return A double which is the breeding probability of the animal. 
     */
    protected double getBreedingProbability()
    {
        return breedingProbability;
    }

    /**
     * @return An int which is the max litter size of the animal. 
     */
    protected int getMaxLitterSize()
    {
        return maxLitterSize;
    }

    /**
     * @return true If the animal is male. 
     */
    protected boolean isMale()
    {
        return isMale;
    }

    /**
     * @return true If the animal is infected. 
     */
    protected boolean isInfected()
    {
        return isInfected;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }

    /**
     * Checks the adjacent locations of the animal and if any animal in that adajcent location
     * is infected, it will return true.
     * 
     * @return true If there's another animal of any species that is infected (the isInfected 
     * variable set as true) in any adjacent location.
     */
    protected boolean diseaseNearby(){
        boolean diseaseNearby = false;
        // Make a list of type locations which contains all adjacent locations to that animal's
        // position.
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        // Go through the whole list.
        for(int i = 0; i < adjacent.size(); i++){
            Object nearbyAnimal = getField().getObjectAt(adjacent.get(i));
            // check if Object is instance of animal in the case the actor in the location
            // is not an animal or null.
            if (nearbyAnimal instanceof Animal) {
                Animal castedNearbyAnimal = (Animal) nearbyAnimal;
                if (isInfected() != castedNearbyAnimal.isInfected()){
                    diseaseNearby= true;
                }
            }
        }
        return diseaseNearby;
    }

    /**
     * Makes an animal infected. Can occur if the animal is already affected.
     */
    protected void makeInfected()
    {
        isInfected = true;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newActors);

    /**
     * Check whether the animal can breed.
     * @return true If the animal can breed.
     */
    abstract public boolean canBreed();
}
