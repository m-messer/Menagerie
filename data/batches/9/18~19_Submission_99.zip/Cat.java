import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a cat.
 * Cats age, eat, move, breed, and die.
 *
 * @version 2019.02.18
 */
public class Cat extends Animal
{
    // Characteristics shared by all cats (class variables).

    // The maximum food value of a cat.
    private static final int FOOD_VALUE = 9;
    // The food value of a hare.
    private static final int HARE_FOOD_VALUE = 9;
    // The food value of a frog.
    private static final int FROG_FOOD_VALUE = 3;
    // The food value of a squirrel.
    private static final int SQUIRREL_FOOD_VALUE = 4;

    // The cat's food level.
    private int foodLevel;
    /**
     * Create a new cat. A cat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the cat will have a random starting food value and age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cat(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, 1, 200, 0.09, 15);
        if(randomAge) {
            foodLevel = rand.nextInt(HARE_FOOD_VALUE);
        }
        else {
            foodLevel = HARE_FOOD_VALUE;
        }
    }

    /**
     * This is what the cat does most of the time - it runs 
     * around and eats hares, squirrels and frogs. Sometimes it will breed or die of old age.
     * @param newCats A list to return newly born cats.
     */
    public void act(List<Actor> newCats)
    {        
        incrementAge();
        incrementHunger();

        if(isAlive()) {
            giveBirth(newCats);

            if(diseaseNearby()==true){
                Random rand = new Random();                
                // Even if there's a disease nearby, the cat isn't neccessarily always
                // infected, there's a 20% chance the cat gets infected in this case.
                if(rand.nextInt(10)%6==0){
                    makeInfected();
                }
            }      

            if(isInfected()){
                incrementStepCounter();
            }

            // if the cat has been infected for 50 or more steps, it will die.             
            if(getStepsInfected()>=50){
                setDead();
                return;
            }    

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }           
    }

    /**
     * Make this cat more hungry. This could result in the cat's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for hares, squirrels and frogs adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());

        // it will check if it is night time, if so it will remove two random adjcent locations
        // it can move to.
        if(FieldStats.getTime() == "Night") 
        {
            Random rand= new Random();            
            adjacent.remove(rand.nextInt(adjacent.size()));
            adjacent.remove(rand.nextInt(adjacent.size()));
        }

        // it will check if it is snowy, if so it will remove a random adjcent location 
        // it can move to.
        if(FieldStats.getWeather() == "Snowy") 
        {
            Random rand= new Random();            
            adjacent.remove(rand.nextInt(adjacent.size()));
        }

        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hare) {
                Hare hare = (Hare) animal;                
                if(hare.isAlive()) { 
                    // the cat eats the hare.
                    hare.setDead();
                    foodLevel += HARE_FOOD_VALUE;
                    // if the cat reaches a food value more than it's intended
                    // max food value, it will cut off the extra, a cat can't eat more
                    // than what it's stomach can handle.
                    if(foodLevel>FOOD_VALUE){
                        int extraFood = Math.abs(FOOD_VALUE-foodLevel);
                        foodLevel -= extraFood;
                    }
                    return where;
                }
            }

            if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                //unlike for the foxes, the cats can see through the camouflage at night time.
                if(frog.isAlive()) { 
                    // the cat eats the frog.
                    frog.setDead();
                    foodLevel += FROG_FOOD_VALUE;
                    if(foodLevel>FOOD_VALUE){
                        int extraFood = Math.abs(FOOD_VALUE-foodLevel);
                        foodLevel -= extraFood;
                    }
                    return where;
                }
            }

            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    // the cat eats the squirrel.
                    squirrel.setDead();
                    foodLevel += SQUIRREL_FOOD_VALUE;
                    if(foodLevel>FOOD_VALUE){
                        int extraFood = Math.abs(FOOD_VALUE-foodLevel);
                        foodLevel -= extraFood;
                    }
                    return where;
                }
            }
        }

        // If there is no food.
        return null;
    }

    /**
     * Check whether or not this cat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCats A list to return newly born cats.
     */
    private void giveBirth(List<Actor> newCats)
    {
        // New cats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cat young = new Cat(false, field, loc);
            newCats.add(young);
        }
    }

    /**
     * Check whether or not this cat is adjacent to another cat of the opposite gender.
     * @return true if there's a cat of the opposite gender adjacent to it's location.
     */
    private boolean mateNearby(){
        boolean mateNearby = false;
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        for(int i = 0; i < adjacent.size(); i++){
            Object nearbyAnimal = getField().getObjectAt(adjacent.get(i));
            if (nearbyAnimal instanceof Cat) {
                Animal nearbyAnimal2 = (Cat) nearbyAnimal;
                if (isMale() != nearbyAnimal2.isMale()){
                    mateNearby= true;
                }
            }
        }
        return mateNearby;
    }

    /**
     * A cat can breed if it has reached the breeding age.
     * @return true if the cat can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return (mateNearby() && getAge() >= getBreedingAge());
    }

}
