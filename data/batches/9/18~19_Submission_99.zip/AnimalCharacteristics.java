import java.util.Random;
/**
 * This class is respossible for determining the chance of which
 * an animal will be born with a certain charactertistic or not.
 *
 * @version 2019.02.18
 */
public class AnimalCharacteristics
{
    /**
     * No constructor for objects of class AnimalCharacteristics
     */
    public AnimalCharacteristics()
    {
    }

    /**
     * Creates a new random variable and sees if it's divisible by 2, if it is, it
     * will return true, otherwise, false. Ideally, this means there's a 50% probability
     * for an animal to be male or female. On a large scale of numbers, this probability
     * will be more and more accurate, therefore, half the animals should be split to female
     * and half to male. There will be natural variation.
     * @return true if the number is divisble by 2.
     */
    public boolean assignRandomGender()
    {
        Random rand = new Random();
        if (rand.nextInt()%2==0){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Creates a new random variable and sees if it's divisible by 100, if it is, it
     * will return true, otherwise, false. If the number is changed to a smaller number,
     * the chance of an animal having a disease will be more likely as more numbers r divisible by
     * smaller numbers. There will be natural variation.
     * @return true if the number is divisble by 100.
     */
    public boolean assignRandomDisease()
    {
        Random rand = new Random();
        if (rand.nextInt()%100==0){
            return true;
        }
        else{
            return false;
        }
    }  
}
