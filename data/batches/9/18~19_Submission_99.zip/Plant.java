import java.util.List;
import java.util.Random;

/**
 * A simple model of a plant.
 * Plants age, grow and die.
 *
 * @version 2019.02.18
 */
public class Plant extends Actor
{
    // The likelihood of a plant growing.
    private static final double GROWING_PROBABILITY = 0.02;
    
    // The maximum age of the plant.
    private static final int MAX_AGE = 100;
    
    // The maximum number of growths.
    private static final int MAX_LITTER_SIZE = 1;
    
    private static final Random rand = Randomizer.getRandom();
    
    // The age of the plant.
    private int age;

    /**
     * Create a new plant. A plant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the plant does most of the time - it grows.
     * Sometimes it will grow or die of old age.
     * @param newPlants A list to return newly born plants.
     */
    public void act(List<Actor> newPlants)
    {
        incrementAge();

        if(isAlive()) {
            growPlants(newPlants);
        }               
    }

    /**
     * Increase the age.
     * This could result in the plant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this plant is to grow at this step.
     * New growths will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     */
    private void growPlants(List<Actor> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int growths = grow();
        for(int g = 0; g < growths && free.size() > 0; g++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc);
            newPlants.add(young);
        }
    }

    /**
     * Generate a number representing the number of growths,
     * if it can grow.
     * @return The number of growths (may be zero).
     */
    private int grow()
    {
        int births = 0;
        if(rand.nextDouble() <= GROWING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

}

