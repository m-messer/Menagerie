import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Wolf.
 * Wolves age, eat, move, breed, and die.
 *
 * @version 2019.02.18
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).
    
    // The maximum food value of a wolf.
    private static final int FOOD_VALUE = 10;
    // The food value of a hare.
    private static final int HARE_FOOD_VALUE = 10;
    // The food value of a frog.
    private static final int FROG_FOOD_VALUE = 6;
    // The food value of a squirrel.
    private static final int SQUIRREL_FOOD_VALUE = 8;
    
    // The wolf's food level.
    private int foodLevel;

    /**
     * Create a new Wolf. A wolf may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the wolf will have a random starting food value and age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, 2, 170, 0.095, 15);
        if(randomAge) {
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * This is what the wolf does most of the time - it runs 
     * around and eats hares, squirrels and frogs. Sometimes it will breed or die of old age.
     * @param newWolves A list to return newly born wolves.
     */
    public void act(List<Actor> newWolves)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWolves);            

            if(diseaseNearby()==true){
                Random rand = new Random();                
                // Even if there's a disease nearby, the wolf isn't neccessarily always
                // infected, there's a 20% chance the wolf gets infected in this case.
                if(rand.nextInt(10)%6==0){
                    makeInfected();
                }
            }      
            
            if(isInfected()){
                incrementStepCounter();
            }

            // if the wolf has been infected for 50 or more steps, it will die.             
            if(getStepsInfected()>=50){
                setDead();
                return;
            }    

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this wolf more hungry. This could result in the wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for hares, squirrels and frogs adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());

        // it will check if it is night time, if so it will remove two random adjcent locations
        // it can move to.
        if(FieldStats.getTime() == "Night") 
        {
            Random rand= new Random();            
            adjacent.remove(rand.nextInt(adjacent.size()));
            adjacent.remove(rand.nextInt(adjacent.size()));
        }

        // it will check if it is snowy, if so it will remove a random adjcent location 
        // it can move to.
        if(FieldStats.getWeather() == "Snowy") 
        {
            Random rand= new Random();            
            adjacent.remove(rand.nextInt(adjacent.size()));
        }

        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hare) {
                Hare hare = (Hare) animal;                
                if(hare.isAlive()) { 
                    // the wolf eats the hare.
                    hare.setDead();
                    foodLevel += HARE_FOOD_VALUE;
                    // if the wolf reaches a food value more than it's intended
                    // max food value, it will cut off the extra, a wolf can't eat more
                    // than what it's stomach can handle.
                    if(foodLevel>FOOD_VALUE){
                        int extraFood = Math.abs(FOOD_VALUE-foodLevel);
                        foodLevel -= extraFood;
                    }
                    return where;
                }
            }

            if(animal instanceof Frog){
                Frog frog = (Frog) animal;
                // If it is night time, the wolf will cannot eat the frog due to camouflage.
                if (FieldStats.getTime() == "Night"){ 
                    return null;
                }

                if(frog.isAlive()){
                    frog.setDead();
                    foodLevel += FROG_FOOD_VALUE;
                    if(foodLevel>FOOD_VALUE){
                        int extraFood = Math.abs(FOOD_VALUE-foodLevel);
                        foodLevel -= extraFood;
                    }
                    return where;
                }                
            }

            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    squirrel.setDead();
                    foodLevel += SQUIRREL_FOOD_VALUE;
                    if(foodLevel>FOOD_VALUE){
                        int extraFood = Math.abs(FOOD_VALUE-foodLevel);
                        foodLevel -= extraFood;
                    }
                    return where;
                }
            }
        }

        // If there is no food.
        return null;
    }

    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolves.
     */
    private void giveBirth(List<Actor> newWolves)
    {
        // New wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, field, loc);
            newWolves.add(young);
        }
    }

    /**
     * Check whether or not this wolf is adjacent to another wolf of the opposite gender.
     * @return true if there's a wolf of the opposite gender adjacent to it's location.
     */
    private boolean mateNearby(){
        boolean mateNearby = false;
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        for(int i = 0; i < adjacent.size(); i++){
            Object nearbyAnimal = getField().getObjectAt(adjacent.get(i));
            if (nearbyAnimal instanceof Wolf) {
                Animal nearbyAnimal2 = (Wolf) nearbyAnimal;
                if (isMale() != nearbyAnimal2.isMale()){
                    mateNearby= true;
                }
            }
        }
        return mateNearby;
    }

    /**
     * A wolf can breed if it has reached the breeding age.
     * @return true if the wolf can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return (mateNearby() && getAge() >= getBreedingAge());
    }

}
