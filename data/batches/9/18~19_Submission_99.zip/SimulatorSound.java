import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.File;
import javax.sound.sampled.*;
import javax.swing.*;

/**
 * This class fetches and plays all the audio that is present in the game.
 *
 * @version 2019.02.18
 */
public class SimulatorSound
{
    // the clip that holds the audio files you want to play. Only one needed
    // as only a few audio files.
    private Clip clip;

    /**
     * No constructor.
     */
    public SimulatorSound()
    {

    }

    /**
     * Play the audio dependant on the weather.
     */
    public void play()
    {
        if( FieldStats.getWeather() == "Rainy") {
            playRain();
        }

        if( FieldStats.getWeather() == "Snowy") {
            playSnow();
        }

        if( FieldStats.getWeather() == "Sunny") {
            playSun();
        }

        if( FieldStats.getWeather() == "Windy") {
            playWind();
        }
    }

    /**
     * Play the rainy.wav audio file which is in the sounds folder.
     */
    private void playRain()
    {
        playSound("rainy");
    }

    /**
     * Play the snowy.wav audio file which is in the sounds folder.
     */
    private void playSnow()
    {
        playSound("snowy");
    }

    /**
     * Play the suny.wav audio file which is in the sounds folder.
     */
    private void playSun()
    {
        playSound("sunny");
    }

    /**
     * Play the windy.wav audio file which is in the sounds folder.
     */
    private void playWind()
    {
        playSound("windy");
    }

    /**
     * Fetch and play the sound file according to the string that is passed on via the paramater.
     *
     * @param sound The name of the sound file in the sounds folder present in the package directory.
     */
    private void playSound(String sound)
    {
        try {
            // find and load file into an audio input stream.
            AudioInputStream ais = AudioSystem.getAudioInputStream(new BufferedInputStream(
                        new FileInputStream("sounds/" + sound + ".wav")));                   
            clip = AudioSystem.getClip();
            // opens the clip, feed the audio input stream to the clip.
            clip.open(ais);
            // infinitely loop the audio file being played in case the audio runs out.
            clip.loop(Clip.LOOP_CONTINUOUSLY);
            // start the audio in the clip.
            clip.start();
        } catch (Exception e) {
            System.out.println("Audio error");
        }
    }

    /**
     * Stops any clip that was previously playing.
     * Closes any clip too because heap memory can fill up fast if not closed.
     */
    public void stopSound() 
    {
        // stops the audio being played.
        clip.stop();
        // closes the clip.
        clip.close();
    }
}
