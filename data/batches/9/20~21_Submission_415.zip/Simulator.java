import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing animals and plants.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that the creature will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY =0.02;
    private static final double CHEETAH_CREATION_PROBABILITY = 0.03;
    private static final double CATTLE_CREATION_PROBABILITY = 0.05;
    private static final double SHEEP_CREATION_PROBABILITY = 0.06;
    private static final double MOUSE_CREATION_PROBABILITY = 0.08;
    private static final double PLANT_CREATION_PROBABILITY = 0.5;
    // List of animals in the field
    private List<Creature> creatures;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //manipulate the day and night (after every 12 steps the state of the day will change) 
    private int time = 0;
    //The state of the day;
    static boolean isDay = true;
    //manipulate the rate of rain.
    private int rain = 0;
    //the state of raining.(after every 2 steps the state of the whether will change)
    static boolean isRaining =false;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // list of all creatures including plants
        creatures = new ArrayList<>();
        field = new Field(depth, width);
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Mouse.class, Color.ORANGE);
        view.setColor(Lion.class, Color.BLUE);
        view.setColor(Sheep.class, Color.PINK);
        view.setColor(Cattle.class, Color.YELLOW);
        //The color of Plants is black but we can not see it because plants are in the first floor of field. I set it for checking whether there is something wrong with my method
        //of putting Plant into the field.
        view.setColor(Plant.class, Color.BLACK);
        view.setColor(Cheetah.class, Color.RED);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * creature.
     */
    public void simulateOneStep()
    {
        step++;
        time++;
        rain++;
        if(time ==13){
            isDay = !isDay;
            time = 1;
        }
        
        if(rain == 3){
            isRaining = !isRaining;
            rain = 1;
        }
        // Provide space for newborn animals.
        
            List<Creature> newCreatures = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
            Creature creature = it.next();
            creature.act(newCreatures);
            if(! creature.isAlive()) {
                it.remove();
            }
        }
    
               
        // Add the newly born foxes and rabbits to the main lists.
        creatures.addAll(newCreatures);
    

        view.showStatus(step, field);
    }
    

        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
       
        creatures.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with creatures(animals and plants).
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,1);//animals put in second floor only.
                    Lion lion = new Lion(true, field, location);
                    creatures.add(lion);
                }
                else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,1);
                    Cheetah cheetah = new Cheetah(true, field, location);
                    creatures.add(cheetah);
                }
                else if(rand.nextDouble() <= CATTLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,1);
                    Cattle cattle = new Cattle(true, field, location);
                    creatures.add(cattle);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col,1);
                    Sheep sheep = new Sheep(true, field, location);
                    creatures.add(sheep);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col ,1);
                    Mouse mouse = new Mouse(true, field, location);
                    creatures.add(mouse);
                }
                
                
            }
        }
        //The probability of creations of plants is too large , if we put this part in the part above the creation of animals will be influenced.
        for(int row = 0; row <field.getDepth(); row++){
          for(int col = 0; col < field.getWidth(); col++){
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col ,0);//plants put in first floor only.
                   Plant plant = new Plant(field, location);
                    creatures.add(plant);
               }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
}
