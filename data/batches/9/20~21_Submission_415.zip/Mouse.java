import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a mouse.
 * mouses age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Mouse extends Creature
{
     // Characteristics shared by all mouses (class variables).

    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    private boolean isFemale;
    // The mouse's age.
    private int age;
    // The number of steps that one plant can make the mouse keep going on.  
    private static final int PLANT_FOOD_VALUE = 20;
    //steps that the mouse can go.
    private int foodLevel;
    /**
     * Create a new mouse. A mouse may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the mouse will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
   public Mouse(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        Random random = new Random();
        isFemale = random.nextBoolean(); 
        if(randomAge)
        {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the mouse does most of the time - it runs 
     * around and eat plants. Sometimes it will breed or die of old age.
     * Animal will get older whatever the time is, but it will be hungry and do other things only in the day time instead of night.
     * @param newMouses A list to return newly born mouses.
     */
    public void act(List<Creature> newMouses)
    {
        incrementAge();
        if(Simulator.isDay==true){
        incrementHunger();
        }
        if(isAlive()&&Simulator.isDay==true){
            giveBirth(newMouses);            
            findPlant();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the mouse's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this mouse is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMouses A list to return newly born rabbits.
     */
    private void giveBirth(List<Creature> newMouses)
    {
        // New mouses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Mouse young = new Mouse(false, field, loc);
            newMouses.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(findMale()&&canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
        }
    
    /**
     * A Mouse can breed if it has reached the breeding age and  it is female.
     * @return true if the mouse can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return isFemale&& age >= BREEDING_AGE;
    }
    
    /**
     * 
     * @return true if the mouse is female, false otherwise.
     */
    private boolean getSex(){
        return isFemale;
    }
    /**
     * A Mouse can breed if it has reached the breeding age and  it is female.
     * @return true if the mouse finds male, false otherwise.
     */
    private boolean findMale(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Mouse){
                Mouse mouse = (Mouse) creature;
                if(mouse.getSex() == false){
                    return true;
                }
            }
        }
        return false;
    
    }
    
    /**
     * get older.
     * 
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    /**
     * A Mouse eats plants if it finds plants around itself.
     * 
     */
    private void findPlant(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            infectDisease(creature);//spread disease.
            if(creature instanceof Plant){
                Plant plant = (Plant) creature;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    
                }
            }
            
        }
       
    }
    
     public void disease(){
        foodLevel=foodLevel-2;
    }
}
