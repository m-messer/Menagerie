import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Cattle.
 * Cattles age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Cattle extends Creature
{
    // Characteristics shared by all cattles (class variables).

    // The age at which a cattle can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a cattle can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a cattle breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE =4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // the sex of the cattle.
    private boolean isFemale;
    // The cattle's age.
    private int age;
    // The food value of a single plant. In effect, this is the
    // number of steps a cattle can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE =20;
    // The cattle's food level, which is increased by eating plants.
    private int foodLevel;
    /**
     * Create a new cattle. A cattle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the cattle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cattle(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        Random random = new Random();
        isFemale = random.nextBoolean();
        age = 0;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the cattle does most of the time - it runs 
     * around. It will breed or die of old age. It will do these things during the day time, but it will get older every step.
     * @param newCattles A list to return newly born cattles.
     */
    public void act(List<Creature> newCattles)
    {
        incrementAge();
        if(Simulator.isDay==true){
        incrementHunger();
        }
        if(isAlive()&&Simulator.isDay==true){
            giveBirth(newCattles);            
            // Try to move into a free location.
            findPlant();
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the cattle's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this cattle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCattles A list to return newly born cattles.
     */
    private void giveBirth(List<Creature> newCattles)
    {
        // New cattles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cattle young = new Cattle(false, field, loc);
            newCattles.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed and find a male cattle.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(findMale()&& canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A cattle can breed if it has reached the breeding age and it is female.
     * @return true if the cattle can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return isFemale&& age >= BREEDING_AGE;
    }
    
    /**
     * 
     * @return true if the cattle is female, false otherwise.
     */
    private boolean getSex(){
        return isFemale;
    }
    
    /**
     * A cattle can breed if it has reached the breeding age and  it is female.
     * @return true if the cattle finds male, false otherwise.
     */
    private boolean findMale(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Cattle){
                Cattle cattle = (Cattle) creature;
                if(cattle.getSex() == false){
                    return true;
                }
            }
        }
        return false;
    
    }
    
    
    /**
     * Increase the age. This could result in the cattle's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * A cattle eats plants if it finds plants around itself.
     * 
     */
    private void findPlant(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            infectDisease(creature);//spread disease.
            if(creature instanceof Plant){
                Plant plant = (Plant) creature;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    
                }
            }
        }
    }
    
     public void disease(){
        foodLevel=foodLevel-2;
    }
}
