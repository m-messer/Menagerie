/**
 * Represent a location in a rectangular grid.
 *
 * @version 2016.02.29
 */
public class Location
{
    // Row and column and height positions.
    private int row;
    private int col;
    private int height;
    /**
     * Represent a row and column and height.
     * @param row The row.
     * @param col The column.
     * @param col The height.
    */
    public Location(int row, int col, int height)
    {
        this.row = row;
        this.col = col;
        this.height = height;
    }
    
    /**
     * Implement content equality.
     */
    public boolean equals(Object obj)
    {
        if(obj instanceof Location) {
            Location other = (Location) obj;
            return row == other.getRow() && col == other.getCol()&& height ==other.getHei();
        }
        else {
            return false;
        }
    }
    
    /**
     * Return a string of the form row,column,height.
     * @return A string representation of the location.
     */
    public String toString()
    {
        return row + "," + col + "," + height;
    }
    
    /**
     * Use the top 16 bits for the row value and the bottom for
     * the column and height. Except for very big grids, this should give a
     * unique hash code for each (row, col,height) pair.
     * @return A hashcode for the location.
     */
    public int hashCode()
    {
        return (row << 16) + col + height;
    }
    
    /**
     * @return The row.
     */
    public int getRow()
    {
        return row;
    }
    
    /**
     * @return The column.
     */
    public int getCol()
    {
        return col;
    }
    
    /**
     * @return The height.
     */
    public int getHei()
    {
        return height;
    }
}
