import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @version 2020.02.22 
 */
public class Weather
{   
    // List storing possible Weather conditions.
    private static final List<String> conditions=  new ArrayList(Arrays.asList("Rain","Sun","Fog","Snow","Clouds"));
    //Current weather conditions
    private String currentWeather;
    //Random type for generating random values.
    private Random rand = new Random();
   /**
    * Call method for setting the weather
    * @param Current season as String. Obtained from Calendar.
    */
   public Weather(String inputSeason)
   {
       setWeather(inputSeason);
    
   }
   /**
    * Call method to generate weather for current season
    * @param  Current season as String. From constructor.
    */
   protected void setWeather(String inputSeason)
    {
        if(inputSeason == "Spring")
        {generateSpringWeather();}
        else if(inputSeason == "Summer")
        {generateSummerWeather();}
        else if(inputSeason == "Autumn")
        {generateAutumnWeather();}
        else if(inputSeason == "Winter")
        {generateWinterWeather();}
    }
   /**
    * Generate random Winter weather.
    * Based on specific probabilities for the season.
    */
   public void generateWinterWeather()
    
    { 
        // probability of weather in Winter:
          double chanceRoll = rand.nextDouble()+0.01;
          //System.out.println(chanceRoll);
          //System.out.println(0.01 <= chanceRoll && chanceRoll <= 0.10);
       if(0.01 <= chanceRoll && chanceRoll <= 0.05)
         {
            //System.out.println("0-10%");
            currentWeather = "Sun";
         }
           else if(0.11 <= chanceRoll && chanceRoll <= 0.2)
         {
            //System.out.println("11-20%");
            currentWeather = "Fog";
        } else if(0.21 <= chanceRoll && chanceRoll <= 0.6)
         {
            //System.out.println("21-40%");
            currentWeather = "Clouds";
         } else if(0.61 <= chanceRoll && chanceRoll <= 0.9)
         {
            //System.out.println("41-75%");
            currentWeather = "Rain";
         }
         else if(0.9 <= chanceRoll && chanceRoll <= 1.00)
         {//System.out.println("76-100%");
             currentWeather= "Snow";
         }
       
    } 
   /**
    * Generate random Spring weather.
    * Based on specific probabilities for the season.
    */ 
   public void generateSpringWeather()
    
    { // probability of weather in Spring:
         double chanceRoll = rand.nextDouble()+0.01;
         System.out.println(chanceRoll);
       if(0.01 <= chanceRoll && chanceRoll <= 0.05)
         {
            //System.out.println("0-5%");
            currentWeather = "Snow";
         }
           else if(0.06 <= chanceRoll && chanceRoll <= 0.25)
         {
            //System.out.println("6-25%");
            currentWeather = "Rain";
         } else if(0.26 <= chanceRoll && chanceRoll >= 0.35)
         {
            //System.out.println("26-35");
            currentWeather = "Fog"; 
        }else if(0.36 <= chanceRoll && chanceRoll >= 0.60)
         {
            //System.out.println("36-60%");
            currentWeather = "clouds";
         }
         else if(0.61 <= chanceRoll && chanceRoll >= 1.00)
         {//System.out.println("61-100%");
             currentWeather= "Sun";
         }
    
    }
   /**
    * Generate random Summer weather.
    * Based on specific probabilities for the season.
    */ 
   public void generateSummerWeather()
        
    { // probability of weather in Summer:
         double chanceRoll = rand.nextDouble()+0.01;
         System.out.println(chanceRoll);
       if(0.01 <= chanceRoll && chanceRoll >= 0.02)
         {
            //System.out.println("0-2%");
            currentWeather = "Snow";
         }
           else if(0.03 <= chanceRoll && chanceRoll >= 0.15)
         {
            //System.out.println("3-15%");
            currentWeather = "Fog";
         } 
         else if(0.16 <= chanceRoll && chanceRoll >= 0.24)
         {
            //System.out.println("16-24%");
            currentWeather = "Rain";
         } 
          else if(0.25 <= chanceRoll && chanceRoll >= 0.45)
         {
            System.out.println("25-45%");
            currentWeather = "Clouds";
         }
         else if(0.46 <= chanceRoll && chanceRoll >= 1.00)
         {//System.out.println("46-100%");
             currentWeather= "Sun";
         }
    }
   /**
    * Generate random Autumn weather.
    * Based on specific probabilities for the season.
    */ 
   public void generateAutumnWeather()
    { // probability of weather in Autumn:
         double chanceRoll = rand.nextDouble()+0.01;
         System.out.println(chanceRoll);
       if(  0.01 <= chanceRoll && chanceRoll >= 0.15)
         {
            //System.out.println("0-15%");
            currentWeather = "Snow";
         }  else if(0.16 <= chanceRoll && chanceRoll >= 0.40)
         {
            //System.out.println("16-40%");
            currentWeather = "Rain";
        } else if(0.41 <= chanceRoll && chanceRoll >= 0.70)
         {
            //System.out.println("41-70%");
            currentWeather = "Clouds";
         } else if(0.71 <= chanceRoll && chanceRoll >= 0.80)
         {
            //System.out.println("71-80%");
            currentWeather = "Fog";
         }
         else if(0.46 <= chanceRoll && chanceRoll >= 1.00)
         {//System.out.println("81-100%");
             currentWeather= "Sun";
         }
    }
   /**
    * Returns current weather.
    * @return current weather.
    */ 
   public String getWeather()
    { 
        return currentWeather;   
    }
}
