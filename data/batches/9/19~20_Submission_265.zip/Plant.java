import java.util.List;
/**
 * Plant class. Carries out plant's pollinate methods. 
 * How they spread to other locations.
 *
 * @version 2020.02.22
 */
public interface Plant
{   
    default void pollinate(List<Actor> newPlants, Actor myself)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = myself.getField();
        List<Location> free = field.getFreeAdjacentLocations(myself.getLocation());
        int births = myself.breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            //Use try/catch to work around method and instantiation exceptions.
            try
            {// reflect contructor to access second constructors in specified sub classes with the specified parameters.
             // Create new instance and add to Actor list directly from Plant class.
            Actor young = myself.getClass().getConstructor(boolean.class, Field.class, Location.class).newInstance(false, field, loc);
            newPlants.add(young);
            }
            catch(Exception e)
            {System.out.println("Something has gone wrong");}
        }
    }
}
