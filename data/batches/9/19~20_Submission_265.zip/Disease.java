import java.util.List;
/**
 * Abstract class Disease
 * Set as targets species and organisms disease is prone to affect.
 *
 * @version 2020.02.22 
 */
public abstract class Disease
{
    //List of targets disease can affect.
    private final List infectionTargets;
    /**
     * Sets list of disease's possible targets to infect.
     * @param list of valid targets for disease.
     */
    public Disease(List validInfectionTargets)
    {
        infectionTargets = validInfectionTargets;
    }
}
