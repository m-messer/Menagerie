import java.util.List;
import java.util.ArrayList;

/**
 * A class representing shared characteristics of Actors.
 *
 * @version 2020.02.22 
 */
public abstract class Actor
{
    // Whether the Actor is alive or not.
    private boolean alive;
    // The Actor's field.
    private Field field;
    // The Actor's position in the field.
    private Location location;
    
    /**
     * Create a new Actor at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Actor(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * List of all methods Actors have to implement.
     * Will result in Plants having redundant methods 
     * due to the nature of the Animal/Plant inheritance.
     */
    abstract protected void act(List<Actor> newActors);
    abstract protected void incrementAge();
    abstract protected int breed();
    abstract protected boolean canBreed();
    abstract protected List getFoodTypes();
    abstract protected int getFoodLevel();
    abstract protected int getFoodValue();
    abstract protected void updateFoodLevel(int inputFood);
    abstract protected boolean getIsMale();
    abstract protected int getMaxFoodLevel();
    abstract protected ArrayList getDiseases();
    abstract protected void addDisease(Disease inputDisease);
    
    /**
     * Check whether the Actor is alive or not.
     * @return true if the Actor is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the Actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        if(this.getClass().getSimpleName()=="Grass")
        {   // Stack trace to identify source of inbalance/error in a species population numbers.
            //StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
            //System.out.println(this.getClass().getSimpleName()+ "Has died " + Thread.currentThread().getStackTrace()[1].getMethodName() + this);
            //System.out.println(this.getClass().getSimpleName()+ "Has died " + Thread.currentThread().getStackTrace()[2].getMethodName() + this);
            //System.out.println(this.getClass().getSimpleName()+ "Has died " + Thread.currentThread().getStackTrace()[3].getMethodName() + this);
            //System.out.println(this.getClass().getSimpleName()+ "Has died " + Thread.currentThread().getStackTrace()[4].getMethodName() + this);
            //System.out.println(this.getClass().getSimpleName()+ "Has died " + Thread.currentThread().getStackTrace()[5].getMethodName() + this);
            //System.out.println(this.getClass().getSimpleName()+ "Has died " + Thread.currentThread().getStackTrace()[6].getMethodName() + this);
        }
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the Actor's location.
     * @return The Actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the Actor at the new location in the given field.
     * @param newLocation The Actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the Actor's field.
     * @return The Actor's field.
     */
    protected Field getField()
    {
        return field;
    }
}
