import java.util.*;
/**
 * Calendar class: Keeps track of daytime, date, time, and season
 * Can set or retrieve current time.
 *
 * @version 2020.02.22
 */
public class CustomCalendar
{   //
    private boolean isDay;
    private Calendar localCalendar;
    private String season;
    
    
    /**
     * Constructor for objects of class Calendar
     */
    public CustomCalendar() 
    {   //Instantiate Calendar.Get current date and time.
        localCalendar = localCalendar.getInstance();
        //Sets isDay to true if it between 6am and 6pm
        if(6<= localCalendar.get(Calendar.HOUR_OF_DAY) && localCalendar.get(Calendar.HOUR_OF_DAY) < 18)
        {isDay = true;}
        else
        {isDay = false;}
        // Set the season.
        int currentMonth = localCalendar.get(Calendar.MONTH);
        
        switch (currentMonth)
        {
            //Winter months
            case 11: case 0: case 1:
            season = "Winter";
            break;
            
            //Spring months
            case 2: case 3: case 4:
            season = "Spring";
            break;
            
            //Summer months
            case 5: case 6: case 7:
            season = "Summer";
            break;
            
            //Autumn months
            case 8: case 9: case 10:
            season = "Autumn";
            break;
            
        }
        
    }
    
    /**
     * Second Constructor for objects of class Calender
     * @param Year; set Calendar's year.
     * @param Month; set Calendar's Month.
     * @param Date; set Calendar's Date.
     * @param Hour; set Calendar's Hour.
     * @param Minute; set Calendar's Minute.
     */
    public CustomCalendar(int year, int month, int date, int hour, int min)
    {
        //Sets isDay to true if it between 6am and 6pm
        if(6<= hour && hour < 18)
        {isDay = true;}
        else
        {isDay = false;}
        //Instantiate & Assign values.
        localCalendar = localCalendar.getInstance();
        localCalendar.set(year, month, date, hour, min);
        
        //Set the season.
        int currentMonth = localCalendar.get(Calendar.MONTH);
        
        switch (currentMonth)
        {
            //Winter months
            case 11: case 0: case 1:
            season = "Winter";
            System.out.println(season);
            break;
            
            //Spring months
            case 2: case 3: case 4:
            season = "Spring";
            System.out.println(season);
            break;
            
            //Summer months
            case 5: case 6: case 7:
            season = "Summer";
            System.out.println(season);
            break;
            
            //Autumn months
            case 8: case 9: case 10:
            season = "Winter";
            System.out.println(season);
            break;
            
        }
    }
    /**
     * Update Calendar's hour.
     */
    public void moveCalendarOneHour()
    {
        localCalendar.add(Calendar.HOUR_OF_DAY, 1);
        //System.out.println(localCalendar.getTime());
        if(6<= localCalendar.get(Calendar.HOUR_OF_DAY) && localCalendar.get(Calendar.HOUR_OF_DAY) < 18)
        {isDay = true;}
        else
        {isDay = false;}
    }
    /**
     * Return current date and time.
     * @return current date and time.
     */
    public Date getTime()
    {return localCalendar.getTime();}
    /**
     * Return if day or not.
     * @return if day or not.
     */
    public boolean getIsDay()
    {return isDay;}
    /**
     * Return season.
     * @return season.
     */
    public String getSeason()
    {return season;}
}

