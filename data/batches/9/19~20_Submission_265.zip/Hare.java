import java.util.Random;
import java.util.List;
import java.util.Iterator;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * A simple model of a Hare.
 * Hares age, move, breed, contract diseases and die.
 *
 * @version 2020.02.22 
 */
public class Hare extends Actor implements Animal
{
     // Characteristics shared by all Hares (Animal class variables).

    // The age at which a Hare can start to breed(6 months).
    private static final int BREEDING_AGE = 5;
    // The age to which a Hare can live(2 years).
    private static final int MAX_AGE = 40;
    // The likelihood of a Prey breeding.
    private static final double BREEDING_PROBABILITY = 0.99;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 9;
    // How filling a Hare is as a food source.
    private static final int HARE_FOOD_VALUE = 78;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    
     
   
    
    // Individual characteristics (instance fields).
    
    // The Prey's age.
    private int age;
    // Prey is male or not.
    private boolean isMale;
    // How much has it eaten.
    private int foodLevel;
    // Max amount it can eat.
    private final int MAX_FOOD_LEVEL = 20;
    // list of valid food sources for a Hare.
    private final List foodTypes = new ArrayList(Arrays.asList("Grass"));
    // list of current diseases Hare is contracting.
    private ArrayList myDiseases;

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age. Born disease-free.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hare(boolean randomAge, Field field, Location location)
    {   
        super(field,location);
        isMale = rand.nextBoolean();
        myDiseases = new ArrayList<>();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL/2);
        }
    }
    
    /**
     * Create, Return a new instance of Hare.
     * @return new instance of Hare.
     */
    public Hare newInstance(boolean randomAge, Field field, Location location)
    {
        return new Hare(false, field, location);
    }
    
    /**
     * This is what the rabbit does most of the time - it runs 
     * around. Sometimes it will breed, look for food or die of old age.
     * @param newRabbits A list to return newly born Hares.
     */
    protected void act(List<Actor> newHares)
    {
        incrementAge();
        incrementHunger();
        Location newLocation = null;
        
        if(isAlive() && !myDiseases.isEmpty())
        {
           if((rand.nextDouble())<= 0.03)
           {
               this.setDead();
           }
        }
        
        if(isAlive()) {
            reproduce(newHares, this);            
            // Try to move into a free location.
            if(foodLevel <= (MAX_FOOD_LEVEL/2))
            {
                if(!getField().getIsDay())
                {
                    if((rand.nextDouble() <= 0.95))
                    {newLocation = findFood();}
                
                }
                else
                {newLocation = findFood();}
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Look for food adjacent to the current location. Only the first food found is eaten.
     * Only eat if valid food type. Can contract disease if contaminated.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plantActor = field.getObjectAt(where);
            if(plantActor!= null && foodTypes.contains(plantActor.getClass().getSimpleName())) {
                Actor plant = (Actor) plantActor;
                if(plant.isAlive() && plant.getDiseases().isEmpty()) { 
                    plant.setDead();
                    foodLevel = plant.getFoodValue();
                    return where;
                }
                else if(!plant.getDiseases().isEmpty())
                {
                    //Sickness chance if eating a diseased plant
                    //System.out.println("Plant has a disease" + plant.getDiseases());
                    if((rand.nextDouble()+0.01)<= 0.1)
                    {
                        Myxomatosis newMyx = new Myxomatosis();
                        myDiseases.add(newMyx);
                        //System.out.println("Myx infection" + this.getDiseases());
                    }
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Increase the age.
     * This could result in the rabbit's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            //System.out.println("Rabbit has died from old age");
            setDead();
        }
    }
    
    /**
     * Make this hare more hungry. This could result in the hare's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this hare is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHares A list to return newly born hares.
     */
    private void giveBirth(List<Actor> newHares)
    {
        // New hares are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hare young = new Hare(false, field, loc);
            newHares.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hare can breed if it has reached the breeding age.
     * @return true if the hare can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    /**
     * Return how much a hare has eaten.
     * @return value indicating how muhchare has eaten.
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Return valid food for hare.
     * @return list of food hare can eat.
     */
    public List getFoodTypes()
    {
        return foodTypes;
    }
    
    /**
     * Return how filling hare is as a food source.
     * @return the food value of a hare.
     */
    public int getFoodValue()
    {
        return HARE_FOOD_VALUE;
    }
    
    /**
     * Update food levels of hare after feeding.
     * @param value of food consumed.
     */
    public void updateFoodLevel(int inputFood)
    {
        foodLevel += inputFood;
    }
    
    /**
     * Return if hare is male.
     * @return true if hare is male. False if female.
     */
    public boolean getIsMale()
    {
        return isMale;
    }
    
    /**
     * Return value for hare's food level when full.
     * @return hare's max food level value.
     */
    public int getMaxFoodLevel()
    {return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return arraylist of diseases Hare currently contracts.
     * @return arraylist of hare's current diseases.
     */
    protected ArrayList getDiseases()
    {return myDiseases;
    }
    
    /**
     * Add disease to hare. Hare contracts a disease.
     * @param input disease type to hare's disease list.
     */
    protected void addDisease(Disease inputDisease)
    {myDiseases.add(inputDisease);
    }
}

