import java.util.Random;
import java.util.List;
import java.util.ArrayList;

/**
 * Tree class. Plant class variable. Spread/Growth rate extremely low.
 * Food type of none.
 *
 * @version 2020.02.22
 */
public class Tree extends Actor implements Plant
{
        // The age at which grass can start to breed.
    private static final int BREEDING_AGE = 100;
    // The age to which a tree can live
    private static final int MAX_AGE = 1000;
    // The likelihood of a Tree breeding.
    private static final double BREEDING_PROBABILITY = 0.0064;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    
    // Individual characteristics (instance fields).
    
    // Tree's age.
    private int age;
    //Redundant fields
    private static final int GRASS_FOOD_VALUE = 9;
    private boolean isMale;
    private ArrayList myDiseases;
    /**
     * Create a Tree. A tree can be created as a new seedling(age zero)
     * Or with a random age.Disease-free.
     * 
     * @param randomAge If true, the tree will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tree(boolean randomAge, Field field, Location location)
    {
      super(field,location);
      isMale = false;
      
      if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }
    
    /**
     * This is what the tree does.
     * Spread/Pollinate.
     * 
     * It can die of old age.
     * @param newGrass A list to return newly grown trees.
     */
    public void act(List<Actor> newTrees)
    {
        //System.out.println(this.getClass().getSimpleName()+ " tree is acting");
        incrementAge();

        if(isAlive()) 
        { 
            if(getField().getIsDay() && getField().getCurrentWeather() == "Sun")
            {pollinate(newTrees, this);}
            else if(rand.nextBoolean())
            {pollinate(newTrees, this);}
        }
        if(! isAlive())
        {
            this.setDead();
        }
    }
    
    /**
     * Check whether or not this tree can spread/pollinate at this step.
     * New tree will be planted into free adjacent locations.
     * @param newTrees A list to return newly grown trees.
     */
    private void giveBirth(List<Actor> newTrees)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tree young = new Tree(false, field, loc);
            newTrees.add(young);
        }
    }
    
    /**
     * Trees can spread/pollinate only if it has reached the breeding age.
     * @return true if the tree can pollinate, false otherwise.
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Increase the age.
     * This could result in the tree's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            //System.out.println("Grass has died of old age" + this);
            this.setDead();
        }
    }
    
    /**
     * Trees can pollinate if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    //redundant methods
    protected int getFoodValue()
    {
        return GRASS_FOOD_VALUE;
    }
    
    protected int getFoodLevel()
    {
        return -1;
    }
    
    protected List getFoodTypes()
    {
        return null;
    }
    
    protected void updateFoodLevel(int inputFood)
    {
    
    }
    
    protected boolean getIsMale()
    {
        return false;
    }
    
    protected int getMaxFoodLevel()
    {
        return -1;
    }
    
    protected ArrayList getDiseases()
    {
        return myDiseases;
    }
    
    protected void addDisease(Disease inputDisease)
    {
        myDiseases.add(inputDisease);
    }
}

