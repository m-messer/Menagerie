import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.io.IOException;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits, hares, wolves, lynxes, grass and trees.
 *
 * @version 2020.02.22 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.01;
    // The probability that a lynx will be created in any given grid position
    private static final double LYNX_CREATION_PROBABILITY = 0.01;
    // The probability that a rabbit will be created in any given grid position 
    private static final double RABBIT_CREATION_PROBABILITY = 0.19;
    // The probability that a hare will be created in any given grid position
    private static final double HARE_CREATION_PROBABILITY = 0.19;
    // The probability that grass will be created in any given grid position
    private static final double GRASS_CREATION_PROBABILITY = 0.99;
    // The probability that a tree will be created in any given grid position
    private static final double TREE_CREATION_PROBABILITY = 0.01;

    // List of Actors in the field.
    private List<Actor> Actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        // Initialise Field and Actors 
        Actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.YELLOW);
        view.setColor(Hare.class, Color.MAGENTA);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Lynx.class, Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Tree.class, new Color(44, 103, 0 ));
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) 
    {
        view.setupDataCollection();
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(1000);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each feature 
     * and fields as they're called/act.
     */
    public void simulateOneStep() 
    {
        step++;
        field.updateCalendar();
        
        //25% chance that the weather changes
        Random rand = new Random();
        if((rand.nextDouble()+0.01)<= 0.2)
        {field.generateCurrentWeather();}
        
        
        // Provide space for newborn Actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Actor> it = Actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            //Data integrity checking, as objects may have died beforehand, ie: due to hunting
            if(! actor.isAlive()) {
                it.remove();
                actor = null;
            }//Validating call for a null value. SetDead() assigns null to List position before removing.
            else if(actor != null&& actor.isAlive())
            {actor.act(newActors);}
            // Remove from Actor List.
            if(actor!= null && ! actor.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        Actors.addAll(newActors);
        //System.out.println(Actors.size());
        //Check current state of simulation field.
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        Actors.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with animal and plant classes.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    Actors.add(wolf);
                }
                else if(rand.nextDouble() <= LYNX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lynx lynx = new Lynx(true, field, location);
                    Actors.add(lynx);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    Actors.add(rabbit);
                }
                else if(rand.nextDouble() <= HARE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hare hare = new Hare(true, field, location);
                    Actors.add(hare);
                }
                
                else if(rand.nextDouble() <= TREE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tree tree = new Tree(true, field, location);
                    Actors.add(tree);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    Actors.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
