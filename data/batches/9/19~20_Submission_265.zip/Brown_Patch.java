import java.util.Arrays;
import java.util.ArrayList;
/**
 * Genetic disease grass can contract at birth.
 * @version 2020.02.22
 */
public class Brown_Patch extends Disease
{
    /**
     * Sets disease's targets/victims to "Grass".
     */
    public Brown_Patch()
    {
       super(new ArrayList(Arrays.asList("Grass")));
    
    }
}
