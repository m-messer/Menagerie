import java.util.Arrays;
import java.util.ArrayList;

/**
 * Disease Herbivores can contract:
 * when feeding on contaminated plants or meeting/nearby animals of same species.
 * @version 2020.02.22
 */
public class Myxomatosis extends Disease
{   
    /**
   * Sets disease's targets/victims to "Rabbit" and "Hare".
   */
    public Myxomatosis()
    {
       super(new ArrayList(Arrays.asList("Rabbit", "Hare")));
    
    }
}
