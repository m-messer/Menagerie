import java.util.Random;
import java.util.List;
import java.util.Iterator;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * A simple model of a Lynx.
 * Lynxes age, move, eat rabbits and hares,contract diseases and die.
 *
 * @version 2020.02.22 
 */
public class Lynx extends Actor implements Animal
{
    // Characteristics shared by all Lynxes (Animal class variables).
    
    // The age at which a Lynx can start to breed.
    private static final int BREEDING_AGE = 35;
    // The age to which a Lynx can live(5 Years).
    private static final int MAX_AGE = 650;
    // The likelihood of a Predator breeding.
    private static final double BREEDING_PROBABILITY = 0.49;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Predator can go before it has to eat again.
    private static final int LYNX_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Predator's age.
    private int age;
    // The Predator's food level, which is increased by eating.
    private int foodLevel;
    // Max amount it can eat
    private final int MAX_FOOD_LEVEL = 200;
    // Predator is male or not.
    private boolean isMale;
    // list of valid food sources for a Lynx.
    private final List foodTypes = new ArrayList(Arrays.asList("Rabbit", "Hare"));
    // list of current diseases lynx is contracting.
    private ArrayList myDiseases;
    
    /**
     * Create a Lynx. A Lynx can be created as a new born (age zero
     * and not hungry) or with a random age and food level. Born disease-free.
     * 
     * @param randomAge If true, the lynx will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lynx(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        isMale = rand.nextBoolean();
        myDiseases = new ArrayList<>();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL/4);
        }
    }
    /**
     * Create, Return a new instance of Lynx.
     * @return new instance of Lynx.
     */
    public Lynx newInstance(boolean randomAge, Field field, Location location)
    {
        return new Lynx(false, field, location);
    }
    
    /**
     * This is what the Lynx does most of the time: it hunts for
     * rabbits. In the process, it might breed,move around, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLynxes A list to return newly born Lynxes.
     */
    public void act(List<Actor> newLynxes)
    {
        incrementAge();
        incrementHunger();
        
        Location newLocation = null;
        //Chances of dying if Lynx infected.
        if(isAlive() && !myDiseases.isEmpty())
        {
           if((rand.nextDouble())<= 0.05)
           {
               this.setDead();
           }
        }
        
        if(isAlive()) {
            // Reproduce.
            reproduce(newLynxes, (Actor) this);            
            //If hungry enough, move towards a source of food if found.
          
            if(foodLevel <= (MAX_FOOD_LEVEL/2))
            {
            if(!getField().getIsDay())
                {
                    if((rand.nextDouble() <= 0.75))
                    {newLocation = findFood();}
                
                }
                else
                {newLocation = findFood();}
            }
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = findGrass(this);
            }
            else if(newLocation == null)
            {newLocation = getField().freeAdjacentLocation(getLocation());}
              // See if it was possible to move toan empty location.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the Lynx's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Lynx more hungry. This could result in the Lynx's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for rabbits and hares adjacent to the current location.
     * Only the first live rabbit/hare is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object preyActor = field.getObjectAt(where);
            //Check whether object found is of appropriate food type.
            if(preyActor!= null && foodTypes.contains(preyActor.getClass().getSimpleName()))
            {
                Actor prey = (Actor) preyActor;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel = prey.getFoodValue();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Lynx is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLynxes A list to return newly born Lynxes.
     */
    private void giveBirth(List<Actor> newLynxes)
    {
        // New Lynxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lynx young = new Lynx(false, field, loc);
            newLynxes.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Lynx can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Return valid food for Lynx.
     * @return list of food a Lynx can eat.
     */
    protected List getFoodTypes()
    {
        return foodTypes;
    }
    
    /**
     * Return how much a Lynx has eaten.
     * @return value indicating how much a Lynx has eaten.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Return how filling Lynx is as a food source.
     * @return the food value of a Lynx.
     */
    protected int getFoodValue()
    {
        return LYNX_FOOD_VALUE;
    }
    
    /**
     * Update food levels of Lynx after feeding.
     * @param value of food consumed.
     */
    protected void updateFoodLevel(int inputFood)
    {
        foodLevel += inputFood;
    }
    
    /**
     * Return if Lynx is male.
     * @return true if Lynx is male. False if female.
     */
    protected boolean getIsMale()
    {
        return isMale;
    }
    
    /**
     * Return value for Lynx's food level when full.
     * @return Lynx's max food level value.
     */
    public int getMaxFoodLevel()
    {return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return arraylist of diseases Lynx currently contracts.
     * @return arraylist of Lynx's current diseases.
     */
    protected ArrayList getDiseases()
    {return myDiseases;
    }
    
    /**
     * Add disease to Lynx. Lynx contracts a disease.
     * @param input disease type to Lynx's disease list.
     */
    protected void addDisease(Disease inputDisease)
    {myDiseases.add(inputDisease);
    }
}
