import java.util.List;
import java.util.Iterator;
import java.lang.reflect.*;
import java.util.Random;

/**
 * Animal Class. Defines how animals gender check for breeding purposes as well as reproduce.
 * How they hunt for food
 * In the case of scarcity of food look for grass or empty locations to move to.
 *
 * @version 2020.02.22 
 */
public interface Animal
{
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Breeding act can result in STI's.
     * @param newAnimals A list to return newly born Animals.
     * @param myself as Actor to reference animal carrying out methods.
     */
    default public void reproduce(List<Actor> newAnimals, Actor myself)
    {   //Only breed if animal to breed with is of opposite gender.
        if(partnerCheck(myself))
        {
            // New Animals are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = myself.getField();
            List<Location> free = field.getFreeAdjacentLocations(myself.getLocation());
            int births = myself.breed();
            //Random chance of getting an STI upon breeding
            Random rand = new Random();
           if(rand.nextDouble()<= 0.01)
            {
                Syphilis newSyp = new Syphilis();
                myself.addDisease(newSyp);
            }
           // Create and place new instance (can be more than one) of animal in free adjacent locations.
           for(int b = 0; b < births && free.size() > 0; b++) 
            {
                Location loc = free.remove(0);
                try
                {   // reflect contructor: Access second constructors in sub class with the specified parameters.
                    // Create new instance and add to Actor list directly from Animal class with values stated.
                    Actor young = myself.getClass().getConstructor(boolean.class, Field.class, Location.class).newInstance(false, field, loc);
                    newAnimals.add(young);
                }
                catch(Exception e)
                {
                    System.out.println("Something has gone wrong");
                }
            }
        }
    }
    
    /**
     * Return location of grass to move to and set as current location.
     * @return location of adjcacent grass.
     */
    default public Location findGrass(Actor myself)
    {
        Field field = myself.getField();
        // Get a list of adjacent locations.
        List<Location> adjacent = field.adjacentLocations(myself.getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {   // Iterate through list, Move to if of type "Grass".
            // Set grass at that location to dead.
            Location where = it.next();
            Object grassObject = field.getObjectAt(where);
            
            if(grassObject!= null && grassObject.getClass().getSimpleName() == "Grass")
            {
                Actor grass = (Actor) grassObject;
                if(grass.isAlive())
                {
                grass.setDead();
                return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Return whether breeding can occur between both instances of animal.
     * @return if both animals are apt for breeding.
     */
    default public boolean partnerCheck(Actor myself)
    {   // Check if animal to breed with is of opposite gender.
        //Retrieve and compare isMale values from both animals.
        Field field = myself.getField();
        boolean validBreedingPartner = false;
        // Get a list of adjacent locations.
        List<Location> partnerLocations = field.adjacentLocations(myself.getLocation());
        Iterator<Location> partnerIterator = partnerLocations.iterator();
        while(partnerIterator.hasNext())
        {   // Iterate through list
            Location tempLocation = partnerIterator.next();
            Actor actorAtLocation = (Actor) field.getObjectAt(tempLocation);
            if(actorAtLocation != null)
            { //Compare isMale values from object at adjacent location and Actor myself.
                if(actorAtLocation.getIsMale() != myself.getIsMale() && myself.getClass()==actorAtLocation.getClass())
                {
                    validBreedingPartner = true;
                }
            }
            
        }
        return validBreedingPartner;
    }
}
