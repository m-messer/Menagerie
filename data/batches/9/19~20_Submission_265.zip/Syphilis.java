import java.util.Arrays;
import java.util.ArrayList;
/**
 * STI Wolf and Lynx can contract when breeding
 * @version 2020.02.22
 */
public class Syphilis extends Disease
{
     /**
   * Sets disease's targets/victims to "Wolf" and "Lynx".
   */
    public Syphilis()
    {
        super(new ArrayList(Arrays.asList("Wolf", "Lynx")));
    
    }
}
