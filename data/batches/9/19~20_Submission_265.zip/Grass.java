import java.util.Random;
import java.util.List;
import java.util.ArrayList;

/**
 * Grass class. Plant class variable. Spread/Growth rate extremely high.
 * Main food source for rabbits and hares.
 * Pollinates at high rates and can contract/inherit diseases.
 *
 * @version 2020.02.22
 */
public class Grass extends Actor implements Plant
{
    // Characteristics shared by all grass (Plant class variables).
    
    // The age at which grass can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a grass can live(40 days).
    private static final int MAX_AGE = 10;
    // The likelihood of a Grass breeding.
    private static final double BREEDING_PROBABILITY = 0.72;
    // The maximum number of pollinates.
    private static final int MAX_LITTER_SIZE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // How filling grass is as a food source.
    private static final int GRASS_FOOD_VALUE = 9;
     
   
    
    // Individual characteristics (instance fields).
    
    // Grass age
    private int age;
    // list of current diseases grass is contracting.
    private ArrayList myDiseases;
    //Redundant field
    private boolean isMale;
    /**
     * Create a grass. A grass can be created as a new seedling(age zero)
     * Or with a random age.Can be grown disease-free or already infected
     * 
     * @param randomAge If true, the grass will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        isMale = false;
        myDiseases = new ArrayList<>();
        //Chance the grass will be have a disease
        if((rand.nextDouble()) <= 0.01)
        {
          Brown_Patch brown = new Brown_Patch();
          myDiseases.add(brown);
          //System.out.println("Grass has got a disease"+ this.getDiseases());
        }
        
        if(randomAge) 
        { 
            age = rand.nextInt(MAX_AGE);
        }
        else 
        {
            age = 0;
        }
    }
    
    /**
     * This is what the grass does.
     * Spread/Pollinate.
     * 
     * It can die of old age or disease.
     * @param newGrass A list to return newly sprouted grass.
     */
    public void act(List<Actor> newGrass)
    {
        //System.out.println(this.getClass().getSimpleName()+ " Grass is acting");
        incrementAge();

        if(isAlive()) {
            pollinate(newGrass, this);            
        }
        //If the grass is sick it may die
        if(!myDiseases.isEmpty())
        {
            if((rand.nextDouble()+0.01) <= 0.1)
            {
                //System.out.println("Grass has died of disease"+ this.getDiseases());
                this.setDead();
            }
        }
        if(! isAlive())
        {
            this.setDead();
        }
    }
    
    /**
     * Check whether or not this grass can spread/pollinate at this step.
     * New grass will be planted into free adjacent locations.
     * @param newGrass A list to return newly sprouted grass.
     */
    private void giveBirth(List<Actor> newGrass)
    {
        // New grass are planted into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
    
    /**
     * Grass can spread/pollinate only if it has reached the breeding age.
     * @return true if the grass can pollinate, false otherwise.
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Increase the age.
     * This could result in the grass's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            //System.out.println("Grass has died of old age" + this);
            this.setDead();
        }
    }
    
    /**
     * grass can pollinate if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Return how filling grass is as a food source.
     * @return the food value of a grass.
     */
    protected int getFoodValue()
    {
        return GRASS_FOOD_VALUE;
    }
    
    //redundant methods
    protected int getFoodLevel()
    {
        return -1;
    }
    
    protected List getFoodTypes()
    {
        return null;
    }
    
    protected void updateFoodLevel(int inputFood)
    {
        
    }
    
    protected boolean getIsMale()
    {
        return false;
    }
    
    protected int getMaxFoodLevel()
    {
        return -1;
    }
    
    protected ArrayList getDiseases()
    {
        return myDiseases;
    }
    
    protected void addDisease(Disease inputDisease)
    {
        myDiseases.add(inputDisease);
    }
}
