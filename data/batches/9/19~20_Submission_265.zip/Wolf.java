import java.util.Random;
import java.util.List;
import java.util.Iterator;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * A simple model of a Wolf.
 * Wolves age, move, eat rabbits, contract diseases and die.
 *
 * @version 2020.02.22 
 */
public class Wolf extends Actor implements Animal
{
    // Characteristics shared by all Wolves (Animal class variables).
    
    // The age at which a Wolf can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Wolf can live(5 Years).
    private static final int MAX_AGE = 420;
    // The likelihood of a Predator breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // How filling a rabbit is as a food source.
    private static final int WOLF_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Predator's age.
    private int age;
    // The Predator's food level, which is increased by eating.
    private int foodLevel;
    // Max amount it can eat
    private final int MAX_FOOD_LEVEL = 200;
    // Predator is male or not.
    private boolean isMale;
    // list of valid food sources for a Wolf.
    private final List foodTypes = new ArrayList(Arrays.asList("Rabbit", "Hare"));
    // list of current diseases wolf is contracting.
    private ArrayList myDiseases;
    
    /**
     * Create a Wolf. A Wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level. Born disease-free.
     * 
     * @param randomAge If true, the Wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        isMale = rand.nextBoolean();
        myDiseases = new ArrayList<>();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL);
        }
        else {
            age = 0;
            foodLevel = rand.nextInt(MAX_FOOD_LEVEL/4);
        }
    }
    
    /**
     * Create, Return a new instance of Wolf.
     * @return new instance of Wolf.
     */
    public Wolf newInstance(boolean randomAge, Field field, Location location)
    {
        return new Wolf(false, field, location);
    }
    
    /**
     * This is what the Wolf does most of the time: it hunts for
     * rabbits. In the process, it might breed, move around, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWolfes A list to return newly born Wolves.
     */
    public void act(List<Actor> newWolves)
    {
        incrementAge();
        incrementHunger();
        
        Location newLocation = null;
        //Chances of dying if Lynx infected.
        if(isAlive() && !myDiseases.isEmpty())
        {
           if((rand.nextDouble())<= 0.05)
           {
               this.setDead();
           }
        }
        
        if(isAlive()) {
           //Reproduce
            reproduce(newWolves, (Actor) this);            
           // If hungry enough, move towards a source of food if found.
           if(foodLevel <= (MAX_FOOD_LEVEL/2))
            {
            if(!getField().getIsDay())
                {
                    if((rand.nextDouble() <= 0.75))
                    {newLocation = findFood();}
                
                }
                else
                {newLocation = findFood();}
            }
           if(newLocation == null) { 
                // No food found - try to move to a location with grass
                newLocation = findGrass(this);
            }
            else if(newLocation == null)
            {newLocation = getField().freeAdjacentLocation(getLocation());}
            // See if it was possible to move toan empty location.
           if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the Wolf's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Wolf more hungry. This could result in the Wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for rabbits and hares adjacent to the current location.
     * Only the first live rabbit/hare is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object preyActor = field.getObjectAt(where);
            //Check whether object found is of appropriate food type.
            if(preyActor!= null && foodTypes.contains(preyActor.getClass().getSimpleName())) 
            {
                Actor prey = (Actor) preyActor;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel = prey.getFoodValue();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born Wolves.
     */
    private void giveBirth(List<Actor> newWolves)
    {
        // New Wolfes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, field, loc);
            newWolves.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Wolf can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Return valid food for wolf.
     * @return list of food a wolf can eat.
     */
    protected List getFoodTypes()
    {
        return foodTypes;
    }
    
    /**
     * Return how much a wolf has eaten.
     * @return value indicating how much a wolf has eaten.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Return how filling wolf is as a food source.
     * @return the food value of a wolf.
     */
    protected int getFoodValue()
    {
        return WOLF_FOOD_VALUE;
    }
    
    /**
     * Update food levels of wolf after feeding.
     * @param value of food consumed.
     */
    protected void updateFoodLevel(int inputFood)
    {
        foodLevel += inputFood;
    }
    
    /**
     * Return if wolf is male.
     * @return true if wolf is male. False if female.
     */
    protected boolean getIsMale()
    {
        return isMale;
    }
    
    /**
     * Return value for wolf's food level when full.
     * @return wolf's max food level value.
     */
    public int getMaxFoodLevel()
    {return MAX_FOOD_LEVEL;
    }
    
    /**
     * Return arraylist of diseases wolf currently contracts.
     * @return arraylist of wolf's current diseases.
     */
    protected ArrayList getDiseases()
    {return myDiseases;
    }
    
    /**
     * Add disease to wolf. Wolf contracts a disease.
     * @param input disease type to wolf's disease list.
     */
    protected void addDisease(Disease inputDisease)
    {myDiseases.add(inputDisease);
    }
}
