import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
/**
 * A simple data collection class for writing to a csv
 *
 * @version 1.2
 */
public class DataCollector
{
    // instance variables - replace the example below with your own
    //private File outputCsv;
    private FileWriter csvWriter;
    private List<List<String>> rows;
    private boolean setupComplete;
    
    public DataCollector() throws IOException
    {
    
    csvWriter = new FileWriter("OutputData.csv");
    setupComplete = false;
    
    }
    

    public void setupDataCollector(ArrayList<String> inputClassTypes) throws IOException
    {
        
        for(String classType: inputClassTypes)
        {
            csvWriter.append(classType);
            csvWriter.append(",");
        }
        csvWriter.append("\n");
        csvWriter.append("\n");
        csvWriter.flush();
        
        setupComplete = true;
        
    }
    
    public void updateDataCollector(ArrayList<Integer> inputData) throws IOException
    {
        if(setupComplete)
        {
        
        for(int popNumbers: inputData)
        {
            csvWriter.append(popNumbers+"");
            csvWriter.append(",");
        }
        csvWriter.append("\n");
        csvWriter.flush();
        }
    }
}
