import java.util.Random;
/**
 * This method tells the other classes if there is a storm or not.
 *
 * @version (a version number or a date)
 */
public class Weather
{
    

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
       
    }
    /**
     * chekWeather returns a true boolean if the step number matches#
     * a randomly generated number and if it does that means that there is
     * a storm so no plants will grow in the Plant Class.
     */
    
    public static boolean checkWeather()
    {
     boolean storm = false;
        int randomNumber;
      randomNumber = (int)(Math.random() * 8000 + 1);
      
     int secondRandom = Simulator.getStepNumber();
     if(randomNumber == secondRandom)
     {
        storm = true;
        
        }
     return storm; 
    
    }
    
}
