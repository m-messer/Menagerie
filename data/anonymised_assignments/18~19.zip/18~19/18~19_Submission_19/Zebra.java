import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.time.*;
/**
 * A simple model of a Zebra.
 * Zebras are able to increment in age, move, eat grass, breed, and die.
 * The behavior of zebras is also affected by time and weather.
 *
 * @version 2016.02.29 (2)
 */
public class Zebra extends Animal
{
    // Characteristics shared by all Zebras (class variables).

    // The age at which a Zebra can start to breed.
    private static final int BREEDING_AGE = 10;
    // The max age to which a Zebra can live.
    private static final int MAX_AGE = 280;
    // The likelihood of a Zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.03;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The number of steps it can travel before it dies.
    private static final int GRASS_FOOD_VALUE = 400;
    // The amount of grass a zebra can eat at once.
    private static double eatenSize = 0.30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Zebra's age.
    private int age;
    // THe Zebra's food level that is increased by eating grass.
    private int foodLevel;
    // The gender of each zebra.
    private int gender;
    // A variable to show the current Weather.
    private Weather weatherNow;

    /**
     * Create a new Zebra. A Zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE); 
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
        gender = rand.nextInt(2); // creates a random counter for gender
        // from 0-2 so 0 inclusive and 2 exclusive.
        // 0 = male
        // 1 = female
        weatherNow = new Weather();
    }
    
     /**
     * Returns the gender of the zebra.
     * @return the gender of the zebra.
     */
    public int getGender()
    {
        return gender;
    }
    
    /**
     * This is what the Zebra does most of the time - it is the prey so it
     * runs around escaping from its predator. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born Zebras.
     */
    public void act(List<Animal> newZebras)
    {
        LocalTime currentTime = LocalTime.now();
        LocalTime earlyTime = LocalTime.parse("00:00:00");   // setting the limit for the two times
        LocalTime lateTime = LocalTime.parse("18:00:00");
        int currentZebra = getGender();
        if ((currentTime.isAfter(earlyTime)) && (currentTime.isBefore(lateTime)) && (weatherNow.getWeather() != "rainy")){
            incrementAge();
            incrementHunger(); 
            // these two methods are executed when it is between the times as listed above.
            if(isAlive()) {
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                int breedTookPlace = 0; //checker to keep giving birth under control
                
                while((breedTookPlace == 0) && (it.hasNext())) {    //stops the iterator after 1 zebra has given 1 birth            
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Zebra) {                    
                        Zebra zebra = (Zebra) animal;
                        if(zebra.isAlive()) {                        
                            if ((zebra.getGender() != currentZebra)){ // checking if the current and new are the same gender
                                giveBirth(newZebras);
                                breedTookPlace = 1;  // makes sure one animal can only breed with one animal at that step.
                                
                            }
                            
                        }
                    }
                }                      
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        else{
            incrementAge();
            //newLocation = findFood();
            if(isAlive()) {
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                int breedTookPlace = 0; 
                
                while((breedTookPlace == 0) && (it.hasNext())) {              
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Zebra) {                    
                        Zebra zebra = (Zebra) animal;
                        if(zebra.isAlive()) {                        
                            if ((zebra.getGender() != currentZebra)){ 
                                giveBirth(newZebras);
                                breedTookPlace = 1; 
                            }
                            
                        }
                    }
                }
            }
        }
        
    }

     /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    // when the current size is less that what the eaten size of the zebra is.
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
     /** 
     * Makes more Zebra more hungry. This could result in the Zebra's death
     * if it does not find any grass to eat.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Increase the age.
     * This could result in the Zebra's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Zebra is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newZebras A list to return newly born Zebras.
     */
    private void giveBirth(List<Animal> newZebras)
    {
        // New Zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Zebra Zebrayoung = new Zebra(false, field, loc);
            newZebras.add(Zebrayoung);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Zebra can breed if it has reached the breeding age.
     * @return true if the Zebra can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
