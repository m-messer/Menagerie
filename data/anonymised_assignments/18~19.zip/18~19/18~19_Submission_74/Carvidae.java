import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple Tree class
 *
 * @version 2019.02.22
 */
public abstract class Carvidae extends Prey 
{
	//You cannot actually create a Carvidae but as super is called in sub class you can still group construction 
	//similarities at each level of inheritance
    public Carvidae(boolean randomAge, Field field, Location location)
    {
    	super(randomAge, field, location);
		//foodLevel = 50;
    }
    
    /**
     * This is what the Carvidae does most of the time - it gives birth based on a few 
     * conditions. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born Carvidae.
     */
	 public void act(List<LivingThings> newPrey)
	    {
	        incrementAge();
	        incrementHunger();
	        if(isAlive()) 
	        {
	            giveBirth(newPrey);            
	            // Move towards a source of food if found.
	            Location newLocation = findFood();
	            if(newLocation == null) { 
	                // No food found - try to move to a free location.
	                newLocation = getField().freeAdjacentLocation(getLocation());
	            }
	            // See if it was possible to move.
	            if(newLocation != null) 
	            {
	                setLocation(newLocation);
	            }
	            else {
	                // Overcrowding.
	                setDead();
	            }
	        }
	    }
	/**
	 * This is how a Carvidae searches for food by searching
	 * adjacent locations for the correct object type that is 
	 * its food, grass.
	 * @return The location of the found food, or null if no food is found
	 */
    protected Location findFood()
    {
     Field field = getField();
     List<Location> adjacent = field.adjacentLocations(getLocation());
     Iterator<Location> it = adjacent.iterator();
     while(it.hasNext()) 
     {
         Location where = it.next();
         Object livingThing = field.getObjectAt(where);
         if(livingThing instanceof Grass) 
         {
        	 Grass grass = (Grass) livingThing;
        		if(grass.isAlive())
            	{
        			addFood(grass.getFoodValue());
            		grass.setDead();
            		//System.out.println("Grass has just been eaten by" +this.getClass());
            		return where;
            	}

         }
         
     }
     return null;
    }
 
}

