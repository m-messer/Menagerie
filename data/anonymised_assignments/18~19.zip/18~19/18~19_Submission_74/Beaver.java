import java.util.Iterator;
import java.util.List;
import java.util.Random;


/**
 * A simple Beaver class
 *
 * @version 2019.02.22
 */
public class Beaver extends Prey
{
	// Characteristics shared by all beaver (class variables).

    // The age at which a beaver can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a beaver can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a beaver breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    // The maximum number of births for beavers
    private static final int MAX_LITTER_SIZE = 6;
    //The amount of food a beaver provides when eaten
    private static final int BEAVER_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    //private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The beaver's age.
    private int age;
    private int foodLevel;
    private boolean isMale;
    
    /**
     * Create a Beaver. A Beaver may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the tree will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Beaver(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        foodLevel = 75;
        
    }

    /**
	 * This is how a Beaver searches for food by searching
	 * adjacent locations for the correct object type that is 
	 * its food, trees.
	 * @return The location of the found food, or null if no food is found
	 */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object livingThing = field.getObjectAt(where);
            if(livingThing instanceof Tree && foodLevel < 50) //stop them eating so frequently
            {
                Tree tree = (Tree) livingThing; 
                if(tree.isAlive()) //If livingThing. Why not just livingThing.setdead():
                { 
                    tree.setDead();
                    foodLevel += tree.getFoodValue();
                    return where;
                }

            }
        }
        return null;
    } 
    
    /**
     * This is what the Beaver does most of the time - it gives birth based on a few 
     * conditions. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born Beaver.
     */
    public void act(List<LivingThings> newPrey)
    {
    	incrementAge();
        incrementHunger();
        if(isAlive()) 
        {
            giveBirth(newPrey);            
            Location newLocation = findFood();
            // Move towards a source of food if found.
            if(!field.getIsDay())
            {
            	
            
            	if(newLocation == null) 
            	{ 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            	}
                // See if it was possible to move.
            	if(newLocation != null) 
            	{
                setLocation(newLocation);
            	}
            	else 	
            	{
                // Overcrowding.
                setDead();
            	}
            }
        }
    }

     protected int getFoodLevel()
	 {return foodLevel;}
	 
	 protected void addFood(int foodInput)
	 {foodLevel += foodInput;}
	 
     protected int getFoodValue()
     {return BEAVER_FOOD_VALUE;}
     
     protected boolean getIsMale()
	 {return isMale;}
	 
	 protected void setIsMale(boolean male)
	 {isMale = male;}
	 
     protected void setAge(int ageInput)
	 {this.age = ageInput;}
	
	 protected int getAge()
	 {return age;}

	 protected int getBreedingAge()
	 {return BREEDING_AGE;}

	 protected int getMaxLitterSize()
	 {return MAX_LITTER_SIZE;}
	    
	 protected double getBreedingProbability()
	 {return BREEDING_PROBABILITY;}
	    
	 protected int getMaxAge()
	 {return MAX_AGE;}
}
