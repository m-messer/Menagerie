import java.util.List;
import java.util.Random;

/**
 * A simple Lynx class
 *
 * @version 2019.02.22
 */
public class Lynx extends Predator 
{
	
	 // The age at which a lynx can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a lynx can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lynx breeding.
    private static final double BREEDING_PROBABILITY = 0.33;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a lynx can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The lynx's age.
    private int age;
    // The lynx's food level, which is increased by eating rabbits.
    private int foodLevel;
    private boolean isMale;
	
	
	
    /**
     * Create a lynx. A lynx may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the tree will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
	public Lynx(boolean randomAge, Field field, Location location) 
	{
		super(randomAge, field, location);
		foodLevel = 25;
	}
	
	 
	 protected int getFoodLevel()
	 {return foodLevel;}
	 
	 protected void addFood(int foodInput)
	 {foodLevel += foodInput;}
	 
	 protected boolean getIsMale()
	 {return isMale;}
	 
	 protected void setIsMale(boolean male)
	 {isMale = male;}
	 
	 protected void setAge(int ageInput)
	 {this.age = ageInput;}
	 
	 protected int getAge()
	 {return age;}
	
	 protected int getBreedingAge()
	 {return BREEDING_AGE;}

	 protected int getMaxLitterSize()
	 {return MAX_LITTER_SIZE;}
	    
	 protected double getBreedingProbability()
	 {return BREEDING_PROBABILITY;}
	    
	 protected int getMaxAge()
	 {return MAX_AGE;}
}
