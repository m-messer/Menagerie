import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing mice, owls, deer, bears and cougars.
 *
 * @version 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The current day of the simulation.
    private int day;
    // Whether it is currently night or day in the simulation.
    private boolean night;
    // The current weather of the simulation.
    private String weather;
    
    // A graphical view of the simulation.
    private SimulatorView view;
    // A population generator that creates the animals in the simulation.
    private PopulationGenerator generator;
    // A random number generator to generate the weather.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        // Create a field to store the animals in the simulation.
        field = new Field(depth, width);

        // Create a population generator to populate the field with animals.
        generator = new PopulationGenerator();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        generator.setColors(view);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (2000 steps).
     */
    public void runLongSimulation()
    {
        simulate(2000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();

            if(step % 4 == 0){
                // Increment the day every four steps.
                day++;
                
                // Generate the weather for each day.
                weather = generateWeather();
            }

            // Determine if it is currently night or day.
            if(step % 4 == 1 || step % 4 ==2){
                night = false;
            }
            else{
                night = true;
            }

            delay(50); 
        }
    }

    /**
     * Run the simulation from its current state for the given number of days.
     * Stop before the given number of days if it ceases to be viable.
     * @param days The number of days to run for.
     */
    public void simulateDays(int days)
    {
        int numSteps = days * 4;    // A day consists of four steps.
        simulate(numSteps);
    }

    /**
     * Run the simulation from its current state for a single step.
     */
    public void simulateOneStep()
    {
        step++;
        generator.simulateAct(night, weather);        
        view.showStatus(step, day, weather, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        day = 1;
        night = false;
        weather = "sunny";
        generator.clearAnimals();
        generator.populate(field);

        // Show the starting state in the view.
        view.showStatus(step, day, weather, field);
    }

    /**
     * Generate the weather.
     * @return the weather generated.
     */
    private String generateWeather()
    {
        Double probability = rand.nextDouble();
        
        if(probability < 0.4){
            weather = "sunny";
        }
        else if(0.4 <= probability && probability < 0.6){
            weather = "rain";
        }
        else if(0.6 <= probability && probability < 0.7){
            weather = "thunderstorm";
        }
        else if(0.7 <= probability && probability < 0.9){
            weather = "fog";
        }
        else{
            weather = "snow";
        }
        
        return weather;
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
