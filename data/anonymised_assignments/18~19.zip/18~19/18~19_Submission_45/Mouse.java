import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A Mouse is an Animal. It ages each step, and since it is
 * nocturnal, it moves and gives birth only during the night.
 * A Mouse can die from old age, disease, or if it struck by
 * lightning during a thunderstorm. A Mouse can mate with
 * adjacent mice, if they are of the opposite sex. A Mouse
 * can be born infected with disease, or may be infected by
 * adjacent infected mice.
 *
 * @version 2019.02.20
 */
public class Mouse extends Animal
{
    // The age to which a mouse can live.
    private static int max_age = 500;
    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 55;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.40;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The likelihood of a mouse being infected by disease at birth.
    private static final double INFECTION_AT_BIRTH_PROBABILITY = 0.0000008;
    // The likelihood of a mouse being infected by disease from another diseased mouse.
    private static final double CONTAGIOUS_INFECTION_PROBABILITY = 0.00000005;

    /**
     * Create a mouse. A mouse can be created as a new born (age zero
     * and not hungry) or with a random age and food level. A mouse
     * can be born infected with disease.
     * 
     * @param randomAge If true, the mouse will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        // There is a chance the new mouse is infected.
        if(rand.nextDouble() <= INFECTION_AT_BIRTH_PROBABILITY){
            infect();
        }
    }

    /**
     * Get the mouse's breeding age.
     * @return the mouse's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * Get the mouse's maximum age.
     * @return the mouse's maximum age.
     */
    public int getMaxAge()
    {
        return max_age;
    }
    
    /**
     * Get the mouse's maximum litter size.
     * @return the mouse's maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Get the mouse's breeding probability.
     * @return the mouse's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Check whether there is a compatible mate in an adjacent location.
     * @return True if the adjacent mouse is of the oppposite gender and
     * can breed, and False otherwise.
     */
    public boolean adjCompatibleMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location location = it.next();
            Object animal = field.getObjectAt(location);
            if(animal instanceof Mouse){
                Mouse mouse = (Mouse) animal;
                if(mouse.isFemale() != isFemale() && mouse.canBreed()){
                    return true;
                }
            }            
        }
        return false;
    }

    /**
     * The mouse might breed, die of hunger, die by
     * being eaten, die of old age, die from disease, 
     * or die by lightning strike.
     * @param newMice A list to return newly born mice.
     * @param isNight A boolean to check if it is currently night in the simulation.
     * @param weather A string that states the current weather in the simulation.
     */
    public void act(List<Animal> newMouse, boolean isNight, String weather)
    {
        incrementAge();       
        if(isAlive()) {
            if(weather.equals("thunderstorm")){
                if(rand.nextDouble()<= LIGHTNING_DEATH){
                    setDead();  // Kill the mouse if it is struck by lightning.
                }
                else{
                    defaultAct(newMouse, isNight);
                }
            }  
            else{
                defaultAct(newMouse, isNight);
            }
        }
    }

    /**
     * This is the default action of the Mouse if it is night.
     * It may give birth, get infected by adjacent infected
     * mice, and move around.
     * @param newMice A list to return newly born mice.
     * @param isNight Whether or not it is night.
     */
    private void defaultAct(List<Animal> newMice, boolean isNight)
    {
        if(isNight){   // The mouse sleeps during the day.
            giveBirth(newMice);
            getInfected();
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Infect the mouse with disease. It will have only
     * two more days to live.
     */
    public void infect()
    {
        super.infect();
        max_age = getAge() + 8;    
    }

    /**
     * If there is an infected mouse in an adjacent location, 
     * this mouse has a chance of getting infected as well.
     */
    private void getInfected()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location location = it.next();
            Object animal = field.getObjectAt(location);
            if(animal instanceof Mouse){
                Mouse mouse = (Mouse) animal;
                if(mouse.isInfected() && !isInfected()){
                    if(rand.nextDouble() <= CONTAGIOUS_INFECTION_PROBABILITY){
                        infect();
                    }
                }
            }            
        }
    }

    /**
     * Create a newborn mouse.
     * @param field The field of the new mouse.
     * @param loc The location in the field of the new mouse.
     * @return The new mouse.
     */
    public Mouse createYoung(Field field, Location loc)
    {
        Mouse young = new Mouse(false, field, loc);
        return young;
    }

}
