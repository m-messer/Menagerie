import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * This class creates the population of animals and sets their
 * colors in the field.
 *
 * @version 2019.02.20
 */
public class PopulationGenerator
{
    // Creation probabilities:
    // The probability that an owl will be created in any given grid position.
    private static final double OWL_CREATION_PROBABILITY = 0.04;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.05;    
    // The probability that an cougar will be created in any given grid position.
    private static final double COUGAR_CREATION_PROBABILITY = 0.02;
    // The probability that an bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.02;
    // The probability that an deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.15;

    // List of animals in the field.
    private List<Animal> animals;

    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create the list of animals.
     */
    public PopulationGenerator()
    {
        animals = new ArrayList<>();
    }

    /**
     * Iterate over the whole field updating the state of each
     * animal by making them act.
     * @param night Whether or not it is night in the simulation.
     * @param weather The weather in the simulation.
     */
    public void simulateAct(boolean night, String weather)
    {
        // Provide space for new animals.
        List<Animal> newAnimals = new ArrayList<>(); 
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, night, weather);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the new animals to the main lists.
        animals.addAll(newAnimals);
    }

    /**
     * Set the colours of each individual animal.
     * @param view The simulator view to 
     */
    public void setColors(SimulatorView view)
    {
        view.setColor(Cougar.class, Color.BLACK);
        view.setColor(Mouse.class, Color.ORANGE);
        view.setColor(Owl.class, Color.CYAN);
        view.setColor(Deer.class, Color.RED);
        view.setColor(Bear.class, Color.PINK);
    }

    /**
     * Clear the list of animals.
     */
    public void clearAnimals()
    {
        animals.clear();
    }

    /**
     * Randomly populate the field with animals.
     */
    public void populate(Field field)
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= OWL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Owl owl = new Owl(true, field, location);
                    animals.add(owl);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    animals.add(deer);
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, field, location);
                    animals.add(bear);
                }
                else if(rand.nextDouble() <= COUGAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cougar cougar = new Cougar(true, field, location);
                    animals.add(cougar);
                }
                // else leave the location empty.
            }
        }
    }
}
