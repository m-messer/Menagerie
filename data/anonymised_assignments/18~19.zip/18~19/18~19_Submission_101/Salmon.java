import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Salmon.
 * Salmon age, move, breed and die.
 * Salmon have genders.
 * They can spawn and move anywhere in the ocean.
 * Salmon eat: Seaweed and Plankton.
 *
 * @version 2019.02.19
 *
 * based on version 2016.02.29
 *
 */

public class Salmon extends Animal
{
    // The age at which a Salmon can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a Salmon can live.
    private static final int MAX_AGE = 40;

    // The likelihood of a Salmon breeding.
    private static final double BREEDING_PROBABILITY = 0.7;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single Salmon. In effect, this is the
    // number of steps a Salmon can go before it has to eat again.
    private static final int FOOD_VALUE = 80;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The ratio of male and female Salmon.
    private static final double FEMALE_RATIO = 0.5;

    // The Salmon's age.
    private int age;
    // The Salmon's food level, which is increased by eating organisms.
    private int foodLevel;

    // If the Salmon is male or female.
    private boolean isFemale;

    /**
     * Create a new Salmon. A Salmon may be created with age
     * zero (a new born) or with a random age. The gender of
     * the Salmon is determined here.
     *
     * @param randomAge If true, the Salmon will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Salmon(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        foodLevel = FOOD_VALUE;

        if(rand.nextDouble() <= FEMALE_RATIO) {
            isFemale = true;
        }
        else{
            isFemale = false;
        }

    }
    
    /**
     * This is what the Salmon does most of the time - it swims
     * around. Sometimes it will breed or die of old age.
     * @param newSalmon A list to return newly born rabbits.
     */
    public void act(List<Organism> newSalmon)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSalmon);
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                if ( newLocation.getRow() >= 0.1 * field.getDepth()) {
                    setLocation(newLocation);
                }
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Salmon's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Salmon more hungry. This could result in the Salmon's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
            foodLevel =0;
        }
    }

    /**
     * Look for organisms adjacent to the current location.
     * Only the first live organism is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if(foodLevel>= FOOD_VALUE *0.6){
            return null;
        }


        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Seaweed){
                Organism fish = (Organism) organism;
                if(fish.isAlive()){
                    fish.setDead();
                    return where;
                }

            }
        }
        return null;
    }


    /**
     * Check whether or not this Salmon is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSalmon A list to return newly born rabbits.
     */
    private void giveBirth(List<Organism> newSalmon)
    {
        // New Salmon are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (loc.getRow() >= 0.1 * field.getDepth()) {
                Salmon young = new Salmon(false, field, loc);
                newSalmon.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {


        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Mackerel can breed if it has reached the breeding age.
     * Ensures only female can breed and checks for an adjacent
     * male to reproduce.
     * @return true if the Mackerel can breed, false otherwise.
     */
    private boolean canBreed()
    {
        if (!isFemale) return false;

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        boolean hasPartner = false;
        while(it.hasNext()) {
            Location where = it.next();
            Object neighbour = field.getObjectAt(where);
            if (neighbour != null && neighbour.getClass() == this.getClass()){
                Salmon n = (Salmon) neighbour;
                hasPartner = (isFemale != n.getIfFemale());
            }
        }

        return age >= BREEDING_AGE && hasPartner;
    }

    /**
     * Return if the Salmon is female.
     * @return true if the Salmon is female.
     */
    private boolean getIfFemale(){
        return isFemale;
    }

}
