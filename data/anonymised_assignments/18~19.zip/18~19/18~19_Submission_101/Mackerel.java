import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 /**
 * A simple model of a Mackerel.
 * Mackerel age, move, breed, eat and die.
 * Mackerel have genders.
 * They can spawn and move anywhere in the ocean.
 * Bass eat: Plankton, Seaweed.
 *
 * @version 2019.02.19
 *
 * based on version 2016.02.29
 *
 */
public class Mackerel extends Animal
{
    // The age at which a Mackerel can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a Mackerel can live.
    private static final int MAX_AGE = 35;

    // The likelihood of a fish breeding.
    private static final double BREEDING_PROBABILITY = 0.7;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a organism. In effect, this is the
    // number of steps a Bass can go before it has to eat again.
    private static final int FOOD_VALUE = 80;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // A ratio between male and female Mackerel
    private static final double FEMALE_RATIO = 0.5;

    // The Mackerel's age.
    private int age;
    // The Mackerel's food level, which is increased by eating organisms.
    private int foodLevel;

    // Whether a Mackerel is male or female.
    private boolean isFemale;

    /**
     * Create a new Mackerel. A Mackerel may be created with age
     * zero (a new born) or with a random age. The Mackerels's
     * gender is determined here.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mackerel(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        foodLevel = FOOD_VALUE;

        // handles gender
        if(rand.nextDouble() <= FEMALE_RATIO) {
            isFemale = true;
        }
        else{
            isFemale = false;
        }

    }
    
    /**
     * This is what the Mackerel does most of the time - it swims
     * around. Sometimes it will breed or die of old age.
     * @param newMackerel A list to return newly born Mackerel.
     */
    public void act(List<Organism> newMackerel)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newMackerel);
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                if ( newLocation.getRow() >= 0.1 * field.getDepth()) {
                    setLocation(newLocation);
                }
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Mackerel's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Mackerel more hungry. This could result in the Mackerel's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
            foodLevel =0;
        }
    }

    /**
     * Look for organisms adjacent to the current location.
     * Only the first live organism is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if(foodLevel>= FOOD_VALUE *0.6){
            return null;
        }


        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Seaweed || organism instanceof Plankton){
                //if(organism instanceof Mackerel){
                Organism fish = (Organism) organism;
                if(fish.isAlive()){
                    fish.setDead();
                    return where;
                }

            }
        }
        return null;
    }


    /**
     * Check whether or not this Mackerel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMackerel A list to return newly born Mackerel.
     */
    private void giveBirth(List<Organism> newMackerel)
    {
        // New Mackerel are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (loc.getRow() >= 0.1 * field.getDepth()) {
                Mackerel young = new Mackerel(false, field, loc);
                newMackerel.add(young);
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Mackerel can breed if it has reached the breeding age.
     * Ensures only female can breed and checks for an adjacent
     * male to reproduce.
     * @return true if the Mackerel can breed, false otherwise.
     */
    private boolean canBreed()
    {
        if (!isFemale) return false;

        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        // checks for male partner
        boolean hasPartner = false;
        while(it.hasNext()) {
            Location where = it.next();
            Object neighbour = field.getObjectAt(where);
            if (neighbour != null && neighbour.getClass() == this.getClass()){
                Mackerel n = (Mackerel) neighbour;
                hasPartner = (isFemale != n.getIfFemale());
            }
        }

        return age >= BREEDING_AGE && hasPartner;
    }

    /**
     * Returns if the Mackerel is female.
     * @return true if the Mackerel is female.
     */
    private boolean getIfFemale(){
        return isFemale;
    }

}
