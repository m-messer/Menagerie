import java.util.List;
import java.util.Iterator;

/**
 * A model of a mouse. Mice move, breed, eat (plants),
 * get eaten by other animals, age and die
 *
 * @version 2019.02.20
 */
public class Mouse extends Animal
{
    // Characteristics shared by all Mice (class variables).
    
    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 7 * SPD;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 35 * SPD;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    //The duration of the mouse' pregnancy
    private static final int PREGNANCY_DURATION =  3 * SPD;
    // The food value it will be worth if it is eaten.
    private static final int FOOD_WORTH = 30;

    /**
     * Constructor for objects of class Mouse
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE);
    }

    /**
     * This is what the Mouse does most of the time: it looks for
     * food (plants), moves, procreates or dies in the meanwhile.
     * It is dependant on what time of the day it is.
     * 
     * @param newMice A list to return newly born mice.
     * @param hour what the current time is
     * @param weather what the current weather is
     */
    public void act(List<Animal> newMice, int hour, String weather)
    {
        age(MAX_AGE);
        if(isAlive()) {
            //if the animal is male and is over the breeding age
            if(getGender() && canBreed(BREEDING_AGE)) {
                if(hour >= 6 && hour <= 20)
                    //look for females in adjacent locations
                    procreate(BREEDING_PROBABILITY);
            }  
            //if the animal is female
            else
                //try to give birth (if it has been pregnant for long enough)
                giveBirth(newMice, PREGNANCY_DURATION, MAX_LITTER_SIZE); 

            // during certain hours
            if(hour >= 4 && hour <= 20) {    
                Location newLocation = null;
                // Move towards a source of food if hungry.
                if(isHungry())
                    newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else 
                    // Overcrowding.
                    setDead();
            }
        }
    }

    /**
     * Look Cycads in adjacent location and eat them
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getPlantAt(where);
            // if it finds a plant of type Flower
            if(plant instanceof Flower) {
                // cast
                Flower flower = (Flower) plant;
                // get its food worth (based on how much the plant is grown) 
                int foodWorth = flower.getFoodWorth();
                // only eats it if its grown enough
                if(foodWorth >= 50) {
                    // eat, increasing its food level by the appropriate amount
                    eat(foodWorth);
                    flower.setEaten();
                    // return the location of the plant so that it can move to it
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * invoked if the animal gets eaten
     * @return the animal's food worth
     */
    protected int getFoodWorth()
    {
        return FOOD_WORTH;
    }

    /**
     * A method required for the java reflection used in the super class
     * It is invoked to fetch the breeding age of a female at run-time
     * @return BREEDING_AGE private field of 'this'
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}

