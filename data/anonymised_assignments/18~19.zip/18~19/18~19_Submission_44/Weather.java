import java.util.Random;
import java.util.ArrayList;
import java.util.List;

/**
 * A weather class to generate random weather conditions.
 * The different possibilities are stored in an ArrayList.
 * Rainy and foggy weather is less likely than sunny.
 * Weather can change certain behaviours in plants/animals.
 *
 * @version 2019.02.20
 */

public class Weather
{  
    // control weather patterns
    private static final Random rand = Randomizer.getRandom();
    // the likelihood of rainy weather
    private static final double RAINY_PROBABILITY = 0.2;
    // the likelihood of foggy weather
    private static final double FOGGY_PROBABILITY = 0.1;

    // A list to store different weather possibilities as strings
    private List<String> weatherConditions;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        // set all possible weather conditions
        weatherConditions = new ArrayList<>();
        weatherConditions.add("sunny");
        weatherConditions.add("foggy");
        weatherConditions.add("rainy");
    }

    /**
     * A method to generate a random weather condition
     * @return a string representing the weather condition
     */
    public String getWeather()
    {
        // it will be sunny by default
        String weather = weatherConditions.get(0);

        // 'roll a dice' for foggy or rainy
        if(rand.nextDouble() <= FOGGY_PROBABILITY)
            weather = weatherConditions.get(1);
        else if(rand.nextDouble() <= RAINY_PROBABILITY)
            weather = weatherConditions.get(2);
        
        return weather;
    }
}
