import java.util.List;
import java.util.Iterator;

/**
 * A model of a Raptor. Raptors move, breed, eat (animals),
 * get eaten, age and die
 *
 * @version 2019.02.20
 */
public class Raptor extends Animal
{
    // Characteristics shared by all Raptors (class variables).
    
    // The age at which a Raptor can start to breed.
    private static final int BREEDING_AGE = 10 * SPD;
    // The age to which a Raptor can live.
    private static final int MAX_AGE = 140 * SPD;
    // The likelihood of a Raptor breeding.
    private static final double BREEDING_PROBABILITY = 0.6;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    //The duration of the animal's pregnancy
    private static final int PREGNANCY_DURATION =  3 * SPD;
    // The food value an ankylosaurs will be worth if it is eaten.
    private static final int FOOD_WORTH = 50;

    /**
     * Constructor for objects of class Raptor
     */
    public Raptor(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE);
    }

    /**
     * This is what the Raptor does most of the time: it looks for
     * food (animals), moves, procreates or dies in the meanwhile.
     * It is dependant on what time of the day it is and the weather
     * 
     * @param newRaptors A list to return newly born trexes.
     * @param hour what the current time is
     * @param weather what the current weather is
     */
    public void act(List<Animal> newRaptors, int hour, String weather)
    {
        age(MAX_AGE);
        if(isAlive()) {
            //if the animal is male and is over the breeding age
            if(getGender() && canBreed(BREEDING_AGE)) {
                if(hour >= 12 && hour <= 20)
                //look for females in adjacent locations
                procreate(BREEDING_PROBABILITY);  
            }
            //if the animal is female
            else
                //try to give birth (if it has been pregnant for long enough)
                giveBirth(newRaptors, PREGNANCY_DURATION, MAX_LITTER_SIZE); 
            
            // every 5 hours during the specified time frame
            if(hour >= 15 && hour <=20 && hour % 5 == 0) {
                Location newLocation = null;
                // Move towards a source of food if hungry and its not foggy
                if(isHungry() && !(weather.equals("foggy")))
                    newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look Mice or Ankylosaurs in adjacent location and eat them
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // iterate through all adjacent locations
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);

            // if the object is a mouse
            if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) { 
                    // safely cast
                    mouse.setDead();
                    // get its food worth and eat
                    eat(mouse.getFoodWorth());
                    return where;
                }
            }

            // if there is an Ankylosaurs
            if(animal instanceof Ankylosaurs) {
                // safely cast
                Ankylosaurs ankylosaurs = (Ankylosaurs) animal;
                if(ankylosaurs.isAlive()) { 
                    ankylosaurs.setDead();
                    // get its food worth and eat
                    eat(ankylosaurs.getFoodWorth());
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * invoked if the animal gets eaten
     * @return the animal's food worth
     */
    protected int getFoodWorth()
    {
        return FOOD_WORTH;
    }  
    
    /**
     * A method required for the java reflection used in the super class
     * It is invoked to fetch the breeding age of a female at run-time
     * @return BREEDING_AGE private field of 'this'
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}
