import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing killer whales, dogfish, clownfish, cod, lobster, seaweed and algae.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double KILLERWHALE_CREATION_PROBABILITY = 0.02;
    // The probability that a rabbit will be created in any given grid position.
    private static final double DOGFISH_CREATION_PROBABILITY = 0.12;
    private static final double COD_CREATION_PROBABILITY = 0.18;
    private static final double LOBSTER_CREATION_PROBABILITY = 0.12;
    private static final double CLOWNFISH_CREATION_PROBABILITY = 0.8;
    private static final double SEAWEED_CREATION_PROBABILITY = 0.12;
    private static final double ALGAE_CREATION_PROBABILITY = 0.1;

    // List of creatures in the field.
    private List<Creature> creatures;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The state of the environment.
    private static EnvironmentState state = new EnvironmentState();
   
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        // initialize the depth and width
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        // give the information of the weather by Label
        checkAndSetWeatherLabel();
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        creatures = new ArrayList<>();
        field = new Field(depth, width);
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Clownfish.class, Color.ORANGE);
        view.setColor(KillerWhale.class, Color.BLUE);
        view.setColor(Dogfish.class, Color.BLACK);
        view.setColor(Cod.class, Color.PINK);
        view.setColor(Lobster.class, Color.RED);
        view.setColor(Seaweed.class, Color.YELLOW);
        view.setColor(Algae.class, Color.GREEN);
        // set up the weather label
        checkAndSetWeatherLabel();
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * The steps are seperated in day and night steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        // set up the step counter with time 
        int step = 1;
        while(step <= numSteps && view.isViable(field)){
            int timeTrack = step % 24;
            if(timeTrack > 0 && timeTrack <= 12){
                simulateOneDayStep();
            }
            else{
                simulateOneNightStep();
            }
            step++;
        }
    }
    
    /**
     * Run the simulation from its current state for a single day time step.
     * Iterate over the whole field updating the state of each creature.
     * Sea environment is randomly set up and some creatures will be influenced.
     */
    public void simulateOneDayStep()
    { 
        step++; 
        state.setRandomWeather();
        checkAndSetWeatherLabel();
        // Provide space for newborn creatures.
        List<Creature> newCreatures = new ArrayList<>();        
        // Let all creatures act.
        if(checkIfToosalty() || checkIfHightemp())
        {
           for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
               Creature creature = it.next();
               if(creature instanceof Seaweed){
                   Seaweed seaweed = (Seaweed) creature;
                   seaweed.weatherAct();
                   if(! seaweed.isAlive()){
                       it.remove();
                    }
               }
               else if(creature instanceof Algae){
                   Algae algae = (Algae) creature;
                   algae.weatherAct();
                   if(! algae.isAlive()){
                       it.remove();
                    }
               }
               else{
                   creature.dayAct(newCreatures);
                   if(! creature.isAlive()) {
                      it.remove();
                   }  
               } 
           }
        }
        else{
            for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
               Creature creature = it.next();
               creature.dayAct(newCreatures);
               if(! creature.isAlive()) {
                   it.remove();
               }
            
           }
        }
               
        // Add the newly born Creatures or plants to the main lists.
        creatures.addAll(newCreatures);
        view.showStatus(step, field);
    }
    
    /**
     * Run the simulation from its current state for a single night step.
     * Iterate over the whole field updating the state of each creature. 
     */
    public void simulateOneNightStep()
    {
        step++;
        
        List<Creature> newCreatures = new ArrayList<>();        
        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
            Creature creature = it.next();
            creature.nightAct();
            if(! creature.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born Creatures or plants to the main lists.       
        creatures.addAll(newCreatures);
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        creatures.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with killer whales, dogfish, 
     * clownfish, cod, lobster, seaweed and algae.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= KILLERWHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    KillerWhale killerWhale = new KillerWhale(true, field, location);
                    creatures.add(killerWhale);
                }
                else if(rand.nextDouble() <= DOGFISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dogfish dogfish = new Dogfish(true, field, location);
                    creatures.add(dogfish);
                }
                else if(rand.nextDouble() <= LOBSTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lobster lobster = new Lobster(true, field, location);
                    creatures.add(lobster);
                }
                else if(rand.nextDouble() <= COD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cod cod = new Cod(true, field, location);
                    creatures.add(cod);
                }
                else if(rand.nextDouble() <= CLOWNFISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Clownfish clownfish = new Clownfish(true, field, location);
                    creatures.add(clownfish);
                }
                else if(rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seaweed seaweed = new Seaweed(true, field, location);
                    creatures.add(seaweed);
                }
                else if(rand.nextDouble() <= ALGAE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Algae algae = new Algae(true, field, location);
                    creatures.add(algae);
                }
                // else leave the location empty.
            }
        }
    }
    
    public static EnvironmentState getState()
    {
        return state;
    }
    
    /**
     * Return the name of sea environment.
     * @return the weather name
     */
    public String checkWeather(){
        return state.getWeather().name();
    }
    
    /**public static Environment getState(){
        return Environment;
    }*/
    /**
     * Check if there is normal weather at that moment
     * @return if enviroment is clear
     */
    public boolean checkIfClear(){
        return checkWeather() == "CLEAR";
    }
    
    /**
     * Check if the environment for the sea is too salty
     * @return if the enviroment is too salty.
     */
    public boolean checkIfToosalty(){
        return checkWeather() == "TOOSALTY";
    }
    
    /**
     * Check if the environment for the sea is about a high temperature
     * @return if the enviroment is high temperature.
     */
    public boolean checkIfHightemp(){
        return checkWeather() == "HIGHTEMP";
    }
    
    /**
     * Show the label in the GUI that weather information can be shown
     */
    private void checkAndSetWeatherLabel(){ 
        if(checkIfClear()){
            view.setClearLabel();
        }
        else if(checkIfToosalty()){
            view.setToosaltyLabel();
        }
        else{
            view.setHightempLabel();
        }
        
    }
}
