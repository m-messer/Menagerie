import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a cod.
 * cod age, move, breed, eat plants, may have disease and die.
 *
 * @version (2019.2.21)
 */
public class Cod extends Prey
{
    private static final int BREEDING_AGE = 6;
    // The age to which a cod can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a cod breeding.
    private static final double BREEDING_PROBABILITY = 0.09;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //The maximum hanger level of a cod. The cod eat seaweed
    //of a maximum height of 25 to reach the 0 hunger level.
    private static final int MAX_HUNGER_LEVEL = 25;
    
    private static final double DISEASE_INFECTED_PROBABILITY = 0.01;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private int age;
    //The hunger level of the cod.
    //It will be dead if the hunger level higher than the maximum of 25.
    private int hungerLevel;
    private boolean isFemale;
    
    /**
     * Create a new cod. A cod may be created with age
     * zero (a new born) or with a random age.
     * The gender of a cod is random.
     * 
     * @param randomAge If true, the cod will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cod(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            hungerLevel = rand.nextInt(MAX_HUNGER_LEVEL);
        }
        else{
            age = 0;
            hungerLevel = 0;
        }
        if(rand.nextInt(2) == 0){
            isFemale = true;
        }
        else{
            isFemale = false;
        }
    }

    /**
     * This is what the cod does most of the day time - it runs 
     * around and eat seaweed. Sometimes it will be infected disease, breed or die of old age.
     * @param newCod A list to return newly born cod. 
     */
    public void dayAct(List<Creature> newCod)
    {
        incrementAge();
        incrementHunger();
        diseaseInfection();
        if(isAlive()) {
            giveBirth(newCod); 
            findFood();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the cod does most of the night time - it 
     * runs around and may be infected disease. 
     */
    public void nightAct()
    {
        diseaseInfection();
        if(isAlive()) {
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the hunger level.
     * This could result in the cod's death.
     */
    private void incrementHunger()
    {
        hungerLevel++;
        if(hungerLevel > MAX_HUNGER_LEVEL) {
            setDead();
        }
    }
    
    /**
     * Increase the age.
     * This could result in the cod's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Look for seaweed that are adjacent to the current location.
     * The cod eat seaweed to reach 0 hunger level and the height of the seaweed will dicrease.
     */
    private void findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Seaweed) {
                Seaweed seaweed = (Seaweed) creature;
                if(seaweed.getHeight() >= hungerLevel){
                    hungerLevel = 0;
                    seaweed.setHeight(seaweed.getHeight() - hungerLevel);
                }
                else{
                    hungerLevel = hungerLevel - seaweed.getHeight();
                    seaweed.setHeight(0);
                }
            }
        }
    }
    
    
    /**
     * Check whether or not this cod is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCod A list to return newly born cod.
     */
    private void giveBirth(List<Creature> newCod)
    {
        // New cods are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cod young = new Cod(false, field, loc);
            newCod.add(young);
        }
    }
    
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero). 
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A cod can breed if it is female, have adjacent 
     * male cod and has reached the breeding age.
     * @return If the cod can breed. 
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE && isFemale && hasAdjacentMale()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Return the cod's gender.
     * @return The cod's gender.
     */
    public boolean getIsFemale()
    {
        return isFemale;
    }
    
    /**
     * Return the cod's age.
     * @return The cod's age.
     */ 
    public int getAge()
    {
        return age;
    }
    
    /**
     * Check if the cod has adjacent male cod.
     * @return if the cod has adjacent male cod.
     */
    private boolean hasAdjacentMale()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Cod) {
                Cod cod = (Cod) creature;
                if(cod.isAlive() && !cod.getIsFemale() && cod.getAge() >= BREEDING_AGE){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check if the cod has adjacent disease infected cod.
     * @return if the cod has adjacent disease infected cod.
     */
    private boolean adjacentInfectedCod()
    {
        Field field = getField();
        if(getLocation() == null)return false;
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Cod) {
                Cod cod = (Cod) creature;
                if(cod.isAlive() && cod.hasDisease()){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * The cod will be infected if it has adjacent cod. 
     */
    private void infectedDisease()
    {
        if(adjacentInfectedCod() && rand.nextDouble() <= DISEASE_INFECTED_PROBABILITY){
            setDisease();
        }
    }
    
    /**
     * Increase the disease level of the infected cod
     * or set disease to the cod if it will be infected.
     */
    private void diseaseInfection()
    {
        if(hasDisease()){
            incrementDiseaseLevel();
        }
        else{
            infectedDisease();
        }
    }
}
