import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Predator is a subclass of class Creature.
 * predator may have disease.
 *
 * @version (2019.2.21)
 */
public abstract class Predator extends Creature
{
    private static final double DISEASE_PROPABILITY = 0.01;
    private Disease disease;
    private static final Random rand = Randomizer.getRandom();
    /**
     * Created a predator. The predator is created as no disease initially.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(Field field, Location location)
    {
        super(field, location);
        if(rand.nextDouble() <= DISEASE_PROPABILITY){
            disease = new Disease(true,0);
        }
        else{
            disease = new Disease(false,0);
        }
    }

    /**
     * Return whether the predator has the disease.
     * @return whether the predator has the disease.
     */
    public boolean hasDisease()
    { 
        return disease.getHasDisease();
    }
    
    /**
     * Predator is infected by disease.
     */
    public void setDisease()
    {
        disease.setDisease();
    }
    
    /**
     * Increase the predator's disease level. 
     */
    public void incrementDiseaseLevel()
    {  
        disease.incrementLevel();
        if(disease.isDead()){
            setDead();
        }
    }
}
