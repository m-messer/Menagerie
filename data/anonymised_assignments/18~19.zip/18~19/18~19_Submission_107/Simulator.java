import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing snakes, rats, sparrows, cats, eagles and plants.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    // The probability that a rat will be created in any given grid position.
    private static final double RAT_CREATION_PROBABILITY = 0.10;
    // The probability that a cat will be created in any given grid position.
    private static final double CAT_CREATION_PROBABILITY = 0.03;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.05; 
    // The probability that a eagle will be created in any given grid position.
    private static final double EAGLE_CREATION_PROBABILITY = 0.03; 
    // The probability that a sparrow will be created in any given grid position.
    private static final double SPARROW_CREATION_PROBABILITY = 0.2; 
    // The probability that a plant will be created in any given grid position.
    private static final double PLANTS_CREATION_PROBABILITY = 0.9;

    // A graphical view of the simulation.
    private SimulatorView view;
    
    // List of animals in the field.
    private List<Animal> animals;
    // List of all the plants.
    private List<Plants> plants; 
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // List of the possible types of weather.
    private ArrayList<Weather> weather; 
    // The depth of the grid
    private int depth; 
    // The width of the grid
    private int width; 
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            this.depth = DEFAULT_DEPTH;
            this.width = DEFAULT_WIDTH;
        }
        this.depth = depth; 
        this.width = width; 
        
        animals = new ArrayList<>();
        field = new Field(depth, width);
        weather = new ArrayList<>();
        plants = new ArrayList<>(); 
        // Adding the types of weather 
        weather.add(new Sunny()); 
        weather.add(new Rain());
        weather.add(new Fog());
        weather.add(new Snow());
        
        view = new SimulatorView(depth, width);
        view.setColor(Rat.class, Color.BLACK);
        view.setColor(Cat.class, Color.ORANGE);
        view.setColor(Eagle.class, Color.YELLOW);
        view.setColor(Snake.class, Color.PINK);
        view.setColor(Sparrow.class, Color.RED);
        view.setColor(Plants.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Randomly populate the field with animals.
     */
    public void populate()
    {   
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(TestProbability(CAT_CREATION_PROBABILITY)) {
                    Location location = new Location(row, col);
                    Cat cat = new Cat(false, true, field, location);
                    animals.add(cat);
                }
                else if(TestProbability(RAT_CREATION_PROBABILITY)) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(false, true, field, location);
                    animals.add(rat);
                }
                else if(TestProbability(EAGLE_CREATION_PROBABILITY)) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(false, true, field, location);
                    animals.add(eagle);
                }
                else if(TestProbability(SPARROW_CREATION_PROBABILITY)) {
                    Location location = new Location(row, col);
                    Sparrow sparrow = new Sparrow(false, true, field, location);
                    animals.add(sparrow);
                }
                else if(TestProbability(SNAKE_CREATION_PROBABILITY)) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(false, true, field, location);
                    animals.add(snake);
                }
                else if(TestProbability(PLANTS_CREATION_PROBABILITY)) {
                    Location location = new Location(row, col);
                    Plants plant = new Plants(field, location);
                    plants.add(plant); 
                }
                // else leave the location empty.
            }
        }
    }
    
    private boolean TestProbability(Double prob)
    {   
        Random rand = Randomizer.getRandom();
        if(rand.nextDouble()<= prob) return true;
        return false; 
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {   
        step = 1; 
        while(step<= numSteps && Possible()){
            simulateOneStep();
            step ++;
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        boolean day = getDayTime(step); 
        Weather weather = getWeather(); 
        
         // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.isAlive()&& animal.CanMove(weather, day))
             {   
                 newAnimals.addAll(animal.act());
             }
  
            if(!animal.isAlive()) {
                it.remove();
            }
        }
        
        // Provide space for new plants. 
        List<Plants> newPlants = new ArrayList<>();
        //Let all plants grow.
        if(day){
        for(Iterator<Plants> it = plants.iterator(); it.hasNext(); ) {
            Plants plant = it.next();
            newPlants.addAll(plant.grow(weather)); 
            if(!plant.isAlive()) {
                it.remove();
            }
        }
        }
   
        // Add all new Animals 
        animals.addAll(newAnimals); 
        
        //Add all new Plants 
        plants.addAll(newPlants);
        
        view.showStatus(step, field, weather);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        view.showStatus(step, field, getWeather());
    }
    
    /**
     *  Check if it possible to display. 
     */
    public boolean Possible()
    {
        return view.isViable(field);
    }
    
    /**
     *  @return the field 
     */
    public Field getField()
    {
        return field; 
    }
    
    /**
     *  @return true if it's daytime and false if it's night time 
     */
    public boolean getDayTime(int step)
    {
        if(step%2 == 1) return true; 
        else return false; 
    }
    
    /**
     *  @return a random type of weather 
     */
    private Weather getWeather()
    {
        Random ran = new Random(); 
        return weather.get(ran.nextInt(4)); 
    }
}
