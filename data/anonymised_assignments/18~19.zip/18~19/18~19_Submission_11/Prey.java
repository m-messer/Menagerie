import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Abstract class Prey 
 * This class represents prey in our simulation.
 * A prey animal can be eaten by the predators 
 * but will be able to eat grass (in some cases).
 * ll also exhibit the same movement functionality.
 *
 * @version 1.0
 */
public abstract class Prey extends Animal
{
    // Characteristics shared by all prey (class variables)
    private static final int PREY_FOOD_LEVEL = 10;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge do we need to generate a random age?
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param type The type of the animal being generated
     */
    public Prey(Boolean randomAge, Field field, Location location, AnimalType type)
    {
        super(field, location, type);
        age = 0;
        foodLevel = PREY_FOOD_LEVEL;
        if(randomAge) {
            age = Simulator.rand.nextInt(animalType.getMaxAge());
        }
    }
    
    /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born prey.
     */
    public void act(List<Animal> newPrey, Weather currentWeather)
    {
        super.act(newPrey, currentWeather);
        move(true);
    }
    
    /** 
     * Allow the current animal to move and then 
     * eat a plant at the current location
     */
    protected void move(Boolean shouldEat) 
    {
        // check that current animal is alive
        if (isAlive()) {
            // get new location
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
                if (shouldEat) {
                    // eat plant if it exists
                    eatPlantAtCurrentLocation();
                }
            }
            else {
                setDead(); // overcrowding
            }   
        }
    }
    
    /**
     * See if there is a plant at the current location 
     */
    protected void eatPlantAtCurrentLocation() 
    {     
        Plant plant = getField().getPlantAt(getLocation());
        // if there is a plant at the current location
        if (plant != null) {
            // if the plant is poisonous then kill the animal
            if (plant.canBeConsumed()) {
                if (plant.plantIsPoisonous()) {
                    setDead();
                } else {
                    foodLevel += PREY_FOOD_LEVEL;
                }   
                plant.setEaten();
            }
        }
    }
    
}
