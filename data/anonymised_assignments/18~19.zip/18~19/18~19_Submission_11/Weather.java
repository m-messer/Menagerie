import java.util.Random;

/**
 * Enumeration class Weather - This enumeration will be responsible for 
 * holding the current weather state of our simulation.
 *
 * @version Version 1.0 - 14/02/2019
 */
public enum Weather
{
    /**
     * Hold the weather types, extendable by adding a new 
     * weather
     */
    SUN,
    FOG,
    RAIN,
    MILD
    ;
    
    /** 
     * Get a random weather used in the simulation 
     * class
     * @return Weather the given random weather
     */
    public static Weather randomWeather() 
    {
        int rnd = Simulator.rand.nextInt(4);
        switch (rnd) {
            case 0: return SUN;
            case 1: return FOG;
            case 2: return RAIN;
            case 3: return MILD;
        }
        return SUN;
    }
}

