import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing lions, snakes, humans, birds, sheep and moose.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;
    // The number of steps of one day
    private static final int DAY_LENGTH = 2;
    
    // List of animals in the field.
    private List<Animal> animals;
    // list of all the plants in the field
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // the current time of the simulation 
    private Time time;
    // A graphical view of the simulation.
    private SimulatorView view;
    // the current weather of the simulation
    // with default value of sun
    private Weather currentWeather = Weather.SUN;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);    
        time = new Time();
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        // set the color representing each animal
        AnimalType.setAnimalViewColoursFor(view);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal
     */
    public void simulateOneStep()
    {
        time.tick();
        // generate random weather if required
        updateWeather();
        // Ensure the plants have grown in the field
        int plantGrowthRate = Plant.getPlantGrowRate(currentWeather);
        field.growPlants(plantGrowthRate);
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.getIsNocturnal() && time.isNight() || !animal.getIsNocturnal() && !time.isNight()) {
                animal.act(newAnimals, currentWeather);
                if(! animal.isAlive()) {
                    it.remove();
                }
            } else {
                // make sure the animal age is incremented when it is sleeping
                animal.incrementAge();
            }
        }
        // Add the newly born animals to the main list.
        animals.addAll(newAnimals);
        view.showStatus(time.getHour(), field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        time.reset();
        animals.clear();
        plants.clear();
        field.removePlants();
        populate();
        // Show the starting state in the view.
        view.showStatus(time.getHour(), field);
    }
    
    /**
     * Randomly populate the field with animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);  
                int plantProbability = rand.nextInt(5);
                // add the plant to the view if needed
                if (shouldAddPlant(plantProbability)) {
                    field.generatePlant(location);
                }
                // add the animal depending on the creation probability
                for (AnimalType type: AnimalType.animalTypes) {
                    // if we are to generate the next animal
                    Double randProbability = rand.nextDouble();
                    // add the animal to the field
                    if (randProbability <= type.getCreationProbability()) {
                        // add the new animal to the simulation
                        Animal newAnimal = AnimalType.createChild(type, true, field, location);
                        animals.add(newAnimal);
                    }
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * @return Boolean - true if the field should generate a plant based
     *                   on a given probability
     */
    private boolean shouldAddPlant(int creationProbability) 
    {
        return creationProbability <= 2;
    }
        
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Update the simulators current weather
     * The weather will update once every 'day'
     */
    public void updateWeather() 
    {
        if (time.isNewDay()) {
            currentWeather = Weather.randomWeather();
        }
    }    

}
