import java.util.List;
/**
 * This class represents a Moose
 *
 * @version Version 1.0 - 07/02/2019
 */
public class Moose extends Prey
{
    
    /**
     * Create a new snake at location in field.
     * 
     * @param randomAge Check if we want a random age
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Moose(Boolean randomAge, Field field, Location location) 
    {
        super(randomAge, field, location, AnimalType.MOOSE);
    }
    
    /**
     * Give moose the ability to eat twice as much grass in one go
     * This calls all the functionality in the super class (prey) 
     * and then moves and acts again.
     */
    public void act(List<Animal> newAnimals, Weather currentWeather)
    {
        // carry out the basic behaviour
        super.act(newAnimals, currentWeather);
        // make the moose move and eat twice
        super.move(true);
    } 
     
}
