import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a WildCat.
 * Wild Cats age, move, eat badgers and snakes, and die.
 *
 * @version 2019.02.20
 */
public class WildCat extends Animal
{
    // Characteristics shared by all wild cats(class variables).
    
    // The age at which a wild cats can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a wild cats can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a wild cats breeding.
    private static final double BREEDING_PROBABILITY = 0.14;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single badger. In effect, this is the
    // number of steps a wildcat can go before it has to eat again.
    private static final int BADGER_FOOD_VALUE = 12;
    // The food value of a single snake. 
    private static final int SNAKE_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    
    // Individual characteristics (instance fields).
    // The wild cats's age.
    private int age;
    // The wild cats's food level, which is increased by eating rabbits.
    private int foodLevel;
    //Number of steps since diseased
    private int diseased;
    
    /**
     * Create a wild cat. A wild cat can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wild cat will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public WildCat(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        diseased = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(BADGER_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = BADGER_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the wild cat does most of the time: it hunts for
     * badgers and snakes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWildCats A list to return newly born WildCats.
     */
    public void act(List<Animal> newWildCat)
    {
        incrementAge();
        incrementHunger();
      
        if(isAlive()) {
            giveBirth(newWildCat);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
             if(isDiseased()){
               incrementDiseased();
            }
            
        }
    }

    /**
     * Increase the age. This could result in the wild cat's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Increase diseased status. Animals live for three steps while diseased
     */
    private void incrementDiseased()
    {
       diseased++;
       if(diseased == 3) {
            setDead();
        } 
    }
    
    /**
     * Make this Wild cat more hungry. This could result in the wild cats's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for food adjacent to the current location.
     * Only the first live badger or snake is eaten.
     * If diseased food is eaten, animal becomes diseased
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
           
            if(animal instanceof Badger) {
               Badger badger = (Badger) animal;
             
               if(badger.isAlive()) { 
                    if (badger.isDiseased()){ 
                        setDiseased();
                    }
                    badger.setDead();
                    foodLevel = foodLevel + BADGER_FOOD_VALUE;
                    
                    return where; 
                }
            } 
           
            if (animal instanceof Snake) {
                Snake snake = (Snake) animal; 
                if (snake.isAlive()){
                   if (snake.isDiseased()){ 
                        setDiseased();
                    }
                    snake.setDead();
                    foodLevel =foodLevel + SNAKE_FOOD_VALUE;
                    return where; 
                }
            }
            
            // If a wildcat is next to a lizard, it is assumed that the wildcat steps on the lizard
            // and hence the lizard will die.
            if (animal instanceof Lizard) {
                Lizard lizard = (Lizard) animal;
                if (lizard.isAlive()){
                    lizard.setDead();
                }
            }
      }
        return null;
    }
    
    
    /**
     * Check whether or not this wild cat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWildCats A list to return newly born cats.
     */
    private void giveBirth(List<Animal> newWildCats)
    {
        // New Wild Cats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
       
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            WildCat young = new WildCat(false, field, loc);
            newWildCats.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
 
    /**
     * Checks if the is an animal of the same species near by that
     * that it can breed with
     */
    private boolean findMate() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof WildCat) {
                WildCat wildcat = (WildCat) animal;
                
                if(isFemale() != wildcat.isFemale() ) { 
                  //If either animal is diseased it will spread  
                    if (wildcat.isDiseased()){ 
                     setDiseased();
                 }
                 if (isDiseased()){
                   wildcat.setDiseased(); 
                    }
                    return true; 
                }
            }
            
        }
        return false;
    }
    
    /**
     * A wild cat can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        
        if (findMate() && age >= BREEDING_AGE) {
         return true;
        }
        else {
        return false;
        }
        
    }
}