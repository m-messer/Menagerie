import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A class representing a Lion.
 * Lion age, move, eat Prey, and die of age or infection.
 *
 * @version 2016.02.20
 */
public class Lion extends Predator
{
   // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a lion can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single prey. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int FOOD_VALUE = 20;

    /**
     * Create a Lion. A Lion can be created as a new born (age zero
     * and not hungry) and his food value or with a random age and a random food level.
     * 
     * @param isRandom If true, the Lion will have a random age and hunger level (food value).
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean isRandom, Field field, Location location)
    {
        super(isRandom, field, location);
    }

    // Getters

    /**
     * @return return the breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return return the max age it can live.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return return the probability to breed.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return return the maximum number of births.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return return the food value of a prey.
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * Create an instance of Lion and return it.
     * 
     * @param isRandom If true, the Lion will have a random age and a random food value.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @return A new instance of Lion
     */
    public Animal getNewBorn(boolean isRandom, Field field, Location location)
    {
        return new Lion(isRandom, field, location);
    }

    /**
     * @param animal an Animal for which we want to find the species.
     * @return true if the animal passed as a parameter is an instanceof Lion
     */
    public boolean sameSpecies(Object animal)
    {
        if (animal instanceof Lion) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Look for preys adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), 1);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            // A Lion can only eat Giraffe and Zebra
            if(animal instanceof Giraffe) {
                Giraffe prey = (Giraffe) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    setFoodLevel(getFoodValue());
                    return where;
                }
            }
            else if(animal instanceof Zebra) {
                Zebra prey = (Zebra) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    setFoodLevel(getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
}
