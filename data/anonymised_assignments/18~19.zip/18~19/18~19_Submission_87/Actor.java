import java.util.List;

/**
 * An interface which should be implemented by all classes representing Actors.  
 *
 * @version 2019.02.20
 */
public interface Actor
{
	/**
	* The action taken by each Actor at each step of the simulation.
	* 
	* @param newActors Collection of the newly created actors at each step.
	* @param dayTime The time of day. 
	* @param changeWeather Truth value representing whether the weather will or won't change.  
	*/
	public void act(List<Actor> newActors, boolean dayTime, boolean changeWeather);

	/**
	* Method which checks whether the actor is alive or dead.
	*
	* @return Truth value: (False = 'Dead', True = 'Alive')
	*/
	public boolean isAlive();
}
  