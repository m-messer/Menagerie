import java.util.List;
import java.util.Random;

/**
 * A class representing the Weather at a location in the field.
 * The weather can act at each step, changing it's state.
 *
 * @version 2016.02.20
 */
public abstract class Weather implements Actor
{
    // The weather's field.
    private Field field;
    // The weather's position in the field.
    private Location location;
    // Whether the weather object is active or not.
    private boolean alive;

    /**
     * Creates a new weather at a location in the field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Weather(Field field, Location location)
    {
        this.field = field;
        alive = true;
        setLocation(location);
    }
   
    // Getters

    /**
     * Check whether the weather is active or not.
     * @return True if the weather is still active, false otherwise.
     */  
    public boolean isAlive()
    {
        return alive;
    }

    // Setters

    /**
     * Place the weather at the new location in the given field.
     * @param newLocation The weather's new location.
     */
    public void setLocation(Location newLocation)
    {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Remove the weather from the field.
     */
    private void clearLocation()
    {
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * This is what the weather can do, change the weather type at a location in the field
     * if the boolean changeWeather is true.
     * @param newWeather A list to return the new weather at the same location.
     * @param dayTime Boolean truth value with true representing day time, and false representing night time.
     * @param changeWeather Boolean truth value representing a change of the weather.
     */   
    public void act(List<Actor> newWeather, boolean dayTime, boolean changeWeather)
    {
        // the weather changes only if the changeWeather parameter is equal to true.
        if (changeWeather) {
            alive = false;
            // if the weather was Sunny change to Rainy.
            if (this instanceof Sunny) {
                Location tmpLocation = location;
                Field tmpField = field;
                clearLocation();
                newWeather.add(new Rainy(tmpField, tmpLocation));
            }
            // if the weather was Rainy change to Sunny.
            else if (this instanceof Rainy) {
                Location tmpLocation = location;
                Field tmpField = field;
                clearLocation();
                newWeather.add(new Sunny(tmpField, tmpLocation));
            }
        }
    }

    // Getter for the Plant's growth rate multiplier of Weather's subclasses.
    abstract public double getPlantGrowthRateMultiplier();
}