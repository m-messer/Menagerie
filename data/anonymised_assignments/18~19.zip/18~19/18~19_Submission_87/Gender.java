/**
 * An enum class representing a Gender.
 * A Gender instance can either represent a male or a female.
 *
 * @version 2019.02.20 
 */
public enum Gender
{
    MALE, FEMALE
}