import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.20
 */
public abstract class Animal implements Actor
{
    // A shared pseudo random number generator.
    private static final Random rand = Randomizer.getRandom();
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    // Maximum steps an Animal can go without food.
    private int foodLevel;

    // The animal's gender.
    private Gender gender;
    // The animal's age.
    private int age;
    // Truth value representing whether the Animal is infected with a disease or not
    private boolean infected;

    /**
     * Creates a new animal at location in field (newborn) with a random gender.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        this.field = field;
        alive = true;
        infected = false;

        /* 
         * 50% probability of Male being born.
         * 50% probability of Female being born.
         */
        if (rand.nextBoolean()) {
            gender = Gender.MALE;
        } 
        else {
            gender = Gender.FEMALE;
        }

        setLocation(location);
    }
    
    // Getters

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /** 
     * Getter for gender.
     * @return The animal's gender.
     */   
    public Gender getGender() 
    {
        return gender;
    }

    /**
     * Getter for infected.
     * @return Truth value: (False: Not Infected, True: Infected)
     */
    public boolean getInfected()
    {
        return infected;
    } 

    /**
     * Getter for age.
     * @return The age of the animal.
     */
    public int getAge()
    {
        return age;
    } 

    /**
     * Check whether the animal is alive or not.
     * @return True if the animal is still alive, false otherwise.
     */
    public boolean isAlive()
    {
        return alive;
    }

    // Setters

    /**
     * Set infected.
     */
    public void setInfected()
    {
        infected = true;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;

        field.place(this, newLocation);
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /* 
     * Setter for Age.
     */
    public void setAge(int newAge)
    {
        age = newAge;
    }

    /* 
     * Setter for Food level.
     */
    protected void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }

    /**
     * Probabilistically kill the Animal.
     */
    public void dieOfInfection()
    {
        if (rand.nextDouble() <= getDieOfInfectionProbability()) {
            setDead();
        }
    } 

    
    /**
     * Check whether or not this Animal is going to give birth at this step. (N.B. Only Females can give birth!)
     * New births will be made into free adjacent locations.
     *
     * @param newBorns A list of newly born Animals.
     */
    public void giveBirth(List<Actor> newBorns)
    {
        // Males do not give birth 
        if (getGender() == Gender.MALE) {
            return ;
        }

        // Female seeks a male to breed with depending on breeding distance.
        Field field = getField();
        List<Location> adjacentLoc = field.adjacentLocations(getLocation(), getBreedingDistance());
        boolean found = false;

        Iterator<Location> it = adjacentLoc.iterator();
        while (it.hasNext() && !found) {
            Location location = it.next();
            // Checks whether the Animal at the given field is of the same specie
            if (sameSpecies(field.getObjectAt(location))) {
                Animal partnerAnimal = (Animal) field.getObjectAt(location);
                // Checks it also a Male
                if (partnerAnimal.getGender() == Gender.MALE) {
                    found = true;

                    // Spread disease.
                    if (getInfected()) {
                        partnerAnimal.setInfected();
                    }
                    else if (partnerAnimal.getInfected()) {
                    	setInfected();
                    }
                }
            }
        }
        if (!found) {
            return ;
        }

        // New Animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = getNewBorn(false, field, loc);
            newBorns.add(young);
        }
    }


    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        setAge(getAge() + 1);
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the fox's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    // Abstract getters

    // Create a new instance of the implementing class.
    abstract public Animal getNewBorn(boolean randomAge, Field field, Location location);

    // Getter for the breeding age
    abstract public int getBreedingAge();

    // Getter for the max age
    abstract public int getMaxAge();

    // Getter for the breeding probability
    abstract public double getBreedingProbability();

    // Getter for max litter size 
    abstract public int getMaxLitterSize();
    
    // Getter for breeding distance
    abstract public int getBreedingDistance();

    // Getter for the infection probability 
    abstract public double getDieOfInfectionProbability();

    // Getter for food value 
    abstract public int getFoodValue();

    // Checks if the Animal passed is of the same species.
    abstract public boolean sameSpecies(Object animal);
}