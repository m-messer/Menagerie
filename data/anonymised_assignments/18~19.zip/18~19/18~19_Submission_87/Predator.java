import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A model of a Predator.
 * Predators age, move, eat Prey, and die of age or infection.
 *
 * @version 2019.02.20
 */
public abstract class Predator extends Animal
{
    // Characteristics shared by all predators (class variables).
    // A shared pseudo random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The max distance for which 2 Predator can meet and breed.
    private static final int BREEDING_DISTANCE = 6;

    // The probability that an infected Predator has to die at each step.
    private static final double DIE_OF_INFECTION_PROBABILITY = 0.2;
    
    // The chance a Predator will catch it's Prey in the rain. 
    private static final double HUNT_CHANCE = 0.8;

    /**
     * Create a Predator. A Predator can be created as a new born (age zero
     * and not hungry) and his food value or with a random age and a random food level.
     * 
     * @param isRandom If true, the Predator will have a random age and hunger level (food value).
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean isRandom, Field field, Location location)
    {
        super(field, location);
        if(isRandom) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getFoodValue()));
        }
        else {
            setAge(0);
            setFoodLevel(getFoodValue());
        }
    }


    // Getters

    /**
     * @return Return the breeding distance.
     */
    public int getBreedingDistance()
    {
        return BREEDING_DISTANCE;
    }

    /**
     *@return Return the probability to die of infection (when infected).
     */
    public double getDieOfInfectionProbability()
    {
        return DIE_OF_INFECTION_PROBABILITY;
    }
    
    /**
     * This is what the Predator does most of the time - 
     * Sometimes it will breed, sometimes it will eat Prey, sometimes it will die of infection or hunger or old age.
     * @param newPredator A list to return newly born Predator.
     * @param dayTime Boolean truth value representing day time, and false representing night time.
     * @param changeWeather Boolean truth value representing a change of the weather.
     */
    public void act(List<Actor> newPredator, boolean dayTime, boolean changeWeather)
    {
        // Probabilistically kill the Predator if it is infected
        if (getInfected()) {
            dieOfInfection();
        }
        
        incrementAge();
        incrementHunger();
        
        /* If it is nighttime, the prey sleep
           Else the Prey act */
        if(isAlive() && !dayTime) {
            giveBirth(newPredator);            
            // Move towards a source of food if found.
            Location newLocation = null;
            if (getField().getObjectAt(getLocation().getRow(), getLocation().getCol(), 2) instanceof Rainy) {
                if (rand.nextDouble() <= HUNT_CHANCE) {
                    newLocation = findFood();
                }
            }
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    // The predator trys to find a Prey which it can eat.
    protected abstract Location findFood();
}
