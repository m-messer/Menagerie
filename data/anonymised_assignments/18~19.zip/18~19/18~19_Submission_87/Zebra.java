import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A class Representing a Zebra.
 * Zebra can age, move, breed, eat plants and die.
 *
 * @version 2019.02.20
 */
public class Zebra extends Prey
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single plant. In effect, this is the
    // number of steps a zebra can go before it has to eat again.
    private static final int FOOD_VALUE = 12;
    
    /**
     * Create a new Zebra. A Zebra may be created with age
     * zero (a new born) and his food value or with a random age and a random food value. 
     * 
     * @param isRandom If true, the Zebra will have a random age and a random food value.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean isRandom, Field field, Location location)
    {
        super(isRandom, field, location);
    }

    // Getters

    /**
     * @return return the breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return return the max age it can live.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return return the probability to breed.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return return the maximum number of births.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return return the food value of a plant.
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * Create an instance of Zebra and return it.
     * 
     * @param isRandom If true, the Zebra will have a random age and a random food value.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @return A new instance of Zebra
     */
    public Animal getNewBorn(boolean isRandom, Field field, Location location)
    {
        return new Zebra(isRandom, field, location);
    }

    /**
     * @param animal an Animal for which we want to find the species.
     * @return true if the animal passed as a parameter is an instanceof Zebra
     */
    public boolean sameSpecies(Object animal)
    {
        if (animal instanceof Zebra) {
            return true;
        }
        else {
            return false;
        }
    }
}
