import java.util.Iterator;
import java.util.List;

/**
 * A class representing shared characteristics of carnivor animals.
 *
 * @version 2019.02.20 (3)
 */
public abstract class Carnivore extends Animal
{
    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Carnivore(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Look for preys adjacent to the current location.
     * Only the first live Mouse is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            for (Class prey : getPreys()) {
                if (prey.isInstance(animal)) {
                    Animal Prey = (Animal) animal;
                    if(Prey.isAlive()) {
                        Prey.setDead();
                        setFoodLevel(Prey.getFoodValue());

                        // Move the poison up the food chain if needed.
                        if (Prey.getPoisoned()) setPoisoned(true);

                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Return a list of the Carnivore's prey's classes.
     * @return prey classes
     */
    abstract public Class[] getPreys();
}