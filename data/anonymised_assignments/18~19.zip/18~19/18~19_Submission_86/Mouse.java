import java.util.List;
import java.util.Random;

/**
 * A simple model of a Mouse.
 * Mice age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Mouse extends Herbivore
{
    // Characteristics shared by all Mice (class variables).

    // The age at which a Mouse can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a Mouse can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a Mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    //The food value of a single Mouse, also the number of steps that its predator can take before 
    //it needs to eat again,
    public static final int FOOD_VALUE = 8;
    // In effect, this is the number of steps a Mouse can go before it has to eat again.
    private static final int MAX_FOOD_VALUE = 20;
    
    // Individual characteristics (instance fields).
    
    // The Mouse's age.
    private int age;
    // The Mouse's food level.
    private int foodLevel;

    /**
     * Create a new Mouse. A Mouse may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Mouse will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Mouse does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMice A list to return newly born Mice.
     */
    public void act(List<Animal> newMice, boolean night)
    {
        // This animal is diurnal. If night time: does nothing
        if (night) {
            return;
        }
        super.act(newMice, night);
    }

    /**
     * Increase the age.
     * This could result in the Mouse's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Mouse more hungry. This could result in the Mouse's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this Mouse is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born Mice.
     */
    protected void giveBirth(List<Animal> newMice)
    {
        // New mice are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Mouse young = new Mouse(false, field, loc);
            newMice.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Mouse can breed if it has reached the breeding age.
     * @return true if the Mouse can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && super.canBreed(this.getClass()));
    }

    /**
     * Returns the food value of a Mouse if eaten.
     * @return the food value of Mouse.
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * Set the Mouse's foodLevel.
     * Set to max if arg is 0.
     * @param foodLevel value to add.
     */
    public void setFoodLevel(int foodLevel)
    {
        if (foodLevel == 0) {
            this.foodLevel = MAX_FOOD_VALUE;
        }
        else {
            this.foodLevel += foodLevel;
            if (this.foodLevel > MAX_FOOD_VALUE) this.foodLevel = MAX_FOOD_VALUE;
        }
    }
}
