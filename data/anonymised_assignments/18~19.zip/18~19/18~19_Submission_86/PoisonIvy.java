import java.util.List;
import java.util.Random;

/**
 * A simple model of Poison Ivy.
 * Ivies age, spread seeds, breed, and die.
 *
 * @version 2019.02.19 (3)
 */
public class PoisonIvy extends Plant{

    // The age to which a poison ivy can live.
    private static final int MAX_AGE = 5;
    // The likelihood of poison ivy releasing seeds.
    private static final double SEED_PROBABILITY = 0.05;
    // The minimum age at which poison ivy can release seeds.
    private static final int FERTILE_AGE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The maximum amount of seeds a square of poison ivy can release.
    private static final int MAX_SEEDS_RELEASED = 2;

    // The age of the plant
    private int age;

    /**
     * Create Poison Ivy. Poison Ivy can be created as a new born (age zero)
     * or with a random age.
     *
     * @param randomAge If true, the Poison Ivy will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public PoisonIvy(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the poison ivy does most of the time.
     * Sometimes it will release seeds or wither of old age.
     * @param newIvies A list to return newly seeded ivies.
     */
    public void act(List<Plant> newIvies, String weather, boolean night)
    {
        incrementAge();
        if(isAlive() && weather.equals("sunny") && !night) {
            spreadSeeds(newIvies);
        }
    }

    /**
     * Increase the age.
     * This could result in the Ivy's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not the ivy is mature enough to release seeds.
     * New seeds will grow into free adjacent locations.
     * @param newIvies A list to return newly grown ivies.
     */
    private void spreadSeeds(List<Plant> newIvies)
    {
        // New ivy grows into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentPlantLocations(getLocation());
        int seeds = growSeeds();
        for(int b = 0; b < seeds && free.size() > 0; b++) {
            Location loc = free.remove(0);
            PoisonIvy seed = new PoisonIvy(false, field, loc);
            newIvies.add(seed);
        }
    }

    /**
     * Generate a number representing the number of seeds spread,
     * if it can release seeds.
     * @return The number of seeds spread (may be zero).
     */
    private int growSeeds()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= SEED_PROBABILITY) {
            births = rand.nextInt(MAX_SEEDS_RELEASED) + 1;
        }
        return births;
    }

    /**
     * Grass can release seeds if it has reached the fertile age.
     * @return true if grass can spreadSeeds, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= FERTILE_AGE;
    }
}
