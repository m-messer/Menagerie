import java.util.List;
/**
 * A simple model of a scorn (boar in the original simulation).
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class Scorn extends Predator
{
    /**
     * Create a scorn. A scorn can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the scorn will have random age and random 
     * hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Scorn(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setBreedingAge(50);
        setMaxAge(300);
        setBreedingProbability(0.1);
        setMaxLitterSize(1);
        setAge(0);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getVexFoodValue() + 1));
        }
        else {
            setFoodLevel(getVexFoodValue()+1);
        }
    }
    
    /**
     * Check whether or not this scorn is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newScorn A list to return newly born scorn.
     */
    protected void giveBirth(List<Animal> newScorn)
    {
        // New scorn are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Scorn young = new Scorn(false, field, loc);
            newScorn.add(young);
        }
    }
}
