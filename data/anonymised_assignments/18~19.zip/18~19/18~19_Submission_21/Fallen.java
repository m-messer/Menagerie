import java.util.List;
/**
 * A simple model of a fallen (rabbit in original simulation).
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class Fallen extends Prey
{
    /**
     * Create a new fallen. A fallen may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the fallen will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fallen(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setBreedingAge(1);
        setMaxAge(50);
        setBreedingProbability(0.1);
        setMaxLitterSize(1);
        setAge(0);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getPlantFoodValue() + 1));
        }
        else {
         setFoodLevel(getPlantFoodValue() + 1);
        }
    }
 
    /**
     * Check whether or not this fallen is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFallen A list to return newly born fallen.
     */
    protected void giveBirth(List<Animal> newFallen)
    {
        // New fallen are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fallen young = new Fallen(false, field, loc);
            newFallen.add(young);
        }
    }
}
