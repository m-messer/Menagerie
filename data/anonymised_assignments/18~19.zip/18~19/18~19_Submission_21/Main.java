/**
 * This class initiates the simulator and constantly checks if a user presses is a button
 */
public class Main {
    /**
     * What to do when the program starts
     */
    public static void main(String[] args) throws InterruptedException 
    {
        Simulator sim = new Simulator();//create a new simulator object
        sim.getView().setColorLabels();//set the appropriate text for the color labels
        
        while (true) {//infinite loop unless exit button is pressed or window is closed
            if (sim.getView().isStartPressed()) {//what to do when the start (simulate 4000 steps) button is pressed
                sim.runLongSimulation();
                sim.getView().setStartPressed(false);//start button no longer pressed
            }

            if (sim.getView().isOneStepPressed()) {//what to do when the simulate one step button is pressed
                sim.simulateOneStep();
                sim.getView().setOneStepPressed(false);//simulate one step button no longer pressed
            }

            if (sim.getStep() == 0) {
                if (sim.getView().isSelectedDisease()) {
                    sim.setInfected(true);//allow animals to have a chance of being infected upon creation
                    sim.resetDiseaseForGrid();//recreate the population with infected animals
                }
            }

            if (sim.getStep() == 0) {
                if (!sim.getView().isSelectedDisease()) {
                    sim.setInfected(false);//disallow animals to have a chance of being infected upon creation
                    sim.resetDiseaseForGrid();//recreate the population without infected animals
                }
            }

            if (sim.getView().isResetPressed()) {//reset the simulation when reset is pressed
                sim.reset();
                sim.getView().setResetPressed(false);//reset button no longer pressed
            }
            
            Thread.sleep(100);//pause the execution of the current thread for 100 milliseconds
        }
    }
}