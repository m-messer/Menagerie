import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Organism implements Actor {
	//number of hours sleep below equilibrium
	private int sleepiness;
	//How satiated an animal is
	private double fullness;
	//How long an animal can live at fullness 0
	private double fatness;
	//Amount of steps for animal to be cured (0 if animal is not sick, greater than 0 if the animal is sick)
    private int sickSteps;
	//Whether the animal is asleep or not
	private boolean asleep;
	
	// Constants that probably won't need to be changed
	// The maximum sleep deprivation an animal can endure
	protected static final int MAX_SLEEPINESS = 70;
	
    // The animal's potential sex
    private enum Sex {
        MALE, FEMALE
    }
    private List<Sex> sexes = List.of(Sex.values());
    private Sex sex = sexes.get(getRandomizer().nextInt(sexes.size()));
    
	private enum Disease { 
		NONE(0, 0), 
		FLU(3, 1), 
		RABIES(7, 2, "Penguin", "Seal"),
		//Acute Retinal Pigment Epitheliitis
		ARPE(5, 3, "Krill");

        private int sickStepsIncrease;
		private int infectivity; 
		private List<String> targetAnimals = new ArrayList<>();
		private boolean speciesSpecific; 
		
		/**
		 * Disease constructor
		 * 
		 * @param sickStepsIncrease Amount of sick steps to increase when animal gets this disease
		 * @param infectivity Probability of infection of disease
		 * @param animalList List of animals which can be affected by the disease 
		 */
        Disease(int sickStepsIncrease, int infectivity, String... animalList) { 
            this.sickStepsIncrease = sickStepsIncrease;
			this.infectivity = infectivity;
			
			for (String animal : animalList) { 
				targetAnimals.add(animal);
			}

			speciesSpecific = true;

		}
		
		/**
		 * Disease constructor
		 * 
		 * @param sickStepsIncrease Amount of sick steps to increase when animal gets this disease
		 * @param infectivity Probability of infection of disease
		 */
        Disease(int sickStepsIncrease, int infectivity) { 
            this.sickStepsIncrease = sickStepsIncrease;
			this.infectivity = infectivity;
			speciesSpecific = false;
        }
		
		/**
		 * Return the sick steps increase 
		 * 
		 * @return Return the sick steps increase 
		 */
        public int getSickStepsIncrease() {
            return sickStepsIncrease;
        }
		
		/**
		 * Return the infection multiplier
		 * 
		 * @return Return the rate of infectivity of an animal's disease
		 */
        public int getInfectivity() {
            return infectivity;
		}
		
		/**
		 * Return the speciesSpecific tag (true if the disease is specific to certain species)
		 * 
		 * @return Return the speciesSpecific tag (true if the disease is specific to certain species)
		 */
        public boolean isSpeciesSpecific() {
            return speciesSpecific;
		}

		/**
		 * Return list of target animals
		 * 
		 * @return Return target animals, null if empty
		 */
        public List<String> getTargetAnimals() {
            return speciesSpecific ? targetAnimals : null;
		}
    }
    
    private List<Disease> diseases = List.of(Disease.values());
    // Set none as initial disease
    // private Disease diseaseType = diseases.get(0);
    public Disease diseaseType = diseases.get(0);//DEBUG

    /**
     * Create a new animal at location in field.
     * 
     * @param field    The field currently occupied.
     * @param location The location within the field.
	 * @param randomAge True if spawned with random age.
     */
    public Animal(Field field, Location location, boolean randomAge) {
		super(field, location, randomAge);
		sleepiness = 0;
		sickSteps = 0;
		fullness = 0;
		fatness = 0;
		
		if (randomAge) {
			fullness = getRandomizer().nextDouble() * getMaxFullness();
			fatness = getRandomizer().nextDouble() * getMaxFatness();
		}
		else // The animal has been born
		{
			changeEnergy(getReproductionEnergy());
		}
    }
	
	/**
     * Create a new animal at location in field.
     * 
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
	public Animal(Field field, Location location) {
		this(field, location, false);
    }
	
	// Abstract methods
	/**
	* Return a list of animals this animal can eat
	* @return a list of animals this animal can eat
	*/
	public abstract List<Class<? extends Organism>> getPrey();
	
	/**
	* Return true if animal is active during the day and sleeps at night.
	* @return true if the animal is active during the day and sleeps at night
	*/
	protected abstract boolean isDiurnal();
	
	/**
	* Create an instance of a subclass of animal.
	*/
	protected abstract Animal makeAnimal(Field field, Location location, boolean randomAge);
	
	//set and get methods for parameters (static fields)
	/**
	* Return the sleep required each day.
	* @return the sleep required each day
	*/
	public abstract int getSleepNeeds();
	
	/**
	* Return the fullness level at which an animal will eat.
	* @return the fullness level at which an animal will eat
	*/
	public abstract double getFullnessPoint();
	
	/**
	* Return the point at which fullness is converted to fatness.
	* @return the point at which fullness is converted to fatness
	*/
	public abstract double getMaxFullness();
	
	/**
	* Return the maximum fat that can be stored
	* @return the maximum fat that can be stored
	*/
	public abstract double getMaxFatness();

	
	/**
	* Return how many energy units this animal needs each step
	* @return how many energy units this animal needs each step
	*/
	public abstract double getEnergyNeeds();
	
	/**
	* Change energy by a given amount.
	* @param energy amount by which to change energy
	*/
	public void changeEnergy(double energy) {
		changeFullness(energy);
	}
	
	/**
	* Return the total energy value of this animal
	* @return the total energy value of this animal
	*/
	public double getEnergyValue() {
		return fatness + fullness;
	}
	
	/**
	* Return true if dormant (unhatched).
	* @return true if dormant (unhatched)
	*/
	protected boolean isDormant() {
		return age <= getDormancyPeriod();
	}
	
	/**
	* Change this animal's fullness level. 
	* If too high, it will get fatter, and if too low, it will lose fat.
	* @param n units of fullness by which to change fullness
	*/
	protected void changeFullness(double n) {
		fullness += n;
		//excess energy is stored as fat
		if (fullness > getMaxFullness()) {
			changeFatness(fullness - getMaxFullness());
			fullness = getMaxFullness();
		} 
		//fat is expended in absence of food
		else if (fullness < 0) {
			changeFatness(fullness);
			fullness = 0;
		}	
	}
	
	/**
	* Check if decrease in fullness will starve the animal.
	* @param decrease decrease in fullness
	* @return true if will starve with decrease in fullness
	*/
	protected boolean willStarve(int decrease) {
		return fatness + fullness - decrease < 0;
	}
	
	/**
	* Change fullness at each step.
	*/
	protected void addEnergyNeeds() {
		changeEnergy(-getEnergyNeeds());
	}
	
	/**
	* Change animal's level of fat by a given amount. 
	* If it falls below zero, the animal will die.
	* @param n units of fat by which to change fatness
	*/
	protected void changeFatness(double n) {
		fatness += n;
		// Cannot store more fat
		if (fatness > getMaxFatness()) fatness = getMaxFatness();
		// The animal has starved
		if (fatness <= 0) {
			setDead();
		}
	}
	
	/**
	* Returns whether an animal should eat food that is within reach.
	* @return true if the animal should eat; false, if otherwise
	*/
	protected boolean isHungry() {
		return fullness <= getFullnessPoint();
	}
	
	//TODO
	protected boolean isWithinRadius(int squares) {
		return false;
	}

	//TODO
	protected boolean isSmallDistance() {
		return false;
	}
	
	//TODO
	protected boolean isMediumDistance() {
		return false;
	}
	
	/**
     * Returns true if an animal has reached the breeding age.
	 * @return true if an animal is old enough to breed; otherwise, false
     */
    protected boolean isPubescent() {
        return age >= getBreedingAge();
    }
    
	/**
	* Returns true if a male is near enough to breed with.
	* @return true if male is close enough to breed with; otherwise, false
	*/
    protected boolean pubescentMaleIsNear() {
		// Returns true if a male of the same species is adjacent
		return getAdjacentAnimals().stream().
			anyMatch(a->a.getSex().equals(Sex.MALE) && isSameSpecies(a) && !a.isDormant() && a.isPubescent());
    }
    
	/**
	* Returns true if this animal is female.
	* @return true if this animal is female; otherwise, false
	*/
    protected boolean isFemale() {
        return getSex() == Sex.FEMALE;
    }
    
	/**
	* Returns the sex of this animal.
	* @return the sex of this animal
	*/
    protected Sex getSex() {
        return sex;
    }
	
	/**
	* Returns true if this animal can give birth.
	* @return true if this animal can give birth; otherwise, false
	*/
    protected boolean canBirth() {
        return isFemale() && isPubescent() && pubescentMaleIsNear();
    }

	/**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int newOffspringSize() {
        int births = 0;
        if(getRandomizer().nextDouble() <= getFertility()) {
            births = getRandomizer().nextInt(getMaxOffspringSize() + 1);
        }
        return births;
    }

	/**
	* Return locations that are viable birth places.
	* @return locations that are viable birth places.
	*/
	protected List<Location> getSpawnLocations() {
		// New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        return field.getFreeAdjacentLocations(getLocation());
	}
	
	/**
	* Return a list of animals to be spawned at adjacent locations.
	* @return a list of newly born animals
	*/
	protected List<Animal> giveBirth() {
		List<Location> spawnLocs = getSpawnLocations();
		List<Animal> newAnimals = new ArrayList<>();
		int births = newOffspringSize();
        for(int i = 0; i < births && i < spawnLocs.size(); i++) {
            Location loc = spawnLocs.get(i);
			// Each animal born will decrease energy
			if (!willStarve(getReproductionEnergy())) {
				newAnimals.add(makeAnimal(field, loc, false));
				changeEnergy(-getReproductionEnergy());
			}
			else break;
        }
		// In case the number of actual births is lower than the potential offspring size
		return newAnimals;
	}
	
	/**
     * Check whether the animal is sick or not. 
     * 
     * @return true if the animal is sick, false otherwise
     */
    protected boolean isSick() {
        // animal is sick if sickSteps is greater than 0
        // if sickSteps animal is healthy
        return getSickSteps() > 0; 
    }

	/**
	 * Get number of steps 
	 * 
	 */
    protected int getSickSteps() { 
        return sickSteps;
    }
	
	/**
     * Change sick steps field by amount (as long as sickSteps remains >= 0)
     * @param sickSteps int amount of steps to change 
     */
    protected void changeSickSteps(int steps) {
        sickSteps += steps; 
		if (sickSteps < 0) {
			sickSteps = 0;
		}
	}
	
	/**
     * Decrease sick steps by 1 if animal is sick
     */
    protected void changeSickSteps() {
        if (isSick()) this.sickSteps--;
    }
	
	/**
     * Randomly choose a disease (can be no disease) and randomly choose if the animal becomes sick
     */
    protected void randomMakeSick() { 
        Disease disease = diseases.get(getRandomizer().nextInt(diseases.size()));
		if (!disease.isSpeciesSpecific() || (disease.getTargetAnimals() != null && disease.getTargetAnimals().contains(this.getClass().getName())))	
			randomMakeSick(disease);
    }
	
	/**
     * Randomly choose a disease (can be no disease) and randomly choose if the animal becomes sick
     * 
     * @param disease type of disease of animal to infect with 
     */
    protected void randomMakeSick(Disease disease) { 
        if (getRandomizer().nextDouble() < 0.01 * disease.getInfectivity()) { 
            changeSickSteps(disease.getSickStepsIncrease());
            diseaseType = disease; 
        }
    }
	
	/**
     * Infect surrounding animals with disease of animal 
     */
    protected void spreadSickness() {
        if (!isAlive()) return;
        
		getAdjacentAnimals().stream().forEach(a->a.randomMakeSick(diseaseType));
    }
	
	/**
	* Return a list of adjacent animals.
	* @return a list of adjacent animals
	*/
	protected List<Animal> getAdjacentAnimals() {
		List<Animal> animals = new ArrayList<>();
		getField().adjacentLocations(getLocation()).stream().
			filter(loc->getField().getObjectAt(loc) instanceof Animal).
			forEach(loc->animals.add((Animal) getField().getObjectAt(loc)));
		return animals;
	}
	
	 /**
     * This is what the animal does most of the time: it hunts for
     * prey. In the process, it might sleep, breed, die of hunger,
     * or die of old age.
	 * 
     * @return a list of newly-born animals
     */
    public List<Animal> act() {
		List<Animal> newAnimals = new ArrayList<>();
		
		// Change state on each step
        incrementAge();
        addEnergyNeeds();
		// Stop if dead or dormant
		if (!isAlive() || isDormant()) return newAnimals;
		
		//randomly make animal sick 
        changeSickSteps();
        randomMakeSick();
        spreadSickness();

        if (isSick()) sleep();
		
		if (Clock.getClock().isNewDay()) addSleepNeeds();
		if (isAsleep()) changeSleepiness(-1);
		
		if (!isAlive()) return newAnimals;
		
		//change sleep state as necessary
		if (mustSleep() || shouldSleep()) {
			if (!isAsleep()) sleep();
		} else {
			if (isAsleep()) wake();
		}
		if (!isAsleep()) {
            if (canBirth()) newAnimals = giveBirth();
			if (!isAlive()) return newAnimals;
            // Move towards a source of food if found.
            Location newLocation = findFood(getPrey());
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
		
		return newAnimals;
    }

	/**
	* Returns true if the animal must go to sleep whether in danger or not.
	*
	* @return true if the animal must sleep now; otherwise, false
	*/ 
	public boolean mustSleep() {
		return sleepiness > getSleepNeeds();
	}
	
	/**
	* Return true if an animal should sleep if it can, but does not apply when in immediate danger.
	*
	* @return true if an animal should sleep and is not in immediate danger.
	*/
	public boolean shouldSleep() {
		if ((field.isDay() && isNocturnal()) || 
		field.isNight() && isDiurnal()) {
			if (getSleepiness() > 0) return true;
		}
		return false;
	}
	
	/** 
	* Add daily change in sleepiness.
	*/
	public void addSleepNeeds() {
		if (Clock.getClock().isNewDay()) {
				sleepiness += getSleepNeeds();
		}
	}
	
	/**
	* Change this animal's sleepiness by an integer amount.
	*/
	protected void changeSleepiness(int n){
		sleepiness += n;
		// animals can die of sleep deprivation
		if (sleepiness > getMaxSleepiness()) {
			setDead();
		}
		// This should not happen
		else if (sleepiness < 0) {
			sleepiness = 0;
		}
	}
	
	/**
	* Return this animal's maximum sleep deprivation.
	* @return this animal's maximum sleep deprivation
	*/
	protected int getMaxSleepiness() {
		return MAX_SLEEPINESS;
	}
	
	/**
	* Return this animal's sleepiness (a gauge of its need to sleep).
	* @return sleepiness (a gauge of an animal's need to sleep)
	*/
	protected int getSleepiness() {
		return sleepiness;
	}
	
	/**
	* Return true if this animal sleeps during the day and is active at night.
	* @return true if this animal is active at night; otherwise, false
	*/ 
	protected boolean isNocturnal() {
		//simplification
		return !isDiurnal();	
	}
	
	/**
	* Put this animal to sleep.
	*/
	protected void sleep() {
		asleep = true;
	}
	
	/** 
	* Wake this animal up.
	*/
	protected void wake() {
		asleep = false;
	}
	
	/**
	* Return true if this animal is asleep.
	*
	* @return true if this animal is asleep; otherwise, false
	*/
	protected boolean isAsleep() {
		return asleep;
	}

	/**
     * Look for organisms adjacent to the current location.
     * Only the first live animal is eaten.
	 * 
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood(List<Class<? extends Organism>> prey)	{
        Field field = getField();
        List<Location> adjacent = field.getUsedAdjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Organism adjOrganism = (Organism) field.getObjectAt(where);
			for (Class<? extends Organism> p : prey) {
				if(adjOrganism.isSameSpecies(p)) {
					if(adjOrganism.isAlive() && this.isHungry()) { 
						adjOrganism.setDead();
						changeEnergy(adjOrganism.getEnergyValue());
						return where;
					}
				}
			}
        }
        return null;
    }
}
