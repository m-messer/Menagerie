import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a seal.
 * Seals age, move, eat, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Seal extends Animal {
    // Characteristics shared by all seals (class variables).
	
	// Parameters to change for different simulation outcomes
    // The age at which this animal can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which this animal can live.
    private static final int MAX_AGE = 50;
    // The likelihood of breeding.
    private static final double FERTILITY = 0.40;
    // The maximum number of births.
    private static final int MAX_OFFSPRING_SIZE = 3;
	// Sleep needs per 24-hour period
	private static final int SLEEP_NEEDS = 6;
	// How much fat this animal can store
	private static final double MAX_FATNESS = 60;
	// Fullness beyond this point is converted to fatness
	private static final double MAX_FULLNESS = 60;
	// How many energy units this animal needs each turn
	private static final double ENERGY_NEEDS = 0.8;
	// The fullness level below or equal to which an animal should eat
	private static final double FULLNESS_POINT = MAX_FULLNESS * 0.70;
	// Energy required to produce one offspring
	private static final double REPRODUCTION_ENERGY = 2;
	// Time for eggs to hatch; treater than 0 only if oviparous
	protected static final int DORMANCY_PERIOD = 0;
	
	// Constant characteristics of organism (should not be changed)
	// A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
	// If not diurnal, nocturnal
	private static final boolean DIURNAL = true;
	//Animals this animal can eat
	private static final List<Class<? extends Organism>> PREY = List.of(Krill.class, Penguin.class, Fish.class);

    /**
     * Create a seal. A seal can be created as a new born (age zero
     * and not hungry) or with a random age and energy level.
     * 
     * @param randomAge If true, the seal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seal(Field field, Location location, boolean randomAge) {
        super(field, location, randomAge);
    }

	//all set and get methods
	/** {@inheritDoc} */
	public int getBreedingAge() {
		return BREEDING_AGE;
	}
	/** {@inheritDoc} */
	public double getFertility() {
		return FERTILITY;
	}
	/** {@inheritDoc} */
	public double getReproductionEnergy() {
		return REPRODUCTION_ENERGY;
	}
	/** {@inheritDoc} */
	public int getMaxAge() {
		return MAX_AGE;
	}
	/** {@inheritDoc} */
	public int getSleepNeeds() {
		return SLEEP_NEEDS;
	}
	/** {@inheritDoc} */
	public int getMaxOffspringSize() {
		return MAX_OFFSPRING_SIZE;
	}
	/** {@inheritDoc} */
	public double getFullnessPoint() {
		return FULLNESS_POINT;
	}
	/** {@inheritDoc} */
	public double getMaxFatness() {
		return MAX_FATNESS;
	}
	/** {@inheritDoc} */
	public double getMaxFullness() {
		return MAX_FULLNESS;
	}
	/** {@inheritDoc} */
	public double getEnergyNeeds() {
		return ENERGY_NEEDS;
	}
	/** {@inheritDoc} */
	public boolean isDiurnal() {
		return DIURNAL;
	}
	/** {@inheritDoc} */
	protected int getDormancyPeriod() {
		return DORMANCY_PERIOD;
	}
	/** {@inheritDoc} */
	public List<Class<? extends Organism>> getPrey(){
		return PREY;
	}
	/** {@inheritDoc} */
	public Random getRandomizer() {
		return rand;
	}
	
	/**
	* Return an instance of this animal.
	* @return an instance of this animal.
	*/ 
	protected Animal makeAnimal(Field field, Location location, boolean randomAge) {
		return new Seal(field, location, randomAge);
	}
}

