import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Plant extends Organism implements Actor {
	
	// The plant's energy store, which is depleted at each step.
	protected double energyStore;
	
	/**
    * Create a new plant at location in field.
    * 
    * @param field    The field currently occupied.
    * @param location The location within the field.
	* @param randomAge True if spawned with random age.
	*/
	public Plant(Field field, Location location, boolean randomAge) {
		super(field, location, randomAge);
		energyStore = 0;
		
		if (randomAge) {
			energyStore = getRandomizer().nextDouble() * getMaxEnergyStore();
		}
		else // The plant has been produced
		{
			changeEnergy(getReproductionEnergy());
		}
	}

	/**
	* What a plant should do on each step.
	* @return A list of new plants
	*/
	public List<Plant> act() {
		List<Plant> newPlants = new ArrayList<>();
		
		// Change state on each step
		incrementAge();
		// Stop if dead or dormant
		if (isDormant() || !isAlive()) return newPlants;
        addEnergyNeeds();
		// Stop if dead 
		if (!isAlive()) return newPlants;
		
		photosynthesize();
		if (canReproduce()) newPlants = reproduce();

		return newPlants;
	}
	
	/**
	* Create and return a number of newly created plants.
	* @return a list of newly spawned plants
	*/
	protected List<Plant> reproduce() {
		Field field = getField();
		List<Location> spawnLocs = getSpawnLocations();
		List<Plant> newPlants = new ArrayList<>();
		int numPlants = newOffspringSize();
        for(int i = 0; i < numPlants && i < spawnLocs.size(); i++) {
            Location loc = spawnLocs.get(i);
			// Each plant born will decrease energy
			if (!willStarve(getReproductionEnergy())) {
				newPlants.add(makePlant(field, loc, false));
				changeEnergy(-getReproductionEnergy());
			}
			else break;
        }
		// In case the number of actual seeds is lower than the potential batch size
		return newPlants;
	}
	
	/**
	* Return locations that are viable spawn locations.
	* @return locations that are viable spawn locations.
	*/
	protected List<Location> getSpawnLocations() {
		// New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
		return field.getFreeAdjacentLocations(getLocation());
	}
	
	/**
	* Return the number of seeds to generate on each step.
	* @return the number of seeds to generate on each step
	*/
	protected int newOffspringSize() {
		int seeds = 0;
        if(getRandomizer().nextDouble() <= getFertility()) {
            seeds = getRandomizer().nextInt(getMaxOffspringSize() + 1);
        }
        return seeds;
	}
	
	/**
	* Return true if can reproduce.
	* @return true if can reproduce.
	*/
	protected boolean canReproduce() {
		return age >= getBreedingAge();
	}

	/**
	* Add energy needs for each step.
	*/
	public void addEnergyNeeds() {
		changeEnergy(-getEnergyNeeds());
	}
	
	/**
	* Change the plant's energy by a given amount.
	*/
	public void changeEnergy(double energy) {
		changeEnergyStore(energy);
	}
	
	/**
	* Increase energy store in proportion to irradiance, 
	* precipitation, and temperature. Photosynthesis is assumed to
	* be directly proportional to these variables.
	*/
	protected void photosynthesize() {
		assert isAlive() : "Dead plant attempts photosynthesis.";
		
		Weather weather = getField().getWeather();
		// Convert temperature to Kelvin to ensure energy is positive
		double temperatureKelvin = weather.getTemperature() + 273.15;
		double energy = weather.getIrradiance() * weather.getPrecipitation() * temperatureKelvin * 
		getLightMultiplier() * getPrecipitationMultiplier() * getTemperatureMultiplier();
		
		changeEnergy(energy);
	}
	
	/**
	* Change energy store by a given amount.
	* @param n amount by which to change energy store
	*/
	protected void changeEnergyStore(double n) {
		energyStore += n;
		// Energy in excess of maximum store capacity cannot be stored
		if (getEnergyStore() > getMaxEnergyStore()) {
			energyStore = getMaxEnergyStore();
		}
		// The plant starves
		else if (getEnergyStore() < 0) {
			setDead();
		}
	}
	
	/**
	* Return true if this plant can not yet act.
	* @return true if this plant can not yet act
	*/
	protected boolean isDormant() {
		// True if cannot survive current temperatures or not enough time to germinate
		return !canSurviveTemperature() || age < getDormancyPeriod();
	}
	
	/**
	* Return the total energy value of this plant.
	* @return the total energy value of this plant
	*/
	public double getEnergyValue() {
		return getEnergyStore();
	}

	/**
	* Return the energy store of this plant.
	* @return the energy store of this plant
	*/
	public double getEnergyStore() {
		return energyStore;
	}
	
	/**
	* Return the maximum energy a plant can store
	* @return maximum energy a plant can store
	*/
	public abstract double getMaxEnergyStore();
	
	/**
	* Return the energy depleted at each step
	* @return the energy depleted at each step
	*/
	public abstract double getEnergyNeeds();
	
	/** Return a mutiplier corresponding with how much photosynthesis is performed at a given irradiance.
	* @return gauge of photosynthesis performed at given irradiance
	*/
	public abstract double getLightMultiplier();
	
	/** Return a mutiplier that scales how much photosynthesis is performed at a given precipitation level.
	* @return gauge of photosynthesis performed at given precipitation level
	*/
	public abstract double getPrecipitationMultiplier();
	
	/** Return a mutiplier that scales how much photosynthesis is performed at a given temperature level.
	* @return gauge of photosynthesis performed at given temperature level
	*/
	public abstract double getTemperatureMultiplier();
	
	/**
	* Make a new plant of this class type.
	* @return Make a new plant of this class type
	*/
	protected abstract Plant makePlant(Field field, Location location, boolean randomAge);
	
	
}