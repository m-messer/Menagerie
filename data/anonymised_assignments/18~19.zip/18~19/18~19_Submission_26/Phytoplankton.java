import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a phytoplankton.
 * Phytoplanktons age, move, eat, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Phytoplankton extends Plant {
    // Characteristics shared by all phytoplankton (class variables).
	
	// Parameters to change for different simulation outcomes
    // The age at which this organism can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which this organism can live.
    private static final int MAX_AGE = 50;
    // The likelihood of breeding.
    private static final double FERTILITY = 0.56;
    // The maximum number of births.
    private static final int MAX_OFFSPRING_SIZE = 4;
	// How many energy units this organism needs each turn
	private static final double ENERGY_NEEDS = 2;
	// The maximum energy this plant can store
	private static final int MAX_ENERGY_STORE = 70;
	// How many steps are needed to germinate
	private static final int DORMANCY_PERIOD = 7;
	// Energy required to produce one offspring
	private static final double REPRODUCTION_ENERGY = 20;
	// How energy derived from photosynthesis scales with irradiance
	private static final double LIGHT_MULTIPLIER = 0.70;
	// How energy derived from photosynthesis scales with precipitation
	private static final double PRECIPITATION_MULTIPLIER = 0.42;
	// How energy derived from photosynthesis scales with temperature 
	private static final double TEMPERATURE_MULTIPLIER = 0.60;
	
	// A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a phytoplankton. A phytoplankton can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the phytoplankton will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Phytoplankton(Field field, Location location, boolean randomAge) {
        super(field, location, randomAge);
    }

	//all set and get methods
	/** {@inheritDoc} */
	public int getBreedingAge() {
		return BREEDING_AGE;
	}
	/** {@inheritDoc} */
	public double getFertility() {
		return FERTILITY;
	}
	/** {@inheritDoc} */
	public int getMaxAge() {
		return MAX_AGE;
	}
	/** {@inheritDoc} */
	public int getMaxOffspringSize() {
		return MAX_OFFSPRING_SIZE;
	}
	/** {@inheritDoc} */
	protected int getDormancyPeriod() {
		return DORMANCY_PERIOD;
	}
	/** {@inheritDoc} */
	public double getEnergyNeeds() {
		return ENERGY_NEEDS;
	}
	/** {@inheritDoc} */
	public double getLightMultiplier() {
		return LIGHT_MULTIPLIER;
	}
	/** {@inheritDoc} */
	public double getPrecipitationMultiplier() {
		return PRECIPITATION_MULTIPLIER;
	}
	/** {@inheritDoc} */
	public double getTemperatureMultiplier() {
		return TEMPERATURE_MULTIPLIER;
	}
	/** {@inheritDoc} */
	public double getMaxEnergyStore() {
		return MAX_ENERGY_STORE;
	}
	/** {@inheritDoc} */
	public double getReproductionEnergy() {
		return REPRODUCTION_ENERGY;
	}
	/** {@inheritDoc} */
	public Random getRandomizer() {
		return rand;
	}
	
	/**
	* Return an instance of this plant.
	* @return an instance of this plant.
	*/ 
	protected Plant makePlant(Field field, Location location, boolean randomAge) {
		return new Phytoplankton(field, location, randomAge);
	}
}

