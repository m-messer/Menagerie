public interface Tickable {
	
    /**
	* What a tickable does on each step.
	*/
    public void tick();
	
	/**
	* Reset a tickable to its initial state.
	*/
	public void reset();
}