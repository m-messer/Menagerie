class Clock implements Tickable {
	private int hours;
	//the unit of time to work in (currently, hours)
	private String unit;
	private static Clock INSTANCE = new Clock();

	/**
	* Create a new clock.
	*/
	public Clock() { 
		hours = 0;
	}

	/**
	* Return a clock instance.
	* @return a clock instance
	*/
	public static Clock newClock() {
		// INSTANCE = new Clock();
		return INSTANCE;
	}

	/**
	* Return a clock instance.
	* @return a clock instance
	*/
	public static Clock getClock() {
		return INSTANCE;
	}

	/**
	* Reset the clock to its starting position.
	*/
	public void reset() {
		hours = 0;
		// INSTANCE = new Clock();
	}

	/**
	* Return the hour of the day, using a 24 hour scheme.
	* @return the hour of the day
	*/
	public int getHourOfDay() {
		return hours%24;
	}

	/**
	* Return the number of days that have passed since the simulation began.
	* @return the number of days that have passed since the simulation began
	*/
	public int getDay() {
		return hours/24;
	}
	
	/**
	* Return the total number of hours.
	* @return the total number of hours
	*/
	public int getHours() {
		return hours;
	}
	
	/**
	* Return true if a new day begins on this hour
	* @return true if a new day begins on this hour.
	*/
	public boolean isNewDay() {
		return getHourOfDay() == 0;
	}

	/**
	* Pass a number of units of hours.
	* @param numHours number of hours to 
	*/
	public void tickHour(long numHours) {
		hours += numHours;
	}

	/**
	* Pass one unit of time.
	*/ 
	public void tick() {
		tickHour(1);
	}

}