import java.lang.Math;
import java.util.Random;

public class Weather implements Tickable {
    // weather information
    private double currentTemperature;
    private double sunlightPercentage;
    private double precipitationPercentage;
    
    // Default median temperature (degrees Celsius)
    private double baseTemp = -30;
    // Default maximum temperature fluctuation from the base (degrees Celsius)
    private double tempFluctuation = 15;

    private static final Random rand = Randomizer.getRandom();

	/**
	* Initialize a Weather object.
	* Weather objects simulate weather conditions such as sunlight,
	* precipitation, and temperature.
	*/
    public Weather() {

        // initialize weather information
        updateWeather(0);
    }

    /**
	* Initialize a Weather object.
	* Weather objects simulate weather conditions such as sunlight,
    * precipitation, and temperature.
    *
    * @param baseTemp the median temperature (a sine wave is added to this temperature)
    * @param tempFluctuation the deviation from the median temperature 
	*/
    public Weather(double baseTemp, double tempFluctuation) {

        // initialize weather information
        updateWeather(0);

        this.baseTemp = baseTemp;
        this.tempFluctuation = tempFluctuation;
    }
	
	/**
	* Use the clock to update the weather on each tick.
	*/
	public void tick() {
		updateWeather(Clock.getClock().getHours());
	}
	
	/**
	* Reset the weather conditions.
	*/
	public void reset() {
		updateWeather(0);
	}

    /**
    * Update weather fields.
    * @param step The current step of the simulation.
    */
    public void updateWeather(double step) {
        updateCurrentTemperature(step);
        updateSunlightPercentage(step);
        updatePrecipitationPercentage(step);
    }

    /**
	* Return the current temperature.
    * @return double Current temperature
    */
    public double getTemperature() {
        return currentTemperature;
    }

    /**
	* Return the current percentage of sunlight.
    * @return sunlight percentage
    */
    public double getIrradiance() {
        return sunlightPercentage;
    }

    /**
	* Return the current percentage of precipitation.
    * @return precipitation percentage
    */
    public double getPrecipitation() {
        return precipitationPercentage;
    }

    /**
    * Update current temperature based on step of simulation.
    * @param step The current step of the simulation.
    */
    public void updateCurrentTemperature(double step) {
        double angle = Math.toRadians(step);
        double randomAngleDeviation = Math.toRadians(generateRandomStepDeviation(0, 10));

        currentTemperature = baseTemp + tempFluctuation * Math.sin(angle + randomAngleDeviation);
    }

    /**
    * Update sunlight percentage based on step of simulation.
    * @param step The current step of the simulation.
    */
    public void updateSunlightPercentage(double step) {
        double angle = Math.toRadians(step);
        double randomAngleDeviation = Math.toRadians(generateRandomStepDeviation(-10, 10));

        sunlightPercentage = 0.5 * Math.toRadians(angle + randomAngleDeviation) + 0.5;
    }

    /**
    * Update precipitation percentage based on step of simulation.
    * @param step The current step of the simulation.
    */
    public void updatePrecipitationPercentage(double step) {
        double angle = Math.toRadians(step);
        double randomAngleDeviation = Math.toRadians(generateRandomStepDeviation(-10, 10));

        precipitationPercentage = 0.5 * Math.toRadians(angle + randomAngleDeviation) + 0.5;
    }

    /**
    * Generate a random step deviation in range [min,max].
    * @param min Minimum angle deviation (units: simulation steps).
    * @param max Maximum angle deviation (units: simulation steps).
    */
    private double generateRandomStepDeviation(double min, double max) {
        return min + (max - min) * rand.nextDouble();
    }
}