import java.awt.*;
import java.awt.event.*;
import java.awt.Image.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;
import java.util.stream.*;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2016.02.29
 */
public class SimulatorView extends JFrame
{
	// Recommended for serialization of this class
	private static final long serialVersionUID = 74L;
	
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private JLabel stepLabel, population, infoLabel;
    private FieldView fieldView;
	
	// The state of the simulation; these fields are manipulated by button actionListeners
	private boolean paused;
	private boolean reset;
	private static final int DELAY_CHANGE = 10;
	private int delayTime = 0;
	
	// Determines whether icons are enabled
	private boolean iconsToggled = false;

	// The paths of local files used as image icons
	private final Map<String, String> iconFiles = Map.of("pause", "img/pause2.png",
												"play", "img/play2.png",
												"reset", "img/reset2.png",
												"faster", "img/faster.png",
												"slower", "img/slower.png",
												"Penguin", "img/penguin1.png",
												"Fish", "img/fish1.png",
												"Seal", "img/seal1.png",
												"Krill", "img/krill1.png"
												// "Phytoplankton", "img/plankton1.png"
												);
	
	// The paths of local files used as image icons
	private final Map<String, ImageIcon> icons = Map.of("pause", new ImageIcon(iconFiles.get("pause")),
												"play", new ImageIcon(iconFiles.get("pause")),
												"reset", new ImageIcon(iconFiles.get("pause")),
												"faster", new ImageIcon("img/faster.png"),
												"slower", new ImageIcon("img/slower.png"),
												"Penguin", new ImageIcon(iconFiles.get("Penguin")),
												"Fish", new ImageIcon(iconFiles.get("Fish")),
												"Seal", new ImageIcon(iconFiles.get("Seal")),
												"Krill", new ImageIcon(iconFiles.get("Krill"))
												// "Phytoplankton", new ImageIcon(iconFiles.get("Phytoplankton"))
												);
												
	// A map of organism names to their corresponding classes; used by the JComboBoxes
	private final Map<String, Class<? extends Organism>> organismClasses = Map.of("penguin", Penguin.class,
																			"fish", Fish.class,
																			"seal", Seal.class,
																			"krill", Krill.class,
																			"phytoplankton", Phytoplankton.class);
	
	// The organism currently selected in the inputPanel (controlled by organismJCBox)
	private Class<? extends Organism> selectedOrganism;
    
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;
	
	// Auxiliary panel to the right of the field view
	private JPanel inputPanel;
	private boolean keyPanelPresent = false;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    // public SimulatorView(int height, int width)
    public SimulatorView(int height, int width, Object sink)
	//sink is a synchronized object used to suspend thread execution of simulation
    {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Antarctic Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

		// Control button icon width and height
		int ctrlIconWidth = 60;
		int ctrlIconHeight = 60;
		
		//Text labels for control buttons
		String playText = "PLAY";
		String pauseText = "PAUSE";
		String resetText = "RESET";
		String fasterText = "FASTER";
		String slowerText = "SLOWER";
		String iconsText = "TOGGLE ICONS";
		
		//Icons for buttons are local files
		ImageIcon pauseIcon = getScaledIcon(new ImageIcon(iconFiles.get("pause")), ctrlIconWidth, ctrlIconHeight);
		ImageIcon playIcon = getScaledIcon(new ImageIcon(iconFiles.get("play")), ctrlIconWidth, ctrlIconHeight);
		ImageIcon resetIcon = getScaledIcon(new ImageIcon(iconFiles.get("reset")), ctrlIconWidth, ctrlIconHeight);
		ImageIcon fasterIcon = getScaledIcon(new ImageIcon(iconFiles.get("faster")), ctrlIconWidth, ctrlIconHeight);
		ImageIcon slowerIcon = getScaledIcon(new ImageIcon(iconFiles.get("slower")), ctrlIconWidth, ctrlIconHeight);
		
		// Make labels for control buttons
		// JLabel pauseLabel = new JLabel(pauseText, pauseIcon, JLabel.CENTER);
		// JLabel playLabel = new JLabel(playText, playIcon, JLabel.CENTER);
		// JLabel resetLabel = new JLabel(resetText, resetIcon, JLabel.CENTER);
		// JLabel iconsLabel = new JLabel(iconsText);
		
		JToggleButton pausePlayBtn = new JToggleButton(pauseText, pauseIcon);
		JToggleButton iconsToggleBtn = new JToggleButton(iconsText);
		JButton resetBtn = new JButton(resetText, resetIcon);
		JButton fasterBtn = new JButton(fasterText, fasterIcon);
		JButton slowerBtn = new JButton(slowerText, slowerIcon);
		
		//Play/pause simulation on pressing the play/pause button
		pausePlayBtn.addActionListener(e->{
			if (pausePlayBtn.isSelected()) {
				pausePlayBtn.setText(playText);
				pausePlayBtn.setIcon(playIcon);
				paused = true;
				
				// wake up the main thread
				synchronized(sink) {
					sink.notifyAll();
				}
			} else {
				pausePlayBtn.setText(pauseText);
				pausePlayBtn.setIcon(pauseIcon);
				paused = false;
				
				// wake up the main thread
				synchronized(sink) {
					sink.notifyAll();
				}
			}
		});
		
		// Reset the simulation on pressing this button
		resetBtn.addActionListener(e->{
			reset = true;
			synchronized(sink) {
				sink.notifyAll();
			}
		});

		fasterBtn.addActionListener(e->{
			delayTime -= DELAY_CHANGE;
			if (delayTime < 0) delayTime = 0;
		});

		slowerBtn.addActionListener(e->{
			delayTime += DELAY_CHANGE;
		});
		
		// Toggle icons to represent the organisms
		iconsToggleBtn.addActionListener(e->{
			iconsToggled = !iconsToggled;
		});
		
		setLocation(100, 50);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        fieldView = new FieldView(height, width);

        Container contents = getContentPane();
		
        JPanel infoPane = new JPanel(new BorderLayout());
            infoPane.add(stepLabel, BorderLayout.WEST);
            infoPane.add(infoLabel, BorderLayout.CENTER);
			infoPane.add(population, BorderLayout.SOUTH);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        // contents.add(population, BorderLayout.SOUTH);
		
		//add control buttons
		JPanel btnPane = new JPanel(new FlowLayout());
		btnPane.add(slowerBtn);
		btnPane.add(pausePlayBtn);
		btnPane.add(resetBtn);
		btnPane.add(fasterBtn);
		btnPane.add(iconsToggleBtn);
		contents.add(btnPane, BorderLayout.SOUTH);
		
		//Panel to the right dispaying all parameter options
		inputPanel = new JPanel();
		BoxLayout inputLayout = new BoxLayout(inputPanel, BoxLayout.Y_AXIS);
		inputPanel.setLayout(inputLayout);
		
		//Make organism drop-down menu
		// String[] organisms = {"Fish", "Penguin"};
		// A Vector can be used to instantiate a JComboBox
		JComboBox<String> organismJCBox = new JComboBox<String>(new Vector<String>(organismClasses.keySet()));
		organismJCBox.setMaximumSize(new Dimension(150,30));
		inputPanel.add(organismJCBox);
		
		//Adding parameter drop-down menus
		JComboBox<Object> breedingAgeJCBox = new JComboBox<Object>(IntStream.range(0,10).boxed().toArray());
		
		JComboBox<Object> fertilityJCBox = new JComboBox<Object>(DoubleStream.iterate(0, x->x+=0.05).
		map(x->Math.round(x*100)/100.0).limit(101).boxed().toArray());
		
		JComboBox<Object> maxHungerJCBox = new JComboBox<Object>(IntStream.range(0,10).boxed().toArray());
		
		JComboBox<Object> maxAgeJCBox = new JComboBox<Object>(IntStream.range(0,10).boxed().toArray());
		
		JComboBox<Object> maxLitterSizeJCBox = new JComboBox<Object>(DoubleStream.iterate(0, x->x+=0.05).
		map(x->Math.round(x*100)/100.0).limit(101).boxed().toArray());
		
		JComboBox<Object> foodValueJCBox = new JComboBox<Object>(DoubleStream.iterate(0, x->x+=0.05).
		map(x->Math.round(x*100)/100.0).limit(101).boxed().toArray());
		
		JComboBox<Object> sleepNeedsJCBox = new JComboBox<Object>(DoubleStream.iterate(0, x->x+=0.05).
		map(x->Math.round(x*100)/100.0).limit(101).boxed().toArray());
		
		//Make a panel for each parameter and add to the inputPanel
		JPanel breedingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		breedingPanel.setMaximumSize(new Dimension(150,40));
		breedingPanel.add(new JLabel("Breeding age: "));
		breedingPanel.add(breedingAgeJCBox);
		inputPanel.add(breedingPanel);
		
		JPanel fertilityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		fertilityPanel.setMaximumSize(new Dimension(150,40));
		fertilityPanel.add(new JLabel("Fertility: "));
		fertilityPanel.add(fertilityJCBox);
		inputPanel.add(fertilityPanel);
		
		JPanel maxHungerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		maxHungerPanel.setMaximumSize(new Dimension(150,40));
		maxHungerPanel.add(new JLabel("Max hunger: "));
		maxHungerPanel.add(maxHungerJCBox);
		inputPanel.add(maxHungerPanel);
		
		JPanel maxAgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		maxAgePanel.setMaximumSize(new Dimension(150,40));
		maxAgePanel.add(new JLabel("Max age: "));
		maxAgePanel.add(maxAgeJCBox);
		inputPanel.add(maxAgePanel);
		
		JPanel maxLitterSizePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		maxLitterSizePanel.setMaximumSize(new Dimension(150,40));
		maxLitterSizePanel.add(new JLabel("Max litter size: "));
		maxLitterSizePanel.add(maxLitterSizeJCBox);
		inputPanel.add(maxLitterSizePanel);
		
		JPanel foodValuePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		foodValuePanel.setMaximumSize(new Dimension(150,40));
		foodValuePanel.add(new JLabel("Food value: "));
		foodValuePanel.add(foodValueJCBox);
		inputPanel.add(foodValuePanel);
		
		JPanel sleepNeedsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		sleepNeedsPanel.setMaximumSize(new Dimension(150,40));
		sleepNeedsPanel.add(new JLabel("Sleep needs: "));
		sleepNeedsPanel.add(sleepNeedsJCBox);
		inputPanel.add(sleepNeedsPanel);
		
		
		// Unimplemented functionality to change organism parameters from the drop-down lists
		// Class<? extends Organism> selectedOrganism = organismClasses.get((String)organismJCBox.getSelectedItem());
		selectedOrganism = organismClasses.get((String)organismJCBox.getSelectedItem());
		
		// organismJCBox.addActionListener(e->{
			// selectedOrganism = organismClasses.get((String)organismJCBox.getSelectedItem());//??		
		// });
		
		// breedingAgeJCBox.addItemListener(it->{
			// try {
				// System.out.println(it.getItem());//DEBUG
				// selectedOrganism.getDeclaredMethod("setBreedingAge", int.class).invoke(null, it.getItem());
			// } catch (Exception e) {
				// e.printStackTrace();
			// }
		// });
		
		contents.add(inputPanel, BorderLayout.EAST);
		
        pack();
        setVisible(true);
    }
	
	/**
	* Add a key panel mapping organism classes to color.
	*/
	private void addKeyPanel(JPanel containerPanel) {
		//ROUGH key panel functionality
		JLabel sealLabel = new JLabel("Seal");
		sealLabel.setForeground(getColor(Seal.class));
		JLabel fishLabel = new JLabel("Fish");
		sealLabel.setForeground(getColor(Fish.class));
		JLabel penguinLabel = new JLabel("Penguin");
		penguinLabel.setForeground(getColor(Penguin.class));
		JLabel planktonLabel = new JLabel("Phytoplankton");
		planktonLabel.setForeground(getColor(Phytoplankton.class));
		JLabel krillLabel = new JLabel("Krill");
		krillLabel.setForeground(getColor(Krill.class));
		
		JPanel keyPanel = new JPanel();
		containerPanel.add(keyPanel, BorderLayout.WEST);
		BoxLayout keyLayout = new BoxLayout(keyPanel, BoxLayout.PAGE_AXIS);
		
		keyPanel.setLayout(keyLayout);
		keyPanel.add(new JLabel("KEY"));
		keyPanel.add(sealLabel);
		keyPanel.add(fishLabel);
		keyPanel.add(penguinLabel);
		keyPanel.add(planktonLabel);
		keyPanel.add(krillLabel);
		inputPanel.add(keyPanel);
		
		keyPanelPresent = true;
	}

	/**
	* Return current time delayed between each step
	* @return current delay time
	*/
	public int getDelayTime() {
		return delayTime;
	}

	/**
	* Set delay time.
	* @param time delay time to set.
	*/
	public void setDelayTime(int time) {
		delayTime = time;
		if (delayTime < 0) delayTime = 0;
	}
	
	/**
	* Return true if simulation is paused.
	* @return true if simulation is paused
	*/
	public boolean isPaused() {
		return paused;
	}
	
	/**
	* Return true if reset button has been pressed on this round.
	* @return true if reset button has been pressed on this round
	*/
	public boolean isReset() {
		return reset;
	}
	
	/**
	* Toggle reset field to indicate whether simulation has just been reset or not.
	*/
	public void toggleReset() {
		reset = !reset;
	}
	
	/**
	* Resets if r is 1 and unresets if r is 0; otherwise, does nothing
	* @param r value to set reset to
	*/
	public void toggleReset(int r) {
		if (r==0) reset = false;
		else if (r==1) reset = true;
	}
	
	/**
	* Return an icon, scaled according to width and height, from a given icon.
	* @param imgIcon icon to scale
	* @param width width to scale to
	* @param height height to scale to
	* @return a scaled version of given icon
	*/
	private ImageIcon getScaledIcon(ImageIcon imgIcon, int width, int height) {
		Image img = imgIcon.getImage().getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH);
		return new ImageIcon(img);
	}
    
    /**
     * Define a color to be used for a given class of organism.
     * @param organismClass The organism's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class organismClass, Color color)
    {
        colors.put(organismClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of organism.
     */
    private Color getColor(Class organismClass)
    {
        Color col = colors.get(organismClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }
	
	/**
	* Return an unscaled image icon to represent the given organism class.
	* @param organismClass the class of organism whose icon should be returned
	* @return an unscaled image icon
	*/
	private ImageIcon getClassIcon(Class organismClass) {
		// return new ImageIcon(iconFiles.get(organismClass.getName()));
		return icons.get(organismClass.getName());
	}
	
	/**
	* Return a scaled image icon to represent the given organism class.
	* @param organismClass the class of organism whose icon should be returned
	* @return a scaled image icon
	*/
	private ImageIcon getClassIcon(Class organismClass, int width, int height) {
		// return getScaledIcon(new ImageIcon(iconFiles.get(organismClass.getName())), width, height);
		return getScaledIcon(icons.get(organismClass.getName()), width, height);
	}
	
	/**
	* Check if a class of organism has an icon specified in the icons map.
	* @param organismClass the class of organism whose icon's presence is to be checked
	*/
	private boolean hasClassIcon(Class organismClass) {
		return icons.get(organismClass.getName()) != null;
	}

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }
            
        stepLabel.setText(STEP_PREFIX + step);
        stats.reset();
        
        fieldView.preparePaint();

         for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object organism = field.getObjectAt(row, col);
                if(organism != null) {
                    stats.incrementCount(organism.getClass());
                    if (hasClassIcon(organism.getClass()) && iconsToggled)
						fieldView.drawMark(col, row, getClassIcon(organism.getClass()));
					else 
						fieldView.drawMark(col, row, getColor(organism.getClass()));
                }
                else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + "    " + stats.getPopulationDetails(field));
		// if (!keyPanelPresent) addKeyPanel(inputPanel);
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
		// Supports serialization of this class
		private static final long serialVersionUID = 86L;
		
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                                 gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }
		
		/**
		* Draw an icon at the grid location on this field, and add color in the background.
		*/ 
		public void drawMark(int x, int y, ImageIcon icon, Color color) {
			g.drawImage(icon.getImage(), x * xScale, y * yScale, xScale-1, yScale-1, color, null);
		}
		
		/**
		* Draw an icon at the grid location on this field.
		*/ 
		public void drawMark(int x, int y, ImageIcon icon) {
			g.drawImage(icon.getImage(), x * xScale, y * yScale, xScale-1, yScale-1, null);
		}

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
