import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * A rainforest predator-prey simulator, based on a rectangular field
 * containing animals and plants.
 *
 * @version 2019.02.19 (3)
 */
public class Simulator
{
	// Constants representing configuration information for the simulation.
	// The default width for the grid.
	private static final int DEFAULT_WIDTH = 180;
	// The default depth of the grid.
	private static final int DEFAULT_DEPTH = 120;
	// The probability that a Caiman will be created in any given grid position.
	private static final double CAIMAN_CREATION_PROBABILITY = 0.08;
	// The probability that a Jaguar will be created in any given grid position.
	private static final double JAGUAR_CREATION_PROBABILITY = 0.08;
	// The probability that a tapir will be created in any given grid position.
	private static final double TAPIR_CREATION_PROBABILITY = 0.24;    
	// The probability that a plant will be created in any given grid position.
	private static final double GORILLA_CREATION_PROBABILITY = 0.2;
	// The probability that a plant will be created in any given grid position.
	private static final double PUMA_CREATION_PROBABILITY = 0.1;
	// The probability that a plant will be created in any given grid position.
	private static final double BAMBOO_CREATION_PROBABILITY = 0.08; 
	// The probability that a plant will be created in any given grid position.
	private static final double ACAI_CREATION_PROBABILITY = 0.08;
	// The probability that a plant will be created in any given grid position.
	private static final double BANYANS_CREATION_PROBABILITY = 0.08;


	// List of animals in the field.
	private List<Animal> animals;
	// List of plants in the field.
	private List<Plant> plants;
	// List of viruses in the field.
	private List<Virus> virus;
	// List of highways in the field.
	private List<Highway> highways;

	// The current state of the field.
	private Field field;
	// The current step of the simulation.
	private int step;
	// A graphical view of the simulation.
	private SimulatorView view;

	// Create an object that stores the weather conditions
	private Weather weather;

	// Random number for the col location of the highway
	Random random = new Random();
	private int randomIntForHighway = 0;

	/**
	 * Construct a simulation field with default size.
	 */
	public Simulator()
	{
		this(DEFAULT_DEPTH, DEFAULT_WIDTH);
	}

	/**
	 * Create a simulation field with the given size.
	 * @param depth Depth of the field. Must be greater than zero.
	 * @param width Width of the field. Must be greater than zero.
	 */
	public Simulator(int depth, int width)
	{
		if(width <= 0 || depth <= 0) {
			System.out.println("The dimensions must be greater than zero.");
			System.out.println("Using default values.");
			depth = DEFAULT_DEPTH;
			width = DEFAULT_WIDTH;
		}

		animals = new ArrayList<>();
		plants = new ArrayList<>();
		virus = new ArrayList<>();
		highways = new ArrayList<>();

		field = new Field(depth, width);

		weather = new Weather(random.nextBoolean(), 15, true);

		// Create a view of the state of each location in the field.
		view = new SimulatorView(depth, width, weather);
		view.setlocation( (int)(Math.random() * ((1000) + 1)), (int)(Math.random() * ((1000) + 1)));
		view.setColor(Highway.class, new Color(0,255,230));
		view.setColor(Tapir.class, Color.black);
		view.setColor(Jaguar.class, Color.orange);
		view.setColor(Caiman.class, new Color(255, 0, 255));
		view.setColor(Bamboo.class, new Color(0, 204, 102));
		view.setColor(Acai.class, new Color(230,230,250));
		view.setColor(Banyans.class, new Color(139, 69, 19));
		view.setColor(Gorilla.class, new Color(153, 0, 0));
		view.setColor(Puma.class, new Color(0,204, 204));

		// Random col for the highway to be built in
		randomIntForHighway = random.nextInt((field.getWidth() - 0) + 1);
		reset();
	}

	/**
	 * Run the simulation from its current state for a reasonably long period,
	 * (4000 steps).
	 */
	public void runLongSimulation()
	{
		simulate(4000);
	}

	/**
	 * Run the simulation from its current state for the given number of steps.
	 * Stop before the given number of steps if it ceases to be viable.
	 * @param numSteps The number of steps to run for.
	 */
	public void simulate(int numSteps)
	{
		for(int step = 1; step <= numSteps && view.isViable(field); step++) {
			simulateOneStep();
			delay(30);   // uncomment this to run more slowly
		}
	}

	/**
	 * Run the simulation from its current state for a single step.
	 * Iterate over the whole field updating the state of each
	 * animal.
	 */
	public void simulateOneStep()
	{
		step++;

		// Provide space for newborn animals.
		List<Animal> newAnimals = new ArrayList<>(); 
		// Provide space for newborn plants.
		List<Plant> newPlants = new ArrayList<>();

		//move animals
		for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
			Animal animal = it.next();
			animal.act(newAnimals);
			if(! animal.isAlive()) {
				it.remove();
			}

		}

		//make plants act
		for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
			Plant plant = it.next();
			plant.act(newPlants);
			if(! plant.isAlive()) {
				it.remove();
			}
		}

		for(int i = 0; i < newAnimals.size(); i++) {
			newAnimals.get(i).setVirus(getVirus());
		} 

		// Add the newly born animals and plants to the main lists.
		animals.addAll(newAnimals);
		plants.addAll(newPlants);
		view.showStatus(step, field);

		//Randomly change rain state every day
		if(step%14==0) {
			weather.setIsraining(random.nextBoolean());
			double currenttemp = weather.getTemp();
			double min = currenttemp - 4;
			double max = currenttemp + 4;

			// Set boundaries for the temperature
			if(min<15) {
				min = 15;
			}
			if(max>35) {
				max = 35;
			}

			// Make the temperature change slowly
			weather.setTemp(min + (max - min) * random.nextDouble());
		}
		if(!view.isViable(field)) {

		}

		//Build a highway in a random location in the field if button pressed by user
		view.addHighway.addMouseListener(new CustomMouseListener());
		view.destroyHighway.addMouseListener(new CustomMouseListenerremove());

	}

	/**
	 * Reset the simulation to a starting position.
	 */
	public void reset()
	{
		step = 0;
		animals.clear();
		plants.clear();
		virus.clear();
		highways.clear();
		populate();

		// Show the starting state in the view.
		view.showStatus(step, field);
	}

	/**
	 * Create a highway in the field at a random location vertically
	 */
	private void highway() {

		int col = randomIntForHighway;
		int height = field.getDepth();
		
		
		for(int row = 0; row < height; row++) {
			for(int i = 0; i < 2 ; i ++) {
				
				Location location = new Location(row, col+i);
				if(field.getObjectAt(location) instanceof Animal) {
					Animal temp = (Animal) field.getObjectAt(location);
					temp.setDead();
				}
				if(field.getObjectAt(location) instanceof Plant) {
					Plant temp = (Plant) field.getObjectAt(location);
					temp.setDead();
				}
				Highway highway = new Highway(field, location, view);
				highways.add(highway);

			}
		}
	}

	/**
	 * Remove all highways on button click
	 */
	private void removehighway() {
		for(int i = 0; i < highways.size(); i ++) {
			highways.get(i).removeHighway(highways.get(i).getLocation());
		}
		highways.clear();
	}

	/**
	 * Randomly populate the field with animals and plants, generate viruses.
	 */
	private void populate()
	{
		Random rand = Randomizer.getRandom();
		field.clear();
		virus.clear();
		//generate 1 type of virus
		for(int i = 0; i < 1; i ++) { 	
			Virus tempVirus = new Virus(true, 1, 0.5, rand.nextDouble()-0.6, "Virus"+virus.size()); // we subtract from the origin probability to make spawn less likely

			virus.add(tempVirus); // add virus to global list
		}


		for(int row = 0; row < field.getDepth(); row++) {
			for(int col = 0; col < field.getWidth(); col++) {
				Virus generated = getVirus(); 
				if(rand.nextDouble() <= CAIMAN_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Caiman caiman = new Caiman(true, field, location, view);
					//caiman.setVirus(getvirus());
					if(caiman.isMale()) {
						view.setColor(caiman, new Color(255,102,178));
					}
					animals.add(caiman);
				}
				else if(rand.nextDouble() <= TAPIR_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Tapir tapir = new Tapir(true, field, location, view);
					//tapir.setVirus(getvirus());
					if(tapir.isMale()) {
						view.setColor(tapir, Color.gray);
					}
					animals.add(tapir);
				}
				else if(rand.nextDouble() <= JAGUAR_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Jaguar jaguar = new Jaguar(true, field, location, view);
					//jaguar.setVirus(getvirus());
					if(jaguar.isMale()) {
						view.setColor(jaguar, Color.orange);
					}
					animals.add(jaguar);
				}
				else if(rand.nextDouble() <= BANYANS_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Banyans banyans = new Banyans(field, location, view);
					//banyans.setvirus(getvirus());
					plants.add(banyans);
				}
				else if(rand.nextDouble() <= GORILLA_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Gorilla gorilla = new Gorilla(true, field, location, view);
					//gorilla.setVirus(getvirus());
					if(gorilla.isMale()) {
						view.setColor(gorilla, new Color(255, 153, 153));
					}
					animals.add(gorilla);
				}
				else if(rand.nextDouble() <= PUMA_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Puma puma = new Puma(true, field, location, view);
					//puma.setVirus(getvirus());
					if(puma.isMale()) {
						view.setColor(puma, new Color(0, 102, 204));
					}
					animals.add(puma);
				}
				else if(rand.nextDouble() <= BAMBOO_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Bamboo bamboo = new Bamboo(field, location, view);
					//bamboo.setvirus(getvirus());
					plants.add(bamboo);
				}
				else if(rand.nextDouble() <= ACAI_CREATION_PROBABILITY) {
					Location location = new Location(row, col);
					Acai acai = new Acai(field, location, view);
					//acai.setvirus(getvirus());
					plants.add(acai);
				}

				// else leave the location empty.
			}
		}
	}

	/**
	 * Get a virus if any is formed
	 * @return null or a virus if the random number generated
	 * is less than or equal to the probability of a virus forming
	 */
	private Virus getVirus() {
		Random rand = Randomizer.getRandom();
		boolean virusSpawned = false;
		int x = 0;
		Virus toReturn = null;

		while(!virusSpawned && x < virus.size()) {

			if(rand.nextDouble() <= virus.get(x).getORIGIN_PROBABILITY() || (this.weather.getTemp() < 20 && rand.nextDouble() <= virus.get(x).getORIGIN_PROBABILITY()+0.3) ){
				virusSpawned = true;
				toReturn = virus.get(x);
			}
			x++;
		}
		return toReturn;
	}


	/**
	 * Pause for a given time.
	 * @param millisec  The time to pause for, in milliseconds
	 */
	private void delay(int millisec)
	{
		try {
			Thread.sleep(millisec);
		}
		catch (InterruptedException ie) {
			// wake up
		}
	}

	/**
	 * Nested class implementation of MouseListener for the buttons
	 * to create or remove a highway.
	 *
	 *
	 */
	class CustomMouseListener implements MouseListener{

		public void mouseClicked(MouseEvent e) {
			highway();
		}   

		public void mousePressed(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}
	}

	class CustomMouseListenerremove implements MouseListener{

		public void mouseClicked(MouseEvent e) {
			removehighway();
		}   

		public void mousePressed(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}
	}
}
