import java.util.List;
import java.awt.Color;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Jaguar.
 * Jaguars age, move, eat animals, and die.
 * Jaguars eat all other animals in the field
 * @version 2019.02.08 (2)
 */
public class Jaguar extends Animal
{
	// Characteristics shared by all Jaguars (class variables).

	// The age at which a Jaguar can start to breed.
	private static final int BREEDING_AGE = 6;
	// The age to which a Jaguar can live.
	private int MAX_AGE = 135;
	// The likelihood of a Jaguar breeding.
	private static final double BREEDING_PROBABILITY = 0.15;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 8;
	// The food value of a single animal. In effect, this is the
	// number of steps a Jaguar can go before it has to eat again.
	private static final int TAPIR_FOOD_VALUE = 20;
	private static final int CAIMAN_FOOD_VALUE = 18;
	private static final int GORILLA_FOOD_VALUE = 15;
	private static final int PUMA_FOOD_VALUE = 7;
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();
	// A shared random number generator to control breeding.


	// Individual characteristics (instance fields).
	// The Jaguar's age.
	private int age;
	// The Jaguar's food level, which is increased by eating animals.
	private int foodLevel;

	/**
	 * Create a Jaguar. A Jaguar can be created as a new born (age zero
	 * and not hungry) or with a random age and food level.
	 * 
	 * @param randomAge If true, the Jaguar will have random age and hunger level.
	 * @param field The field currently occupied.
	 * @param location The location within the field.
	 */
	public Jaguar(boolean randomAge, Field field, Location location,SimulatorView view)
	{
		super(field, location, view);
		if(randomAge) {
			age = rand.nextInt(MAX_AGE);
			foodLevel = rand.nextInt(CAIMAN_FOOD_VALUE);
		}
		else {
			age = 0;
			foodLevel = CAIMAN_FOOD_VALUE;
		}
	}

	/**
	 * This is what the Jaguar does most of the time: it hunts for
	 * animals. In the process, it might breed, sleep, die of hunger,
	 * or die of old age.
	 * @param field The field currently occupied.
	 * @param newJaguars A list to return newly born Jaguars.
	 */
	public void act(List<Animal> newJaguars)
	{
		incrementAge();
		incrementHunger();
		if(isAlive()) {
			Location newLocation = null;
			giveBirth(newJaguars);   
			if(this.getVirus()!=null) {
				maxAgeDecrease(this.getVirus().getVIRUS_DANGER());
			}
			if(this.getview().getweather().isIsDay()) {
				// Try to move towards a source of food if it is day
				newLocation = findFood();
			}
			if(newLocation == null) { 
				// No food found or it is night - try to move to a free location.
				newLocation = getField().freeAdjacentLocation(getLocation());
			}
			// See if it was possible to move.
			if(newLocation != null) {
				setLocation(newLocation);
			}
			else {
				// Overcrowding.
				setDead();
			}
		}
	}

	/**
	 * Increase the age. This could result in the Jaguar's death.
	 */
	private void incrementAge()
	{
		age++;
		if(age > MAX_AGE) {
			setDead();
		}
	}

	/**
	 * Make this Jaguar more hungry. This could result in the Jaguar's death.
	 */
	private void incrementHunger()
	{
		foodLevel--;
		if(foodLevel <= 0) {
			setDead();
		}
	}

	/**
	 * Look for animals adjacent to the current location.
	 * Only the first live animal is eaten.
	 * @return Where food was found, or null if it wasn't.
	 */
	private Location findFood()
	{
		Field field = getField();
		List<Location> adjacent = field.adjacentLocations(getLocation());
		Iterator<Location> it = adjacent.iterator();
		
		while(it.hasNext()) {
			Location where = it.next();
			Object item = field.getObjectAt(where);
			
			if(item instanceof Tapir) {
				Tapir tapir = (Tapir) item;
				this.setVirus(tapir.getVirus());
				if(tapir.isAlive()) { 
					tapir.setDead();
					foodLevel = TAPIR_FOOD_VALUE;
					return where;
				}
			}else if(item instanceof Caiman) {
				Caiman caiman = (Caiman) item;
				this.setVirus(caiman.getVirus());
				if(caiman.isAlive()) { 
					caiman.setDead();
					foodLevel = CAIMAN_FOOD_VALUE;
					return where;
				}
			}
			else if(item instanceof Gorilla) {
				Gorilla gorilla = (Gorilla) item;
				this.setVirus(gorilla.getVirus());
				if(gorilla.isAlive()) { 
					gorilla.setDead();
					foodLevel = GORILLA_FOOD_VALUE;
					return where;
				}
			}
			else if(item instanceof Puma) {
				Puma puma = (Puma) item;
				this.setVirus(puma.getVirus());
				if(puma.isAlive()) { 
					puma.setDead();
					foodLevel = PUMA_FOOD_VALUE;
					return where;
				}
			}
		}
		return null;
	}

	/** 
	 * Decreases the max age of the animal by a given number if the animal 
	 * is infected by a virus
	 * @param decimal number between 0 and 1 by which we should decrease the max age
	 */
	public void maxAgeDecrease(double decimal) {
		MAX_AGE = (int) Math.round(MAX_AGE * decimal) ;

	}

	/**
	 * Check whether or not this Jaguar is to give birth at this step.
	 * New births will be made into free adjacent locations.
	 * @param newJaguares A list to return newly born Jaguars.
	 */
	private void giveBirth(List<Animal> newJaguares)
	{
		// New Jaguars are born into adjacent locations.
		// Get a list of adjacent free locations.
		Field field = getField();
		List<Location> free = field.getFreeAdjacentLocations(getLocation());
		int births = breed();
		
		for(int b = 0; b < births && free.size() > 0; b++) {
			Location loc = free.remove(0);
			Jaguar young = new Jaguar(false, field, loc, this.getview());
			//if the parent has a virus the child will have a virus as well
			young.setVirus(this.getVirus());
			
			//check the gender of the newly born animal
			if(young.isMale()) {
				this.getview().setColor(young, Color.yellow);
			}
			newJaguares.add(young);
		}
	}

	/**
	 * Generate a number representing the number of births,
	 * if it can breed.
	 * @return The number of births (may be zero).
	 */
	private int breed()
	{
		Field field = getField();
		List<Object> AdjacentSameBreed = field.getAdjacentLocationsOfSameAnimal(getLocation(), this); //List of adjacent animals of the same species
		boolean found = false;
		
		for(Object posiblePartner: AdjacentSameBreed) {
			Jaguar temp = (Jaguar) posiblePartner;
			
			//Check if an adjacent animal is the opposite gender
			if(temp.canBreed() && (temp.isMale() != this.isMale())) { 
				found = true;
			}
		}
		
		int births = 0;
		if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && found) {

			births = rand.nextInt(MAX_LITTER_SIZE) + 1;
		}
		return births;
	}

	/**
	 * A Jaguar can breed if it has reached the breeding age.
	 */
	private boolean canBreed()
	{
		return age >= BREEDING_AGE;
	}
}
