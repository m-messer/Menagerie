
public class Main {

	public static void main(String[] args) {
		int x = 0;
		//run more simulations at once
		while(x < 1) {
			new Thread(new Runnable() {
			     @Override
			     public void run() {
			    	 Simulator run = new Simulator();
			 		run.runLongSimulation();
			     }
			}).start();
		
		x++;
		}
	}

}
