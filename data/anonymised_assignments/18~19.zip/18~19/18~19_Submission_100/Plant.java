import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2019.02.12 (2)
 */
public abstract class Plant
{
	// Whether the plant is alive or not.
	private boolean alive;
	// The plants's field.
	private Field field;
	// The plants's position in the field.
	private Location location;
	private SimulatorView view;


	/**
	 * Create a new plant at location in field.
	 * 
	 * @param field The field currently occupied.
	 * @param location The location within the field.
	 */
	public Plant(Field field, Location location, SimulatorView view)
	{	
		this.view = view;
		alive = true;
		this.field = field;
		setLocation(location);
	}

	/**
	 * Make this plant act - that is: make it do
	 * whatever it wants/needs to do.
	 * @param newPlants A list to return newly born plants.
	 */
	abstract public void act(List<Plant> newPlants);

	/**
	 * Check whether the Plant is alive or not.
	 * @return true if the plant is still alive.
	 */
	protected boolean isAlive()
	{
		return alive;
	}

	/**
	 * Indicate that the plant is no longer alive.
	 * It is removed from the field.
	 */
	protected void setDead()
	{
		alive = false;
		if(location != null) {
			field.clear(location);
			location = null;
			field = null;
		}
	}

	/**
	 * Return the plant's location.
	 * @return The plants's location.
	 */
	protected Location getLocation()
	{
		return location;
	}

	protected SimulatorView getview()
	{
		return view;
	}

	/**
	 * Place the plant at the new location in the given field.
	 * @param newLocation The plants's new location.
	 */
	protected void setLocation(Location newLocation)
	{
		if(!(field.getObjectAt(newLocation) instanceof Highway)) {
			if(location != null) {
				field.clear(location);
			}
			location = newLocation;
			field.place(this, newLocation);
		}
		
	}

	/**
	 * Return the Plants's field.
	 * @return The Plants's field.
	 */
	protected Field getField()
	{
		return field;
	}
}
