import java.util.List;
import java.util.Random;

/**
 * A class representing a highway built by the user.
 *
 * @version 2019.02.19 (2)
 */
public class Highway
{
    // The highway's field.
    private Field field;
    // The highway's position in the field.
    private Location location;
    
    private SimulatorView view;
    
    /**
     * Create a new highway at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Highway(Field field, Location location, SimulatorView view)
    {	
    	this.view = view;
        this.field = field;
        setLocation(location);
    }

    protected SimulatorView getview()
    {
        return view;
    }

    /**
     * Return the highway's location.
     * @return The highway's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /*
     * Remove a highway object form location L in the field
     */
    public void removeHighway(Location L) {
    	if(field.getObjectAt(L) instanceof Highway) {
    		field.clear(L);
    	}
    	
    }

    /**
     * Place the highway at the new location in the given field.
     * @param newLocation The highway's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(this.location != null) {
        	
            field.clear(this.location);

        }
        
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the highway's field.
     * @return The highway's field.
     */
    protected Field getField()
    {
        return field;
    }
}
