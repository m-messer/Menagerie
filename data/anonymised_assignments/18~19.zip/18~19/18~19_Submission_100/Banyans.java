import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * A simple model of a Banyans palnt.
 * Plants age, grow in adjacent locations, and die when reach max age or get eaten.
 *
 * @version 2019.02.12 
 */
public class Banyans extends Plant{
	// The age to which a banyans can live.
	private int MAX_AGE = 35;
	// The likelihood of a banyans growing.
	private static final double GROW_PROBABILITY = 0.07;
	// The food value of a single plant.
	private static final int PLANT_FOOD_VALUE = 17;
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();

	// The banyans' age.
	private int age;
	// The Banyans' food level, which is increased by eating other plants.
	private int foodLevel;

	// Individual characteristics (instance fields).
	public Banyans(Field field, Location location, SimulatorView view){
		super(field, location, view);
		age = 0;
		foodLevel = PLANT_FOOD_VALUE;
	}

	/**
	 * This is what the banyans does most of the time: it grows and kills other plants.
	 * In the process, it might grow, be eaten, die of old age or do nothing,
	 * @param newPlants A list to return newly born plants.
	 */
	@Override
	public void act(List<Plant> newPlants) {
		incrementAge();
		incrementHunger();

		if(isAlive()) {
			// Plants don't grow during night
			if(this.getview().getweather().isIsDay()){
				grownewplant(newPlants);           
				// Move towards a source of food if found.
				findFood();
			}
		}
	}

	/**
	 * Increase the age.
	 * This could result in the banyans's death.
	 */
	private void incrementAge()
	{
		age++;
		if(age > MAX_AGE) {

			setDead();
		}
	}

	/**
	 * Make this Banyans more hungry. This might result in the Banyans' death.
	 */
	private void incrementHunger()
	{
		foodLevel--;
		if(foodLevel <= 0) {
			setDead();
		}
	}

	/**
	 * Look for plant adjacent to the current location.
	 * Only the first live plant is eaten.
	 * @return Where food was found, or null if it wasn't.
	 */
	private Location findFood()
	{
		Field field = getField();
		List<Location> adjacent = field.adjacentLocations(getLocation());
		Iterator<Location> it = adjacent.iterator();
		while(it.hasNext()) {
			Location where = it.next();
			Object item = field.getObjectAt(where);
			if(item instanceof Bamboo) {
				Bamboo bamboo = (Bamboo) item;
				if(bamboo.isAlive()) { 
					bamboo.setDead();
					foodLevel = PLANT_FOOD_VALUE;
					return where;
				}
			}else if(item instanceof Acai) {
				Acai acai = (Acai) item;
				if(acai.isAlive()) { 
					acai.setDead();
					foodLevel = PLANT_FOOD_VALUE;
					return where;
				}
			}
		}
		return null;
	}

	/**
	 * Duplicate plant species in an adjacent field
	 * @param newPlants a list of new plants
	 */
	private void grownewplant(List<Plant> newPlants) {
		Field field = getField();
		List<Location> free = field.getFreeAdjacentLocations(getLocation());
		for(Location loc : free) {
			if(canMultiply()) {
				Random random = new Random();
				if(this.getview().getweather().raining() || random.nextBoolean()) {
					Banyans young = new Banyans(field, loc, this.getview());
					newPlants.add(young);
				}
			}
		}
	}

	/**
	 * Check if a banyans will grow according to its 
	 * probability of growing.
	 * @return true or false if the plant will grow
	 */
	private boolean canMultiply(){
		boolean canMultiply = false;
		if(rand.nextDouble() <= GROW_PROBABILITY) {
			canMultiply = true;
		}
		return canMultiply;

	}
}
