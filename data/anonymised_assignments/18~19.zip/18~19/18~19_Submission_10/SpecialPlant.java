import java.util.List;
import java.util.Iterator;

/**
 * Special plants are much more rare and have a slow growth rate, they are special because they can cure disease
 */
public class SpecialPlant extends Plant
{
    // The growth rate of the plant
    private double growthRate = 0.01;
    // The health of the plant (How many steps it can be alive for)
    private int health = 100;
   
    /**
     * Constructor for the SpecialPlant object
     * @param Field The field of the plant
     * @param Location The location of the plant
     */
    public SpecialPlant(Field field, Location location) {
        super(field, location);
    }
    
    /**
     * Grow method, controls how the SpecialPlant grows
     * @param newSpecialPlants list of newly created SpecialPlants'
     */
    @Override
    public void grow(List<Plant> newSpecialPlants) {
        update(); // Update the state of the plant
        if(this.isAlive()) { // If the plant is still alive, try spread the plant
            spread(newSpecialPlants);
        }
    }
    
    /**
     * Method for spreading (Creating new) plants
     * @param newSpecialPlants list of the new plants
     */
    private void spread(List<Plant> newSpecialPlants) {
        Field field = this.getField();
        List<Location> adjacent = field.adjacentLocations(this.getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location loc = it.next();
            Object obj = field.getObjectAt(loc);
            if(obj instanceof Grass) { // SpecialPlants can only grow next to grass
                Grass grass = (Grass) obj;
                List<Location> free = grass.getField().getFreeAdjacentLocations(grass.getLocation());
                for(Location location : free) { // For each location around the grass, try grow a new SpecialPlant
                    if(rand.nextDouble() <= growthRate) {
                        SpecialPlant offspring = new SpecialPlant(field, location);
                        newSpecialPlants.add(offspring);
                    }
                }
            }
        }
    }
    
    /**
     * Simulate decay of the plant and also change the plants growthRate depending on the current weather
     */
    private void update() {
        this.health--;
        if(this.health <= 0) {
            this.setDead();
            return;
        }
     
        if(State.WEATHER.getValue() == Value.RAINY) {
            this.growthRate = 0.3;
        }
        else if(State.WEATHER.getValue() == Value.SNOWY) {
            this.growthRate = 0;
        } 
        else {
            this.growthRate = 0.1;
        }
    }
}
    