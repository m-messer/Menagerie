import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Snakes hunt Deers and compete with hawks
 *
 */
public class Snake extends Animal
{
  // Characteristics shared by all snakes (class variables).
    
    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a snake can live.
    private static final int MAX_AGE = 500;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single Deer. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 70;
    private static final int MOUSE_FOOD_VALUE = 50;
    private static final int HAWK_FOOD_VALUE = 60;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The snakes' age.other animals.
    private int age;
    // The snakes' food level, which is increased by eating Deers or foxes.
    private int foodLevel;

    /**
     * Constructor for a Snake
     * @param randomAge If true, the Snake will get a random age
     * @param Field The snakes' field.
     * @param Location The location of the snake.
     */
    public Snake(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(DEER_FOOD_VALUE + HAWK_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = DEER_FOOD_VALUE + HAWK_FOOD_VALUE;
        }
    }
    
    /**
     * Act method for snake, snakes only hunt during the night, so if it is daytime they sleep
     * @param List of new animals
     */
    @Override
    public void act(List<Animal> newSnakes)
    {
        if(State.TIME.getValue() == Value.NIGHT) {
            this.sleep();
            return;
        }
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSnakes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(isAlive()) {
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * Skips everything in the act method apart from incrementing hunger.
     */
    private void sleep() {
        incrementHunger();
    }
   
    /**
     * Method for finding food which can be Deers or hawks
     * @return Location of Deer/hawk, if there is none then it returns null
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hawk) {
                Hawk hawk = (Hawk) animal;
                if(hawk.isAlive()) {
                    if(this.getStrength() > hawk.getStrength()) {
                        hawk.setDead();
                        this.foodLevel += HAWK_FOOD_VALUE;
                        if(hawk.isInfected()) this.infect();
                        return where;
                    } else {
                        this.setDead();
                        hawk.setFoodLevel(50);
                        return null;
                    }
                }
            }
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    deer.setDead();
                    this.foodLevel += DEER_FOOD_VALUE;
                    if(deer.isInfected()) this.infect();
                    return where;
                }
            }
            if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) {
                    mouse.setDead();
                    this.foodLevel += MOUSE_FOOD_VALUE;
                    if(mouse.isInfected()) this.infect();
                    return where;
                }
            }
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant instanceof SpecialPlant && this.isInfected()) { // If the Deer is infected, and eats a special plant, the Deer is cured.
                    this.cure();
                    plant.setDead();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Method for giving birth to new animals
     * @param List of new snakes
     */
    private void giveBirth(List<Animal> newSnakes)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if(snake.isAlive() && snake.gender != this.gender) {
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Snake young = new Snake(false, field, loc);
                        if(this.isInfected()) {
                            young.infect();
                        }
                        newSnakes.add(young);
                    }
                    break;
                }
            }
        }
    }
    
    /**
     * Increment the age of the snake
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Method to decrement foodLevel
     */
    private void incrementHunger() {
        if(this.isInfected()) foodLevel -= 3;
        else foodLevel--;
        
        if(foodLevel <= 0) this.setDead();
    }
    
    /**
     * Setter for foodLevel
     * @param amount to increment foodLevel by
     */
    public void setFoodLevel(int increment) {
        this.foodLevel += increment;
    }
    
    /**
     * Getter for foodLevel
     */
    private int getFoodLevel() {
        return foodLevel;
    }
    
    /**
     * Getter for strength level
     */
    public int getStrength() {
        return BASE_STRENGTH + age;
    }
    
    /**
     * Checks if the Snake is able to breed
     * @return True/False depending on if the Snake is able to breed
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Generate a random number of offspring according to breeding probability and max litter size
     * @return Number of offspring
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
