import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Wolf.
 * Wolves age, move, eat Deers, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all Wolves (class variables).
    
    // The age at which a Wolf can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a Wolf can live.
    private static final int MAX_AGE = 500;
    // The likelihood of a Wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single Deer. In effect, this is the
    // number of steps a Wolf can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 150;
    private static final int HAWK_FOOD_VALUE = 50;   
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Wolf's age.
    private int age;
    // The Wolf's food level, which is increased by eating Deers.
    private int foodLevel;
  

    /**
     * Create a Wolf. A Wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(DEER_FOOD_VALUE + HAWK_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = DEER_FOOD_VALUE + HAWK_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Wolf does most of the time: it hunts for
     * Deers. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWolves A list to return newly born Wolves.
     */
    public void act(List<Animal> newWolves)
    {
        if(State.TIME.getValue() == Value.DAY) {
            this.sleep();
            return;
        }
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWolves);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(isAlive()) {
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Method to skip the Wolves other actions apart from increasing it's hunger
     */
    private void sleep() {
        incrementHunger();
    }
    
    /**
     * Look for Deers adjacent to the current location.
     * Only the first live Deer is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hawk) {
                Hawk hawk = (Hawk) animal;
                if(hawk.isAlive()) {
                    if(this.getStrength() > hawk.getStrength()) {
                        hawk.setDead();
                        this.foodLevel += HAWK_FOOD_VALUE;
                        if(hawk.isInfected()) this.infect();
                        return where;
                    } else {
                        this.setDead();
                        hawk.setFoodLevel(50);
                        return null;
                    }
                }
            }
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    deer.setDead();
                    this.foodLevel += DEER_FOOD_VALUE;
                    if(deer.isInfected()) this.infect();
                    return where;
                }
            }
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant instanceof SpecialPlant && this.isInfected()) { // If the Deer is infected, and eats a special plant, the Deer is cured.
                    this.cure();
                    plant.setDead();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born Wolves.
     */
    private void giveBirth(List<Animal> newWolves)
    {
        // New Wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wolf) {
                Wolf wolf = (Wolf) animal;
                if(wolf.isAlive() && wolf.gender != this.gender) {
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Wolf young = new Wolf(false, field, loc);
                        if(this.isInfected()) {
                            young.infect();
                        }
                        newWolves.add(young);
                    }
                    break;
                }
            }
        }
    }
    
    /**
     * Method to increment the age of the Wolf.
     */
    private void incrementAge() {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Method to increment the hunger of the Wolf.
     */
    private void incrementHunger() {
        if(this.isInfected()) foodLevel -= 4;
        else foodLevel--;
        
        if(foodLevel <= 0) this.setDead();
    }
    
    /**
     * Getter for foodLevel.
     */
    private int getFoodLevel() {
        return foodLevel;
    }
    
    /**
     * Getter for strength.
     */
    public int getStrength() {
        return BASE_STRENGTH + age;
    }
    
    /**
     * @return True/False depending of whether the Wolf is able to breed or not
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Setter for foodLevel
     * @param amount to increase foodLevel by.
     */
    public void setFoodLevel(int increment) {
        this.foodLevel += increment;
    }
    
    /**
     * Method to generate a random number of offspring.
     * @return Number of offspring
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
