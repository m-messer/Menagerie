import java.util.List;
import java.util.Random;

/**
 * A template for a Plant object, plants do not eat food, but they have a growth rate which depends on the weather
 *
 */
public abstract class Plant
{
    // The field of the plant
    private Field field;
    // The location of the plant
    private Location location;
    // Whether the plant is alive or dead
    private boolean alive;
    // A randomizer object, used for plant spread.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Constructor for a Plant
     * @param Field The field of the plant
     * @param Location The location of the plant
     */
    public Plant(Field field, Location location) {
        this.alive = true; // Set the alive field to true
        this.field = field;
        this.setLocation(location);
    }
    
    /**
     * Method which needs to be implemented in each subclass, controls how the plant grows
     * @param newPlants list of new plants
     */
    protected abstract void grow(List<Plant> newPlants);
    
    /**
     * Getter for the Field
     * @return The Field of the Plant
     */
    protected Field getField() {
        return this.field;
    }
    
    /**
     * Getter for the Location of the Plant
     * @return The Location of the Plant
     */
    protected Location getLocation() {
        return this.location;
    }
    
    /**
     * Setter for the Location of the plant
     * @param Location The location you wish to set the plant to
     */
    protected void setLocation(Location newLocation) {
        if(this.location != null) { // Check that the current location of the plant is not null
            this.field.clear(location); // Clear the old location
        }
        this.location = newLocation; // Set the new location
        this.field.place(this, newLocation); // Place the plant in the field, at the new location
    }
    
    /**
     * Getter for the alive field
     * @return True/False depending of if the plant is alive or dead
     */
    protected boolean isAlive() {
        return this.alive;
    }
    
    /**
     * Setter for the alive field
     */
    protected void setDead() {
        this.alive = false; // Set alive to false
        if(this.location != null) { // If the plant has a location
            this.field.clear(this.location); // Clear that location
            this.location = null; // Set it to null
            this.field = null; // The plant doesn't have a field anymore since it's dead
        }
    }
   
}
