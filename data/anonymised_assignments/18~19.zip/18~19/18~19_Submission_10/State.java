
/**
 * Stores the current state (Time + Weather) of the simulation
 */
public enum State
{
    // Time and Weather default to day and sunny respectively
    TIME(Value.DAY),
    WEATHER(Value.SUNNY);
    
    // The value of the time/weather
    private Value value;
    
    /**
     * Constructor for the State
     * @param Value The initial value of the State obj
     */
    State(Value value) {
        this.value = value;
    }
    
    /**
     * Getter for the value field
     * @return Value of the State enum
     */
    public Value getValue() {
        return this.value;
    }
    
    /**
     * Setter of the value field
     * @param Value The value you wish to set
     */
    public void setValue(Value value) {
        this.value = value;
    }
}
