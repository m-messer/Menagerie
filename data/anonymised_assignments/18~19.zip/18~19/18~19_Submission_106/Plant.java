import java.util.*;
/**
 * This class represents the plants. They can die, grow, spread around,
 * some of them can also cure an animal's disease if it eats them
 *
 */
public class Plant extends LifeForm
{
    // The probability that a plant will be spread to the adjacentt location.
    private static final int growthProbability = 3;
    private static final Random rand = Randomizer.getRandom();
    // The max age of a plant.
    private static final int MAX_AGE = 30; 
    //The plants have 2 growth levels. Once they reach maturity they have more food value for the animal eating them
    private int growthLevel;
    //Array storing the foodValues of the plant depending on their growth level
    private int[] foodValues={15,25};
    // the food value which the plant can provide to the preys.
    private int foodValue;
    //boolean that stores whether a plant is a cure or not
    private boolean isCure;
    
    
    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field,Location location,boolean randomAge)
    {
        // initialise instance variables
        super(field,location);
        this.isCure = 30<= rand.nextInt(100);
        
        
        growthLevel=1;
        foodValue=foodValues[0];
        if(randomAge) {
            this.setAge(rand.nextInt(MAX_AGE));
            incrementAge();
        }
        else {
            setAge(0);
        }
    }
    /**
     * Make the plants grow. 
     * If they reach a certain age, they reach maturity and their food value changes
     * During the rain, plants that haven't reached maturity grow twice as fast,
     * while mature plants do not grow at all in this period.
     */
    public void incrementAge()
    {   
       incAge();
       if (getField().getWeather().getWeatherName()=="rainy")
       {
           if (growthLevel==1)
           {
               incAge();
           }
           else{
               decAge();
           }
       }
       if(this.getAge()>=20)
        incrementGrowthLevel();
       if(this.getAge()>MAX_AGE)
        setDead();
       if(growthLevel==2)
        foodValue=foodValues[1];
    }
    /**
     * The plants cannot move but they 
     * can spread around their current location
     * @param newPlants a list of new plants that spread around
     */
    public void spread(List<LifeForm> newPlants)
    {
    
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        while(free.size()>0)
        {
            Location loc = free.remove(0);
            if (rand.nextInt(100)<=growthProbability){
                Plant plant = new Plant(field, loc, false);
                newPlants.add(plant);}
        }
         
    }
    /**
     * Make the plants age and spread around.
     * @param newPlants the list of new plants after the old ones spread around
     * @param step the current step of the simulation
     */
    public void act(List<LifeForm> newPlants, int step){
        incrementAge();
        if(isAlive()) 
        {
            spread(newPlants);
    }
    }

    public int getGrowthProbability()
    {
        return growthProbability;
    }
    public int getGrowthLevel()
    {
        return growthLevel;
    }
    public int getFoodValue()
    {
        return foodValue;
    }
    public boolean isCure()
    {
        return isCure;
    }
    public void incrementGrowthLevel()
    {
       growthLevel=2;
    }
}