import java.util.List;
import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.21 (2)
 */
public abstract class Animal extends LifeForm
{
    private boolean isFemale;
    private int foodLevel;
    private String animalName;
    
    //An array for the property for every animal
    //0 position is the breeding age
    //1 position is the max age
    //2 position is the breeding possibility
    //3 position is the max litter size
    //4 position is the food value when they eat(does not matter for preys)
    //5 position is the minimum days after a breeding before an animal can breed again
    //6 position is the maximum size of their food level
    private int[] property;
    
    
    //An array list storing the time period an animal can act during a day
    private ArrayList<Integer> actingPeriod;
    
    // The probability that the animal will spread the diease they carry.
    private static final int DISEASE_SPREAD_RATE=30;
    // The probability that disease will be created in the begining.
    private static final int DISEASE_CREATION=10;
    // The boolean storing the state of ill or not.
    private boolean isSick;
    // the integer show how long the animal has been ill
    private int timeSpentSick;
    // the integer show how long since the last breeding of the animal.
    private int timeAfterBreed;
    // A hashmap to match each animal to their properties
    private HashMap<String,int[]>  properties;
    
    
    private Field plantField;
    //An array list storing all the animal name of prey
    private ArrayList<String> PREY_NAME;
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge The animal is created at the start or not.
     * @param plantField The field for the plants.
     */
    public Animal(Field field, Location location,boolean randomAge,String animalName,Field plantField)
    {
        super(field,location);
        this.plantField=plantField;
        setProperties();
        this.isFemale = 50<= rand.nextInt(100);
        this.animalName = animalName;
        property=properties.get(animalName);
        actingPeriod=new ArrayList();
        isSick=false;
        
        timeAfterBreed=0;
        
        if(randomAge) {
            setAge(rand.nextInt(property[1]));
            foodLevel = 40+rand.nextInt(property[4]);
            if (rand.nextInt(100)<DISEASE_CREATION)
            {
                isSick=true;
            }
        }
        else {
            setAge(0);
            foodLevel = 30;
        }
    }

    /**
     * set the property for each kind of animals
     */
    private void setProperties()
    {
        properties= new HashMap();
        int[] pr1={500,1700,25,2,400,180,600};
        properties.put("lion",pr1);
        int[] pr2={120,500,20,4,150,40,250};
        properties.put("leopard",pr2);
        int[] py1={160,700,60,3,40,40,100};
        properties.put("zebra",py1);
        int[] py2={95,600,45,5,10,30,60};
        properties.put("giraffe",py2);
        
        PREY_NAME=new ArrayList();
        PREY_NAME.add("zebra");
        PREY_NAME.add("giraffe");
    }
    
    
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<LifeForm> newAnimals,int step){
        incrementAge();
        incrementHunger();
        timeAfterBreed--;
        //animals can onlt acts in acting period.
        if(isAlive() && actingPeriod.contains(step%4+1)) {
            if( step%4+1 ==4 || step%4+1 ==1) 
            {
                spreadDisease();
            }
            giveBirth(newAnimals,getAnimalName(),plantField);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    abstract public Location findFood();
    
    
    
    /**
     * Make the animal grow older. 
     * If the animal has reached its maximum age, it dies.
     * If the animal has been sick for 15 days, if it is a prey it dies, 
     * otherwise it becomes cured so that it cannot spread the disease, predators only serving as carriers.
     */
    protected void incrementAge()
    {
        incAge();
        incrementTimeSpentSick();
        if(getAge() > property[1]) {            
            setDead();
        }
        else if(timeSpentSick>=15)
        {
           if(PREY_NAME.contains(animalName))
           setDead();
           else
           becomeCured();
           
        }
    }
    
    /**
     * Increments the time an animal has been sick for.
     */
    public void incrementTimeSpentSick()
    {
        if(this.isSick())
        timeSpentSick++;
    }
    /**
     *  Increments the time for which an animal can live before it dies of hunger. 
     *  Once that number reaches their limit, it gets capped so no matter how much more it eats
     *  its food level will not exceed this limit.
     *  @param foodValue the food value of the animal or plant being eaten
     */   
    protected void incrementFoodLevel(int foodValue)
    {
        foodLevel+=foodValue;
        if (foodLevel>property[6]){
                foodLevel=property[6];
            }
        
    }
        
    /**
     * Spreads the disease by checking if 
     * there is a sick animal is located next to a healthy animal.
     */
    protected void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal!=null) {
                Animal aanimal = (Animal) animal;
                if (rand.nextInt(100)<=DISEASE_SPREAD_RATE)
                {   //This makes the disease spread at a random rate
                    if(this.isSick && aanimal.timeSpentSick>0)
                    {
                        aanimal.setSick();
                    }else if (aanimal.isSick() && this.timeSpentSick>0){
                        this.setSick();
                    }
                    
                }
            } 
        }   
    }
        
    
    protected void setSick()
    {
        isSick=true;
    }
      /**
     * Once the animal is cured the isSick boolean is set to false and
     * timeSpenSick changes to a very low number, 
     * so that the animal can't get sick again
     */
    public void becomeCured()
    {
        timeSpentSick=Integer.MIN_VALUE;
        isSick=false;
    }
    protected boolean isSick()
    {
        return isSick;
    }
    
    /**
     * Adds a time of the day in which this animal can act
     */
    protected void addActingPeriod(int period)
    {
        actingPeriod.add(period);
    }
    
    protected Field getPlantField()
    {
        return plantField;
    }
    
    /**
     * Make an animal give birth to newborn babies
     * @param newBabyAnimal a list of new animals getting born
     * @param animalName the species of the animals
     * @param plantField the plant field attached to the newborns
     */
    protected void giveBirth(List<LifeForm> newBabyAnimal,String animalName,Field plantField)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            LifeForm young=null;
            switch(animalName){
                case"lion": young = new Lion(false, field, loc,animalName,plantField);
                            break;
                            
                case"leopard": young = new Leopard(false, field, loc,animalName,plantField);
                            break;
            
            
                case"zebra":young = new Zebra(false, field, loc,animalName,plantField);
                            break;
                            
                case"giraffe": young = new Giraffe(false, field, loc,animalName,plantField);
                               break;            
            
            }
            newBabyAnimal.add(young);
            
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextInt(100) <= property[2]) {
            births = rand.nextInt(property[3]) + 1;
            timeAfterBreed=property[5];
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age and 
     * if there is an animal of the same species and opposite sex in 
     * an adjacent location.
     */
    private boolean canBreed()
    {
        Field field = getField();
        if(getAge()<property[0])
              return false;
        else 
        {       
            if (timeAfterBreed<=0)
            {
                if(isFemale())
                {
                    for(Location location : field.adjacentLocations(getLocation()))
                       {
                           Animal animal=(Animal)field.getObjectAt(location);
                                if(animal!=null)
                                    if(!(animal.isFemale()))
                                        if(animal.getAnimalName()==this.getAnimalName())
                                            return true;
                       }
                    }
                }
            } 
        return false;
    }
    
    
    
    /**
     * Make this animal more hungry. 
     * This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    protected int[] getProperty()
    {
        return property;
    }
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    protected boolean isFemale()
    {
        return isFemale;
    }
    protected String getAnimalName()
    {
        return animalName;
    }
}
