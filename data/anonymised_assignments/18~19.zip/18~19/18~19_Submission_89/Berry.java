import java.util.List;



public class Berry extends Entity {
    //The location of the berry
    private Location location;
    //The Berry's collision field
    private static final BerryCollider berryCollider = new BerryCollider();

    /**
     * Create a new Berry instance
     * @param field of the berry
     * @param location of the berry
     */
    public Berry(Field field, Location location) {
        super(field);
        this.location = location;
        field.place(this, location);
    }

    /**
     * Function to delete the berry and remove
     * from the map
     */
    public void setDead() {
        field.remove(location, this);
        location = null;
        field = null;
    }

    /**
     * Get the collider of the berry
     */
    @Override
    public Collider getCollider() {
        return berryCollider;
    }
}
