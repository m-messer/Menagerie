import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Sheep extends Animal {

    // Characteristics shared by all sheep (class variables).
    private static final SheepCollider sheepCollider = new SheepCollider();
    // The age at which a sheep can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a sheep can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a sheep breeding.
    private static final double BREEDING_PROBABILITY = 0.43;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single sheep. In effect, this is the
    // number of steps a sheep can go before it has to eat again.
    private static final int BERRY_FOOD_VALUE = 48;
    // A variable keeping track whether the Sheep is sleeping or not
    private boolean isSleeping;
    // A variable to check whether the animal is male or female
    private boolean isMale;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    // The Sheep's age.
    private int age;
    // The sheep's food level, which is increased by eating berries.
    private int foodLevel;

    /**
     * Create a sheep. A sheep can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale indicates the gender of the animal
     * @param weather inserts the weather object
     * @param time inserts the time object
     */
    public Sheep(boolean randomAge, Field field, Location location, boolean isMale, Weather weather, Time time) {
        super(field, location, weather, time);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(BERRY_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = BERRY_FOOD_VALUE;
        }

        this.isMale = isMale;

        isSleeping = false;
    }

    /**
     * This is what the sheeps does most of the time: it search for
     * berries. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSheep A list to return newly born sheeps.
     */
    public void act(List < Organism > newSheep) {
        incrementAge();
        incrementHunger();
        // Check if the sheep is alive
        if (isAlive()) {
            // Check if the animal is sleeping
            if (!isSleeping()) {
                findPartner(newSheep);
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), this);
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Make this sheep more hungry. This could result in the sheep's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for sheep's adjacent to the current location.
     * Search for Berries
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > thingsAround = field.getObjectsAt(where);

            for (Entity thing: thingsAround) {

                if (thing instanceof Berry) {
                    Berry berry = (Berry) thing;
                    berry.setDead();
                    foodLevel = BERRY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this sheep is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSheeps A list to return newly born foxes.
     */
    private void giveBirth(List < Organism > newSheeps) {
        // New sheeps are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List < Location > free = field.getFreeAdjacentLocations(getLocation(), this);
        int births = breed();

        for (int b = 0; b < births && free.size() > 0; b++) {

            Location loc = free.remove(0);
            Sheep young = new Sheep(false, field, loc, isMale, weather, time);
            newSheeps.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    /**
     * Return the breeding age
     * @return BREEDING_AGE
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Return the sheeps max age
     * @return MAX_AGE
     */
    public int getMaxAge() {
        return MAX_AGE;
    }
    /**
     * Return the sheep's collider
     * @return sheepCollider
     */
    public Collider getCollider() {
        return sheepCollider;
    }

    /**
     * Return whether the animal is currently is sleeping or not
     * @return (time.getHour() > 19);
     */
    public boolean isSleeping() {
        return (time.getHour() > 19);
    }

    /**
     * The findPartner Function is used to check all the things in proximity
     * Filter for animals of type sheep and different gender
     * If there is such a sheep, proceed to the mating
     * @param newSheeps
     */
    private void findPartner(List < Organism > newSheeps) {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > animals = field.getObjectsAt(where);

            for (Entity animal: animals) {

                if (animal instanceof Sheep) {
                    Sheep sheep = (Sheep) animal;
                    if (isMale != sheep.isMale) {
                        //                      System.out.println("Two crocs found each other");
                        giveBirth(newSheeps);
                    }
                }
            }
        }
    }
}