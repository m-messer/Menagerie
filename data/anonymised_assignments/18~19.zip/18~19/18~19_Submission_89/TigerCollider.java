public class TigerCollider extends AnimalCollider {

    /**
     * This function checks whether the Tiger is colliding with the lake or not
     * @param lake
     * @return true for collides with lake, meaning that the tiger won't end up in the lake.
     */


    @Override
    public boolean collidesWith(LakeCollider lake) {
        return true;
    }
}