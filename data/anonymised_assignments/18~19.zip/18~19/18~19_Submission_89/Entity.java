import java.util.List;

public abstract class Entity {
    protected Field field;

    public abstract Collider getCollider();

    /**
     * Return the entity's field.
     * @return The entity's field.
     */
    protected Field getField() {
        return field;
    }

    Entity(Field field) {
        this.field = field;
    }
}
