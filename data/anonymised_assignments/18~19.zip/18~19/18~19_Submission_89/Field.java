import java.util.*;

/**
 * Represent a rectangular grid of field positions.
 * Each position is able to store a single animal.
 *
 * @version 2019.02.22
 */
public class Field
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();
    // Maximum number of entities that can be in one location at a given time.
    private static final int MAX_ENTITIES = 2;
    
    // The depth and width of the field.
    private int depth, width;
    // Storage for the animals.
    private LinkedList<Entity>[][] field;

    /**
     * Represent a field of the given dimensions.
     * @param depth The depth of the field.
     * @param width The width of the field.
     */
    public Field(int depth, int width)
    {
        this.depth = depth;
        this.width = width;
        field = new LinkedList[depth][width];

        for (int d = 0; d < depth; d++) {
            for (int w = 0; w < width; w++) {
                field[d][w] = new LinkedList<>();
            }
        }
    }
    
    /**
     * Empty the field.
     */
    public void clear()
    {
        for(int row = 0; row < depth; row++) {
            for(int col = 0; col < width; col++) {
                field[row][col].clear();
            }
        }
    }
    
    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    public void clear(Location location)
    {
        field[location.getRow()][location.getCol()].clear();
    }

    public void remove(Location location, Entity thisEntity) {
        LinkedList<Entity>currentLocation = field[location.getRow()][location.getCol()];
        // remove location reference to object if it is found
        for(ListIterator<Entity> it = currentLocation.listIterator(); it.hasNext();) {
            Entity entity = it.next();
            if (entity == thisEntity) {
                it.remove();
            }
        }
    }
    
    /**
     * Place an animal at the given location.
     * If there is already an animal at the location it will
     * be lost.
     * @param entity The animal to be placed.
     * @param row Row coordinate of the location.
     * @param col Column coordinate of the location.
     */
    public void place(Entity entity, int row, int col)
    {
        place(entity, new Location(row, col));
    }
    
    /**
     * Place an animal at the given location.
     * If there is already an animal at the location it will
     * be lost.
     * @param animal The animal to be placed.
     * @param location Where to place the animal.
     */
    public void place(Entity animal, Location location) {
        int row = location.getRow();
        int col = location.getCol();

        if (field[row][col].size() < MAX_ENTITIES) {
            field[location.getRow()][location.getCol()].addFirst(animal);
        }
    }
    
    /**
     * Return the animal at the given location, if any.
     * @param location Where in the field.
     * @return The animal at the given location, or null if there is none.
     */
    public ArrayList<Entity> getObjectsAt(Location location)
    {
        return getObjectsAt(location.getRow(), location.getCol());
    }
    
    /**
     * Return the animal at the given location, if any.
     * @param row The desired row.
     * @param col The desired column.
     * @return The animal at the given location, or null if there is none.
     */
    public ArrayList<Entity> getObjectsAt(int row, int col)
    {
        return new ArrayList<>(field[row][col]);
    }

    public boolean isWithinFieldBounds(Location location) {
        return location.getRow() < getDepth() &&
                location.getCol() < getWidth() &&
                location.getRow() >= 0 &&
                location.getCol() >= 0;
    }
    
    /**
     * Generate a random location that is adjacent to the
     * given location, or is the same location.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location randomAdjacentLocation(Location location)
    {
        List<Location> adjacent = adjacentLocations(location);
        return adjacent.get(0);
    }
    
    /**
     * Get a shuffled list of the free adjacent locations.
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */

    public List<Location> getFreeAdjacentLocations(Location location, Entity entity) {
        List<Location> free = new LinkedList<>();
        List<Location> adjacent = adjacentLocations(location);

        for(Location next : adjacent) {
            if(getObjectsAt(next).size() < MAX_ENTITIES && !isInLocation(next, entity)) {
                free.add(next);
            }
        }

        return free;
    }

    public boolean isInLocation(Location location, Entity entity) {
        return isInLocation(location, entity.getCollider());
    }

    public boolean isInLocation(Location location, Collider collider) {
        ArrayList<Entity> entities = getObjectsAt(location);

        for (Entity nextEntity : entities) {
            if (nextEntity.getCollider().collidesWith(collider)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Try to find a free location that is adjacent to the
     * given location. If there is none, return null.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location freeAdjacentLocation(Location location, Entity entity)
    {
        // The available free ones.
        List<Location> free = getFreeAdjacentLocations(location, entity);
        if(free.size() > 0) {
            return free.get(0);
        }
        else {
            return null;
        }
    }

    /**
     * Find a random location in Proximity to drop a berry afterwards.
     */
    
    public Location randomLocationInRange(Location location, int lower, int upper) {
        Random r = new Random();

        int distance = lower + r.nextInt(upper - lower);
        double angle = 2 * Math.PI * r.nextDouble();

        double row =  location.getRow() + distance * Math.sin(angle);
        double col = location.getCol() + distance * Math.cos(angle);

        return new Location((int) row, (int) col);
    }

    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    public List<Location> adjacentLocations(Location location)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        if(location != null) {
            int row = location.getRow();
            int col = location.getCol();
            for(int roffset = -1; roffset <= 1; roffset++) {
                int nextRow = row + roffset;
                if(nextRow >= 0 && nextRow < depth) {
                    for(int coffset = -1; coffset <= 1; coffset++) {
                        int nextCol = col + coffset;
                        // Exclude invalid locations and the original location.
                        if(nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
                            locations.add(new Location(nextRow, nextCol));
                        }
                    }
                }
            }
            
            // Shuffle the list. Several other methods rely on the list
            // being in a random order.
            Collections.shuffle(locations, rand);
        }
        return locations;
    }

    /**
     * Return the depth of the field.
     * @return The depth of the field.
     */
    public int getDepth()
    {
        return depth;
    }
    
    /**
     * Return the width of the field.
     * @return The width of the field.
     */
    public int getWidth()
    {
        return width;
    }
}