
import java.util.Iterator;
        import java.util.List;
        import java.util.Random;
        import java.util.ArrayList;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Mouse extends Animal {
    // Characteristics shared by all rabbits (class variables).
    private static final  MouseCollider mouseCollider = new MouseCollider();
    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The nutrition points gained by eating a Berry
    private static final int BERRY_FOOD_VALUE = 48;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // A variable to check if the mouse is currently sleeping or not
    private boolean isSleeping;
    // Define the gender of the mouse
    private boolean isMale;
    // The food level of the animal
    private int foodLevel;
    // The Mouse's age.
    private int age;
    // The Mouse's Min and Max Temperature to survive
    private double minTemp;
    private double maxTemp;

    /**
     * Create a new Mouse. A Mouse may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Mouse will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param isMale    The mouse's Gender
     * @param weather   The weather object gets passed in
     * @param time      The time object gets passed in
     */
    public Mouse(boolean randomAge, Field field, Location location, boolean isMale, Weather weather, Time time) {
        super(field, location, weather, time);
        foodLevel = BERRY_FOOD_VALUE;
        minTemp = -5 + (2 * rand.nextGaussian());
        maxTemp = 35 + (2 * rand.nextGaussian());
        age = 0;
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        this.isMale = isMale;

    }

    /**
     * This is what the Mouse does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     *
     * @param newMice A list to return newly born Mice.
     */
    public void act(List < Organism > newMice) {
        incrementAge();
        incrementHunger();
        // Make sure the Mouse is alive
        if (isAlive()) {
            //Make sure the Mouse is not sleeping
            if (!isSleeping()) {
                findPartner(newMice);
                Location newLocation = findFood();
                // Try to move into a free location.
                if (newLocation == null) {
                    newLocation = getField().freeAdjacentLocation(getLocation(), this);
                }
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
                //Check if the mouse is not dying because it is too cold or too warm.
                if (Simulator.weather.getTemperature() < minTemp) {
                    setDead();
                }

                if (Simulator.weather.getTemperature() > maxTemp) {
                    setDead();
                }
            }
        }
    }

    /**
     * The incrementHunger Function to make the animal loose a foodvalue point every step
     */

    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Check whether or not this Mouse is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born Mice.
     */
    private void giveBirth(List < Organism > newMice) {
        // New Mice are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List < Location > free = field.getFreeAdjacentLocations(getLocation(), this);
        int births = breed();

        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Mouse young = new Mouse(false, field, loc, isMale, weather, time);
            newMice.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A function to return the Breeding age
     * @return BREEDING_AGE
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * A function to return the Max age
     * @return MAX_AGE
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * A function to see if it collides with the lake
     * @return true
     */
    public boolean collidesWith(Lake lake) {
        return true;
    }

    /**
     * A function returning the collider
     * @return mouseCollider
     */
    public Collider getCollider() {
        return mouseCollider;
    }

    /**
     * A function to check whether the animal is currently asleep or not
     * @return (time.getHour() > 19);
     */
    public boolean isSleeping() {
        return (time.getHour() > 19);
    }


    /**
     * A function for the Mouse to find Berries in his proximity
     * @return null or return where, depending what the Mouse finds.
     */
    private Location findFood() {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > thingsAround = field.getObjectsAt(where);

            for (Entity thing: thingsAround) {
                if (thing instanceof Berry) {
                    Berry berry = (Berry) thing;
                    berry.setDead();
                    foodLevel = BERRY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * A function to find a partner. The function checks for Mouses in proximity and then makes sure they are
     * of different gender and then proceed to the mating.
     * @param newMice
     */

    private void findPartner(List < Organism > newMice) {

        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > animals = field.getObjectsAt(where);

            for (Entity animal: animals) {

                if (animal instanceof Mouse) {
                    Mouse mouse = (Mouse) animal;
                    if (isMale != mouse.isMale) {
                        giveBirth(newMice);
                    }
                }
            }
        }
    }
}