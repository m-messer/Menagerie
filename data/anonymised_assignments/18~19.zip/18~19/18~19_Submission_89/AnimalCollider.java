public abstract class AnimalCollider implements Collider {
    @Override


    /**
     * The following functions are used to decide which animals collide with:
     * 1) other animals,
     * 2) Plants,
     * 3) Berries,
     * 4) Lake,
     * This class is essentialy used to make sure animals except the crocodile don't end up in the lake or in the plants
     */


    public boolean collidesWith(AnimalCollider animal) {
        return true;
    }

    @Override
    public boolean collidesWith(PlantCollider plant) {
        return true;
    }

    @Override
    public boolean collidesWith(BerryCollider berry) {
        return false;
    }

    @Override
    public abstract boolean collidesWith(LakeCollider lake);

    @Override
    public boolean collidesWith(Collider collider) {
        return collider.collidesWith(this);
    }
}