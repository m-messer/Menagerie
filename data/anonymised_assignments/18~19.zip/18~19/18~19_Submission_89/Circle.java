/**
 * Class defining properties of a circle.
 * Radius and location of centre as fields.
 */

public class Circle {
    public Location centre;
    public int radius;

    public Circle(Location centre, int radius)  {
        this.centre = centre;
        this.radius = radius;
    }
}
