import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019/02/21
 */
public abstract class Animal extends Organism
{

    // The animal's position in the field.
    private Location location;

    // Creating a variable for the weather. Each animal needs to know what the weather is like at some point. The variable is of tpye "Weather".
    protected Weather weather;

    // Creating a variable for the time. Each animal needs to know what time it is at some point. The variable is of tpye "Time".
    protected Time time;

    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param weather The weather object is passed in.
     * @param time The time object is passed in.
     */
    public Animal(Field field, Location location, Weather weather,Time time) {
        super(field);
        setLocation(location);
        this.weather = weather;
        this.time = time;

    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    //public abstract void act(List<Entity> newEntities);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        isAlive = false;
        if (location != null) {
            field.remove(location, this);
            location = null;
            field = null;
        }
    }


    /**
     * This protected, abstract function is used to return the Breeding age of a given Animal that extends this class.
     */
    protected abstract int getBreedingAge();

    /**
     * This function returns a boolean, indicating whether the animal is ready to breed or not. This is decided based on the age.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {

        if (location != null) {
            field.remove(location, this);
        }

        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
}
