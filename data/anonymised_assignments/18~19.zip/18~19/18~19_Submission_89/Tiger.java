import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a Tiger.
 * Tiger's age, move, eat rabbits, and die.
 *
 * @version 2019/02/21
 */
public class Tiger extends Animal {
    // Characteristics shared by all Tigers (class variables).
    private static final TigerCollider tigerCollider = new TigerCollider();
    // The age at which a Tiger can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a Tiger can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a Tiger breeding.
    private static final double BREEDING_PROBABILITY = 0.33;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single Sheep or Mouse. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int MOUSE_FOOD_VALUE = 32;
    private static final int SHEEP_FOOD_VALUE = 56;
    // A variable to check whether the animal is currently sleeping or not
    private boolean isSleeping;
    // A variable making clear if the tiger is male or female
    private boolean isMale;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The tiger's age.
    private int age;
    // The tiger's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a Tiger. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale indicates the gender of the animal
     * @param weather inserts the weather object
     * @param time inserts the time object
     */
    public Tiger(boolean randomAge, Field field, Location location, boolean isMale, Weather weather, Time time) {
        super(field, location, weather, time);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MOUSE_FOOD_VALUE + SHEEP_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = MOUSE_FOOD_VALUE + SHEEP_FOOD_VALUE;
        }
        this.isMale = isMale;
        isSleeping = false;
    }

    /**
     * This is what the tiger does most of the time: it hunts for
     * sheeps or mouse, looks for a partner. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newTigers A list to return newly born tigers.
     */
    public void act(List < Organism > newTigers) {
        incrementAge();
        incrementHunger();
        //Check if the tiger is alive
        if (isAlive()) {
            //Check if the animal is sleeping
            if (!isSleeping()) {
                findPartner(newTigers);
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), this);
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Make this tiger more hungry. This could result in the tiger's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Sheeps and Mouses adjacent to the current location.
     * Only the first live Sheeps and Mouses is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > thingsAround = field.getObjectsAt(where);
            for (Entity thing: thingsAround) {
                if (thing instanceof Mouse) {
                    Mouse mouse = (Mouse) thing;
                    if (mouse.isAlive()) {
                        mouse.setDead();
                        foodLevel = MOUSE_FOOD_VALUE;
                        return where;
                    }
                }
                if (thing instanceof Sheep) {
                    Sheep sheep = (Sheep) thing;
                    if (sheep.isAlive()) {
                        sheep.setDead();
                        foodLevel = SHEEP_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTigers A list to return newly born foxes.
     */
    private void giveBirth(List < Organism > newTigers) {
        // New tigers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List < Location > free = field.getFreeAdjacentLocations(getLocation(), this);
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tiger young = new Tiger(false, field, loc, isMale, weather, time);
            newTigers.add(young);
        }
    }
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Return the breeding age of the tiger
     * @return BREEDING_AGE
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    /**
     * Return the maximal age of the tiger
     * @return MAX_AGE
     */

    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     *  Return the tigerCollider
     * @return tigerCollider
     */

    public Collider getCollider() {
        return tigerCollider;
    }


    /**
     * Return whether the animal is sleeping or not.
     * @return (time.getHour() > 16)
     */
    public boolean isSleeping() {
        return (time.getHour() > 16);
    }

    /**
     * The findPartner function is used to check all the fiels around the tiger for
     * tigers of different genders to mate.
     * @param newRabbits
     */
    private void findPartner(List < Organism > newRabbits) {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > animals = field.getObjectsAt(where);
            for (Entity animal: animals) {
                if (animal instanceof Tiger) {
                    Tiger tiger = (Tiger) animal;
                    if (isMale != tiger.isMale) {
                        giveBirth(newRabbits);
                    }
                }
            }
        }
    }
}