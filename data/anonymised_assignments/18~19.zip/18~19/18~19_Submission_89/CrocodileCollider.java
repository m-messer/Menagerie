public class CrocodileCollider extends AnimalCollider {

    /**
     * This function checks whether the croco is colliding with the lake or not
     * @param lake
     * @return false for collides with lake, meaning that the croco can and will stay in the lake
     */


    @Override
    public boolean collidesWith(LakeCollider lake) {
        return false;
    }
}