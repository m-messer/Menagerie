/**
 *
 */

public class Time {

    private int hour;
    private int day;
    private int step;

    Time(){
        step = 0;
        hour = 0;
        day = 0;
    }

    public void nextTime() {

        step++;
        hour = step % 24;
        day = step / 24 ;

    }

    public int getHour(){return hour;}
    public int getDay(){return day;}
    public int getStep(){return step;}

    public void reset(){

        step = 0;
        hour = 0;
        day = 0;
    }
}
