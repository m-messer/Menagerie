import java.util.Random;

public class Weather {
    // Reference to the current temperature
    private Temperature temp;
    private Random r;
    private double precipitation;
    // Markov chain of sky condition probabilities
    private Markov weatherMarkov;
    // Used to ensure that changeWeather is only called once for every step
    private int lastStepAtCall;

    public Weather(double maxMeanTemp, double minMeanTemp) {
        // Initialise matrix of probability states
        double[][] probabilities = {{0.77, 0.23}, {0.06, 0.94}};
        weatherMarkov = new Markov(probabilities);
        temp = new Temperature(maxMeanTemp, minMeanTemp);
        r = new Random();
        // Ensure that changeWeather can be called for Oth step.
        lastStepAtCall = -1;
    }

    /**
     * Simulate sky condition for the next step (hour).
     * Method can only execute normally once per step (hour).
     * @param step
     */
    public void changeWeather(int step) {
        // ensure that method is only called once per step
        if (lastStepAtCall != step) {
            weatherMarkov.randomWalk();
            temp.nextTemp(step);

            // simulate rain/snowfall
            if (weatherMarkov.getCurrentState() == 0) {
                precipitation = 5 + r.nextGaussian();
            } else {
                precipitation = 0;
            }
        }
    }

    public double getTemperature() {
        return temp.getCurrentTemp();
    }

    public double getPrecipitation() {
        return precipitation;
    }

    /**
     * method returns a string literal of current sky condition at a given step
     * */
    public String getCondition() {
        int newState = weatherMarkov.getCurrentState();
        switch (newState) {
            case 0 :
                if (temp.getCurrentTemp() > 0) {
                    return "RAINY";
                }
                return "SNOWY";
            case 1:
                return "SUNNY";
        }

        return "UNDETERMINED";
    }
}