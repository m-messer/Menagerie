import java.util.Random;

public class Temperature {
    // The maximum mean temperature in a year.
    private double maxMeanTemp;
    // The minimum mean temperature in a year.
    private double minMeanTemp;
    // The temperature at the current step (hour).
    private double currentTemp;
    // used to ensure that nextTemp is only called once for every step
    private int lastStepAtCall;

    private Random r;

    public Temperature(double maxMeanTemp, double minMeanTemp) {
        this.maxMeanTemp = maxMeanTemp;
        this.minMeanTemp = minMeanTemp;
        r = new Random();
        // Ensure that nextTemp can be called for Oth step.
        lastStepAtCall = -1;
    }

    public double getCurrentTemp() {
        return currentTemp;
    }

    /**
     * Simulates the temperature for the next step (hour).
     * This method can only be called once per hour.
     * **/
    public void nextTemp(int step) {
        if (lastStepAtCall != step) {
            double mid = (maxMeanTemp - minMeanTemp) / 2;
            double dayTempCycle = Math.sin((2 * Math.PI * step / 24) - Math.PI / 2);
            double annualTempCycle = Math.sin(2 * Math.PI * step / (24 * 365));
            double error = 0.5 * r.nextGaussian(); // random variation from mean day temperature

            currentTemp = (minMeanTemp + mid) + ((mid - 2) * annualTempCycle) + (2 * dayTempCycle) + error;
            lastStepAtCall = step;
        }
        return;
    }
}