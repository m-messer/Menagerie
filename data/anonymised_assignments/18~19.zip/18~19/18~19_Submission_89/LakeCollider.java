public class LakeCollider implements Collider {
    @Override
    public boolean collidesWith(LakeCollider lake) {
        return false;
    }

    @Override
    public boolean collidesWith(AnimalCollider animal) {
        return false;
    }

    @Override
    public boolean collidesWith(PlantCollider plant) {
        return false;
    }

    @Override
    public boolean collidesWith(BerryCollider berry) {
        return true;
    }

    @Override
    public boolean collidesWith(Collider collider) {
        return collider.collidesWith(this);
    }
}
