import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 **/
public class Spruce extends Plant {

    // Optimal temperature for growth
    private static final double OPTIMAL_TEMP = 15;
    // optimal rainfall for growth
    private static final double OPTIMAL_RAINFALL = 6;
    // maximum maturity is when plant is able to reproduce and drop fruit
    private static final double MAX_MATURITY = 100;
    // maximum age of spruce tree
    private static final int MAX_AGE = 850;
    // Average minimum and maximum temperatures for a seed to germinate
    private static final double MAX_SEED_TEMP = 22.0;
    private static final double MIN_SEED_TEMP = 12.0;
    // Probability a matured Spruce will spread a seed at any given step
    private static final double BREEDING_PROBABILITY = 0.1;
    // Probability a seed will germinate at any given step
    private static final double GERMINATION_PROBABILITY = 0.1;
    // All locations fully matured Spruces occupy, relative to seed (centre)
    private static final Location[] offsets = {
                                                new Location(0, -1),
                                                new Location(0, 1),
                                                new Location(-1, 0),
                                                new Location(1, 0)};

    public Spruce(Field field, Location seedLoc, Weather weather,ArrayList<Organism> plants, boolean randMaturity) {
        super(field, seedLoc, weather,plants, randMaturity);

        int row = seedLoc.getRow();
        int col = seedLoc.getCol();
        // Add seed to list of locations Spruce occupies.
        locations.add(new Location(row, col));
    }

    // Spruce is finally showed as a sapling on the field.
    protected void germinate() {
        isSeed = false;
        field.place(this, seedLoc);
    }

    /**
     * Seeds are spread within a given radius (4 <= blocks <= 7) from a Spruce centre
     * A seed will not be guaranteed to be in a valid location
     **/
    protected void breed(List<Organism> newPlants) {

        Location seedLoc = field.randomLocationInRange(locations.get(0), 4, 7);
        if (isValidLoc(seedLoc)) {
            Spruce newSpruce = new Spruce(field, seedLoc, weather, plants, false);
            newPlants.add(newSpruce);
        }
    }

    /**
     * Drops a berry at a random range of distances from the plant.
     * Note this does not guarantee a berry will be dropped,
     * as berry must have been dropped in a suitable location.
     */
    private void dropBerry() {
        Random r = new Random();

        Location berryLoc = field.randomLocationInRange(locations.get(0), 3, 4);

        if (field.isWithinFieldBounds(berryLoc) && !field.isInLocation(berryLoc, new BerryCollider()) && r.nextDouble() < 0.1) {
            Berry newBerry = new Berry(field, berryLoc);
        }
    }

    @Override
    public double getMaxMaturity() {
        return MAX_MATURITY;
    }

    @Override
    public double getOptimalRainfall() {
        return OPTIMAL_RAINFALL;
    }

    @Override
    public double getOptimalTemp() {
        return OPTIMAL_TEMP;
    }

    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Checks if potential spruce is in a viable location.
     */
    public boolean isValidLoc(Location seedLoc) {
        int minDistance = 4; // Closest distance to a Spruce that seed can be placed
        int row = seedLoc.getRow();
        int col = seedLoc.getCol();

        // Check if seed location and locations at full maturity are within field bounds
        for (Location offset : offsets) {
            int nextRow = row + offset.getRow();
            int nextCol = col + offset.getCol();

              if((nextRow>=field.getWidth()-1)){
                return false;
            }
            if((nextCol>=field.getDepth()-1)){
                return false;
            }


            if (!field.isWithinFieldBounds(new Location(nextRow, nextCol))) {
                return false;
            }

            // Check if seed is not in same location as a "collidable" entity
            if (field.isInLocation(seedLoc, this)) {
                return false;
            }
        }

        // Calculate distance between seed and all existing Spruce centres
        // Only viable location if greater than minDistance
        for(Iterator<Organism> it = plants.iterator(); it.hasNext(); ) {
            Plant current = (Plant) it.next();

            if (current == this) {
                continue;
            }

            if(seedLoc.squareDistanceTo(current.seedLoc) <= Math.pow(minDistance, 2)) {
                return false;
            }
        }
        return true;
    }

    /**
     * The 'adult'/mature appearance of the Spruce is drawn.
     * Spruces can now drop berries and spread seeds.
     */
    public void mature() {
        int row = seedLoc.getRow();
        int col = seedLoc.getCol();

        // add all spaces relative to seed location that plant will occupy once matured.
        for (Location offset : offsets) {
            locations.add(new Location(row + offset.getRow(), col + offset.getCol()));
        }
        // place and draw these locations on the field.
        for (Location loc : locations) {
            field.place(this, loc);
        }
        matured = true;
    }

    public void setDead() {
        isAlive = false;
        // Remove all locations occupied by the spruce.
        for (Location loc : locations) {
            field.remove(loc, this);
            //loc = null;
        }
        field = null;
    }

    /**
     * The Spruce initially starts as a seed until favourable conditions allow germination.
     * Spruces grow and mature at varying rates, dependent on rainfall and temperature.
     * Once matured, they can drop berries and spread seeds.
     * @param newPlants
     */
    public void act(List<Organism> newPlants) {
        Random r = new Random();

        if (!isSeed) {
            grow();

            if (isAlive()) {
                if (matured && r.nextDouble() < BREEDING_PROBABILITY) {
                    breed(newPlants);
                    dropBerry();
                }
            }
        }
        else {
            // germination is possible only if seed is in suitable location and within germination temperature range.
            if (weather.getTemperature() >= MIN_SEED_TEMP && weather.getTemperature() <= MAX_SEED_TEMP && isValidLoc(seedLoc)) {
                if (r.nextDouble() < GERMINATION_PROBABILITY) {
                    germinate();
                }
            }
        }
    }
}