public class PlantCollider implements Collider {
    @Override
    public boolean collidesWith(LakeCollider lake) {
        return true;
    }

    @Override
    public boolean collidesWith(PlantCollider plant) {
        return true;
    }

    @Override
    public boolean collidesWith(AnimalCollider animal) {
        return true;
    }

    public boolean collidesWith(BerryCollider berry) { return true; }

    public boolean collidesWith(Collider collider) {
        return collider.collidesWith(this);
    }
}
