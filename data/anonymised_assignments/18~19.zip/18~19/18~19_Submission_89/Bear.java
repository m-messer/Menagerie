import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Bear extends Animal {

    // Characteristics shared by all bears (class variables).
    private static final BearCollider bearCollider = new BearCollider();
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 50;
    // The age to which a fox can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.32;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int TIGER_FOOD_VALUE = 50;
    private static final int SHEEP_FOOD_VALUE = 30;


    // This variable indicates wheter the animal is currently sleeping or not.
    private boolean isSleeping;
    // This boolean indicates whether an animal is male or female. This is important for the breeding later on.
    private boolean isMale;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Bear's age.
    private int age;
    // The Bear's food level, which is increased by eating Tigers and Sheep.
    private int foodLevel;

    /**
     * Create a Bear. A Bear can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Bear will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isMale indicates the gender of the animal
     * @param weather inserts the weather object
     * @param time inserts the time object
     */
    public Bear(boolean randomAge, Field field, Location location, boolean isMale, Weather weather, Time time) {
        super(field, location, weather, time);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(TIGER_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = TIGER_FOOD_VALUE;
        }

        this.isMale = isMale;

        isSleeping = false;
    }

    /**
     * This is what the bear does most of the time: it hunts for
     * Tigers and Sheeps. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newBears A list to return newly born Bears.
     */
    public void act(List < Organism > newBears) {
        incrementAge();
        incrementHunger();
        //Make sure the animal is alive
        if (isAlive()) {
            //Make sure the animal is not sleeping

            if (!isSleeping()) {
                findPartner(newBears); //Start looking if there is any animal in Proximity of same Kind and different Gender
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), this);
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Make this Bear more hungry. This could result in the Bear's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Tigers and Sheeps adjacent to the current location.
     * Only the first live Tiger or Sheep is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > thingsAround = field.getObjectsAt(where);

            for (Entity thing: thingsAround) {
                if (thing instanceof Tiger) {
                    Tiger tiger = (Tiger) thing;
                    if (tiger.isAlive()) {
                        tiger.setDead();
                        foodLevel = TIGER_FOOD_VALUE;
                        return where;
                    }
                }

                if (thing instanceof Sheep) {
                    Sheep sheep = (Sheep) thing;
                    if (sheep.isAlive()) {
                        sheep.setDead();
                        foodLevel = SHEEP_FOOD_VALUE;
                        return where;
                    }
                }
            }

        }
        return null;
    }

    /**
     * Check whether or not this Bear is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBears A list to return newly born Bears.
     */
    private void giveBirth(List < Organism > newBears) {
        // New Bears are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List < Location > free = field.getFreeAdjacentLocations(getLocation(), this);
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bear young = new Bear(false, field, loc, isMale, weather, time);
            newBears.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Bear can breed if it has reached the breeding age.
     * Return the breeding age.
     */

    public int getBreedingAge() {
        return BREEDING_AGE;
    }
    /**
     * Return the animals max age
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Return the collider to make sure the animal doesn't collide with the wrong things. Like the lake.
     */

    public Collider getCollider() {
        return bearCollider;
    }

    /**
     * IsSLeeping Function to
     * @return the sleeping time of the animal
     */

    public boolean isSleeping() {
        return (time.getHour() > 19);
    }

    /**
     * Function to find a breeding partner for the bear.
     * @param newBears is the list of bears, we look for a bear of different gender in proximity
     */

    private void findPartner(List < Organism > newBears) {

        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > animals = field.getObjectsAt(where);

            for (Entity animal: animals) {

                if (animal instanceof Bear) {
                    Bear bear = (Bear) animal;
                    if (isMale != bear.isMale) {
                        giveBirth(newBears);
                    }
                }
            }
        }
    }
}