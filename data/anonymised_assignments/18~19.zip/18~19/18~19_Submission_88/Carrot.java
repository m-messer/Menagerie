/**
 * Its a type of plant.
 * The herbivores feeds from plants, which here it means carrot is food for Crickets.

 */
public class Carrot extends Plant
{
//    in each step the size of the plants (carrots) get bigger by 5
    private static final int GROWTH_RATE = 5;
    public Carrot(boolean randomAge, Field field, Location location){
        super(randomAge, field, location);
      }

    /**
     * gets growth rate
     * @return
     */
      public int getGrowthRate(){
        return GROWTH_RATE;
      }

}