import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public abstract class Carnivore extends Animal {

    // A Fox's food value.
    protected static final int FOX_FOOD_VALUE = 12;

    // A Rabbit's food value.
    protected static final int RABBIT_FOOD_VALUE = 8;
    // A Lizard's food value.
    protected static final int LIZARD_FOOD_VALUE = 6;
    // A Cricket's food value.
    protected static final int CRICKET_FOOD_VALUE = 4;
    // A Grasshopper's food value.
    protected static final int GRASSHOPPER_FOOD_VALUE = 4;
    // Random object to implement random behaviour.
    private static final Random rand = new Random();

    /**
     * Constructor for a carnivore. Only call's the superclass's constructor.
     * @param randomAge
     * @param field
     * @param location
     */
    public Carnivore(boolean randomAge, Field field, Location location)
    {
       super(field, location, randomAge);

    }

    /**
     * This is what the Carnivore does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger, catch diseases,
     * or die of old age.
     * @param newAnimals A list to return newly born Cougares.
     * @param day The animal only acts during the day and is asleep during the night.
     * @param weather The animal also responds to weather and behaves accordingly.
     */
    @Override
    public void act(List<Animal> newAnimals, boolean day, String weather) {
        incrementAgeHunger();
        if (day) {
            super.act(newAnimals, day, weather);
        }
    }


    /**
     * Look for prey adjacent to the current location.
     * Only the first live pray is eaten.
     * The predator finds it harder to hunt in rainy weather.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood(String weather)
    {
        if (weather.equals("Rainy") && rand.nextDouble() < 0.4){
           return null;
        }

            Set<Object> surroundingObjects = getSurroundingObjects();
            for (Object object : surroundingObjects) {
                if (object instanceof Animal) {
                    Animal animal = (Animal) object;
                    Location loc = animal.getLocation();
                    return eat(loc, animal);
                }
            }

        return null;
    }

    //ABSTRACT METHODS
    abstract public Location eat(Location location, Object animal);
    abstract public double getBreedingProb();
    abstract public int getBreedingAge();
    abstract public int getMaxAge();
    abstract public int getMaxLitter();
    abstract public Animal createAnimal(Field field, Location loc);

}
