import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Rabbit.
 * Rabbites age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Rabbit extends Carnivore
{
    // Characteristics shared by all Rabbites (class variables).

    // The age at which a Rabbit can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a Rabbit can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a Rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.20;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Rabbit can go before it has to eat again.
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    /**
     * Create a Rabbit. A Rabbit can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Rabbit will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location)
    {
        super(randomAge ,field, location);
        foodLevel = rand.nextInt(LIZARD_FOOD_VALUE);

    }

    /**
     * Returns the Rabbit's max age.
     * @return
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Returns the Rabbit's breeding age.
     * @return
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Returns the likelihood of the Rabbit to breed.
     * @return
     */
    public double getBreedingProb(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the maximum number of children a Rabbit can have.
     * @return
     */
    public int getMaxLitter(){
        return MAX_LITTER_SIZE;
    }
    public Location eat(Location loc, Object animal) {
        if (animal instanceof Lizard) {
            Lizard fox = (Lizard) animal;
            if (fox.isAlive()) {
                fox.setDead();
                foodLevel += FOX_FOOD_VALUE;
                return loc;
            }

        }
        return null;
    }



    /**
     * Create a new Rabbit with age 0 and the specified location with the specified field.
     * @param field
     * @param loc
     * @return
     */
    public Animal createAnimal(Field field, Location loc){
        return new Rabbit(false, field, loc);
    }



}
