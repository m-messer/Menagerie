import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Lizard.
 * Lizardes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Lizard extends Carnivore
{
    // Characteristics shared by all Lizardes (class variables).

    // The age at which a Lizard can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a Lizard can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a Lizard breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Lizard can go before it has to eat again.
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    /**
     * Create a Lizard. A Lizard can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Lizard will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lizard(boolean randomAge, Field field, Location location)
    {
        super(randomAge ,field, location);
        foodLevel = rand.nextInt(16);

    }

    /**
     * Returns the Lizard's max age.
     * @return
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Returns the Lizard's breeding age.
     * @return
     */

    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Returns the likelihood of the Lizard's to breed.
     * @return
     */

    public double getBreedingProb(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Retruns the maximum number of children a Lizard's can have.
     * @return
     */

    public int getMaxLitter(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Tries to eat the object given that the object is either corn or a cricket
     * @param loc
     * @param animal
     * @return
     */
    public Location eat(Location loc, Object animal) {
        if (animal instanceof GrassHopper) {
             GrassHopper fox = (GrassHopper) animal;
            if (fox.isAlive()) {
                fox.setDead();
                foodLevel += GRASSHOPPER_FOOD_VALUE;
                return loc;
            }

        } else if (animal instanceof Cricket) {
            Cricket cricket = (Cricket) animal;
            if (cricket.isAlive()) {
                cricket.setDead();
                foodLevel += CRICKET_FOOD_VALUE;
                return loc;
            }
        }
        return null;
    }

    public Animal createAnimal(Field field, Location loc){
        return new Lizard(false, field, loc);
    }



}
