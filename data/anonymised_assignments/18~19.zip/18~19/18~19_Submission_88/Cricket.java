import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Cricket.
 * Cricketes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Cricket extends Herbivore
{
    // Characteristics shared by all Cricketes (class variables).

    // The age at which a Cricket can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a Cricket can live.
    private static final int MAX_AGE = 10;
    // The likelihood of a Cricket breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    private static final int FOOD_CAPACITY = 3;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Cricket can go before it has to eat again.
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Cricket's age.
    // The Cricket's food level, which is increased by eating rabbits.

    /**
     * Create a Cricket. A Cricket can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Cricket will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cricket(boolean randomAge, Field field, Location location)
    {
        super(randomAge ,field, location);
        foodLevel = rand.nextInt(5);
        foodLevel = 1000;

    }

    /**
     * Tries to eat the object given that the object is Carrot
     * @param plant
     */
    @Override
    public void eat(Plant plant) {
        if (plant instanceof Carrot) {
            while (plant.getSize() > 0 && foodLevel < FOOD_CAPACITY) {
                plant.decrementSize();
                foodLevel++;
            }
        }
    }

    /**
     * Returns the Cricket's max age.
     * @return
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Returns the likelihood of the Cricket to breed.
     * @return
     */

    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Returns the likelihood of the Cricket to breed.
     * @return
     */
    public double getBreedingProb(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the maximum number of children a Cricket can have
     * @return
     */
    public int getMaxLitter(){
        return MAX_LITTER_SIZE;
    }

    /**
     *  Create a new Cricket with age 0 and the specified location with the specified field.
     * @param field
     * @param loc
     * @return
     */
    public Animal createAnimal(Field field, Location loc){
        return new Cricket(false, field, loc);
    }




}
