import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Fox extends Carnivore
{
    // Characteristics shared by all Foxes (class variables).

    // The age at which a Fox can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a Fox can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a Fox breeding.
    private static final double BREEDING_PROBABILITY = 0.18;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Fox can go before it has to eat again.
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    /**
     * Create a Fox. A Fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the Fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location)
    {
        super(randomAge ,field, location);
        foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);

    }

    /**
     * Returns the Fox's max age.
     * @return
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Returns the Fox's breeding age.
     * @return
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Returns the likelihood of the fox to breed.
     * @return
     */
    public double getBreedingProb(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Reruns the maximum number of children a Fox can have.
     * @return
     */

    public int getMaxLitter(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Tries to eat the object given that the object is a rabbit
     * @param loc
     * @param animal
     * @return
     */
    public Location eat(Location loc, Object animal) {
         if (animal instanceof Rabbit) {
            Rabbit rabbit = (Rabbit) animal;
            if (rabbit.isAlive()) {
                rabbit.setDead();
                foodLevel += RABBIT_FOOD_VALUE;
                return loc;
            }
        }
        return null;
    }

    /**
     * Create a new Fox with age 0 and the specified location with the specified field.
     * @param field
     * @param loc
     * @return returns the newly created Fox.
     */
        public Animal createAnimal(Field field, Location loc){
        return new Fox(false, field, loc);
    }




}
