import java.util.Random;
/**
 * A simple model of seaweed, seaweed can: grow, die and be eaten
 *
 * @version 2021.03.03 
 */
public class Seaweed
{
    //the 
    private static final int GROWTH_RATE = 1;
    
    private static final int MAX_SIZE = 10;
    // Tracks the current size of the seaweed
    private int size;
    // Tracks wether or not the seaweed has been eaten
    private boolean eaten = false;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //Wether or not he seaweed is large enough to be eaten
    private boolean edible = false;
    //the minimum and maximum sizes for a seaweed to be edible;
    private int maxEdible = 20;
    private int minEdible = 5;
    
   private static final Random rand = Randomizer.getRandom();
    
    /**
     * Constructor for objects of class seaweed
     */
    public Seaweed(Boolean randomSize, Field field, Location location)
    {
        this.field = field;
        setLocation(location);
        size = 0;
        if(randomSize){size = rand.nextInt(MAX_SIZE);}
    }
    
    /**
     * sets a seaweed's 'eaten' value to true;
     */
    public void setAsEaten(){
        eaten = true;
    }
    /**
     * controls whether or not a seaweed can be eaten or not
     * if it is outside a particular size range, it will be inedible
     */
    private void setEdible(){
        if(size >= minEdible && size <= maxEdible){edible = true;}
        else{edible = false;}
    }
    /**
     * @return wether or not the seaweed is edible
     */
    public boolean isEdible(){
        return edible;
    }
    /**
     * resets the size of a seaweed to 0
     */
    public void resetSize(){
        size = 0;
    }
    /**
     * resets a seaweed, forcing it to grow again as if it were a newly created seaweed object
     */
    private void reset(){
        resetSize();
        setEdible();
    }
    /**
     * increments the size of the seaweed
     */
    private void grow(){
        size++;
        die();
    }
    /**
     * "kills" the plant if it ofver a certain size(age), causing it to reset
     */
    private void die(){
        if(size >= MAX_SIZE){
            reset();
        }
    }
    /**
     * makes the seaweed act i.e it grows and checks if it has been eaten yet;
     */
    public void act(){
        grow();
        if(eaten){reset();}
    }
    /**
     * Place the seaweed at the new location in the given field.
     * @param newLocation The seaweed's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
}
