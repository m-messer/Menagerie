import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a gazelle.
 * gazelles age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Gazelle extends Prey
{
    // Characteristics shared by all gazelles (class variables).

    // The age at which a gazelle can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a gazelle breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    // Individual characteristics (instance fields).

    // The gazelle's age.
    //private int age;

    /**
     * Create a new gazelle. A gazelle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the gazelle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gazelle(boolean randomAge, Field field, Location location, Time clock)
    {
        super(field, location, clock);
        name="Gazelle";
        MAX_AGE=40;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the gazelle does most of the clock - it runs 
     * around. Someclocks it will breed or die of old age.
     * @param newgazelles A list to return newly born gazelles.
     */

    public void act(List<Animal> newgazelles)
    {
        if(clock.getHour() < 20 && clock.getHour() > 8) {
            incrementAge();
            if(isAlive()) {
                giveBirth(newgazelles);
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // Try to move into a free location.
                //Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether or not this gazelle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newgazelles A list to return newly born gazelles.
     */
    private void giveBirth(List<Animal> newgazelles)
    {
        // New gazelles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Gazelle young = new Gazelle(false, field, loc, clock);
            newgazelles.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * @return name
     */
    protected String getName()
    {
        return name;
    }

    /**
     * Checks whether the gazelles in the adjacent location are of opposite genders
     * returns true if they are 
     * returns false if they are not 
     */
    protected boolean difSexBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Gazelle) {
                Gazelle gazelle = (Gazelle) animal;
                if(this.isMale() == gazelle.isMale()) { 
                    return true;
                }
            }
        }
        return false;
    }
}
