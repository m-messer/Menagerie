
/**
 * Write a description of class Time here.
 *
 * @version (03/03/2021)
 */
public class Time
{
    // instance variables - replace the example below with your own
    int hour = 20;
    String minute = "00";

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        
    }

    public void changeTime()
    {
        if(minute.equals("30")) {
            minute = "00";
            hour++;
        }
        else {
            minute = "30";
        }
        
        hour%=24;
    }
    
    /**
     * @return hour.
     */
    public int getHour()
    {
        return this.hour;
    }
    
    /**
     * @return minute.
     */
    public String getMinute()
    {
        return this.minute;
    }
}
