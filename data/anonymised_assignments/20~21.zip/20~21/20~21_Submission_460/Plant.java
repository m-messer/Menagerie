import java.util.List;

/**
 * This class for the plants in the simulation.
 *
 * @version (03/03/2021)
 */
public class Plant extends Actor
{
    protected static double REPRODUCTION_PROBABILITY;
    protected static int MAX_OFFSPRING_SIZE;
    protected int PLANT_FOOD_VALUE;
    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Location location, Time clock)
    {
        super(field, location, clock);
        MAX_AGE = 15;
        REPRODUCTION_PROBABILITY = 0.3;
        MAX_OFFSPRING_SIZE = 6;
        PLANT_FOOD_VALUE = 1;
    }

    /**
     * Increments food value as the plant grows.
     */
    protected void grow()
    {
        if(clock.getHour() == 0 && PLANT_FOOD_VALUE<5) {
            this.PLANT_FOOD_VALUE++;
        }
    }

    /**
     * Allows plants to perform asexual reproduction.
     */
    protected void reproduce()
    {
        Field field = getField();
        List<Location> surrounding = field.adjacentLocations(getLocation());
        if(rand.nextDouble() <= REPRODUCTION_PROBABILITY) {
            for(int ind = 0; ind < rand.nextInt(surrounding.size())+1; ind++) {
                Plant newPlant = new Plant(field, location, clock);
            }
        }
    }

    /**
     * @return food value.
     */
    protected int getFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }
}
