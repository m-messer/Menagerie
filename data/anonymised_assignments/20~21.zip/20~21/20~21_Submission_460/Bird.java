import java.util.List;
import java.util.Iterator;

/**
 * Bird is an animal in the simulation.
 * birds can eat plants, breed, and die.
 *
 * @version (03/03/2021)
 */
public class Bird extends Prey
{
    // instance variables - replace the example below with your own
    // The age at which a gazelle can start to breed.
    private static final int BREEDING_AGE = 3;
    // The likelihood of a gazelle breeding.
    private static final double BREEDING_PROBABILITY = 0.11;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    /**
     * Constructor for objects of class Bird
     */
    public Bird(boolean randomAge, Field field, Location location, Time clock)
    {
        super(field, location, clock);
        name = "Bird";
        MAX_AGE = 35;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This method detrmines how the bird acts.
     * it can give birth, move, and die.
     */
    public void act(List<Animal> newbirds)
    {

        if(clock.getHour() < 22 && clock.getHour() > 6) {
            incrementAge();
            if(isAlive()) {
                giveBirth(newbirds);            
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * @return name of the bird.
     */
    protected String getName()
    {
        return name;
    }

    /**
     * this method allows the birds to mate.
     */
    private void giveBirth(List<Animal> newbirds)
    {
        // New gazelles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bird young = new Bird(false, field, loc, clock);
            newbirds.add(young);
        }
    }

    /**
     * returns the number of babies per birth.
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * this methods determines if two animals in adjacent locations are of opposite genders.
     */
    protected boolean difSexBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bird) {
                Bird bird = (Bird) animal;
                if(this.isMale() == bird.isMale()) { 
                    return true;
                }
            }
        }
        return false;
    }
}
