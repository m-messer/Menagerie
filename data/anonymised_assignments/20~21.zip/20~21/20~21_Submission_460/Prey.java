import java.util.Iterator;
import java.util.List;

/**
 * This class is for all the preys in the simulation.
 * It contains fields and methods common in all of them.
 *
 * @version (03/03/2021)
 */
public abstract class Prey extends Animal
{
    //protected static int PLANT_FOOD_VALUE = 2;

    /**
     * Constructor for objects of class Prey
     */
    public Prey(Field field, Location location, Time time)
    {
        super(field, location, time);
        alive = true;
        this.field = field;
        setLocation(location);
    }

    abstract protected String getName();

    abstract public void act(List<Animal> newAnimals);

    /**
     * locates plants for the prey to feed on
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant){ 
                Plant newPlant = (Plant) plant;
                newPlant.setDead();
                foodLevel = newPlant.getFoodValue();
                return where;
            }
        }
        return null;
    }
}
