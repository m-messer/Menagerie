import java.util.List;
import java.util.Iterator;

/**
 * This class is for all the predators in the simulation.
 *
 * @version (03/03/2021)
 */
public abstract class Predator extends Animal
{
    // instance variables - replace the example below with your own
    // Characteristics shared by all predators (class variables).

    // The age at which a lion can start to breed.
    protected static int BREEDING_AGE;
    // The likelihood of a lion breeding.
    protected static double BREEDING_PROBABILITY;
    // The maximum number of births.
    protected static int MAX_LITTER_SIZE;
    // The food value of a single gazelle. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    protected static int GAZELLE_FOOD_VALUE = 9 ;
    protected static int ZEBRA_FOOD_VALUE = 15;
    protected static int BIRD_FOOD_VALUE = 5;


    /**
     * Constructor for objects of class Predator
     */
    public Predator(Field field, Location location, Time clock)
    {
        super(field, location, clock);
        alive = true;
        //this.field = field;
        setLocation(location);
        //super.foodLevel=5;
    }

    /**
     * Look for gazelles adjacent to the current location.
     * Only the first live gazelle is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Gazelle) {
                Gazelle gazelle = (Gazelle) animal;
                if(gazelle.isAlive()) { 
                    gazelle.setDead();
                    foodLevel = GAZELLE_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if(zebra.isAlive()) { 
                    zebra.setDead();
                    foodLevel = ZEBRA_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Bird) {
                Bird bird = (Bird) animal;
                if(bird.isAlive()) { 
                    bird.setDead();
                    foodLevel = BIRD_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
