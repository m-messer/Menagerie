import java.util.List;
import java.util.Iterator;

/**
 * Write a description of class Zebra here.
 *
 * @version (03/03/2021)
 */
public class Zebra extends Prey
{
    // instance variables - replace the example below with your own
    // The age at which a gazelle can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a gazelle breeding.
    private static final double BREEDING_PROBABILITY = 0.14;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    /**
     * Constructor for objects of class Zebra
     */
    public Zebra(boolean randomAge, Field field, Location location, Time clock)
    {
        super(field, location, clock);
        name = "Zebra";
        MAX_AGE = 35;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * Determines how the Zebras will act.
     * they can give birth, age, eat, and die.
     */public void act(List<Animal> newzebras)
    {
        
        if(clock.getHour() < 7 && clock.getHour() > 6) {
            incrementAge();
            if(isAlive()) {
                giveBirth(newzebras);            
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        //checkForDisease();
    }

    /**
     * Allows Zebras to give birth.
     */
    private void giveBirth(List<Animal> newzebras)
    {
        // New gazelles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Zebra young = new Zebra(false, field, loc, clock);
            newzebras.add(young);
        }
    }

    /**
     * determines the number of babies that are made.
     */private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * @return name.
     */
    protected String getName()
    {
        return name;
    }

     /** Checks whether the lions in the adjacent locations are of opposite genders.
     * @return true if they are
     * @return false if they are not
     */
    protected boolean difSexBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if(this.isMale() == zebra.isMale()) { 
                    return true;
                }
            }
        }
        return false;
    }
}
