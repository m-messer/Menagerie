import java.util.List;

/**
 * This class represents the sheep specie in the simulation.
 * It defines the specific actions of the sheeps such as creating a sheep baby
 * and their daily routine.
 * It specifies the fields of all sheep as well
 *
 * @version 01.03.2021
 */
public class Sheep extends Animal {

    // The age where the animal can start breeding
    private static final int BREEDING_AGE = 6;
    // Maximum age of the animal
    private static final int MAX_AGE = 100;
    // Probability of an animal to breed
    private static final double BREEDING_PROBABILITY = 0.94;
    // The maximum number of children can be created
    private static final int MAX_LITTER_SIZE = 4;
    // Maximum food that an animal can have
    private static final int MAX_FOOD_LEVEL = 23;
    // Objects (classes) that an animal can consume
    private static final Class[] FOOD_LIST = {Grass.class, Pumpkin.class};
    // The layer of view where the Deer looks for its food
    private static final int FOOD_LAYER = 0;

    /**
     * Create a new sheep at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param randomAge Flag whether the sheep can have randomly allocated age
     */
    public Sheep(boolean randomAge, Field field, Location location) {
        super(field, location, randomAge, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL, FOOD_LIST);
    }


    /**
     * It executes the actions that a sheep can do based on the given conditions
     *
     * @param newSheeps A list to receive newly born Sheeps.
     */
    @Override
    public void act(List<Animal> newSheeps) {
        incrementAge();
        incrementHunger();
        simulateInfection();
        if (isAlive()) {
            if (getIsFemale() && findMate()) {
                giveBirth(newSheeps);
            }

            // Move towards a source of food if found.
            Location newLocation = findFood(FOOD_LAYER);
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * It creates a new sheep object
     *
     * @param field The field that it occupies
     * @param loc   The location within the field.
     * @return The new sheep object that is created
     */
    public Sheep createBaby(Field field, Location loc) {
        Sheep young = new Sheep(false, field, loc);
        return young;
    }

}
