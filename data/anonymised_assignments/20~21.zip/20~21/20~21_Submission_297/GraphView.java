import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.*;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.util.concurrent.CountDownLatch;

/**
 * GraphView is the class which handles all the line graphs
 * and displays them on screen using JavaFX.
 * <p>
 * Source for the methods which get the this view running using threads:
 * https://stackoverflow.com/questions/25873769/launch-javafx-application-from-another-class
 *
 * @version 01.03.2021
 */
public class GraphView extends Application {
    private XYChart.Series currentInfection;
    private XYChart.Series totalInfection;
    private XYChart.Series totalDeath;

    private XYChart.Series mousePopulation;
    private XYChart.Series sheepPopulation;
    private XYChart.Series deerPopulation;
    private XYChart.Series bearPopulation;
    private XYChart.Series wolfPopulation;

    private XYChart.Series grassPopulation;
    private XYChart.Series pumpkinPopulation;

    private XYChart.Series clearSkyPopulation;
    private XYChart.Series rainPopulation;
    private XYChart.Series cloudPopulation;

    private LineChart<Number, Number> populationLineChart;
    private LineChart<Number, Number> virusLineChart;
    private LineChart<Number, Number> plantLineChart;
    private LineChart<Number, Number> weatherLineChart;

    public static final CountDownLatch latch = new CountDownLatch(1);
    public static GraphView graphView = null;

    /**
     * Waits for setGraphView to finish and then returns the graphView object.
     * This method is taken and modified from the source mentioned in the class comment.
     *
     * @return This object of GraphView
     */
    public static GraphView waitForGraphView() {
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return graphView;
    }

    /**
     * Sets the graphViev and marks the work done.
     * This method is taken and modified from the source mentioned in the class comment.
     *
     * @param newGraphView The object of GraphView to be set.
     */
    public static void setGraphView(GraphView newGraphView) {
        graphView = newGraphView;
        latch.countDown();
    }

    /**
     * Constructor of GraphView, starts the initialization process.
     * This method is taken and modified from the source mentioned in the class comment.
     */
    public GraphView() {
        setGraphView(this);
    }

    /**
     * Creates the GridPane and 4 charts. Places the charts into the GridPane and
     * shows the stage.
     *
     * @param stage The stage of the view
     */
    @Override
    public void start(Stage stage) {
        stage.setTitle("Graphs");
        GridPane root = new GridPane();

        createPopulationLineChart();
        createVirusLineChart();
        createPlantLineChart();
        createWeatherLineChart();

        GridPane.setConstraints(populationLineChart, 0, 0);
        GridPane.setConstraints(virusLineChart, 1, 0);
        GridPane.setConstraints(plantLineChart, 0, 1);
        GridPane.setConstraints(weatherLineChart, 1, 1);
        root.getChildren().addAll(populationLineChart, virusLineChart, plantLineChart, weatherLineChart);

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Creates the Animal Population line chart, sets up the x,y Axis. Creates the
     * spieces specific population chart series and sets their names. Then the
     * population chart series are added to the population line chart
     */
    public void createPopulationLineChart() {
        // create the x,y Axis
        final NumberAxis xAxisPopulation = new NumberAxis();
        final NumberAxis yAxisPopulation = new NumberAxis();
        xAxisPopulation.setLabel("Number of Steps");
        yAxisPopulation.setLabel("Number of Animals");

        // create the chart
        populationLineChart = new LineChart<Number, Number>(xAxisPopulation, yAxisPopulation);
        populationLineChart.setPrefSize(850, 550);
        populationLineChart.setTitle("Animal Population");

        // create the animal specific chart series
        mousePopulation = new XYChart.Series();
        sheepPopulation = new XYChart.Series();
        deerPopulation = new XYChart.Series();
        bearPopulation = new XYChart.Series();
        wolfPopulation = new XYChart.Series();

        // set the names for the chart series
        mousePopulation.setName("Mouse");
        sheepPopulation.setName("Sheep");
        deerPopulation.setName("Deer");
        bearPopulation.setName("Bear");
        wolfPopulation.setName("Wolf");

        // add the animal species specific chart series to the animal population chart
        populationLineChart.getData().add(mousePopulation);
        populationLineChart.getData().add(sheepPopulation);
        populationLineChart.getData().add(deerPopulation);
        populationLineChart.getData().add(bearPopulation);
        populationLineChart.getData().add(wolfPopulation);
    }

    /**
     * Creates the Virus line chart, sets up the x,y Axis. Creates the Virus data
     * chart series and sets their names. Then the Virus chart series are added to
     * the virus line chart
     */
    public void createVirusLineChart() {
        // create the x,y Axis
        final NumberAxis xAxisVirus = new NumberAxis();
        final NumberAxis yAxisVirus = new NumberAxis();
        xAxisVirus.setLabel("Number of Steps");
        yAxisVirus.setLabel("Number of Animals");

        // create the chart
        virusLineChart = new LineChart<Number, Number>(xAxisVirus, yAxisVirus);
        virusLineChart.setPrefSize(850, 550);
        virusLineChart.setTitle("Spread of virus");

        // create the Virus data chart series
        currentInfection = new XYChart.Series();
        totalInfection = new XYChart.Series();
        totalDeath = new XYChart.Series();

        // set the names for the chart series
        currentInfection.setName("Current Infection");
        totalInfection.setName("Total Infection");
        totalDeath.setName("Total Deaths");

        // add the animal species specific chart series to the virus chart
        virusLineChart.getData().add(currentInfection);
        virusLineChart.getData().add(totalInfection);
        virusLineChart.getData().add(totalDeath);
    }

    /**
     * Creates the Plant population line chart, sets up the x,y Axis. Creates the
     * plant species specific chart series and sets their names. Then the plant
     * species specific series are added to the plant population line chart
     */
    public void createPlantLineChart() {
        // create the x,y Axis
        final NumberAxis xAxisPlants = new NumberAxis();
        final NumberAxis yAxisPlants = new NumberAxis();
        xAxisPlants.setLabel("Number of Steps");
        yAxisPlants.setLabel("Number of Plants");

        // create the chart
        plantLineChart = new LineChart<Number, Number>(xAxisPlants, yAxisPlants);
        plantLineChart.setPrefSize(850, 550);
        plantLineChart.setTitle("Plants");

        // create the plant species chart series
        grassPopulation = new XYChart.Series();
        pumpkinPopulation = new XYChart.Series();

        // set the names for the chart series
        grassPopulation.setName("Grass");
        pumpkinPopulation.setName("Pumpkin");

        // add the plant species specific chart series to the plant population chart
        plantLineChart.getData().add(grassPopulation);
        plantLineChart.getData().add(pumpkinPopulation);
    }

    /**
     * Creates the Weather line chart, sets up the x,y Axis. Creates the weather
     * type specific chart series and sets their names. Then the weather type
     * specific series are added to the weather line chart
     */
    public void createWeatherLineChart() {
        // create the x,y Axis
        final NumberAxis xAxisWeather = new NumberAxis();
        final NumberAxis yAxisWeather = new NumberAxis();
        xAxisWeather.setLabel("Number of Steps");
        yAxisWeather.setLabel("Number of Weather");

        // create the chart
        weatherLineChart = new LineChart<Number, Number>(xAxisWeather, yAxisWeather);
        weatherLineChart.setPrefSize(850, 550);
        weatherLineChart.setTitle("Weather");

        // create the weather type chart series
        clearSkyPopulation = new XYChart.Series();
        rainPopulation = new XYChart.Series();
        cloudPopulation = new XYChart.Series();

        // set the names for the chart series
        clearSkyPopulation.setName("Clear Sky");
        rainPopulation.setName("Rain");
        cloudPopulation.setName("Cloud");

        // add the weather type specific chart series to the weather line chart
        weatherLineChart.getData().add(clearSkyPopulation);
        weatherLineChart.getData().add(rainPopulation);
        weatherLineChart.getData().add(cloudPopulation);
    }

    /**
     * Adds data to the animal species specific chart series
     * and updates the animela population line graph.
     *
     * @param step                  The current step of the simulation
     * @param mousePopulationNumber The number of mice in the simulation
     * @param sheepPopulationNumber The number of sheeps in the simulation
     * @param deerPopulationNumber  The number of deers in the simulation
     * @param bearPopulationNumber  The number of bears in the simulation
     * @param wolfPopulationNumber  The number of wolves in the simulation
     */
    public void addPopulationData(int step, int mousePopulationNumber, int sheepPopulationNumber,
                                  int deerPopulationNumber, int bearPopulationNumber, int wolfPopulationNumber) {
        Platform.runLater(() -> {
            mousePopulation.getData().add(new XYChart.Data(step, mousePopulationNumber));
            sheepPopulation.getData().add(new XYChart.Data(step, sheepPopulationNumber));
            deerPopulation.getData().add(new XYChart.Data(step, deerPopulationNumber));
            bearPopulation.getData().add(new XYChart.Data(step, bearPopulationNumber));
            wolfPopulation.getData().add(new XYChart.Data(step, wolfPopulationNumber));
        });
    }

    /**
     * Adds data to all the virus data chart series
     * and updates the virus line chart.
     *
     * @param step                   The current step of the simulation
     * @param currentInfectionNumber The number of currently infected animals
     * @param totalInfectionNumber   The numebr of infected animals in total
     * @param totalDeathNumber       The number of deaths caused by the virus in total
     */
    public void addVirusData(int step, int currentInfectionNumber, int totalInfectionNumber, int totalDeathNumber) {
        Platform.runLater(() -> {
            currentInfection.getData().add(new XYChart.Data(step, currentInfectionNumber));
            totalInfection.getData().add(new XYChart.Data(step, totalInfectionNumber));
            totalDeath.getData().add(new XYChart.Data(step, totalDeathNumber));
        });
    }

    /**
     * Adds data to all the plant species specific chart series
     * and updates the plant population line chart.
     *
     * @param step                    The current step of the simulation
     * @param grassPopulationNumber   The number of grass in the population
     * @param pumpkinPopulationNumber The number of pumpkins in the population
     */
    public void addPlantData(int step, int grassPopulationNumber, int pumpkinPopulationNumber) {
        Platform.runLater(() -> {
            grassPopulation.getData().add(new XYChart.Data(step, grassPopulationNumber));
            pumpkinPopulation.getData().add(new XYChart.Data(step, pumpkinPopulationNumber));
        });
    }

    /**
     * Adds data to all the weather type specific chart series
     * and updates the weather line chart.
     *
     * @param step                     The current step of the simulation
     * @param clearSkyPopulationNumber The number of locations with clear skies weather
     * @param rainPopulationNumber     The number of locations with rain weather
     * @param cloudPopulationNumber    The number of locations with cloudy weather
     */
    public void addWeatherData(int step, int clearSkyPopulationNumber, int rainPopulationNumber,
                               int cloudPopulationNumber) {
        Platform.runLater(() -> {
            clearSkyPopulation.getData().add(new XYChart.Data(step, clearSkyPopulationNumber));
            rainPopulation.getData().add(new XYChart.Data(step, rainPopulationNumber));
            cloudPopulation.getData().add(new XYChart.Data(step, cloudPopulationNumber));
        });
    }
}
