import java.util.List;

/**
 * This class represents wolf specie in the simulation.
 * It defines the specific actions of the wolves such as creating a wolf baby
 * and their daily routine.
 * It specifies the fields of all wolves as well
 *
 * @version 01.03.2021
 */
public class Wolf extends Animal {

    // The age where the animal can start breeding
    private static final int BREEDING_AGE = 8;
    // Maximum age of the animal
    private static final int MAX_AGE = 85;
    // Probability of an animal to breed
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of children can be created
    private static final int MAX_LITTER_SIZE = 4;
    // Maximum food that an animal can have
    private static final int MAX_FOOD_LEVEL = 31;
    // Objects (classes) that a Bear can consume
    private static final Class[] FOOD_LIST = {Mouse.class, Sheep.class};
    // The layer of view where a Bear looks for food
    private static final int FOOD_LAYER = 1;

    /**
     * Create a new wolf at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param randomAge Flag whether the wolf can have randomly allocated age
     */
    public Wolf(boolean randomAge, Field field, Location location) {
        super(field, location, randomAge, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL, FOOD_LIST);
    }


    /**
     * It executes the actions that a wolf can do based on the given conditions
     *
     * @param newWolves A list to receive newly born Wolves.
     */
    @Override
    public void act(List<Animal> newWolves) {
        incrementAge();
        incrementHunger();
        simulateInfection();
        if (isAlive()) {
            if (getIsFemale() && findMate()) {
                giveBirth(newWolves);
            }

            //A Wolf only hunts for food and moves at night and in the afternoon
            if (TimeCycle.getIsAfternoon() || TimeCycle.getIsNight()) {
                Location newLocation = findFood(FOOD_LAYER);
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * It creates a new wolf object
     *
     * @param field The field that it occupies
     * @param loc   The location within the field.
     * @return The new wolf object that is created
     */
    @Override
    public Wolf createBaby(Field field, Location loc) {
        Wolf young = new Wolf(false, field, loc);
        return young;
    }
}
