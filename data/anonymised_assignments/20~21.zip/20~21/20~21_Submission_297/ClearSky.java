import java.util.Iterator;
import java.util.List;


/**
 * This class is a representation of clear sky weather in the simulation
 * This kind of weather can multiply/spread and
 * take over Rain weather types.
 *
 * @version 01.03.2021
 */
public class ClearSky extends Weather {

    // Probability of a weather type to multiply
    private static final double Multiplying_PROBABILITY = 0.6;
    // The maximum number of place where a ClearSky can extend
    private static final int MAX_LITTER_SIZE = 2;

    /**
     * Create a new ClearSky at location in field.
     *
     * @param field    The field that it occupies
     * @param location The location within the field.
     */
    public ClearSky(Field field, Location location) {
        super(field, location, Multiplying_PROBABILITY, MAX_LITTER_SIZE);
    }

    /**
     * It looks for Rain type of weather in the nearby locations
     * and takes it over if there is
     *
     * @return The new location of the CLearSky object
     */
    protected Location changeWeather() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), 2);
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object weather = field.getObjectAt(where);
            if (weather instanceof Rain) {

                Rain rain = (Rain) weather;
                if (rain.isAlive()) {
                    rain.setDead();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * It creates a new ClearSky object
     *
     * @param field The field that it occupies
     * @param loc   The location within the field.
     * @return The new ClearSky object
     */
    public Weather createNewWeather(Field field, Location loc) {
        return new ClearSky(field, loc);
    }

}
