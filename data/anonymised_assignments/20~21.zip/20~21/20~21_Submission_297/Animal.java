import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.02.28
 */
public abstract class Animal {
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's sex
    private boolean isFemale;
    // The animal's infection status
    private boolean infected;
    // The animal's current food level
    private int foodLevel;
    // The age where the animal can start breeding
    private int breedingAge;
    // Maximum age of the animal
    private int maxAge;
    // Probability of an animal to breed
    private double breedingProbability;
    // The maximum number of children can be created
    private int maxLitterSize;
    //The age of the animal
    private int age;
    // Maximum food that an animal can have
    private int maxFoodLevel;
    // Objects (classes) that an animal can consume
    private Class[] foodList;
    // The flag that shows if an animal has been infected
    private boolean wasInfected;


    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     *
     * @param field               The field currently occupied.
     * @param location            The location within the field.
     * @param randomAge           Flag whether an animal can have randomly allocated age
     * @param breedingAge         The age where the animal can start breeding
     * @param maxAge              Maximum age of the animal
     * @param breedingProbability Probability of an animal to breed
     * @param maxLitterSize       The maximum number of children can be created
     * @param maxFoodLevel        Maximum food that an animal can have
     */
    public Animal(Field field, Location location, boolean randomAge, int breedingAge, int maxAge,
                  double breedingProbability, int maxLitterSize, int maxFoodLevel, Class[] foodList) {
        alive = true;
        this.field = field;
        this.isFemale = rand.nextBoolean();
        setLocation(location);
        this.breedingAge = breedingAge;
        this.breedingProbability = breedingProbability;
        this.maxLitterSize = maxLitterSize;
        this.maxFoodLevel = maxFoodLevel;
        this.maxAge = maxAge;
        this.foodList = foodList;
        wasInfected = false;

        if (randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = maxFoodLevel;
        } else {
            age = 0;
            foodLevel = maxFoodLevel / 4;
        }
    }

    /**
     * Make this animal act - that is: make it do whatever it wants/needs to do.
     *
     * @param newAnimals A list to receive newly born animals.
     */
    abstract protected void act(List<Animal> newAnimals);

    /**
     * It creates a baby for a specific animal type object
     *
     * @param field The field that it occupies
     * @param loc   The location within the field.
     * @return null
     */
    abstract protected Animal createBaby(Field field, Location loc);


    /**
     * Check whether the animal is female or not
     *
     * @return true of the animal is female
     */
    protected boolean getIsFemale() {
        return isFemale;
    }

    /**
     * Check whether the animal is alive or not.
     *
     * @return true if the animal is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive. It is removed from the field
     */
    protected void setDead() {
        if (getIsInfected()) {
            Virus.decreaseInfectedCount();
        }
        infected = false;
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Simulate the infection in animal's body.
     * Based ont the recovery probability the animal can die or recover from the disease
     */
    protected void simulateInfection() {
        if (isAlive() && getIsInfected()) {
            if (rand.nextDouble() <= Virus.getRecoverProbability()) {
                recover();
            } else if (rand.nextDouble() <= Virus.getDeathProbability()) {
                infectionDeath();
            }
        }
    }

    /**
     * It sets the animal dead and increase the total death count of the virus
     */
    protected void infectionDeath() {
        Virus.increaseDeadCount();
        setDead();
    }


    /**
     * It looks for objects in the adjacent locations and
     * moves the animal of there is a consumable object (animal specific)
     * The consumed object is set dead and its food value added to the animals food level
     *
     * @param foodLayer The layer where animal searches the food
     * @return location of the new animal
     */
    protected Location findFood(int foodLayer) {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), foodLayer);
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);

            //if the animal is a predator
            if (object instanceof Animal) {
                //check consumable classes
                for (Class food : foodList) {
                    if (object.getClass() == food) {
                        Animal animal = (Animal) object;
                        if (animal.isAlive()) {
                            animal.setDead();
                            setFoodLevel(animal.getFoodValue());
                            return new Location(where.getRow(), where.getCol(), getLocation().getLayer());
                        }
                    }
                }
            }

            //if the animal eats plants
            if (object instanceof Plant) {
                //check consumable classes
                for (Class food : foodList) {
                    if (object.getClass() == food) {
                        Plant plant = (Plant) object;
                        if (plant.isAlive()) {
                            plant.setDead();
                            setFoodLevel(plant.getFoodValue());
                            return new Location(where.getRow(), where.getCol(), getLocation().getLayer());
                        }
                    }
                }
            }
        }

        return null;

    }

    /**
     * Return the animal's location.
     *
     * @return The animal's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     *
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     *
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Sets the animal to infected and increases the current number of infected animals
     */
    protected void infected() {
        if (!getIsInfected() && isAlive() && !wasInfected) {
            infected = true;
            wasInfected = true; //animal gains immunity
            Virus.increaseInfectedCount();
        }

    }

    /**
     * Set animal to not infected and decrease the current infection count
     */
    protected void recover() {
        if (getIsInfected() && isAlive()) {
            infected = false;
            Virus.decreaseInfectedCount();
        }

    }

    /**
     * Check whether an animal is in infected
     *
     * @return true if the animal is infected
     */
    protected boolean getIsInfected() {
        return infected;
    }

    /**
     * Decreases the food level
     * If food level is less than or equal to zero then set animal dead
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        } else if (foodLevel > maxFoodLevel) {
            foodLevel = maxFoodLevel;
        }
    }

    /**
     * Sets the food level of the animal to the given parameter
     *
     * @param newFoodLevel The new food level of the animal
     */
    protected void setFoodLevel(int newFoodLevel) {
        foodLevel = newFoodLevel;
    }


    /**
     * Looks for a potential mate in the adjacent locations and
     * return true if there is one.
     * Set the other animal infected if it is and vice versa
     *
     * @return true if the animal found a mate in the adjacent locations
     */
    protected boolean findMate() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), getLocation().getLayer());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Animal) {
                Animal potentialMate = (Animal) animal;
                if (this.getClass().equals(potentialMate.getClass())) {
                    if (potentialMate.isAlive()) {
                        if (!potentialMate.getIsFemale() && potentialMate.getAge() >= breedingAge) {
                            if (potentialMate.getIsInfected()) {
                                infected();
                            } else if (getIsInfected()) {
                                potentialMate.infected();
                            }

                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }


    /**
     * Returns the age of the animal (getter)
     *
     * @return The age of the animal
     */
    protected int getAge() {
        return age;
    }


    /**
     * Based on the breeding probability and the maximum litter size,
     * the number of children born is calculated
     *
     * @return The number of young animals born from a breeding
     */
    protected int breed() {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= breedingProbability) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * Check if the animal is older than the breeding age, therefore able to breed
     *
     * @return true if the age is equal or more than breeding age
     */
    protected boolean canBreed() {
        return age >= breedingAge;
    }


    /**
     * Create the new animals and put them into locations.
     * Add then to the list and make them infected if parents were infected
     *
     * @param newAnimals A list to receive newly born animals.
     */
    protected void giveBirth(List<Animal> newAnimals) // animal specific
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = createBaby(field, loc);
            if (getIsInfected()) {
                young.infected();
            }
            newAnimals.add(young);
        }
    }

    /**
     * Increments the age.
     * If age is bigger than the maximum age then set the animal to dead
     */
    protected void incrementAge() {
        age++;
        if (age > maxAge) {
            setDead();
        }
    }

    /**
     * Check the maximum food level that an animal can have and returns it (getter)
     *
     * @return The maximum food value that the animal can have
     */
    protected int getMaxFoodLevel() {
        return maxFoodLevel;
    }

    /**
     * Calculates the value of food that is gained after consuming the object
     *
     * @return The food value that animal can gain by consuming its food
     */
    protected int getFoodValue() {
        return maxFoodLevel / 2 + (maxFoodLevel / 2 * (age / maxAge));
    }

}
