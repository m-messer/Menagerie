import java.util.List;

/**
 * This class represents bear specie in the simulation.
 * It defines the specific actions of the bears such as creating a bear baby
 * and their daily routine.
 * It specifies the fields of all bears as well
 *
 * @version 01.03.2021
 */
public class Bear extends Animal {

    // The age where the animal can start breeding
    private static final int BREEDING_AGE = 30;
    // Maximum age of the animal
    private static final int MAX_AGE = 150;
    // Probability of an animal to breed
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of children can be created
    private static final int MAX_LITTER_SIZE = 4;
    // Maximum food that an animal can have
    private static final int MAX_FOOD_LEVEL = 100;
    // Objects (classes) that a Bear can consume
    private static final Class[] FOOD_LIST = {Deer.class, Sheep.class};
    // The layer of view where a Bear looks for food
    private static final int FOOD_LAYER = 1;

    /**
     * Create a new bear at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param randomAge Flag whether the bear can have randomly allocated age
     */
    public Bear(boolean randomAge, Field field, Location location) {
        super(field, location, randomAge, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL, FOOD_LIST);
    }


    /**
     * It executes the actions that a bear can do based on the given conditions
     *
     * @param newBears A list to receive newly born Bears.
     */
    @Override
    public void act(List<Animal> newBears) {
        incrementAge();
        incrementHunger();
        simulateInfection();
        if (isAlive()) {
            if (getIsFemale() && findMate()) {
                giveBirth(newBears);
            }
            // Bears sleep at night and hunt/move during the day
            if (!TimeCycle.getIsNight()) {

                Location newLocation = findFood(FOOD_LAYER);
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * It creates a new bear object
     *
     * @param field The field that it occupies
     * @param loc   The location within the field.
     * @return The new bear object that is created
     */
    @Override
    public Bear createBaby(Field field, Location loc) {
        Bear young = new Bear(false, field, loc);
        return young;
    }
}
