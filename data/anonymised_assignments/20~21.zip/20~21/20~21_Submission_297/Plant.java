import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version (a version number or a date)
 */
public abstract class Plant {

    // Whether the animal is alive or not.
    private boolean alive;
    // The plant's field.
    protected Field field;
    // The plant's position in the field.
    private Location location;
    //The value of the plant to an animal when its eaten
    private int foodValue;
    // The layer of view where the plants can get weather information from
    private static final int WEATHER_LAYER = 2;
    // The age where the plant can start spreading
    private int spreadingAge;
    // Maximum age of the plant
    private int maxAge;
    //The age of the plant
    private int age;
    // Probability of a plant to spread
    private double spreadingProbability;
    //The number of plants that can be created during spreading
    private int spreadSize;


    private static final Random rand = Randomizer.getRandom();


    /**
     * Create a new plant at location in field.
     *
     * @param randomAge            Flag whether a plant can have randomly allocated age
     * @param field                he plant's position in the field.
     * @param location             The value of the plant to an animal when its eaten
     * @param breedingAge          The age where the plant can start spreading
     * @param maxAge               Maximum age of the plant
     * @param spreadingProbability Probability of a plant to spread
     * @param foodValue            The value of the plant to an animal when its eaten
     */
    public Plant(boolean randomAge, Field field, Location location, int breedingAge, int maxAge, double spreadingProbability, int spreadSize, int foodValue) {
        alive = true;
        this.field = field;
        setLocation(location);

        this.spreadingAge = breedingAge;
        this.spreadingProbability = spreadingProbability;
        this.maxAge = maxAge;
        this.foodValue = foodValue;
        this.spreadSize = spreadSize;

        if (randomAge) {
            age = rand.nextInt(maxAge);

        } else {
            age = 0;
        }
    }

    /**
     * Make this plant act - that is: make it do whatever it wants/needs to do.
     *
     * @param newPlant A list to receive newly created animals.
     */
    public abstract void act(List<Plant> newPlant);

    /**
     * It returns a Plant object that is defined in the subclass
     *
     * @return A new Plant object
     */
    public abstract Plant createPlant(Field field, Location location);

    /**
     * Increment the age only if the conditions give
     * There is rain or clear sky
     */
    protected void grow() {

        if (isAlive()) {
            Object object = field.getObjectAt(location.getRow(), location.getCol(), WEATHER_LAYER);

            if (object != null) {
                if (object instanceof Rain || object instanceof ClearSky) {
                    incrementAge();
                }
            }
        }
    }

    /**
     * Check whether the plant is alive or not.
     *
     * @return true if the plant is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive. It is removed from the field
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * It creates new Plant objects and puts them to locations
     * 
     * @param newPumpkins A list to receive newly created Plant.
     */
    protected void multiply(List<Plant> newPumpkins) {
        // New pumpkins is born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = spread();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = createPlant(field, loc);
            newPumpkins.add(young);
        }
    }

    /**
     * Return the plant's location.
     *
     * @return The plant's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the plant at the new location in the given field.
     *
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's field.
     *
     * @return The plant's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Increments the age
     * If age is bigger than the maximum age then set the animal to dead
     */
    protected void incrementAge() {
        age++;
        if (age > maxAge) {
            setDead();
        }
    }

    /**
     * the number of new plants is  returned
     *
     * @return The number of new plants from a spreading
     */
    protected int spread() {
        int spreadSizeNumber = 0;
        if (canSpread() && rand.nextDouble() <= spreadingProbability) {
            spreadSizeNumber = spreadSize;
        }
        return spreadSizeNumber;
    }

    /**
     * Check if the plant is older than the spreding age, therefore able to spread
     *
     * @return true if the age is equal or more than spreading age
     */
    protected boolean canSpread() {
        return age >= spreadingAge;
    }

    /**
     * Calculates the value of food that is gained after consuming the object
     *
     * @return The food value that animal can gain by consuming its food
     */
    protected int getFoodValue() {
        return foodValue / 2 + (foodValue / 2 * (age / maxAge));
    }

    /**
     * Returns the age of the plant (getter)
     *
     * @return The age of the plant
     */
    public int getAge() {
        return age;
    }
}
