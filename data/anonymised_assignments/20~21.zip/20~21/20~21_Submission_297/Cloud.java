import java.util.Iterator;
import java.util.List;

/**
 * This class is a representation of cloudy weather in the simulation
 * This kind of weather can multiply/spread and
 * take over ClearSky weather types.
 *
 * @version 01.03.2021
 */
public class Cloud extends Weather {

    // Probability of a weather type to multiply
    private static final double Multiplying_PROBABILITY = 0.8;
    // The maximum number of place where the Cloud can extend to
    private static final int MAX_LITTER_SIZE = 2;

    /**
     * Create a new Cloud  at location in field.
     *
     * @param field    The field that it occupies
     * @param location The location within the field.
     */
    public Cloud(Field field, Location location) {
        super(field, location, Multiplying_PROBABILITY, MAX_LITTER_SIZE);
    }


    /**
     * It looks for ClearSky type of weather in the nearby locations
     * and takes it over if there is
     *
     * @return The new location of the Cloud object
     */
    protected Location changeWeather() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), 2);
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object weather = field.getObjectAt(where);
            if (weather instanceof ClearSky) {
                ClearSky clearSky = (ClearSky) weather;
                if (clearSky.isAlive()) {
                    clearSky.setDead();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * It creates a new Cloud object
     *
     * @param field The field that it occupies
     * @param loc   The location within the field.
     * @return The new Cloud object
     */
    public Weather createNewWeather(Field field, Location loc) {
        return new Cloud(field, loc);
    }

}

