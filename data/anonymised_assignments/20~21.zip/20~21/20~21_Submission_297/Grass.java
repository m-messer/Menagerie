import java.util.List;

/**
 * This class represents the grass plant specie in the simulation.
 * It defines the specific actions of the grass such as multiplying and its
 * behaviour.
 * It specifies the fields of all grass as well
 *
 * @version 01.03.2021
 */
public class Grass extends Plant {

    // The age when the plant can start breeding
    private static final int BREEDING_AGE = 1;
    // Maximum age of the plant
    private static final int MAX_AGE = 25;
    // Probability of a plant to multiply
    private static final double BREEDING_PROBABILITY = 1;
    // The the number of new grass created when multiplying
    private static final int SPREAD_SIZE = 4;
    // The food value of the plant when eaten
    private static final int FOOD_VALUE = 15;

    /**
     * Create a new grass at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param randomAge Flag whether the grass can have randomly allocated age
     */
    public Grass(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, SPREAD_SIZE, FOOD_VALUE);
    }

    /**
     * It executes the actions that a grass can do based on the given conditions
     *
     * @param newGrass A list to receive newly created Grass.
     */
    @Override
    public void act(List<Plant> newGrass) {

        // Grass only grows during the day
        if (!TimeCycle.getIsNight()) {
            grow();
            if (isAlive()) {
                multiply(newGrass);
            }
        }
    }

    /**
     * It creates a new Grass object and returns it
     *
     * @param field The field currently occupied.
     * @param loc   The location within the field.
     * @return A new grass object
     */
    @Override
    public Plant createPlant(Field field, Location loc) {
        return new Grass(false, field, loc);
    }
}
