import java.util.List;
import java.util.Random;


/**
 * A class representing shared characteristics of weather types.
 *
 * @version 2021.02.28
 */
public abstract class Weather {


    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The maximum number of weat can be created
    private int maxLitterSize;
    // Probability of a weather to multiply
    private  double multiplyingProbability;

    private static final Random rand = Randomizer.getRandom();


    /**
     * Create a new weather at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param multiplyingProbability   // The maximum number of place where the weather can extend to
     * @param maxLitterSize  // Probability of a weather to multiply
     */
    public Weather( Field field, Location location, double multiplyingProbability, int maxLitterSize)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.multiplyingProbability=multiplyingProbability;
        this.maxLitterSize=maxLitterSize;

    }


    /**
     *Make this weather act - that is: make it do whatever it wants/needs to do.
     *
     * @param newWeather A list to receive newly created weathers.
     */
    protected void act(List<Weather> newWeather){

        if(isAlive()) {
            multiply(newWeather);
            // Move towards a source of space if found.
            Location newLocation = changeWeather();
            // See if it was possible to move.
            if(newLocation != null) {
                Location previousLocation = getLocation();
                Field field = getField();
                setLocation(newLocation);
                Weather young = createNewWeather(field,previousLocation);
                newWeather.add(young);
            }
            else {
                // Overcrowding
                Location location = getLocation();
                Field field = getField();
                setDead();
                Weather young =  createNewWeather(field,location);
                newWeather.add(young);
            }
        }

    }


    protected abstract Location changeWeather();

    /**
     * Check whether the weather is exists or not.
     *
     * @return true if the weather is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     *Indicate that the weather is no longer exists. It is removed from the field
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the weather's location.
     *
     * @return The weather's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the weather at the new location in the given field.
     *
     * @param newLocation The weather's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the weather's field.
     *
     * @return The weather's field.
     */
    protected Field getField()
    {
        return field;
    }


    /**
     * Based on the multiplying probability and the maximum litter size,
     * the number of new weather places is calculated
     *
     * @return The number of weather born from a multiplying
     */
    protected int spread()
    {
        int births = 0;
        if(rand.nextDouble() <= multiplyingProbability) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * Create the new weathers and put them too locations.
     * Add them to the list
     *
     * @param newClearSkies A list to receive newly born animals.
     */
    protected void multiply(List<Weather> newClearSkies)
    {

        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = spread();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Weather young = createNewWeather(field, loc);
            newClearSkies.add(young);
        }
    }

    /**
     * It creates a new Weather object
     *
     * @param field The field that it occupies
     * @param loc The location within the field.
     * @return The new weather object
     */
    protected abstract Weather createNewWeather(Field field, Location loc);
}


