import java.util.List;

/**
 * This class represents the mouse specie in the simulation.
 * It defines the specific actions of the mice such as creating a mouse baby
 * and their daily routine.
 * It specifies the fields of all mice as well
 *
 * @version 01.03.2021
 */
public class Mouse extends Animal {

    // The age where the animal can start breeding
    private static final int BREEDING_AGE = 8;
    // Maximum age of the animal
    private static final int MAX_AGE = 30;
    // Probability of an animal to breed
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of children can be created
    private static final int MAX_LITTER_SIZE = 2;
    // Maximum food that an animal can have
    private static final int MAX_FOOD_LEVEL = 31;
    // Objects (classes) that an animal can consume
    private static final Class[] FOOD_LIST = {Grass.class, Pumpkin.class};
    // The layer of view where the Deer looks for its food
    private static final int FOOD_LAYER = 0;

    /**
     * Create a new mouse at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param randomAge Flag whether the mouse can have randomly allocated age
     */
    public Mouse(boolean randomAge, Field field, Location location) {
        super(field, location, randomAge, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_LEVEL, FOOD_LIST);
    }

    /**
     * It executes the actions that a mouse can do based on the given conditions
     *
     * @param newMice A list to receive newly born mice.
     */
    @Override
    public void act(List<Animal> newMice) {
        incrementAge();
        incrementHunger();
        simulateInfection();
        if (isAlive()) {
            if (getIsFemale() && findMate()) {
                giveBirth(newMice);
            }
            // Move towards a source of food if found.
            Location newLocation = findFood(FOOD_LAYER);
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * It creates a new mouse object
     *
     * @param field The field that it occupies
     * @param loc   The location within the field.
     * @return The new mouse object that is created
     */
    @Override
    public Mouse createBaby(Field field, Location loc) {
        Mouse young = new Mouse(false, field, loc);
        return young;
    }

}
