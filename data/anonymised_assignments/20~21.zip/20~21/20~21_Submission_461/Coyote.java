
/**
  * Coyote class - a class to be used in the simulation to simulate
                  coyote. This class will have all the unique features of a 
                  coyote for example every coyote have different breeding 
                  probabilities compared to wolves.
 *
 * @version 2016.02.29 (2)
 */
public class Coyote extends Predator
{
    // Characteristics shared by all Coyotees (class variables).
    
    // Breeding age for a coyote to start breeding 
    private static final int BREEDING_AGE = 70;
    // maximum age a coyote can live up to
    private static final int MAX_AGE = 200;
    // the probability of a coyote winning against a wolf
    private static final double COYOTE_WIN_PROB = 0.2;
    // constant: default breeding probability for all coyotes
    private static final double DEFAULT_BREEDING_PROBABILITY = 0.4;
    // the breeding probability that can change with each coyote
    private static  double breedingProbability = DEFAULT_BREEDING_PROBABILITY;
    // the maximum litter size of each coyote
    private static final int MAX_LITTER_SIZE = 1;
    
    
    

    /**
     * Create a coyote. A coyote can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the coyote will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The simulation the coyote is in 
     */
    public Coyote(boolean randomAge, Field field, Location location,Simulator simulation)
    {
        super(randomAge,field, location,simulation);
    }

    /**
     * This method returns the breeding age of a coyote
     * 
     * @return Integer value of the coyote breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * This method returns the maximum age of a coyote
     * 
     * @return Integer value of the coyote maximum age
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * This method returns the breeding probability of a coyote
     * 
     * @return Double value of the coyote breeding probability
     */
    public double getBreedingProbability(){
        return breedingProbability;
    }
    
    /**
     * This method returns the maximum litter size of a coyote
     * 
     * @return Integer value of the coyote maximum litter size
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * This method will change the breeding probability of the coyote depending
     * on the weather condition and if the coyote is diseased
     * 
     * @param Integer value to indicate the weather condition
     */
    public void changeBreedingProbability(int weather){
        // check if weather is raining or the Coyote is diseased
        if (weather == 1 || getDisease()){
                // divide breeding by 2 because raining lower breeding probability
                breedingProbability /= 2;
        }
        // check if weather is hot
        if (weather == 0){
                // hot weather increases breeding probability
                breedingProbability *= 3;
        }
        // if the weather is anything else then the probability would be default
        else{
            setBreedingDefault();
        }
    }
    
    /**
     * This method will change the breeding probability of the coyote back to 
     * its default probability
     */
    protected void setBreedingDefault(){
        // breeding proability resets back to default
        breedingProbability = DEFAULT_BREEDING_PROBABILITY;
    }
    
    /**
     * Look for wolf adjacent to the current location.
     * Only the first live wolf is killed.
     * @param object of Finder class to be used to find a wolf
     * @return Where wolf was found, or null if it wasn't.
     */
    public Location compete(Finder find)
    {
        // find wolf in the area
        Wolf wolf = find.findWolf();
        // check if wolf exist
        if (wolf != null){
            // check if wolf is alive

            if (wolf.isAlive()&& getRandom().nextDouble() <=COYOTE_WIN_PROB){
            // check if conditions are satisfied
                 // check if wolf is diseased
             if (wolf.getDisease() && !this.getDisease()){
                     // change current coyote to be diseased
                    super.changeDisease();
                }
                else if (wolf.getDisease()&& this.getDisease()){
                    // predator catches diseased
                    this.changeDisease();
                    getSimulation().decreaseCount();
                }
                //kill the wolf
                wolf.setDead();
                // return the location of the wolf for the coyote new location
                return wolf.getLocation();
            
         } 
        }
    
        // find common food eaten by predators
        return super.preyFood(find);
    }
    
    
    /**
     * This method returns a new object of a Coyote class
     * 
     * @return object of the Coyote class
     */
    public Animal getNewAnimal(Field field,Location location){
        // returns a new object of the Coyote class for breeding
        return new Coyote(false, field, location,super.getSimulation());
    }
        

}
