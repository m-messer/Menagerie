import java.util.List;
import java.util.Random;
/**
 * Prey class - an abstract class to be used in the simulation to simulate
                preys which include Guinea pigs and deers. This class will
                have all the features of every prey animal for example 
                every prey animal can eat grass.
 *
 * @version (a version number or a date)
 */
public abstract class Prey extends Animal
{
    //food value of grass
    private static final int GRASS_FOOD_VALUE = 50;

    /**
     * Create a new prey animal which inherites from the Animal class.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge - determines if animal has a random age or not.
     * @param simulation - object of the Simulator class for the animal to reference.
     */
    public Prey(boolean randomAge, Field field, Location location,Simulator simulation){
        super(randomAge,field,location,simulation);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * This method will allow the prey to move if it's night time 
     * as well as give birth to more prey.
     * 
     * @param newOrganism A list to receive newly born animals.
     */
    public void act(List<Organism> newOrganism)
    {
        // Finder object to find plants near a prey
        Finder find = new Finder(getField(),getLocation());
        // simulation the prey is in 
        Simulator simulation = getSimulation();
        // day and night cycle for the prey to sleep and be awake
        Environment enviro = getSimulation().getEnvironment();
        // check if it is day as well as make sure prey sleep during mid day
        if(enviro.getDay() && enviro.getTime() <= 10){
            // increment the age
            incrementAge();
            // make prey hungrier
            decrementHunger();
            // check if the prey has the disease
            if(getDisease()){
                // lower the disease time for the prey to be cured
                    decrementDiseaseTime();
                }
            // check if prey is alive in order for them to act
            if(isAlive()) {
                if(getDisease()){
                // lower the disease time for the prey to be cured
                    decrementDiseaseTime();
                    super.canSpreadDisease();
                }
                if(getDisease()){
                // lower the disease time for the prey to be cured
                    decrementDiseaseTime();
                }
                if (simulation.getDisease()&& !getDisease() ){
                    // check if prey is able to catch the disease
                    super.catchDisease();
                }
    
                // spread the disease if they have it
                super.canSpreadDisease();
                // change breeding probability based on weather
                changeBreedingProbability(getSimulation().getWeather());  
                // retrieve new location based on grass food location
                Location newLocation = grassFood(find);
                // check if the location returned is valid
                if(newLocation == null){
                    // get a different free location 
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // check if the new location is valid
                if(newLocation == null) {
                    // Overcrowding.
                    //check if current prey has the disease to lower the count
                    if (getDisease()){
                        // lower the disease count
                        changeDisease();
                    }
                    // set the prey to be dead
                    setDead();
                }
                else {
                    //move the current prey 
                    setLocation(newLocation);
                    // create list of new birth done by the current prey
                    List<Animal> newBaby = super.giveBirth();
                    // for each baby add them into the simulation
                    for (Animal newAnimals : newBaby) {
                        // add baby to simulation
                        newOrganism.add(newAnimals);
                    }
                    // reset breeding probability
                    setBreedingDefault();

                }
            }

        }
    }

    /**
     * This method allows the preys to eat all the grass
     * 
     * @param an object of the Finder class to be used to find specific grass nearby
     * 
     * @return Location of the plant found nearby
     * @return null if no location of preys/grass is found nearby
     */
    protected Location grassFood(Finder find)
    {
        // find a plant nearby
        Plant grass = find.findPlant();
        // check if plant is valid
        if (grass != null){
            // check if plant is alive
            if (grass.isAlive()){
                // set the plant to dead
                grass.setDead();
                // add the food value to the current food level depending on the disease
                super.setFoodLevel(GRASS_FOOD_VALUE);
                // return new location for the prey to move to
                return grass.getLocation();
            }
        }
        return null;
    }

    /**
     * This method returns the food levels to retrieve the max food level a prey can have
     * 
     * @return Integer value that returns the maximum food level of prey
     */
    protected int getFoodLevelMax(){
        return GRASS_FOOD_VALUE;
    }

    /**
     * abstract method that retrieves a new object of the Animal class
     *
     * @param field The field currently occupied.
     * @param location The location within the field. 
     */
    abstract protected Animal getNewAnimal(Field field,Location location);

    /**
     * abstract method that changes the breeding probability of the prey due to change in 
     * weather conditions
     * 
     * @param Integer value to determine what the weather condition is.
     */
    abstract protected void changeBreedingProbability(int weather);

    /**
     * abstract method that resets the breeding probability back to default
     */
    abstract protected void setBreedingDefault();
}
