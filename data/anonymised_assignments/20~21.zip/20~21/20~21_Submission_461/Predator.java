import java.util.List;
import java.util.Random;
/**
 * Predator class - an abstract class to be used in the simulation to simulate
                    predator which include coyote and wolf. This class will
                    have all the features of every predator animal for example 
                    every predator animal can eat a prey animal.
 *
 * @version (version number or date here)
 */
public abstract class Predator extends Animal
{
    //food value of guinea pigs
    private static final int  GUINEAPIG_FOOD_VALUE = 22;
    // food value of deers
    private static final int DEER_FOOD_VALUE = 50;

    /**
     * Create a new predator animal which inherites from the Animal class.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge - determines if animal has a random age or not.
     * @param simulation - object of the Simulator class for the animal to reference.
     */
    public Predator(boolean randomAge, Field field, Location location,Simulator simulation){
        super(randomAge,field,location,simulation);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * This method will allow the predator to move if it's night time 
     * as well as give birth to more predators.
     * 
     * @param newOrganism A list to receive newly born animals.
     */
    public void act(List<Organism>  newOrganism)
    {
        // Finder object to find plants near a predator
        Finder find = new Finder(getField(),getLocation());
        // simulation the predator is in 
        Simulator simulation = getSimulation();
        // day and night cycle for the predator to sleep and be awake
        Environment enviro = getSimulation().getEnvironment();
        // check if it is night
        if(!enviro.getDay()){
            // increment the age
            incrementAge();
            // make predator hungrier
            decrementHunger();

            // check if predator is alive in order for them to act
            if(isAlive()) {
                // check if the predator has the disease
                if(getDisease()){
                    // lower the disease time for the predator to be cured
                    decrementDiseaseTime();
                    // spread the disease if they have it
                    super.canSpreadDisease();
                }

                if (simulation.getDisease() && !getDisease()){
                    // check if predator is able to catch the disease
                    super.catchDisease();
                }

                // change breeding probability based on weather
                changeBreedingProbability(simulation.getWeather());
                // retrieve new location based on grass food location
                Location newLocation = compete(find);
                // check if the location returned is valid
                if(newLocation == null) { 
                    // no food found get a different free location 
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // check if the new location is valid
                if(newLocation == null) {
                    // Overcrowding.
                    //check if current predator has the disease to lower the count
                    if (getDisease()){
                        // lower the disease count
                        simulation.decreaseCount();
                    }
                    // set the predator to be dead
                    setDead();

                }
                else {
                    //move the current predator 
                    setLocation(newLocation);
                    // create list of new birth done by the current predator
                    List<Animal> newBaby = super.giveBirth();
                    // for each baby add them into the simulation
                    for (Animal newAnimals : newBaby) {
                        // add baby to simulation
                        newOrganism.add(newAnimals);
                    }
                    // reset breeding probability
                    setBreedingDefault();

                }
            }

        }
    }

    /**
     * This method allows the predators to eat all the common preys
     * this method also allows predators to get past grass by removing them
     * but not eat them
     * 
     * @param an object of the Finder class to be used to find specific prey nearby
     * 
     * @return Location of the deer found nearby
     * @return Location of the guinea pig found nearby
     * @return Location of the plant found nearby
     * @return null if no location of preys/grass is found nearby
     */
    protected Location preyFood(Finder find)
    {
        //find guinea pig nearby 
        GuineaPig pig = find.findGuineaPig();
        //find deer nearby
        Deer deer = find.findDeer();
        // find plant nearby 
        Plant plant = find.findPlant();
        // check if deer is valid
        if (deer != null){
            // check if deer is alive
            if (deer.isAlive()){
                //check if deer has the disease and the predator doesn't have the disease
                if (deer.getDisease()&& !this.getDisease()){
                    // predator catches diseased
                    this.changeDisease();
                }
                else if (deer.getDisease()&& this.getDisease()){
                    // predator catches diseased
                    this.changeDisease();
                    getSimulation().decreaseCount();
                }
                // set the deer to dead
                deer.setDead();
                // add the food value to the current food level depending on if predator has the disease
                super.setFoodLevel(DEER_FOOD_VALUE);
                // return new location for the predator to move to
                return deer.getLocation();
            }
        }

        // check if guinea pig is valid
        if (pig != null){
            // check if guinea pig is alive
            if(pig.isAlive()){
                //check if guinea pig has the disease and the predator doesn't have the disease
                if (pig.getDisease() && !this.getDisease()){
                    // predator catches diseased
                    this.changeDisease();
                }else if (pig.getDisease()&& this.getDisease()){
                    // predator catches diseased
                    this.changeDisease();
                    getSimulation().decreaseCount();
                }
                // set the guinea pig to dead
                pig.setDead();
                // add the food value to the current food level depending on if predator has the disease
                super.setFoodLevel(GUINEAPIG_FOOD_VALUE);
                // return new location for the predator to move to
                return pig.getLocation();
            }
        }
        // check if plant is valid
        if (plant != null){
            // check if plant is alive
            if(plant.isAlive()){
                // set the plant to dead
                plant.setDead();
                // return new location for the predator to move to
                return plant.getLocation();
            }
        }

        return null;
    }

    /**
     * This method returns the food levels combined to retrieve the max food level a predator can have
     * 
     * @return Integer value that returns the maximum food level of predator
     */
    protected int getFoodLevelMax(){
        return DEER_FOOD_VALUE + GUINEAPIG_FOOD_VALUE;
    }

    /**
     * abstract method that retrieves a new object of the Animal class
     *
     * @param field The field currently occupied.
     * @param location The location within the field. 
     */
    abstract protected Animal getNewAnimal(Field field,Location location);

    /**
     * abstract method that is specific to each predator who compete with each other for prey food
     */
    abstract protected Location compete(Finder find);

    /**
     * abstract method that changes the breeding probability of the predators due to change in 
     * weather conditions
     * 
     * @param Integer value to determine what the weather condition is.
     */
    abstract protected void changeBreedingProbability(int weather);

    /**
     * abstract method that resets the breeding probability back to default
     */
    abstract protected void setBreedingDefault();

}
