import java.util.Random;
/**
 * Environment class - a class to be used in the simulation to simulate the day
                       and night cycle as well as have a countdown timer for 
                       the cycle.
 *
 * @version (a version number or a date)
 */
public class Environment
{
    // instance variables - replace the example below with your own
    // day/night countdown timer
    private int time;
    // default day is true which indicates it's morning
    private boolean isDay = true;
    // randomizer to randomise values
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * This method changes the day for example morning to night
    */
    public void changeDay(){
        // change the day
        isDay=!isDay;
    }
    
    public Random getRandom(){
        return rand;
    }
    
    /**
     * This method sets the day to false to indicate that it is night 
    */
    public void setfalse(){
        // set day to night
        isDay = false;
    }
    
    /**
     * This method returns a boolean value to indicate if it is morning or 
     * night 
     * 
     * @return Boolean value to indicate if it is morning or night
    */
    public boolean getDay(){
        return isDay;
    }
    
    /**
     * This method returns a random integer value
     * 
     * @param Integer number to be the max limit of the random number generator
     * 
     * @return Integer number of the random number generated.
    */
    public int getRandom(int number){
         // return a random number from 0 to a number in the parameter
         return rand.nextInt(number);   
    }
    
    /**
     * This method increments the time used for the countdown of the day
    */
    public void incrementTime()
    {
        // increment the time by 1
        time++;
    }
    
    /**
     * This method returns a timer for the day countdown
     * 
     * @return Integer value of the time of the day timer
    */
    public int getTime(){
        return time;
    }
    
    /**
     * this method resets the time variable to indicate a new day has started
    */
    public void resetTime(){
        // reset time to show a the time has changed
        time = 0;
    }
}
