
/**
 * Weather class - a class to be used in the simulation to simulate the weather
                   as well as have a countdown timer for different weather.
 *
 * @version (a version number or a date)
 */
public class Weather extends Environment
{
    // The current weather condition in the simulation
    private int weather;
    // the weather countdown time
    private int weatherTime;

    /**
     * This method returns a random integer value to indicate the current 
     * weather
     * This method calls a method from the super class to generate a random
     * number
     * 
     * @return Integer value to indicate the current weather condition
    */
    public int getWeather(){
        // call method from super class to generate random number
        weather = super.getRandom(3);
        // 0 = hot
        // 1 = raining
        // 2 = normal
        
        // return the new weather condition
        return weather;
        
    }

    /**
     * @Override
     * Method override (Chapter 11)
     * This method increments the time used for the countdown of the weather
    */
    public void incrementTime(){
        weatherTime++;
    }
    
    /**
     * @Override
     * Method override (Chapter 11)
     * This method returns a timer for the weather countdown
     * 
     * @return Integer value of the weather countdown timer
    */
    public int getTime(){
        return weatherTime;
        
    }
    
    public String getWeatherType(int weather){
        if(weather == 0){
            return "HOT";
        }
        else if(weather == 1){
            return "RAINING";
        }else{
            return "NORMAL";
        }
    }
    
    /**
     * @Override
     * Method override (Chapter 11)
     * 
     * this method resets the time variable to indicate the current weather 
     * condition has changed  
     */
    public void resetTime(){
        // weather has changes and countdown timer resets
        weatherTime = 0;
    }
}
