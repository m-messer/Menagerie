import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * Animal class - an abstract class to be used in the simulation to simulate
                  animals which include predators and prey. This class will
                  have all the features of every animal for example 
                  each female animal can breed with a male animal.
 *
 * @version 
 */
public abstract class Animal extends Organism
{
    // Longevity of the disease time
    private int diseaseTime = 4;
    // boolean value of the gender true if male, false if female
    private boolean isMale;
    private Random rand;
    // the simulation the animal is in 
    private Simulator simulation;
    // boolean value to indicate if the animal has the disease
    private boolean isDiseased;
    // food level of the animal 
    private int foodLevel;
    // probablility of catching the disease
    private static  double DISEASE_PROBABILITY = 0.02;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge - determines if animal has a random age or not.
     * @param simulation - object of the Simulator class for the animal to reference.
     */
    public Animal(boolean randomAge,Field field, Location location,Simulator simulation)
    {
        // inherits attributes from super class(Organism)
        super(randomAge,field,location,simulation);
        this.rand = getRandom();
        this.simulation = simulation;
        // determine gender of animal by random gender
        this.isMale = rand.nextBoolean();
        // determines if the food level is random or the maximum
        if(randomAge){
            foodLevel = rand.nextInt(getFoodLevelMax());
        }
        else{
            foodLevel = getFoodLevelMax();
        }
    }

    /**
     * Check whether the animal is male or not.
     * true - the animal is a male
     * false - the animal is a female
     * @return true if the animal is male.
     */
    protected boolean getGender()
    {
        return this.isMale;
    }
    
    /**
     * @Override
     * Method override (Chapter 11)
     * increments age every step and if the organism's age is above the max age then they are 
     * removed from the field.
     * Also check if the animal is diseased to lower the count
     */
    protected void incrementAge()
    {
        // increments age of organism
        incrementAnimalAge();
        // if age passes max age then organism dies
        if (getAge() > this.getMaxAge()) {
            if (getDisease()){
                    simulation.decreaseCount();
                }
            // organism dies
            setDead();
        }
    }
    
    protected void catchDisease(){
        // determines if the animal can gets diseased based on probability
        if(rand.nextDouble() < DISEASE_PROBABILITY){
            isDiseased = true;
            simulation.increaseCount();
        }
    }
    
    /**
     * Check whether the animal is diseased or not.
     * true - the animal is diseased
     * false - the animal is not diseased
     * @return boolean value true if the animal is diseased.
     */
    protected boolean getDisease()
    {
        return this.isDiseased;
    }

    /**
     * Changes the food level of the animal based on the value passed through.
     * 
     * @param integer value to add onto the foodlevel
     * @return boolean value true if the animal is diseased.
     */
    protected void setFoodLevel(int newFoodLevel){
        // increase food level with the new food level
        this.foodLevel += newFoodLevel;
    }
    
    /**
     * Food level depends on if the animal is diseased or not. An animal being 
     * diseased means the food value eaten will be halved and added to the food level
     * 
     * @param integer value of the food value eaten by the animal
     */
    protected void checkFoodLevel(int foodValue){
        // check if animal is diseased
        if (getDisease()){
            //add the new food value which is halved
            setFoodLevel(foodValue/2);
        }
        // animal is not diseased
        else{
            // add normal food value
            setFoodLevel(foodValue);
        }
    }
    
    /**
     * Returns the food level value of the animal
     * 
     * @return integer value of the animal's food level. 
     */
    protected int getFoodLevel(){
        return foodLevel;
    }

    /**
     * decrements the food level of the animal every step.
     * if the food level is less than or equal to 0 then the animal will die.
     */
    protected void decrementHunger()
    {
        // decrements food level to indicate the animal is getting hungrier
        this.foodLevel--;
        // if the food level is less than 0 the animal dies
        if(this.foodLevel <= 0) {
            if (getDisease()){
                    simulation.decreaseCount();
                }
            setDead();
        }
    }

    /**
     * decrements the disease time for the animal.
     * if the disease time is less than or equal to 0 then they will be cured from the disease
     */
    protected void decrementDiseaseTime(){
        // decrement disease time to indicate they are slowly getting cured
        this.diseaseTime--;
        // if the disease time is less than or equal to 0 then they get cured
        if (this.diseaseTime <=0){
            isDiseased = false;
            simulation.decreaseCount();
        }
    }

    /**
     * This method changes the disease based on if the animal is diseased or not.
     */
    protected void changeDisease(){
        // disease changes based on the current boolean value 
        isDiseased = !isDiseased ;
    }

    /**
     * Determines if object found is an instance of the Animal class or not.
     * 
     * @param the object to be checked if it is an instance of the Animal class.
     * @return an object of the Animal class.
     * @return null if it is not an instance of the Animal class.
     */
    protected Animal getAnimal(Object obj){
        // check if the object is an instance of animal 
        if(obj instanceof Animal){
            // create object of the animal class using obj
            Animal animal = (Animal) obj;
            // return the object of the Animal class
            return animal;

        }
        // obj is not an instance of the Animal class
        return null;
    }

    /**
     * Determines if animals nearby will get the disease from this animal
     * based on:
     * object found is an animal
     * probability works out
     * this animal is diseased
     * this method finds animals and spreads the disease if the current animal
     * has the disease.
     */
    protected void canSpreadDisease(){
        // retrieve the field of the animal
        Field field = getField();
        // get locations near the current animal
        List<Location> adjacent = field.adjacentLocations(super.getLocation());
        Iterator<Location> it = adjacent.iterator();
        Random rand = getRandom();
        // iterate through the locations near the animal and check if there is a non diseased animal
        while(it.hasNext()) {
            Location where = it.next();
            // create object of the thing in the location
            Object partner = field.getObjectAt(where);
            // check if object is an animal and assing it to an animal object
            Animal diseasePartner = getAnimal(partner);
            // check if animal is null, current animal is diseased and disease probability works out
            if(diseasePartner!= null && rand.nextDouble() < DISEASE_PROBABILITY && getDisease()) {
                // check if animal is not diseased
                if (!diseasePartner.getDisease()){
                    // spread the disease to the new animal
                    diseasePartner.changeDisease();
                    simulation.increaseCount();
                }      
            }
        }
    }

    /**
     * Determines if the animal is able to breed based on if the :
     * animal found is the same type of animal  
     * probability works out
     * animal gender is a male
     */
    protected boolean canMate(){
        // retrieve the field of the animal
        Field field = getField();
        // get locations near the current animal
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // iterate through the locations and check if there is an animal who is the same animal and a male
        while(it.hasNext()) {
            Location where = it.next();
            // create object of the thing in the location
            Object breedingPartner = field.getObjectAt(where);
            // check if object is an animal and assing it to an animal object
            Animal partner = getAnimal(breedingPartner);
            // check if the animal is the same type and the animal is a male
            if(partner != null && breedingPartner.getClass() == this.getClass() && (partner.getGender())) {
                // the animal fits all the conditions
                return true;
            }

        }
        // animal couldn't be found
        return false;
    }

    /**
     * Determines if the animal is able to breed based on if :
     * this animal is a female (only females can give birth to new animals)
     * the age of this animal is more than the breeding age
     * there is a male animal that is the same type as this animal.
     * 
     * @return false if this animal is a male
     * @return true if the animal is of age and able to breed.
     */
    protected Boolean canBreed()
    {
        // checks if current animal is male
        // male animals cannot breed
        if(getGender()){
            return false;
        }
        // return boolean value if these 2 conditions are satisfied
        return (this.getAge() >= this.getBreedingAge() &&  canMate());
    }

    /**
     * This method determines how many births an animal can do.
     * 
     * @return integer of the amount of births an animal can do
     */
    protected int breed()
    {
        // number of births an animal can do
        int births = 0;
        Random rand = getRandom();
        // if statement checks if animal can breed and the probability is satisfied
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            // births depend on the maximum litter size number
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        // returns number of births the current animal can do.
        return births;
    }

    /**
     * Determines the number of animals an animal can give birth to
     * 
     * @return a list of new babies born from this animal
     */
    protected List<Animal> giveBirth()
    {
        // Get a list of new babies that have been birthed to from this current animal
        List<Animal> newBaby = new ArrayList<>();
        // Get the field of the current animal
        Field field = getField();
        // Get free locations near the current animal
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        // Calls a breed method to retrieve the number of births this animal can do
        int births = breed();
        // For loop to give birth to the new baby animal
        for(int b = 0; b < births && free.size() > 0; b++) {
            // find the first free location to put the baby in 
            Location location = free.remove(0);
            // call the method from the sub class to retrieve an object of the animal class
            newBaby.add(getNewAnimal(field,location));
        }

        return newBaby;
    }

    /**
     * abstract method that retrieves the maximum litter size of an animal
     */
    protected abstract int getMaxLitterSize();

    /**
     * abstract method that retrieves the breeding probability of an animal
     */
    protected abstract double getBreedingProbability();

    /**
     * abstract method that retrieves the maximum age of an animal
     */
    abstract protected int getMaxAge();

    /**
     * abstract method that retrieves the breeding age of an animal
     */
    abstract protected int getBreedingAge();

    /**
     * abstract method that retrieves the breeding age of an animal
     */
    protected abstract int getFoodLevelMax();

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newOrganism A list to receive newly born animals.
     */
    abstract public void act(List<Organism> newOrganism);

    /**
     * abstract method that retrieves a new object of the Animal class
     */
    abstract protected Animal getNewAnimal(Field field,Location location);

}
