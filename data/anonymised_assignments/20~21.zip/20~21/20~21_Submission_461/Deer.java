
/**
  * Deer class - a class to be used in the simulation to simulate
                  deers. This class will have all the unique features of a deer 
                  for example every deer have different max ages compared 
                  to Guinea pigs.
 *
 * @version (a version number or a date)
 */
public class Deer extends Prey
{
    // instance variables - replace the example below with your own
    // Breeding age for a deer to start breeding 
    private static int BREEDING_AGE = 4;
    // maximum age a deer can live up to
    private static int MAX_AGE = 110;
    // constant: default breeding probability for all deers
    private static final double DEFAULT_BREEDING_PROBABILITY = 0.75;
    // the breeding probability that can change with each deer
    private static double breedingProbability = DEFAULT_BREEDING_PROBABILITY;
    // the maximum litter size of each deer
    private static int MAX_LITTER_SIZE = 8;
    
     
    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The simulation the deer is in 
     */
    public Deer(boolean randomAge, Field field, Location location,Simulator simulation)
    {
        super(randomAge,field, location,simulation);
    }
    
    /**
     * This method returns the breeding age of a deer
     * 
     * @return Integer value of the deer breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
     }
     
    /**
     * This method returns the maximum age of a deer
     * 
     * @return Integer value of the deer maximum age
     */ 
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * This method returns the breeding probability of a deer
     * 
     * @return Double value of the deer breeding probability
     */
    public double getBreedingProbability(){
        return breedingProbability;
    }
    
    /**
     * This method returns the maximum litter size of a deer
     * 
     * @return Integer value of the deer maximum litter size
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * This method returns a new object of a Deer class
     * 
     * @return object of the Deer class
     */
    public Animal getNewAnimal(Field field,Location location){
        // returns a new object of the Deer class for breeding
        return new Deer(false, field, location,super.getSimulation());
    }
    
    /**
     * This method will change the breeding probability of the deer depending
     * on the weather condition and if the deer is diseased
     * 
     * @param Integer value to indicate the weather condition
     */
     public void changeBreedingProbability(int weather){
        // check if weather is raining and if the deer is diseased
         if (weather == 1 || getDisease()){
                // divide breeding by 2 because raining lower breeding probability 
                breedingProbability /= 2;
        }
        // check if weather is hot
        if (weather == 0){
                // hot weather increases breeding probability
                breedingProbability *= 3;
        }
        // if the weather is anything else then the probability would be default
        else{
            setBreedingDefault();
        }
    }
    
    /**
     * This method will change the breeding probability of the deer back to 
     * its default probability
     * 
     */
    protected void setBreedingDefault(){
        // breeding proability resets back to default
        breedingProbability = DEFAULT_BREEDING_PROBABILITY ;
    }
}
