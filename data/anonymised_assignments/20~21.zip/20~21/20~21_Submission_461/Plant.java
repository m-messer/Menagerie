import java.util.List;
import java.util.Random;
/**
  * Plant class - an abstract class to be used in the simulation to simulate
                  plants which include grass. This class will have all the 
                  features of every plant for example each plant can self breed 
 *
 * @version (version number or date here)
 */
public abstract class Plant extends Organism
{

    /**
     * Create a new prey animal which inherites from the Animal class.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge - determines if animal has a random age or not.
     * @param simulation - object of the Simulator class for the animal to reference.
     */
    public Plant(boolean randomAge,Field field, Location location, Simulator simulation)
    {
        // inherits attributes from super class(Organism)
        super(randomAge,field,location,simulation);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * This method will allow the prey to move if it's night time 
     * as well as give birth to more prey.
     * 
     * @param newOrganism A list to receive newly born animals.
     */
    public void act(List<Organism> newOrganism){
        // retrieve the environment object to check the day
       Environment enviro = getSimulation().getEnvironment();
       // Get the simulation of the current plant
       Simulator simulation = getSimulation();
       // check if the day is morning since plants can only grow in the morning
       if(enviro.getDay()){
           // increment the age of the plant
        incrementAge();
        // Check if the plant is alive to make it active
        if(isAlive()) {
            // change breeding probability depending on the current weather condition
            changeBreedingProbability(simulation.getWeather());
            // plant is able to give birth if they meet the conditions
            giveBirth(newOrganism);
        }
        }
        // reset breeding probability at the end of every step
       setBreedingDefault();
    }
    
    
    /**
     * Determines if a plant is able to breed based on if :
         * the age of the plant is more than the breeding age
     * 
     * @return true if the animal is of age and able to breed.
     */
    protected Boolean canBreed()
    {
        // return boolean value if this condition is satisfied
        return (super.getAge() >= this.getBreedingAge());
    }

    /**
     * This method determines how many births a plant can do.
     * 
     * @return integer of the amount of births a plant can do
     */
    protected int breed()
    {
        // number of births a plant can do
        int births = 0;
        Random rand = getRandom();
        // if statement checks if plant can breed and the probability is satisfied
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        // returns number of births the current plant can do.
        return births;
    }
    
    /**
     * abstract method that retrieves the maximum litter size of a plant
     */
    protected abstract int getMaxLitterSize();
    
    /**
     * abstract method that retrieves the breeding probability of a plant
     */
    protected abstract double getBreedingProbability();
    
    /**
     * abstract method that changes the breeding probability of the plant due 
     * to change in weather conditions
     * 
     * @param Integer value to determine what the weather condition is.
     */
    abstract protected void changeBreedingProbability(int weather);
    
    /**
     * abstract method that resets the breeding probability back to default
     */
    abstract protected void setBreedingDefault();
    
    /**
     * abstract method that retrieves the maximum age of a plant
     */
    abstract protected int getMaxAge();
    
    /**
     * abstract method that retrieves the breeding age of a plant
     */
    abstract protected int getBreedingAge();
    
    /**
     * abstract method which determines if the plant will give birth or not
     */
    abstract protected void giveBirth(List<Organism> newOrganism);
    
}
