
/**
  * GuineaPig class - a class to be used in the simulation to simulate
                  GuineaPigs. This class will have all the unique features of a GuineaPig 
                  for example every GuineaPig have different breeding ages to deers.
 *
 * @version 2016.02.29 (2)
 */
public class GuineaPig extends Prey
{
    // Characteristics shared by all GuineaPig (class variables).

    // Breeding age for a GuineaPig to start breeding 
    private static final int BREEDING_AGE = 4;
    // maximum age a GuineaPig can live up to
    private static final int MAX_AGE = 100;
    // constant: default breeding probability for all GuineaPigs
    private static final double DEFAULT_BREEDING_PROBABILITY = 0.9;
    // the breeding probability that can change with each GuineaPig
    private static double breedingProbability = DEFAULT_BREEDING_PROBABILITY;
    // the maximum litter size of each GuineaPig
    private static final int MAX_LITTER_SIZE = 3;
    


    /**
     * Create a new GuineaPig. A GuineaPig may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the GuineaPig will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The simulation the GuineaPig is in 
     */
    public GuineaPig(boolean randomAge, Field field, Location location,Simulator simulation)
    {
        super(randomAge,field, location,simulation);
    }
    
    /**
     * This method returns the breeding age of a GuineaPig
     * 
     * @return Integer value of the GuineaPig breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * This method returns the maximum age of a GuineaPig
     * 
     * @return Integer value of the GuineaPig maximum age
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * This method returns the breeding probability of a GuineaPig
     * 
     * @return Double value of the GuineaPig breeding probability
     */
    public double getBreedingProbability(){
        return breedingProbability;
    }
    
     /**
     * This method returns the maximum litter size of a GuineaPig
     * 
     * @return Integer value of the GuineaPig maximum litter size
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * This method returns a new object of a GuineaPig class
     * 
     * @return object of the GuineaPig class
     */
    public Animal getNewAnimal(Field field,Location location){
        // returns a new object of the GuineaPig class for breeding
        return new GuineaPig(false, field, location,super.getSimulation());
    }
    
    /**
     * This method will change the breeding probability of the GuineaPig depending
     * on the weather condition and if the guinea pig is diseased
     * 
     * @param Integer value to indicate the weather condition
     */
    public void changeBreedingProbability(int weather){
        // check if weather is raining and if the guinea pig is diseased
        if (weather == 1 || getDisease()){
            // divide breeding by 5 because raining lower breeding probability 
            breedingProbability /= 5;
        }
        // check if weather is hot
        if (weather == 0){
            // hot weather increases breeding probability
            breedingProbability *= 1.3;
        }
        // if the weather is anything else then the probability would be default
        else{
            setBreedingDefault();
        }
    }
    
    /**
     * This method will change the breeding probability of the GuineaPig back to 
     * its default probability
     * 
     */
    protected void setBreedingDefault(){
        // breeding proability resets back to default
        breedingProbability = this.DEFAULT_BREEDING_PROBABILITY ;
    }
        

}
