import java.util.List;
/**
  * Grass class - a class to be used in the simulation to simulate
                  grass. This class has unique features for example if the 
                  weather is raining then the plants grow more unlike animals
 *
 * @version (a version number or a date)
 */
public class Grass extends Plant
{
    // Breeding age for grass to start breeding 
    private static final int BREEDING_AGE = 2;
    // maximum age grass can live up to
    private static final int MAX_AGE = 50;
    // constant: default breeding probability for all grass
    private static final double DEFAULT_BREEDING_PROBABILITY = 0.2;
    // the breeding probability that can change with each grass
    private static double breedingProbability = DEFAULT_BREEDING_PROBABILITY;
    // the maximum litter size of each grass
    private static final int MAX_LITTER_SIZE = 1;

    /**
     * Create a new plant. A plant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The simulation the plant is in 
     */
    public Grass(boolean randomAge, Field field, Location location,Simulator simulation)
    {
        super(randomAge,field, location,simulation);
    }

    /**
     * This method returns the breeding age of a plant
     * 
     * @return Integer value of the plant breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * This method returns the maximum age of a plant
     * 
     * @return Integer value of the plant maximum age
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * This method returns the breeding probability of a plant
     * 
     * @return Double value of the plant breeding probability
     */
    public double getBreedingProbability(){
        return breedingProbability;
    }
    
    /**
     * This method returns the maximum litter size of a plant
     * 
     * @return Integer value of the plant maximum litter size
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * This method will change the breeding probability of the plant depending
     * on the weather condition
     * 
     * @param Integer value to indicate the weather condition
     */
    protected void changeBreedingProbability(int weather){
        // check if weather is raining 
        if (getSimulation().getWeather() == 1){
            // multiply breeding by 2 because raining increases breeding probability
           breedingProbability *= 2;
        }
        // check if weather is hot
        if (getSimulation().getWeather() == 0){
            // hot weather decreases breeding probability
            breedingProbability /= 3;
        }
        // if the weather is anything else then the probability would be default
        else{
            setBreedingDefault();
        }
    }
    
    /**
     * This method will change the breeding probability of the plant back to 
     * its default probability
     * 
     */
    protected void setBreedingDefault(){
        // breeding proability resets back to default
        breedingProbability = DEFAULT_BREEDING_PROBABILITY;
    }
    
    
    /**
     * Determines the number of plants a plant can give birth to
     * 
     * @param newGrass A list to receive newly born Grass.
     */
    protected void giveBirth(List<Organism> newGrass)
    {
        // Get the field of the current grass
        Field field = getField();
        // Get free locations near the current grass
        List<Location> free = field.getFreeAdjacentLocations(super.getLocation());
        // Calls a breed method to retrieve the number of births grass can do
        int births = breed();
        // For loop to give birth to the new grass
        for(int b = 0; b < births && free.size() > 0; b++) {
            // find the first free location to put new grass in 
            Location loc = free.remove(0);
            // create new object of Grass class
            Grass young = new Grass(false, field, loc,super.getSimulation());
            // add the new grass into a list of birthed list.  
            newGrass.add(young);
        }
    }
}
