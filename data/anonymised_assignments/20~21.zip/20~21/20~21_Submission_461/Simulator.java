import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing coyotes, wolfs, guinea pigs, deers, and grass.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    
    private static final Color DARK_GREEN = new Color(0,102, 0);
    private static final Color PURPLE = new Color(102,0, 153);
    private static final Color LIGHT_BLUE = new Color(51,204,255);
    // The probability that a coyote will be created in any given grid position.
    private static final double COYOTE_CREATION_PROBABILITY = 0.03;
    // The probability that a guinea pig will be created in any given grid position.
    private static final double GUINEAPIG_CREATION_PROBABILITY = 0.06; 
    // The probability that a wolf will be created in any given grid position
    private static final double WOLF_CREATION_PROBABILITY = 0.02; 
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.04; 
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.3;
    // The maximum time until the weather randomly changes
    private static final int MAX_WEATHER_TIME = 10;
    // The maximum time until the disease outbreak randomly changes
    private static final int MAX_DISEASE_TIME = 25;
    // The maximum time until the day randomly changes
    private static int MAX_DAY_TIME = 20;
    // List of organism in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The day and night cycle of the simulation
    private Environment environment;
    // The weather of the simulation
    private Weather weather;
    // The current weather condition of the simulation
    private int currentWeather;
    // The disease outbreak in the simulation
    private Disease disease;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        // list of organisms in the simulation
        organisms= new ArrayList<Organism>();
        field = new Field(depth, width);
        environment = new Environment();
        // disease in the simulation
        disease = new Disease();
        // weather condition in the simulation
        weather = new Weather();
        // weather condition during the start of the simulator
        currentWeather = weather.getWeather();; // weather is normal
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(GuineaPig.class, Color.ORANGE);
        view.setColor(Coyote.class, LIGHT_BLUE);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Deer.class, PURPLE);
        view.setColor(Grass.class, Color.GREEN);
        updateDisplay();
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (2000 steps).
     */
    public void runLongSimulation()
    {
        simulate(2000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Iterate over the whole field updating the state of each
     * organism and plant
     */
    public void create(List<Organism> newOrganism){
        //for loop to iterate through the list of organism
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganism);
            // if statements to check if organism is an animal or plant
            if(organism instanceof Animal) {
                Animal animal = (Animal) organism;
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
            if (organism instanceof Plant){
                Plant plant = (Plant) organism;
                if(!plant.isAlive()) {
                    it.remove();
                }
            }
        }

    }

    /**
     * Run the simulation from its current state for a single step.
     * This method increments also determines if:
     * a daytime changes
     * a disease outbreak occurs
     * the weather changes.
     */
    public void simulateOneStep()
    {
        // increment step
        step++;
        // increment day/night time
        environment.incrementTime();
        // increment weather time
        weather.incrementTime();
        // increment disease time
        disease.incrementTime();
        // ArrayList of new organisms in simulation
        List<Organism> newOrganism = new ArrayList<>(); 
        // update the simulation display
        updateDisplay();
        // if the environment time reaches the max time then the day changes
        if (environment.getTime() == MAX_DAY_TIME ){
            // time of day changes for example morning to night
            environment.changeDay();
            if(environment.getDay()){
                view.setColor(Grass.class,Color.GREEN);
            }
            if (!environment.getDay()){
                view.setColor(Grass.class,DARK_GREEN);
            }

            // environment time resets
            environment.resetTime();
        }
        // if the disease time reaches the max time then the disease outbreak can randomly change
        if(disease.getTime() == MAX_DISEASE_TIME){
            // the disease outbreak can randomly change or stay the same.
            disease.ChangeDisease();
            // disease time resets 
            disease.resetTime();
        }
        // if the weather time reaches the max weather time then change the weather
        if (weather.getTime() == MAX_WEATHER_TIME ){
            // change the weather condition randomly
            currentWeather = weather.getWeather();
            // reset the weather time
            weather.resetTime();
        }
        // check if the current weather condition is raining
        if (currentWeather == 1){
            // add random grass into the simulation
            populateGrass();
        }
        // let the organisms act
        create(newOrganism);
        
        organisms.addAll(newOrganism);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        // reset steps of simulation 
        step = 0;
        // reset the environment time
        environment.resetTime();
        // clear the organisms ArrayList to show no organisms in the simulation
        organisms.clear();
        // reset disease time 
        disease.resetTime();
        // reset weather time
        weather.resetTime();
        disease.resetDiseaseCount();
        // populate a new list of organisms
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field);
        updateDisplay();
    }
    
    /**
     * This method adds random grass in the simulation since grass can grow anywhere
     */
    private void populateGrass(){
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // lower the chance of grass being created in order to slow down growth
                if(rand.nextDouble() <= (GRASS_CREATION_PROBABILITY/100)){
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location,this);
                    organisms.add(grass);
                }
            }
        }
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // creates new coyotes
                if(rand.nextDouble() <= COYOTE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Coyote coyote = new Coyote(true, field, location,this);
                    organisms.add(coyote);
                }
                // creates new guinea pigs
                else if(rand.nextDouble() <= GUINEAPIG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    GuineaPig pig = new GuineaPig(true, field, location,this);
                    organisms.add(pig);
                    
                }
                // creates new wolves
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location,this);
                    organisms.add(wolf);
                }
                // creates new deers
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY){
                    //
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location,this);
                    organisms.add(deer);
                }
                // creates new grass
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location,this);
                    organisms.add(grass);
                }
            }
        }
    }

    /**
     * Returns the object of the Environment Class in order to use it's methods
     * 
     * @returns object of the Environment Class
     */
    public Environment getEnvironment(){
        return environment;
    }

    /**
     * Returns the weather condition which is an int:
     * 0 = hot
     * 1 = rain
     * 2 = normal
     * 
     * @returns integer value that represents the current weather condition
     */
    public int getWeather(){
        return currentWeather;
    }

    /**
     * Returns boolean value whether a disease outbreak is happening or not
     * true - disease outbreak active
     * false - disease outbreak inactive
     * 
     * @returns boolean value that indicates if a disease outbreak is happening.
     */
    public Boolean getDisease(){
        return disease.getDisease();
    }

    /**
     * Increments the disease counter to indicate another animal has caught the disease.
     * The method in the Disease class is called which increments the counter.
     */
    public void increaseCount(){
        disease.increaseDiseaseCount();
    }

    /**
     * Decrements the disease counter to indicate an animal has lost the disease.
     * The method in the Disease class is called which decrements the counter.
     */
    public void decreaseCount(){
        disease.decreaseDiseaseCount();
    }

    /**
     * Returns the disease counter which shows how many animals have the disease.
     * The method to retrieve the counter is found in the Disease class.
     * 
     * @returns integer value for the disease counter
     */
    public int getDiseaseCount(){
        return disease.getDiseaseCount();
    }

    /**
     * This method updates the GUI of the simulator
     * This method calls the SimulatorView class and updates the information for example:
     * Day countdown
     * Weather/Disease countdown
     * Disease counter etc.
     * 
     * @returns integer value for the disease counter
     */
    public void updateDisplay(){
        // calls the SimulatorView class to update GUI of simulator
        view.update(MAX_DAY_TIME-environment.getTime(),MAX_DISEASE_TIME-disease.getTime(),weather.getWeatherType(currentWeather),disease.getDisease(),environment.getDay(),getDiseaseCount());
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

}
