import java.util.List;
import java.util.Random;
/**
 * Organism class - an abstract class to be used in the simulation to simulate
                    organisms which include animals and plants. This class 
                    will have all the features every organism have for example
                    age. 
 *
 * @version (a version number or a date)
 */
public abstract class Organism
{
    // The current state of the field.
    private Field field;
    // the current location of the organism
    private Location location;
    // the current simulation the organism is in
    private Simulator simulation;
    // the age of the organism
    private int age;
    // if the organism is alive
    private boolean alive;
    // randomizer to generate random values 
    private static final Random rand = Randomizer.getRandom();
    /**
     * Abstract constructor for Organism inherited type.
     * @param randomAge - determines if the organism will have a random age or not.
     * @param field - the field that the organisms are on.
     * @param location - the location of the organism on the field. 
     * @param simulation - The object of the Simulator class since many simulations can occur.
     */
    public Organism(boolean randomAge,Field field, Location location,Simulator simulation){
        // initalize the values
        this.field = field;
        this.simulation=simulation;
        this.location = location;
        this.alive = true;
        setLocation(location);
        // if statment to check if the organism is a new born or randomly generated organism
        if(randomAge){
            // random number for the age 
            // indicates organism is not a new born
            age = rand.nextInt(getMaxAge());
        }
        else{
            // organism is a new born
            age = 0;
        }
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganism A list to receive newly born organisms.
     */
    abstract public void act(List<Organism> newOrganism);

    /**
     * Returns the object of the Random Class.
     * @return object of the Random Class.
     */
    protected Random getRandom()
    {
        return rand;
    }  

    /**
     * Returns the field of where the organisms are.
     * @return object of the Field Class.
     */
    protected Field getField()
    {
        return field;
    } 

    /**
     * Returns the location of where the organisms are.
     * @return object of the Location Class.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Returns the age of the organism
     * @return Integer number for the age of the organism.
     */
    protected int getAge()
    {
        return this.age;
    }

    /**
     * Returns the object of the Simulator to reference methods inside it.
     * @return object of the Simulator Class.
     */
    protected Simulator getSimulation()
    {
        return simulation;
    }

    /**
     * Removes the organism from the field after they die.
     */
    protected void removeOrganism() {
        // organism is removed from the field
        field.clear(location);
        // organism cannot be located anywhere
        location = null;
        field = null;
    }

    /**
     * increments age every step and if the organism's age is above the max age then they are 
     * removed from the field.
     */
    protected void incrementAge()
    {
        // increments age of organism
        this.age++;
        // if age passes max age then organism dies
        if (this.age > this.getMaxAge()) {
            // organism dies
            setDead();
        }
    }
    
    /**
     * increments animal age every step
     */
    protected void incrementAnimalAge()
    {
        // increments age of organism
        this.age++;
    }
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        // set alive value to false to indicate organism is dead
        alive = false;
        // remove organism
        if(location != null) {
            removeOrganism();           
        }
    }

    /**
     * This methods updates the organisms location after every step.
     * @param object of the Location class to indicate the new location for the organism
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * abstract method to retrieve the max age of an organism since some organisms have 
     * different maximum age.
     */
    abstract protected int getMaxAge();

    
}
