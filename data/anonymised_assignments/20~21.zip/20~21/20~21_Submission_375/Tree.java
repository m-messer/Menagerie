import java.util.List;
import java.util.Random;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Tree extends Plant
{
    // Characteristics shared by all grass
    
    // The age to which takes grass to grow to eatable.
    private static final int MAX_GROWTH = 50;
  
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private static final int TREE_FOOD_LEVEL = 3;
    
    // Individual characteristics (instance fields).
    
    // is there rain in the environment
    private boolean isRaining;
    
    // The grass's age.
    private int growth;
    
    // is the grass fully grown
    private boolean isMaxGrowth;

    /**
     * Create a new tree.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tree(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * This is what the trees does most of the time: it grows, in the process, 
     * it can grow faster if there is rain or just grows much slower if there isn't.
     *
     * @param newTrees A list to return newly generated trees.
     */
    public void act(List<Plant> newTrees)
    {
        if(growth < MAX_GROWTH) {
            if (raining() == true && (growth + 6 <= MAX_GROWTH)){
                growth = growth + 6;
            }
            else if(growth + 6 >= MAX_GROWTH){
                growth = MAX_GROWTH;
            }
            else{
                growth++;        
            } 
        }   
        
    }

    /**
     * This method randomly decides if it's raining or not at
     * any give step in the simulation.
     * 
     * @return a random boolean, if true it's raining, false otherwise.
     */
    public boolean raining()
    {
        Random random = new Random();
        boolean isRaining = random.nextBoolean();
        return isRaining;
    }
    
    /**
     * @return true if the maxium growth has been met, otherwise false.
     */
    public boolean isMaxGrowth()
    {
        return growth >= MAX_GROWTH;
    }
    
    /**
     * Resets the growth back to 0 once eaten by
     * an elephant in the jungle.
     */
    public void reset()
    {
        growth = 0;
    }
}
