import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Orangutan.
 *  Orangutan's can move around for food from Ants in the jungle. 
 *  They can age, and grow old. As well as die from lack of food or old age.
 *
 * @version 2016.02.29 (2)
 */
public class Orangutan extends Animal
{
    // Characteristics shared by all orangutans (class variables).
    
    // The age at which a orangutan can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a orangutan can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a orangutan breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single elephant. In effect, this is the
    // number of steps a orangutan can go before it has to eat again.
    private static final int ANT_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The orangutan's age.
    private int age;
    // The orangutan's food level, which is increased by eating elephants.
    private int foodLevel;

    /**
     * Create a orangutan. A orangutan can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the orangutan will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Orangutan(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ANT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ANT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the orangutan does most of the time: it hunts for
     * ants. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newOrangutans A list to return newly born orangutans.
     */
    public void act(List<Animal> newOrangutans)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newOrangutans);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the orangutan's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this orangutan more hungry. This could result in the orangutan's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for ants adjacent to the current location.
     * Only the first live ant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Ant) {
                Ant ant = (Ant) animal;
                if(ant.isAlive()) { 
                    ant.setDead();
                    foodLevel = ANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this orangutan is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrangutans A list to return newly born orangutans.
     */
    private void giveBirth(List<Animal> newOrangutans)
    {
        // New orangutanes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Orangutan young = new Orangutan(false, field, loc);
            newOrangutans.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An orangutan can breed if it has reached the breeding age and the opposite gender.
     * 
     * @return a boolean value of true if an orangutan can breed.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Elephant){
                Elephant elephant = (Elephant) animal;
                if (elephant.getGender() != getGender()) {
                    return age >= BREEDING_AGE;
                }
            }
        }
       
        return false;
    }
}
