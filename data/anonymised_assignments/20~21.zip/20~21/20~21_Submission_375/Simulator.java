import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing elephants, tigers, leopards, orangutans and ants to come 
 * out king of the jungle!
 *
 * @version 2021.03.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.05;
    // The probability that a leopard will be created in any given grid position.
    private static final double LEOPARD_CREATION_PROBABILITY = 0.05;
    // The probability that a elephant will be created in any given grid position.
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.06; 
    // The probability that an orangutan is created in any given grid position.
    private static final double ORANGUTAN_CREATION_PROBABILITY = 0.08; 
    // The probability that an ant is created in any given grid position.
    private static final double ANT_CREATION_PROBABILITY = 0.03;  
    // The probability that a tree will be created in any given grid position.
    private static final double TREE_CREATION_PROBABILITY = 0.1;   
    // The probability that an animal gets infected with a disease in any given grid position.
    //private static final double DISEASE_INFECTION_PROBABILITY = 0.01;  
    
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The time of day
    private int clock;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        view.setColor(Elephant.class, Color.LIGHT_GRAY);
        view.setColor(Tiger.class, Color.BLUE);
        view.setColor(Leopard.class, Color.YELLOW);
        view.setColor(Ant.class, Color.GRAY);
        view.setColor(Orangutan.class, Color.ORANGE);
        view.setColor(Tree.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(35);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        clock++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();  
        // Provide space for new plant.
        List<Plant> newPlants = new ArrayList<>(); 
            
        if (clock == 24) {
            clock = 0;
        }
        else if (7 <= clock && clock <= 19) {
            // Let all animals act.
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                animal.act(newAnimals);
                if(!animal.isAlive()) {
                    it.remove();
                }
                if (animal.isInfected()){
                    if (!animal.recovered()){
                        animal.setDead();
                    }
                }
            }
            // Let all plants act.
            for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
                Plant plant = it.next();
                plant.act(newPlants);
                if(! plant.isAlive()) {
                    it.remove();
                }
            }
            SimulatorView.EMPTY_COLOR = Color.white; // white background for daylight
        }
        else {
            SimulatorView.EMPTY_COLOR = Color.black; // black background for night time
        }

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        // Add plants to the main lists.
        plants.addAll(newPlants);
        
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with foxes and Elephants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= LEOPARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Leopard leopard = new Leopard(true, field, location);
                    animals.add(leopard);
                }
                else if(rand.nextDouble() <= ELEPHANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Elephant elephant = new Elephant(true, field, location);
                    animals.add(elephant);
                }
                else if(rand.nextDouble() <= ANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Ant ant = new Ant(true, field, location);
                    animals.add(ant);
                }
                else if(rand.nextDouble() <= ANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Orangutan orangutan = new Orangutan(true, field, location);
                    animals.add(orangutan);
                }
                else if(rand.nextDouble() <= TREE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tree tree = new Tree(field, location);
                    plants.add(tree);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
