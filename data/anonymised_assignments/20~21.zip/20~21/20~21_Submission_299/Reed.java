import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
* A simple model of a Reed.
* Reed reproduce and die of old age
*
* @version 2021.02.26 
*/

public class Reed extends Plant{

   // The likelihood of a Reed breeding.
   private static final double BREEDING_PROBABILITY = 0.24;//0.22//0.08//0.1
   // The likelihood of a Reed dying in the event of a heatwave.
    private static final double HEATWAVE_DEATH_PROBABILITY = 0.22;//0.2 //0.10
   // The maximum number of births.
   private static final int MAX_LITTER_SIZE = 1;
   // A shared random number generator to control breeding.
   private static final Random rand = Randomizer.getRandom();
   // The age to which a the plant can live.
   private static final int MAX_AGE = 20;

  /**
     * Create a new Reed at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
  public Reed(Field field, Location location){
    super(field, location);
   }
  
  /**
     * This is what the reed does most of the time: it might breed,
     * or die of old age.
     * @param newReed The list of all the off spring reed.
     * @param isDay The reeds only act during the day time
     */
  public void act(List<Organism> newReed, boolean isDay)
   {
      if (isDay){
        incrementAge();
        if(isAlive()) {
            giveBirth(newReed);
            if ( !findSpace() ) {
                setDead();
            } 
        }  
      }
  }
  
  /**
     * Looks in the adjacent cells for an un-occupied cell
     * @return boolean isSpace, returns true if there is an unoccupied cell next to the reed
     */
  public boolean findSpace()
  {
    Field field = getField();
    boolean isSpace = false;
    Location adjacent = field.freeAdjacentLocation(getLocation());
    if(adjacent != null) {
        isSpace = true;
    }
    return isSpace;
  }

  /**
     * The reed reproduces new reeds, upto its max litter size, if the reed is of
     * reproducing age and there are adjacent cells available
     * @param newReeds A List of all the new reed objects to add to the field.
     */
  public void giveBirth(List<Organism> newReeds) {
    // New reeds are born into adjacent locations.
    // Get a list of adjacent free locations.
    Field field = getField();
    List<Location> free = field.getFreeAdjacentLocations(getLocation());
    int births = breed();
    for (int b = 0; b < births && free.size() > 0; b++) {
      Location loc = free.remove(0);
      Reed young = new Reed(field, loc);
      newReeds.add(young);
    }
  }

  /**
    * This method overrides the getMaxLitterSize() method in Creature, 
    * @return the Constant MAX_LITTER_SIZE specific to the object type
  **/
  public int getMaxLitterSize()
  {
    return MAX_LITTER_SIZE;
  }

  /**
    * This method overrides the getMaxAge() method in Creature 
    * @return the Constant MAX_AGE specific to the object type
  **/
  public int getMaxAge()
  {
    return MAX_AGE;
  }

  /**
    * This method overrides the getBreedingProbability() method in Creature, 
    * @return the Constant BREEDING_PROBABILITY specific to the object type
  **/
  public double getBreedingProbability()
  {
    return BREEDING_PROBABILITY;  
  } 

  /**
      * This method causes a percentage of reeds to die in the heat 
    **/
  public void heatDeathGenerator()
  {
    double deathProbability = rand.nextDouble();
    if(deathProbability <= HEATWAVE_DEATH_PROBABILITY)
    {
      setDead();
    }
  }  

}