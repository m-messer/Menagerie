import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a locust.
 * Locusts age, move, breed, and die.
 * 
 *
 * @version 2021.02.26 
 */
public class Locust extends Creature  
{
    // Characteristics shared by all locusts (class variables).

    // The age at which a locust can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a locust can live.
    private static final int MAX_AGE = 100;//75
    // The likelihood of a locust breeding.
    private static final double NORMAL_BREEDING_PROBABILITY =0.10; //0.90; //0.22
    // The likelihood of a locust breeding when there is a heatwave.
    private static final double INCREASED_BREEDING_PROBABILITY = 0.13;//1.00; //0.22
    private double BREEDING_PROBABILITY; 
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final int PLANT_FOOD_VALUE = 40;//20
    private static final Random rand = Randomizer.getRandom();
    
    private boolean isIncreased = false;
   // Individual characteristics (instance fields).
    

    /**
     * Create a new locust. A locust may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the locust will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Locust(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Look for a reed adjacent to the current location.
     * Only the first live reed is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Reed) {
                Reed reed = (Reed) plant;
                reed.setDead();
                incrementFoodLevel();
                return where;

            }
        }
        
        return null;
    }

     /**
      * This method overrides the getFoodValue() method in Creature 
      * @return the  Constant FISH_FOOD_VALUE specific to the         * objecttype
    **/
    public int getFoodValue()
    {
      return PLANT_FOOD_VALUE;
    }

    /**
      * This method overrides the getMaxAge() method in Creature 
      @return the Constant MAX_AGE specific to the object type
    **/
    public int getMaxAge()
    {
      return MAX_AGE;
    }

    /**
      * This method overrides the getMaxLitterSize() method in Creature, 
      @return the Constant MAX_LITTER_SIZE specific to the object type
    **/
    public int getMaxLitterSize()
    {
      return MAX_LITTER_SIZE;
    }

    /**
      * This method overrides the getBreedingProbability() method in Creature, @return the Constant BREEDING_PROBABILITY specific to the object type
    **/
    public double getBreedingProbability()
    {
      return BREEDING_PROBABILITY;        
    }  

    /**
    * This sets the appropraite breeding probability for the          * conditions.
    * If it is raining then the breeding probability is increased. 
    */
    public void setBreedingProbability(boolean isIncreased)
    {
      if (isIncreased){
        BREEDING_PROBABILITY = INCREASED_BREEDING_PROBABILITY;
      }
      else{
        BREEDING_PROBABILITY = NORMAL_BREEDING_PROBABILITY;
      }
    }

    /**
      * This method overrides the getBreedingAge() method in Creature, 
      * @return the Constant BREEDING_AGE specific to the object type
    **/
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * This is what the locust does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newLocusts A list to return newly born locusts.
     */
    public void act(List<Organism> newLocusts, boolean isDay)
    { 
      if (isDay){
          super.act(newLocusts, isDay); 
          if(isAlive()) {
              setBreedingProbability(false);
              giveBirth(newLocusts); 
          }
      }
    }
    
    /**
     * Check whether or not this locust is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLocusts A list to return newly born locusts.
     */
    public void giveBirth(List<Organism> newLocusts)
    {
        // New locusts are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Locust young = new Locust(false, field, loc);
            newLocusts.add(young);
            
        }
    }
  /**
      
      * This method returns true because Locusts will 
      * reproduce regardless of their neighbours gender  
      * @return the Boolean true
    **/
    protected boolean isOppositeGender(Object occupant) 
    {
      return true;
    }

   
}