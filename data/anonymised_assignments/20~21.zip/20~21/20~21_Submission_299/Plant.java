import java.util.Random;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Plant.
 * Plants age and reproduce.
 *
 * @version 2021.02.26 
 */

public abstract class Plant extends Organism {

    // No food hunting or gender required- gender = null because n/a to plants
    private static final Random rand = Randomizer.getRandom(); 

    /**
     * A plant object. This reproduces asexually so does not require a mate or have gender.
     * Plants may die of overcrowding or age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location) {
        super(field, location);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

}