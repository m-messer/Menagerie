import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing fish and Crocodilees.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a Crocodile will be created in any given grid position.
    private static final double CROCODILE_CREATION_PROBABILITY = 0.01;
    // The probability that a otter will be created in any given grid position.
    private static final double OTTER_CREATION_PROBABILITY = 0.02;//0.01
    // The probability that a frog will be created in any given grid position.
    private static final double FROG_CREATION_PROBABILITY = 0.10;//0.08 
    // The probability that a fish will be created in any given grid position.
    private static final double FISH_CREATION_PROBABILITY = 0.12;//0.10 
    // The probability that a locust will be created in any given grid position.
    private static final double LOCUST_CREATION_PROBABILITY = 0.14; 
    // The probability that an algae will be created in any given grid position.
    private static final double ALGAE_CREATION_PROBABILITY = 0.17; 
    // The probability that a reed will be created in any given grid position.
    private static final double REED_CREATION_PROBABILITY = 0.20;//0.16   

    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current weather conditions
    private WeatherGenerator weather;
    //The current infectious climate for disease X among otters
    private DiseaseGenerator disease;
    // True if it is day time, false if night
    private boolean isDay;
    // True if there is disease among the otter population
    private boolean isDisease = false;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        isDay = true;
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();
        field = new Field(depth, width);

        weather = new WeatherGenerator(field);
        disease = new DiseaseGenerator(field);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Otter.class, Color.BLACK );
        view.setColor(Crocodile.class, Color.BLUE);
        view.setColor(Frog.class, Color.RED );
        view.setColor(Fish.class, Color.CYAN );
        view.setColor(Locust.class, Color.PINK);
        view.setColor(Algae.class, Color.GREEN);
        view.setColor(Reed.class, Color.YELLOW );

        /** 
         * Potentially  make general for every class^^^ class.getColour?
         */

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(100);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Creature and plant
     */
    public void simulateOneStep()
    {
        step++;
        checkIsDay();
        weather.todaysWeather();
        checkIsDisease();

        // Provide space for newborn organism.
        List<Organism> newOrganism = new ArrayList<>();        
        // Let all fish act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism animal = it.next();
            animal.act(newOrganism, isDay);
            if(!animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born Crocodiles and fish to the main lists.
        organisms.addAll(newOrganism);

        view.showStatus(step, field, isDay, weather.getWeather(), isDisease);
    }

    /**
     * If there is disease then it allows the otters to transmit to any neighbours
     * Otherwise it generates a random number and checks if a new disease arrived today
     */
    public void checkIsDisease()
    {
        if (isDisease){
            disease.transmitter();
        }
        else{
            isDisease = disease.updateDisease();
        }
    }

    /**
     * All even steps are night and odd steps are day time, sets the boolean to be 
     * true accordingly
     */
    public void checkIsDay()
    {
        if ((step % 2) == 0)
        {
            isDay = false;
        }
        else
        {
            isDay = true;
        } 
    }

    /**
     * @return boolean isDay, returns true when it is day time
     */
    public boolean getIsDay()
    {
        return isDay;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, isDay, weather.getWeather(), isDisease);
    }

    /**
     * Randomly populate the field with all the plants are creatures
     * currently generates: Crocodiles, Otters, Frogs, Fish, Locusts, Reeds, Algae
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {

                if(rand.nextDouble() <= CROCODILE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Crocodile crocodile = new Crocodile(true, field, location);
                    organisms.add(crocodile);
                }
                else if(rand.nextDouble() <= OTTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Otter otter = new Otter(true, field, location);
                    organisms.add(otter);
                }
                else if(rand.nextDouble() <= FROG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Frog frog = new Frog(true, field, location);
                    organisms.add(frog);
                }
                else if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fish fish = new Fish(true, field, location);
                    organisms.add(fish);
                }
                else if(rand.nextDouble() <= LOCUST_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Locust locust = new Locust(true, field, location);
                    organisms.add(locust);
                }
                else if(rand.nextDouble() <= ALGAE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Algae algae = new Algae(field, location);
                    organisms.add(algae);
                }
                else if(rand.nextDouble() <= REED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Reed reed = new Reed(field, location);
                    organisms.add(reed);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
