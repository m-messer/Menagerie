
import java.util.Random;
import java.awt.event.ItemEvent;
import java.util.List;

/**
    * Simulates the effects of disease that affects otters
    * If an otter has
    *  the disease, its life span halves and it can pass it on to   other otters.
    *
    * @version 2021.02.26 
    */
public class DiseaseGenerator{
  
  // The current state of the field.
  private Field field;
  // A shared random number generator to control reproduction.
  private static final Random rand = Randomizer.getRandom();
  // The probability that a disease exists in this simulation
  private static final double WORLD_HAVING_DISEASE_PROBABILITY = 0.2;
  
  /**
  * Creates a disease. This disease affects otters. If an otter has
  * the disease, its life span halves and it can pass it on to other
  * otters.
  * @param field The field currently occupied.
  */
  public DiseaseGenerator(Field field)
  {
      this.field = field;
  }

  /*
  *  Simulates a disease which will decrease the life expectancy of a percentage 
  *  of Otters, who also spread the diease to other otters they meet
  */
  public void initialiseDisease()
  {
    for(int row = 0; row < field.getDepth(); row++) {
          for(int col = 0; col < field.getWidth(); col++) {
            Object item = field.getObjectAt(row,col);
            infectOtter(item);
          }
      }
  }

  /**
  * Goes through each cell in the field and checks each organism for a specific disease
  * If it is diseased it will check its neighbours to see if it can be transmitted
  */

  public void transmitter()
  {
    for(int row = 0; row < field.getDepth(); row++) {
        for(int col = 0; col < field.getWidth(); col++) {
            Object item = field.getObjectAt(row,col);
            otterDisease(item);
        }
    }
  }
  /**
  * This checks if the item passed to it is an infected otter and 
  * randomly predicts whether or not the surrounding otters will
  * also get infected.
  * @param Object item = an organism from the field cells
  */
  public void otterDisease(Object item)
  {
    if (item instanceof Otter){   // if the cell has an otter in it
      Otter otty = (Otter) item;
      if (otty.getIsInfected()){  // and the otter is infected
        List<Location> neighbours = field.adjacentLocations(otty.getLocation());
        for (Location cell: neighbours){ 
          //check its neighbours for otters to spread to
          Object occupant = field.getObjectAt(cell);
          infectOtter(occupant) ;
        }
      }
    }
  }
  
  /**
  * This checks if the item passed to it is an infected otter and 
  * randomly predicts whether or not the otter will get infected.
  * @param Object item = an organism from the field cells
  */
  public void infectOtter(Object item)
  {
    if (item instanceof Otter){
      Otter otty = (Otter) item;
      double probability = rand.nextDouble();
      if (probability <= otty.getInfectionRate() ){
        otty.setIsInfected();
      }
    }
  }
  /**
  * This randomly decides using the WORLD_HAVING_DISEASE_PROBABILITY 
  * whether or not a disease exists in the simulation.
  * @return boolean The boolean value indicates the presence of a 
  * disease.
  */
  public boolean updateDisease(){
    double chance = rand.nextDouble();

    if (chance <= WORLD_HAVING_DISEASE_PROBABILITY){
      initialiseDisease();
      return true;
    }
    else{
      return false;
    }
  }
}