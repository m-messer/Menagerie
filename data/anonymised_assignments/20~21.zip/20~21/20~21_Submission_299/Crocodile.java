import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a crocodile.
 * Crocodiles age, move, eat fish and frogs, and die.
 *
 * @version 2021.02.26 
 */
public class Crocodile extends Creature

{ 
    // Characteristics shared by all crocodiles (class variables).
    
    // The age at which a can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a crocodile can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a crocodile breeding.
    private static final double BREEDING_PROBABILITY = 0.80;//0.60; //0.10
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single fish. In effect, this is the
    // number of steps a crocodile can go before it has to eat again.
    private static final int FISH_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    

    /**
     * Create a Crocodile. A crocodile can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the crocodile will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Crocodile(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    
    /**
     * This is what the crocodile does most of the time: it hunts for
     * fish. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newCrocodiles A list to return newly born crocodiles.
     */
    public void act(List<Organism> newCrocodiles, boolean isDay)
    { 
      if (isDay){
        super.act(newCrocodiles, isDay);
        if(isAlive()) {
            giveBirth(newCrocodiles);                
        }
      }
    }

    /**
   * Return this creature's food value which is the number of days
   * this creature can survive after it eats.
   * @return FISH_FOOD_VALUE This is the integer value for the fish
   * the crocodile eats.
   */
    public int getFoodValue()
    {
      return FISH_FOOD_VALUE;
    }
    
    
    /**
     * Look for fish adjacent to the current location.
     * Only the first live fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setDead();
                    incrementFoodLevel();
                    return where;
                }
            }
            if(animal instanceof Frog) {
                Frog frog = (Frog) animal;
                if(frog.isAlive()) { 
                    frog.setDead();
                    incrementFoodLevel();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this crocodile is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCrocodiles A list to return newly born crocodiles.
     */
    public void giveBirth(List<Organism> newCrocodiles)
    {
        // New crocodiles are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Crocodile young = new Crocodile(false, field, loc);
            newCrocodiles.add(young);
        }
    }

    /**
      * This method overrides the getMaxAge() method in Creature, returns the Constant MAX_AGE specific to the object type
    **/
    protected int getMaxAge()
    {
      return MAX_AGE;
    }
    /**
      * This method overrides the getMaxLitterSize() method in Creature, 
      @return the Constant MAX_LITTER_SIZE specific to the object type
    **/
    public int getMaxLitterSize()
    {
      return MAX_LITTER_SIZE;
    }

    /**
      * This method overrides the getBreedingAge() method in Creature, 
      * @return the Constant BREEDING_AGE specific to the object type
    **/
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
      * This method overrides the getBreedingProbability() method in Creature,   
      * @return the Constant BREEDING_PROBABILITY specific to the object type
    **/
    
    public double getBreedingProbability()
    {
      return BREEDING_PROBABILITY;  
    }   

    /**
      * This method checks the neighbouring cell contains a crocodile of the
      * opposite gender   
      * @return the Boolean isOppositeGender
    **/
    protected boolean isOppositeGender(Object occupant) 
    { 
      boolean isOppositeGender = false;
      if (occupant instanceof Crocodile){
          Crocodile croc = (Crocodile) occupant;
          if (croc.getIsFemale() ^ this.getIsFemale()) {
            isOppositeGender = true;
          } //XOR only one can be true  != or ^
        }
      return isOppositeGender;
      
    }
    
}
