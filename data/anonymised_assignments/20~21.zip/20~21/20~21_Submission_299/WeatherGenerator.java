import java.util.Random;
 
public class WeatherGenerator
{   
    /**
    * Simulates the effects of different weather conditions on the animal populations
    * Current weather types implemented: Rain, Heat, Freezing, Optimal/Warm
    *
    * @version 2021.02.26 
    */
    
    private static final double HEATWAVE_PROBABILITY = 0.15;
    private static final double FREEZING_PROBABILITY = 0.30;
    private static final double RAINING_PROBABILITY = 0.45;
    //private static final int HEATWAVE_PROBABILITY = 0.1;
    private static final Random rand = Randomizer.getRandom();
    private Field field;

    private boolean isHeatwave;
    private boolean isRaining;
    private boolean isFreezing;

    public WeatherGenerator(Field field)
    {
      this.field = field;
    }

    /**
     * Resets all the weather booleans to false and randomly generates the weather
     * for one step
     *
     */
    public void todaysWeather()
    {
      isHeatwave = false;
      isRaining = false;
      isFreezing = false;

      double prob = rand.nextDouble();

      if(prob <= HEATWAVE_PROBABILITY) {
          heatWave();
      }
      else if(prob <= FREEZING_PROBABILITY) {
        freezing();
      }
      else if(prob <= RAINING_PROBABILITY) {
        raining();
      }
    }

  /**
  * In the event of a heatwave a percentage of reeds and frogs die
  */
  private void heatWave() // kills Reeds and frogs 
  {   
      isHeatwave = true;
      //System.out.println("IT'S HEATWAVING");
      for(int row = 0; row < field.getDepth(); row++) {
          for(int col = 0; col < field.getWidth(); col++) {
              Object being = field.getObjectAt(row,col);
            if (being instanceof Frog){
                Frog froggy = (Frog) being;
                froggy.heatDeathGenerator();   
            } 
            else if (being instanceof Reed){
                Reed reedy = (Reed) being;
                reedy.heatDeathGenerator();   
            }   
          }
        }
  }

  /**
  * When the temperature is freezing, a percentage of Algae die
  */
  private void freezing()// kill Algae
  {
    isFreezing = true;
    //System.out.println("IT'S FREEZING!");
    for(int row = 0; row < field.getDepth(); row++) {
          for(int col = 0; col < field.getWidth(); col++) {
              Object being = field.getObjectAt(row,col);
            if (being instanceof Algae){
                Algae algae = (Algae) being;
                algae.freezeDeathGenerator();   
            } 
          }
    }
  }
  /**
  * In the event of rain, the locusts' breeding probability increases
  */
  private void raining() // locusts breed more
  {
    isRaining = true;
    //System.out.println("IT'S RAINING!");
    for(int row = 0; row < field.getDepth(); row++) {
          for(int col = 0; col < field.getWidth(); col++) {
              Object being = field.getObjectAt(row,col);
            if (being instanceof Locust){
                Locust locust = (Locust) being; 
                // Action for Locust
                locust.setBreedingProbability(true);
                
            }   

          }
    }
        
  }
  /**
    * Returns the appropriate string depending on the current weather conditions
    * @return String stating the weather conditions e.g "HEATWAVE"
    */
  public String getWeather()
    {
      if (isHeatwave)
      {
        return "HEATWAVE";
      }
      else if (isFreezing){
        return "FREEZING";
      }
      else if (isRaining){
        return "RAINING";
      }
      else {
        return "OPTIMAL";
      }
    }
}

