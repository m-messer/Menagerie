import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a creature.
 * Creatures age, move, eat plants or other creatures, and die.
 *
 * @version 2021.02.26 
 */
abstract class Creature extends Organism

{ 
    // Characteristics shared by all Creatures (class variables).
   
    // Individual characteristics (instance fields).
    private int age;
    // The creature's gender.
    private boolean isFemale;
    // The creature's food level, which is increased by eating.
    private int foodLevel;
    // A shared random number generator to control reproduction.
    private static final Random rand = Randomizer.getRandom();
    // Whether or not a creature has been infected with a disease.
    private boolean isInfected = false;

    /**
     * Create a creature. A creature can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the creature will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Creature(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        generateGender();
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt( getFoodValue());
        }
        else {
            age = 0;
            foodLevel =  getFoodValue();
        }
        
    }

  /**
     * This is what the otter does most of the time: it hunts for
     * fish. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newOrganism A list to return newly born organism.
     * @param isDay Whether it is currently day or night.
     */  
  public void act(List<Organism> newOrganism, boolean isDay)
  {
    incrementAge();
    incrementHunger(); 
    if (isAlive()){          
        // Move towards a source of food if found.
        Location newLocation = findFood();
        if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }
  }

  /**
     * Sets the isInfected variable as true when a disease exists in 
     * the environment.
     */
  public void setIsInfected()
  {
    isInfected = true;
   }

  /**
  * @return isInfected The boolean that says whether or not a creature
  * has a disease.
  */
   public boolean getIsInfected()
   {
    return isInfected;
   }
    
   /**
   * Return this creature's breeding age which is the age at which this
   * creature can give birth 
   */
   abstract protected int getBreedingAge();

   /**
   * Return this creature's food value which is the number of days
   * this creature can survive after it eats.
   */
   abstract protected int getFoodValue();

    /**
     * Make this creature more hungry. This could result in the creature's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for creatures adjacent to the current location.
     * Only the first live creature is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    abstract Location findFood();
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

   public void incrementFoodLevel()
   {
     foodLevel = getFoodValue() + foodLevel;
   } 

    /**
     * A creature can breed if it has reached the breeding age and 
     * has found a mate
     */
    public boolean canBreed()
    {
        return ( (age >= getBreedingAge()) && findMate());
    }

    /**
    * Finds out is a creature is of the opposite gender to this
    * creature.
    * @param occupant The object that is located in a specific space
    * on the field.
    * @return returns a boolean value indication if a creature is of
    * the opposite gender to this creature. 
    */
    abstract protected boolean isOppositeGender(Object occupant);
    
    /**
    * Randomly assigns true or false to the isFemale field to indicate
    * the creature's gender. 
    */
    protected void generateGender()
    {
      isFemale = true;
      int num = rand.nextInt(1);
      if (num == 1){
        isFemale = false;
      }
    }

    /**
    *   Checks the Neighbouring cells of the creature for a creature 
    *   of the opposite gender to reproduce with
    *   @return foundMate, returns true if there is one of each gender
    */
    public boolean findMate(){
      boolean foundMate = false;
      List<Location> neighbours = getField().adjacentLocations(getLocation());
      for (Location cell: neighbours){
        Object occupant = getField().getObjectAt(cell);
        if (isOppositeGender(occupant)){
            foundMate = true;
          } 
        }
      return foundMate;
    }
    /**
     * Return the creature's isFemale field.
     * @return isFemale This boolean value indicates the gender of 
     * this creature.
     */
      protected boolean getIsFemale()
      {
          return isFemale;
      }


}

