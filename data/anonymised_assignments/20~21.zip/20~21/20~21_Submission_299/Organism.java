import java.util.List;
/**
 * A class representing shared characteristics of all living organisims in the simulation.
 *
 * @version 2021.02.26 
 */

public abstract class Organism
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The fox's age.
    private int age;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this animal act - that is: make it do whatever it wants/needs to do.
     * @param newOrganism A list to receive newly born animals.
     * @param isDay A boolean allowing the organism to change behaviour depending
     *        on the time of day
     */
    abstract public void act(List<Organism> newOrganism, boolean isDay);

    /**
     * Generate a list of new organisms the current one just gave birth to 
     * depending a variety of factors relevant to the type of organism 
     */
    abstract public void giveBirth(List<Organism> newOrganisms);

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     */
    abstract protected int breed();

    /**
     * Return the constant for that organism
     * @return The organism's BREEDING_PROBABILITY
     */
    abstract protected double getBreedingProbability();

    /**
     * Return the constant that determines the max number of births at once
     * @return The organism's MAX_LITTER_SIZE
     */
    abstract protected int getMaxLitterSize();

    /**
     * Return the constant that determines the max number of steps an 
     * organism lives
     * @return The organism's MAX_AGE
     */
    abstract protected int getMaxAge();

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Increase the age. This could result in the fox's death.
     */ 
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
