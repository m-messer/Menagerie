import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Frog.
 * Frogs age, move, eat fish, and die.
 * 
 *
 * @version 2021.02.26 
 */
public class Frog extends Creature

{ 
    // Characteristics shared by all Frogs (class variables).
    
    // The age at which a can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Frog can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a Frog breeding.
    private static final double BREEDING_PROBABILITY = 0.15;//0.40;//0.90;
    // The likelihood of a Frog dying in the case of a heatwave.
    private static final double HEATWAVE_DEATH_PROBABILITY = 0.25;//0.25 
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single fish. In effect, this is the
    // number of steps a Frog can go before it has to eat again.
    private static final int FISH_FOOD_VALUE = 25;
    // The food value of a single locust. In effect, this is the
    // number of steps a Frog can go before it has to eat again.
    private static final int LOCUST_FOOD_VALUE = 25;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    

    /**
     * Create a Frog. A Frog can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Frog will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Frog(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    
    /**
     * This is what the Frog does most of the time: it hunts for
     * fish. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFrogs A list to return newly born Frogs.
     */
    public void act(List<Organism> newFrogs, boolean isDay)
    {
      if (!isDay){  
        super.act(newFrogs, isDay);
        if(isAlive()) {
          giveBirth(newFrogs);
        }
      }
    }

     /**
      * This method overrides the getFoodValue() method in Creature 
      * @return the sum of the Constants FISH_FOOD_VALUE and         * LOCUST_FOOD_VALUE specific to the objecttype
    **/
    public int getFoodValue()
    {
      return FISH_FOOD_VALUE + LOCUST_FOOD_VALUE;
    }
    
    
    
    /**
     * Look for fish adjacent to the current location.
     * Only the first live fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant.isAlive()) { 
                    plant.setDead();
                    incrementFoodLevel();
                    return where;
                }
            }
            else if(animal instanceof Locust) {
                Locust locust = (Locust) animal;
                if(locust.isAlive()) { 
                    locust.setDead();
                    incrementFoodLevel();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Frog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFrogs A list to return newly born Frogs.
     */
    public void giveBirth(List<Organism> newFrogs)
    {
        // New Frogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Frog young = new Frog(false, field, loc);
            newFrogs.add(young);
        }
    }

    /**
      * This method overrides the getMaxAge() method in Creature, returns the Constant MAX_AGE specific to the object type
    **/
    protected int getMaxAge()
    {
      return MAX_AGE;
    }

    /**
      * This method overrides the getMaxLitterSize() method in Creature, 
      @return the Constant MAX_LITTER_SIZE specific to the object type
    **/
    public int getMaxLitterSize()
    {
      return MAX_LITTER_SIZE;
    }

    /**
      * This method overrides the getBreedingAge() method in Creature, 
      * @return the Constant BREEDING_AGE specific to the object type
    **/
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
      * This method overrides the getBreedingProbability() method in Creature,   
      * @return the Constant BREEDING_PROBABILITY specific to the object type
    **/
    public double getBreedingProbability()
    {
      return BREEDING_PROBABILITY;  
    }   

    /**
      
      * This method returns true because Frogs will 
      * reproduce regardless of their neighbours gender  
      * @return the Boolean true
    **/
    protected boolean isOppositeGender(Object occupant) 
    {
      return true;
    }

  /**
  * Checks whether or not frog succumb to a heatwave.
  * If the random number is less than the HEATWAVE_DEATH_PROBABILITY,
  * then it is set as dead.
  */
  public void heatDeathGenerator()
  {
    double deathProbability = rand.nextDouble();
    if(deathProbability <= HEATWAVE_DEATH_PROBABILITY)
    {
      setDead();
    }
  }    
}


