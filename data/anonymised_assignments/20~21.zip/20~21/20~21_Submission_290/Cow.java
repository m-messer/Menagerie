import java.util.List;
import java.util.Random;
import java.util.ArrayList; 
import java.util.Iterator;

/**
 * A simple model of a cow.
 * Cows age, move, breed, eat grass and die.
 *
 * @version 2021.3.2
 */
public class Cow extends Animal
{
    // Characteristics shared by all cows (class variables).

    // The age at which a cow can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a cow can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a cow breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 500;
    // The food value of a single cow. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    private ArrayList<Location>orders;
    // The cow's age.
    private int age;
    // The cow's food level, which is increased by eating grass.
    private int foodLevel;

    /**
     * Create a new cow. A cow may be created with age
     * zero and not hungry(a new born) or with a random age and food level.
     * 
     * @param randomAge If true, the cow will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cow(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * This is what the cow does during daytime when sunny - it runs and eat grass
     * around. Sometimes it will breed, die of hunger or die of old age.
     * @param newCows A list to return newly born cows.
     */
    public void act(List<Animal> newCows)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newCows);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is what the cow does during night when sunny - it runs and eat grass
     * around. Sometimes it will breed, or die of old age but will not die of hunger.
     */
    public void sleep(List<Animal> newCows)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newCows);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is what the cow does when rainy
     * Sometimes it will breed or die of old age but will not die of hunger.
     */
    public void rest(List<Animal> newCows)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newCows);            
        }
    }

    /**
     * Increase the age.
     * This could result in the cow's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this cow is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCows A list to return newly born cows.
     */
    private void giveBirth(List<Animal> newCows)
    {
        // New cows are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cow young = new Cow(false, field, loc);
            newCows.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A cow can breed if it has reached the breeding age
     * and whether this cow adjacent to a opposite sex cow.
     * @return true if the cow can breed, false otherwise.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> occupied = field.adjacentLocations(getLocation());
        for(int i = 0 ; i<occupied.size() ; i++){
            Object aroundAni = field.getObjectAt(occupied.get(i));
            if(aroundAni instanceof Cow) {
                Cow cow = (Cow) aroundAni;
                if(cow.getGender() == this.getGender()){
                    return false;        
                }
                else{
                    if(age >= BREEDING_AGE){
                        return true;
                    }                 
                }
            }
        }
        return false;
    }

    /**
     * Make this cow more hungry. This could result in the cow's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for cows adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where grass was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Grass) {
                Grass grass = (Grass) animal;
                if(grass.isAlive()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
