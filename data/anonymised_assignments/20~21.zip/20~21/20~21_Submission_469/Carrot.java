import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A Simple mode of a carrot
 * carrot fundamental attribute.
 */
public class Carrot extends Plant
{
    // The age at which a carrot can be eatted.
    private static final int EATEN_AGE = 0;
    // The age to which a carrot can live.
    private static final int MAX_AGE = 2;
    
    private static final int MAX_LITTER_SIZE = 1;
    private static final Random rand = Randomizer.getRandom();
    private int age;
    
    
    /**
     * Create a new carrot. A carrot may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the carrot will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Carrot(boolean randomAge, Field field, Location location)
    {
       super(field, location);
       if(randomAge) {
           age = rand.nextInt(MAX_AGE);
       } 
       else {
           age = 0;
       }
    }

    /**
     * This is what the carrot does most of the time - it runs 
     * around. Sometimes it will die of old age.
     * @param newcarrots A list to return newly born carrots.
     */
    public void act(List<Plant> newCarrots)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newCarrots);
        }           
        else{
             // Overcrowding.
             setDead();
        }
    }
    
    
    /**
     * Increase the age.
     * This could result in the carrot's death.
     */
    private void incrementAge()
    {
        age = age + 2;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this carrot is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param carrots A list to return newly born carrots.
     */
    private void giveBirth(List<Plant> newCarrots)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = growth();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Carrot young = new Carrot(false, field, loc);
            newCarrots.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can growth.
     * @return The number of births (may be zero).
     */
    private int growth()
    {
        int births = 0;
        births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        return births;
    }
}
