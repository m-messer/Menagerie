import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.1;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.1;    
    private static final double TIGER_CREATION_PROBABILITY = 0.03;
    private static final double ZEBRA_CREATION_PROBABILITY = 0.03;
    private static final double LION_CREATION_PROBABILITY = 0.03;
    private static final double CARROT_CREATION_PROBABILITY = 0.03;
    // List of animals in the field.
    private List<Animal> animals;
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    private int day;
    // A graphical view of the simulation.
    private boolean night;
    private boolean fogged;
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Tiger.class, Color.RED);
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Lion.class, Color.GRAY);
        view.setColor(Carrot.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        day = step/5;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        // Let all rabbits act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext();){
            Plant plant = it.next();
            if(step%5 == 1){
                plant.act(newPlants);}
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(!isFogged()){
                if(animal.isNightAnimal() && isNight()){
                    animal.act(newAnimals);}
                    else if(!animal.isNightAnimal() && !isNight()){
                        animal.act(newAnimals);
                    }
                if(! animal.isAlive()) {
                    it.remove();
                }
            }   
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);

        view.showStatus(step, day, fogged, night, field);
    }
    
    /**
     * Set the environment change
     * Simulator may have day and night.
     */
    public boolean isNight(){
        if(step%5 == 4){
            night = true;
        }
        else{
            night = false;
        } 
        return night;
    }
    
    /**
     * Set the environment change
     * Simulator may have different weather and it will affect the animal's
     * action.
     */
    public boolean isFogged()
    {
       int a = (int)(Math.random()*5);
        if (a<=1){
            fogged = true;
        }
        if (a>1){
            fogged = false;
        } 
        return fogged;
    }
    
    /**
     * Set the number of step in simulator and return
     */
    public int getNumberOfStep()
    {
        return step;
    }
    
    /**
     * Set the number of day in simulator and return
     */
    public int getNumberOfDay()
    {
        return day;
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        day = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, day,fogged, night, field);

    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= CARROT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Carrot carrot = new Carrot(true, field, location);
                    plants.add(carrot);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
