    import java.util.List;
    import java.util.Iterator;
    import java.util.Random;
    
    /**
     * A class representing shared characteristics of animals.
     *
     * @version 2016.02.29 (2)
     */
    public abstract class Animal
    {
        // Whether the animal is alive or not.
        protected boolean alive;
        // The animal's field.
        protected Field field;
        // The animal's position in the field.
        protected Location location;
        // the age of the animal
        protected int age;
        // the food level of the animal
        protected int foodLevel;
        // A shared random number generator to control breeding.
        private static final Random rand = Randomizer.getRandom();
        //The animal gender
        protected boolean female;
        //the rates at which the disease spreads
        private static double SPREADING_PROBABILITY = 0.001;
        
        private static double INFECTION_PROBABILITY = 0.0001;
        
        protected static boolean isInfected;
        
        protected static int stepInfected;
    
        /**
         * Create a new animal at location in field.
         * 
         * @param field The field currently occupied.
         * @param location The location within the field.
         */
        public Animal(Field field, Location location)
        {
            alive = true;
            this.field = field;
            setLocation(location);
        }
        
        /**
         * Make this animal act - that is: make it do
         * whatever it wants/needs to do.
         * @param newAnimals A list to receive newly born animals.
         */
        abstract public void act(List<Animal> newAnimals);
    
        /**
         * Check whether the animal is alive or not.
         * @return true if the animal is still alive.
         */
        protected boolean isAlive()
        {
            return alive;
        }
    
        /**
         * Indicate that the animal is no longer alive.
         * It is removed from the field.
         */
        protected void setDead()
        {
            alive = false;
            if(location != null) {
                field.clear(location);
                location = null;
                field = null;
            }
        }
        
        /**
         * Return the animal's location.
         * @return The animal's location.
         */
        protected Location getLocation()
        {
            return location;
        }
        
        /**
         * Place the animal at the new location in the given field.
         * @param newLocation The animal's new location.
         */
        protected void setLocation(Location newLocation)
        {
            if(location != null) {
                field.clear(location);
            }
            location = newLocation;
            field.place(this, newLocation);
        }
        
        /**
         * Return the animal's field.
         * @return The animal's field.
         */
        protected Field getField()
        {
            return field;
        }
       
        // abstract classes used
    
        // the following get.... clases are used to obtain values
        // found within subclass objects
    
        protected abstract double getBreedingProbablity();
    
        protected abstract int getBreedingAge();
    
        protected abstract int getMaxAge();
    
        protected abstract int getMaxLitterSize();
    
        protected abstract int getFirstFoodValue();
        
        protected abstract int getSecondFoodValue();
    
        protected abstract Class getAnimalClass();
        
        protected abstract Class getFirstFoodClass();
        
        protected abstract Class getSecondFoodClass();
    
        public abstract Animal getNewAnimal(boolean randomAge, Field field, Location location);
        
        protected abstract boolean getFemale();
        
        // integrated methods to prevent duplicated code
    
        /**
         * Increase the age. This could result in the animal's death.
         */
        protected void incrementAge()
        {
            age++;
            if(age >= getMaxAge()) {
                setDead();
            }
        }
        
        /**
         * Make this animal more hungry. This could result in the animal's death.
         */
        protected void incrementHunger()
        {
            foodLevel--;
            if(foodLevel <= 0) {
                setDead();
            }
        }
        
        /**
         * Check whether or not this wolf is to give birth at this step.
         * New births will be made into free adjacent locations.
         * @param newSpecies A list to return newly born animals.
         */
        protected void giveBirth(List<Animal> newSpecies)
        {
            // New animals are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Animal young = getNewAnimal(false, field, loc);
                newSpecies.add(young);
            }
        }
            
        /**
         * Generate a number representing the number of births,
         * if it can breed.
         * @return The number of births (may be zero).
         */
        protected int breed()
        {
            int births = 0;
            if(canBreed() && rand.nextDouble() <= getBreedingProbablity()) {
                births = rand.nextInt(getMaxLitterSize()) + 1;
            }
            return births;
        }
        
        /**
         * A wolf can breed if it has reached the breeding age.
        */
        protected boolean canBreed()
        {
            Class animal1 = getAnimalClass();
            if( age >= getBreedingAge()){
               Field field = getField();
               List<Location> adjacent = field.adjacentLocations(getLocation());
               Iterator<Location> it = adjacent.iterator();
               while(it.hasNext()) {
                 Location where = it.next();
                 Object animal2 = field.getObjectAt(where);
                 if(animal1.isInstance(animal2)) {
                    Animal breeder = (Animal) animal2;
                    boolean female2 = breeder.getFemale();
                    if(female && !female2) {
                        return true;
                    }
                    else if(!female && female2) {
                        return true;
                    }
                 }
              }
            }
            return false;
        }
        
        /**
         * The method that creates and implpements the disease
         */
        protected void CheckDisease()
        {
            if (Simulator.step - stepInfected >= 5)
            {
                setDead();
            }
        }
        
        /**
         * This method is a chance that an animal is infected
         */
        public static void StartDisease()
        {
            if(rand.nextDouble() <= INFECTION_PROBABILITY)
            {
                isInfected = true;
                stepInfected = Simulator.step;
            }
        }

        /**
        * Method that spreads the disease.
        */
        protected void SpreadDisease()
        {
            if(isInfected && rand.nextDouble() <= SPREADING_PROBABILITY && isAlive())
            {
               Field field = getField();
               List<Location> adjacent = field.adjacentLocations(getLocation());
               Iterator<Location> it = adjacent.iterator();
               while(it.hasNext())
               {
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    isInfected = true;
               }
            }
        }
    
        /**
        * 
        */
        public boolean isFemale()
        {
            female = rand.nextBoolean();
            if(female == true ){
                return true;
            }
            return false;
        }
}
