    import java.util.List;
    import java.util.Iterator;
    import java.util.Random;


public class Weather
{
    // a string used to tell what the weather is in other classes
    public static String type = "Clear";
    // an integer of the amount of weather types
    private static int weatherTypes = 7;
    // the chance that the weather will change when being called upon
    private static double changeWeatherProbability = 0.05;
    
    private static final Random rand = Randomizer.getRandom();
      
    public static void changeWeather()
    {
        // generates a random double used to change the weather
        double randWeather = rand.nextDouble();
        // has a random chance to change the weather
        if (randWeather <= changeWeatherProbability) 
        {
            // generates a random integer that is assigned with a specific weather type
            int random = rand.nextInt(weatherTypes - 1);
            // changes the weather type based of what the random integer is
            if (random == 0)
            {
                type = "Rainfall";
            }
            else if (random == 1)
            {
                type = "Heatwave";
            }
            else if (random == 2)
            {
                type = "Blizzard";
            }
            else if (random == 3)
            {
                type = "Fog";
            }
            else if (random == 4)
            {
                type = "Storm";
            }
            else if (random == 5)
            {
                type = "Clear";
            }
            else if (random == 6)
            {
                type = "Cloudy";
            }
        }
    }
      
}
