import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Deer.
 * Deers age, move, breed, and die.
 *
 * @version 2021.03.01 (5)
 */
public class Deer extends Animal
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a deer can live.
    private static final int MAX_AGE = 75;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.68;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The numbers of steps that the deer can do without eating.
    private static final int GRASS_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new coypu. A coypu may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the coypu will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        female = isFemale();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
            
        }
    }
    
    /**
     * This is what the coypu does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newCoypu A list to return newly born coypu.
     */
    public void act(List<Animal> newDeer)
    {
        if (Weather.type == "Clear" && Simulator.time >= 8 && Simulator.time <= 20) 
        {
            regularActivity(newDeer);
        }
        else if (Weather.type == "Blizzard" && Simulator.time >= 12 && Simulator.time <= 17)
        {
            regularActivity(newDeer);
        }
        else if (Weather.type == "Rainfall" && Simulator.time >= 12 && Simulator.time <= 18)
        {
            regularActivity(newDeer);
        }
        else if (Weather.type == "Heatwave" && Simulator.time >= 7 && Simulator.time <= 21)
        {
            regularActivity(newDeer);
        }
        else if (Weather.type == "Fog" && Simulator.time >= 8 && Simulator.time <= 20)
        {
            regularActivity(newDeer);
        }
        else if (Weather.type == "Storm" && Simulator.time >= 12 && Simulator.time <= 16)
        {
            regularActivity(newDeer);
        }
        else if (Weather.type == "Cloudy" && Simulator.time >= 8 && Simulator.time <= 20)
        {
            regularActivity(newDeer);
        }
    }

     /**
     * This method is used in place for
     * the act method and resembles regular
     * behaviour for the animal in a single step.
     */
    private void regularActivity(List<Animal> newDeer)
    {
        incrementAge();
        incrementHunger();
        CheckDisease();
        if(isInfected)
        {
            SpreadDisease();
        }
        if(isAlive()) 
        {
            if (foodLevel > 4) 
            {
                giveBirth(newDeer);
            }
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    public double getBreedingProbablity()
    {
        return BREEDING_PROBABILITY;
    }

    public int getBreedingAge() 
    {
        return BREEDING_AGE;
    }

    public int getMaxAge()
    {
        return MAX_AGE;
    } 
    
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    public Class getAnimalClass()
    {
        return Deer.class;
    }
    
        public Class getFirstFoodClass()
    {
        return Grass.class;
    }
    
    public Class getSecondFoodClass()
    {
        return null;
    }
    
    public int getFirstFoodValue()
    {
        return GRASS_FOOD_VALUE;
    }
    
    public int getSecondFoodValue()
    {
        return 0;
    }
    
        public boolean getFemale() 
    {
        return female;
    }
    
    public Animal getNewAnimal(boolean randomAge, Field field, Location location)
    {
        Deer newAnimal = new Deer(false, field, location);
        return newAnimal;
    }
    
    /**
     * Look for rabbits or mouse adjacent to the current location.
     * Only the first live rabbit/ mouse is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
         while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Grass  ) {
                Grass grass = (Grass) animal;
                if(grass.isAlive() && foodLevel > 4) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
       }
}