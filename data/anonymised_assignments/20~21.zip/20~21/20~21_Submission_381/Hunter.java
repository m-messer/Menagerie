import java.util.List;
import java.util.Random;

/**
 * 
 * A class representing shared characteristics of hunters.
 * A simple model of a hunter
 * Hunters move and shoot.
 */
public class Hunter extends Human
{   
    // The number of bullets each hunter has
    private static final int NUMBER_OF_BULLETS = 5;
    
    /**
     * Create a hunter. 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hunter(Field field, Location newLocation)
    {
        super(field, newLocation);
    }

    /**
     * Hunter hunts animals and moves to adjecent locations. 
     * If it is overcrowded, he dies.
     * @param field The field currently occupied.
     * @param newbears A list to return newly born bears.
     */
    
    public void act(List<Actor> newHunters)
    {
        // Move towards a source of food if found.
        if(isActive()) {
            Location newLocation = hunt();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for an animal in a random location to hunt.
     * @return Where the last animal is shot, or null if it wasn't.
     */
    private Location hunt()
    {
        Field field = getField();
        int randRow = new Random().nextInt(getField().getDepth());
        int randCol = new Random().nextInt(getField().getDepth());
        Location location = null;
        int num = 0;
        while(num <= NUMBER_OF_BULLETS) {
            Location where = new Location(randRow, randCol);
            Object actor = field.getObjectAt(where);
            if(actor instanceof Animal) 
            {
                Animal animal = (Animal) actor;
                if(animal.isActive()) 
                { 
                    animal.setDead();
                    location = where;
                }
            }
            num++;
        }
        return location;
    } 
}