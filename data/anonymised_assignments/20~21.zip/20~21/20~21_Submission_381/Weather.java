import java.util.HashMap;
import java.util.List;
import java.util.Random;
/**
 * THis class represents weather in the predator/ prey simulation. 
 */

public class Weather
{
    // a HashMap that holds all weather conditions words and thier value
    private HashMap<String, WeatherConditions> conditions;
    // a string representing current weather. 
    private String currentWeather;
    // radnom object used to assign a radnom weather to the String currentWeather. 
    private Random rand = new Random();
    
    /**
     * Constructor -  intialize the weather conditions.
     */
    public Weather(){
        createWeatherConditions();
        setRandomWeather();
    }
    
    /**
     * Create a HashMap that holds all weather conditions and thier string value 
     */
    private void createWeatherConditions(){
       conditions = new HashMap<String, WeatherConditions>();
       for(WeatherConditions condition : WeatherConditions.values()){
               conditions.put(condition.toString(), condition);
       }    
    }
    
    /**
     * Check whether a given String is a valid command word. 
     * @return true if it is, false if it isn't.
     */
    public boolean isWeather(String aString)
    {
        if(conditions.containsKey(aString)){
            return true;
        }
        // if we get here, the string was not found in the commands
        return false;
    }
    
    /**
     * @returns current weather. 
     */
    public String getCurrentWeather(){
        return currentWeather;
    }
    
    /**
     * sets a random weather from the enum weatherConditions. 
     */
    public void setRandomWeather(){
        currentWeather = getConditionList().get(rand.nextInt(getConditionList().size()));
    }
    
    /**
     * @returns a weather String to be used in the display of the simulation. 
     */
    public String getWeatherString(){
        String weatherString = " Weather: " + currentWeather; 
        return weatherString; 
    } 
    
    
    /**
     * @returns a list of weather conditions.
     */
    public List<String> getConditionList() 
    {
        return List.copyOf(conditions.keySet());
    }
}
