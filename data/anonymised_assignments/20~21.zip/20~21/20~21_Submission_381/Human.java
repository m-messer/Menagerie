import java.util.Random;
/**
 * A class representing shared characteristics of humans.
 *
 * @version 2/3/2021
 */
public abstract class Human implements Actor
{
    //Whether the human is alive or not. 
    private boolean alive;
    // The human's field.
    private Field field;
    // The human's position in the field.
    private Location location;
    //a shared random number generator. 
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new human at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Human(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Check whether the human is alive or not.
     * @return true if the human is still alive.
     */
    public boolean isActive()
    {
        return alive;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the human's location.
     * @return The human's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the human at the new location in the given field.
     * @param newLocation The human's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the human's field.
     * @return The human's field.
     */
    protected Field getField()
    {
        return field;
    }
    /**
     * returns the random object used in the class human. 
     */
    protected Random getRandom(){
        return rand;
    }
}
