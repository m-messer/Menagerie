import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Write a description of class Giraffe here.
 *
 * @version (a version number or a date)
 */
public class Giraffe extends Animal
{
    // Characteristics shared by all giraffees (class variables).
    
    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 10;// 15
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 93; //90
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.125; //125
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;//3
    // The food value of a single grass. In effect, this is the
    // number of steps a giraffe can go before it has to eat again.
    private static final int ACACIA_FOOD_VALUE = 35; //12     30
    // The food level at which an animal can breed
    private static final int BREEDING_FOOD_LEVEL = ACACIA_FOOD_VALUE/4;
    // Maximum food value
    private static final int MAX_FOOD_VALUE = ACACIA_FOOD_VALUE*2; 

    /**
     * Create a giraffe. A giraffe can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the giraffe will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Giraffe(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setFoodLevel(getRandom().nextInt(ACACIA_FOOD_VALUE));            
            setAge(getRandom().nextInt(MAX_AGE));
        }
        else {
            setFoodLevel(ACACIA_FOOD_VALUE);            
            setAge(0);
        }
        setInfection(false);
        setLifeExpectancy(MAX_AGE); 
    }
    
    /**
     * This is what the giraffe does most of the time: it eats for
     * acacia. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newgiraffees A list to return newly born giraffees.
     */
    public void act(List<Actor> newgiraffees)
    {
        incrementAge();
        incrementHunger();
        decrementLifeExpectancy();
        if(isActive()) {
            giveBirth(newgiraffees);  
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for rabbits adjacent to the current location.
     * all adjecent live acacia is eaten, 
     * but food level remains at max food level.
     * @return Where the last food was found, or null if it no food was found.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        Location location = null; 
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Acacia) {
                Acacia acacia = (Acacia) actor;
                if(acacia.isActive()) { 
                    acacia.setDead();
                    if(!isInfected()){
                        setInfection(acacia.isInfected());
                        if(isInfected()){ 
                            setInfectionSource(acacia.getInfectionSource());
                            setLifeExpectancy((int)(getAge()*getInfectionSource().getLifeExpectancy()));
                        }
                    }
                    setFoodLevel(getFoodLevel()+ACACIA_FOOD_VALUE);
                    if(getFoodLevel() > MAX_FOOD_VALUE){
                        setFoodLevel(MAX_FOOD_VALUE);
                        location = where;
                    }
                }
            }
        }
        return location;
    }
    
    /**
     * creates a giraffe object in the given field and location
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @returns a giraffe object.
     */
    protected Animal giveBirth(Field field, Location location){
        return new Giraffe(false, field, location);
    }
    
    /**
     * finds a suitable mate, 
     * who is of the same species and different gender.
     * @param location The location within the field.
     * @return true if a mate has been found, false otherwise.
     */
    protected boolean isMate(Location loc){
        Field field = getField();
        if (field.getObjectAt(loc) instanceof Giraffe ){
            if (((Giraffe)field.getObjectAt(loc)).isMale() != isMale()){ 
                return true;
            }
        }
        return false;
    }
    
    /**
     * @returns the maximum age.
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @returns the breeding age.
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @returns the max litter size 
     * which is the maximum number of births 
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @returns the breeding probability
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @returns breeding food age
     * which is the minimum food level for a zebra to breed
     */
    protected int getBreedingFoodLevel(){
        return BREEDING_FOOD_LEVEL;
    }
}
