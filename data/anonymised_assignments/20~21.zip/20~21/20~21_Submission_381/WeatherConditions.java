/**
 * Enumeration class WeatherConditions. - 
 * 
 * Representation for all the valid weather strings for the simulation
 * 
 */
public enum WeatherConditions
{
    RAINY("Rainy"), SUNNY("Sunny"), STORMY("Stormy"), SNOWY("Snowy"); 

    private String currentWeather; 
    /**
     * Constructor -  intialize with the corresponding weather String.
     * @param curretnWeather 
     */
    WeatherConditions(String currentWeather){ 
        this.currentWeather = currentWeather; 
    } 
    
    /**
     * Returns a string.
     * @return The weather word as a string.
     */
    public String toString(){ 
        return currentWeather; 
    } 
}
