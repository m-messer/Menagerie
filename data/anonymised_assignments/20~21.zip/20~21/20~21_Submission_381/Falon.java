import java.util.List;

/**
 * class Falon extends disease - represents a type of disease. 
 *
 * @version (version number or date here)
 */
public class Falon extends Disease
{   
    // life expectacny of animals infected with this disease. 
    private double LIFE_EXPECTENCY = 0.3;
    
    /**
     * constructor
     */
    public Falon(){
        setLifeExpectancy(LIFE_EXPECTENCY);
    }
}
