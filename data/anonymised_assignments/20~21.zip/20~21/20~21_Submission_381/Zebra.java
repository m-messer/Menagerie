import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
/**
 * Write a description of class zebra  here.
 *
 * @version (a version number or a date)
 */
public class Zebra extends Animal
{
    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.125; //155
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single grass. In effect, this is the
    // number of steps a zebra can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 50; 
    // The food level at which an animal can breed 
    private static final int BREEDING_FOOD_LEVEL = GRASS_FOOD_VALUE/4;
    // Maximum food value 
    private static final int MAX_FOOD_VALUE = GRASS_FOOD_VALUE*4;
    
    /**
     * Create a new zebar. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setFoodLevel(getRandom().nextInt(GRASS_FOOD_VALUE));            
            setAge(getRandom().nextInt(MAX_AGE));
        }
        else {
            setFoodLevel(GRASS_FOOD_VALUE);            
            setAge(0);
        }
        setInfection(false);
        setLifeExpectancy(MAX_AGE);
    }
    
    /**
     * This is what the zebra does most of the time - it eats for
     * grass. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newZebras A list to return newly born zebras.
     */
    public void act(List<Actor> newzebras)
    {
        incrementAge();
        incrementHunger();
        decrementLifeExpectancy();
        if(isActive()) {
            giveBirth(newzebras); 
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
   
    /**
     * Look for grass adjacent to the current location.
     * all adjecent live garss is eaten, 
     * but food level remains at max food level.
     * @return Where the last food was found, or null if it no food was found.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        Location location = null;
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Grass) {
                Grass grass = (Grass) actor;
                if(grass.isActive()) { 
                    grass.setDead();
                    if(!isInfected()){
                        setInfection(grass.isInfected());
                        if(isInfected()){ 
                            setInfectionSource(grass.getInfectionSource());
                            setLifeExpectancy((int)(getAge()*getInfectionSource().getLifeExpectancy()));
                        }
                    }
                    setFoodLevel(getFoodLevel()+GRASS_FOOD_VALUE);
                    if(getFoodLevel() > MAX_FOOD_VALUE){
                        setFoodLevel(MAX_FOOD_VALUE);
                        location = where;
                    }
                }
            }
        }
        return location;
    }
    
    /**
     * creates a zebra object in the given field and location
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @returns a zebra object.
     */
    protected Animal giveBirth(Field field, Location location){
        return new Zebra(false, field, location);
    }
    
    /**
     * finds a suitable mate, 
     * who is of the same species and different gender.
     * @param location The location within the field.
     * @return true if a mate has been found, false otherwise.
     */
    protected boolean isMate(Location loc){
        Field field = getField();
        if (field.getObjectAt(loc) instanceof Zebra ){
            if (((Zebra)field.getObjectAt(loc)).isMale() != isMale()){ 
                return true;
            }
        }
        return false;
    }
    
    /**
     * @returns the maximum age.
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @returns the breeding age.
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @returns the max litter size 
     * which is the maximum number of births 
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @returns the breeding probability
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @returns breeding food age
     * which is the minimum food level for a zebra to breed
     */
    protected int getBreedingFoodLevel(){
        return BREEDING_FOOD_LEVEL;
    }
}
