/**
 * Write a description of class Time here.
 *
 * @version (a version number or a date)
 */
public class Time
{
    private int time;
    
    /**
     * Constructor -  intialize the time.
     */
    public Time()
    {
        time = 0; 
    }

    /**
     * increment the time by one.
     */
    public void incrementTime(){ 
        time++; 
        if(time > 23){
            time = 0; 
        }
    } 
    
    /**
     * sets if it is night or not.
     * @returns true if the time is between 12 a.m and 8 a.m
     */
    public boolean isNight()
    {
        if (time  > 0 && time < 8){ 
            return true; 
        } 
        return false; 
    }
    
    /**
     * generate a string that states the time to be used in simulater view.
     * @returns a string stating the time.
     */
    public String generateTimeString(){ 
        String timeString = ""; 
        if (time == 0) { // 12 am 
                timeString = " time: "+ (12) + "AM"; 
        } 
        else if(time < 12) { // 1 am to 11 am 
                timeString = " time: "+ (time) + "AM"; 
        } 
        else if(time == 12) { // 12 pm
                timeString = " time: "+ (time) + "PM"; 
        } 
        else{ // 1 pm to 11 pm
                timeString = " time: "+ (time%12) + "PM"; 
        } 
        return timeString;
    }  
    
    /**
     * resets the time to 0.
     */
    public void restart(){
        time = 0; 
    } 
}
