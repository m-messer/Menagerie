import java.util.List;
/**
 * Write a description of class Grass here.
 *
 * @version (a version number or a date)
 */
public class Grass extends Plant
{
    // The age at which a grass can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a grass can live.
    private static final int MAX_AGE = 25;//25
    // The likelihood of a grass breeding.
    private static final double BREEDING_PROBABILITY = 0.05; //0.05
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // Infection probability, 
    private static final double INFECTION_PROBABILITY = 0.001; 

    /**
     * Create a new grass. A grass may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        setAge(0);
        if(randomAge) {
             setAge(getRandom().nextInt(MAX_AGE));
        }
        
        setIsInfected(getInfectionStatus());
        if(isInfected()){
            setInfectionSource(new Falon());
            System.out.println(getInfectionSource().getLifeExpectancy());
        }
    }
    
    /**
     * This is what the grass does most of the time - 
     * Sometimes it will breed or die of old age.
     * @param newgrasss A list to return newly born grasss.
     */
    public void act(List<Actor> newgrasss)
    {
        incrementAge();
        if(isActive()) {
            propagate(newgrasss);
        }
    }
   
    /**
     * creates a grass object in the given field and location
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @returns a grass object.
     */
    protected Plant propagate(Field field, Location location){
        return new Grass(false, field, location);
    }
    
    /**
     * @returns the maximum age.
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @returns the breeding age.
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @returns the max litter size 
     * which is the maximum number of births 
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @returns the breeding probability
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @returns the infection probability
     */
    protected double getInfectionProbability(){
        return INFECTION_PROBABILITY;
    }
}
