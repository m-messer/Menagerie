import java.util.List;
import java.util.Iterator;
import java.util.Random;


/**
 * Write a description of class tiger here.
 *
 * @version (a version number or a date)
 */
public class Tiger extends Animal
{
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a fox can live.
    private static final int MAX_AGE = 130; //130
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.1; //1
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single zebra. In effect, this is the
    // number of steps a tiger can go before it has to eat again.
    private static final int FOOD_VALUE = 50; //45 
    // The food level at which an animal can breed
    private static final int BREEDING_FOOD_LEVEL = FOOD_VALUE/4;
    // Maximum food value
    private static final int MAX_FOOD_VALUE = FOOD_VALUE*3;
 
    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setFoodLevel(getRandom().nextInt(FOOD_VALUE));            
            setAge(getRandom().nextInt(MAX_AGE));
        }
        else {
            setFoodLevel(FOOD_VALUE);            
            setAge(0);
        }
        setInfection(false);
        setLifeExpectancy(MAX_AGE); 
    }
    
    /**
     * This is what the tiger does most of the time: it hunts for
     * giraffe. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Actor> newtigers)
    {
        incrementAge();
        incrementHunger();
        decrementLifeExpectancy();
        if(isActive()) {
            giveBirth(newtigers);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * all adjecent live acacia is eaten, 
     * but food level remains at max food level.
     * @return Where the last food was found, or null if it no food was found.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        Location location = null; 
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Giraffe) {
                Giraffe giraffe = (Giraffe) actor;
                if(giraffe.isActive()) { 
                    giraffe.setDead();
                    if(!isInfected()){
                        setInfection(giraffe.isInfected());
                        if(isInfected()){ 
                            setInfectionSource(giraffe.getInfectionSource());
                            setLifeExpectancy((int)(getAge()*getInfectionSource().getLifeExpectancy()));
                        }
                    }
                    setFoodLevel(getFoodLevel()+FOOD_VALUE);
                    if(getFoodLevel() > MAX_FOOD_VALUE){
                        setFoodLevel(MAX_FOOD_VALUE);
                        location = where;
                    }
                }
            }
        }
        return location;
    }
    
    /**
     * creates a tiger object in the given field and location
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @returns a tiger object.
     */
    protected Animal giveBirth(Field field, Location location){
        return new Tiger(false, field, location);
    }
    
    /**
     * finds a suitable mate, 
     * who is of the same species and different gender.
     * @param location The location within the field.
     * @return true if a mate has been found, false otherwise.
     */
    protected boolean isMate(Location loc){
        Field field = getField();
        if (field.getObjectAt(loc) instanceof Tiger ){
            if (((Tiger)field.getObjectAt(loc)).isMale() != isMale()){ 
                return true;
            }
        }
        return false;
    }
     
    /**
     * @returns the maximum age.
     */
    protected int getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * @returns the breeding age.
     */
    protected int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * @returns the max litter size 
     * which is the maximum number of births 
     */
    protected int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @returns the breeding probability
     */
    protected double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @returns breeding food age
     * which is the minimum food level for a zebra to breed
     */
    protected int getBreedingFoodLevel(){
        return BREEDING_FOOD_LEVEL;
    }
}
