import java.util.List;
/**
 * Abstract class Disease - represents a disease in the predator/ prey simulation. 
 *
 * @version  2/3/2021
 */
public abstract class Disease
{
    //the lifeExpectancy of the ifected animal 
    private double infectionlifeExpectancy;

    /**
     * constructor
     */
    public Disease(){
    }
    
    /**
     * @returns life Expectancy of infected animal 
     */
    public double getLifeExpectancy(){
        return infectionlifeExpectancy;
    }
    
    /**
     * sets life Expectancy to the passed parameter. 
     * @param int representing lifeExpectancy 
     */
    public void setLifeExpectancy(double num){
        infectionlifeExpectancy = num;
    }
}
