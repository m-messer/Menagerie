import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Plant implements Actor
{
    // Whether the plant is alive or not.
    private boolean alive;
    // The age of the plant.
    private int age;
    // a boolean representing whether the plant is infected or not. 
    private boolean isInfected; 
    // represents the disease this plant is infected with. 
    private Disease infectionSource;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // A shared random number generator.  
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        age = 0;
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newplants A list to receive newly born plants.
     */
    abstract public void act(List<Actor> newplants);

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isActive()
    {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * returns the age of the plant. 
     */
    protected int getAge(){
        return age;
    }
    
    /**
     * sets the age of the plant to the passed parameter. 
     * @param int repersenting new age 
     */
    protected void setAge(int num){
        age = num;
    }
    
    /**
     * returns the maximum age a plant can live.
     */
    abstract protected int getMaxAge();
    
    /**
     * increments age by 1. 
     */
    protected void incrementAge(){
        setAge(getAge() + 1);
        if(getAge() > getMaxAge()) {
            setDead();
        }
    } 
    
    /**
     * returns the probability of which the plant is infected or not. 
     * @return double value representing the probability of the plant being infected. 
     */
    abstract protected double getInfectionProbability();
    
    /**
     * generates a random number and checks if the plant is infected or not based on the number generated. 
     * @rturns a boolean representing whether the plant is infected or not
     */
    public boolean getInfectionStatus(){ 
        if (getRandom().nextDouble() <= getInfectionProbability()) { 
            return true;
        } 
        return false; 
    } 
    
    /**
     * @rturns a boolean representing whether the plant is infected or not
     */
    public boolean isInfected(){
        return isInfected;
    }
    
    /**
     * sets the plant to infected or not based on the parameter passed. 
     */
    public void setIsInfected(boolean infection){
        isInfected = infection;
    }
    
    /**
     * returns the disease that is affecting this plant. 
     */
    public Disease getInfectionSource(){
        return infectionSource;
    }
    
    /**
     * sets infection sources to the disease passed in th eparameter. 
     * @param disease that represents source of infection. 
     */
    public void setInfectionSource(Disease source){
        infectionSource = source;
    }
    
    /**
     * @return the maximum number of births the plant can give
     */
    abstract protected int getMaxLitterSize();
    
    /**
     * @return the breeding gprobability of the plant
     */
    abstract protected double getBreedingProbability();
    
    /**
     * generate a number representing th enumber of births 
     * if it can bread. 
     * @return the number of births (may be zero). 
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= getBreedingProbability()) {
            births = getRandom().nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * @returns the afe in which an animal can breed. 
     */
    abstract protected int getBreedingAge();
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed(){
        return getAge() >= getBreedingAge();
    }
    
    /**
     * Checks wheather or not this animal is to give births at this step
     * new births will be make into free adgacent locations.
     * @param the field and the current location of the animal
     */
    abstract protected Plant propagate(Field field, Location location);
        
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void propagate(List<Actor> newPlants)
    {
        // New grasss are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newPlants.add(propagate(field, loc));
        }
    }
        
    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * returns the random number generated in this plant. 
     */
    protected Random getRandom(){
        return rand;
    }
}
