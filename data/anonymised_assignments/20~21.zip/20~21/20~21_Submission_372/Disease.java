import java.util.Random;

/**
 * A class which holds the different types of
 * diseases which are in the simulator, and 
 * the characteristics of the diseases.
 * @version 2021.01.03
 */

public class Disease
{
    // The name of the disease.
    private String name;
    // The probability of the disease affecting an animal.
    private double diseaseProbability;
    // Contains whether the disease is infection or not.
    // If a disease is infectious, it spreads between the animals closeby.
    private boolean infectiousOrNot; 
    // A random number generator to control the chance of an animal being affected.
    private Random rand = new Random();
    
    /**
     * Creatation of a disease.
     * @param name The name of the disease.
     * @param infectious True if the disease can be spread between animals, false otherwise.
     * @param probability The chance of the animal being affected.
     */
    public Disease(String name, boolean infectious, double probability)
    {
        this.name = name;
        infectiousOrNot = infectious;
        diseaseProbability = probability;
    }

    /**
     * @return True if the disease is spreadable, false otherwise
     */
    public boolean getInfectious()
    {
        return infectiousOrNot;    
    }

    /**
     * Checks if by chance the animal is going to be affected or not.
     * @return true if the animal is going to be affected, false otherwise.
     */
    public boolean animalAffectedOrNot()
    {
        if(rand.nextDouble()<diseaseProbability){
            return true;
        }
        else{
            return false;
        }
    }
}
