import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a rat.
 * Rats age, move, breed, and die.
 *
 * @version 2021.01.03
 */
public class Rat extends Animal
{
    // Characteristics shared by all rats (class variables).
    // The age at which a rat can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rat can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a rat breeding.
    private static final double BREEDING_PROBABILITY = 0.80;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a grass.
    private static final int GRASS_FOOD_VALUE = 10;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The rat's age.
    private int age;
    // The rat's food level, which is increased by eating grass.
    private int startingFoodLevel;
    // The number of steps the rat has taken
    private int numOfSteps;

    /**
     * Create a new rat. A rat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rat(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            startingFoodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            startingFoodLevel = GRASS_FOOD_VALUE;
        }
        numOfSteps = 0;
        setAgeAndFoodLevel();
    }

    /**
     * @return The age of the rat.
     */
    public int getAge()
    {
        return age;   
    }

    /**
     * @return The maximum age of the rat.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return The food level the rat has when it is born.
     */
    public int getStartingFoodLevel()
    {
        return startingFoodLevel;
    }

    /**
     * This is what the rat does most of the time: it eats the
     * grass. Sometimes it will breed or die of old age.
     * @param newRats A list to return newly born rats.
     * @param hour The current hour of the simulator.
     * @param weather The current weather status of the simulator.
     */
    public void act(List<Animal> newRats, int hour, String weather)
    {
        numOfSteps++;
        incrementAge(numOfSteps);

        if(numOfSteps%2 == 0){
            incrementHunger(weather);
        }

        // Checks if the rat has been affected by a disease.
        checkAnimalWithDisease();

        // The rat can only do something when they are not sleeping.
        // The rats are sleeping during the hour of 20 until 2
        if(hour<=20 && hour>=2){
            if(isAlive()) {
                giveBirth(newRats);   
                
                // Find grass to eat
                findGrass();

                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Check whether or not this rat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRats A list to return newly born rats.
     */
    private void giveBirth(List<Animal> newRats)
    {
        Field field = getField();

        // Gets the list of the adjacent locations
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();

            // Gets the animal at the adjacent location.
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rat) {

                // Get a list of adjacent free locations.
                List<Location> free = field.getFreeAdjacentLocations(getLocation());
                Rat rat = (Rat) animal;

                // Checks if the sex of this rat is different to the one in one of the adjacent locations
                // Only breeds if one rat is Male while the other is Female
                if(super.getSex() != rat.getSex()){
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        
                        // New rats are born into adjacent locations.
                        Location loc = free.remove(0);
                        Rat young = new Rat(false, field, loc);
                        young.setSex(rand.nextDouble());
                        newRats.add(young);
                    }
                }
            }
        }

    }

    /**
     * @return The maximum number of children this rat can have
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return The probability of the rat breeding
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * A rat can breed if it has reached the breeding age.
     * @return true if the rat can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Finds the grass for the rat to eat.
     * Checks first if the grass is fully grown and
     * is ready to be eaten. 
     */
    private void findGrass()
    {
        Location grassLocation = super.getLocation();
        if(grassLocation.isFullyGrown()){
            increaseFoodLevel(GRASS_FOOD_VALUE);
            grassLocation.grassEaten();
        }
    }
}
