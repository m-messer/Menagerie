import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Lion.
 * Lions age, move, eat deers or coyotes, and die.
 *
 * @version 2021.01.03
 */
public class Lion extends Animal
{
    // Characteristics shared by all Lions (class variables).

    // The age at which a Lion can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a Lion can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a Lion breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single coyote.
    private static final int COYOTE_FOOD_VALUE = 18;
    // The food value of a single Deer.
    private static final int DEER_FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Lion's age.
    private int age;
    // The Lion's starting food level.
    private int startingFoodLevel;
    // The number of steps the lion has taken
    int numOfSteps;

    /**
     * Create a Lion. A Lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            startingFoodLevel = rand.nextInt(DEER_FOOD_VALUE);
        }
        else {
            age = 0;
            startingFoodLevel = DEER_FOOD_VALUE;
        }
        numOfSteps = 0;
        setAgeAndFoodLevel();
    }

    /**
     * @return The age of the lion.
     */
    public int getAge()
    {
        return age;   
    }

    /**
     * @return The maximum age of the lion.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return The food level the lion has when it is born.
     */
    public int getStartingFoodLevel()
    {
        return startingFoodLevel;
    }

    /**
     * This is what the Lion does most of the time: it hunts for
     * coyotes or deers. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.
     * @param hour The current hour of the simulator.
     * @param weather The current weather status of the simulator.
     */
    public void act(List<Animal> newLions, int hour, String weather)
    {
        numOfSteps++;
        incrementAge(numOfSteps);

        if(numOfSteps%2 == 0){
            incrementHunger(weather);
        }

        // Checks if the lion has been affected by a disease.
        checkAnimalWithDisease();

        // The lion can only do something when they are not sleeping.
        // The lions are sleeping between the hours of 8 until 12
        if(hour>=12 || hour<=8){
            if(isAlive()) {
                giveBirth(newLions);            
                // Move towards a source of food if found.
                Location newLocation = findFood(weather);
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for coyotes and deers adjacent to the current location.
     * Only the first animal found is eaten.
     * @param weather The current weather status of the simulator.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(String weather)
    {
        //The lion can only find food when it is hungry(foodlevel less than 5) and the weather is clear.
        if((getCurrentFoodLevel()<5) && !("Foggy".equals(weather))){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                
                // Checks which animal is found in the neighbouring locations.
                if(animal instanceof Coyote) {
                    Coyote coyote = (Coyote) animal;
                    if(coyote.isAlive()) { 
                        coyote.setDead();
                        increaseFoodLevel(COYOTE_FOOD_VALUE);
                        return where;
                    }
                }

                else if(animal instanceof Deer) {
                    Deer deer = (Deer) animal;
                    if(deer.isAlive()) {
                        deer.setDead();
                        increaseFoodLevel(DEER_FOOD_VALUE);
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    private void giveBirth(List<Animal> newLions)
    {
        Field field = getField();

        // Get a list of adjacent locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();

            // Gets the animals at the adjacent location.
            Object animal = field.getObjectAt(where);
            if(animal instanceof Lion) {

                // Get a list of adjacent free locations.
                List<Location> free = field.getFreeAdjacentLocations(getLocation());
                Lion lion = (Lion) animal;

                // Checks if the sex of this lion is different to the one in one of the adjacent locations
                // Only breeds if one lion is Male while the other is Female             
                if(super.getSex() != lion.getSex()){
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {

                        // New lions are born into adjacent locations.
                        Location loc = free.remove(0);
                        Lion young = new Lion(false, field, loc);
                        young.setSex(rand.nextDouble());
                        newLions.add(young);
                    }
                }
            }
        }
    }

    /**
     * @return The maximum number of children this lion can have
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return The probability of the lion breeding
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * A lion can breed if it has reached the breeding age.
     * @return true if the lion can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
