import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.01.03
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // A shared random number generator to control breeding and spread of a disease.
    private static final Random rand = Randomizer.getRandom();    
    // The sex of the animal
    private boolean isFemale;
    // The age of the animal
    private int age;
    // The animal's current food level..
    private int currentFoodLevel;
    // Number of steps in the rainy weather. More rain means more water for the animals to drink from so the hunger decreases more slowly.
    private int rainyNumOfSteps;
    // Number that holds the value of the number of steps the animal has been affected of some disease.
    private int numOfStepsAffected;
    // Checks if the animal has been affected by a disease or not.
    private boolean animalAffectedOrNot;
    // Checks if the disease is spreadable.
    private boolean infectiousDisease;
    // Checks if the animal has already spread the disease once.
    private boolean alreadySpreadADisease;
    /**
     * Create a new animal at location in field, setting 
     * some of the characteristics.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);

        animalAffectedOrNot = false;
        alreadySpreadADisease = false;
        rainyNumOfSteps = 0;
        numOfStepsAffected =0;
    }

    /**
     * Sets the age and the starting food level of an animal.
     */
    public void setAgeAndFoodLevel()
    {
        age = getAge();
        currentFoodLevel = getStartingFoodLevel();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param hour The current hour of the simulator.
     * @param weather The current weather status of the simulator.
     */
    abstract public void act(List<Animal> newAnimals, int hour, String weather);

    /**
     * @return the age of the animal
     */
    public abstract int getAge();

    /**
     * @return The maximum age the specific animal can get to.
     */
    public abstract int getMaxAge();

    /**
     * @return The starting food level of the animal.
     */
    public abstract int getStartingFoodLevel();

    /**
     * Make this Animal more hungry. This could result in the animal's death.
     * @param weather The current weather of the Simulator, which affects hunger.
     */
    protected void incrementHunger(String weather)
    {
        //Checks if the weather is rainy so decreases the hunger after every 2 steps in the rainy weather.
        if("Rainy".equals(weather)){
            rainyNumOfSteps++;
            if(rainyNumOfSteps%2 == 0){
                currentFoodLevel--;
                if(currentFoodLevel <= 0) {
                    setDead();
                }            
            }
        }
        else{
            currentFoodLevel--;
            if(currentFoodLevel <= 0) {
                setDead();
            }
        }
    }

    /**
     * @return The current food level of the animal.
     */
    protected int getCurrentFoodLevel()
    {
        return currentFoodLevel;   
    }

    /**
     * Increases the food level of the animal by the help of the parameter.
     * @param numToIncreaseFoodLevelBy The number to increase the food level by.
     */
    protected void increaseFoodLevel(int numToIncreaseFoodLevelBy)    
    {
        currentFoodLevel += numToIncreaseFoodLevelBy;
    }

    /**
     * Increase the age. This could result in the Animal's death.
     * @param step The number of steps this animal has lived upto yet.
     */
    protected void incrementAge(int step)
    {
        if(step%5==0){ //increases age after every 5 steps
            age++;
            if(age > getMaxAge()) {
                setDead();
            }        
        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * @return the probability of the animal breeding.
     */
    public abstract double getBreedingProbability();

    /**
     * @return True if the animal is above the breeding age, false otherwise.
     */
    public abstract boolean canBreed();

    /**
     * @return The maximum number of children the animal can have.
     */
    public abstract int getMaxLitterSize();

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Sets the sex of the animal by checking the probability.
     * Proability is a 50% chance of a male and a female.
     * @param probability The chance of the animal being a male or a female.
     */
    protected void setSex(double probability)
    {
        if(probability<0.5){
            isFemale = true;
        }
        else{
            isFemale = false;
        }
    }

    /**
     * @return The sex of the animal
     */
    protected boolean getSex()
    {
        return isFemale;
    }

    /**
     * Infects the animal with the disease and sets the infectious to true if the disease is spreadable.
     * @param InfectiousOrNot True if the disease is spreadable, false otherwise.
     */
    protected void affectAnimal(Boolean infectiousOrNot)
    {
        animalAffectedOrNot=true;
        if(infectiousOrNot){
            infectiousDisease = true;   
        }
    }

    /**
     * @return True if the animal has been affected, false otherwise.
     */
    protected boolean getAnimalAffectedOrNot()
    {
        return animalAffectedOrNot;
    }

    /**
     * @return True if the disease is spreadable, false otherwise.
     */
    protected boolean getInfectiousDisease()
    {
        return infectiousDisease;
    }

    /**
     * Checks if the animal has been affected by a disease.
     * Checks if the disease is infectious, and then proceeds to spread it.
     * 
     * If the animal has been alive for more than 50 steps with the disease
     * affecting it, there would be a 50% of the animal dying.
     */
    protected void checkAnimalWithDisease()
    {
        if(animalAffectedOrNot){
            numOfStepsAffected++;
            if(infectiousDisease && !alreadySpreadADisease){
                hasInfectiousDisease();
                spreadDisease();
            }

            if(numOfStepsAffected>50){
                Random rand = Randomizer.getRandom();
                if(rand.nextDouble() < 0.5){
                    setDead();
                }
            }
        }
    }

    /**
     * Spreads the disease onto nearby animals.
     */
    protected void spreadDisease()
    {
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if(object instanceof Animal) {
                Animal animal = (Animal) object;
                if(!animal.getAnimalAffectedOrNot()){
                    animal.affectAnimal(getInfectiousDisease());
                }
            }
        }
    }

    /**
     * @return True if the animal has already spread the disease once, False otherwise.
     */
    protected boolean getAlreadySpread()
    {
        return alreadySpreadADisease;
    }

    /**
     * @return True if the disease is infectious, false otherwise.
     */
    protected void hasInfectiousDisease()
    {
        alreadySpreadADisease = true;
    }
}
