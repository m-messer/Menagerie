import java.util.Random;
import java.util.HashMap;

/**
 * A simple weather simulator which changes
 * between three different types of weathers,
 * sunny, rainy and foggy.
 * @version 2021.01.03
 */

public class Weather
{
    // Integer as key to hold the whether type in the hasmap.
    private int weatherType;
    // A random number generator to toggle between the weathers.
    private Random rand = new Random();
    // Hashmap which contains the whether types and its keys.
    private HashMap<Integer, String> weatherMap = new HashMap<>();
    // A number that holds the number of steps of a weather type. 
    private int stepsForWeather;

    /**
     * Creats the weather, putting different keys and whether types
     * in the hasmap.
     */
    public Weather()
    {
        weatherMap.put(1, "Rainy");
        weatherMap.put(2, "Sunny");
        weatherMap.put(3, "Foggy");
        stepsForWeather = 0;
    }

    /**
     * @return The type of weather currently.
     */
    public String getWeather()
    {
        return weatherMap.get(weatherType);
    }

    /**
     * Changes the type weather randomely.
     * One type of weather stays for 10 steps.
     */
    public void setWeather()
    {
        stepsForWeather++;
        if(stepsForWeather%10==0){
            weatherType = rand.nextInt(3) + 1;
        }
    }
}
