import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a sloth.
 * Sloths age, move, breed, eat plants, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Sloth extends Animal
{
    // Characteristics shared by all sloths (class variables).

    // The age at which a sloth can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a sloth can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a sloth breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births a sloth can have.
    private static final int MAX_LITTER_SIZE = 4;
    // The default range within which the sloth can act.
    private static final int DEFAULT_EFFECTIVE_RANGE = 1;
    // The maximum food the sloth can have.
    private static final int MAX_FOOD_VALUE = 20;
    // The food value of a single plant. In effect, this is the
    // number of steps a sloth can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 12;
    // The maximum cooldown for breeding, after which breeding is possible.
    private static final int MAX_BREEDING_COOLDOWN = 3;
    // Whether the sloth is active during the day.
    private static final boolean ACTIVE_IN_DAY = true;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The sloth's age.
    private int age;
    // The sloth's food level, which is increased by eating plants.
    private int foodLevel;
    // How long before a sloth can breed again.
    private int breedingCooldown;
    // The range within which the sloth can act.
    private int effectiveRange;
    // The weather currently.
    private Weather weather;

    /**
     * Create a sloth. A sloth may be created as a new born (age zero,
     * not hungry and max breeding cooldown) or with a random age, food level 
     * and breeding cooldown.
     * @param randomAge If true, the sloth will have a random age, hunger level and
     * breeding cooldown.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param weather The current weather.
     */
    public Sloth(boolean random, Field field, Location location, Weather weather)
    {
        super(field, location);
        this.weather = weather;
        effectiveRange = DEFAULT_EFFECTIVE_RANGE;
        if(random) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_VALUE);
            breedingCooldown = rand.nextInt(MAX_BREEDING_COOLDOWN);
        }
        else{
            age = 0;
            foodLevel = MAX_FOOD_VALUE;
            breedingCooldown = MAX_BREEDING_COOLDOWN;
        }
    }

    /**
     * This is what the sloth does most of the time - it finds and eats plants.
     * In the process, it might breed, die of hunger,
     * die of old age, or die of overcrowding.
     * @param newSloths A list to return newly born sloths.
     */
    public void act(List<Animal> newSloths)
    {
        if(isAlive()){
            incrementAge();
            incrementHunger();
            if(isAlive() && weather.isDay() == ACTIVE_IN_DAY) {          
                Location newLocation;
                // Will breed and find food if animals effective range is greater than 0.
                if (effectiveRange <= 0){
                    newLocation = getLocation();
                }else{
                    mate(newSloths); 
                    // Move towards a source of food if found.
                    newLocation = findFood();
                }
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), effectiveRange);
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the sloth's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this sloth more hungry. This could result in the sloth's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), effectiveRange);

        // Find adjacent plants.
        Iterator<Location> plantLocationIt = adjacent.iterator();
        while(plantLocationIt.hasNext()) {
            Location where = plantLocationIt.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant) {
                Plant aPlant = (Plant) plant;
                if(aPlant.isAlive() && aPlant.isEdible()) { 
                    aPlant.setDead();
                    eat(PLANT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Eats plant and food value is added.
     * @param food The food level of the plant.
     */
    private void eat (int food)
    {
        foodLevel = foodLevel + food;
        // The food value cannot go over max food value.
        if(foodLevel > MAX_FOOD_VALUE){
            foodLevel = MAX_FOOD_VALUE;
        }
    }

    /**
     * Check whether or not this sloth is to give birth at this step.
     * New births will be made into free adjacent locations within the effective range.
     * @param newSloths A list to return newly born sloths.
     */
    private void giveBirth(List<Animal> newSloths)
    {
        // New sloths are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), effectiveRange);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Sloth young = new Sloth(false, field, loc, weather);
            newSloths.add(young);
        }
    }

    /**
     * Checks adjacent sloths to mate with the opposite gender within the effective range.
     * @param newSloths A list to return newly born sloths.
     */
    private void mate(List<Animal> newSloths){
        Field field = getField();
        breedingCooldown--;
        List<Location> locations = field.adjacentLocations(getLocation(), effectiveRange);
        for(Location location : locations){
            Object animal = field.getObjectAt(location);
            if (animal instanceof Sloth){
                Sloth sloth = (Sloth) animal;
                // Checks opposite gender.
                if(sloth.isMale() != this.isMale()){
                    giveBirth(newSloths);
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            breedingCooldown = MAX_BREEDING_COOLDOWN;
        }
        return births;
    }

    /**
     * A sloth can breed if it has reached the breeding age and has 
     * reached its breeding cooldown.
     * @return true if the sloth can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && breedingCooldown <= 0;
    }

    /**
     * Sets effective range on clear weather.
     */
    public void clearDay()
    {
        effectiveRange = DEFAULT_EFFECTIVE_RANGE;
    }

    /**
     * Sets effective range on foggy weather.
     */
    public void fog()
    {
        effectiveRange = 0;
    }
}