import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a squirrel.
 * Squirrels age, move, breed, eat plants, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Squirrel extends Animal
{
    // Characteristics shared by all squirrels (class variables).

    // The age at which a squirrel can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a squirrel can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a squirrel breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births a squirrel can have.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum food the squirrel can have.
    private static final int MAX_FOOD_VALUE = 10;
    // The food value of a single plant.
    private static final int PLANT_FOOD_VALUE = 6;
    // The maximum cooldown for breeding, after which breeding is possible.
    private static final int MAX_BREEDING_COOLDOWN = 3;
    // The default range within which the squirrel can act.
    private static final int DEFAULT_EFFECTIVE_RANGE = 1;
    // Whether the squirrel is active during the day.
    private static final boolean ACTIVE_IN_DAY = true;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The squirrel's age.
    private int age;
    // The squirrel's food level, which is increased by eating plants.
    private int foodLevel;
    // How long before a squirrel can breed again.
    private int breedingCooldown;
    // The range within which the squirrel can act.
    private int effectiveRange;
    // The weather currently.
    private Weather weather;

    /**
     * Create a squirrel. A squirrel may be created as a new born (age zero,
     * not hungry and max breeding cooldown) or with a random age, food level 
     * and breeding cooldown.
     * @param random If true, the squirrel will have a random age,hunger level and 
     * breeding cooldown.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param weather The current weather.
     */
    public Squirrel(boolean random, Field field, Location location, Weather weather)
    {
        super(field, location);
        this.weather = weather;
        effectiveRange = DEFAULT_EFFECTIVE_RANGE;
        if(random) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_VALUE);
            breedingCooldown = rand.nextInt(MAX_BREEDING_COOLDOWN);
        }
        else{
            age = 0;
            foodLevel = MAX_FOOD_VALUE;
            breedingCooldown = MAX_BREEDING_COOLDOWN;
        }
    }

    /**
     * This is what the squirrel does most of the time - it finds and eats plants.
     * In the process, it might breed, die of hunger,
     * die of old age, or die of overcrowding.
     * @param newSquirrels A list to return newly born squirrels.
     */
    public void act(List<Animal> newSquirrels)
    {
        if(isAlive()){
            incrementAge();
            incrementHunger();
            if(isAlive() && weather.isDay() == ACTIVE_IN_DAY) {
                Location newLocation;
                // Will breed and find food if animals effective range is greater than 0.
                if (effectiveRange <= 0){
                    newLocation = getLocation();
                }else{
                    mate(newSquirrels); 
                    // Move towards a source of food if found.
                    newLocation = findFood();
                }
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), effectiveRange);
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the squirrel's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this squirrel more hungry. This could result in the squirrel's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), effectiveRange);

        // Find adjacent plants.
        Iterator<Location> plantLocationIt = adjacent.iterator();
        while(plantLocationIt.hasNext()) {
            Location where = plantLocationIt.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant) {
                Plant aPlant = (Plant) plant;
                if(aPlant.isAlive() && aPlant.isEdible()) { 
                    aPlant.setDead();
                    eat(PLANT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Eats plant and food value is added.
     * @param food The food level of the plant.
     */
    private void eat (int food)
    {
        foodLevel = foodLevel + food;
        // The food value cannot go over max food value.
        if(foodLevel > MAX_FOOD_VALUE){
            foodLevel = MAX_FOOD_VALUE;
        }
    }

    /**
     * Check whether or not this squirrel is to give birth at this step.
     * New births will be made into free adjacent locations within the effective range.
     * @param newSquirrels A list to return newly born squirrels.
     */
    private void giveBirth(List<Animal> newSquirrels)
    {
        // New squirrels are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), effectiveRange);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Squirrel young = new Squirrel(false, field, loc, weather);
            newSquirrels.add(young);
        }
    }

    /**
     * Checks adjacent squirrels to mate with the opposite gender within the effective range.
     * @param newSquirrels A list to return newly born squirrels.
     */
    private void mate(List<Animal> newSquirrels){
        Field field = getField();
        breedingCooldown--;
        List<Location> locations = field.adjacentLocations(getLocation(), effectiveRange);
        for(Location location : locations){
            Object animal = field.getObjectAt(location);
            if (animal instanceof Squirrel){
                Squirrel squirrel = (Squirrel) animal;
                // Checks opposite gender.
                if(squirrel.isMale() != this.isMale()){
                    giveBirth(newSquirrels);
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            breedingCooldown = MAX_BREEDING_COOLDOWN;
        }
        return births;
    }

    /**
     * A squirrel can breed if it has reached the breeding age and has 
     * reached its breeding cooldown.
     * @return true if the squirrel can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && breedingCooldown <= 0;
    }

    /**
     * Sets effective range on clear weather.
     */
    public void clearDay()
    {
        effectiveRange = DEFAULT_EFFECTIVE_RANGE;
    }

    /**
     * Sets effective range on foggy weather.
     */
    public void fog()
    {
        effectiveRange = 0;
    }
}
