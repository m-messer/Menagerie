import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * Determines the effect of a disease on an animal.
 * There is only one type of disease.
 * The disease can spread, kill, or be cured.
 * The disease does its effect after every step of the simulator class.
 *
 * @date 02/03/2021
 */
public class Disease
{
    // The probability an animal will get the disease.
    private static final double ANIMAL_DISEASE_PROBABILITY = 0.01;
    // The probability an animal will spread the disease. 
    private static final double ANIMAL_DISEASE_SPREAD_PROBABILITY = 0.02;
    // The probability an animal will die by the disease.
    private static final double ANIMAL_DEATH_PROBABILITY = 0.01;
    // The probability an animal will be cured of the disease.
    private static final double ANIMAL_CURE_PROBABILITY = 0.05;
    // The range at which an animal will spread the disease.
    private static final int ANIMAL_DISEASE_RANGE = 1;
    // A shared random number generator to control probabilities.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Does nothing at the moment, since almost everything here is based on random probability.
     */
    public Disease()
    {
    }

    /**
     * Check first if animal is alive, then
     * Do probabilities for animal getting a disease,
     * animal getting cured from a disease,
     * animal spreading disease to other animals,
     * and animal dying from a disease.
     */
    public void setAnimalEffect(Animal animal)
    {
        if(animal.isAlive()){
            
            double randomNumber = rand.nextDouble();
            
            if(!animal.hasDisease() && randomNumber < ANIMAL_DISEASE_PROBABILITY){
                animal.setDisease();
            }
            
            if(animal.hasDisease()){
                Field field = animal.getField();
                List<Location> adjacent = field.adjacentLocations(animal.getLocation(), ANIMAL_DISEASE_RANGE);
                Iterator<Location> animalLocationIt = adjacent.iterator();
                while(animalLocationIt.hasNext()) {
                    randomNumber = rand.nextDouble();
                    Location where = animalLocationIt.next();
                    Object adjacentItem = field.getObjectAt(where);
                    if(adjacentItem instanceof Animal && randomNumber < ANIMAL_DISEASE_SPREAD_PROBABILITY){
                        Animal adjacentAnimal = (Animal) adjacentItem;
                        adjacentAnimal.setDisease();
                    }
                }
                
                if(randomNumber < ANIMAL_CURE_PROBABILITY){
                    animal.cureDisease();
                }
                
                randomNumber = rand.nextDouble();
                
                if(randomNumber < ANIMAL_DEATH_PROBABILITY && animal.hasDisease()){
                    animal.setDead();
                }
            }
        }
    }
}