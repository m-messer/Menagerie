import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a jaguar.
 * Jaguars age, move, breed, eat sloths and squirrels, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Jaguar extends Animal
{
    // Characteristics shared by all jaguars (class variables).

    // The age at which a jaguar can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a jaguar can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a jaguar breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births a jaguar can have.
    private static final int MAX_LITTER_SIZE = 2;
    // The maximum food the jaguar can have.
    private static final int MAX_FOOD_VALUE = 15;
    // The food value of a single sloth.
    private static final int SLOTH_FOOD_VALUE = 9;
    // The food value of a single squirrel.
    private static final int SQUIRREL_FOOD_VALUE = 8;
    // The maximum cooldown for breeding, after which breeding is possible.
    private static final int MAX_BREEDING_COOLDOWN = 5;
    // The default range within which the jaguar can act.
    private static final int DEFAULT_EFFECTIVE_RANGE = 1;
    // Whether the jaguar is active during the day.
    private static final boolean ACTIVE_IN_DAY = false;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The jaguar's age.
    private int age;
    // The jaguar's food level, which is increased by eating animals.
    private int foodLevel;
    // How long before a jaguar can breed again.
    private int breedingCooldown;
    // The range within which the jaguar can act.
    private int effectiveRange;
    // The weather currently.
    private Weather weather;

    /**
     * Create a jaguar. A jaguar can be created as a new born (age zero
     * not hungry and max breeding cooldown) or with a random age, food level 
     * and breeding cooldown.
     * @param randomAge If true, the jaguar will have random age, hunger level and
     * breeding cooldown.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param weather The current weather.
     */
    public Jaguar(boolean random, Field field, Location location, Weather weather)
    {
        super(field, location);
        this.weather = weather;
        effectiveRange = DEFAULT_EFFECTIVE_RANGE;
        if(random) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_VALUE);
            breedingCooldown = rand.nextInt(MAX_BREEDING_COOLDOWN);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_VALUE;
            breedingCooldown = MAX_BREEDING_COOLDOWN;
        }

    }

    /**
     * This is what the jaguar does most of the time: it hunts for
     * eatable animals. In the process, it might breed, die of hunger,
     * die of old age, or die of overcrowding.
     * @param newJaguars A list to return newly born jaguars.
     */
    public void act(List<Animal> newJaguars)
    {
        if(isAlive()){
            incrementAge();
            incrementHunger();
            if(isAlive() && weather.isDay() == ACTIVE_IN_DAY) {
                Location newLocation;
                // Will breed and find food if animals effective range is greater than 0.
                if (effectiveRange <= 0){
                    newLocation = getLocation();
                }else{
                    mate(newJaguars); 
                    // Move towards a source of food if found.
                    newLocation = findFood();
                }
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation(), effectiveRange);
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the jaguar's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this jaguar more hungry. This could result in the jaguar's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for eatable animals adjacent to the current location.
     * Only the first live animal is eaten with a preference of animals with higher
     * food values.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation(), effectiveRange);

        // Find adjacent sloths.
        Iterator<Location> slothLocationIt = adjacent.iterator();
        while(slothLocationIt.hasNext()) {
            Location where = slothLocationIt.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Sloth) {
                Sloth sloth = (Sloth) animal;
                if(sloth.isAlive()) { 
                    sloth.setDead();
                    eat(SLOTH_FOOD_VALUE);
                    return where;
                }
            }
        }

        // Find adjacent squirrels.
        Iterator<Location> squirrelLocationIt = adjacent.iterator();
        while(squirrelLocationIt.hasNext()){
            Location where = squirrelLocationIt.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel){
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    squirrel.setDead();
                    eat(SQUIRREL_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Eats eatable animal and food value is added.
     * @param food The food level of the eatable animal.
     */
    private void eat (int food)
    {
        foodLevel = foodLevel + food;
        // The food value cannot go over max food value.
        if(foodLevel > MAX_FOOD_VALUE){
            foodLevel = MAX_FOOD_VALUE;
        }
    }

    /**
     * Check whether or not this jaguar is to give birth at this step.
     * New births will be made into free adjacent locations within the effective range.
     * @param newJaguars A list to return newly born jaguars.
     */
    private void giveBirth(List<Animal> newJaguars)
    {
        // New jaguars are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), effectiveRange);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Jaguar young = new Jaguar(false, field, loc, weather);
            newJaguars.add(young);
        }
    }

    /**
     * Checks adjacent jaguars to mate with the opposite gender within the effective range.
     * @param newJaguars A list to return newly born jaguars.
     */
    private void mate(List<Animal> newJaguars){
        Field field = getField();
        breedingCooldown--;
        List<Location> locations = field.adjacentLocations(getLocation(), effectiveRange);
        for(Location location : locations){
            Object animal = field.getObjectAt(location);
            if (animal instanceof Jaguar){
                Jaguar jaguar = (Jaguar) animal;
                // Checks opposite gender.
                if(jaguar.isMale() != this.isMale()){
                    giveBirth(newJaguars);
                }
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            breedingCooldown = MAX_BREEDING_COOLDOWN;
        }
        return births;
    }

    /**
     * A jaguar can breed if it has reached the breeding age and has 
     * reached its breeding cooldown.
     * @return true if jaguar can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE && breedingCooldown <= 0;
    }

    /**
     * Sets effective range on clear weather.
     */
    public void clearDay()
    {
        effectiveRange = DEFAULT_EFFECTIVE_RANGE;
    }

    /**
     * Sets effective range on foggy weather.
     */
    public void fog()
    {
        effectiveRange = 0;
    }
}