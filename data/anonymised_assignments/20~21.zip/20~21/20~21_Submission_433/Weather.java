import java.util.Random;
/**
 * Determines the weather for the current day,
 * which has an effect on plants and animals.
 * Each day is half a step of the simulator class.
 * Has season, and each is 50 steps.
 * Each year is 200 steps.
 *
 * @date 02/03/2021
 */
public class Weather
{
    // The starting day or night.
    private static final boolean DEFAULT_DAY = true;
    // The starting rainfall. Has to be false if DEFAULT_FOG is true.
    private static final boolean DEFAULT_RAIN = false;
    // the starting fog. Has to be false if DEFAULT_RAIN is true.
    private static final boolean DEFAULT_FOG = false;
    // A shared random number generator to control weather conditions.
    private static final Random rand = Randomizer.getRandom();
    
    // Whether it is day or night.
    private boolean day;
    // Whether it is raining.
    private boolean rain;
    // Whether it is a fog.
    private boolean fog;

    /**
     * Set starting weather conditions.
     */
    public Weather()
    {
        day = DEFAULT_DAY;
        rain = DEFAULT_RAIN;
        fog = DEFAULT_FOG;
    }

    /**
     * Check for new day, so that new weather conditions apply.
     * Check which season it is, and do conditions accordingly.
     */
    public void newDay(int step)
    {
        day = !day;
        int value = step % 200;
        if(day){
            double randomNumber = rand.nextDouble();
            if(value < 50){
                spring(randomNumber);
            }else if(value < 100){
                summer(randomNumber);
            }else if(value < 150){
                autumn(randomNumber);
            }else{
                winter(randomNumber);
            }
        }
    }

    /**
     * Weather conditions in spring.
     */
    private void spring(double randomNumber)
    {
        if(randomNumber < 0.1){
            fog = true;
            rain = false;
        }else if(randomNumber < 0.5){
            fog = false;
            rain = true;
        }else{
            fog = false;
            rain = false;
        }
    }

    /**
     * Weather conditions in summer.
     */
    private void summer(double randomNumber)
    {
        if(randomNumber < 0.1){
            fog = true;
            rain = false;
        }else if(randomNumber < 0.3){
            fog = false;
            rain = true;
        }else{
            fog = false;
            rain = false;
        }
    }

    /**
     * Weather conditions in autumn.
     */
    private void autumn(double randomNumber)
    {
        if(randomNumber < 0.3){
            fog = true;
            rain = false;
        }else if(randomNumber < 0.7){
            fog = false;
            rain = true;
        }else{
            fog = false;
            rain = false;
        }
    }

    /**
     * Weather conditions in winter.
     */
    private void winter(double randomNumber)
    {
        if(randomNumber < 0.3){
            fog = true;
            rain = false;
        }else if(randomNumber < 0.6){
            fog = false;
            rain = true;
        }else{
            fog = false;
            rain = false;
        }
    }

    /**
     * Set the effect the weather will have on the animal input.
     */
    public void setAnimalEffect(Animal animal)
    {
        if (fog){
            animal.fog();
        }else{
            animal.clearDay();
        }
    }

    /**
     * Set the effect the weather will have on the plant input.
     */
    public void setPlantEffect(Plant plant)
    {
        if (rain){
            plant.rain();
        }else{
            plant.clearDay();
        }
    }

    /**
     * Rest weather back to starting conditions.
     */
    public void reset(){
        day = DEFAULT_DAY;
        rain = DEFAULT_RAIN;
        fog = DEFAULT_FOG;
    }

    /**
     * Check for day.
     * @return true if it's day, false if night.
     */
    public boolean isDay(){
        return day;
    }
}