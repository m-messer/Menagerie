import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a jaguar.
 * Jaguars age, move, breed, eat Monkeys & Sloths, and die.
 *
 * @version 03.03.2021
 */
public class Jaguar extends Animal
{
    // Characteristics shared by all jaguars (class variables).

    // The age at which a jaguar can start to breed.
    private static final int BREEDING_AGE = 10;

    // The age to which a jaguar can live.
    private static final int MAX_AGE = 150;

    // The likelihood of a jaguar breeding.
    private static final double BREEDING_PROBABILITY = 0.23;//23

    // The maximum number of births.;
    private static final int MAX_LITTER_SIZE = 5;

    // The food value of a single Monkey. In effect, this is the
    // number of steps a jaguar can go before it has to eat again.
    private static final int ANIMAL_FOOD_VALUE = 18;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The jaguar's age.
    private int age;

    //The gender value of a jaguar (true = male, false = female)
    private boolean gender;

    // The jaguar's food level, which is increased by eating Monkeys and Sloths.
    private int foodLevel;

    /**
     * Create a jaguar. A jaguar can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the jaguar will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Jaguar(boolean randomAge, Field field, Location location)
    {
        super(true, field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ANIMAL_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ANIMAL_FOOD_VALUE;
        }
    }

    /**
     * This is what the jaguar does most of the time: it hunts for
     * Monkeys. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newJaguar A list to return newly born jaguars.
     * @param time The time of day.
     * @param weather The current weather type.
     */
    public void act(List<Organism> newJaguar, boolean time, int weather)
    {
        double breedingProbability = BREEDING_PROBABILITY;
        age = incrementAge(MAX_AGE, age);
        foodLevel = incrementHunger(foodLevel);
        diseaseKill();
        lightningKill(weather);
        if (time == false){
            if(isAlive()) {
                findPartner(null, null, null, null, newJaguar, foodLevel, ANIMAL_FOOD_VALUE, age, BREEDING_AGE, breedingProbability, MAX_LITTER_SIZE);   
                // Move towards a source of food if found.
                Location newLocation = findFood();
                //System.out.println("jag foodLevel: " + foodLevel);
                //System.out.println("jag ANIMAL_FOOD_VALUE: " + ANIMAL_FOOD_VALUE);
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                findNewLocation(newLocation);
            }
        }
    }

    /**
     * Look for Monkeys and Sloths adjacent to the current location.
     * Only the first live Monkey or Sloth is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Monkey) {
                Monkey monkey = (Monkey) organism;
                if(monkey.isAlive()) { 
                    monkey.setDead();
                    foodLevel = ANIMAL_FOOD_VALUE;
                    return where;
                }
            }
            else if(organism instanceof Sloth) {
                Sloth sloth = (Sloth) organism;
                if(sloth.isAlive()) { 
                    sloth.setDead();
                    foodLevel = ANIMAL_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
