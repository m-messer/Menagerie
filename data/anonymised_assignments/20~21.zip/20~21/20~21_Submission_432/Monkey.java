import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a monkey.
 * Monkeys age, move, breed, eat Plants and die.
 *
 * @version 03.03.2021
 */
public class Monkey extends Animal
{
    // Characteristics shared by all monkeys (class variables).
    // The age at which a monkey can start to breed.
    private static final int BREEDING_AGE = 5;

    // The age to which a monkey can live.
    private static final int MAX_AGE = 100;

    // The likelihood of a monkey breeding.
    private static final double BREEDING_PROBABILITY = 0.43;//43

    // The maximum number of births..
    private static final int MAX_LITTER_SIZE = 15;

    //The food value of a single plant. In effect, this is the
    // number of steps a monkey can go before it has to eat again.
    private static final int ANIMAL_FOOD_VALUE = 12;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    //The gender value of a monkey (true = male, false = female)
    private boolean gender;

    // The monkey's age.
    private int age;

    private int foodLevel;

    /**
     * Create a new monkey. A monkey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the monkey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Monkey(boolean randomAge, Field field, Location location)
    {
        super(true, field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ANIMAL_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = ANIMAL_FOOD_VALUE;
        } 
    }

    /**
     * This is what the monkey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMonkeys A list to return newly born monkeys.
     * @param time The time of day.
     * @param weather The current weather type.
     */
    public void act(List<Organism> newMonkey, boolean time, int weather)
    {
        double breedingProbability = BREEDING_PROBABILITY;
        age = incrementAge(MAX_AGE, age);
        foodLevel = incrementHunger(foodLevel);
        diseaseKill();
        lightningKill(weather);
        if (time == true){
            if(isAlive()) {
                findPartner(null, null, newMonkey, null, null, foodLevel, ANIMAL_FOOD_VALUE, age, BREEDING_AGE, breedingProbability, MAX_LITTER_SIZE);            
                // Try to move into a free location.
                //Location newLocation = findFood(foodLevel, ANIMAL_FOOD_VALUE);
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                findNewLocation(newLocation);
            }
        }
    }

    /**
     * Look for Plants adjacent to the current location.
     * Only the first live Plants is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Plant) {
                Plant plant = (Plant) organism;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = ANIMAL_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
