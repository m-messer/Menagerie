import java.util.List;
import java.util.Random;

/**
 * Write a description of class Plant here.
 *
 * @version 03.03.2021
 */
public class Plant extends Organism
{
    // instance variables - replace the example below with your own
    private int age;

    // The age at which a plant can start to breed.
    private static final int BREEDING_AGE = 0;

    // The age to which a plant can live.
    private static final int MAX_AGE = 100;

    // The likelihood of a plant breeding.
    private static final double BREEDING_PROBABILITY = 0.7;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Plant
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
    }

    /**
     * This is what the plant does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPlants A list to return newly born sloths.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public void act(List<Organism> newPlants, boolean time, int weather)
    {
        age = incrementAge(MAX_AGE, age);
        if(isAlive()) {
            if (weather != 0){    
                giveBirth(newPlants);
            }
        }

    }

    /**
     * Increase the age.
     * This could result in the plant's death.
     */
    /*private void incrementAge()
    {
    age++;
    if(age > MAX_AGE) {
    setDead();
    }
    }*/

    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlant A list to return newly born plants.
     */
    private void giveBirth(List<Organism> newPlant)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc); 
            newPlant.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
