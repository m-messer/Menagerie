import java.util.*;

/**
 * Write a description of class Plant here.
 *
 * @version (a version number or a date)
 */
public abstract class Plant
{
    //Whether the plant is alive or eaten
    private boolean alive;
    //Plant's field
    private Field field;
    //Plant's location
    private Location location;

    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Location location)
    {
       alive = true;
       this.field = field;
       setLocation(location);
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    //Makes the plant 'do' plant things
    abstract public void act(List<Plant> newPlants);
    
    //Returns if the plant is alive
    protected boolean isAlive()
    {
        return alive;
    }
    
    //Removes plant from the field as it is eaten
     protected void setEatenOrDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    //Retrieve location
     protected Location getLocation()
    {
        return location;
    }
    
  
    
    //Retrieve field
    protected Field getField()
    {
        return field;
    }
}
