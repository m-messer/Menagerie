import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //Animal's sex
    private boolean isMale;
    //Is the animal infected?
    protected boolean isInfected;
    
    
    private static final Random rand = Randomizer.getRandom();

    protected int step = 0;
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, boolean isMale, boolean isInfected)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.isMale = isMale;
        this.isInfected = isInfected;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    public boolean makeGender()
    {
        double genderDecider = rand.nextDouble();
       
        return genderDecider < 0.5; 
    }
    
    public boolean getGender()
    {
        return isMale;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    //This method will be executed and randomly infect (or not infect) animals
    protected void infectAnimals()
    {
        Random rand = new Random();
        Random rand2 = new Random();
        Random rand3 = new Random();
        
        List<Location> locs = field.adjacentLocations(getLocation());
        isInfected = (rand.nextDouble() < 0.001);
        
        if(isInfected)
        {
          
    
            for(int count = 0; count < locs.size(); count++)
            {
                Object o = field.getObjectAt(locs.get(count));
                
                if(o instanceof Squirrel
                || o instanceof Hare
                || o instanceof Wolf
                || o instanceof Badger
                || o instanceof Rodent) 
                {
                    Animal ani = (Animal) o;
                    
                    if (rand3.nextDouble() < 0.1 ) {ani.isInfected = true;} //Chance to infect nearby animals
                   
                }
            }
            if(rand2.nextDouble() < 0.1) {setDead();}
        }
        
           isInfected = false;
        }
    
    public boolean getIsInfected()
    {
        return isInfected;
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
