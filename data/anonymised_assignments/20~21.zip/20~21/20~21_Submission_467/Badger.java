import java.util.*;
/**
 * Write a description of class Badger here.
 *
 * @version (a version number or a date)
 */
public class Badger extends Animal
{
    // Characteristics shared by all Badgers (class variables).
    
    // The age at which a badger can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a fox can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    
    // The food value of a single rabbit. In effect, this is the
    // number of steps a badger can go before it has to eat again.
    private static final int SQUIRREL_FOOD_VALUE = 13;
    private static final int WOLF_FOOD_VALUE = 12;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The badger's age.
    private int age;
    // The badger's food level, which is increased by eating rabbits.
    private double foodLevel;


    /**
     * Constructor for objects of class Badger
     */
    public Badger(boolean randomAge, Field field, Location location, boolean isMale, boolean isInfected)
    {
        super(field, location, isMale, isInfected);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SQUIRREL_FOOD_VALUE);
            isMale = makeGender();
        }
        else {
            age = 0;
            foodLevel = SQUIRREL_FOOD_VALUE;
            isMale = makeGender();
        }
    }

     public void act(List<Animal> newBadgers)
    {
        Random rando = Randomizer.getRandom();

        incrementAge();
        incrementHunger();
        
        
        //If the weather is foggy, badger's mobility is extremely limited
        
        if(isAlive()) {
            
            giveBirth(newBadgers);  
            
                      
            // Move towards a source of food if found.
            Location newLocation = null;
            
            if(!Simulator.getWeather().equals("Snow"))
            {
                newLocation = findFood();
            }
          
            
            if(Simulator.getSteps() % 24 < 12) //In the daytime badgers have food level buffs
            {
                foodLevel += 0.2;
            }
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            if(isAlive()){infectAnimals();}
        }
    }
    
    /**
     * Increase the age. This could result in the badger's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this badger more hungry. This could result in the badger's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    squirrel.setDead();
                    foodLevel = SQUIRREL_FOOD_VALUE;
                    return where;
                }
            }
            
            if(animal instanceof Wolf) {
                Wolf wolf = (Wolf) animal;
                if(wolf.isAlive()) { 
                    wolf.setDead();
                    foodLevel = SQUIRREL_FOOD_VALUE;
                    return where;
                }
            }
            
        }
        return null;
    }
    
    /**
     * Check whether or not this badger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBadgers A list to return newly born badgers.
     */
    private void giveBirth(List<Animal> newBadgers)
    {
        // New badgers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
         //Checks if the animal has collided with one of the opposite sex (to breed)
            
            List<Location> locs = field.adjacentLocations(getLocation());
    
            for(int count = 0; count < locs.size(); count++)
            {
                Object o = field.getObjectAt(locs.get(count));
                if(o instanceof Badger) 
                {
                    Badger badger = (Badger) o;
                    if ((badger.getGender()) != getGender()) 
                    {
                        count = locs.size();
                        for(int b = 0; b < births && free.size() > 0; b++)
                        {
                            Location loc = free.remove(0);
                            Badger young = new Badger(false, field, loc, makeGender(), false);
                            newBadgers.add(young);
                    }
                }
            }
        }
        
      
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A badger can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
}
