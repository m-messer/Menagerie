    import java.util.*;
    
    /**
     * A simple model of a hare.
     * Hares age, move, breed, and die.
     *
     * @version 2016.02.29 (2)
     */
    public class Hare extends Animal
    {
        // Characteristics shared by all hares (class variables).
    
        // The age at which a hare can start to breed.
        private static final int BREEDING_AGE = 3;
        // The age to which a hare can live.
        private static final int MAX_AGE = 175;
        // The likelihood of a hare breeding.
        private static final double BREEDING_PROBABILITY = 0.075;
        // The maximum number of births.
        private static final int MAX_LITTER_SIZE = 8;
        //Number of steps a hare must go before eating
        private static final int CARROT_FOOD_VALUE = 20;
    
        // A shared random number generator to control breeding.
        private static final Random rand = Randomizer.getRandom();
        
        // Individual characteristics (instance fields).
        
        // The hare's age.
        private int age;
        //Hare's food level- increased by eating carrots
        private double foodLevel;
    
        /**
         * Create a new hare. A hare may be created with age
         * zero (a new born) or with a random age.
         * 
         * @param randomAge If true, the hare will have a random age.
         * @param field The field currently occupied.
         * @param location The location within the field.
         */
        public Hare(boolean randomAge, Field field, Location location, boolean isMale, boolean isInfected)
        {
            super(field, location, isMale, isInfected);
            age = 0;
            if(randomAge) {
                age = rand.nextInt(MAX_AGE);
                foodLevel = rand.nextInt();
                isMale = makeGender();
            }
            else {
                age = 0;
                foodLevel = CARROT_FOOD_VALUE;
                isMale = makeGender();
            }
        }
        
        /**
         * This is what the hare does most of the time - it runs 
         * around. Sometimes it will breed or die of old age.
         * @param newHares A list to return newly born hares.
         */
        public void act(List<Animal> newHares)
        {
            incrementAge();
            incrementHunger();
            
            
            //If the weather is snowy, the hare hibernates, effectively making it immune/inactive for the duration of snow
            if(!Simulator.getWeather().equals("Snow"))
            {
            
                incrementHunger();
                
                if(isAlive())
                {

                    giveBirth(newHares);       
                           
                    // Move towards a source of food if found.
                    Location newLocation = findFood();
                    
                    if(Simulator.getSteps() % 24 > 12) //If it is night time
                    {
                        foodLevel -= 0.5; //Hare cannot see food at night time so it will be hungrier
                    }
                    
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                    
                 if(isAlive()){infectAnimals();} 
                }
            }
        }
    
         /**
         * Look for carrots adjacent to the current location.
         * Only the first carrot is eaten.
         * @return Where food was found, or null if it wasn't.
         */
        private Location findFood()
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object hareFood = field.getObjectAt(where);
                if(hareFood instanceof Carrot) {
                    Carrot carrot = (Carrot) hareFood;
                    if(carrot.isAlive()) { 
                        carrot.setEatenOrDead(); 
                        foodLevel = CARROT_FOOD_VALUE;
                        return where;
                    }
                }
            }
            return null;
        }
        
        /**
         * Increase the age.
         * This could result in the hare's death.
         */
        private void incrementAge()
        {
            age++;
            if(age > MAX_AGE) {
                setDead();
            }
        }
        
         
        /**
         * Make this hare more hungry. This could result in the hare's death.
         */
        private void incrementHunger()
        {
            foodLevel--;
            if(foodLevel <= 0) {
                setDead();
            }
        }
        
        /**
         * Check whether or not this hare is to give birth at this step.
         * New births will be made into free adjacent locations.
         * @param newHares A list to return newly born hares.
         */
        private void giveBirth(List<Animal> newHares)
        {
            // New hares are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
           
            //Checks if the animal has collided with one of the opposite sex (to breed)
            
            List<Location> locs = field.adjacentLocations(getLocation());
    
            for(int count = 0; count < locs.size(); count++)
            {
                Object o = field.getObjectAt(locs.get(count));
                if(o instanceof Hare) 
                {
                    Hare hare = (Hare) o;
                    if ((hare.getGender()) != getGender()) 
                    {
                        count = locs.size();
                        for(int b = 0; b < births && free.size() > 0; b++)
                        {
                            Location loc = free.remove(0);
                            Hare young = new Hare(false, field, loc, makeGender(), false);
                            newHares.add(young);
                    }
                }
            }
        }
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hare can breed if it has reached the breeding age.
     * @return true if the hare can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
