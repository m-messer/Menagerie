import java.util.*;

/**
 * Write a description of class Carrot here.
 *
 * @version (a version number or a date)
 */
public class Carrot extends Plant
{
    //Age at which a carrot germinates
    private static final int REPRODUCTION_AGE = 10;
    //Age at which the carrot lives to before rotting
    private static final int MAX_AGE = 1000;
    //Probability the carrot reproduces
    private static final double REPRODUCTION_PROBABILITY = 0.02;
    //Max number of carrots that can be spawned from this
    private static final int MAX_CARROTS = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    //Carrot's age
    private int age;

    /**
     * Constructor for objects of class Carrot
     */
    public Carrot(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
    }

     public void act(List<Plant> newCarrots)
    {
        incrementAge();
        if(isAlive()) {
           
            germinate(newCarrots);            
            
             //Appropriate weather conditions accelerate plant growth or weaken the plant
            if(Simulator.getWeather().equals("Sunny") || Simulator.getWeather().equals("Rainy") )
            {
                germinate(newCarrots);
                germinate(newCarrots);
                germinate(newCarrots);
            } else {
                age += 35;
            }
               
        }
    }
    
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setEatenOrDead();
        }
    }
    
    private void germinate(List<Plant> newCarrots)
    {
        // New carrots are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int spawn = spread();
        for(int b = 0; b < spawn && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Carrot young = new Carrot(false, field, loc);
            newCarrots.add(young);
        }
    }
    
     private int spread()
    {
        int spawn = 0;
        if(canSpread() && rand.nextDouble() <= REPRODUCTION_PROBABILITY) {
            spawn = rand.nextInt(MAX_CARROTS) + 1;
        }
        return spawn;
    }

    /**
     * A carrot can spread if it has reached the reproduction age.
     * @return true if the carrot can spread, false otherwise.
     */
    private boolean canSpread()
    {
        return age >= REPRODUCTION_AGE;
    }
}
