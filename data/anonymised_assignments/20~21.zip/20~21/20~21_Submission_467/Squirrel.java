import java.util.*;
/**
 * Write a description of class Squirrel here.
 *
 * @version (a version number or a date)
 */
public class Squirrel extends Animal
{
    // Characteristics shared by all Rodents (class variables).
    
    // The age at which a squirrel can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a squirrel can live.
    private static final int MAX_AGE = 95;
    // The likelihood of a squirrel breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20;
    
    // The food value of a single acorn. In effect, this is the
    // number of steps a squirrel can go before it has to eat again.
    private static final int ACORN_FOOD_VALUE = 17;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The squirrel's age.
    private int age;
    // The squirrel's food level, which is increased by eating plants.
    private int foodLevel;



    /**
     * Constructor for objects of class Squirrel
     */
    public Squirrel(boolean randomAge, Field field, Location location, boolean isMale, boolean isInfected)
    {
        super(field, location, isMale, isInfected);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ACORN_FOOD_VALUE);
            isMale = makeGender();

        }
        else {
            age = 0;
            foodLevel = ACORN_FOOD_VALUE;
            isMale = makeGender();

        }
        
    }

     public void act(List<Animal> newSquirrels)
    {
        
        Random rando = Randomizer.getRandom();

        incrementAge();
        incrementHunger();
        
        
        if(isAlive()) {
            
            
            giveBirth(newSquirrels);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if(Simulator.getSteps() % 24 < 12) 
            {
               
            
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
            }
            if(isAlive()){infectAnimals();} 
        }
    }
    
    /**
     * Increase the age. This could result in the squirrel's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this squirrel more hungry. This could result in the squirrel's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for acorns adjacent to the current location.
     * Only the first acorn is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object squirrelFood = field.getObjectAt(where);
            if(squirrelFood instanceof Acorn) {
                Acorn acorn = (Acorn) squirrelFood;
                if(acorn.isAlive()) { 
                    acorn.setEatenOrDead(); 
                    foodLevel = ACORN_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this squirrel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSquirrels A list to return newly born squirrels.
     */
    private void giveBirth(List<Animal> newSquirrels)
    {
        // New badgers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
         //Checks if the animal has collided with one of the opposite sex (to breed)
            
            List<Location> locs = field.adjacentLocations(getLocation());
    
            for(int count = 0; count < locs.size(); count++)
            {
                Object o = field.getObjectAt(locs.get(count));
                if(o instanceof Squirrel) 
                {
                    Squirrel squirrel = (Squirrel) o;
                    if ((squirrel.getGender()) != getGender()) 
                    {
                        count = locs.size();
                        for(int b = 0; b < births && free.size() > 0; b++)
                        {
                            Location loc = free.remove(0);
                            Squirrel young = new Squirrel(false, field, loc, makeGender(), false);
                            newSquirrels.add(young);
                    }
                }
            }
        }
        
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A squirrel can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
}
