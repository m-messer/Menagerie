import java.util.*;
/**
 * Write a description of class Rodent here.
 *
 * @version (a version number or a date)
 */
public class Rodent extends Animal
{
    // Characteristics shared by all Rodents (class variables).
    
    // The age at which a rodent can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a rodent can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a rodent breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    
    // The food value of a single squirrel. In effect, this is the
    // number of steps a rodent can go before it has to eat again.
    private static final int SQUIRREL_FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The rodent's age.
    private int age;
    // The rodent's food level, which is increased by eating squirrels.
    private int foodLevel;


    /**
     * Constructor for objects of class Rodent
     */
    public Rodent(boolean randomAge, Field field, Location location, boolean isMale, boolean isInfected)
    {
       super(field, location, isMale, isInfected);
       
       if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SQUIRREL_FOOD_VALUE);
            isMale = makeGender();
        }
        else {
            age = 0;
            foodLevel = SQUIRREL_FOOD_VALUE;
            isMale = makeGender();
        }
    }

     public void act(List<Animal> newRodents)
    {
        incrementAge();
        incrementHunger();
        
        if(isAlive()) {
         
          
            giveBirth(newRodents);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if((Simulator.getSteps() % 24 < 12) && !Simulator.getWeather().equals("Rain")) //Rodent sleeps at night; only moves during the day and when weather is not rainy
            {
                if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            } 
            
            }
            
            if(isAlive()){infectAnimals();}
            
        }
    }
    
     /**
     * Increase the age. This could result in the rodent's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this rodent more hungry. This could result in the rodent's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for squirrels adjacent to the current location.
     * Only the first live squirrel is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) { 
                    squirrel.setDead();
                    foodLevel = SQUIRREL_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this rodent is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newRodents A list to return newly born rodents.
     */
    private void giveBirth(List<Animal> newRodents)
    {
        // New badgers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
         //Checks if the animal has collided with one of the opposite sex (to breed)
            
            List<Location> locs = field.adjacentLocations(getLocation());
    
            for(int count = 0; count < locs.size(); count++)
            {
                Object o = field.getObjectAt(locs.get(count));
                if(o instanceof Rodent) 
                {
                    Rodent rodent = (Rodent) o;
                    if ((rodent.getGender()) != getGender()) 
                    {
                        count = locs.size();
                        for(int b = 0; b < births && free.size() > 0; b++)
                        {
                            Location loc = free.remove(0);
                            Rodent young = new Rodent(false, field, loc, makeGender(), false);
                            newRodents.add(young);
                    }
                }
            }
        }
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A rodent can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    

}
