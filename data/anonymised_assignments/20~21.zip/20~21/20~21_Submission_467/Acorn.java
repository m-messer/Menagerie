import java.util.*;

/**
 * Write a description of class Acorn here.
 *
 * @version (a version number or a date)
 */
public class Acorn extends Plant
{
    //Age at which an acorn germinates
    private static final int REPRODUCTION_AGE = 10;
    //Age at which the acorn lives to before rotting
    private static final int MAX_AGE = 1050;
    //Probability the acorn reproduces
    private static final double REPRODUCTION_PROBABILITY = 0.015;
    //Max number of acorns that can be spawned from this
    private static final int MAX_ACORNS = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    //Acorn's age
    private int age;
    

    /**
     * Constructor for objects of class Acorn
     */
    public Acorn(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        
    }

    public void act(List<Plant> newAcorns)
    {
        incrementAge();
        if(isAlive()) {
            
            germinate(newAcorns);  
            
            //Appropriate weather conditions accelerate plant growth or weaken the plant
            if(Simulator.getWeather().equals("Sunny") || Simulator.getWeather().equals("Rainy") )
            {
                
                germinate(newAcorns);
                germinate(newAcorns);
            } else {
                age += 50;
            }
               
        }
    }
    
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setEatenOrDead();
        }
    }
    
    private void germinate(List<Plant> newAcorns)
    {
        // New acorns are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int spawn = spread();
        for(int b = 0; b < spawn && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Acorn young = new Acorn(false, field, loc);
            newAcorns.add(young);
        }
    }
    
     private int spread()
    {
        int spawn = 0;
        if(canSpread() && rand.nextDouble() <= REPRODUCTION_PROBABILITY) {
            spawn = rand.nextInt(MAX_ACORNS) + 1;
        }
        return spawn;
    }

    /**
     * An acorn can spread if it has reached the reproduction age.
     * @return true if the acorn can spread, false otherwise.
     */
    private boolean canSpread()
    {
        return age >= REPRODUCTION_AGE;
    }
}
