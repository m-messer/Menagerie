import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular forest
 * containing wolves, bears, deer, badgers and mice.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 160;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.015;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.026;
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.010;
    // The probability that a badger will be created in any given grid position.
    private static final double BADGER_CREATION_PROBABILITY = 0.032;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.026;
    //The number of steps in a day/night
    private static final int DAY_NIGHT_CYCLE = 40;

    // List of animals in the forest.
    private List<Animal> animals;
    // The current state of the forest.
    private Forest forest;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //states whether it is day or not
    private boolean isDay;
    
    /**
     * Construct a simulation forest with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation forest with the given size.
     * @param depth Depth of the forest. Must be greater than zero.
     * @param width Width of the forest. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        forest = new Forest(depth, width);
        isDay = true;

        // Create a view of the state of each location in the forest.
        view = new SimulatorView(depth, width);
        view.setColor(Deer.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Bear.class, Color.RED);
        view.setColor(Badger.class, Color.BLACK);
        view.setColor(Mouse.class, Color.GREEN);
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(forest); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole forest updating the state of each
     * type of animal.
     */
    public void simulateOneStep()
    {
        step++;
        setDayNight();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all prey act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(animal.isNocturnal() == true) {
                if(!isDay) {
                    animal.act(newAnimals);
                }
                else if(isDay) {
                    animal.sleep(newAnimals); 
                }
            }
            if(animal.isNocturnal() == false) {
                if(!isDay) {
                    animal.sleep(newAnimals);
                }
                else if(isDay) {
                    animal.act(newAnimals); 
                }
            }
            
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, forest);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, forest);
    }
    
    /**
     * Randomly populate the forest with animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        forest.clear();
        for(int row = 0; row < forest.getDepth(); row++) {
            for(int col = 0; col < forest.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, forest, location);
                    animals.add(wolf); 
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, forest, location);
                    animals.add(bear);
                }
                else if(rand.nextDouble() <= BADGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Badger badger = new Badger(true, forest, location);
                    animals.add(badger);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, forest, location);
                    animals.add(deer);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, forest, location);
                    animals.add(mouse);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Changes between day and night every given number of 
     * steps.
     */
    private void setDayNight()
    {
        if(step % DAY_NIGHT_CYCLE == 0){
            isDay = !isDay;
        }
    }
}
