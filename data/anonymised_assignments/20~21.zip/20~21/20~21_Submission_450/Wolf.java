import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * Wolves age, move, eat deer and mice, and die.
 *
 * @version 2021.03.03
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).
    
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.75;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single deer. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int DEER_FOOD_VALUE = 60;
    // The food value of a single mouse.
    private static final int MOUSE_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The wolf's age.
    private int age;
    // The wolf's food level, which is increased by eating deer or mice.
    private int foodLevel;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param forest The forest currently occupied.
     * @param location The location within the forest.
     */
    public Wolf(boolean randomAge, Forest forest, Location location)
    {
        super(forest, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(DEER_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = DEER_FOOD_VALUE;
        }
        if(rand.nextDouble() <= PROBABILITY_IS_MALE) {
            isMale = true;
        }
        else 
        {
            isMale = false;
        }
        isNocturnal = true;
    }
    
    /**
     * This is what the wolf does most of the time: it hunts for
     * deer. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param forest The forest currently occupied.
     * @param newWolves A list to return newly born wolves.
     */
    public void act(List<Animal> newWolves)
    {
        incrementAge();
        incrementHunger();
        developDisease();
        diseaseEffects();
        if(isAlive()) {
            giveBirth(newWolves);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getForest().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the wolf's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this wolf more hungry. This could result in the wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for deer and mice adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Forest forest = getForest();
        List<Location> adjacent = forest.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = forest.getObjectAt(where);
            if(animal instanceof Deer) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel += DEER_FOOD_VALUE;
                    justAte();
                    return where;
                }
            }
            else if (animal instanceof Mouse)
            {
                Mouse mouse = (Mouse) animal;
                if (mouse.isAlive()) 
                {
                    mouse.setDead();
                    foodLevel += MOUSE_FOOD_VALUE; //changed
                    justAte();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolves.
     */
    private void giveBirth(List<Animal> newWolves)
    {
        // New wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Forest forest = getForest();
        List<Location> free = forest.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Wolf young = new Wolf(false, forest, loc);
            newWolves.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A wolf can breed if it has reached the breeding age, is adjacent to
     * a partner and has eaten food in its lifetime.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && partnerAdjacent() && hasEaten());
    }
    
    /**
     * Causes an animal to spread disease, and gives them only 
     * a few steps left to live - unless they already have less life 
     * than that left, in which case they die immediately.
     */
    private void diseaseEffects() {
        if(isAlive() && hasDisease()) {
            spreadDisease();
            if(age <= MAX_AGE - STEPS_AFTER_DISEASE) {
                age = MAX_AGE - STEPS_AFTER_DISEASE;
            }
            else {
                setDead();
            }
        }
    }
}
