import java.util.List;
import java.util.LinkedList;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // Whether the animal is male or female, only opposites can breed.
    protected boolean isMale;
    //Whether the animal is nocturnal.
    protected boolean isNocturnal;
    //Whether the animal has eaten during its lifetime.
    protected boolean hasEaten = false;
    //Whether the animal has a disease or not
    protected boolean hasDisease = false;
    //Probability of an animal developing a disease
    private static final double DISEASE_PROBABILITY = 0.003;
    //How many steps the animal has left to live after catching the disease
    protected static final int STEPS_AFTER_DISEASE = 250;

    
    // The animal's forest.
    private Forest forest;
    // The animal's position in the forest.
    private Location location;
    //Probability the animal is male
    protected static final double PROBABILITY_IS_MALE = 0.5;
    //Randomizer
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in forest.
     * 
     * @param forest The forest currently occupied.
     * @param location The location within the forest.
     */
    public Animal(Forest forest, Location location)
    {
        alive = true;
        this.forest = forest;
        setLocation(location);
        isMale = setGender();
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Make this animal sleep - that is: they will 
     * not move, age, hunt, etc.
     * @param newAnimals A list to receive newly born animals.
     */
    protected void sleep(List<Animal> newAnimals) {
        if(isAlive()) {
            //do nothing
        }
    }
    
    /**
     * Gives the animal a small chance of naturally developing a disease.
     */
    protected void developDisease() {
        if (rand.nextDouble() <= DISEASE_PROBABILITY) {
            catchDisease();
        }
    }
    
    /**
     * Makes an animal positive for a disease.
     */
    protected void catchDisease() {
        hasDisease = true;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the forest.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            forest.clear(location);
            location = null;
            forest = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Return whether the animal can breed with a nearby partner.
     * @return true if member of opposite sex is in adjacent tile.
     */
    protected boolean partnerAdjacent()
    {
        List<Location> adjacentTiles = new LinkedList<>(); //instantiates list of adjacent tiles
        adjacentTiles = forest.adjacentLocations(getLocation()); //fills list of adjacent tiles based on animal's current location
        for (Location tile: adjacentTiles) //scans adjacent tiles
        {
            if (forest.getObjectAt(tile) == null) {
                continue; //skips current iteration
            }
            else {
                Animal buddy = (Animal) forest.getObjectAt(tile);
                if (getClass().equals(buddy.getClass())) { //check for same type of animal
                    if(buddy.isMale() && !isMale()) {
                        //checks that animals are of different 
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Checks for nearby animals and spreads the disease
     * to them.
     */
    protected void spreadDisease() {
        List<Location> adjacentTiles = new LinkedList<>(); //instantiates list of adjacent tiles
        adjacentTiles = forest.adjacentLocations(getLocation()); //fills list of adjacent tiles based on animal's current location
        for (Location tile: adjacentTiles) //scans adjacent tiles
        {
            if (forest.getObjectAt(tile) == null) {
                continue; //skips current iteration
            }
            else {
                Animal animal = (Animal) forest.getObjectAt(tile);
                animal.catchDisease();
            }
        }
    } 
    
    /**
     * Randomly chooses a gender for the new animal.
     * @return true if animal is assigned male.
     */
    protected boolean setGender() {
        double r = rand.nextDouble();
        if (r <= PROBABILITY_IS_MALE) {
            return true;
        }
        return false;
    }
    
    /**
     * Returns animal's gender (effectively).
     * @return true if animal is male.
     */
    
    protected boolean isMale()
    {
        return isMale;
    }
    
    /**
     * Place the animal at the new location in the given forest.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            forest.clear(location);
        }
        location = newLocation;
        forest.place(this, newLocation);
    }
    
    /**
     * Return the animal's forest.
     * @return The animal's forest.
     */
    protected Forest getForest()
    {
        return forest;
    }
    
    /**
     * Return whether the animal is nocturnal or not.
     * @return whether the animal is nocturnal.
     */
    public boolean isNocturnal()
    {
        return isNocturnal;
    }
    
    /**
     * Sets hasEaten to true.
     */
    public void justAte()
    {
        hasEaten = true;
    }
    
    /**
     * Check whether the animal has eaten or not.
     * @return true if the animal has eaten.
     */
    public boolean hasEaten()
    {
        return hasEaten;
    }
    
    /**
     * Check whether the animal has a disease or not.
     * @return true if the animal has a disease.
     */
    protected boolean hasDisease()
    {
        return hasDisease;
    }
}
