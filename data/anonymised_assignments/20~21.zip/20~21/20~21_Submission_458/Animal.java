import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2021.03.02
 */
public abstract class Animal
{
    //animal is live or not
    private boolean alive;
    //
    private Field field;
    //the place of each animal
    private Location location;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);
    
    /**
     * Make this animal act at the night - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void nightAct(List<Animal> newAnimals);
    
    /**
     * Make this animal act in the winter - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void winterAct(List<Animal> newAnimals);
    
    /**
     * Make this animal act in a snowing day- that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void snowAct(List<Animal> newAnimals);
    
    /**
     * Make this animal act in a raining day - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void rainingAct(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * set up the item to some place
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * give the location where the item is 
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * give the place where the animal is at
     */
    protected Field getField()
    {
        return field;
    }    
    
    /**
     * Make the animal act to the trap, 
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public Boolean checkTrap();
    
    /**
     * Return the animal's Gender
     * Random get a gender
     * @ return thr animal's gender.
     */
    
    protected Boolean MaleOrNot(){
        Random getValue = new Random();
        return getValue.nextBoolean();
    }

}
