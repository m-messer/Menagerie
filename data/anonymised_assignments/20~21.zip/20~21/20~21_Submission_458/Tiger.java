import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A animal model of a tiger.
 * Tigers age, move, eat sheeps, sleep at night and die.
 * giving birth at the right age
 * 
 *
 * @version 2021.03.02
 */
public class Tiger extends Animal
{
    // Characteristics shared by all foxes (class variables).

    private static final int BREEDING_AGE = 20;
    private static final int MAX_AGE = 130;
    private static final double BREEDING_PROBABILITY = 0.03;
    private static final int MAX_LITTER_SIZE = 2;
    private static final int SHEEP_FOOD_VALUE = 80;
    private static final Random rand = Randomizer.getRandom();


    private int age;
    private int foodLevel;

    /**
     * Create a tiger. A tiger can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the tiger will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SHEEP_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SHEEP_FOOD_VALUE;
        }
    }

    /**
     * This is what the tiger does most of the time: it hunts for
     * sheeps. In the process, it might breed, die of hunger,
     * or die of old age.
     * if find a trap, the tiger will dead
     * every step, age and hunger level will increase.
     * @param field The field currently occupied.
     * @param newTigers A list to return newly born tigers.
     */
    public void act(List<Animal> newTigers)
    {
        incrementAge();
        incrementHunger();

        if(isAlive()) {
            giveBirth(newTigers);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                if(checkTrap() == true)
                {
                    setDead();
                }
                setDead();
            }
        }
    }
    
    /**
     * at night, tigers will go to sleep and not hunting, but age will increase
     */
    public void nightAct(List<Animal> newTigers)
    {
        incrementAge();
    }
    
    /**
     * In winter, no one is release traps
     * tiger harder give birth in winter.
     */
    public void winterAct(List<Animal> newTigers)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            Random random = new Random();
            random.nextInt(1);
            if(random.nextInt(1)==0)
            {
                giveBirth(newTigers);
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                if(checkTrap() == true)
                {
                    setDead();
                }
                setDead();
            }
        }
    }
    
    /**
     * hard to give birth
     * easier to get hungry
     */
    public void snowAct(List<Animal> newTigers)
    {
        incrementAge();
        incrementHunger();
        incrementHunger();

        if(isAlive()) {
            Random random = new Random();
            if(random.nextInt(1)==0)
            {
                giveBirth(newTigers);
            }       
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                if(checkTrap() == true)
                {
                    setDead();
                }
                setDead();
            }
        }
    }
    
    /**
     * act as normal
     */
    public void rainingAct(List<Animal> newTigers)
    {
        incrementAge();
        incrementHunger();

        if(isAlive()) {
            giveBirth(newTigers);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                if(checkTrap() == true)
                {
                    setDead();
                }
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the tiger's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this tiger more hungry. This could result in the tiger's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for sheeps adjacent to the current location.
     * Only the first live sheep is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Sheep) {
                Sheep sheep = (Sheep) animal;
                if(sheep.isAlive()) { 
                    sheep.setDead();
                    foodLevel = SHEEP_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * if finding a trap, the tiger dead
     */
    public Boolean checkTrap()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object objectStored = field.getObjectAt(where);
            if(objectStored instanceof Trap) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Check whether or not this tiger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Gender
     * @param newTigers A list to return newly born tigers.
     */
    private void giveBirth(List<Animal> newTigers)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        boolean male = true;
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tiger young = new Tiger(false, field, loc);
            newTigers.add(young);
        }

    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A tiger can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
