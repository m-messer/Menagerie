import java.util.Random;
import java.util.ArrayList;

/**
 * this class is a weather selector
 *
 * @version 2021.03.02
 */
public class Weather
{
    /**
     * no need for initial
     */
    public Weather()
    {
    }

    /**
     * act same as the normal act, no change was made.
     */
    private String sunny()
    {
        return "Sunny";
    }
       
    /**
     * Raining day make animal move slowly.
     */
    private String Raining()
    {
        return "raining";
    }
    
    /**
     * In winter, some animal doesn't move and no need for food.
     */
    private String winter()
    {
        return "In winter";
    }
    
    /**
     * snowing ady only happen in winter.
     * other than the animal is already sleeping, other animlas move slower.
     */
    private String snowing()
    {
        return "Snowing Day";
    }
    
    /**
     * random select weather
     */
    public String weatherSelect()
    {
        ArrayList<String> weather = new ArrayList<String>();
        weather.add(sunny());
        weather.add(Raining());
        weather.add(winter());
        weather.add(snowing());
        Random random = new Random();
        return weather.get(random.nextInt(weather.size()-1));
        
    }
}
