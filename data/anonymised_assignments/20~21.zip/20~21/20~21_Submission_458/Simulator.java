import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing tigers,sheep,cows, wolves and lions.
 *
 * @version 2021.03.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.03;
    // The probability that a rabbit will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.08;
    // The probability that a cow will be created in any given grid position.
    private static final double COW_CREATION_PROBABILITY = 0.15;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.05;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.03;
    // The probability that a trap will be created in any given grid position.
    private static final double Trap_CREATION_PROBABILITY = 0.002;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    
    private int stepInADay;
    // every six steps is one day
    private int trapLevel;
    //
    private SimulatorView view;
    //Screen setup to show the informatiojn
    public Simulator simulation;
    // A graphical view of the simulation.
    public Date date;
    //Date class for working with the date
    public Trap trap;
    //trap can kill animlas
    public Weather weather;
    // weather can change the moving of the animals
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * Set the color for different animals on the grid.
     * Set up animals, field, date, weather.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);
        date = new Date();
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Sheep.class, Color.ORANGE);
        view.setColor(Tiger.class, Color.BLUE);
        view.setColor(Cow.class, Color.YELLOW);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Lion.class, Color.GREEN);
        view.setColor(Trap.class, Color.BLACK);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (2000 steps).
     */
    public void runLongSimulation()
    {
        simulate(2000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * Also, slow down the movement.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(100);
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * tiger and sheep and wolf and cow and lion.
     */
    public void simulateOneStep()
    {
        step++;
        stepInADay++;
        oneDay();
        if(date.check(step) == false)
        {
            // Provide space for newborn animals.
            List<Animal> newAnimals = new ArrayList<>();        
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                animal.act(newAnimals);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
            animals.addAll(newAnimals);
            view.showStatus(step, field,date.getCurrentDate(),weather.weatherSelect());
        }
        else if (date.check(step) == true)
        {
            // Provide space for newborn animals.
            List<Animal> newAnimals = new ArrayList<>();        
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                animal.nightAct(newAnimals);
                if(!animal.isAlive())
                {
                    it.remove();
                }
            }
            animals.addAll(newAnimals);
            view.showStatus(step, field,date.getCurrentDate(),weather.weatherSelect());
        }
        }
        
        /**
         * When the step reach to six, the date would increase and weather will change.
         */
        private void oneDay()
        { 
        if(stepInADay == 6){
            date.incrementDate(); 
        if(weather.weatherSelect().equals ("sunny"))
            {
                List<Animal> newAnimals = new ArrayList<>();        
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    animal.nightAct(newAnimals);
                    if(!animal.isAlive())
                    {
                        it.remove();
                    }
                }
                animals.addAll(newAnimals);
                view.showStatus(step, field,date.getCurrentDate(),weather.weatherSelect());
            }else if(weather.weatherSelect().equals ("raining"))
            {
                List<Animal> newAnimals = new ArrayList<>();        
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    animal.rainingAct(newAnimals);
                    if(!animal.isAlive())
                    {
                        it.remove();
                    }
                }
                animals.addAll(newAnimals);
                view.showStatus(step, field,date.getCurrentDate(),weather.weatherSelect());
            }else if(weather.weatherSelect().equals ("In winter"))
            {
                List<Animal> newAnimals = new ArrayList<>();        
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    animal.winterAct(newAnimals);
                    if(!animal.isAlive())
                    {
                        it.remove();
                    }
                }
                animals.addAll(newAnimals);
                view.showStatus(step, field,date.getCurrentDate(),weather.weatherSelect());
            }else if(weather.weatherSelect().equals ("Snowing Day"))
            {
                List<Animal> newAnimals = new ArrayList<>();        
                for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                    Animal animal = it.next();
                    animal.snowAct(newAnimals);
                    if(!animal.isAlive())
                    {
                        it.remove();
                    }
                }
                animals.addAll(newAnimals);
                view.showStatus(step, field,date.getCurrentDate(),weather.weatherSelect());
            }
            stepInADay = 0;
        }
    }

    /**
     * Reset the simulation to a starting position.
     * Clear all the steps and date
     */
    public void reset()
    {
        step = 0;
        trapLevel = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field,date.getCurrentDate(),weather.weatherSelect());
    }

    /**
     * Randomly populate the field with animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    animals.add(tiger);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Sheep sheep = new Sheep(true, field, location);
                    animals.add(sheep);
                }else if(rand.nextDouble() <= COW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cow cow= new Cow(true, field, location);
                    animals.add(cow);
                }else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= Trap_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Trap trap = new Trap(field, location);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * return the number of steps that has been gone
     */
    private int getStep()
    {
        System.out.println(step);
        return step;
    }
}
