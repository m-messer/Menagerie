
/**
 * a trap will kill animals if they fall ing
 *
 * @version 2021.03.02
 */
public class Trap
{
    private Field field;

    private Location location;

    /**
     * initial the fielf place and set up the trap
     */
    public Trap(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
    }

    /**
     * set up the initial place for the trap at the begining
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

}
