

/**
 * This class is keeping track of the date and steps 
 * Also, change the day and night when hours are passing
 *
 * @version 2021.03.02
 */
public class Date
{
    // date now at this amount of step
    public int currentDate;
    //
    public boolean isNight;
    

    /**
     * Constructor for objects of class Date
     */
    public Date()
    {
        // initial date is zero
        currentDate = 0;
        isNight = false;
    }

    /**
     * return date at this moment
     */
    public int getCurrentDate()
    {
        return currentDate;
    }
    
    /**
     * increase date by one
     */
    public void incrementDate()
    {
        ++ currentDate;
    }
    
    /**
     * set step to night which will cahnge the movement of the animals
     */
    public void setNight()
    {
        isNight = true;
    }
    
    /**
     * set step to morning whihc will change the movement to normal
     */
    public void setMorning()
    {
        isNight = false;
    }
    
    /**
     * check if this is at night or in the morning.
     */
    public boolean check(int step)
    {
        if (step % 8 >= 6)
        {
            setNight();
        }
        else
        {
            setMorning();
        }
        
        return isNight;
    }
            
}
