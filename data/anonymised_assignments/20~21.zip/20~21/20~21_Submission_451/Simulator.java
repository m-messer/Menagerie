import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing six species - Lizard, RattleSnake, Cactus, Tarantula, Hawk and KangarooRat
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The creation probability that any species will be created in any given grid position.
    private static final double Hawk_CREATION_PROBABILITY = 0.06;
    private static final double KangarooRat_CREATION_PROBABILITY = 0.20;
    private static final double RattleSnake_CREATION_PROBABILITY = 0.06;
    private static final double Tarantula_CREATION_PROBABILITY = 0.09;
    private static final double Lizard_CREATION_PROBABILITY = 0.18;
    private static final double Cactus_CREATION_PROBABILITY = 0.55;

    // List of AnimalsAndPlants in the field.
    private List<Species> AnimalsAndPlants;
    // The current state of the field.
    private Field field;
    // The sex of the species.
    private String sex;
    // The current weather.
    private String weather;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // If it is night or not.
    private boolean isNight;
    // Current time.
    private String time;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        AnimalsAndPlants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(KangarooRat.class, Color.ORANGE);
        view.setColor(Hawk.class, Color.BLUE);
        view.setColor(RattleSnake.class, Color.PINK);
        view.setColor(Tarantula.class, Color.RED);
        view.setColor(Lizard.class, Color.CYAN);
        view.setColor(Cactus.class, Color.GREEN);

        isNight = false;
        weather =  "clear";

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step and update the weather.
     * Iterate over the whole field updating the state of each including weather
     * Hawk and KangarooRat.
     */
    public void simulateOneStep()
    {
        step++;


        // Provide space for newborn AnimalsAndPlants.
        List<Species> newAnimalsAndPlants = new ArrayList<>();
        // Change the boolean value of night so species are dormant between 8pm and 6am.
        int hours = view.getClock().getHours();
        if( hours > 19 || hours < 7){
            isNight = true;
        }
        else{
            isNight = false;
        }
        // Creates the probability of each weather in each if statement.
        Random rand = new Random();
        int rand_int = rand.nextInt(100);
        if(step % 300 == 0)
        {
            if (rand_int < 35)
            {
                view.setWeather("clear");
            }
            else if (rand_int > 35 && rand_int < 50)
            {
                view.setWeather("sunny");
            }
            else if (rand_int > 50 && rand_int < 85)
            {
                view.setWeather("raining");
            }
            else{
                view.setWeather("foggy");
            }

        }
        // Let all KangarooRats act.
        for(Iterator<Species> it = AnimalsAndPlants.iterator(); it.hasNext(); ) {
            Species Species = it.next();
            Species.act(newAnimalsAndPlants, isNight,view.getWeather());
            if(! Species.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born Species to the main lists.
        AnimalsAndPlants.addAll(newAnimalsAndPlants);

        view.showStatus(step, field, time, weather);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        AnimalsAndPlants.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, time, weather);
    }

    /**
     * Randomly populate the field with all the species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Hawk_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hawk Hawk = new Hawk(true, field, location, sex);
                    AnimalsAndPlants.add(Hawk);
                }
                else if(rand.nextDouble() <= KangarooRat_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    KangarooRat KangarooRat = new KangarooRat(true, field, location, sex);
                    AnimalsAndPlants.add(KangarooRat);
                }
                else if(rand.nextDouble() <= RattleSnake_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    RattleSnake RattleSnake = new RattleSnake(true, field, location, sex);
                    AnimalsAndPlants.add(RattleSnake);
                }
                else if(rand.nextDouble() <= Tarantula_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tarantula Tarantula = new Tarantula(true, field, location, sex);
                    AnimalsAndPlants.add(Tarantula);
                }
                else if(rand.nextDouble() <= Lizard_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lizard Lizard = new Lizard(true, field, location, sex);
                    AnimalsAndPlants.add(Lizard);
                }
                else if(rand.nextDouble() <= Cactus_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cactus Cactus = new Cactus(true, field, location, sex);
                    AnimalsAndPlants.add(Cactus);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
