import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of AnimalsAndPlants.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Species
{
    // Whether the Species is alive or not.
    private boolean alive;
    // The Species's field.
    private Field field;
    // The Species's position in the field.
    private Location location;
    // The Species's sex
    private String sex;

    /**
     * Create a new species at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param sex The sex of the species.
     */
    public Species(Field field, Location location, String sex)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        Random rand = new Random();
        int rand_int = rand.nextInt(100);
        if (rand_int < 50){
            this.sex =  "female";
        }
        else{
            this.sex = "male";
        }

    }

    /**
     * Make this species act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimalsAndPlants A list to receive newly born AnimalsAndPlants.
     * @param isNight A boolean value when true it is night time and Species are dormant.
     * @param weather The weather whose status is to be displayed.
     */
    abstract public void act(List<Species> newAnimalsAndPlants, Boolean isNight, String weather);

    /**
     * Check whether the Species is alive or not.
     * @return true if the Species is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the Species is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return The Species's location.
     * @return The species's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the species at the new location in the given field.
     * @param newLocation The species's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the species's field.
     * @return The species's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the species's sex.
     * @return The species's sex.
     */
    protected String getSex()
    {
        return sex;
    }
}
