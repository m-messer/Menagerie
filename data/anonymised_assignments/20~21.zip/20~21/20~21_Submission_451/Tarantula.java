import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Tarantula.
 * Tarantulas age, move, eat KangarooRats, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Tarantula extends Species
{
    // Characteristics shared by all Tarantulas (class variables).

    // The age at which a Tarantula can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a Tarantula can live.
    private static final int MAX_AGE = 25;
    // The likelihood of a Tarantula breeding.
    private static final double BREEDING_PROBABILITY = 0.35;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The food value of a single KangarooRat. In effect, this is the
    // number of steps a Tarantula can go before it has to eat again.
    private static final int KangarooRat_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Tarantula's age.
    private int age;
    // The Tarantula's food level, which is increased by eating KangarooRats.
    private int foodLevel;

    /**
     * Create a Tarantula. A Tarantula can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Tarantula will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param sex The sex of the species.
     */
    public Tarantula(boolean randomAge, Field field, Location location, String sex)
    {
        super(field, location, sex);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(KangarooRat_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = KangarooRat_FOOD_VALUE;
        }
    }

    /**
     * This is what the Tarantula does most of the time: it hunts for
     * KangarooRats. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newTarantulas A list to return newly born Tarantulas.
     * @param isNight A boolean value when true it is night time and Tarantulas are dormant.
     * @param weather The current weather, effects birth of Tarantulas and their ability to find food.
     */
    public void act(List<Species> newTarantulas, Boolean isNight, String weather)
    {
        if(!isNight){
            incrementAge();
            incrementHunger();
            if(isAlive()) {
                if(weather != "foggy"){
                    giveBirth(newTarantulas);  
                }
                else{
                    Random rand = new Random();
                    int chance = rand.nextInt(100);
                    if (chance > 50){
                        giveBirth(newTarantulas); 
                    }
                }
                    // Move towards a source of food if found.
                    Location newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // Overcrowding.
                        setDead();
                    }
                
                
            }
        }
    }

    /**
     * Increase the age. This could result in the Tarantula's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Tarantula more hungry. This could result in the Tarantula's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for KangarooRats adjacent to the current location.
     * Only the first live KangarooRat is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Species = field.getObjectAt(where);
            //Uses eating probability to allow the other species to grow
            Random rand = new Random();
            int chance = rand.nextInt(100);
            if(Species instanceof KangarooRat && chance > 50) {
                KangarooRat KangarooRat = (KangarooRat) Species;
                if(KangarooRat.isAlive()) { 
                    KangarooRat.setDead();
                    foodLevel = KangarooRat_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this Tarantula is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTarantulas A list to return newly born Tarantulas.
     */
    private void giveBirth(List<Species> newTarantulas)
    {
        // New Tarantulas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        String sex = getSex();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tarantula young = new Tarantula(false, field, loc, sex);
            newTarantulas.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && age >= BREEDING_AGE) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Tarantula can breed if it has reached the breeding age and if it is nearby the location of a lizard of the opposite sex.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Species = field.getObjectAt(where);
            if(Species instanceof Tarantula) {
                Tarantula Tarantula = (Tarantula) Species;
                if(Tarantula.getSex() != getSex()) { 
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }
}
