import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Grass extends Plant
{
    // Characteristics shared by Grass (class variables).

    // The age to which the grass can "live" up-to.
    private static final int MAX_AGE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The Grass's "age."
    private int age;

    /**
     * Create new Grass. Grass may be created with age
     * zero (newly grown) or with a random "age".
     * 
     * @param randomAge If true, the Grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the grass does most of the time - it stays
     * still. 
     * @param newGrass A list to return newly grown grass.
     */
    public void act(List<Plant> newGrass)
    {
        incrementAge();
    }

    /**
     * Increase the age.
     * This could result in the grass's "death".
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }  
}