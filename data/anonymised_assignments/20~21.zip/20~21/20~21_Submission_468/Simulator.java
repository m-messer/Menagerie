    import java.util.Random;
    import java.util.List;
    import java.util.ArrayList;
    import java.util.Iterator;
    import java.awt.Color;
    
    /**
     * A simple predator-prey simulator, based on a rectangular field
     * containing animals and grass.
     *

     * @version 2016.02.29 (2)
     */
    public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.010;
    // The probability that an eagle will be created in any given grid position.
    private static final double EAGLE_CREATION_PROBABILITY = 0.035;
    // The probability that a ferret will be created in any given grid position.
    private static final double FERRET_CREATION_PROBABILITY = 0.14;
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.23;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.19;
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.003;
    private static final double START_GRASS_CREATION_PROBABILITY = 0.08;

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //Day or night state
    public boolean night;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        night = false;
    }

    /**
     * Contains all of the colours of all of the entities in the simuation
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        view = new SimulatorView(depth, width);
        view.setColor(Ferret.class, Color.ORANGE);

        view.setColor(Wolf.class, Color.BLUE);

        view.setColor(Eagle.class, Color.BLACK);

        view.setColor(Mouse.class, Color.PINK);

        view.setColor(Squirrel.class, Color.RED);

        view.setColor(Grass.class, Color.GREEN);

        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (400 steps).
     * Change the parameter from 400 to your desired amount of steps if you 
     * wish to change.
     */
    public void runLongSimulation()
    {
        simulate(400);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * Each step is delayed by 35 milliseconds.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(35);
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     * Generates grass/environment constantly.
     * Changes from day/night if appropriate.
     * 
     */
    public void simulateOneStep()
    {
        step++;
        generateGrass();
        timeChanger();
        List<Plant> newPlants = new ArrayList<>();
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }

        List<Animal> newAnimals = new ArrayList<>();
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(night,newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        animals.addAll(newAnimals);
        view.showStatus(step, field);
        view.showTime(night);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with animals.
     * Generates the grass at the start of the simulation.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= FERRET_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Ferret ferret = new Ferret(true, field, location);
                    animals.add(ferret);
                }
                else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);

                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location);
                    animals.add(squirrel);

                }
                else if(rand.nextDouble() <= EAGLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(true, field, location);
                    animals.add(eagle);
                }

                else if(rand.nextDouble() <= START_GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row,col);
                    Grass grass = new Grass(true, field, location);
                }
            }
        }
    }
    
    /**
     * Has a chance of generating grass/plant in the field.
     */
    private void generateGrass()
    {
        Random rand1 = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {

                if(rand1.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row,col);
                    Grass grass = new Grass(true, field, location);

                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
        }
    }
    
    /**
      * Changes between day/night every 50 steps.
     */
    public void timeChanger(){
        if(step % 50 == 0){
            night = !night;
        }
    }

}
