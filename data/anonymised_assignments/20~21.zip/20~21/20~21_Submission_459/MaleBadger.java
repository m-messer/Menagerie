import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a male badger.
 *  Male Badger age, move, breed with female badgers, and die.
 *
 * @version 2016.02.29 (2)
 */
public class MaleBadger extends Animal
{
    // Characteristics shared by all Male badgers (class variables).
    
    // The age at which a Male Badger can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a Male Badger can live.
    private static int MAX_AGE = 120;
    // The likelihood of a Male Badger breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The male badger's age.
    private int age;
    

    /**
     * Create a male badger. A male badger can be created as a new born (age zero
     * ) or with a random age 
     * 
     * @param randomAge If true, the male badger will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public MaleBadger(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the male badger does most of the time: 
     * In the process, it might breed,
     * die of old age.
     * @param field The field currently occupied.
     * @param newMaleBadgers A list to return newly new male badgers.
     */
    public void act(List<Animal> newMaleBadgers)
    {
        incrementAge();
        
        if(isAlive()) {            
            // Move towards a source of food if found.
            Location newLocation = propagate(newMaleBadgers);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the male badger's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    public void fog() 
    {
        MAX_AGE = 110;
    }
    
    
    
    /**
     * Look for female badgers adjacent to the current location.
     * Only the first live female badger is breed with.
     * @return Where food was found, or null if it wasn't.
     */
    private Location propagate(List<Animal> newMaleBadgers)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof FemaleBadger) {
                FemaleBadger femaleBadger = (FemaleBadger) animal;
                if(femaleBadger.isAlive()) { 
                    giveBirth(newMaleBadgers);
                    return where;
                }
            }
            
        }
        return null;
    }
    
    
    
    /**
     * Check whether or not this male badger is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMaleBadgers A list to return newly male badgers.
     */
    private void giveBirth(List<Animal> newMaleBadgers)
    {
        // New male badgers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            MaleBadger young = new MaleBadger(false, field, loc);
            newMaleBadgers.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A male badger can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
