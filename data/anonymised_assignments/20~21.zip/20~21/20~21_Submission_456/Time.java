/**
 * Represents the weather in the field.
 *
 * @version 2016.02.29
 */
public class Time
{
    // Current Time 
    private int currentTime;
    // Current Day number
    private int dayNumber;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        currentTime = 0;
        dayNumber = 1;
    }

    /**
     * The time has a maximum value of 24. When this exceeds, it gets reset to 0.
     * When the time increments from 0, it represents a new day.
     */
    public void increment()
    {
        currentTime = currentTime + 1;
        
        if (currentTime > 24) {
            currentTime = 0;
            dayNumber++;
        }
    }
    
    /**
     * @return the current time
     */
    public int getTime()
    {
        return currentTime;
    }
    
    /**
     * @return the current day number
     */
    public int getDayNumber()
    {
        return dayNumber;
    }
    
    /**
     * Configures a new time
     * 
     * @param the new time
     */
    public void setTime(int newTime)
    {
        if ((newTime > -1) && (newTime < 25)) {
            currentTime = newTime;
        } else {
            currentTime = 0;
        }
    }
    
    /**
     * Resets the time and dayNumber.
     * Note: The simulation starts with day 1
     */
    public void resetTime()
    {
        currentTime = 0;
        dayNumber = 1;
    }

    /**
     * Night is defined as the period at which most animals are asleep
     *
     * @return true if night. Otherwise, false.
     */
    public boolean isNight()
    {
        if ((currentTime > 21) || (currentTime < 6)) {
            return true;
        }
        
        return false;
    }
}
