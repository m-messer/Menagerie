import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * 
 * A predator-prey-producer simulator, based on a rectangular field
 * containing: Shrimps, Tunas, Killer Whales, Sharks, Seals and Seaweeds.
 * The simulation consists of multiple factors: Weather, Disease, Time.
 * Each factor affects the simulation in a seperate way.
 * The activities of the animals and plants is dependent on these factors. 
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 140;
    // The probability that a killer whale will be created in any given grid position.
    private static final double KILLERWHALE_CREATION_PROBABILITY = 0.05;
    // The probability that a seal will be created in any given grid position.
    private static final double SEAL_CREATION_PROBABILITY = 0.03;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.07;
    // The probability that a seaweed will be created in any given grid position.
    private static final double SEAWEED_CREATION_PROBABILITY = 0.02;
    // The probability that a shrimp will be created in any given grid position.
    private static final double SHRIMP_CREATION_PROBABILITY = 0.04;
    // The probability that a tuna will be created in any given grid position.
    private static final double TUNA_CREATION_PROBABILITY = 0.08;

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The time within the simulation
    private Time time;   
    // The weather within the simulation
    private Weather weather;
    // The number of steps required to initiate the change of the weather cycle
    private final int weatherOccurrence = 24; // 24 steps equals 1 day
    // The number of deaths caused through the disease
    private int deathsThroughDisease;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        time = new Time();

        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();
        plants = new ArrayList<>();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Shrimp.class, Color.ORANGE);
        view.setColor(KillerWhale.class, Color.BLUE);
        view.setColor(Shark.class, Color.GRAY);
        view.setColor(Tuna.class, Color.YELLOW);
        view.setColor(Seal.class, Color.RED);
        view.setColor(Seaweed.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        int i = 0;
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   
            if (step%weatherOccurrence == 0) // Change weather
            {
                i++;
                i = i % 3;
                weather.changeWeather(i);
                view.showWeather(weather); // Update the weather label in the GUI
            }
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Shrimp, Seal, Killer Whale, Shark, Tuna, Seaweed.
     * Moreover, it also changes the state of the weather, deaths through the disease and the day/time.
     */
    public void simulateOneStep()
    {
        step++;
        time.increment();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();   
        List<Plant> newPlants = new ArrayList<>();
        
        // Let all animals act
        for(Iterator<Animal> animalIterator = animals.iterator() ; animalIterator.hasNext();) 
        {
            Animal animal = animalIterator.next();

            if(!time.isNight()) // Animals can't "act" during the night
            {
                if(animal.getIsInfected()) // Kill off any infected animals
                {
                    animal.setDead();
                    deathsThroughDisease++;
                    
                }
                else{
                    animal.act(newAnimals, weather);
                }

            }
            
            if(!animal.isAlive()) { // Remove dead animals
                animalIterator.remove();
            }
        }
        
        // Let all plants act
        for(Iterator<Plant> plantIterator = plants.iterator() ; plantIterator.hasNext();) 
        {
            Plant plant = plantIterator.next();

            plant.act(newPlants, weather);

            if(!plant.isAlive()) { // Remove dead plants
                plantIterator.remove();
            }
        }

        // Add the newly born animals and plants to the main lists.
        animals.addAll(newAnimals);
        plants.addAll(newPlants);
        
        // Update the labels within the GUI
        view.showStatus(step, field);
        view.showAdditionalInformation(deathsThroughDisease, time.getDayNumber());

    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        deathsThroughDisease = 0;
        animals.clear();
        plants.clear();
        populate();
        time.resetTime();
        weather.resetWeather();

        // Show the starting state in the view.
        view.showStatus(step, field);
        view.showWeather(weather);
        view.showAdditionalInformation(deathsThroughDisease, time.getDayNumber());
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant seaweed = new Seaweed(true, field, location);
                    plants.add(seaweed);

                }
                else if(rand.nextDouble() <= SHRIMP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shrimp shrimp = new Shrimp(true, field, location);
                    animals.add(shrimp);
                }
                else if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location);
                    animals.add(seal);
                }
                else if(rand.nextDouble() <= KILLERWHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    KillerWhale killerWhale = new KillerWhale(true, field, location);
                    animals.add(killerWhale);
                }
                else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    animals.add(shark);
                }
                else if(rand.nextDouble() <= TUNA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tuna tuna = new Tuna(true, field, location);
                    animals.add(tuna);
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
