import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a Seaweed.
 * seaweed age, pollinate(create new seaweeds across the field)and die.
 *
 * @version 2016.02.29 (2)
 */
public class Seaweed extends Plant
{
    // Characteristics shared by all plants (class variables).
    
    // The age at which a seaweed can start pollinating.
    private static final int POLLINATION_AGE = 72; 
    // The maximum age to which a seaweed can live. 
    private static final int MAX_AGE = 100;
    
    // Individual characteristics (instance fields).
    
    // The seaweed's age.
    private int age;
    // Random Generator
    private Random rand = new Random();
    //Maximum number of plants born through pollination of 1 plant
    private int birthsValue; // Similar to breeding probability for plants
    //Whether the seaweed is a carrier of the disease or not.
    private boolean isCarrier;
    //The probability of the seaweed acting as a carrier of the disease.
    private final int infectionChance = 17; 
    /**
     * Create a new seaweed. A seaweed may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the seaweed will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seaweed(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        
        if (randomAge)
        {
            age=rand.nextInt(MAX_AGE);
        }
        else {
            age=0;
        }
        //This gives us a random number from 0 to 49.
        int infectionEvent = rand.nextInt(50);
        //for the 'if' statement to be 'true', the infectionEvent has to be less than 17.
        //Thus, the probability of the seaweed acting as a carrier is 18/50 or 36%.
        if (infectionChance > infectionEvent)
        {
            isCarrier = true;
        }
    }
    
    /**
     * Checks the disease carrier status of the plant
     * @return true if the animal has the disease.
     */
    public boolean getIsCarrier()
    {
        return isCarrier;
    }
    
    /**
     * Increase the age. This could result in the seaweed's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * This is what the plant does most of the time: it pollinates and it doesn't move.
     * @param weather Weather object. The weather influences the birth rate through pollination.
     * @param newSeaweeds A list to return newly born seaweeds.
     */
    public void act(List<Plant> newSeaweeds, Weather weather)
    {
        incrementAge();
        
        birthsValue = 2; // the amount of births that happen through pollination 
        
        //If raining, then change birthsValue to 1
        if (!weather.getCurrentWeather().equals("rainy")) {
            birthsValue = 1;
        }
        
        if(isAlive() && age>POLLINATION_AGE) {
            pollination(newSeaweeds);            
        }
    }
    
    /**
     * Check whether or not this seaweed is to pollinate at this step.
     * New seaweeds will be made into free locations across the field.
     * @param newSeaweeds A list to return newly born seaweeds.
     */
    public void pollination(List<Plant> newSeaweeds)
    {
         //int births = rand.nextInt(birthsValue); // 0 to 2 Seaweeds will grow
         int births = birthsValue; //Stable growth
         Location location;
         Field field = getField();
         
         for(int i=0;i<births;i++)
         {
             location=field.getRandomFreeLocation();
             if (location != null)
             {
                 Plant young = new Seaweed(false, field, location);
                 newSeaweeds.add(young);
             }
             else {
                 break;
             }
         }
    }
    
}
