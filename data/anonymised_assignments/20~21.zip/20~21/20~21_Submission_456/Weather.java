import java.util.ArrayList;
import java.util.Random;

/**
 * Represents the weather in the field.
 *
 * @version 2016.02.29
 */
public class Weather
{
    // An arrayList consisting of the weathers in the form of a string
    private ArrayList <String> weatherList;
    // Current Weather in the form of a string
    private String currentWeather;
    
    /**
     * Create Weather.
     * The currentWeather is made sunny
     */
    public Weather()
    {
        weatherList = new ArrayList<>();
        createWeatherList();
        
        // The currentWeather is made sunny
        resetWeather();
    }
    
    /**
     * Create Weather. An array list of different weathers is created
     * Three types of weather are 
     * sunny,
     * foggy
     * and rainy.
     */
    private void createWeatherList()
    {
        weatherList.add("sunny");
        weatherList.add("foggy");
        weatherList.add("rainy");
    }
    
    /**
     * Changes the current weather sequentially.
     * @param indexNumber refers to the index number of the weather within the array list.
     */
    public void changeWeather(int indexNumber)
    {
        currentWeather = weatherList.get(indexNumber);
    }
    
    /**
     * @return the current weather
     */
    public String getCurrentWeather()
    {
        return currentWeather;
    }
    
    /**
     * Reset the current weather to "sunny".
     */
    public void resetWeather()
    {
        currentWeather = weatherList.get(0);
    }
    
}
