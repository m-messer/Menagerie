import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a shrimp.
 * Shrimps age, move, breed, and die.
 * There are certain factors that affect their movement, breeding ability and health.
 *
 * @version 2016.02.29 (2)
 */
public class Shrimp extends Animal
{
    // Characteristics shared by all shrimps (class variables).

    // The age at which a shrimp can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a shrimp can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a shrimp breeding.
    private static final double BREEDING_PROBABILITY = 0.55;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 19;
    // The food value of a single Seaweed for the Shrimp. In effect, this is the
    // number of steps a shrimp can go before it has to eat again.
    private static final int SEAWEED_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The shrimp's age.
    private int age;
    // The shrimp's foodlevel, which is increased by eating seaweeds.
    private int foodLevel;

    /**
     * Create a new shrimp. A shrimp may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the shrimp will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shrimp(boolean randomAge, Field field, Location location)
    {
        super(field, location,false);
        age = 0;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SEAWEED_FOOD_VALUE);
        }
        else{
            age = 0;
            foodLevel = SEAWEED_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the shrimp does most of the time - it swims and looks for seaweeds to eat 
     * around. Sometimes it will breed or die of old age.
     * @param newShrimps A list to return newly born shrimps.
     * @param weather A weather object, as the current weather affects the breeding ability of the shrimps
     */
    public void act(List<Animal> newShrimps, Weather weather)
    {
        incrementAge();
        
        if(isAlive()) {
            if (!weather.getCurrentWeather().equals("foggy") ) {
                giveBirth(newShrimps);
            }
            
            // Try to move into a location where it's food was located location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        
    }

    /**
     * Increase the age.
     * This could result in the shrimp's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Decrease the foodLevel.
     * This could result in the shrimp's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this shrimp is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newShrimps A list to return newly born shrimps.
     */
    private void giveBirth(List<Animal> newShrimps)
    {
        Field field = getField();
        // Get a list of adjacent locations.
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> iterator = adjacent.iterator();
        
        while(iterator.hasNext()) {
            Object animal = field.getObjectAt(iterator.next());
            if (animal instanceof Shrimp) {
                Shrimp adjacentShrimp = (Shrimp)animal;
                // Checks whether the gender of the adjacent rabbit is of the opposite
                if (adjacentShrimp.isMale() != isMale()) {
                    // Get a list of adjacent free locations.
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    // New shrimps are born into adjacent locations.
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Shrimp young = new Shrimp(false, field, loc);
                        newShrimps.add(young);
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        
        return births;
    }

    /**
     * A shrimp can breed if it has reached the breeding age.
     * @return true if the shrimp can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Look for seaweeds adjacent to the current location.
     * Only the first live seaweed is eaten.
     * @return Where Location where the food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Seaweed) {
                Seaweed seaweed = (Seaweed) plant;
                if(seaweed.isAlive()) { 
                    if(seaweed.getIsCarrier())
                    {
                        makeAnimalInfected();
                    }
                    seaweed.setDead();
                    foodLevel = SEAWEED_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
}
