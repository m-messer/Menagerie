
import javax.print.attribute.standard.PrinterMakeAndModel;
import javax.sound.midi.SysexMessage;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.03;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.3;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.03;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.3;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.5;
    
    private String currentWeather;

    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Current hours in the time.
    private int hours;
    // Current days in the simulation
    private int days;
    // Whether it is night or not
    private boolean night;
    // List of all possible weather types
    private List<String> weather = new ArrayList<>();
    // Whether it is rainy or not
    private boolean isRainy;
    // Whether it is sunny or not
    private boolean isSunny;
    // Whether it is foggy or not
    private boolean isFoggy;
    // Whether it is normal weather or not
    private boolean isNormal;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width); //creates the field

        // adding all possible weather options to the arraylist
        weather.add("Rainy");
        weather.add("Sunny");
        weather.add("Foggy");
        weather.add("Normal");
        // weather states are initialized
        isRainy = false;
        isSunny = false;
        isFoggy = false;
        isNormal = false;

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);
        view.setColor(Fox.class, Color.BLUE);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Deer.class, Color.YELLOW);
        view.setColor(Plant.class, Color.GREEN);
        Random rand = Randomizer.getRandom();
        // hours are initialized between 0 to 24 hours
        hours = rand.nextInt(24);
        
        
        // Setup a valid starting point.
        reset();

    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //             delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();

        // weather is changed every step
        changeWeather(weather);

        // Let all rabbits act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(night == false && animal instanceof Fox)
            {
                animal.setAsleep();  
            }
            if(night == false && animal instanceof Wolf)
            {
                animal.setAsleep();  
            }
            animal.act(newAnimals);
            if(! animal.isAlive())
            {
                it.remove();
            }
            animal.setAwake();
        }

        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);
        // Each step counts for 2 hours in the simulation   
        hours+=2;
        if(hours%24==0){
            hours = 0;
            days ++;
        }
        if (hours >= 22 || hours <= 8) {night=true;} else {night  = false;}
        Random rand = Randomizer.getRandom();
        
        currentWeather = getWeather();

        view.showStatus(step, field,hours,days,night, currentWeather);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        
        
        view.showStatus(step, field,hours,days,night, getWeather());
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer= new Deer(true, field, location);
                    animals.add(deer);
                }
                else if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant= new Plant(true, field, location);
                    animals.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Change weather based on random pick from list of weather types
     * @param weather - list of weather types
     */
    private void changeWeather(List<String> weather)
    {
        Random rand = Randomizer.getRandom();
        switch(weather.get(rand.nextInt(3))) {
            case "Sunny":
            if(night == true){
                isSunny = false;
            }
            else{
                isSunny = true;
                isRainy = false;
                isFoggy = false;
                isNormal = false;
            }
            break;
            case "Rainy" :
            isRainy = true;
            isFoggy = false;
            isSunny = false;
            isNormal = false;
            break;
            case "Foggy" :
            isFoggy = true;
            isRainy = false;
            isSunny = false;
            isNormal = false;
            break;
            case "Normal" :
            isNormal = true;
            isRainy = false;
            isFoggy = false;
            isSunny = false;    
            default:
        }

    }

    /**
     * Returns current weather type
     */
    private String getWeather()
    {
        if(isRainy == true){
            return "Rainy";
        }
        if(isSunny == true){
            return "Sunny";
        }
        if(isFoggy == true){
            return "Foggy";
        }
        else
            return "Normal";
    }
}

