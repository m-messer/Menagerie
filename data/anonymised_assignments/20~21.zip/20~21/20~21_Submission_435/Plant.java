import java.util.List;

/**
 * A super class representing the shared characteristics of Plants.
 *
 * @version 25/02/211
 */
public abstract class Plant
{
    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    
    /**
     * Create a new plants at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this plants act - that is: make it do
     * whatever it needs to do.
     * @param newplants A list to receive newly spwnaed plants.
     */
    abstract public void act(List<Plant> newPlants);

    /**
     * Check whether the plants is alive or not.
     * @return true if the plants is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the plants is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the plants's location.
     * @return The plants's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the plants at the new location in the given field.
     * @param newLocation The plants's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plants's field.
     * @return The plants's field.
     */
    protected Field getField()
    {
        return field;
    }
}
