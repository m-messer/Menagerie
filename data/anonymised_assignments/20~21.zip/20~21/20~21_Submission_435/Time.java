import java.util.Random;

/**
 * Keeps track of the time of day within the simulator.
 *
 * @version (27/02/21)
 */
public class Time
{
    // Keeps track of the hours
    private int hour;
    // Keeps track of the minutes
    private int minute;
    // The maxium minute that can be stored.
    private int maxMinute = 60;
    // 24-hour clock - prevents hour going over 23.
    private int maxHour = 23;
    
    // Randomises values.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Generates a random time.  
     */
    public Time()
    {
        // initialise instance variables
        hour = rand.nextInt(maxHour);
        minute = rand.nextInt(maxMinute);     
    }

    /**
     * Sets the minute value.
     * 
     * @param minute
     **/
    private void setMinute(int minute)
    {
        // put your code here
        this.minute = minute;

    }
    
    /**
     * Sets the hour value.
     * 
     * @param hour.
     **/
    private void setHour(int hour)
    {
        // put your code here
        this.hour = hour;
    }
    
    /**
     * Increases the minutes in incremnets of 10.
     * Each step taken evalutes to 10 minutes.
     * Checks whether minute has reached the max minute before rolling over to 0.
     **/
    public void increaseMinute() {
        minute = minute + 10;
        if (minute > maxMinute) {
            minute = minute - maxMinute;
            increaseHour();
        } else if (minute == maxMinute) {
            increaseHour();
            minute = 0;
        }
    }
    
    /**
     * Increases the hour value.
     * Rolls over if max minute has been reached. 
     * 
     **/
    public void increaseHour() {
        if (hour != maxHour) {
            hour++;
        } else {
            hour = 0;
        }
    }
    
    /**
     * Formats the time in the form HH:MM.
     * If hour/minute is less single digit, add '0'.
     * 
     * @Return timeString time is displayed in a string.
     **/
    
    public String getTime() {
        
        // Strings to store the minutes and hours.
        String minuteString;
        String hourString;
        
        // Add '0' if minute is less than 10
        if (minute < 10) {
            minuteString = "0" + minute;
        } else {
            minuteString = "" + minute;
        }
        
        // Add '0' if hour is less than 10.
        if (hour < 10) {
            hourString = "0" + hour;
        } else {
            hourString = "" + hour;
        }
        
        // adds minute string and hour string in standard time format.
        String timeString = hourString + ":" + minuteString;
        return timeString;
    }
    
    /**
      *The range of time in which the predators are active.
      *
      *@Return True if the current simulator time is within this range
       **/
    public Boolean activePreyHours() {
        
        if (hour >= 9 && hour <= 21) {
            return true;
        }
        return false;
    }
    
    /**
     * The range of time in which the preys are active.
     * 
     * @Return True if the current simulator time is within this range
       **/
    public Boolean activePredatorHours() {
        
        if ((hour >= 15 && hour <= 23) || (hour >= 0 && hour <= 3)) {
            return true;
        }
        return false;
    }

}
