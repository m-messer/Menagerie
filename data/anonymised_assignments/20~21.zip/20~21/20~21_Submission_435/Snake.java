import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a snake.
 * snakees age, move, eat Monkeys and Birds, and die.
 *
 * @version 23.02.2021
 */
public class Snake extends Animal
{
    // Characteristics shared by all snakees (class variables).

    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a snake can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.40;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single Monkey and Bird for a snake. In effect, this is the
    // number of steps a snake can go before it has to eat again.
    private static final int BIRD_FOOD_VALUE = 100;
    private static final int MONKEY_FOOD_VALUE = 150;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The maximum gender that can be represented. Male(0) and Female(1)
    private static final int MAX_GENDER = 2;

    // Individual characteristics (instance fields).
    // The snake's age.
    private int age;
    // The snake's food level, which is increased by eating Monkeys and Birds.
    private int foodLevel;
    // The snake's gender
    private int gender;

    private Time time;
    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time the current time within the simulation.
     */
    public Snake(boolean randomAge, Field field, Location location, Time time)
    {
        super(field, location);
        this.time = time;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(BIRD_FOOD_VALUE) + rand.nextInt(MONKEY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = BIRD_FOOD_VALUE + MONKEY_FOOD_VALUE;
        }

        gender = rand.nextInt(MAX_GENDER);
    }

    /**
     * This is what the snake does most of the time: it hunts for
     * Monkeys and Birds. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newsnakees A list to return newly born snakees.
     */
    public void act(List<Animal> newSnakes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && time.activePredatorHours()) {

            if (findMate()) {
                giveBirth(newSnakes);
            }
            // Move towards a source of food if found.

            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the snake's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this snake more hungry. This could result in the snake's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Monkeys and Birds adjacent to the current location.
     * Only the first live Monkeys and Bird is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bird) {
                Bird bird = (Bird) animal;
                if(bird.isAlive()) { 
                    bird.setDead();
                    foodLevel = BIRD_FOOD_VALUE;
                    return where;
                }
            } else if (animal instanceof Monkey) {

                Monkey monkey = (Monkey) animal;
                if(monkey.isAlive()) { 
                    monkey.setDead();
                    foodLevel = MONKEY_FOOD_VALUE;
                    return where;
                }

            }
        }
        return null;
    }

    /**
     * Check whether or not this snake is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newsnakees A list to return newly born snakees.
     */
    private void giveBirth(List<Animal> newSnake)
    {
        // New snakees are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Snake young = new Snake(false, field, loc, time);
            newSnake.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A snake can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Retrives the gender of the snake.
     * 
     * @return gender
     */
    private int getGender()
    {
        return gender;
    }

    /**
     * identifies whether this snake is a female and of breeding age 
     * and the adjacent snake in the neighbouring cell is a male and of breeding age 
     * within the same species. Where female == 1 and male is == 0.
     * @return true if neighbouring cell contains a potential mate which is male.
     */
    private Boolean findMate() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if((getGender() == 1) && (snake.getGender() == 0) && (snake.canBreed())) { 
                    return true;
                }
            }
        }
        return false;   
    }
}
