import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a flower.
 * Flowers grow, spawn, and dies.
 * @version 25.02.2021
 */
public class Flower extends Plant
{
    // Characteristics shared by all flowers (class variables).

    // The age at which a flower can start to 'spawn'.
    private static final int SPAWNING_AGE = 15;
    // The age to which a flower can live.
    private static final int MAX_AGE = 144;
    // The likelihood of a flower spawning.
    private static final double SPAWNING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control spawning.
    private static final Random rand = Randomizer.getRandom();

    
    // Individual characteristics (instance fields)
    // The flower's age.
    private int age;
    
    private Time time;
   

    /**
     * Create a new flower. A flower may be created with age
     * zero (a seedling) or with a random age.
     * 
     * @param randomAge If true, the flower will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time the current time of the simulation
     */
    public Flower(boolean randomAge, Field field, Location location, Time time)
    {  
       super(field, location);
       this.time = time;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;  
        }
    }
    
    /**
     * This is what the flower does most of the time. It Grows(ages) 
     * spawns or dies.
     * @param newFlowers A list to return newly spawned flowers.
     */
    public void act(List<Plant> newFlowers)
    {
        incrementGrowth();
        // flowers have the same active hours as the preys. 
        // They only spawn during the day.
        if(isAlive() && time.activePreyHours()) {
            spawn(newFlowers);        
        }
    }

    /**
     * Increase the 'age'.
     * This could result in the flower's death.
     */
    private void incrementGrowth()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this flower can spawn at this step.
     * New 'births' will be made into free adjacent locations.
     * @param newFlowers A list to return newly created flowers.
     */
    private void spawn(List<Plant> newFlower)
    {
        // New flowers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Flower young = new Flower(false, field, loc, time);
            newFlower.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of 'births',
     * if its of spawning age.
     * @return The number of 'births' (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canSpawn() && rand.nextDouble() <= SPAWNING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A flower can spawn if it has reached the spawning age
     * @return true if the flower can spawn, false otherwise.
     */
    private boolean canSpawn()
    {
        return age >= SPAWNING_AGE;
    }
    
 }

