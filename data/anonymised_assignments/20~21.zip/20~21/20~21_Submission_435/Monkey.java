import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Monkey.
 * Monkeys age, move, breed, and die.
 *
 * @version 23.02.2021
 */
public class Monkey extends Animal
{
    // Characteristics shared by all Monkeys (class variables).

    // The age at which a Monkey can start to breed.
    private static final int BREEDING_AGE = 18;
    // The age to which a Monkey can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a Monkey breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single flower for a monkey. In effect, this is the
    // number of steps a bird can go before it has to eat again.
    private static final int FLOWER_FOOD_VALUE = 100;
    // The maximum gender that can be represented. Male(0) and Female(1)
    private static final int MAX_GENDER = 2;

    // Individual characteristics (instance fields).
    // The Monkey's age.
    private int age;
    // The Monkey's food level, which is increased by eating Monkeys.
    private int foodLevel;
    // The gender of the Monkey. Male(0) and Female(1).
    private int gender;
    
    private Time time;

     /**
     * Create a new Monkey. A Monkey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Monkey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time The current time of the simulation
     */
    public Monkey(boolean randomAge, Field field, Location location, Time time)
    {
        super(field, location);
        this.time = time;

        if(randomAge) {
            foodLevel = rand.nextInt(FLOWER_FOOD_VALUE);
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
            foodLevel = FLOWER_FOOD_VALUE;
        }
        
        gender = rand.nextInt(MAX_GENDER);
    }

     /**
     * This is what the Monkey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMonkeys A list to return newly born Monkeys.
     */
    public void act(List<Animal> newMonkey)
    {
        incrementAge();
        if(isAlive() && time.activePreyHours()) {

            if (findMate()) {
                giveBirth(newMonkey);
            }
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Monkey's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Monkey more hungry. This could result in the Monkey's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for Monkeys adjacent to the current location.
     * Only the first live Monkey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Flower) {
                Flower flower = (Flower) plant;
                if(flower.isAlive()) { 
                    flower.setDead();
                    foodLevel = FLOWER_FOOD_VALUE;
                    return where;
                }

            }     
        }
        return null;
    }

    /**
     * Check whether or not this Monkey is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMonkeys A list to return newly born Monkeys.
     */
    private void giveBirth(List<Animal> newMonkey)
    {
        // New Monkeys are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Monkey young = new Monkey(false, field, loc, time);
            newMonkey.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Monkey can breed if it has reached the breeding age.
     * @return true if the Monkey can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * @return gender the animals gender.
     */
    private int getGender()
    {
        return gender;
    }
    
    /**
     * identifies whether this monkey is a female and of breeding age 
     * and the adjacent monkey in the neighbouring cell is a male and of breeding age 
     * within the same species. Where female == 1 and male is == 0.
     * @return true if neighbouring cell contains a potential mate which is male.
     */
    private Boolean findMate() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Monkey) {
                Monkey monkey = (Monkey) animal;
                if((getGender() == 1) && (monkey.getGender() == 0) && (monkey.canBreed())) { 
                    return true;
                }
            }
        }
        return false;   
    }
}
