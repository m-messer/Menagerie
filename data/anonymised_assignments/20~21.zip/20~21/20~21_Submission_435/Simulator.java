import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Snakes, Tigers, Wild Pigs, Birds and Monkey.
 *
 * @version 23/02/2021
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.01;   // The food value of a single flower. In effect, this is the
    // number of steps a bird can go before it has to eat again.
    // The probability that a tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.01;
    // The probability that a wild pigs will be created in any given grid position.
    private static final double WILDPIG_CREATION_PROBABILITY = 0.05;
    // The probability that a bird will be created in any given grid position.
    private static final double BIRD_CREATION_PROBABILITY = 0.05;
    // The probability that a monkey will be created in any given grid position.
    private static final double MONKEY_CREATION_PROBABILITY = 0.05;
    // The probability that a flower will be created in any given grid position.
    private static final double FLOWER_CREATION_PROBABILITY = 0.10;
    

    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    // The time of the simulation
    private Time time;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        time = new Time();
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, time);
        view.setColor(Bird.class, Color.BLUE);
        view.setColor(WildPig.class, Color.PINK);
        view.setColor(Snake.class, Color.GREEN);
        view.setColor(Monkey.class, Color.RED);
        view.setColor(Tiger.class, Color.ORANGE);
        view.setColor(Flower.class, Color.YELLOW);
       

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // slows down how fast simulation runs.
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * predator, prey and plants.
     */
    public void simulateOneStep()
    {
        // increases the step
        step++;
        // increases the current time of simulation.
        time.increaseMinute(); 
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Provide space for new plants.
        List<Plant> newPlants = new ArrayList<>();
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        // Let all plants act.
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
        

        // Add the newly born predator and prey to the main lists.
        animals.addAll(newAnimals);
        // Add the new plants to the main lists.
        plants.addAll(newPlants);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with predators and preys.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location,time);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location, time);
                    animals.add(tiger);
                }
                 else if(rand.nextDouble() <= WILDPIG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    WildPig wildPig = new WildPig(true, field, location, time);
                    animals.add(wildPig);
                }
                 else if(rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bird bird = new Bird(true, field, location, time);
                    animals.add(bird);
                }
                 else if(rand.nextDouble() <= MONKEY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Monkey monkey = new Monkey(true, field, location, time);
                    animals.add(monkey);
                }
                else if(rand.nextDouble() <= FLOWER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Flower flower = new Flower(true, field, location, time);
                    plants.add(flower);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
