import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Wild pig.
 * Wild Pigs age, move, breed, die and eat.
 *
 * @version 23.02.2021
 */
public class WildPig extends Animal
{
    // Characteristics shared by all Wild Pigs (class variables).

    // The age at which a Wild Pig can start to breed.
    private static final int BREEDING_AGE = 18;
    // The age to which a Wild Pig  can live.
    private static final int MAX_AGE = 144;
    // The likelihood of a Wild Pig breeding.
    private static final double BREEDING_PROBABILITY = 0.24;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom(); 
    // The food value of a single flower for a pig. In effect, this is the
    // number of steps a bird can go before it has to eat again.
    private static final int FLOWER_FOOD_VALUE = 100;
    // The maximum amount of genders that can be represented 0(Male) and 1(Female).
    private static final int MAX_GENDER = 2;
    
    // indiviual characteristics.
    // Stores the gender ID.
    private int gender;
    // The Wild Pig's age.
    private int age;  
    // The Wild pigs's food level, which is increased by eating Flowers.
    private int foodLevel;
    
    private Time time;

    /**
     * Create a new Wild Pig . A Wild Pig  may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Wild Pig  will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param time the current time within the simualtion.
     */
    public WildPig(boolean randomAge, Field field, Location location, Time time)
    {
        super(field, location);
        this.time = time;

        if(randomAge) {
            foodLevel = rand.nextInt(FLOWER_FOOD_VALUE);
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
            foodLevel = FLOWER_FOOD_VALUE;
        }
        
        gender = rand.nextInt(MAX_GENDER);
    }

    /**
     * This is what the Wild Pig  does most of the time - it runs 
     * around. Sometimes it will breed, die and eat.
     * @param newWildPig A list to return newly born Wild Pigs.
     */
    public void act(List<Animal> newWildPig)
    {
        incrementAge();
        
        // Check whether prey is alive and current simulator time is within range of their 
        // active hours.
        if(isAlive() && time.activePreyHours()) {
            if (findMate()) {
                giveBirth(newWildPig);  
            }
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the Wild Pig's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Wild pig more hungry. This could result in the Wild Pig's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
      /**
     * Look for Flowers adjacent to the current location.
     * Only the first live Flower is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Flower) {
                Flower flower = (Flower) plant;
                if(flower.isAlive()) { 
                    flower.setDead();
                    foodLevel = FLOWER_FOOD_VALUE;
                    return where;
                }

            }     
        }
        return null;
    }

    /**
     * Check whether or not this Wild Pig is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWild Pig s A list to return newly born Wild Pigs.
     */
    private void giveBirth(List<Animal> newWildPig)
    {
        // New Wild Pigs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            WildPig young = new WildPig(false, field, loc, time);
            newWildPig.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Wild Pig can breed if it has reached the breeding age.
     * @return true if the Wild Pig can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    /**
     * @return gender the gender of the wild pig.
     */
    private int getGender()
    {
        return gender;
    }

    /**
     * identifies whether this wildPig is a female and of breeding age 
     * and the adjacent wildPig in the neighbouring cell is a male and of breeding age 
     * within the same species. Where female == 1 and male is == 0.
     * @return true if neighbouring cell contains a potential mate which is male.
     */
    private Boolean findMate() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof WildPig) {
                WildPig wildPig = (WildPig) animal;
                if((getGender() == 1) && (wildPig.getGender() == 0) && (wildPig.canBreed())) { 
                    return true;
                }
            }
        }
        return false;   
    }
}
