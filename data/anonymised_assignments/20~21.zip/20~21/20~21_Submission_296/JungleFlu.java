import java.util.Random;
/**
 * 
 * A simple model of Jungle flu disease
 *
 * 
 * @version 2021.03.01
 */
public class JungleFlu implements Disease
{
    // instance variables - replace the example below with your own
    private double spreadRate = 0.8;
    private double DISEASE_CREATION_PROBABILITY = 0.000005;
    private double DISEASE_CARRY_ON = 0.3;
    //Static variable represent if disease is presenting in the ecosystem
    private static boolean disease = false;
    private Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Disease
     */
    public JungleFlu()
    {
        //empty
    }

    /**
     * @return spreadRate, spread rate of the disease
     */
    public double getSpreadRate()
    {
        return spreadRate;
    }

    /**
     * A random generator to see for disease to start
     * 
     */public boolean diseasePossibility()
    {
        if(rand.nextDouble() <= DISEASE_CREATION_PROBABILITY)
        {
            return true;
        }else{
            return false;
        }
    }

    /**
     * @return disease, checking if disease is currently spreaded in simulator
     */
    public boolean getDisease()
    {
        return disease;
    }

    /**
     * Disease disappear from simulator
     */
    public void diseaseReset()
    {
        disease = false;
    }

    /**
     * A random generator of chance an animal can survive on disease
     */
    public boolean cured()
    {
        if (rand.nextDouble() <= DISEASE_CARRY_ON)
        {
            return true;
        }else{
            return false;
        }

    }

    /**
     * Disease starts
     */
    public void diseaseOccurs()
    {
        disease = true;
    }

}
