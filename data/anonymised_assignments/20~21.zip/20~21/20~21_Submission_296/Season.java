
/**
 * This class represents characteristic of a season.
 *
 * 
 * @version 2021.03.01
 */
public abstract class Season
{

     /**
      * Make a specific current season
      */
     abstract protected void currentSeason();

     /**
      * Change the season 
      */
     abstract protected void changeSeason();

     /**
      * get the current season
      */
     abstract protected boolean getSeason();
}
