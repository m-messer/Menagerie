import java.util.Random;
/**
 * This class represents characteristic of a season.
 *
 * 
 * @version 2021.03.01
 */
public abstract class Weather
{
   protected Random rand = Randomizer.getRandom();
    
   /**
    * get the measurement unit depending on the weather
    */
   abstract protected double getMeasureUnit();
    
   /**
    * get the duration of the weather that is happening
    */
   abstract protected int getMinute();
   
   /**
    * The chance of a specific weather occuring
    */
   abstract protected boolean possibility();
   
   /**
    * Probability of living thing being dead due to weather, especially
    * plants
    */
   public boolean loseLife()
   {
        if(rand.nextDouble() <= getLostProbability())
        {
            return true;
        }else{
            return false;
        }
   }
   
   /**
    * The probability of something losing their life to the weather
    */
   abstract protected double getLostProbability();
   
   /**
    * Get the current weather
    */
   abstract protected boolean getWeather();
   
   /**
    * Set weather back to default weather
    */
   abstract protected void backNormal();
}
