
/**
 * This class represents characteristic of a Winter.
 * A simple model of Winter
 * This is the class that make the season become Winter.
 * Changing state of season to Winter
 *
 * 
 * @version 2021.03.01
 */
public class Winter extends Season
{
    // instance variables - replace the example below with your own
    private static boolean isWinter = false;
    protected Weather rain = new Rain();

    /**
     * Constructor for objects of class Winter
     */
    public Winter()
    {
        //empty
    }

    /**
     * Change the season to winter
     */
    public void currentSeason() {
        isWinter = true;
    }

    /**
     * Change season because winter is finished
     */
    public void changeSeason() {
        isWinter = false;
    }

    /**
     * @return true, if winter is the current season
     */
    public boolean getSeason() {
        return isWinter;
    }
}
