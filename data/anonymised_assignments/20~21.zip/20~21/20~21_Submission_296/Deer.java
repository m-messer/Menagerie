import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * This class represents characteristic of a Deer.
 * A simple model of a Deer.
 * Deers eat plant only such as Grass
 * Deers age, move, breed, and die.
 *
 * 
 * @version 2021.03.01
 */
public class Deer extends Prey
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 600;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private static final int MAX_FOOD_LEVEL = 90 ;

    private static final int DEER_FOOD_VALUE = 40;
    // Individual characteristics (instance fields).

    /**
     * Create a new Deer. A Deer may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location,boolean gender,boolean haveDisease)
    {
        super(randomAge, field, location, gender,haveDisease);
         
    }

    /**
     * @return MAX_AGE, max age of Deer
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return BREEDING_PROBABILITY , breeding probability of Deer
     * In other words, chance of it giving new born Deer
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return MAX_LITTER_SIZE, max litter size of this Deer when
     * giving birth while mating
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return BREEDING_AGE, age this Deer has to reached before
     * it can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return foodLevel, food level of this Deer. In effects,
     * the step this Deer has left before it has to eat again
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * @return DEER_FOOD_VALUE The value that a predator that eat a deer
     * will consumed and be added to the predator's food level
     */
    protected int getFoodValue()
    {
        return DEER_FOOD_VALUE;
    }
    
    /**
     * @return MAX_FOOD_LEVEL, max food level of Deer
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return haveDisease The status of this Deer having
     * disease or not
     */
    protected boolean getAnimalDisease()
    {
        return haveDisease;
    }
    
    /**
     * Create new instance of this Deer
     * In other words, a new born baby of this Deer
     * @param field The field that it will be born to
     * @param loc the Location of the field
     */
    protected Animal getAnimal(Field field, Location loc)
    {
       Deer young = new Deer(false, field, loc, super.randomGender(),false);
       return young;
    }

}
