import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of predator. 
 *
 * 
 * @version 2021.03.01
 */
public abstract class Predator extends Animal
{

    /**
     * Constructor for objects of class Predator
     */
    public Predator(boolean randomAge,Field field, Location location, boolean gender,boolean haveDisease)
    {
        super(randomAge,field, location,gender,haveDisease);
    }
    
    /**
     * Check the time, if Night time, sleeping will occur
     * @return true, if night time
     * @return false, if day time
     */
    protected boolean nightTime()
    {
        //only some predator of that specific animal type sleeps
        if (!Time.dayTime() && rand.nextBoolean())
        {
            return true;
        }
        else{
            return false;
        }        
    }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = super.getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()){ 
                    if (prey.getFoodValue() <= (getMaxFoodLevel() - foodLevel))
                    {
                    prey.setDead();
                    foodLevel = prey.getFoodValue();
                    return where;
                    }
                }
            }
        }
        return null;
    }
}
