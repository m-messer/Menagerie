
/**
 * A simple model of Time
 *
 * 
 * @version 2021.03.01
 */
public class Time
{
    // instance variables - replace the example below with your own
    private static boolean dayTime = false;
    private static int hour = 0;
    private static int minute = 0;
    private final static int maxMinutes = 60;
    private final static int maxHours = 23;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        //empty
    }

    /**
     * A static method that return the period of the day if it is
     * day or night time
     * @return dayTime True if it is day time
     */
    public static boolean dayTime()
    {
        return dayTime;
    }
    
    /**
     * @return hour The hour of the day
     */
    public static int getTime()
    {
        return hour;
    }
    
    /**
     * @return minute The minute of the hour
     */
    public static String getMinute()
    {
        if (minute < 10)
        {
          return "0" + minute;  
        }else
        {
          return "" + minute;
        }
    }

    /**
     * Increment the time as each step increment
     * Simulate time for the simulator
     * From 0 to 23 in term of hours
     */
    public static void incrementTime()
    {
    minute = minute + 50;
        if (minute >= maxMinutes)
    {
       minute = minute % maxMinutes;
       if (hour >= maxHours)
        {
           hour = hour % maxHours;
        }
        else{
           hour++;
       }
    }
       
    dayNight();
    }
    
    /**
     * Change the state of the day whether it is day or night
     */
    private static void dayNight()
    {
        if (hour < 6)
        {
            dayTime = false;
        }else if (hour >= 6 && hour < 19 )
        {
            dayTime = true;
        }else if (hour >= 19)
        {
            dayTime = false;
        }
    }
    
    /**
     * Reset the time to 0
     */
    public static void timeReset()
    {
        hour = 0;
        minute = 0;
    }
}
