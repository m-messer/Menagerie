import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.Random;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Lion, Alligator, Hyena, Deer, Giraffes, and Zebra.
 *
 * 
 * @version 2021.03.01 (3)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.012;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.05;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.25;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.008;
    // The probability that a giraffes will be created in any given grid position.
    private static final double GIRAFFES_CREATION_PROBABILITY = 0.07;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.07;
    // The probability that an alligator will be created in any given grid position.
    private static final double ALLIGATOR_CREATION_PROBABILITY = 0.008;

    // List of animals in the field.
    private List<LivingThing> LivingThings;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //The current living thing
    private LivingThing theLivingThing;

    private Weather rain = new Rain();
    private Weather sun = new Sunny();

    private static final Random rand = Randomizer.getRandom();
    //Keep track of number of step of weather
    private int weatherCounter = 0;

    private Season summer = new Summer();
    private Winter winter = new Winter();

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        Time.timeReset();
    }

    /**
     * main method to run a long simulation
     */
    public static void main(String[] args)
    {
        Simulator simulator = new Simulator();
        simulator.runLongSimulation();
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        LivingThings = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);//, this);
        view.setColor(Zebra.class, Color.RED);
        view.setColor(Hyena.class, Color.BLUE);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Lion.class, Color.MAGENTA);
        view.setColor(Giraffes.class, Color.BLACK);
        view.setColor(Deer.class, Color.CYAN);
        view.setColor(Alligator.class, Color.ORANGE);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
       for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);
            // uncomment this to run more slowly
        }
     }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * livingThing that is animal and plant.
     */
    public void simulateOneStep()
    {
        step++;
        //increment the time at each step
        Time.incrementTime();
        //Getting a random generated season for this step
        getSeason();

        // Provide space for newborn animals.
        List<LivingThing> newLivingThing = new ArrayList<>();        
        // Let all living thing act.
        for(Iterator<LivingThing> it = LivingThings.iterator(); it.hasNext(); ) {
            LivingThing livingThing = it.next();
            livingThing.act(newLivingThing);

            if(! livingThing.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animal and newly grow plant to the main lists.
        LivingThings.addAll(newLivingThing);

        view.showStatus(step, field, Time.getTime());

    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        LivingThings.clear();
        populate();
        //reset the time
        Time.timeReset();

        // Show the starting state in the view.
        view.showStatus(step, field, 0);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(true, field, location,rand.nextBoolean(),false);
                    LivingThings.add(hyena);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location,rand.nextBoolean(),false);
                    LivingThings.add(zebra);
                }else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Grass(field, location);
                    LivingThings.add(plant);
                }
                else if (rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true,field, location,rand.nextBoolean(),false);
                    LivingThings.add(lion);
                }
                else if (rand.nextDouble() <= GIRAFFES_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Giraffes giraffes = new Giraffes(true,field, location,rand.nextBoolean(),false);
                    LivingThings.add(giraffes);
                }
                else if (rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true,field, location,rand.nextBoolean(),false);
                    LivingThings.add(deer);
                }
                else if (rand.nextDouble() <= ALLIGATOR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Alligator alligator = new Alligator(true,field, location,rand.nextBoolean(),false);
                    LivingThings.add(alligator);
                }

                // else leave the location empty.
            }
        }
    }

     /**
     * Generate a random chance of weather to be rain
     * If it is raining and it reached raining duration or it has become summer
     * then put the rain back to default weather
     */
    private void raining() {
        weatherCounter++;
        
        //when raining reaches its random generated duration, it is back to normal weather
        if (rain.getWeather() && (weatherCounter > rain.getMinute()))
        {
            rain.backNormal();
        }
        
        if(summer.getSeason())
        {
            rain.backNormal();
        }
        
        if (!(rain.getWeather()))
        {
            int temp = rand.nextInt(100);
            weatherCounter = 0;
            if (temp <= 40)
            {
                rain.possibility();
            }
        }
    }

    /**
     * Generate a random chance of weather to be sunny
     * If it is raining and it reached sunny duration or it has become winter
     * then put the sunny weather back to default weather
     */
    private void sunShine() {
        weatherCounter++;
        //when sunny weather reaches its random generated duration, it is back to normal weather
        if(sun.getWeather() && (weatherCounter > sun.getMinute()))
        {
            sun.backNormal();  
        }
        
        if(winter.getSeason())
        {
            sun.backNormal();  
        }
        
        if (!Time.dayTime())
        {
            sun.backNormal();  
        }
        
        if (!(sun.getWeather()))
        {
            int temp = rand.nextInt(100);
            weatherCounter = 0;
            if (temp >= 60){//>= 34 && temp <= 66) {
                sun.possibility();
            }
        }
    }

    /**
     * This method implements the season winter or summer
     * The duration of summer and winter is implemented in this method
     */
    private void season() {
        int temp = step;
        temp = temp % 100;
        //Changing of season in term of step
        if (temp < 80) {
            summer.currentSeason();
            winter.changeSeason();
        }
        else {
            winter.currentSeason();
            summer.changeSeason();
        }
    }

     /**
     * This check what season it is in simulator and avoid season crashing
     * to each other
     */
    private void getSeason() {
        season();
        if (winter.getSeason()) {
            sun.backNormal();
            raining();
        }
        else {
            rain.backNormal();
            sunShine();
        }
    }

     /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

}
