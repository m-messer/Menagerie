
/**
 * This interface represents characteristic of a disease.
 *
 * 
 * @version 2021.03.01
 */
public interface Disease
{
    double getSpreadRate();
    
    boolean diseasePossibility();
    
    boolean getDisease();
    
    void diseaseReset();
    
    boolean cured();
    
    void diseaseOccurs();
}
