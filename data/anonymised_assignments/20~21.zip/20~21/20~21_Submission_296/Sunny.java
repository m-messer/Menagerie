import java.util.Random;
/**
 * This class represents characteristic of a Sunny.
 * A simple model of Sunny
 * This is the class that make the weather to be sunny.
 * Changing state of weather to sunny
 *
 * 
 * @version 2021.03.01
 */
public class Sunny extends Weather
{
    // instance variables - replace the example below with your own
    private double temperature;

    private int minute;

    private static boolean sunny;

    private final static double sun_probability = 0.02;

    private final static double lost_probability = 0.9;

    public Sunny()
    {
        //empty
    }

    /**
     * @return temperature, measured in degree Celcius
     */
    public double getMeasureUnit()
    {
        return temperature;
    }

    /**
     * @return minute
     */
    public int getMinute()
    {
        return minute;
    }

    /**
     * A random generator if it will be sunny or not
     */
    public boolean possibility()
    {
        sunny = false;
        if(rand.nextDouble() <= sun_probability)
        {
         sunny = true;
         //randomise the duration of the sun
         minute = rand.nextInt(300) + 1;
         //randomise the temperate of the sun
         temperature = rand.nextDouble() + rand.nextInt(10) + 30;
        }else{
            sunny = false;
        }
        return sunny;
    }
    
    /**
     * @return lost_probability, the probability of losing lives to 
     * sunny weather
     */
    public double getLostProbability()
    {
        return lost_probability;
    }

    /**
     * @return raining, checking if it rains
     */
    public boolean getWeather()
    {
        return sunny;
    }
    
    /**
     * Reset the weather to normal
     */
    public void backNormal()
    {
        sunny = false;
    }

}
