import java.util.Random;
/**
 * This class represents characteristic of a Rain.
 * A simple model of Rain
 * This is the class that make the weather rains.
 * Changing state of weather to rain.
 *
 * 
 * @version 2021.03.01
 */
public class Rain extends Weather
{
    // instance variables - replace the example below with your own
    private int precipitation;

    private int minute;

    private static boolean raining;

    private final static double raining_probability = 0.1;

    private final static double lost_probability = 0.2;//0.05;

    /**
     * Constructor for objects of class Rainy
     */
    public Rain()
    {
        //empty
    }

     /**
     * @return precipitation, measured in inches
     */
    public double getMeasureUnit()
    {
        return precipitation;
    }

     /**
     * @return minute, raining duration
     */
    public int getMinute()
    {
        return minute;
    }

    /**
     * A random generator if it will rain or not
     */
    public boolean possibility()
    {
        raining = false;
        if(rand.nextDouble() <= raining_probability)
        {
            raining = true;
            //randomise the duration of the rain
            minute = rand.nextInt(300) + 1; 
            //randomise the preciptation of the rain
            precipitation = rand.nextInt(80) + 1;
        }else{
            raining = false;
        }
        return raining;
    }
    
    /**
     * @return lost_probability, the probability of losing lives to 
     * raining weather
     */
    public double getLostProbability()
    {
        return lost_probability;
    }

    /**
     * @return raining, checking if it rains
     */
    public boolean getWeather()

    {
         return raining;
    }
    
    /**
     * Reset the weather to normal
     */
    public void backNormal()
    {
        raining = false;
    }
}
