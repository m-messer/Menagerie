import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

/**
 * This class represents characteristic of a Giraffe.
 * A simple model of a Giraffe.
 * Giraffes eat plant only such as Grass
 * Giraffes age, move, breed, and die.
 *
 * 
 * @version 2021.03.01
 */
public class Giraffes extends Prey
{
    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a fox can live.
    private static final int MAX_AGE = 700;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 20;
    
    private static final int MAX_FOOD_LEVEL = 90 ;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int GIRAFFE_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Giraffes. A Giraffes can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Giraffes will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Giraffes(boolean randomAge, Field field, Location location,boolean gender,boolean haveDisease)
    {
        super(randomAge,field, location,gender,haveDisease);
        
    }

    /**
     * @return MAX_AGE, max age of Giraffes
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return BREEDING_PROBABILITY , breeding probability of Giraffes
     * In other words, chance of it giving new born Giraffes
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return MAX_LITTER_SIZE, max litter size of Giraffes when
     * giving birth while mating
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return BREEDING_AGE, age Giraffes has to reached before
     * it can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return foodLevel, food level of Giraffes. In effects,
     * the step Giraffes has left before it has to eat again
     */
    protected int getFoodLevel()
     {
        return foodLevel;
     }
    
    /**
     * @return GIRAFFE_FOOD_VALUE The value that a predator that eat a giraffe
     * will consumed and be added to the predator's food level
     */
    protected int getFoodValue()
    {
        return GIRAFFE_FOOD_VALUE;
    }
    
    /**
     * @return MAX_FOOD_LEVEL, max food level of Giraffes
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return haveDisease The status of Giraffes having
     * disease or not
     */
    protected boolean getAnimalDisease()
    {
        return haveDisease;
    }
    
    /**
     * Create new instance of Giraffes
     * In other words, a new born baby of Giraffes
     * @param field The field that it will be born to
     * @param loc the Location of the field
     */
    protected Animal getAnimal(Field field, Location loc)
    {
       Giraffes young = new Giraffes(false, field, loc, super.randomGender(),false);
       return young;
    }
}
