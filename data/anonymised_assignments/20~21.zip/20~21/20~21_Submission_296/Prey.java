import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of prey.
 *
 * 
 * @version 2021.03.01
 */
public abstract class Prey extends Animal
{

    /**
     * Constructor for objects of class Prey
     */
    public Prey(boolean randomAge,Field field, Location location, boolean gender,boolean haveDisease)
    {
        super(randomAge, field, location,gender,haveDisease);
    }
    
    /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * It also eat plants
     * @param newPreys A list to return newly born preys.
     */
    public void act(List<LivingThing> newPreys)
    {
        super.incrementAge();
        //check if they got disease
        super.checkDisease();
        super.incrementHunger();
        if(isAlive()) {
            super.mating(newPreys);
            // Try to move into a free location.
            Location newLocation = findFood();
            mating(newPreys);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = super.getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant) {
                Plant thePlant = (Plant) plant;
                if(thePlant.isAlive()) { 
                    if (thePlant.getFoodValue() <= (getMaxFoodLevel() - foodLevel))
                    {
                    if(thePlant.getHeight() >= 2)
                    {
                        foodLevel = thePlant.getFoodValue();
                        //extra portion since the height is greater
                        foodLevel++; 
                    }else{
                        foodLevel = thePlant.getFoodValue();
                    }
                    thePlant.setDead();
                    return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Get food value of this animal
     */
    abstract protected int getFoodValue();

}
