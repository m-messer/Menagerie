import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 */
public abstract class Animal extends LivingThing

{
    protected boolean isMale;
    // The animal's age, which increased over time
    protected int age;
    // The animal's food level, which is increased by eating what it hunts.
    protected int foodLevel;
    //Disease that animal can be infected
    protected Disease disease = new JungleFlu();

    protected Weather rain = new Rain();

    protected Random rand = new Random();
    //All animal can have a disease
    protected boolean haveDisease;

    protected Animal(boolean randomAge, Field field, Location location, boolean gender, boolean haveDisease )
    {
        super(field, location);
        isMale = gender;
        this.haveDisease = haveDisease;
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(getMaxFoodLevel());
        }
        else {
            age = 0;
            foodLevel = getMaxFoodLevel();
        }
    }

    /**
     * Getting each animal's food level
     */
    abstract protected int getFoodLevel();
    
    /**
     * Getting each animal's max food level
     */
    abstract protected int getMaxFoodLevel();

    /**
     * if true, then it is a male
     * @return true or false, randomise gender for animals
     */
    protected boolean randomGender()
    {
        return rand.nextBoolean();
    }

    /**
     * @return isMale Gender of the animal, true if it is a Male
     */
    protected boolean getGender()
    {
        return isMale;
    }

    /**
     * Make the animal more hungry. This could result to the death of the animal.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
   

    /**
     * Getting animal's max age
     */
    abstract protected int getMaxAge();

    /**
     * Increase the age. This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Getting animal's breeding probability
     */
    abstract protected double getBreedingProbability();

    /**
     * Getting animal's litter size
     */
    abstract protected int getMaxLitterSize();

    /**
     * Getting animal's breeding age
     */
    abstract protected int getBreedingAge();

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age.
     * @return true, if this animal's age is greater than breeding age
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * This method is used to create a new animal, essentially new born 
     * animal for each specific species
     */
    abstract protected Animal getAnimal(Field field, Location loc);

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBorn animal A list to return newly born animals.
     */
    protected void giveBirth(List<LivingThing> newBabies)
    {
        // New animal are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = getAnimal(field, loc);
            newBabies.add(young);
        }
    }

    /**
     * Checking if male and female of this animal meet
     * if meet, able to give birth for a new born animal
     */
    protected Location mating(List<LivingThing> newBabies)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            String theAnimal = this.getClass().getSimpleName();

            if (animal instanceof Animal)
            {
                Animal animals = (Animal) animal;
                if (animal.getClass().getSimpleName().equals(theAnimal))
                {
                    //If they are not the same gender, then they can give birth
                    if(animals.getGender() != isMale)
                    {
                        giveBirth(newBabies);
                    }
                }

            }

        }
        return null;
    }

    /**
     * If this animal is alive, disease might start from this animal
     */
    private void diseaseMightStart()
    {
        if(isAlive()) {            
            Location newLocation = diseaseInfectionPossibility();
        }
    }

    /**
     * If this animal is alive, disease might be pass on and spread further
     */
    private void passOnDisease()
    {
        if(isAlive()) {            
            Location newLocation = carryOnDiseasePossibility();
        }
    }

    /**
     * Generate if animal might catch disease, if yes disease will start spreading
     */
    private boolean catchDisease()
    {
        return disease.diseasePossibility();
    }

    /**
     * This animal can survive from this disease and be cured
     * Otherwise, disease spread further
     */
    private boolean mightCarryOnDisease()
    {
        return disease.cured();
    }

    /**
     * Look for this animal adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where Food was found, or null if it wasn't.
     */
    private Location diseaseInfectionPossibility()
    {
       //Check if animal starts a disease
        if(catchDisease())
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            haveDisease();
            foodLevel--;
            disease.diseaseOccurs();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Animal) {
                    Animal animals = (Animal) animal;
                    if(animals.isAlive()) { 
                        if(rand.nextDouble() <= disease.getSpreadRate())
                        {   
                            animals.haveDisease();
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Look for animal adjacent to the current location.
     * All neighbour animals have a chance to get disease from this animal
     * @return null, If no neighbour animal found
     */
    private Location carryOnDiseasePossibility()
    {
        //Check if animal has disease, if true, they have chance to pass it on to other animal
        if(mightCarryOnDisease())
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            foodLevel--;
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Animal) {
                    Animal animals = (Animal) animal;
                    if(animals.isAlive()) { 
                        if(rand.nextDouble() <= disease.getSpreadRate())
                        {  
                            animals.haveDisease();
                        }
                    }
                }
            }
        }else{
            // an individual animal is cured from the disease
            animalCured();
        }
        return null;
    }

    /**
     * All disease gone from all animal
     */
    protected void diseaseDisappearPossibility()
    {
        if (rand.nextDouble() <= 0.00001)
        {
            disease.diseaseReset();
        }
   }

    /**
     * Check if there is disease in this animal and check if disease is spreading 
     * in the current ecosystem or not
     */
    protected void checkDisease()
   {
         if(getAnimalDisease() == false && disease.getDisease() == false)
        {
            diseaseMightStart();
        }else if (getAnimalDisease() == true && disease.getDisease() == true){
            passOnDisease();
         }
        diseaseDisappearPossibility();
   }

    /**
     * Check if a particular animal has the disease
     */
    abstract protected boolean getAnimalDisease();
     
    /**
     * If this animal catches disease, change the status of disease
     * for this animal to be true
     */
    protected void haveDisease()
    {
        haveDisease = true;
    }
    
    /**
     * If this animal survived from the disease, change the status of disease
     * for this animal to be false
     */
    protected void animalCured()
    {
        haveDisease = false;
    }

}
