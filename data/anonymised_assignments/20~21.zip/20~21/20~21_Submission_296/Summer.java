
/**
 * This class represents characteristic of a Summer.
 * A simple model of Summer
 * This is the class that make the season become Summer.
 * Changing state of season to Summer
 *
 * 
 * @version 2021.03.01
 */
public class Summer extends Season
{
    // instance variables - replace the example below with your own
    private static boolean isSummer = false;
    protected Weather sun = new Sunny();

    /**
     * Constructor for objects of class Summer
     */
    public Summer()
    {
        //empty
    }

    /**
     * Change the season to summer
     */
    public void currentSeason() {
        isSummer = true;
    }
    
    /**
     * Change season because summer is finished
     */
    public void changeSeason() {
        isSummer = false;
    }
    
    /**
     * @return true, if summer is the current season
     */
    public boolean getSeason() {
        return isSummer;
    }
}
