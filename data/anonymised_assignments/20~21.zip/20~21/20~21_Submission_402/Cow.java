import java.util.List;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Cow extends Animal {
    // Characteristics shared by all cows.
    // The age to which can live.
    private static final int MAX_AGE = 100;
    // The age at which can start to breed.
    private static final int BREEDING_AGE = 20;
    // The likelihood of breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // How much the food can satiate.
    private static final int FOOD_VALUE = 4;

    /**
     * Create a new Cow. A cow may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the cow will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Cow(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, MAX_AGE, FOOD_VALUE);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     * @param simulationStep The current step in the simulator.
     */
    protected int birthCount(int simulationStep) {
        boolean canBreed = age >= BREEDING_AGE;
        if (canBreed && rand.nextDouble() <= BREEDING_PROBABILITY) {
            return rand.nextInt(MAX_LITTER_SIZE) + 1;
        } else {
            return 0;
        }
    }

    /**
     * Create a new cow
     * 
     * @return Newborn cow.
     * @param field Field, where the cow will live.
     * @param location Location in the given field.
     */
    protected Creature birth(Field field, Location location) {
        return new Cow(false, field, location);
    }

    /**
     * Check if given creature is edible.
     * 
     * @return If true, then it's edible.
     * @param creature The creature, that needs to be checked.
     */
    public boolean isFood(Creature creature) {
        return creature instanceof Grass;
    }
}
