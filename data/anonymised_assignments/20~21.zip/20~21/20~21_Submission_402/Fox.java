import java.util.ArrayList;
import java.util.List;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Fox extends Animal {
    // Characteristics shared by all foxes (class variables).

    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 20;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int FOOD_VALUE = 9;

    // Is this fox a male?
    private final boolean male;

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, MAX_AGE, FOOD_VALUE);
        male = rand.nextBoolean();
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     * @param simulationStep The current step in the simulator.
     */
    protected int birthCount(int simulationStep) {
        Field field = getField();
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && male) {
            List<Location> adjacents = field.adjacentLocations(getLocation());
            List<Location> locations = new ArrayList<>();
            for (int i = 0; i < adjacents.size(); i++) {
                locations.addAll(field.adjacentLocations(adjacents.get(i)));
            }
            adjacents.addAll(locations);
            for (int i = 0; i < adjacents.size(); i++) {
                Location location = adjacents.get(i);
                Creature creature = field.getObjectAt(location);
                if (creature instanceof Fox) {
                    Fox fox = (Fox) creature;
                    if (!fox.male) {
                        births++;
                    }
                }
            }
            births++;
        }
        return births;
    }

    protected Creature birth(Field field, Location location) {
        return new Fox(false, field, location);
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }

    /**
     * Check if given creature is edible.
     * 
     * @return If true, then it's edible.
     * @param creature The creature, that needs to be checked.
     */
    public boolean isFood(Creature creature) {
        return creature instanceof Rabbit || creature instanceof Cow;
    }
}
