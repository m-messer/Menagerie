import java.util.List;
import java.util.Random;

public abstract class Creature {
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    // Whether the creature is alive or not.
    private boolean alive;
    // The creature's field.
    private Field field;
    // The creature's position in the field.
    private Location location;

    // Individual characteristics (instance fields).
    // The creature's current age.
    protected int age;
    // The age to which can live.
    private final int maxAge;

    /**
     * Create a new creature at location in field.
     *
     * @param randomAge If true, the creature will have a random age.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The age to which creature can live.
     */
    public Creature(boolean randomAge, Field field, Location location, int maxAge) {
        alive = true;
        this.field = field;
        this.maxAge = maxAge;
        if (randomAge) {
            age = rand.nextInt(maxAge);
        } else {
            age = 0;
        }
        setLocation(location);
    }

    /**
     * Make this creature act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newCreatures   A list to receive newly born creatures.
     * @param simulationStep The current step in the simulator.
     */
    public final void act(List<Creature> newCreatures, int simulationStep) {
        incrementAge(1);
        if (this instanceof Animal) {
            Animal animal = (Animal) this;
            animal.increaseHunger(1);
        }
        if (isAlive()) {
            giveBirth(newCreatures, simulationStep);

            Location newLocation = null;
            if (this instanceof Plant) {
                // Plants don't move
            } else {
                if (this instanceof Animal) {
                    Animal animal = (Animal) this;
                    newLocation = animal.findFood();
                }
                if (newLocation == null) {
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
            }
            if (newLocation == null) {
                setDead(); // Overcrowding
            } else {
                setLocation(newLocation);
            }
        }
    }

    /**
     * Check whether the creature is alive or not.
     *
     * @return true if the creature is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the creature is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the creature's location.
     *
     * @return The creature's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the creature at the new location in the given field.
     *
     * @param newLocation The creature's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the creature's field.
     *
     * @return The creature's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Increase the age. This could result in the creature's death.
     */
    protected void incrementAge(int by) {
        age += by;
        if (age > maxAge) {
            setDead();
        }
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newCreatures A list to return newly born foxes.
     * @param simulationStep The current step in the simulator.
     */
    private void giveBirth(List<Creature> newCreatures, int simulationStep) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = birthCount(simulationStep);
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Creature young = birth(field, loc);
            newCreatures.add(young);
        }
    }

    /**
     * Create a new creature.
     * 
     * @return Newborn creature.
     * @param field Field, where it's going to live
     * @param location Location in the field.
     */
    protected abstract Creature birth(Field field, Location location);

    /**
     * Get number of birth this creature can do at current simulation step.
     * 
     * @return number of births.
     * @param simulationStep The current step in the simulator.
     */
    protected abstract int birthCount(int simulationStep);
}
