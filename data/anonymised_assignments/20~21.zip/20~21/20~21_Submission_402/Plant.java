public abstract class Plant extends Creature {
    /**
     * Create a new animal at location in field.
     *
     * @param randomAge If true, the creature will have a random age.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The age to which creature can live.
     */
    public Plant(boolean randomAge, Field field, Location location, int maxAge) {
        super(randomAge, field, location, maxAge);
    }
}
