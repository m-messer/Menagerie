/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Grass extends Plant {
    // The age to which can live.
    static final int MAX_AGE = 50;
    // The age at which can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    /**
     * Create a grass. A grass can be created as a new born (age zero) or 
     * with a random age.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, MAX_AGE);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int birthCount(int simulationStep) {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE + 1);
        }
        int time = simulationStep % 24;
        boolean isDark = true;
        if (8 <= time && time <= 20) {
            isDark = false;
        }
        if (isDark) {
            return births / 2;
        }
        return births;
    }

    /**
     * Create a new grass
     * 
     * @return Newborn grass.
     * @param field Field, where the grass will grow.
     * @param location Location in the given field.
     */
    protected Creature birth(Field field, Location location) {
        return new Grass(false, field, location);
    }

    /**
     * A grass can breed if it has reached the breeding age.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
}
