import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Creature {
    // Current food level of this animal.
    private int foodLevel;
    // How much the food can satiate.
    private final int foodValue;
    // Is the animal currently infected.
    private boolean isInfected;

    /**
     * Create a new animal at location in field.
     *
     * @param random If true, the creature will have a random age and food value.
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param maxAge The age to which creature can live.
     * @param foodValue How much the food can satiate.
     */
    public Animal(boolean random, Field field, Location location, int maxAge, int foodValue) {
        super(random, field, location, maxAge);
        if (random) {
            foodLevel = rand.nextInt(foodValue);
            isInfected = rand.nextBoolean();
        } else {
            foodLevel = foodValue;
            isInfected = false;
        }
        this.foodValue = foodValue;
    }


    /**
     * Look for food adjacent to the current location.
     * Only the first live creature is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (int i = 0; i < adjacent.size(); i++) {
            Location where = adjacent.get(i);
            Creature creature = field.getObjectAt(where);
            if (isFood(creature)) {
                creature.setDead();
                foodLevel = foodValue;
                return where;
            }
        }
        return null;
    }

    /**
     * Check if given creature is edible.
     * 
     * @return If true, then it's edible.
     * @param creature The creature, that needs to be checked.
     */
    abstract boolean isFood(Creature creature);

    /**
     * Increase the age. This could result in the creature's death from age or infection.
     * 
     * @param by Increment age by the given value.
     */
    protected void incrementAge(int by) {
        isInfected = rand.nextDouble() <= Simulator.INFECTION_PROBABILITY;
        if (isInfected) {
            boolean isLethal = rand.nextDouble() <= Simulator.INFECTION_LETHAL_PROBABILITY;
            if (isLethal) {
                setDead();
            } else {
                super.incrementAge(by + Simulator.INFECTION_AGING);
            }
        } else {
            super.incrementAge(by);
        }
    }

    /**
     * Make this fox more hungry. This could result in the creature's death.
     * 
     * @param by Decrease food level by the given value.
     */
    protected void increaseHunger(int by) {
        assert by >= 0;
        foodLevel -= by;
        if (foodLevel <= 0) {
            setDead();
        }
    }
}
