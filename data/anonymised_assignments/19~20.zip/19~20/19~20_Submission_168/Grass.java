import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of grass. Grass will expand and be eaten by animals
 * Condition will influence the act of grass
 * 
 *
 * @version 2020/02/20 
 */
public class Grass extends Creature
{
    // The age at which a grass can start to breed.
    private static int BREEDING_AGE =30;
    // The age to which a grass can live.
    private static int MAX_AGE = 100;
    // The likelihood of a grass breeding.
    private static double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static int LITTER_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //actual maximum number of births considering conditions
    private static int new_LITTER_SIZE;
    //actual likelihood of breeding consdering conditions
    private static double new_BREDDING_PROBABILITY;
    
    /**
     * @param randomAge If true, the grass will have random age
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge ,Field field , Location location)
    {
        super(field , location);
        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE);
        }
        else 
        {
            age = 0;
        }
        }
    
    /**
     * This is what the grass does most of the time: it might breed, 
     * die because of age 
     * @param field The field currently occupied.
     * @param newGrass A list to return newly born grass.
     */
    public void act(List<Creature> creature)
    {
        incrementAge();
        //parameters are updated accourding to conditions
        simulateCondition();
        if(isAlive())
        {
            giveBirth(creature);
        }
    }
 
     /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrass A list to return newly born grass.
     */
    private void giveBirth(List<Creature> newGrass)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int birth = Breed();
        for(int n = 0;free.size() > 0 &&  n < birth && n < free.size() ; n++)
        {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
    
    /**
     * newVALUEs are updated for different conditions and ready for further use
     */
    private void simulateCondition()
    {
        int c = Condition.getWeather();
        if(c == 1)
        {
            new_LITTER_SIZE = LITTER_SIZE;
            new_BREDDING_PROBABILITY = BREEDING_PROBABILITY;
        }
        else if(c == 2)
        {
            new_LITTER_SIZE = LITTER_SIZE + 1;
            new_BREDDING_PROBABILITY = BREEDING_PROBABILITY *1.2;
        }
        else 
        {
            new_LITTER_SIZE = LITTER_SIZE - 1;
            new_BREDDING_PROBABILITY = BREEDING_PROBABILITY * 0.8;
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int Breed()
    {
        if(rand.nextDouble() <= new_BREDDING_PROBABILITY)
        {
            return rand.nextInt(new_LITTER_SIZE);
        }
        return 0;
    }
    
    /**
     * age is incremented after each step
     */
    public void incrementAge()
    {
        age++;
        if(age >= MAX_AGE)
        {
            setDead();
        }
    }
    
}