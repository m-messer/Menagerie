import java.util.*;
import javafx.util.Pair;

/**
 * A simple model of a Sparrow.
 * Sparrow age, move, eat butterfly, grasshopper and dragonfly, it may infected by 
 * disease and die because of disease and starvation. Condition will influence
 * the act of sparrow
 * @version 2020/02/20 
 */
public class Sparrow extends Animal
{
    // Characteristics shared by all Sparrows (class variables).
    // The age at which a sparrow can start to breed.
    private static final int BREEDING_AGE =10;
    // The age to which a sparrow can live.
    private static final int MAX_AGE = 300;
    // The likelihood of a sparrow breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single dragonfly. In effect, this is the
    // number of steps a sparrow can go before it has to eat again.
    private static final int DRAGONFLY_FOOD_VALUE = 40;
    // The food value of a single butterfly.
    private static final int BUTTERFLY_FOOD_VALUE = 40;
    // The food value of a single grasshoper.
    private static final int GRASSHOPPER_FOOD_VALUE = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The possibility that this step will do nothing
    private static final double REST_PROBABILITY = 0.3;
    // Individual characteristics (instance fields).
    /**
     * Create a sparrow. A sparrow can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Dragonfly will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sparrow(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            //food level of new created sparrow
            foodLevel = rand.nextInt(DRAGONFLY_FOOD_VALUE);
        }
        else {
            age = 0;
            //food level of new born sparrow
            foodLevel = (int)(DRAGONFLY_FOOD_VALUE * 0.7);
        }
    }
    
    /**
     * This is what the sparrow does most of the time: it hunts for
     * butterfly, dragonfly and grasshopper. In the process, it might breed, die because
     * of starvation, age or disease.
     * @param field The field currently occupied.
     * @param newDragonflies A list to return newly born sparrows.
     */
    public void act(List<Creature> newSparrow)
    {
        incrementAge();
        if(rand.nextDouble() < REST_PROBABILITY)
        {
            return;
        }
        else
        {
            incrementHunger();
            illness();
            if(isAlive())
            {
                giveBirth(newSparrow);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) 
                { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) 
                {
                    setLocation(newLocation);
                }
                else 
                {
                    // Overcrowding.
                    setDead();
                }
            } 
        }
    }

    /**
     * Increase the age. This could result in the sparrow's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }   
    
    /**
     * Look for preys adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
     private Location findFood()
    {
        Iterator<Location> it = adjacentIterator();
        while(it.hasNext()) 
        {
            Location where = it.next();
            Object what = field.getObjectAt(where);
            if(what instanceof Grasshopper) 
            {
                Grasshopper grasshopper = (Grasshopper) what ;
                if(grasshopper.isAlive()) 
                { 
                    grasshopper.setDead();
                    foodLevel = GRASSHOPPER_FOOD_VALUE;
                    return where;
                }
            }
            else if(what instanceof Butterfly) 
            {
                Butterfly butterfly = (Butterfly) what;
                if(butterfly.isAlive())
                { 
                    butterfly.setDead();
                    foodLevel = BUTTERFLY_FOOD_VALUE;
                    return where;
                }
            }
            else if(what instanceof Dragonfly)
            {
                Dragonfly dragonfly = (Dragonfly) what;
                if(dragonfly.isAlive())
                {
                    dragonfly.setDead();
                    foodLevel = DRAGONFLY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * If sparrow is ill it may spread disease to adjacent sparrows
     */
    public void findInfect()
    {
        Iterator<Location> it = adjacentIterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if( rand.nextDouble() <= ILL_PROBABILITY &&isIll() && animal instanceof Sparrow)
            {
                Sparrow sparrow = (Sparrow) animal;
                if(sparrow.isAlive())
                {
                    sparrow.setIll();
                }
            }
        }
    }
    
    /**
     * Check whether or not this sprrow is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSparrow A list to return newly born Sparrow.
     */
    private void giveBirth(List<Creature> newSparrow)
    {
        // New Dragonflyes are born into adjacent locations.
        // Get a list of adjacent free locations.
        // This method is called by female fragonfly
        if(!getGender())
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext())
            {
                Location where = it.next();
                Object what = field.getObjectAt(where);
                if(what instanceof Sparrow)
                {
                    Sparrow sparrow = (Sparrow) what ;
                    //only reproduce when two sparrow are of opposite gender
                    if(sparrow.getGender())
                    {
                        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Sparrow young = new Sparrow(false, field, loc);
                            newSparrow.add(young);
                            break;
                           }
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && foodLevel > 9) 
        {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;//inclusive
        }
        if(births > 0)
        {
            foodLevel -= 1 ;//sparrow will lose foodlevel when give birth 
            //to its offsprings.
        }
        
        return births;
    }
    
    /**
     * @return boolean
     * A Dragonfly can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}