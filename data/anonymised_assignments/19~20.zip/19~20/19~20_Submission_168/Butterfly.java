import java.util.*;
import javafx.util.Pair;

/**
 * A simple model of a Butterfly.
 * Butterflies age, move, eat butterfly, it may infected by 
 * disease and die because of disease and starvation. Condition will influence
 * the act of butterfly
 * @version 2020/02/20 
 */
public class Butterfly extends Animal
{
    // Characteristics shared by all butterflys (class variables).
    // The age at which a butterfly can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a butterfly can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a butterfly breeding.    
    private static final double BREEDING_PROBABILITY = 0.78;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The food value of a single butterfly. In effect, this is the
    // number of steps a butterfly can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 25;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The possibility that this butterfly will do nothing during this step
    private static final double REST_PROBABILITY = 0.3;
    
    /**
     * Create a butterfly. A butterfly can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the butterfly will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Butterfly(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else 
        {
            age = 0;
            foodLevel = (int)(GRASS_FOOD_VALUE * 0.7);
        }
    }
    
    /**
     * This is what the butterfly does most of the time: it hunts for
     * grass. In the process, it might breed, die because
     * of starvation, age or disease.
     * @param field The field currently occupied.
     * @param newButterfly A list to return newly born butterfly.
     */
    public void act(List<Creature> newBuffterfly)
    {
        incrementAge();
        if(Condition.getWeather() == 0 && rand.nextDouble() < REST_PROBABILITY)
        {
            return;
        }
        else
        {
            incrementHunger();
            illness();
            if(isAlive()) 
            {
                giveBirth(newBuffterfly);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) 
                { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                    // See if it was possible to move.
                if(newLocation != null) 
                {
                    setLocation(newLocation);
                }
                else 
                {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the butterfly's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) 
        {
            setDead();
        }
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Iterator<Location> it = adjacentIterator();
        while(it.hasNext()) 
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Grass) 
            {
                Grass grass = (Grass) animal;
                if(grass.isAlive()) 
                { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * If butterfly is ill it may spread disease to adjacent butterflies
     */
    public void findInfect()
    {
        Iterator<Location> it = adjacentIterator();
        while(it.hasNext()) 
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if( rand.nextDouble() <= ILL_PROBABILITY &&isIll() && animal instanceof Butterfly)
            {
                Butterfly butterfly = (Butterfly) animal;
                if(butterfly.isAlive())
                {
                    butterfly.setIll();
                }
            }
        }
    }
    
    /**
     * Check whether or not this butterfly is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newButterfly A list to return newly born Butterfly.
     */
    private void giveBirth(List<Creature> newButterfly)
    {
        // New Dragonflyes are born into adjacent locations.
        // Get a list of adjacent free locations.
        // This method is called by female butterfly
        if(!getGender())
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext())
            {
                Location where = it.next();
                Object what = field.getObjectAt(where);
                if(what instanceof Butterfly)
                {
                    Butterfly butterfly = (Butterfly) what;
                    //only reproduce when two sparrow are of opposite gender
                    if(butterfly.getGender())
                    {
                        List<Location> free = field.getFreeAdjacentLocations(getLocation());
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Butterfly young = new Butterfly(false, field, loc);
                            newButterfly.add(young);
                            break;
                           }
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && foodLevel>5) 
        {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;//inclusive
        }
        if(births > 0)
        {
            foodLevel -= 1 ;
            //this butterfly will decrease foodlevel 
            //when give birth to a new butterfly
        }
        return births;
    }

    /**
     * A butterfly can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}