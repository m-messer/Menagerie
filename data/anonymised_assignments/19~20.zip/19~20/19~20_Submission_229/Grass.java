import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a grass.
 * grass age and die.
 *
 * @version 20.2.2018
 */
public class Grass extends Actor implements Edible
{
    // Characteristics shared by all grasss (class variables).
    private static final int MAX_AGE = 5;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new grass. A grass may be created with age
     * zero (a new grass) or with a random age.
     *
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
           age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * Grasss don't move. They stay stationary and occasionally 
     * die and are replaced by new seedlings.
     * @param newActors A list to return newly created grasss.
     */
    public void act(List<Actor> newActors)
    {
        if(Simulator.getWeather().getRaining()) {
            incrementAge();
        }
    }
    
    /**
     * Grasss do not die they are replaced by new seedlings
     * in the same position.
     */
    protected void setDead()
    {
        age = 0;
    }
    
    /**
     * @return Maximum age a grass can grow to
     * before dying.
     */
    protected int getMAX_AGE()
    {
        return MAX_AGE;
    }
    
    /**
     * When grasss grow they gain nutritional content.
     * The older the grass the more nutritious.
     * @return nutrition value of grass when eaten.
     */
    public int getFOOD_VALUE()
    {
        return age;
    }
    

}
