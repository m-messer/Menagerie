

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a grass.
 * Grasss age, move, eat grasss, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Grass extends Plant
{
    // The age at which a grass can start to breed.
    private static final int BREEDING_AGE = 2;
    
    // The age to which a grass can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a grass breeding.
    private static final double GROWING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 9;
    //A shared random number to generate the age of grass.
    private static final Random rand = Randomizer.getRandom();
    // The grass's age.
    private int age;
    

    /**
     * Create a grass. A grass will be created as a new born.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
        age = 0;
       
    }

    /**
     * The grass will grow and increase age during one step
     * And die if it is not alive.
     */
    public void act(List<Actor> newGrasss)
    {
        incrementAge();
        
        if(isAlive()) {
            giveBirth(newGrasss);
        }else {
                // Overcrowding.
                setDead();
            }
    }

    /**
     * Increase the age. This could result in the grass's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrasss A list to return newly born grass.
     */
    private void giveBirth(List<Actor> newGrasss)
    {
        // New wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.adjacentNullLocation(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(field, loc);
            newGrasss.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can grow.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if( rand.nextDouble() <= GROWING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    

    
    /**
     * Get the current age of grass.
     * @return the current age of the grass.
     */
    public int getAge(){
        return age;
    }
    
}
