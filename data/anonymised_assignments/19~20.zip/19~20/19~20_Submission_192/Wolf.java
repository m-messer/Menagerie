import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * Wolfes age, move, eat squirrels, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).

    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 81;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 9;
    // The food value of a single squirrel, dingo and snake. In fact, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 199;
    private static final int FOX_FOOD_VALUE = 199;
    private static final int SNAKE_FOOD_VALUE = 199;
    // A shared random number generator to control breeding and gender.
    private static final Random rand = Randomizer.getRandom();
    //Generate the random gender of the wolf.
    private boolean gender = rand.nextBoolean();

    // Individual characteristics (instance fields).
    // The wolf's age.
    private int age;
    // The wolf's food level, which is increased by eating squirrels.
    private int foodLevel;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender  If true, the snake will be a female.
     */
    public Wolf(boolean randomAge, Field field, Location location, boolean gender)
    {
        super(field, location, gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }

     /**
     * Wolf will act in one step
     * including increase the age, increase hunger, find food, give birth and move to a new place
     * If the wolf is not healthy, its lifespan will be decremented.
     * @param newWolfes A list of new wolfes. 
     */
    public void act(List<Actor> newWolfes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newWolfes);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }

            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
            
            if(!isHealthy()){
                decrementLifeRemain();
            }
        }
    }

    /**
     * Increase the age. This could result in the wolf's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this wolf more hungry. This could result in the wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for squirrels, dingoes and snakes adjacent to the current location.
     * Only the first live food is eaten.
     * If its prey is sick because of the plague, it will get sick too.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) {
                    if (!squirrel.isHealthy()){
                        this.getSick();
                    }
                    squirrel.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Dingo) {
                Dingo dingo = (Dingo) animal;
                if(dingo.isAlive()) {
                    if (!dingo.isHealthy()){
                        this.getSick();
                    }
                    dingo.setDead();
                    foodLevel = FOX_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if(snake.isAlive()) {
                    if (!snake.isHealthy()){
                        this.getSick();
                    }
                    snake.setDead();
                    foodLevel = SNAKE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the wolf is sick because of the plague, its children will be sick too.

     * @param newWolfes A list to return newly born wolves.
     */
    private void giveBirth(List<Actor> newWolfes)
    {
        // New wolves are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gend = rand.nextBoolean();
            Wolf young = new Wolf(false, field, loc, gend);
            newWolfes.add(young);
            if (!this.isHealthy()){
                young.getSick();
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(findLove() == true && canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Get the breeding age
     * @return the breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    /**
     * Get the age of wolf
     * @return the age of wolf
     */
    public int getAge(){
        return age;
    }
    
    /**
     * Wolf will search other wolf with different gender in adjacent location.
     * If either this snake or the spouse is not healthy, both of them
     * are going to get sick.
     * @return true if the wolf find spouse, false otherwise.
     */
    public boolean findLove()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        if(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wolf) {
                Wolf wolf = (Wolf) animal;
                if(wolf.getGender() != this.getGender())
                    if(wolf.isHealthy() != true || this.isHealthy() !=true){
                        this.getSick();
                        wolf.getSick();
                    }
                return true;
            }
        }
        return false;
    }
   
}
