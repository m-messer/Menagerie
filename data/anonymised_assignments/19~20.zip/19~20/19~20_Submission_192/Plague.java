 

import java.util.Random;
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Write a description of class Plague here.
 *
 * @version (a version number or a date)
 */
public class Plague extends ExtremeCondition
{
    // instance variables - replace the example below with your own

    private Random rand = Randomizer.getRandom();
    //The life span of the plague.
    private final int LIFE_SPAN = 50;
    //Number to count the duration of plague.
    private int duration;
    //A shared number to control extinct period.
    private final int extinctPeriod = 10;
    //Whether the plague has started.
    private boolean plagueStarted;
    
    /**
    * Create a new plague.
    * @param field The field that the plague is in.
    * @param location The location of the plague.
    */
    public Plague(Field field, Location location)
    {
        // initialise instance variables
        super(field,location);
        duration = 0;
    }


    /**
     * Check if it is a new plague or an existing plague.
     * @param newActors a list of all Actors on the field to be infected.
     */
    public void act(List<Actor> actors)
    {
        if (plagueStarted == false){
            startInfecting();
        }else if(plagueStarted == true){
            infectNearbyAnimal();
        }
    }
     
        
    /***
     * Ten day trial of infecting. If the plague doesn't infect any animal nearby, 
     * it extincts naturally.
     */
        private void startInfecting(){
            infectNearbyAnimal();
    }
     /**
     * Plague will search animals adjacent to its location
     * and infect them
     * If animal is healthy.
     * Once an animal if infected,plague will start.
     */
    private void infectNearbyAnimal(){
        Field field = getField();
        if(field == null)
        {
            System.out.println("No field");
        }
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Animal) {
                Animal animal = (Animal) organism;
                if(animal.isHealthy()) { 
                    animal.getSick();
                    plagueStarted = true;
                    
                }
            }
        }
    incrementDuration();
    }
    private void incrementDuration(){
        duration++;
        if (duration == LIFE_SPAN){
            
            
            for (int row = 0;row <getField().getDepth();row++){
            for (int col = 0;col <getField().getWidth();col++){
             if (getField().getObjectAt(row,col) instanceof Animal){
            Animal patient = (Animal) getField().getObjectAt(row,col);
            if (patient != null){
                patient.getCured();
            }
            
            
        }
        
        }}
        setDead();
    }
    }
}
    
        
        
    