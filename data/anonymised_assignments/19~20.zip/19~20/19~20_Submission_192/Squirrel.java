import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a rat.
 * Squirrels age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Squirrel extends Animal
{
    // Characteristics shared by all rats (class variables).

    // The age at which a squirrel can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a squirrel can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a squirrel breeding.
    private static final double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The food value of a single grass. In effect, this is the
    // number of steps a squirrel can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //Generate the gender of rat.
    private boolean gender = rand.nextBoolean();
    // The rat's food level, which is increased by eating grass.
    private int foodLevel;

    // Individual characteristics (instance fields).

    // The rat's age.
    private int age;

     /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender If true, the squirrel will be a female.
     */
    public Squirrel(boolean randomAge, Field field, Location location, boolean gender)
    {
        super(field, location, gender);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }

    }

    /**
     * Squirrel will act in one step
     * including increase the age, increase hunger, find food, give birth and move to a new place
     * If the fox is not healthy, its lifespan will be decremented.
     * @param newSquirrels A list of new rats. 
     */
    public void act(List<Actor> newSquirrels)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSquirrels);
            // Try to move into a free location
            Location newLocation = findFood();
            
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());}
           
            
            if(newLocation != null) {
                setLocation(newLocation);
            }else{
            setDead();
            }
            
            if(!isHealthy()){
                decrementLifeRemain();
            }
        }
    }
    
    /**
     * Make this snake more hungry. This could result in the  rat's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increase the age.
     * This could result in the rat's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Check whether or not this squirrel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the squirrel is sick because of the plague, its children will be sick too.
     * @param newSquirrels A list to return newly born rats.
     */
    private void giveBirth(List<Actor> newSquirrels)
    {
        // New rats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gend = rand.nextBoolean();
            Squirrel young = new Squirrel(false, field, loc, gend );
            newSquirrels.add(young);
            if (this.isHealthy() == false){
                young.getSick();
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;

        if(findLove() == true && canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A squirrel can breed if it has reached the breeding age.
     * @return true if the squirrel can breed, false otherwise.
     */

    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    public int getAge(){
        return age;
    }

     /**
     * Look for grasses adjacent to the current location.
     * Only the first live grass is eaten.
     * Squirrel will die if eat aconitum
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        if(adjacent.size()>0){
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) {
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }else if(plant instanceof Grass) {
                Aconitum aconitum = (Aconitum) plant;
                if(aconitum.isAlive()) { 
                    aconitum.setDead();
                    setDead();
                    return where;
                }
            } 

        }}
        return null;
    }

     /**
     * Squirrel will search other squirrel with different gender in adjacent location.
     * @return true if the squirrel find spouse, false otherwise.
     * If either this squirrel or the spouse is not healthy, both of them
     * are going to get sick.
     */
    public boolean findLove()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        if(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.getGender() != this.getGender())
                    if(squirrel.isHealthy() != true || this.isHealthy() !=true){
                        this.getSick();
                        squirrel.getSick();
                    }
                return true;}
        }
        return false;
    }
    
    
}
