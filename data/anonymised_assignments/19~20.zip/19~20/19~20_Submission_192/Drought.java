import java.util.Random;
import java.util.List;

/**
 * A simple model of a drought.
 * The number of grass will decrease during drought.
 *
 * @version  2020/2/22.
 */
public class Drought extends ExtremeCondition
{
    //The shared probability that the drought will happen.
    private static final double probability = 0.1;
    //The minimum size of drought. 
    private static final int MIN_DURATION = 10;
    //The maximum size of drought. 
    private static final int MAX_DURATION = 30;
    //A shared random number to control drought.
    private Random rand = Randomizer.getRandom();
    //The colum of drought.
    private int col;
    //The row of drought.
    private int row;
   
    /**
     * Create a new drought
     * A drought will kill 30% of grasses.
     */
    public Drought(Field field, Location location)
    {
        super(field,location);
    }

    /**
     * The drought will influece all the plant on the field.
     * After it the drought will disappear and removed.
     * @param a list of actors to be set dead if it is a plant.
     */
    public void act(List<Actor> newActor)
    {
        Field field = getField();
        for (col = 0;col <field.getWidth();col++){
           for (row = 0;row <field.getDepth();row++){
             
            Actor victim = (Actor) field.getObjectAt(row,col);
            if(victim != null){
            if (rand.nextDouble()<0.3 && victim instanceof Plant){
                victim.setDead();
              }
           }
           } 
        }
        setDead();
    }
}
