

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a dingo.
 * Dingoes age, move, eat squirrels, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Dingo extends Animal
{
    // Characteristics shared by all dingoes (class variables).

    // The age at which a dingo can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a dingo can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a dingo breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The food value of a single squirrel and rat. In effect, this is the
    // number of steps a dingo can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 4;
    private static final int RAT_FOOD_VALUE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Generate the random gender of dingo.
    private boolean gender = rand.nextBoolean();

    // Individual characteristics (instance fields).
    // The dingo's age.
    private int age;
    // The dingo's food level, which is increased by eating squirrels.
    private int foodLevel;

    /**
     * Create a dingo. A dingo can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the dingo will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
    *  @param gender If true, the dingo will be a female.

     */
    public Dingo(boolean randomAge, Field field, Location location, boolean gender)
    {
        super(field, location, gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }

    /**
     * Dingo will act in one step
     * including increase the age, increase hunger, find food, give birth and move to a new place
     * If the dingo is not healthy, its lifespan will be decremented.
     * @param newDingoes A list of new Dingoes. 
     */
    public void act(List<Actor> newDingoes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newDingoes);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }else {
                // Overcrowding.
                setDead();
            }
            
            if(!isHealthy()){
                decrementLifeRemain();
            }
        }
        
    }

    /**
     * Increase the age. This could result in the dingo's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this dingo more hungry. This could result in the dingo's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for squirrels adjacent to the current location.
     * Only the first live squirrel is eaten.
     * If its prey is sick because of the plague, it will get sick too.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) {
                    if (!squirrel.isHealthy()){
                        this.getSick();
                    }
                    squirrel.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
            
            if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.isAlive()) {
                    if (!rat.isHealthy()){
                        this.getSick();
                    }
                    rat.setDead();
                    foodLevel = RAT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this dingo is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the dingo is sick because of the plague, its children will be sick too.
     * @param newDingoes A list to return newly born dingoes.
     */
    private void giveBirth(List<Actor> newDingoes)
    {
        // New dingoes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gend = rand.nextBoolean();
            Dingo young = new Dingo(false, field, loc, gend);
            newDingoes.add(young);

            if (this.isHealthy() == false){
                young.getSick();
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(findLove() == true && canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Get the breeding age
     * @return the breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Get the age of dingo
     * @return the age of dingo
     */
    public int getAge(){
        return age;
    }
    
    /**
     * Dingo will search other dingo with different gender in adjacent location.
     * @return true if the dingo find spouse, false otherwise.
     * If either the dingo or the spouse is not healthy,both of them
     * are going to get sick.
     */
    public boolean findLove()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        if(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Dingo) {
                Dingo dingo = (Dingo) animal;
                if(dingo.getGender() != this.getGender())
                    if(dingo.isHealthy() != true || this.isHealthy() !=true){
                        this.getSick();
                        dingo.getSick();
                    }
                return true;}
        }
        return false;
    }
    
   
}
