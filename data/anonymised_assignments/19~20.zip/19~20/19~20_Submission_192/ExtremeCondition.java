/**
 * A class representing shared characteristics of extreme conditions.
 *
 * @version  2020/2/22.
 */
public abstract class ExtremeCondition extends Actor
{
    
     /**
     * Create a new weather at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public ExtremeCondition(Field field, Location location)
    {
        super(field,location);
    }
}
