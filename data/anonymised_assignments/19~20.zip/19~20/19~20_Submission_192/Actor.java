import java.util.List;

/**
 * A class representing shared characteristics of actors. 
 * @Version 2020/2/22
 */
public abstract class Actor
{    
    // Whether the actor is alive or not.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    protected Location location;
    
    /**
     * Create a new actor at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    
    public Actor(Field field, Location location)
    {   alive = true;
        this.field = field;
        
        setLocation(location);
    }
    
    /**
     * Set actors into the new location and delete the orginal location
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        this.location = newLocation;
        field.place(this, newLocation);

    }
    
    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
        
    }
    
    //abstract method which will be override.
    abstract public void act(List<Actor> newActor);
    
    /**
     * Get the location of the actor
     * @return the location of the actor.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Get the current field of the actor.
     * @return the field of the actor.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * To konw whether the actor is or not alive.
     * @return ture if actor is alive, false otherwise.
     */
    protected boolean isAlive()
    {
        return alive;
    }

}
