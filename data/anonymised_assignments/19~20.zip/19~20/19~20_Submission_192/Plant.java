import java.util.Random;
import java.util.Iterator;
import java.util.List;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Plant extends Actor
{

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {   super(field,location);
    }    
}
