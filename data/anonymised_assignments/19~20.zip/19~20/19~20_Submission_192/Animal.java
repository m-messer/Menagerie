import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor {
    //Characteristics shared by all animals (class variables).
    
    //A shared random number generator to control breeding and gender.
    private static final Random rand = Randomizer.getRandom();
    //The gender of animal.
    private boolean gender;
    //Whether the animal is alive or not.
    private boolean alive;
    //The days animal can be alive afther get infection.
    private int lifeRemainDaysAfterInfection;
    //Whether the animal is healthy.
    private boolean healthy;


    /**
     * Create a new animal at location in field.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     * @param gender   The gender of the animal.
     */
    public Animal(Field field, Location location, Boolean gender)
    {   super(field,location);
        healthy = true;
        gender = rand.nextBoolean();
        lifeRemainDaysAfterInfection = 30;

    }

    /**
     * Decreasen the remain days of animal. 
     * If the remain days are below 0, animal will die.
     */
    public void decrementLifeRemain() {
        lifeRemainDaysAfterInfection--;
        if (lifeRemainDaysAfterInfection <= 0) {
            setDead();
        }
    }
    
    /**
     * Animal become healthy if it is cured from infection.
     */
    public void getCured() {
        healthy = true;
    }
    
    /**
     * An animal can breed if it has reached the breeding age.
     *
     * @return true if the animal can breed, false otherwise.
     */
    public boolean canBreed() {
        return getAge() >= getBreedingAge();
    }
    //abstract method which will be override.
    abstract public int getBreedingAge();
    //abstract method which will be override.
    abstract public int getAge();



    /**
     * Get the gender of animal
     * @return the gender of animal
     */
    protected boolean getGender() {
        return gender;
    }
    
    /**
     * Afther get infected, animal become unhealthy.
     */
    public void getSick() {
        healthy = false;
    }
    
    /**
     * Get the status of animal
     * @reuturn true if animal is healthy, false otherwise.
     */
    public boolean isHealthy() {
        return healthy;
    }
}