import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing actors.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a dingo will be created in any given grid position.
    private static final double DINGO_CREATION_PROBABILITY = 0.1;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.3;
    // The probability that a rat will be created in any given grid position.
    private static final double RAT_CREATION_PROBABILITY = 0.3;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.05;
    // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.8;
    // The probability that one grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.9;
    // The probability that one aconitum will be created in any given grid position.
    private static final double ACONITUM_CREATION_PROBABILITY = 0.01;
    // The probability that a kind of wheather "snap" happened.
    private static final double SNAP_PROBABILITY = 0.005;
    // The probability that a kind of wheather "drought" happened.
    private static final double DROUGHT_PROBABILITY = 0.1;
    // The probability that a kind of disease "plague" happened.
    private static final double PLAGUE_PROBABILITY = 0.001;
    
    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    
    
    
    // A graphical view of the simulation.
    private List<SimulatorView> views;
    //The gender of animals.
    private boolean gender;
    //A random number used to generate random gender.
    private Random rand;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * Create a graphic view of the numbers of the species.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        
        field = new Field(depth, width);
        views = new ArrayList<>();
        
       
        
        SimulatorView view = new GridView(depth, width);
        view.setColor(Squirrel.class, Color.ORANGE);
        view.setColor(Dingo.class, Color.BLUE);
        view.setColor(Rat.class, Color.RED);
        view.setColor(Wolf.class, Color.MAGENTA);
        view.setColor(Snake.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        

    
    
        

        views.add(view);
        
        
        view = new GraphView(500, 150, 500);
        view.setColor(Squirrel.class, Color.ORANGE);
        view.setColor(Dingo.class, Color.BLUE);
        view.setColor(Rat.class, Color.RED);
        view.setColor(Wolf.class, Color.MAGENTA);
        view.setColor(Snake.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        
        views.add(view);

        //Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && views.get(0).isViable(field); step++) {
            simulateOneStep();
             delay(100);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     * The extreme conditions, Drought, ThanosSnap and Plague will only be added
     * to the field if the random double is smaller than their posibilities.
     * When there is an extreme condition on the field, it always acts. 
     */
public void simulateOneStep()
    {
        step++;
        Random rand = Randomizer.getRandom();


        if(rand.nextDouble()<= DROUGHT_PROBABILITY){
            actors.add(new Drought(field,new Location (1,1)));
            System.out.println("Drought happened at step" + step);
        }
        if(rand.nextDouble()< SNAP_PROBABILITY){
            actors.add(new ThanosSnap(field,new Location (1,1)));
            System.out.println("Thanos snapped at step"+step);

        }if(rand.nextDouble()<=PLAGUE_PROBABILITY){
            Location freeLocation = field.randomLocation();
           
            if(freeLocation != null)
            {
                actors.add(new Plague(field,freeLocation));
                System.out.println("Plague started at step" + step + "and will extinct in 50 steps");
            }
        
        }


        // Provide space for newborn Actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            
            Actor actor = (Actor) it.next();
            if(isDaytime() == true){
                if(actor instanceof Squirrel || actor instanceof Wolf || actor instanceof Dingo || actor instanceof Grass)
                {
                    actor.act(newActors);
                }
            }else{
                if(actor instanceof Snake || actor instanceof Rat || actor instanceof Grass){
                actor.act(newActors);
                }
  
            }
        
        if(actor instanceof ExtremeCondition)
            {
                actor.act(newActors);
            }
        
        if(!actor.isAlive()) {
                it.remove();
            }
        }
        actors.addAll(newActors);
        updateViews();
    
}
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        for (SimulatorView view : views) {
            view.reset();
        }

        populate();
        updateViews();
    }
    
    /**
     * Set 40 steps as one day, so 20 steps are in daytime, the rest at night.
     * @return true if it is in the daytime, false if at night.
     */
    private boolean isDaytime()
    {
    
        if (10> (step%20)&&(step%20) >=0)
        {
            return true;
        }
            return false;
    }
    
    /**
     * Update all existing views, In the daytime show the normal color
     * At night show the darker color 
     */
    private void updateViews()
    {
        for (SimulatorView view : views) {
            view.showStatus(step, field);
                if (isDaytime() == true){
            view.setColor(Squirrel.class, Color.ORANGE);
            view.setColor(Dingo.class, Color.BLUE);
            view.setColor(Rat.class, Color.RED);
            view.setColor(Wolf.class, Color.MAGENTA);
            view.setColor(Snake.class, Color.GRAY);
            view.setColor(Grass.class, Color.GREEN);
           
            
        }else{
            view.setColor(Squirrel.class, Color.ORANGE.darker());
            view.setColor(Dingo.class, Color.BLUE.darker());
            view.setColor(Rat.class, Color.RED.darker());
            view.setColor(Wolf.class, Color.MAGENTA.darker());
            view.setColor(Snake.class, Color.GRAY.darker());
            view.setColor(Grass.class, Color.GREEN.darker()); 
        }
        }
    }
    
    /**
     * Randomly populate the field with all kinds of species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= DINGO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Dingo dingo = new Dingo(true, field, location, gender);
                    actors.add(dingo);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location, gender);
                    actors.add(squirrel);
                }
                else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rat rat = new Rat(true, field, location, gender);
                    actors.add(rat);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location, gender);
                    actors.add(wolf);
                }else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(field, location);
                    actors.add(grass);
                }else if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location, gender);
                    actors.add(snake);
                }else if(rand.nextDouble() <= ACONITUM_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Aconitum aconitum = new Aconitum(field, location);
                    actors.add(aconitum);
                }// else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
