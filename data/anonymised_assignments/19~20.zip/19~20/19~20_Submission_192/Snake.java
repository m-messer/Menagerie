

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a snake.
 * Snakes age, move, eat squirrels, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Snake extends Animal
{
    // Characteristics shared by all snakes (class variables).

    // The age at which a snake can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a snake can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a snake breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The food value of a single squirrel and rat. In effect, this is the
    // number of steps a snake can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 10;
    private static final int RAT_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Generate the random gender of snake.
    private boolean gender = rand.nextBoolean();

    // Individual characteristics (instance fields).
    // The snake's age.
    private int age;
    // The snake's food level, which is increased by eating squirrels.
    private int foodLevel;

    /**
     * Create a snake. A snake can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the snake will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
    *  @param gender If true, the snake will be a female.

     */
    public Snake(boolean randomAge, Field field, Location location, boolean gender)
    {
        super(field, location, gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }

    /**
     * Snake will act in one step
     * including increase the age, increase hunger, find food, give birth and move to a new place
     * If the snake is not healthy, its lifespan will be decremented.
     * @param newSnakes A list of new Snakes. 
     */
    public void act(List<Actor> newSnakes)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newSnakes);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }else {
                // Overcrowding.
                setDead();
            }
            
            if(!isHealthy()){
                decrementLifeRemain();
            }
        }
        
    }

    /**
     * Increase the age. This could result in the snake's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this snake more hungry. This could result in the snake's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for squirrels adjacent to the current location.
     * Only the first live squirrel is eaten.
     * If its prey is sick because of the plague, it will get sick too.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) {
                    if (!squirrel.isHealthy()){
                        this.getSick();
                    }
                    squirrel.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
            
            if(animal instanceof Rat) {
                Rat rat = (Rat) animal;
                if(rat.isAlive()) {
                    if (!rat.isHealthy()){
                        this.getSick();
                    }
                    rat.setDead();
                    foodLevel = RAT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this snake is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the snake is sick because of the plague, its children will be sick too.
     * @param newSnakes A list to return newly born snakes.
     */
    private void giveBirth(List<Actor> newSnakes)
    {
        // New snakes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gend = rand.nextBoolean();
            Snake young = new Snake(false, field, loc, gend);
            newSnakes.add(young);

            if (this.isHealthy() == false){
                young.getSick();
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * 
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(findLove() == true && canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Get the breeding age
     * @return the breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Get the age of snake
     * @return the age of snake
     */
    public int getAge(){
        return age;
    }
    
    /**
     * Snake will search other snake with different gender in adjacent location.
     * @return true if the snake find spouse, false otherwise.
     * If either the snake or the spouse is not healthy,both of them
     * are going to get sick.
     */
    public boolean findLove()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        if(it.hasNext())
        {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if(snake.getGender() != this.getGender())
                    if(snake.isHealthy() != true || this.isHealthy() !=true){
                        this.getSick();
                        snake.getSick();
                    }
                return true;}
        }
        return false;
    }
    
   
}
