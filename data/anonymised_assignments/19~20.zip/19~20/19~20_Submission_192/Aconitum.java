import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a aconitum.
 * Aconitums age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Aconitum extends Plant
{
    //The growing probability of the plant aconitum. 
    private static final double GROWING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The maximum age of aconitum.
    private static final int MAX_AGE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The age of the individual aconitums.
    private int age;

    /**
     * Create a new aconitum. A aconitum is created at age 0.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Aconitum( Field field, Location location)
    {
        super(field, location);
        age = 0;
      
    }
    
    /**
     * The aconitum will grow and increase age during one step
     * And die if it is not alive.
     */
    public void act(List<Actor> newAconitums)
    {
        incrementAge();
        
        if(isAlive()) {
            grow(newAconitums);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the aconitum's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this aconitum is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAconitums A list to return newly born aconitums.
     */
    public void grow(List<Actor> newAconitum)
    {
        // New aconitums are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        Location loc = free.remove(0);
        Aconitum young = new Aconitum(field, loc);
        newAconitum.add(young);
        }
    
    /**
     * Get the age
     * @return the age of aconitum
     */
    public int getAge(){
     return age;   
    }
    
   
    
}
