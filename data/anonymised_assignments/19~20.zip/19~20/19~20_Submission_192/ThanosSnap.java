import java.util.Random;
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a ThanosSnap.
 * Half of actors will die after ThanosSnap.
 *
 * @version  2020/2/22.
 */
public class ThanosSnap extends ExtremeCondition
{
    //The probability that ThanosSnap will happen
    private static final double probability = 0.01;
    //The minimum duration of ThanosSnap    
    private static final int MIN_DURATION = 1;
    //The maximum duration of ThanosSnap    
    private static final int MAX_DURATION = 1;
    //A random number used to control the death of actors.   
    private Random rand = Randomizer.getRandom();
    //The location of ThanosSnap.
    private Location location;
    //The victim under ThanosSnap.
    private Actor victim;
    /**
    * Create a new ThanosSnap
    * The ThanosSnap will kill half of animals.
    */
    public ThanosSnap(Field field, Location location)
    {
       super(field,location);
    }

    /**
     * When ThanosSnap happened, half victims in the influenced field will die.
     * @param animal A list of Animals to be set dead if it is an animal.
     */
    public void act(List<Actor> animal)
    {
        Field field = getField();
        for (int row = 0;row <field.getDepth();row++){
        for (int col = 0;col <field.getWidth();col++){
            Actor victim = (Actor) field.getObjectAt(row,col);
            while (rand.nextDouble()<=0.5 && victim != null){
                victim.setDead();
            }
        }
     setDead();}
    }
}
