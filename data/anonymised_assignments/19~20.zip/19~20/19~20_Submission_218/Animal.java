import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.HashMap;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field fauna;
    // The animal's position in the field.
    private Location location;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    //the animal's gender
    private boolean isMale;
    //the animal's age
    protected int age;
    // Animals can only eat up to a certain value.
    private int MAX_FOOD_CAPACITY;
    // animal's prey and their food values.
    protected HashMap<Integer, Integer> foodValue;
    // the animal's food level.
    protected int foodLevel;
    // The likelihood of an animal being infected.
    private static final double INFECTION_PROBABILITY = 0.05;
    // The disease infection state of an animal.
    private boolean infected = false;
    // The animal's disease. 
    protected Disease disease;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field fauna, Location location)
    {
        foodValue = new HashMap<Integer, Integer>();
        alive = true;
        isMale = rand.nextBoolean();
        this.fauna = fauna;
        setLocation(location);
        MAX_FOOD_CAPACITY = getMaxFoodCapacity();
        age = 0;
    }

    /**
     * This is what the animal does most of the time - it runs 
     * around and searches for food. Sometimes it will breed or die of old age.
     * @param newMarmots A list to return newly born marmots.
     */
    public void act(List<Animal> newAnimals, Weather currentWeather, Field flora)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newAnimals);            
            // Move towards a source of food if found.
            Location newLocation = findFood(flora);
            if(newLocation == null) {  
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * @return true if the animal is also nocturnal.
     */
    abstract public boolean actsAtNight();

    /**
     * it is probable some animals act during the night
     */
    abstract protected double getNightHuntingProbability();
    
    /**
     * @return the breeding age of an animal.
     */
    abstract protected int getBREEDINGAGE();

    /**
     * @return the maximum age of an animal. 
     */
    abstract protected int getMAXAGE();

    /**
     * @return the breeding probability of an animal.
     */
    abstract protected double getBREEDINGPROBABILITY();

    /**
     * @return the maximum litter size.
     */
    abstract protected int getMAXLITTERSIZE();

    /**
     * return the species number.
     */
    abstract protected int getSpeciesNo();
    
    /**
     * @return the probability of an animal moving during the rain.
     */
    abstract protected double getRAINMOVEMENTPROBABILITY();

    /**
     * During night, some animals sleep, but they still age and get hungry.
     */
    public void restNightShift()
    {
        incrementHunger();
        incrementAge();
    }

    /**
     * during night, predators can hunt or rest
     */
    public void activeNightShift(List<Animal> newAnimals, Weather currentWeather, Field flora)
    {
        if(rand.nextDouble() <= getNightHuntingProbability())
        {
            //act(newAnimals, currentWeather, flora);
            rainMovement(newAnimals, currentWeather, flora);
        }
        else
        {
            incrementHunger();
            incrementAge();
        }
    }

    /**
     * During rain animals can move or take shelter(stop moving).
     */
    public void rainMovement(List<Animal> newAnimals, Weather currentWeather, Field flora)
    {
        if(currentWeather.isRaining())
        {
            if(rand.nextDouble() <= getRAINMOVEMENTPROBABILITY())
            {
                act(newAnimals, currentWeather, flora);
            }
            else
            {
                incrementHunger();
                incrementAge();
            }
        }
        else
        {
            act(newAnimals, currentWeather, flora);
        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            fauna.clear(location);
            location = null;
            fauna = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            fauna.clear(location);
        }
        location = newLocation;
        fauna.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return fauna;
    }

    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMAXAGE()) {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBREEDINGPROBABILITY()) {
            births = rand.nextInt(getMAXLITTERSIZE()) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age
     * and if it finds nearby another animal of the same species but different gender.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed()
    {
        if(age >= getBREEDINGAGE() && getAdjacentGender()==true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Look for animals adjacent to the current location.
     * Check its gender.
     * @return true where gender is different and animal is of the same
     * species and false if not.
     */
    private boolean getAdjacentGender()
    {
        Field fauna = getField();
        List<Location> adjacent = fauna.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = fauna.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal anim = (Animal) animal;
                if(anim.isMale!=this.isMale && anim.getClass().equals(this.getClass())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal that the animal feeds on is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood(Field flora)
    {
        Field fauna = getField();
        List<Location> adjacent_plant = flora.adjacentLocations(getLocation());
        Iterator<Location> it_plant = adjacent_plant.iterator();
        List<Location> adjacent = fauna.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        //some animals feed on other animals.
        while(it.hasNext()) {
            Location where = it.next();
            Object object = fauna.getObjectAt(where);
            if(object instanceof Animal) {
                Animal animal = (Animal) object;
                if(animal.getClass()!=this.getClass() && this.foodValue.containsKey(animal.getSpeciesNo()) && animal.isAlive())
                {
                    animal.setDead();
                    if(foodLevel + this.foodValue.get(animal.getSpeciesNo()) > MAX_FOOD_CAPACITY)
                    {
                        foodLevel = MAX_FOOD_CAPACITY;
                    }
                    else
                    {
                        foodLevel = foodLevel + this.foodValue.get(animal.getSpeciesNo());
                    }
                    return where;
                }
            }
        }
        //some animals feed on plants.
        while(it_plant.hasNext()){
            Location where = it_plant.next();
            Object object = flora.getObjectAt(where);
            if(object instanceof Plant){
                Plant plant = (Plant) object;
                if(this.foodValue.containsKey(plant.getSpeciesNo()) && plant.getWorth()>0)
                {
                    
                    plant.feedAnimal();
                    foodLevel = plant.getMaxWorth();
                    //return where;
                }
            }
        }
        return null;
    }

    /**
     * @return the maximum eating capcaity of an animal.
     */
    abstract protected int getMaxFoodCapacity();
    
    /**
     * Check whether or not this animal is to give birth at this step.
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field fauna = getField();
        List<Location> free = fauna.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (getSpeciesNo()==0){
                Marmot young = new Marmot(false, fauna, loc);
                newAnimals.add(young);
            }
            else if (getSpeciesNo()==1){
                Lynx young = new Lynx(false, fauna, loc);
                newAnimals.add(young);
            }
            else if (getSpeciesNo()==2){
                Wolf young = new Wolf(false, fauna, loc);
                newAnimals.add(young);
            }
            else if (getSpeciesNo()==3){
                Deer young = new Deer(false, fauna, loc);
                newAnimals.add(young);
            }
            else if (getSpeciesNo()==4){
                Primitive young = new Primitive(false, fauna, loc);
                newAnimals.add(young);
            }
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Might infect the animal.
     */
    protected void infect()
    {
        if(rand.nextDouble() < INFECTION_PROBABILITY)
            {
                disease = new Rabies();
                infected = true;
            }
    }
    
    /**
     * Checks if the animal is infected and @return true if that's the case, false otherwise.
     */
    public boolean isInfected()
    {
        return infected;
    }
    
    /**
     * @return the probability of a disease killing the infected animal.
     */
    public double getMortalityRate()
    {
        return disease.getMortalityRate();
    }
    
    /**
     * If infected animals are found in adjacent locations,
     * might inffect current animal.
     */
    public void adjacentInfect()
    {
        Field fauna = getField();
        List<Location> adjacent = fauna.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = fauna.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal anim = (Animal) animal;
                if(anim.isInfected()) {
                    //will try to infect the current animal
                    this.infect();
                }
            }
        }   
    }
}
