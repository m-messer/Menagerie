import java.util.HashMap;
import java.util.Random;
/**
 * Represent simple types of weather.
 * The weather influences all entities in the simulator.
 *
 * @version 2016.02.29 (2)
 */
public class Weather
{
    // Stores the weather type (0-x) and its name.
    private HashMap<Integer, String> allWeather;
    // Current weather type. 
    private int weather;
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        allWeather = new HashMap<>();
        allWeather.put(0, "Clear");
        allWeather.put(1, "Cloudy");
        allWeather.put(2, "Rainy");
        allWeather.put(3, "Foggy");
        changeWeather();
    }

    /**
     * Changes the current weather into a random one.
     * (Can stay the same.)
     */
    public void changeWeather()
    {
        Random rand = new Random(System.nanoTime());
        weather = rand.nextInt(4);
    }
    
    /**
     * @return an Integer representing the current weather type.
     */
    public String getWeather()
    {
        return allWeather.get(weather);
    }
    
    /**
     * @return true if current weather is rainy.
     */
    public boolean isRaining()
    {
        if(weather==2){
            return true;
        }
        return false;
    }
    
    /**
     * @return true if current weather is foggy.
     */
    public boolean isFoggy()
    {
        if(weather==3){
            return true;
        }
        return false;
    }
    
    /**
     * @return true if current weather is cloudy.
     */
    public boolean isCloudy()
    {
        if(weather==1){
            return true;
        }
        return false;
    }
    
    /**
     * @return true if current weather is clear.
     */
    public boolean isClear()
    {
        if(weather==0){
            return true;
        }
        return false;
    }
}
