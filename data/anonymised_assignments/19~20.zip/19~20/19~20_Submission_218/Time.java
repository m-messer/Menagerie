
/**
 * A class representing the time in 24h format.
 *
 * @version 2016.02.29 (2)
 */
public class Time
{
    private int hour;
    // minutes are not being used in the current simulation, but could be needed sometime later, so they are commented out for now.
    //private int min;  
    String displayString;
    
    /**
     * The simlation starts at a random time.
     * for the scale of this simulation, only hours will be taken into account
     */
    public Time(int hour /*, int min */)
    {
        this.hour = hour;
        //this.min = min;
    }

    /**
     * the run() method is called at every new step
     * for the scale of this simulation it will only increment the hours of the current time.
     */
    public void run()
    {
        hour++;
        hour = hour % 24;
    }

    /**
     * @return a standard time-display value
     */
    public String getDisplayValue(int value)
    {
        if(value < 10) {
            return "0" + value;
        }
        else {
            return "" + value;
        }
    }

    /**
     * Checks if it is nighttime.
     * (it is considered to be nighttime between 22:00 and 06:00)
     */
    public boolean isNight()
    {
        if(hour>=22 || hour<6)
            return true;
        return false;
    }

    /**
     * @return a String that contains the hour.
     */
    public String getHour()
    {
        return hour +":00";
    }

}
