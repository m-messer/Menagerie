import java.util.List;
/**
 * A simple model of a primitive.
 * Primitives age, move, eat and die.
 *
 * @version 2016.02.29 (2)
 */
public class Primitive extends Animal
{
    // Characteristics shared by all wolves (class variables).

    // The primitive's species number.
    private static final int speciesNo = 4;
    // The age at which a primitive can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a primitive can live.
    private static final int MAX_AGE = 36; 
    // Marmot's cannot eat more than this. 
    private static final int MAX_FOOD_CAPACITY = 30;
    // The likelihood of a primitive breeding.
    private static final double BREEDING_PROBABILITY = 0.20;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3; // they can do triplets :D
    // The food value of a single animal eaten. In effect, this is the
    // number of steps a primitive can after eating that animal.
    private static final int MARMOT_FOOD_VALUE = 20;
    private static final int LYNX_FOOD_VALUE = 25;
    private static final int DEER_FOOD_VALUE = 30;
    private static final int WOLF_FOOD_VALUE = 30;

    // The probability of a primitive moving during rain.
    private static final double RAIN_MOVEMENT_PROBABILITY = 0.65;
    // The primitive rests at night.
    private boolean actsAtNight = false;
    
    /**
     * Create a primitive. A primitive can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the primitive will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Primitive(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        foodValue.put(0, MARMOT_FOOD_VALUE);
        foodValue.put(1, LYNX_FOOD_VALUE);
        foodValue.put(3, DEER_FOOD_VALUE);
        foodValue.put(2, WOLF_FOOD_VALUE);
        if(randomAge) 
        {
            age = rand.nextInt(getMAXAGE());
            this.foodLevel = rand.nextInt(DEER_FOOD_VALUE);
        }
        else 
        {
            age = 0;
            this.foodLevel = DEER_FOOD_VALUE;
        }
    }
    
    /**
    * Checks if the primitive can be active during night.
    */
    public boolean actsAtNight()
    {
        return actsAtNight;
    }
    
    /**
     * @return the primitive's breeding age.
     */
    protected int getBREEDINGAGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age of a primitive.
     */
    protected int getMAXAGE()
    {
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of a primitive.
     */
    protected double getBREEDINGPROBABILITY()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return the maximum litter size of a primitive.
     */
    protected int getMAXLITTERSIZE()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the marmot's maximum eating capacity.
     */
    protected int getMaxFoodCapacity()
    {
        return MAX_FOOD_CAPACITY;
    }
    
    /**
     * @return primitive's species number.
     */
    protected int getSpeciesNo()
    {
        return speciesNo;
    }
    
    /**
     * @return the probability of a primitive hunting at night.
     */
    protected double getNightHuntingProbability()
    {
        return (double) 0;
    }
    
    /**
     * @return the probability of a primitive to move during rain.
     */
    protected double getRAINMOVEMENTPROBABILITY()
    {
        return RAIN_MOVEMENT_PROBABILITY;
    }
}
