/**
 * A simple model of a plant.
 * Common plants can grow and feed some animals.
 *
 * @version 2016.02.29 (2)
 */
public class CommonPlant extends Plant
{
    // max level of resource that can be supplied from CommonPlants
    private static final int MAX_WORTH = 12;
    //CommonPlant's species number.
    private static final int speciesNo = 100;
    
    /**
     * Create a common plant.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public CommonPlant(Field field, Location location)
    {
        super(field, location);
        setWorth(rand.nextInt(MAX_WORTH));
    }
    
    /**
     * @return the maxim value of resource this plant can provide.
     */
    protected int getMaxWorth()
    {
        return MAX_WORTH;
    }
    
    /** 
     * @return the species number.
     */
    protected int getSpeciesNo()
    {
        return speciesNo;
    }
}
