import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that different animals will be created in any given grid position.
    private static final double LYNX_CREATION_PROBABILITY = 0.10; //0.08;
    private static final double MARMOT_CREATION_PROBABILITY = 0.18;//0.18;
    private static final double WOLF_CREATION_PROBABILITY = 0.07;//0.08; 
    private static final double DEER_CREATION_PROBABILITY = 0.14;//0.10; 
    private static final double PRIMITIVE_CREATION_PROBABILITY = 0.09;//0.09; 
    // The probability that a plant will be created in any given grid position.
    private static final double COMMONPLANT_CREATION_PROBABILITY = 0.70; 
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the animal field.
    private Field fauna;
    // The current state of the plant field.
    private Field flora;
    // The current step of the simulation.
    private int step;
    // A graphical view of the animal simulation (and also a separate one for plants display).
    private SimulatorView animalView;
    private SimulatorView plantView;
    // The current time of the simulation.
    private Time currentTime;
    // The current weather of the simlation.
    private Weather currentWeather;
    // A shared random number generator to control t.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        currentTime = new Time(rand.nextInt(23));
        currentWeather = new Weather();

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        fauna = new Field(depth, width);
        flora = new Field(depth, width);

        // When creating a new Simulator, a separate field showing plants' location will also pop up.
        plantView = new SimulatorView(depth, width);
        // Create a view of the state of each location in the field.
        animalView = new SimulatorView(depth, width);
        animalView.setColor(Marmot.class, Color.ORANGE);
        animalView.setColor(Lynx.class, Color.MAGENTA);
        animalView.setColor(Wolf.class, Color.RED);
        animalView.setColor(Deer.class, Color.GREEN);
        animalView.setColor(Primitive.class, Color.CYAN);
        plantView.setColor(CommonPlant.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && animalView.isViable(fauna); step++) {
            simulateOneStep();
            //delay(60);   // comment this to run faster
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     */
    public void simulateOneStep()
    {
        step++;
        currentTime.run();
        
        // every 16 steps, the weather might change
        if(step % 16 == 0) {
            currentWeather.changeWeather();
        }
        
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext();) 
        {
            Animal animal = it.next();
            //animals can be infected by other infected animals, not depending on the species
            if(animal.isAlive())
            {
                animal.adjacentInfect();
            }
            //infected animals can die at any time
            if(animal.isInfected() && rand.nextDouble() < animal.getMortalityRate())
            {
                animal.setDead();
            }
            else
            {
                if(currentTime.isNight()&& !animal.actsAtNight())
                {
                    animal.restNightShift();
                }
                else if(currentTime.isNight()&& animal.actsAtNight())
                {
                    //fauna is already taken as parameter when creating the animals
                    animal.activeNightShift(newAnimals, currentWeather, flora);
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }
                else
                { 
                    //animal.act(newAnimals, currentWeather, flora);
                    animal.rainMovement(newAnimals, currentWeather, flora);
                    if(! animal.isAlive()) {
                        it.remove();
                    }
                }
            }
        }
        
        //during rain and clear weather, plants regenerate.
        if(currentWeather.isRaining() && !currentTime.isNight())
        {
            for(Iterator<Plant> it = plants.iterator(); it.hasNext(); )
            {
                Plant plant = it.next();
                plant.regenerate();
            }
        }
        //plants also grow back during day and clear weather, but more slowly
        else if(currentWeather.isClear() && !currentTime.isNight())
        {
            for(Iterator<Plant> it = plants.iterator(); it.hasNext(); )
            {
                Plant plant = it.next();
                plant.incrementWorth();
            }
        }
        
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        animalView.showStatus(step, fauna, currentTime.isNight(), currentTime, currentWeather);
        plantView.showStatus(step, flora, currentTime.isNight(), currentTime, currentWeather);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        animalView.showStatus(step, fauna, currentTime.isNight(), currentTime, currentWeather);
        plantView.showStatus(step, flora, currentTime.isNight(), currentTime, currentWeather);
    }

    /**
     * Randomly populate the field with the animals below.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        fauna.clear();
        flora.clear();
        //both fields hold the same parameters, hence one iteration only.
        for(int row = 0; row < fauna.getDepth(); row++) 
        {
            for(int col = 0; col < fauna.getWidth(); col++) 
            {
                // Might populate cell with animals and/or plants.
                populateAnimals(row,col);
                populatePlants(row,col);
            }
        }
    }

    /**
     * Might create an animal at the given location.
     * It is also possible to leave the location empty.
     */
    private void populateAnimals(int row, int col)
    {
        if(rand.nextDouble() <= MARMOT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lynx lynx = new Lynx(true, fauna, location);
                    lynx.infect();
                    animals.add(lynx);
                }
                else if(rand.nextDouble() <= MARMOT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Marmot marmot = new Marmot(true, fauna, location);
                    marmot.infect();
                    animals.add(marmot);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, fauna, location);
                    wolf.infect();
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, fauna, location);
                    deer.infect();
                    animals.add(deer);
                }
                else if(rand.nextDouble() <= PRIMITIVE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Primitive primitive = new Primitive(true, fauna, location);
                    primitive.infect();
                    animals.add(primitive);
                }
    }
    
    /**
     * Might create a plant at the given location.
     * Plants can be created at the same location as animals.
     * It is possible to leave the location empty.
     */
    private void populatePlants(int row, int col)
    {
        if(rand.nextDouble() <= COMMONPLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    CommonPlant plant = new CommonPlant(flora, location);
                    plants.add(plant);
                }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * used this in the simulator view
     */
    private boolean isNight()
    {
        return currentTime.isNight();
    }
}
