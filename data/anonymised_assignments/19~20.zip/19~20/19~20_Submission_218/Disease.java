import java.util.Random;
/**
 * A class representing shared characteristics of diseases. 
 * (for now we only have and care for one disease)
 *
 * @version 2016.02.29 (2)
 */
public abstract class Disease
{
    // A shared random number generator to generate infected animals at start of simulation.
    protected static final Random rand = Randomizer.getRandom();
    
    public Disease()
    {
        
    }

    /**
     * @return the probability of an infected animal to die.
     */
    abstract protected double getMortalityRate();
}
