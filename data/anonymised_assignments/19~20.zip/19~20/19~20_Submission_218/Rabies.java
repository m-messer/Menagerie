
/**
 * A simple model of a disease.
 * Diseases affect animals.
 * An inffected animal might die at any step.
 *
 * @version 2016.02.29 (2)
 */
public class Rabies extends Disease
{
    // The probability of an animal being killed by this disease at any step.
    private static final double MORTALITY_RATE = 0.10;
    
    public Rabies()
    {
        
    }
    
    /**
     * @return the dying probability.
     */
    protected double getMortalityRate()
    {
        return MORTALITY_RATE;
    }
}
