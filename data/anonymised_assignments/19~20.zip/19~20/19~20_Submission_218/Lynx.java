import java.util.List;
/**
 * A simple model of a Marmot.
 * Lynxes age, move, eat marmots, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Lynx extends Animal
{
    // Characteristics shared by all lynxes (class variables).
    
    // The lynx's species number.
    private static final int speciesNo = 1;
    // The age at which a lynx can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a lynx can live.
    private static final int MAX_AGE = 30;
    // Lynxes cannot eat more than this. 
    private static final int MAX_FOOD_CAPACITY = 22;
    // The likelihood of a lynx breeding.
    private static final double BREEDING_PROBABILITY = 0.37;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single marmot. In effect, this is the
    // number of steps a lynx can go before it has to eat again.
    private static final int MARMOT_FOOD_VALUE = 20;
    // The probability of a lynx moving during rain.
    private static final double RAIN_MOVEMENT_PROBABILITY = 0.47;
    // Lynxes can hunt during nighttime
    private static final double NIGHT_HUNTING_PROBABILITY = 0.35;
    // The lynx can be active during nighttime.
    private boolean actsAtNight = true;

    /**
     * Create a lynx. A lynx can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lynx will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lynx(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        foodValue.put(0, MARMOT_FOOD_VALUE);
        if(randomAge) {
            age = rand.nextInt(getMAXAGE());
            this.foodLevel = rand.nextInt(MARMOT_FOOD_VALUE);
        }
        else {
            age = 0;
            this.foodLevel = MARMOT_FOOD_VALUE;
        }
    }

    /**
    * Checks if the lynx can be active during night.
    */
    public boolean actsAtNight()
    {
        return actsAtNight;
    }
    
    /**
     * @return the lynx's breeding age.
     */
    protected int getBREEDINGAGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age of a lynx.
     */
    protected int getMAXAGE()
    {
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of a lynx.
     */
    protected double getBREEDINGPROBABILITY()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return the maximum litter size of a lynx.
     */
    protected int getMAXLITTERSIZE()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the lynx's maximum eating capacity.
     */
    protected int getMaxFoodCapacity()
    {
        return MAX_FOOD_CAPACITY;
    }
    
    /**
     * @return lynx's species number.
     */
    protected int getSpeciesNo()
    {
        return speciesNo;
    }
    
    /**
     * @return the probability of a lynx hunting at night.
     */
    protected double getNightHuntingProbability()
    {
        return NIGHT_HUNTING_PROBABILITY;
    }
    
    /**
     * @return the probability of a deer to move during rain.
     */
    protected double getRAINMOVEMENTPROBABILITY()
    {
        return RAIN_MOVEMENT_PROBABILITY;
    }
}
