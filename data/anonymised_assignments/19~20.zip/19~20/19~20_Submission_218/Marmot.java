import java.util.List;
/**
 * A simple model of a marmot.
 * Marmots age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Marmot extends Animal
{
    // Characteristics shared by all marmots (class variables).

    // The marmot's species number.
    private static final int speciesNo = 0;
    // The age at which a marmot can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a marmot can live.
    private static final int MAX_AGE = 18; 
    // Marmot's cannot eat more than this. 
    private static final int MAX_FOOD_CAPACITY = 16;
    // The likelihood of a marmot breeding.
    private static final double BREEDING_PROBABILITY = 0.70;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // number of steps a marmot can go before it has to eat again.
    private static final int COMMONPLANT_FOOD_VALUE = 15;
    // The probability of a rabit moving during rain.
    private static final double RAIN_MOVEMENT_PROBABILITY = 0.60;
    // The marmot is not active at night.
    private boolean actsAtNight = false;
    
    /**
     * Create a new marmot. A marmot may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the marmot will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Marmot(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        if(randomAge) {
            age = rand.nextInt(getMAXAGE());
            this.foodLevel = rand.nextInt(MAX_FOOD_CAPACITY);
        }
        else {
            age = 0;
            this.foodLevel = MAX_FOOD_CAPACITY;
        }
        foodValue.put(100, COMMONPLANT_FOOD_VALUE);
    }
   
    /**
    * Checks if the marmot acts during night.
    */
    public boolean actsAtNight()
    {
        return actsAtNight;
    }
    
    /**
     * @return the marmot's breeding age.
     */
    protected int getBREEDINGAGE()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return the maximum age of a marmot.
     */
    protected int getMAXAGE()
    {
        return MAX_AGE;
    }
    
    /**
     * @return the breeding probability of a marmot.
     */
    protected double getBREEDINGPROBABILITY()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return the maximum litter size of a marmot.
     */
    protected int getMAXLITTERSIZE()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return the marmot's maximum eating capacity.
     */
    protected int getMaxFoodCapacity()
    {
        return MAX_FOOD_CAPACITY;
    }
    
    /**
     * @return marmot's species number.
     */
    protected int getSpeciesNo()
    {
        return speciesNo;
    }
    
    /**
     * @return 0 probability, because marmots sleep during the night.
     */
    protected double getNightHuntingProbability()
    {
        return (double) 0;
    }
    
    /**
     * @return the probability of a marmot to move during rain.
     */
    protected double getRAINMOVEMENTPROBABILITY()
    {
        return RAIN_MOVEMENT_PROBABILITY;
    }
}
