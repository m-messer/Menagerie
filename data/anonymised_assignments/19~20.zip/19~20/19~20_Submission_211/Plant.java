import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * An abstract class to create different plants
 *
 * @version 19/02/2020
 */
public abstract class Plant extends Actor
{   
    public Plant(Field field, Location location)
    {
        super(field, location);
    }
}