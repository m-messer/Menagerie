import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{
    // The animals age.  
    protected int age;
    //The animal's food level. 
    protected int foodLevel; 
        // the gender of the gopher
    protected boolean isMale;
    //The probability og a gopher having a virus 
    protected double Virus; 
    /**
     * Create a new animal at location in field.     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        foodLevel = getFoodValue(); 
    }



    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    protected abstract int getFoodValue(); 
    
    protected abstract void giveBirth(List<Actor> newAnimals);

    protected abstract Location findFood();
    
    protected abstract double getVirus();
   
    private boolean getWhetherAMale()
    {
        return isMale;
    }

}
