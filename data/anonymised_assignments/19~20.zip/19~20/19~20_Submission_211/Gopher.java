import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Gopher.
 *
 * @version 19/02/2020
 */
public class Gopher extends Animal
{
    // Characteristics shared by all gophers (class variables).

    // The age at which a gopher can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a gopher can live.
    private static final int MAX_AGE = 10;
    // The likelihood of a gopher breeding.
    private static final double BREEDING_PROBABILITY = 0.35015;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // number of steps a fox can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 9;
    // The likelihood of a gopher having a virus
    private static final double VIRUS_PROBABILITY = 0.11;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The gopher's food level, which is increased by eating gophers.
    private int foodLevel;
    // the gender of the gopher
    private boolean isMale;
    //The probability og a gopher having a virus 
    private double Virus; 
    // Keep a track of weather
    private Weather weather;
    /**
     * Create a new gopher. A gopher may be created with age
     * zero (a new born) or with a random age.     * 
     * @param randomAge If true, the gopher will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gopher(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = (rand.nextInt(MAX_AGE));
        }else {
            age = 0;
            foodLevel = PLANT_FOOD_VALUE;
        }
        foodLevel = PLANT_FOOD_VALUE;
        isMale= rand.nextBoolean();
        Virus = rand.nextDouble();
    }

    /**
     * Return gender of Gopher.
     * @return gender of Gopher.
     */
    private boolean getWhetherAMale()
    {
        return isMale;
    }

    /**
     * Return Virus probability of Gopher.
     * @return Virus probability of Gopher.
     */
    public double getVirus()
    {
        return Virus;
    }    

    /**
     * Check whether or not this gopher is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGophers A list to return newly born gophers.
     * @override from animal super-class
     */
    protected void giveBirth(List<Actor> newGophers)
    {
        // New gophers are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Gopher young = new Gopher(true, field, loc);
            newGophers.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed and does not have a virus probability more than threshold.
     * @return The number of births (may be zero).
     * @override from animal super-clas
     */
    protected int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Gopher) {
                Gopher gopher = (Gopher) animal;
                //if the gopher has more virus than the probability
                //then kill the gopher itself and it's partner                
                if (gopher.VIRUS_PROBABILITY>=gopher.Virus ||VIRUS_PROBABILITY>= Virus){ 
                    setDead();
                }else{
                    //if the mating partners have opposite genders 
                    //then they will give birth
                    if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                        if((getWhetherAMale() && !gopher.getWhetherAMale())||(!getWhetherAMale() && gopher.getWhetherAMale())){
                            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                        }   
                    }
                }
            }
        }
        return births;
    }

    /**
     * This is what the gopher does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGophers A list to return newly born gophers.
     * @override from actor super-class
     */
    public void act(List<Actor> newGophers)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newGophers);   
            if(isAlive()){
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Look for gophers adjacent to the current location.
     * Only the first live gopher is eaten.
     * @return Where food was found, or null if it wasn't.
     * @override from animal super-class
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Plant) {
                Plant plant = (Plant) actor;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Return foodValue of Gopher.
     * @return foodValue of Gopher.
     * @override from actor super-class
     */
    protected int getFoodValue(){
        return PLANT_FOOD_VALUE; 
    }

    /**
     *  Retun breeding age of gopher.
     *  @retun breeding age of gopher.
     *  @override from actor super-clas
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * A gopher can breed if it has reached the breeding age.
     * @return true if the gopher can breed, false otherwise.
     * @override from animal super-class
     */
    protected boolean canBreed()
    {
        return age>= getBreedingAge();
    }

    /**
     * Return gophers max age.
     * @return gophers max age.
     * @override from actor super-clas
     */

    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Return true if gopher is alive, false otherwise.
     * @return true if gopher is alive, false otherwise. 
     * @override from actor super-class
     */
    public boolean isActive()
    {
        return isAlive();
    }

}
