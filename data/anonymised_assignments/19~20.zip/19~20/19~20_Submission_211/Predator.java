
/**
 * Write a description of interface Predator here.
 *
 * @version (a version number or a date)
 */
public interface Predator
{
    public Location findFood();
}
