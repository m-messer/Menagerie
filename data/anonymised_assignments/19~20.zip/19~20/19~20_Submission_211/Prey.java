
/**
 * Write a description of interface Prey here.
 *
 * @version (a version number or a date)
 */
public interface Prey
{
    public Location findFood();
}
