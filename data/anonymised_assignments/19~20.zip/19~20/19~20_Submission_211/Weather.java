import java.util.Random;
/**
 * This class models the weather throughout the simulation
 * The weather changes based on the random number generated, thus the weather occurs
 * randomly. It changes based on intial probablities set on each type of weather
 * @version 2016.02.19
 */
public class Weather 
{
    //a string to keep track of the currentWeather 
    public String currentWeather;
    //a random generator, and instance of the Random class
    private static final Random rand = Randomizer.getRandom();
    //The current state of the Simulator
    public Simulator sim;
    
    //Constants for each weather name.
    private static final String NORMAL_WEATHER = "Normal";
    private static final String FOGGY_WEATHER = "Foggy";
    private static final String RAINY_WEATHER = "Rainy";
    private static final String SUNNY_WEATHER = "Sunny";
    
    //Constants for each weather probablity
    private static final double NORMAL_WEATHER_PROBABLITY = 0.7;
    private static final double FOGGY_WEATHER_PROBABLITY = 0.15;
    private static final double RAINY_WEATHER_PROBABLITY = 0.13;
    private static final double SUNNY_WEATHER_PROBABLITY = 0.02;
    /**
     * Constructor for objects of class Weather
     */
    public Weather(Simulator sim)
    {
        this.sim= sim;
        currentWeather = NORMAL_WEATHER;
    }

    /**
     * This method generates a random float between 0.0 to 1.0
     * @return float- randomly generated float number
     */
    public float getRandomFloat(){
        return rand.nextFloat();
    }

    /**
     * This method  compares the generated random number with the probabilities of the weather.
     * Thus most of the time it will be normal weather since the probablity is relatively high. 
     * @return String- returns the currentWeather (a string)
     */
    public String getRandomWeather(){
        if (getRandomFloat() < NORMAL_WEATHER_PROBABLITY ){
            currentWeather = NORMAL_WEATHER;
        } 
        else if (getRandomFloat() < FOGGY_WEATHER_PROBABLITY ){
            currentWeather = FOGGY_WEATHER;
        }
        else if (getRandomFloat() < RAINY_WEATHER_PROBABLITY){
            currentWeather = RAINY_WEATHER;
        }
        else if (getRandomFloat() < SUNNY_WEATHER_PROBABLITY){
            currentWeather = SUNNY_WEATHER;
        }
        else if (getRandomFloat() > NORMAL_WEATHER_PROBABLITY ){
            currentWeather = NORMAL_WEATHER;
        }
        return currentWeather;
    }
}
