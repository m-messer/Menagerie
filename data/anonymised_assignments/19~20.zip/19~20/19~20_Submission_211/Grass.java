import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A subclass of Plant. 
 * Eaten by gophers and rodents
 *
 * @version 19/02/2020
 */
public class Grass extends Plant
{
    // instance variables - replace the example below with your own
    // The age at which a gopher can start to breed.
    // The age at which a Plant can start to breed.
    private static final int BREEDING_AGE = 0;
    // // The age to which a Plant can live.
    private static final int MAX_AGE = 14;
    // // The likelihood of a Plant breeding.
    private static final double BREEDING_PROBABILITY = 0.060015;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    // A tracker to keep track of the time
    private Time time;
    // A tracker to keep track of the weather
    private Weather weather;

    private Simulator simulator;
    private int age;
    /**
     * Constructor for objects of class Grass
     */
    public Grass (Field field, Location location)
    {
        // initialise instance variables
        super(field, location);
        age = 0;
        weather= new Weather(simulator);
        //sim = new Simulator();
        //time = new Time();

    }

    /**
     * Check whether or not this Plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newplants A list to return newly born plants.
     */
    private void giveBirth(List<Actor> newGrasses)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        if(isAlive()){
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Grass young = new Grass(field, loc);
                newGrasses.add(young);
            }
        }
    }

    /**
     * This is what the Plant does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newplants A list to return newly born plants.
     * @override from actor super-class
     */
    public void act(List<Actor> newGrass)
    {
        setAge();
        incrementAge();
        if(isAlive()){
            if(weather.getRandomWeather().matches("Rainy|Sunny|Normal") ||!Time.isNight()){
                giveBirth(newGrass);            
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     * @override from actor super-class
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /** 
     * Return the age at which the plant can breed
     * @return the age at which the plant can breed 
     * @override from actor super-class
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * A Plant can breed if it has reached the breeding age.
     * @return true if the Plant can breed, false otherwise.
     * @override from actor super-class
     */
    protected boolean canBreed()
    {
        return getAge()>= getBreedingAge();
    }

    protected void setAge()
    {
        if (getAge() == MAX_AGE-1)
        {
            age=0;
        } 
    }

    /**  
     * Return true if plant is alive
     * @return true if plant is alive
     * @override from actor super-class
     */    
    public boolean isActive()
    {
        return isAlive();
    }

    protected  int getMaxAge()
    {
        return MAX_AGE;
    }
}

