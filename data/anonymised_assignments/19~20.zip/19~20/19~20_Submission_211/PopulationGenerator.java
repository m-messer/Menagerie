import java.awt.Color;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
/**
 * Write a description of class Grass here.
 *
 * @version 19/02/2020
 */
public class PopulationGenerator
{
    // The probability that a weasel will be created in any given grid position.
    private static final double WEASEL_CREATION_PROBABILITY = 0.05;
    // The probability that a rodent will be created in any given grid position.
    private static final double RODENT_CREATION_PROBABILITY = 0.04;
    // The probability that a GOPHER will be created in any given grid position.
    private static final double GOPHER_CREATION_PROBABILITY = 0.11;    
    // The probability that a Coyote will be created in any given grid position.
    private static final double COYOTE_CREATION_PROBABILITY = 0.04;
    // The probability that a BEAR will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.06;
    // The probability that a Plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY=0.12016;
    //The field for the simulation
    private Field field;
    // A graphical view of the simulator
    private SimulatorView view;
    //A counter to keep track of the weather
    private Weather weather;

    /**
     * Constructor for objects of class PopulationGenerator
     * @param field The field of the simulation.
     * @param view The graphical view of the simulation.
     */
    public PopulationGenerator(Field field, SimulatorView view, Simulator sim)
    {
        this.field = field;
        this.view = view;
        view.setColor(Gopher.class, Color.ORANGE);
        view.setColor(Weasel.class, Color.BLUE);
        view.setColor(Rodent.class, Color.RED);
        view.setColor(Coyote.class, Color.MAGENTA);
        view.setColor(Bear.class, Color.darkGray);
        view.setColor(Grass.class, Color.GREEN);
        weather= new Weather(sim);
    }

    /**
     * Randomly populate the field with weasels, gophers and coyotes, etc.
     */
    public List<Actor> populate()
    {
        List <Actor> actors = new ArrayList<Actor>();
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WEASEL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Weasel weasel = new Weasel(true, field, location);
                    actors.add(weasel);   
                    // else leave the location empty.
                }
                if(rand.nextDouble() <= RODENT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rodent rodent= new Rodent(true, field, location);
                    actors.add(rodent);   
                    // else leave the location empty.
                }
                if(rand.nextDouble() <= GOPHER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Gopher gopher = new Gopher(true, field, location);
                    actors.add(gopher);   
                    // else leave the location empty.
                }
                else if(rand.nextDouble() <=COYOTE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Coyote coyote= new Coyote(true, field, location);
                    actors.add(coyote);   
                    // else leave the location empty.                    
                }
                else if(rand.nextDouble() <=BEAR_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Bear bear= new Bear(true, field, location);
                    actors.add(bear);   
                    // else leave the location empty.
                }
                else if(rand.nextDouble() <=PLANT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Plant plant= new Grass(field, location);
                    actors.add(plant);   
                    // else leave the location empty.
                }
            }
        }
        return actors;
    }
}
