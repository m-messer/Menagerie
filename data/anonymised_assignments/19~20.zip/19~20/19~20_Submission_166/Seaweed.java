import java.util.*;

/**
 * A simple model of a seaweed.
 * Seaweeds age, move, breed, and die.
 * 
 * @version 2020.02.23
 */
public class Seaweed extends Animal
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    /**
     * Create a new seaweed. A seaweed may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the seaweed will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current simulator 
     */
    public Seaweed(boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(field, location, simulator);
    }
    
    /**
     * This is what the seaweeds do, they don't move, and they only breed. I
     * did not set the maximum age because seems like this plant can keep on growing
     * as long as no animals eats it.
     * @param newSeaweeds A list to return newly born seaweeds.
     */
    public void act(List<Animal> newSeaweeds)
    {
        if(isAlive()) {
            giveBirth(newSeaweeds);
        }
    }
    
    /**
     * The way seaweeds breed is they will spread spores, and those spores will
     * flow in the ocean. The spores might die, or they might find a place and
     * start growing. Because of that, in my program, the way seaweed grows is that
     * for each seaweed that's alive, each blank space on the map has a chance of
     * having a new seaweed. Just like how each seaweed spreads spores, those
     * spores will flow to any place on the ocean.
     * @param newSeaweeds A list to return newly born seaweeds.
     */
    private void giveBirth(List<Animal> newSeaweeds)
    {
        // New seaweeds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        Simulator sim = getSimulator();
        List<Location> free = field.allFreeLocations();
        Collections.shuffle(free, rand);
        for(Iterator<Location> it = free.iterator(); it.hasNext();) {
            double prob = Math.random();
            Location loc = it.next();
            it.remove();
            if (prob <= 0.00005){
                Seaweed young = new Seaweed(false, field, loc, sim);
                newSeaweeds.add(young);
            }
        }
    }
}
