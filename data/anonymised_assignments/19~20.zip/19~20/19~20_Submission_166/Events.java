import java.util.*;
/**
 * This class determines the season and weather for all animals on the map,
 * and generates the disease for each animal
 *
 * 
 * @version 2020.02.23
 */
public class Events
{
    //A variable indicates the season
    private String season;
    //A list of all possible weathers
    private List <String> weather;
    //A variable indicates the weather of a day
    private String weathers;
    //A list of all possible diseases
    private List <String> disease;
    //A variable indicates the disease
    private String diseases;
    private Simulator simulator;
    //A counter that is used to generate the season and weather
    private int step;

    /**
     * Creats a new event class, that contains all possible weathers and disease
     * @param simulator If the input is null, that means a new event for a specific
     * animal is created, and the animal has it's own disease and landscape. If the input 
     * is simulater, that means this class is valid for all animals, and the class
     * is used to determine the weather and season
     */
    public Events(Simulator simulator)
    {
        this.simulator = simulator;
        weather = new ArrayList<>();
        disease = new ArrayList<>();
        weather.add("Rainy");
        weather.add("Sunny");
        weather.add("Windy");
        disease.add("Parasite");
        disease.add("Fungal Infection");
        disease.add("Mammals' Disease");
        disease.add("Influenza");
    }
    
    /**
     * According to the number of step, determines which season it is. In this
     * program each step is an hour, but if that is the case the change of season
     * will be too slow, so I set the change of season to be every 7 days
     */
    public String season(){
        int count = 0;
        while(step >= 0){
            step -= 672;
            count ++;
        }
        step += 672;
        if (step % 672 < 168){
            season = "Winter";
        }
        else if (step % 672 < 336){
            season = "Spring";
        }
        else if (step % 672 < 504){
            season = "Summer";
        }
        else {
            season = "Autumn";
        }
        return season;
    }
    
    /**
     * There is a chance the animal will get a disease, and this method can 
     * generates that
     */
    public void disease(){
        double prob = Math.random();
        if (prob < 0.9){
            diseases = null;
        }
        else if (prob < 0.91){
            diseases = disease.get(3);
        }
        else if (prob < 0.94){
            diseases = disease.get(2);
        }
        else if (prob < 0.97){
            diseases = disease.get(1);
        }
        else {
            diseases = disease.get(0);
        }
    }
    
    /**
     * The weather changes every day, this method can randomly generates a weather
     */
    public void weather(){
        if(step % 24 == 0) {   
            //when step%24 = 0, that means it's a new week so a new weather is
            //generated
            Random w = new Random();        
            int a = w.nextInt(3);
            weathers = weather.get(a);
        }
        //the weather will start by sunny
        if(step < 24){
            weathers = weather.get(1);
        }
    }
    
    /**
     * returns the season
     * @return returns the season
     */
    public String getSeason(){
        return season;
    }
    
    /**
     * returns the weather
     * @return returns the weather
     */
    public String getWeather(){
        return weathers;
    }
    
    /**
     * returns the disease
     * @return returns the disease
     */
    public String getDisease(){
        return diseases;
    }
    
    /**
     * This method will increment the step, and generates the weather, disease
     * and determines the season.
     */
    public void generate(){
        step ++;
        weather();
        disease();
        season();
    }
}
