import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing herrings and seales.
 * 
 * @version 2020.02.23
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 140;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a seal will be created in any given grid position.
    private static final double SEAL_CREATION_PROBABILITY = 0.05;
    // The probability that a herring will be created in any given grid position.
    private static final double HERRING_CREATION_PROBABILITY = 0.15;   
    private static final double SEAGULL_CREATION_PROBABILITY = 0.05;
    private static final double SEAWEED_CREATION_PROBABILITY = 0.25;
    private static final double MUSSEL_CREATION_PROBABILITY = 0.2;
    private static final double CRAB_CREATION_PROBABILITY = 0.2;
    private ArrayList<String> season;
    private ArrayList<String> weather;
    private ArrayList<String> disease;
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    private Simulator simulator;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    private Events event;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        step = 0;
        //create a new event class
        event = new Events(this);
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        animals = new ArrayList<>();
        field = new Field(depth, width);
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Herring.class, Color.ORANGE);
        view.setColor(Seal.class, Color.BLUE);
        view.setColor(Seagull.class, Color.RED);
        view.setColor(Mussel.class, Color.YELLOW);
        view.setColor(Seaweed.class, Color.GREEN);
        view.setColor(Crab.class, Color.PINK);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 0; step < numSteps && view.isViable(field); step++) {
            simulateOneStep();
        }
    }   
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * seal and herring.
     */
    public void simulateOneStep()
    {
        step++;
        //update the events of the step(season and weather)
        event.generate();
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all herrings act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born seales and herrings to the main lists.
        animals.addAll(newAnimals);
        view.showStatus(step,field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with seales and herrings.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SEAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location, this);
                    animals.add(seal);
                }
                else if(rand.nextDouble() <= HERRING_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Herring herring = new Herring(true, field, location, this);
                    animals.add(herring);
                }
                else if(rand.nextDouble() <= SEAGULL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seagull seagull = new Seagull(true, field, location, this);
                    animals.add(seagull);
                }
                else if(rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seaweed seaweed = new Seaweed(true, field, location, this);
                    animals.add(seaweed);
                }
                else if(rand.nextDouble() <= MUSSEL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mussel mussel = new Mussel(true, field, location, this);
                    animals.add(mussel);
                }
                else if(rand.nextDouble() <= CRAB_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Crab crab = new Crab(true, field, location, this);
                    animals.add(crab);
                }
            }
        }
    } 
    public Events getEvent(){
        return event;
    }
    public int getStep(){
        return step;
    }
}
