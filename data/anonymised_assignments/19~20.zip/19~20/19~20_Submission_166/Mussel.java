import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a mussel.
 * Mussels , move, eat seaweeds, and die.
 * 
 * @version 2020.02.23
 */
public class Mussel extends Animal
{
    // Characteristics shared by all musseles (class variables).
    // The age at which a mussel can start to breed.
    private static final int MALE_BREEDING_AGE = 5;
    private static final int FEMALE_BREEDING_AGE = 4;
    // The average age of a mussel.
    private static final int MALE_AVE_AGE = 800;
    private static final int FEMALE_AVE_AGE = 625;
    // The likelihood of a mussel breeding.
    private double breedingProbability;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single mussel. In effect, this is the
    // number of steps a mussel can go before it has to eat again.
    private static final int SEAWEED_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The probability it will hunt successfully.
    private static final double HUNT_PROBABILITY = 0.7;
    // Individual characteristics (instance fields).
    // The mussel's age.
    private int age;
    //The max age of a specific mussel.
    private int maxAge;
    // The mussel's food level, which is increased by eating mussels.
    private double foodLevel;
    //The amount of food level that will be decreased every step, this can be 
    //effected by season, diseases...
    private double hungerRate;
    //Some animals are more active than others. This is the max number of grids
    //an animal moves each step
    private int moveValue;
    //a link to the event class
    private Events event;
    //After getting a desease, this value will keep decreasing and when reaches 0, the animal dies.
    private int resistance;
    //The cure level of a disease. When an animal gets a disease, this variable is
    //0, and when it reaches 100, the disease is cured.
    private int cure;
    //A variable indicates the current disease that the animal has. Each animal
    //can have a maximum number of 1 disease at a time, and influenza can infect
    //other adjacent animals.
    private String disease;
    //A variable indicates the weather of the day
    private String weather;
    //A variable indicates the current season
    private String season;
    //A variable indicates the current landscape
    private String landscape;
    //The rate of the decrease of the resistance. 
    private int resistRate;
    //The rate of curing of a disease, it's different for different disease
    private int cureRate;
    //The probability of successfully hunting an animal
    private double huntingProbability;
    //The hour of the day
    private int hour;
    //The gender of the animal
    private String sex;

    /**
     * Create a mussel. A mussel can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the mussel will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param simulator The current simulator 
     */
    public Mussel(boolean randomAge, Field field, Location location, Simulator simulator)
    {
        super(field, location, simulator);
        Random r = new Random();        
        int s = r.nextInt(2);
        //Randomly assign the gender
        if(s == 0) {
            sex = "female";     
        }
        else{
            sex = "male";
        }        
        double chance = Math.random();
        //The max age of the animal will approximately follow a normal
        //distribution
        if (chance<0.6){
            maxAge = getMAX_AGE();
        }
        else if (chance<0.75){
            maxAge = getMAX_AGE() + rand.nextInt(15);
        }
        else if (chance<0.9){
            maxAge = getMAX_AGE() - rand.nextInt(15);
        }
        else if (chance<0.95){
            maxAge = getMAX_AGE() + rand.nextInt(20);
        }
        else{
            maxAge = getMAX_AGE() - rand.nextInt(20);
        }
        if(randomAge) {
            age = rand.nextInt(maxAge);
            foodLevel = rand.nextInt(SEAWEED_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SEAWEED_FOOD_VALUE;
        }
        //creates a new event class that indicates the disease and landscape
        event = new Events(null);
        //Initialize the resistance and cure
        resistance = 100;
        cure = 0;
    }
    
    /**
     * This is what the mussel does most of the time: it eats seaweed
     * . In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newmusseles A list to return newly born musseles.
     */
    public void act(List<Animal> newmusseles)
    {
        Simulator sim = getSimulator();
        //updates the disease and landscape
        event.generate();
        //Standardize the data(clears the affect (for example weather) in the previous day)
        standardize();
        incrementAge();
        incrementHunger();
        //assign the disease
        if(isAlive()){
            if (disease == null){
                effect(null);
                if (disease == null){
                    if (Math.random() < 0.2){
                        //the animal might get infected by another animal who 
                        //has the influenza
                        infection();
                        effect(disease);
                    }
                }
            } 
            else {
                effect(disease);
            }
            //Changes the values according to the information of the day
            constant();
            if (disease != null){
                cur();
                resist();
            }
        }
        //The animal will only move when they are awake. The active time is
        //different for different animals
        if(isAlive() && (sim.getStep()%24) > 5 && (sim.getStep()%24) < 19 ) {
            giveBirth(newmusseles);
            int g = moveValue;
            //The animals will move at least one step per hour (If they are
            //awake)
            if (moveValue < 1){
                g = 1;
            }
            for (int i = 0; i < rand.nextInt(g); i++){ 
                if(isAlive()){
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
                }
            }
        }
    }
    
    /**
     * According to my reaserch, the male and female mussels has different 
     * maximum age, and this method checks the gender and assign the maximum
     * age
     * @return returns the maximum age of this animal
     */
    private int getMAX_AGE(){
        if(sex.equals("male")){
            return MALE_AVE_AGE;
        }
        else{
            return FEMALE_AVE_AGE;
        }
    }
    
    /**
     * According to my reaserch, the male and female mussels has different 
     * breeding age, and this method checks the gender and assign the breeding
     * age
     * @return returns the breeding age of this animal
     */
    private int getBREEDING_AGE(){
        if(sex.equals("male")){
            return MALE_BREEDING_AGE;
        }
        else{
            return FEMALE_BREEDING_AGE;
        }
    }
    
    /**
     * Increase the age. This could result in the mussel's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }
    
    /**
     * Make this mussel more hungry. This could result in the mussel's death.
     */
    private void incrementHunger()
    {
        foodLevel -= hungerRate;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Decrease the health of the animal, this will result in the mussel's death.
     */
    private void resist(){
        resistance -= rand.nextInt(resistRate);
        if(resistance <= 0){
            setDead();
        }
        else if (disease == null){
            resistance = 100;
        }
    }
    
    /**
     * Increase the cure of a disease, this will cure the current disease the animal has.
     */
    private void cur(){
        cure += rand.nextInt(cureRate);
        if(cure >= 100){
            disease = null;
            cure = 0;
        }
    }
    
    /**
     * Look for seaweeds adjacent to the current location.
     * Only the first live mussel is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            //mussels will try to eat mussels, if not then eat crabs.
            if(animal instanceof Seaweed) {
                Seaweed seaweed = (Seaweed) animal;
                if(seaweed.isAlive()) { 
                    seaweed.setDead();
                    foodLevel += SEAWEED_FOOD_VALUE;
                    return where;
                }
          
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this mussel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newmusseles A list to return newly born musseles.
     */
    private void giveBirth(List<Animal> newmussels)
    {
        // New musseles are born into adjacent locations.
        // Get a list of adjacent free locations.
        if (canBreed()) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Simulator sim = getSimulator();
                Mussel young = new Mussel(false, field, loc, sim);
                newmussels.add(young);
            }
        }
    }
    

    /**
     * Check whether or not two mussels with different sex are met.
     * @return returns whether there are same animal with same gender nearby
     */
    private boolean differentSex(){
        boolean pair = false;        
        Field field = getField();
        List <Location> nearBy = field.adjacentLocations(getLocation());
        for (Location i : nearBy){
            if (field.getObjectAt(i) instanceof Mussel && getSex(field.getObjectAt(i)) != sex){
                pair = true;
            }
        }
        return pair;
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= breedingProbability) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A mussel can breed with the opposite sex mussel
     * if they both have reached the breeding age.
     * @return returns whether the animal can breed
     */
    private boolean canBreed()
    {
        if(differentSex() && age >= getBREEDING_AGE()){
            return true;
        }
        else{
            return false;
        }   
    }   
    
    /**
     * Assign disease to the animal. 
     * @param if the input is null, the method will randomly assign a disease
     * (maybe null) to the animal. If the input it not null, the disease variable 
     * will be set to the same as input
     */
    private void effect(String input){
        if (disease == null){
            if (input == null){
                disease = event.getDisease();
            }
            else {
                disease = input;
            }
            if ("Influenza".equals(disease)){
                cureRate = 30;
                resistRate = 40;
                hungerRate -= 0.02;
                moveValue -= 1;
                breedingProbability -= 0.01;
                huntingProbability -= 0.05;
            }
            else if ("Fungal Infection".equals(disease)){
                cureRate = 20;
                resistRate = 15;
                moveValue -= 1;
                huntingProbability -= 0.1;
            }
            else{
                disease = null;
            }
        }
    }
    
    /**
     * Assign the weather, season and landscape
     */
    private void constant(){
        Field field = getField();
        Simulator sim = getSimulator();
        //The weather and season is shared by all animals, whereas the 
        // disease is valid only to aspecific one. So they must use different
        //event class
        weather = sim.getEvent().getWeather();
        season = sim.getEvent().getSeason();
        landscape = field.getLandscape(getLocation());
        if ("Spring".equals(season)){
            hungerRate += 1;
            resistance += 5;
            breedingProbability += 0.02;
        }
        else if ("Summer".equals(season)){
            hungerRate += 0.05;
            resistance += 5;
            moveValue += 1;
            huntingProbability += 0.05;
        }
        else if ("Autumn".equals(season)){
            hungerRate += 0.1;
            moveValue += 1;
            breedingProbability -= 0.01;
        }
        else if ("Winter".equals(season)){
            hungerRate -= 0.09;
            resistance -= 5;
            moveValue -= 1;
            breedingProbability -= 0.01;
        }
        if("undercurrent".equals(landscape)){
            moveValue += 1;
            breedingProbability -= 0.01;
            huntingProbability -= 0.05;
        }
        else if ("trench".equals(landscape)){
            moveValue += 1;
            huntingProbability += 0.05;
        }
        if ("Sunny".equals(weather)){
            hungerRate += 1;
            resistance += 5;
            moveValue += 1;
            breedingProbability += 0.02;
            huntingProbability += 0.2;
        }
        else if ("Rainy".equals(weather)){
            hungerRate -= 0.08;
            moveValue -= 1;
        }
        else if ("Windy".equals(weather)){
            hungerRate -= 0.1;
            moveValue += 1;
            breedingProbability -= 0.01;            
        }
    }
    
    /**
     * Initialize the data of the animal to clear last step's affact.
     */
    private void standardize(){
        hungerRate = 1;
        moveValue = 3;
        breedingProbability = 0.5;
        huntingProbability = 0.6;
    }
    
    /**
     * If any adjacent animal has influenza, this animal might get infected.
     */
    private void infection(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location i : adjacent){
            if ("Influenza".equals(getDisease(field.getObjectAt(i)))){
                disease = "Influenza";
            }
        }
    }
    
    /**
     * return the current disease the animal has
     * @return the disease of the animal, returns null if the animal is healthy
     */
    private String getDisease(Object animal){
        return disease;
    }
}
