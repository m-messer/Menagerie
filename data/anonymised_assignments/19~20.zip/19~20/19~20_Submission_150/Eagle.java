import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a eagle.
 * Eagles age, move, breed, eat sheep and deer and pig ,and die.
 *  
 * @version 2020.02.23
 **/
public class Eagle extends Animal
{
    // Characteristics shared by all eagles (class variables).
    
    // The age at which a eagle can start to breed.
    private static int BREEDING_AGE = 15;
    // The age to which a eagle can live.
    private static int MAX_AGE = 400;
    // The likelihood of a eagle breeding.
    private static double BREEDING_PROBABILITY = 0.8;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 2;
    // The food value of a single sheep. In effect, this is the
    // number of steps a eagle can go before it has to eat again.
    private static int SHEEP_FOOD_VALUE = 15;
    // The food value of a single deer.
    private static int DEER_FOOD_VALUE = 15;
    // The food value of a single pig.
    private static int PIG_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //current time.
    private Daytime time;
    //if current time is daytime.
    private boolean dayTime;

    // Individual characteristics (instance fields).
    
    //The eagle's gender.
    private boolean gender;
    // The eagle's age.
    private int age;
    // The eagle's food level, which is increased by eating herbivore.
    private int foodLevel;

    /**
     * Create a eagle. A eagle can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the eagle will have random age and hunger level.
     * @param gender If true, the eagle's gender is male.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Eagle(boolean randomAge, boolean gender, Field field, Location location)
    {
        super(field, location);
        time = new Daytime();
        if(randomAge){
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SHEEP_FOOD_VALUE);
            this.gender = Randomizer.setGender();
            foodLevel = 15;
        }
        else{
            age = 0;
            foodLevel = SHEEP_FOOD_VALUE;
            this.gender = Randomizer.setGender();
            foodLevel = 15;
        }
    }
    
    /**
     * This is what the wolf does most of the time: In the process, it does the daytime activities, 
     * or does the nighttime activities.
     * @param newEagles A list to return newly born eagles.
     */
    public void act(List<Creature> newEagle)
    {
        incrementAge();
        incrementHunger();
        dayTime = time.dayTime();
        if(dayTime){
            dayTimeAct(newEagle);
        }
        else{
            nightTimeAct(newEagle);
        }
    }
    
    /**
     * This is what the eagle does in day time: In the process, it will execute
     * the nightTimeAct three times at one step. The action of eagle in day time will become quicker than night time.
     * @param newEagles A list to return newly born eagles.
     */
    private void dayTimeAct(List<Creature> newEagle)
    {
        for(int i = 0; i < 3; i++){
           nightTimeAct(newEagle);
        }
    }
    
    /**
     * This is what the eagle does most of the time: it hunts for
     * sheep,pig and deer. In the process, it might breed, die of can not move.
     * @param newEagles A list to return newly born eagles.
     */
    private void nightTimeAct(List<Creature> newEagle)
    {
        if(isAlive()){
            giveBirth(newEagle);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null){ 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null){
                setLocation(newLocation);
            }
            else{
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age. This could result in the eagle's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE){
            setDead();
        }
    }
    
    /**
     * Make this eagle more hungry. This could result in the eagle's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0){
            setDead();
        }
    }
    
    /**
     * Look for sheep or pig or deer adjacent to the current location.
     * Only the first live arrested eater is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Sheep){
                Sheep sheep = (Sheep) animal;
                if(sheep.isAlive()){ 
                    sheep.setDead();
                    foodLevel += SHEEP_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Deer){
                Deer deer = (Deer) animal;
                if(deer.isAlive()){ 
                    deer.setDead();
                    foodLevel += DEER_FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Pig){
                Pig pig = (Pig) animal;
                if(pig.isAlive()){ 
                    pig.setDead();
                    foodLevel += PIG_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Get the gender of eagle;
     * @return the gender of eagle.
     */
    public boolean getGender() 
    {
        return gender;
    }
    
    /**
     * Check whether or not this eagle is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newEalges A list to return newly born Eagles.
     */
    private void giveBirth(List<Creature> newEagles)
    {
        // New eagles are born into adjacent locations.
        // Get a list of adjacent free locations.
        boolean gender = Randomizer.setGender();
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++){
            Location loc = free.remove(0);
            Eagle young = new Eagle(false, gender, field, loc);
            newEagles.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY){
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * The offspring could be reproduced only if the male and female
     * of the same species are adjacent to each other and have both reached the breeding age.
     * @return Whether this eagle can breed.
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            if (gender){    
                //Judge this eagle is male or famale, if it is male return false.
                return false;
            }
            else{    
                //If this eagle is female, judge the neighbour species.
                while(it.hasNext()){
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Eagle){     
                        //if the neighbour is eagle, check the neighbour eagle gender.
                        Eagle eagle = (Eagle) animal;
                        if(eagle.getGender()){   
                            // if the neighbour eagle gender is male, return true.
                            return true;
                        }
                        else{
                            return false;
                        }
                    }
                    else{
                        return false;
                    }
                }
                return false;
            }
        }
        else{
            return false;
        }
    }
}
