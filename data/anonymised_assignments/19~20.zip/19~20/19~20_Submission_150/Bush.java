import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of bush.
 * The bush can growing and be eaten by sheep, deer, and pig.
 *
 * @version 2020.02.23
 */
public class Bush extends Plant
{ 
    private static int MAX_GROWING_STATUS = 10;
    private  int growingStatus;
    private Weather weather;
    /**
     * Constructor for objects of class Bush
     */
    public Bush(Field field, Location location)
    {
        super(field, location);
        // Initial growth value is 5.
        growingStatus = 5;
    }

    /**
     * This is what the bush does most of the time: In the process, it does the rainy day act, 
     * or does the sunny day act.
     * @param field The field currently occupied.
     * @param newBush A list to return newly born bush.
     */
    public void act(List<Creature> newBush)
    {
        weather = new Weather();
        if(weather.getWeather()){
            rainyDayAct();
        }
        else{
            sunnyDayAct();
        }
    }
    
    /**
     * Get the bush growing status.
     * @return bush growing status.
     */
    public int getGrowingStatus()
    {
        return growingStatus;
    }
    
    /**
     * Within the maxmum growing status, bush growth will make bush growing status plus one 
     */
    private void grow()
    {
        if(growingStatus < MAX_GROWING_STATUS){
            growingStatus++;
        }
    }
    
    /**
     * When the bush is eaten, the growing status will minus one.
     */
    public void wasEaten()
    {
        if(growingStatus > 0){
            growingStatus--;
        }
    }
    
    /**
     * The bush will growing in the rainy day.
     */
    public void rainyDayAct()
    {
        grow();
    }
    
    /**
     * So far the bush will do nothing in the sunny day.
     */
    public void sunnyDayAct()
    {

    }
}
