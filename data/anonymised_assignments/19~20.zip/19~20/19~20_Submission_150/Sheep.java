import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a sheep.
 * Sheep age, move, breed, eat bush and die.
 *  
 * @version 2020.02.23
 */
public class Sheep extends Animal
{
    // Characteristics shared by all sheep (class variables).

    // The age at which a sheep can start to breed.
    private static  int BREEDING_AGE = 2;
    // The age to which a sheep can live.
    private static  int MAX_AGE = 150;
    // The likelihood of a sheep breeding.
    private static  double BREEDING_PROBABILITY =0.8;
    // The maximum number of births.
    private static  int MAX_LITTER_SIZE = 8;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single berry from bushes, this is the
    // number of steps a sheep can go before it has to eat again.
    private static  int BERRY_FOOD_VALUE = 50;
    // The current time, day or night.
    private Daytime daytime;
    
    // Individual characteristics (instance fields).
    
    // The sheep's gender.
    private boolean gender;
    // The sheep's age.
    private int age;
    // The sheep's food level, which is increased by eating berries from bushes.
    private int foodLevel;
    
    /**
     * Create a new sheep. A sheep may be created with age
     * zero (a new born) or with a random age and food level.
     * 
     * @param randomAge If true, the sheep will have a random age.
     * @param gander If true, the sheep is male.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sheep(boolean randomAge, boolean gender, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge){
            age = rand.nextInt(MAX_AGE);
            this.gender = Randomizer.setGender();
            foodLevel = 50;
        }
        else{
            age = 0;
            this.gender = Randomizer.setGender();
            foodLevel = 50;
        }
    }
    
    /**
     * This is what the sheep does most of the time: In the process, it does the daytime activities, 
     * or does the nighttime activities.
     * @param newDeer A list to return newly born deer.
     */
    public void act(List<Creature> newSheep)
    {
        daytime = new Daytime();
        incrementAge();
        incrementHunger();
        if(daytime.dayTime()){
            dayTimeAct(newSheep);
        }
        else{
            // Just sleep.
        }
    }

    /**
     * This is what the sheep does in day time: In the process, it will breed, run away and eat berries from bushes.
     * @param newSheeps A list to return newly born sheeps.
     */
    private void dayTimeAct(List<Creature> newSheep)
    {
        if(isAlive()){
            giveBirth(newSheep);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null){
                setLocation(newLocation);
                eat();
            }
            else{
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Stop move just sleep.
     */
    private void nightTimeAct()
    {
        // Just sleep.
    }
    
    /**
     * Increase the age.
     * This could result in the sheep's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE){
            setDead();
        }
    }
    
    /**
     * Make this sheep more hungry. This could result in the sheep's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0){
            setDead();
        }
    }
    
    /**
     * The sheep will eat the berry from bush, but they do not actively seek out food.
     */
    private void eat()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Bush){
                Bush bush = (Bush) creature;
                if(bush.getGrowingStatus() > 0){ 
                    bush.wasEaten();    //the bush has been eaten.
                    foodLevel += BERRY_FOOD_VALUE;
                }
            }
        }
    }
    
    /**
     * Get the sheep's gender.
     * @return the gender of sheep.
     */
    public boolean getGender() 
    {
        return gender;
    }
    
    /**
     * Check whether or not this sheep is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSheep A list to return newly born sheep.
     */
    private void giveBirth(List<Creature> newSheep)
    {
        // New sheep are born into adjacent locations.
        // Get a list of adjacent free locations.
        boolean gender = Randomizer.setGender();
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++){
            Location loc = free.remove(0);
            Sheep young = new Sheep(false, gender, field, loc);
            newSheep.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY){
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * The offspring could be reproduced only if the male and female
     * of the same species are adjacent to each other and have both reached the breeding age.
     * @return Whether this sheep can breed.
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            if (gender){
                //Judge this sheep is male or famale, if it is male return false.
                return false;
            }
            else{
                //If this sheep is female, judge the neighbour species.
                while(it.hasNext()){
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Sheep){
                        //if the neighbour is sheep, check the neighbour sheep gender.
                        Sheep sheep = (Sheep) animal;
                        if(sheep.getGender()){
                            // if the neighbour sheep gender is male, return true.
                            return true;
                        }
                        else{
                            return false;
                        }
                    }
                    else{
                        return false;
                    }
                }
                return false;
            }
        }
        else{
            return false;
        }
    }
}
