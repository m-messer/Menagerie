import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing creatures.
 *  
 * @version 2020.02.23
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    // The probability that a eagle will be created in any given grid position.
    private static final double EAGLE_CREATION_PROBABILITY = 0.004;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.004;
    // The probability that a sheep will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.08;    
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.0995;
    // The probability that a pig will be created in any given grid position.
    private static final double PIG_CREATION_PROBABILITY = 0.1;
    // The probability that a bush will be created in any given grid position.
    private static final double BUSH_CREATION_PROBABILITY = 0.3;
    
    // List of animals in the field.
    private List<Creature> creatures;
    
    // The current state of the field.
    private Field field;
    
    // The current step of the simulation.
    private static int step;
    
    // A graphical view of the simulation.
    private List<SimulatorView> views;

    // The animal's gender.
    private boolean gender;
    
    // Current time.
    private  Daytime daytime;
    //Display current time.
    private String displayDaytime;
    
    // Current weather.
    private  Weather weather;
    // Display current weather.
    private String displayWeather;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0){
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        creatures = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        views = new ArrayList<>();
        
        SimulatorView view = new GridView(depth, width);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Eagle.class, Color.BLACK);
        view.setColor(Sheep.class, Color.CYAN);
        view.setColor(Deer.class, Color.MAGENTA);
        view.setColor(Pig.class, Color.PINK);
        view.setColor(Bush.class, Color.GREEN);
        views.add(view);
        
        //view = new  GridView(depth, width);
        view = new GraphView(500, 150, 500);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Eagle.class, Color.BLACK);
        view.setColor(Sheep.class, Color.CYAN);
        view.setColor(Deer.class, Color.MAGENTA);
        view.setColor(Pig.class, Color.PINK);
        view.setColor(Bush.class, Color.GREEN);
        views.add(view);

        daytime = new Daytime();
        weather = new Weather();
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && views.get(0).isViable(field); step++){
            simulateOneStep();
            delay(10);   // uncomment this to run more slowly
            
            weather.getWeather();
            daytime.dayTime();
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * creature.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn creature.
        List<Creature> newCreatures = new ArrayList<>();        
        // Let all creatures act.
        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ){
            Creature creature = it.next();
            creature.act(newCreatures);
            weather.getWeather();
            daytime.dayTime();
            if(! creature.isAlive()){
                it.remove();
            }
        }   
        // Add the newly born creatures to the main lists.
        creatures.addAll(newCreatures);
        
        displayDaytime = daytime.timeDisplay();     //display the time.
        displayWeather = weather.weatherDisplay();     //display the weather.
        updateViews();
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        creatures.clear();
        populate();
        for (SimulatorView view : views) {
            view.reset();
        }
        updateViews();
        // Show the starting state in the view.
        displayDaytime = daytime.timeDisplay();     //display the time.
        displayWeather = weather.weatherDisplay();      //display the weather.
    }
    
    /**
     * Update all existing views.
     */
    private void updateViews()
    {
        for (SimulatorView view : views) {
            view.showStatus(step, displayDaytime, displayWeather, field);
        }
    }
    
    /**
     * Randomly populate the field with wolves, eagle, sheep, deer, pig, bush.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++){
            for(int col = 0; col < field.getWidth(); col++){
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, gender, false, field, location);
                    creatures.add(wolf);
                }
                else if(rand.nextDouble() <= EAGLE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(true, gender, field, location);
                    creatures.add(eagle);
                }
                else if(rand.nextDouble() <= SHEEP_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Sheep sheep = new Sheep(true, gender, field, location);
                    creatures.add(sheep);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, gender, field, location);
                    creatures.add(deer);
                }
                else if(rand.nextDouble() <= PIG_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Pig pig = new Pig(true, gender, field, location);
                    creatures.add(pig);
                }
                else if(rand.nextDouble() <= BUSH_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Bush bush = new Bush(field, location);
                    creatures.add(bush);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try{
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie){
            // wake up
        }
    }
    
    /**
     * Get the current step.
     * @return the number of step
     */
    public static int getStep()
    {
        return step;
    }
}
