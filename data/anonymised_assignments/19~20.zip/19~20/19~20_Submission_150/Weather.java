
/**
 * This class is be use to record and distinguish raining day and sunny day.
 *
 * @version 2020.02.23
 */
public class Weather
{
    private  String currentWeather;
    
    /**
     * Distinguish the raining day and sunny day.
     * @return Whether the day is raining day.
     */
    public boolean getWeather()
    {
        if(Simulator.getStep() % 100 <= 50){
            currentWeather = "raining";
            return true;
        }
        else{
            currentWeather = "sunny";
            return false;
        }
    }
        
    /**
     * Display the current weather.
     * @return Current weather is raining day or sunny day.
     */
    public String weatherDisplay()
    {
        return currentWeather;
    }
    
}    
    
