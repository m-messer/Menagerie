/**
 * This class is be use to record and distinguish day time and night time.
 *
 * @version 2020.02.23
 */
public class Daytime
{
    private  String timeDisplay;
    
    /**
     * Distinguish the day time and night time.
     * @return Whether the day is day time.
     */
    public boolean dayTime()
    {
        if(Simulator.getStep() % 20 <= 10){
            timeDisplay = "Day";
            return true;
        }
        else{
             timeDisplay = "Night";
             return false;
        }   
    }
    
    /**
     * Display the current time.
     * @return Current time is  day time or night time.
     */
    public  String timeDisplay()
    {
        return timeDisplay;
    }

}
