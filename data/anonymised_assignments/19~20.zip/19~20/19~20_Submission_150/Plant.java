import java.util.List;

/**
 * A class representing shared characteristics of plants.
 *  
 * @version 2020.02.23
 */
public abstract class Plant extends Creature
{
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newCreatures A list to receive newly born plants.
     */
    abstract public void act(List<Creature> newCreatures);
    
}
