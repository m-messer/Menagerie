import java.util.List;

/**
 * A class representing shared characteristics of creatures.
 *  
 * @version 2020.02.23
 */
public abstract class Creature
{
    // Whether the creature is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    /**
     * Constructor for objects of class Creature
     */
    public Creature(Field field, Location location)
    {
        // initialise instance variables
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * get the Creature live status.
     * @return True if the creature is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * If the creature is not alive, remove this creature.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null){
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the creature's location.
     * @return The creature's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the creature at the new location in the given field.
     * @param newLocation The creature's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null){
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the creature's field.
     * @return The creature's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Make this creature act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newCreatures A list to receive newly born creature.
     */
    abstract public void act(List<Creature> newCreatures);
}
