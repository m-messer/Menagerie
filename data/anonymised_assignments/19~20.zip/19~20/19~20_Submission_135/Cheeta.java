import java.util.List;
import java.util.Random;
/**
 * A Class representing Cheetas in the simulation.
 *
 * @version 1.0
 */
public class Cheeta extends Predator
{
    /**
     * Constructor for objects of class Cheeta.
     * @param field Field where the Lion will be placed.
     * @param location Location of the Lion in the field.
     */
    public Cheeta(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Calls on the act method of the superclass.
     * @param newAnimals a List that provides space for new Animals.
     */
    public void act(List<Animal> newAnimals) {
        super.act(newAnimals);
    }
    
    /**
     * Method that handles the reproduction of the Cheeta.
     * @param newBabies A List that provides space for new Cheetas.
     */
    public void giveBirth(List<Animal> newBabies) {
        // New Cheetas are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cheeta young = new Cheeta(field, loc);
            newBabies.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(super.canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    
}
