import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Abstract class Prey - representing Preys in the simulation. They eat grass to survive.
 *
 * @version 1.0
 */
public abstract class Prey extends Animal
{
    // The age at which a prey can start to breed.
    protected static final int BREEDING_AGE = 5;
    // The age to which a prey can live.
    protected static final int MAX_AGE = 40;
    // The likelihood of a prey breeding.
    protected static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    protected static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    private int foodLevel;
    private int age;
    protected boolean isMale;
    
    /**
     * A Constructor for Class Prey.
     * @param field Field where the Prey will be placed.
     * @param location Location of the Prey in the field.
     */
    public Prey(Field field, Location location) {
        super(field, location);
        age = 0;
        foodLevel = 8;
        //Decide gender of the prey.
        if(rand.nextInt(10) < 6) {
            isMale = true;
        } else {
            isMale = false;
        }
    }
    
    /**
     * Make this prey more hungry. This could result in the prey's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    
    /**
     * Method that handles the breeding, hunger and reproduction of preys.
     * @param newPrey A List that provides space for new Preys.
     * @param plantField Field that contains the plants.
     */
    public void act(List<Animal> newPrey, Field plantField)
    {
        incrementHunger();
        incrementAge();
        if(isAlive()) {
            giveBirth(newPrey);
        }
        if(alive) {
            
            List<Location> adjacentPlants = plantField.adjacentLocations(getLocation());
            
            Iterator it = adjacentPlants.iterator();
            
            
            Location newPlantLocation = findFood(plantField);
            if(newPlantLocation == null) { 
                // No food found - try to move to a free location.
                newPlantLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newPlantLocation != null) {
                setLocation(newPlantLocation);
                infect();
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        
        if(isSick() && disease.isDeadly()) {
            setDead();
        }
    }
    
    /**
     * Handles the finding of food in the plant field. 
     * @param plantField Field that contains the plants.
     */
    private Location findFood(Field plantField)
    {
        
        List<Location> adjacent = plantField.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = plantField.getObjectAt(where);
            if(food instanceof Plant) {
                Plant foods = (Plant) food;
                foodLevel = foodLevel + foods.getNutritionalValue();
                if(foodLevel>15)
                    foodLevel=15;
                foods.setDead();
                return foods.getLocation();
            }
        }
        return null;
    }
    
    /**
     * Abstract method that handles the reproduction of the preys.
     * @param newPreys A List that provides space for new Preys.
     */
    abstract void giveBirth(List<Animal> newPreys);
    
    /**
     * Increases the Age of the Prey. If its too old it is set dead.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * A prey can breed if it has reached the breeding age.
     * @return True if above or equal to breeding age, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
