import java.util.List;
import java.util.Iterator;
/**
 * A Class representing Zebras in the simulation.
 * 
 * @version 1.0
 */
public class Zebra extends Prey
{
    // instance variables - replace the example below with your own
    protected static final double BREEDING_PROBABILITY = 0.31;

    /**
     * Constructor for objects of class Zebra
     * @param field Field where the Zebra will be placed.
     * @param location Location of the Zebra in the field.
     */
    public Zebra(Field field, Location location)
    {
        super(field, location);
        
    }
    
    /**
     * Calls on the act method of the superclass.
     * @param newAnimals a List that provied space for new Animals.
     * @param plantField The field that contains the plants. 
     */
    public void act(List<Animal> newAnimals, Field plantField) {
        super.act(newAnimals, plantField);
    }
    
    /**
     * Method that handles the reproduction of the Zebra.
     * @param newZebra A List that provides space for new Zebras.
     */
    public void giveBirth(List<Animal> newZebra)
    {
        // New zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator it = adjacent.iterator(); 
        
        while(it.hasNext()) {
            Location location = (Location) it.next();
            if(field.getObjectAt(location) instanceof Zebra) {
                Zebra zeb = (Zebra) field.getObjectAt(location);
                if(zeb.isMale != isMale) {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Zebra young = new Zebra(field, loc);
                            newZebra.add(young);
                    }
                }
            }
        }
        
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(super.canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
