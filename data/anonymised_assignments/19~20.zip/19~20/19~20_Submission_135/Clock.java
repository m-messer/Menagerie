import java.util.Random;

/**
 * A Class representing a clock.
 * It is responsible for handeling the day/night cycle and when the 
 * weather should change.
 * 
 * @version 1.0
 */
public class Clock
{
    //Contains if its day or not.
    private boolean day;
    //Counter for keeping track of steps.
    private int counter; 
    //Random object for creating random numbers.
    private Random rand;
    //Variable to store the weather object.
    private Weather weather;
    /**
     * Creates a new Clock with a weather object that it controlls.
     * @param weather that it should controll.
     */
    public Clock(Weather weather)
    {
        rand = new Random();
        this.weather = weather;
        day = true;
        counter = 0;
    }
    
    /**
     * Method that counts. Increases the counter and may change the weather
     * and wether its day / night.
     * @return True if its day, false if its night.
     */
    public boolean count() {
        counter++;
        if(counter%50 == 0) {
            day =! day;
        }
        if(counter%(rand.nextInt(300)+1) == 0) {
            weather.generateWeather();
        }
        return day;
    }
    
    
}
