/**
 * A Class representing a disease in the simulation.
 *
 * @version 1.0
 */
public class Disease
{
    //How fast the disease spreads.
    private static final double contagiousness = 0.01;
    //If the disease is deadly.
    private boolean deadly;
    
    /**
     * Creates a new deadly disease.
     * 
     */
    public Disease() {
        deadly = true;
    }
    /**
     * Method to get contagiousness.
     * @return the contagiousness.
     */
    public double getContagiousness() {
        return contagiousness;
    }
    /**
     * Method to get wether or not the disease is deadly.
     * @return True if deadly, false otherwise.
     */
    public boolean isDeadly() {
        return deadly;
    }
}
