import java.util.List;
import java.util.Iterator;
/**
 * A Class representing Giraffes in the simulation.
 *
 * @version 1.0
 */
public class Giraffe extends Prey
{
    // instance variables - replace the example below with your own
    protected static final double BREEDING_PROBABILITY = 0.29;

    /**
     * Constructor for objects of class Giraffe.
     * @param field Field where the Giraffe will be placed.
     * @param location Location of the Giraffe in the field.
     */
    public Giraffe(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Calls on the act method of the superclass.
     * @param newAnimals a List that provied space for new Animals.
     * @param plantField the field that contains the plants.
     */
    public void act(List<Animal> newAnimals, Field plantField) {
        super.act(newAnimals, plantField);
    }
    
    /**
     * handles reproduction of the giraffes.
     * @param newGiraffe List that provides space for new Giraffes.
     */
    public void giveBirth(List<Animal> newGiraffe)
    {
       // New giraffes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator it = adjacent.iterator(); 
        
        while(it.hasNext()) {
            Location location = (Location) it.next();
            if(field.getObjectAt(location) instanceof Giraffe) {
                Giraffe gif = (Giraffe) field.getObjectAt(location);
                if(gif.isMale != isMale) {
                    List<Location> free = field.getFreeAdjacentLocations(getLocation());
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Giraffe young = new Giraffe(field, loc);
                            newGiraffe.add(young);
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(super.canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
