import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Abstract class Predator - represents predators in the simulation. They hunt preys.
 *
 * @version 1.0
 */
public abstract class Predator extends Animal
{
    // The age at which a predator can start to breed.
    protected static final int BREEDING_AGE = 15;
    // The age to which a predator can live.
    protected static final int MAX_AGE = 150;
    //level of food given by one eaten prey
    protected static final int PREY_FOOD_VALUE = 8;
    //probability to breed when two a male and a female meet
    protected static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    protected static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    //initializes the variable that is the age of the predator
    private int age;
    // The predator's food level, which is increased by eating preys.
    private int foodLevel;
    
    /**
     * A Constructor for Class Predator.
     * @param field The field where the Predator will be placed.
     * @param location Location of the Predator in the field.
     */
    public Predator(Field field, Location location) {
        super(field, location);
        age = 0;
        foodLevel = PREY_FOOD_VALUE;
    }
    
    /**
     * Method that handles the breeding, finding of food (preys) and reproduction of predators.
     * @param newPredator A List that provides space for new Predators.
     */
    public void act(List<Animal> newPredator)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPredator);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Method that handles the breeding, finding of food (preys) and reproduction of predators.
     * @param newPredator A List that provides space for new Predators.
     * @param plantField Field that contains the plants.
     */
    public void act(List<Animal> newAnimals, Field plantField) {
        act(newAnimals);
    }
    
    /**
     * Increases the Age of the Predators. If its too old it is set dead.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this predator more hungry. This could result in the predator's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    foodLevel = PREY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Abstract method that handles the reproduction of the predators.
     * @param newPreys A List that provides space for new predators.
     */
    abstract public void giveBirth(List<Animal> newPredators);
    
    /**
     * A predator can breed if it has reached the breeding age.
     * @return True if above or equal to breeding age, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
