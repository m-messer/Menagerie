import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Write a description of class Mouse here.
 *
 * @version (a version number or a date)
 */
public class Mouse extends Animal
{
    // The age at which a Mouse can start to breed.
    private static final int BREEDING_AGE = 23;
    // The age to which a Mouse can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a Mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.150;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The likelihood of a mouse infecting others. 
    private static final double INFECT_PROBABILITY = 0.72;
    // The food value of a single plant. In effect, this is the
    // number of steps a mouse can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 30;
    // Individual characteristics (instance fields).
    // The Mouse's food level, which is increased by eating plants.
    private int foodLevel;
    //The number of steps a mouse has been sick for.
    private int sickness = 0; 
    //The health state of the animal.
    private boolean sick = false;
    
    /**
     * Constructor for objects of class Mouse
     */
    public Mouse(boolean randomAge, Field field, Location location, boolean sick)
    {
        super(field, location); //get the field and location form the superClass.
        if(randomAge) {
            setAge();
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            setAgeTo0();
            foodLevel = PLANT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the mouse does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMice A list to return newly born mice.
     */
    public void act(List<Actor> newMice, String season, boolean isDay)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if (rand.nextDouble() <= INFECT_PROBABILITY) 
            {
                infect(); 
            }
            giveBirth(newMice);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                //setDead();
            }
        }
    }

    /**
     * Make this mouse more hungry. This could result in the mouse's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Plant) {
                Plant plant = (Plant) actor;
                if(plant.isAlive()) { 
                    plant.setDead();
                    foodLevel = PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * @return The value at which a mouse can start breeding
     * @param BREEDING_AGE the age which allows an mouse to breed
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return The maximum age a mouse can have
     * @param MAX_AGE the age at which a mouse dies
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return The likelihood of a mouse to breed.
     * @param BREEDING_PROBABILITY the probability that makes the mice breed randomly
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return  The level of food that the mouse has eaten.
     * @param foodLevel how much food the mouse has eaten.
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * @return the maximum value for the litter size of a mouse.
     * @param MAX_LITTER_SIZE how many babies a mouse can produce.
     */
    public int getLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Check whether or not this mouse is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born mice.
     */
    private void giveBirth(List<Actor> newMice)
    {
        // New Mice are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if(this.isSick() == false) 
            {
                Mouse young = new Mouse(false, field, loc, false);
                newMice.add(young);
            }
            else 
            if(this.isSick() == true) // if this mouse is sick, its children will be sick too
            {
                Mouse young = new Mouse(false, field, loc, true);
                newMice.add(young);
            }
        }
    }
    
    /**
     * @sick boolean to set if an animal is sick or not
     */
    public void setSick()
    {
        sick = true;
    }

    /**
     * Returns true if the animal is infected, fale if it is not.
     * @sick The boolean used for checking if the animal is infected.
     */
    public boolean isSick()
    {
        return sick;
    }
    
    /**
     * This method checks if there is a healthy mouse nearby and it infects it if the current mouse is sick.
     */
    public void infect()
    {   
        if (isSick() == true) //checks if this mouse is sick
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Mouse) {
                    Mouse mouse = (Mouse) animal;
                    if(mouse.isSick() == false  )
                    {
                        mouse.setSick(); //sets the nearby mouse to sick.
                    }
                }
            }
        }
    }

    /**
     * @sickness used as counter to see for how many steps the animal has been sick
     */
    public void getSicker()
    {   
        sickness++;
    }

    /**
     * This method returns the level of sickness
     * @sickness level of sickness
     */
    public int getIncrement()
    {
        return sickness;
    }

    /**
     * This method sets the animal dead if it reaches the maximum level of sickness.
     * @sickness counter
     */
    public void kill()
    {
        if(sickness == 11)
            setDead();
    }
}