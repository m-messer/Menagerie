import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Write a description of class Antelope here.
 *
 * @version (a version number or a date)
 */
public class Antelope extends Animal
{
    // The age at which a Antelope can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a Antelope can live.
    private static final int MAX_AGE = 220;
    // The likelihood of a Antelope breeding.
    private static final double BREEDING_PROBABILITY = 0.166;
    // The maximum number of births
    private static final int MAX_LITTER_SIZE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single plant. In effect, this is the
    // number of steps an antelope can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 64;
    // Individual characteristics (instance fields).
    // The Antelope's food level, which is increased by eating plants.
    private int foodLevel;

    /**
     * Constructor for objects of class Antelope
     */
    public Antelope(boolean randomAge, Field field, Location location)
    {
        super(field, location); //get the field and location form the superClass.
        if(randomAge) {
            setAge();
            foodLevel = rand.nextInt(PLANT_FOOD_VALUE);
        }
        else {
            setAgeTo0();
            foodLevel = PLANT_FOOD_VALUE;
        }
    }

    /**
     * This is what the antelope does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * The antilope only moves during day-time.
     * @param newAntelopes A list to return newly born Antelopes.
     */
    public void act(List<Actor> newAntelopes, String season, boolean isDay)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() && isDay == true) {
            giveBirth(newAntelopes);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this antelope more hungry. This could result in the antelope's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {   if (foodLevel >= PLANT_FOOD_VALUE){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();

            while(it.hasNext()) {
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                if(actor instanceof Plant) {
                    Plant plant = (Plant) actor;
                    if(plant.isAlive()) { 
                        plant.setDead();
                        foodLevel = PLANT_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * @return The value at which an antelope can start breeding
     * @param BREEDING_AGE the age which allows an antelope to breed
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return The maximum age an antelope can have
     * @param MAX_AGE the age at which an antelope dies
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return The likelihood of an antelope to breed.
     * @param BREEDING_PROBABILITY the probability that makes the antelopes breed randomly
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return  The level of food that the antelope has eaten.
     * @param foodLevel how much food the antelope has eaten.
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * @return the maximum value for the litter size of an antelope.
     * @param MAX_LITTER_SIZE how many babies an antelope can produce.
     */
    public int getLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Check whether or not this antelope is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAntelopes A list to return newly born antelopes.
     */
    private void giveBirth(List<Actor> newAntelopes)
    {
        // New Antelopes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Antelope young = new Antelope(false, field, loc);
            newAntelopes.add(young);
        }
    }
}

