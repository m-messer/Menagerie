import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
/**
 * Write a description of class Predator2 here.
 *
 * @version (a version number or a date)
 */
public class Coyotee extends Animal
{
    // The age at which a coyotee can start to breed.
    private static final int BREEDING_AGE = 55;
    // The age to which a coyotee can live.
    private static final int MAX_AGE = 340;
    // The likelihood of a coyotee breeding.
    private static final double BREEDING_PROBABILITY = 0.085;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single antelope. In effect, this is the
    // number of steps a coyotee can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 150;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The coyotee's food level, which is increased by eating plants.
    private int foodLevel;
    //The health state of the animal.
    private boolean sick = false;
    //The number of steps a coyotee has been sick for.
    private int sickness = 0; 

    // The likelihood of a coyotee infecting others. 
    private static final double INFECT_PROBABILITY = 0.64;
    /**
     * Constructor for objects of class Predator2
     */
    public Coyotee(boolean randomAge, Field field, Location location, boolean sick)
    {
        super(field, location);
        if(randomAge) {
            setAge();
            foodLevel = rand.nextInt(ANTELOPE_FOOD_VALUE);
        }
        else {
            setAgeTo0();
            foodLevel = ANTELOPE_FOOD_VALUE;
        }
        this.sick=sick;
    }

    /**
     * Returns the age at which a coyotee can breed.
     * @param BREEDING_AGE The value which allows a coyotee to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the age until a coyotee cand live.
     * @MAX_AGE The maximum age a coyotee is allowed to have.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @BREEDING_PROBABILITY  The likelihood of a fox breeding.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the maximum value for the litter size of a coyotee.
     * @MAX_LITTER_SIZE The maximum number of babies the coyotee can have. 
     */
    public int getLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns true if the animal is infected, false if it is not.
     * @sick The boolean used for checking if the animal is infected.
     */
    public boolean isSick()
    {
        return sick;
    }
    
    /**
     * This is what the coyotee does most of the time: it hunts for
     * antelopes. In the process, it might breed, die of hunger,
     * die of old age or die of disease.
     * @param field The field currently occupied.
     * @param newLions A list to return newly born coyotees.
     */
    public void act(List<Actor> newCoyotees, String season, boolean isDay)
    {
        incrementAge();
        incrementHunger();

        if(isAlive())
        {
            if (rand.nextDouble() <= INFECT_PROBABILITY) 
            {
                infect(); 
            }
            giveBirth(newCoyotees);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this coyotee more hungry. This could result in the coyotee's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for antelopes adjacent to the current location.
     * Only the first live antelope is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if (foodLevel >= ANTELOPE_FOOD_VALUE){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Antelope) {
                    Antelope antelope = (Antelope) animal;
                    if(antelope.isAlive()) { 
                        antelope.setDead();
                        foodLevel = ANTELOPE_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this coyotee is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCoyotee A list to return newly born coyotees.
     */
    private void giveBirth(List<Actor> newCoyotees)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();

        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Coyotee young = new Coyotee(false, field, loc, false);
            newCoyotees.add(young);
        }
    }

    /**
     * @sick boolean to set if an animal is sick or not
     */
    public void setSick()
    {
        sick = true;
    }

    /**
     * This method checks if there is a healthy coyotee nearby and it infects it if the current coyotee is sick.
     */
    public void infect()
    {   
        if (isSick() == true) //checks if this coyotee is sick
        {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Coyotee) {
                    Coyotee coyotee = (Coyotee) animal;
                    if(coyotee.isSick() == false  )
                    {
                        coyotee.setSick(); //set the nearby coyotee to sick.
                    }
                }
            }
        }
    }

    /**
     * @sickness used as counter to see for how many steps the animal has been sick
     */
    public void getSicker()
    {   
        sickness++;
    }

    /**
     * This method returns the level of sickness
     * @sickness level of sickness
     */
    public int getIncrement()
    {
        return sickness;
    }

    /**
     * This method sets the animal dead if it reaches the maximum level of sickness.
     * @sickness counter
     */
    public void kill()
    {
        if(sickness == 15)
            setDead();
    }
}
