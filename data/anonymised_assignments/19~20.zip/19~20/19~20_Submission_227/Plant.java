import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * Write a description of class Plant here.
 *
 * @version (a version number or a date)
 */
public class Plant implements Actor 
{
    // The maximum height to which a plant can get to before it dies.
    private static int MAX_HEIGHT = 30;
    //The minimum level a water can have before it dies.
    private static int MIN_Water = 1;
    //When a plant is created, its water level is initialized to 6.
    private int waterLevel = 6;
    // The water value of a rainy day.
    private int WATER_VALUE = 6;
    // The plant's field.
    private Field field;
    // The maximum number of seeds a plant can produce.
    private int MAX_SEEDS = 5;
    // The plant's position in the field.
    private Location location;
    //The string that stores the current season.
    private String season = "";
    //The likelihood of a plant producing seeds.
    private double PRODUCING_PROBABILITY = 0.83;
    //The height of the plant.
    private int height;
    // Whether the plant is alive or not.
    private boolean alive;
    //The likelihood of raining during the wet season.
    private double RAIN_WET_SEASON_PROBABILITY = 0.9;
    //The likelihood of raining during the dry season.
    private double RAIN_DRY_SEASON_PROBABILITY = 0.19;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Plant
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomHeight, Field field, Location location)
    {
        // initialise instance variables
        alive = true;
        this.field = field;
        setLocation(location);
        if(randomHeight) {
            setHeight();
        }
        else {
            setHeightTo0(); //when newly produced by another plant
        }

    }

    /**
     * During the wet season the probability of rain is bigger.
     * The probability of plants growing in height is bigger as well.
     * There are less chances for them to die during this season.
     */
    public void simulateWetSeason()
    {   
        if(rand.nextInt() <= RAIN_WET_SEASON_PROBABILITY)
        {   
            increment_waterLevel();
            increment_height();
        }
    }

    /**
     * During the dry season the probability of rain is smaller.
     * The probability of plants growing in height is smaller as well.
     * There are more chances that they die of thirst.
     */
    public void simulateDrySeason()
    {
        if(rand.nextInt() <= RAIN_DRY_SEASON_PROBABILITY)
        {   
            increment_waterLevel();
            increment_height();
        }
    }

    /**
     * Increments the water level when it rains with the water value.
     * @waterLevel updates the current water level.
     * @WATER_VALUE the water value of rain.
     */
    private void increment_waterLevel()
    {
        waterLevel = waterLevel + WATER_VALUE;
    }

    /**
     * Increments the height of the plant when it rains.
     * @height updates the current height 
     */
    private void increment_height()
    {
        height = height + 3;
    }

    /**
     * This is what the plants does. It gets thirsty, it grows in height when
     * it rains and it produces seeds.
     */
    public void act(List<Actor> newPlants, String season, boolean isDay)
    {
        incrementThirst();
        if (isAlive() && canProduceSeeds() == true ) 
            createOtherPlants(newPlants);

        if(season.equals("Wet season")){
            simulateWetSeason();
        }
        else if(season.equals("Dry season")){
            simulateDrySeason();
        }
    }

    /**
     * Decrements the water level of the plant.
     * If the water level gets lower os equal to the minimum level of water,
     * the plant dies.
     * @waterLevel updates the current level of water.
     * @MIN_Water minimum level of water necessary for the plant to live
     */
    private void incrementThirst()
    {
        waterLevel--;
        if(waterLevel <= MIN_Water) {
            setDead();
        }
    }

    /**
     * When the plant reaches the maximum height it can produce seeds.
     * @height current height of the plant.
     * @MAX_HEIGHT maximum height to which a plant can get to.
     */
    public boolean canProduceSeeds()
    {   
        return height == MAX_HEIGHT;
    }

    /**
     * Generate a number representing the number of seeds,
     * if it can produce.
     * @return The number of seeds(may be zero).
     */
    public int produceSeeds()
    {
        int numberOfSeeds = 0;
        if(canProduceSeeds() && rand.nextDouble() <= PRODUCING_PROBABILITY) {
            numberOfSeeds = rand.nextInt(getSeedsNumber()) + 1;
        }
        return numberOfSeeds;
    }

    /**
     * @return the maximum value for the number of seeds a plant can produce.
     * @param MAX_SEEDS how many seeds a plant can produce.
     */
    public int getSeedsNumber()
    {
        return MAX_SEEDS;
    }

    /**
     * @return the current season
     */
    private String getSeason()
    {
        return season;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    private void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Sets the plant's height to 0.
     */
    private void setHeightTo0()
    {
        height = 0;
    }

    /**
     * The random height a plant can have when it is displayed.
     */
    private void setHeight()
    {
        height = rand.nextInt(MAX_HEIGHT);
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    public Field getField()
    {
        return field;
    }

    /**Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
    */
    public void createOtherPlants(List<Actor> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int numberOfSeeds = produceSeeds();
        for(int b = 0; b < numberOfSeeds && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant seed = new Plant(false, field, loc);
            newPlants.add(seed);
        }
        this.setDead();
    }
}
