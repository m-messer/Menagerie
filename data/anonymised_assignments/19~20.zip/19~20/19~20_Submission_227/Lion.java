import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lion.
 * Lions age, move, eat antelopes, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Lion extends Animal 
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 68;
    // The age to which a lion can live.
    private static final int MAX_AGE = 350;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.091;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single antelope. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 140;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The lion's food level, which is increased by eating antelopes.
    private int foodLevel;

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge();
            foodLevel = rand.nextInt(ANTELOPE_FOOD_VALUE);
        }
        else {
            setAgeTo0();
            foodLevel = ANTELOPE_FOOD_VALUE;
        }
    }

    /**
     * Returns the age at which a lion can breed.
     * @param BREEDING_AGE The value which allows a lion to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the age until a lion cand live.
     * @MAX_AGE The maximum age a lion is allowed to have.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @BREEDING_PROBABILITY  The likelihood of a lion breeding.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the maximum value for the litter size of a lion.
     * @MAX_LITTER_SIZE The maximum number of babies the lion can have. 
     */
    public int getLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * antelopes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newLions A list to return newly born lions.
     */
    public void act(List<Actor> newLions, String season, boolean isDay)
    {
        incrementAge();
        incrementHunger();
        if(isAlive() ) {
            giveBirth(newLions);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                //setDead();
            }

        }
    }

    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for antelopes adjacent to the current location.
     * Only the first live antelope is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        if (foodLevel >= ANTELOPE_FOOD_VALUE){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Antelope ) {
                    Antelope antelope = (Antelope) animal;
                    if(antelope.isAlive()) { 
                        antelope.setDead();
                        foodLevel = ANTELOPE_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     */
    private void giveBirth(List<Actor> newLions)
    {
        // New lions are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }
}