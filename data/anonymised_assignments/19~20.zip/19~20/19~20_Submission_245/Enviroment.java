/**
 * An Enviroment manages the time within the simulation.
 * It could also theoretically manage other things, such as weather and seasons, if they were implemented in this version.
 *
 * @version 2020.02.22
 */
public class Enviroment
{
    // instance variables - replace the example below with your own
    private static double time = 0d; // An double representing the current time
    // Measured in minutes since 00:00am on Day 1.
    private static final double START_TIME = 540d; // A double representing the start time. Currently will start sim at 09:00 on Day 1.
    private double TIME_INTERVAL = 20d;
    /**
     * Constructor for objects of class Enviroment
     */
    public Enviroment()
    {
        time = START_TIME;
    }

    /**
     * Resets the time to a default value.
     */
    public void reset(){
        time = START_TIME;
    }

    /**
     * Passes time.
     *
     * @param  minutes  The number of minutes that should pass.
     */
    public void passTime(double minutes)
    {
        time += minutes;
    }

    /**
     * Returns the current day as an integer.
     */
    public int getDay(){
        return (int) Math.floor(time/1440) + 1;
    }
    
    /**
     * Returns the time interval; the amount of time passed each tick.
     */
    public double getTimeInterval(){
        return TIME_INTERVAL;
    }

    /**
     * Returns the current time as a double representing minutes since midnight.
     */
    public double getTime(){
        return time%1440;
    }

    /**
     * Returns the current hour as an integer.
     */
    public int getHour(){
        return (int) Math.floor(time/60) % 24;
    }

    /**
     * Returns the current hour as an integer.
     */
    public int getMinute(){
        return (int) Math.floor(time) % 60;
    }

    /**
     * Returns a representation of the current simulation date and time as a
     * string.
     */
    public String getDateTimeRep(){
        String h = String.format("%02d",getHour());
        String m = String.format("%02d",getMinute());
        return "Day "+getDay()+" "+h+":"+m;
    }
}
