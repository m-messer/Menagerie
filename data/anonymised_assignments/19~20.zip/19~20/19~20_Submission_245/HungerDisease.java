import java.util.List;
/**
 * This is a simple Disease implementation - it removes 1% of a creature's max energy
 * from their current energy each time it ticks, and then attempts to spread to those
 * around it.
 *
 * @version 2020.02.22
 */
public class HungerDisease extends Disease
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class ClockDisease
     */
    public HungerDisease()
    {
        
    }

    /**
     * This method is ran by the animal hosting this disease every time it takes an action itself.
     *
     * @param  host  the animal which hosts the disease
     */
    public void act(Animal host)
    {
        // Animal loses additional energy equal to 1% of maximum; rounded.
        host.loseEnergy((host.getMaxEnergy()/100));
        // Spreading. 
        List<Location> newLoc = host.getField().adjacentLocations(host.getLocation());
        for(int i = 0; i<newLoc.size(); i++){
            Object newHost = host.getField().getObjectAt(newLoc.get(i));
            if(newHost != null && newHost instanceof Goose){
                ((Animal) newHost).infect(new HungerDisease());
            }
        }
    }
}
