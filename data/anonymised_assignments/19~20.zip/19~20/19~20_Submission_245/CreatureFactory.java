import java.util.HashMap;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;

/**
 * A Factory designed to create Creatures, for use in the simulation.
 * Methods are available to randomly select creatures and generate a populated Field for use within the simulation.
 *
 * @version 2020.02.22
 */
public class CreatureFactory
{
    // An randomiser
    private static Random rand = Randomizer.getRandom();
    
    // An Enum, to represent the different types of entity which can occupy a location.
    enum Creature {
        RED_PANDA,
        GOOSE,
        SNOW_LEOPARD,
        PIKA,
        GOAT,
        GRASS,
        APPLE_TREE,
        NONE
    }

    // A HashMap, giving probabilities for each Creature to be placed on a tile when initialised.
    // The total of probabilities should not exceed 1; beyond that any creatures will never be chosen.
    private static HashMap<Creature,Double> creatureProb;
    static {
        creatureProb = new HashMap<Creature,Double>();
        creatureProb.put(Creature.RED_PANDA,0.0005);
        creatureProb.put(Creature.GOOSE,0.02);
        creatureProb.put(Creature.SNOW_LEOPARD,0.001);
        creatureProb.put(Creature.PIKA,0.02);
        creatureProb.put(Creature.GOAT,0.02);
        creatureProb.put(Creature.GRASS,0.03);
        creatureProb.put(Creature.APPLE_TREE,0.01);
    }
    
    // A HashMap, giving probabilities that another instance of that organism should be generated when generating a Pack
    // of that creature type. This number roughly determines the sizes of packs generated.
    private static HashMap<Creature,Double> packProb;
    static {
        packProb = new HashMap<Creature,Double>();
        packProb.put(Creature.RED_PANDA,0.75);
        packProb.put(Creature.GOOSE,0.85);
        packProb.put(Creature.SNOW_LEOPARD,0.9);
        packProb.put(Creature.PIKA,0.85);
        packProb.put(Creature.GOAT,0.85);
        packProb.put(Creature.GRASS,0.65);
        packProb.put(Creature.APPLE_TREE,0.00);
    }
    // A Disease that randomly affects Geese; this is the chance it should be applied to newly created Geese.
    private static final double HUNGER_DISEASE_CHANCE = 0.01d;
    
    /**
     * A method which creates an Organism based upon the Creature value passed to it; with other parameters affecting
     * the creature generated.
     *
     * @param c A Creature enum value, representing the subclass of Organism for which an object should be created.
     * @param field The Field on which the created Organism should reside.
     * @param pos The Position of that Organism on the provided field.
     * @param randomAge Whether the Age (and Energy) of the Organism should be randomly set, or 0 and max respectively.
     * @return the creature generated; will be a subclass of Organism.
     */
    private Organism createCreature(Creature c, Field field, Location pos, boolean randomAge){
        Organism newOrganism = null;
        switch(c){
            case RED_PANDA:
            newOrganism = new RedPanda(randomAge,field,pos);
            break;
            case GOOSE:
            newOrganism = new Goose(randomAge,field,pos);
            // Chance of the goose starting infected!
            if (rand.nextDouble() < HUNGER_DISEASE_CHANCE){((Animal) newOrganism).infect(new HungerDisease());}
            break;
            case SNOW_LEOPARD:
            newOrganism = new SnowLeopard(randomAge,field,pos);
            break;
            case PIKA:
            newOrganism = new Pika(randomAge,field,pos);
            break;
            case GOAT:
            newOrganism = new Goat(randomAge,field,pos);
            break;
            case GRASS:
            newOrganism = new Grass(field,pos);
            break;
            case APPLE_TREE:
            newOrganism = new AppleTree(field,pos);
            break;
            case NONE:
            default:

        }
        return newOrganism;
    }
    
    /**
     * Randomly populate the field with organisms.
     * A creature type is chosen. We then create a creature at that position, and then utilise the probability provided
     * in packProb to decide whether we should generate another in an adjacent position.
     * @return A list of Organisms representing all Organisms generated on the field.
     */
    public List<Organism> populatePacks(Field field)
    {
        List generatedOrganisms = new ArrayList<Organism>();
        field.clear();
        // For each position on the field
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location pos = new Location(row,col);
                // Get the creature that should be placed
                Creature creatureValue = pickCreatureType();
                if(field.getObjectAt(pos) == null && creatureValue != Creature.NONE){
                    boolean packGen = true;
                    while(packGen && pos != null && field.getObjectAt(pos) == null){
                        generatedOrganisms.add(createCreature(creatureValue, field, pos, true));
                        pos = field.freeAdjacentLocation(pos);
                        packGen = rand.nextDouble() < packProb.get(creatureValue);
                    }
                }
                // else leave the location empty.
            }
        }
        return generatedOrganisms;
    }
    
    /**
     * Chooses a random creature type, based on the creatureProb hashmap defined within this class.
     * @return An Creature enum, representing the creature chosen by the randomiser.
     */
    private Creature pickCreatureType(){
        // Get a random number to compare to probabilities.
        double seed = rand.nextDouble();
        Creature[] creatures = Creature.values();
        for(int i=0; i < creatures.length; i++){
            Creature c = creatures[i];
            double prob = creatureProb.getOrDefault(c, 0d);
            // If the seed value is less than the probability given, we pick that type.
            if(seed < prob){
                return c;
            }
            // Otherwise, we remove it from the seed value, bringing it closer to 0
            seed -= prob;
        }
        return Creature.NONE;
    }

}
