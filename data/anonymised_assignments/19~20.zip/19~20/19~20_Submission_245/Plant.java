import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashSet;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2020.02.22
 */
public abstract class Plant extends Organism
{
    // SPREADING PARAMETERS
    // The likelihood of this Plant reproducing.
    private double SPREADING_PROBABILITY;
    // The maximum number of new plants that can be created at once.
    private int MAX_LITTER_SIZE;
    // A shared random number generator to control spreading.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Sets the spread parameters of the Plant.
     * 
     * @param breedChance The probability this plant will successfuly spread.
     * @param maxLitter The maximum number of plants to create. Each spread generates a number randomly from 1 to this number to create.
     */
    public void setSpreadParameters(double spreadChance, int maxLitter)
    {
        SPREADING_PROBABILITY = spreadChance;
        MAX_LITTER_SIZE = maxLitter;
    }
    
    /**
     * Generate a number representing the number of plants to generate,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int spread()
    {
        int births = 0;
        if(rand.nextDouble() <= SPREADING_PROBABILITY) {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

}
