
import java.util.List;


/**
 * Organisms inhabit the simulation. At a baseline level, organisms can Act, Move and have values dictating what should happen when other Organisms
 * interact with them.
 *
 * @version 2020.02.22
 */
public abstract class Organism
{
    // Whether the organism is alive.
    protected boolean alive;
    // The organism's field.
    protected Field field;
    // The organism's position in the field.
    protected Location location;
    // The energy this organism provides to another if consumed.
    private int FOOD_VALUE = 0;
    // Whether other animals should be able to move onto (and 
    private boolean pathable = false;
    
    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly created organisms.
     */
    abstract public void act(List<Organism> newOrganisms);

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Sets a given organism to be dead. Doing so should remove all
     * references within the fields of the organism; including that of
     * its location or field.
     * Implementation may vary based on organism; a default implementation
     * is provided here.
     */
    protected void setDead()
    {
        alive = false;
        field = null;
        location = null;
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return this.field;
    }
    
    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Attempts to set the location of this organism. If an organism
     * already exists at the new location...
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        if(field.getObjectAt(newLocation) != null && ((Organism)field.getObjectAt(newLocation)).getPathable()){
            Organism old = (Organism) field.getObjectAt(newLocation);
            old.setDead();
        }
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's food value - that is the amount of nutrition 
     * it provides if consumed by another organism.
     * @return The organism's food value.
     */
    public int getFoodValue(){
        return FOOD_VALUE;
    }
    
    /**
     * Sets the food value of this organism to the provided value.
     * @param newFoodVal The desired value for FOOD_VALUE.
     */
    public void setFoodValue(int newFoodVal){
        FOOD_VALUE = newFoodVal;
    }
    
    /**
     * Gets the pathability of this organism - that is whether other organisms can replace it in place.
     * @return The organism's pathability.
     */
    public boolean getPathable(){
        return pathable;
    }
    
    /**
     * Sets the pathability of this organism - that is whether other organisms can replace it in place.
     * @param newValue The desired pathability.
     */
    public void setPathable(boolean newValue){
        pathable = newValue;
    }
}
