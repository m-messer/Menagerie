import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashSet;

/**
 * A simple model of a Red Panda.
 * Red Pandas eat Pikas and Geese, and are awake between 8pm and 8am
 *
 * @version 2020.02.22
 */
public class RedPanda extends Animal
{
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();

    /**
     * Create a red panda. A panda can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the panda will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public RedPanda(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setBreedParameters(90,0.08,4);
        setMaxEnergy(2000);
        setMaxAge(1440*28);
        setFoodValue(120);
        addPrey(Pika.class);
        addPrey(Goose.class);
        if(randomAge){
            randomiseAgeEnergy();
        }else{
            setEnergy(getMaxEnergy());
        }
    }

    /**
     * This method is run every simulation tick.
     * The animal seeks its prey, 
     * @param field The field currently occupied.
     * @param offspring A list to return newly born offspring.
     */
    public void act(List<Organism> offspring)
    {
        int energySpent = 0;
        if(isAlive()) {
            int currentHour = getField().getEnviroment().getHour();
            Location newLocation = getLocation();
            getOlder(getField().getEnviroment().getTimeInterval());
            energySpent += 1;
            if(currentHour < 8 || currentHour >= 20){
                // Lose a total of 10 energy when awake
                energySpent += 9;
                if(isAlive()) {
                    giveBirth(offspring);            
                    // Move towards a source of food if found.
                    newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else {
                        // This animal can stay where it is.
                    }
                }
            }
            // Now process the loss of energy and increase in age - if the animal is too old or hungry it dies.
            if(
                isAlive() && (getOlder(getField().getEnviroment().getTimeInterval()) ||
                loseEnergy(energySpent))
                )
                {
                    setDead();
                }
            if(disease != null){
                disease.act(this);
            }
        }
    }

    /**
     * Check whether or not this predator is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param offspring A list to return newly born offspring.
     */
    private void giveBirth(List<Organism> offspring)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            RedPanda young = new RedPanda(false, field, loc);
            young.setEnergy(this.getEnergy()/2);
            offspring.add(young);
        }
    }

}
