import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;
import java.util.Set;

/**
 * The main logic of the predator-prey simulator. It supports multiple organisms, which each
 * act every tick of the simulation.
 *
 * @version 2020.02.22
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The number of minutes that should pass each time a step takes place.
    private static final int timeInterval = 20;
    // The number of miliseconds each step should take at a minimum
    private static final int MIN_STEP_DELAY = 40;
    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // 
    private static final CreatureFactory creatureFactory = new CreatureFactory();
    // An randomiser for future use.
    private static Random rand = Randomizer.getRandom();

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Goose.class, Color.ORANGE);
        view.setColor(RedPanda.class, Color.RED);
        view.setColor(SnowLeopard.class, Color.BLUE);
        view.setColor(Goat.class, Color.PINK);
        view.setColor(Pika.class, Color.MAGENTA);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(AppleTree.class, Color.CYAN);
        view.setColor(Apple.class, Color.YELLOW);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            int start = (int) System.currentTimeMillis();
            simulateOneStep();
            int finish = (int) System.currentTimeMillis();
            int timeElapsed = finish - start;
            
            delay(Math.max((int) MIN_STEP_DELAY-timeElapsed,0)); // Force a delay for debug purposes.
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Every organism within the simulation is made to act.
     */
    public void simulateOneStep()
    {
        step++;
        List<Organism> offspring = new ArrayList<>();          
        // Let all rabbits act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism o = it.next();
            o.act(offspring);
            if(! o.isAlive()) {
                it.remove();
            }
        }
        organisms.addAll(offspring);
        field.getEnviroment().passTime(timeInterval);
        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        organisms = creatureFactory.populatePacks(field);
        
        field.getEnviroment().reset();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
