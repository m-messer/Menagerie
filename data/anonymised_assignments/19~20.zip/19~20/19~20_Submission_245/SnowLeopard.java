import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashSet;

/**
 * A simple model of a snow leopard.
 * Snow Lepoards are Apex Predators, eating all other animals but themselves, and are awake between 6am and 9pm.
 *
 * @version 2020.02.22
 */
public class SnowLeopard extends Animal
{

    // Individual characteristics (instance fields).

    /**
     * Create a snow leopard. A snow leopard can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the snow leopard will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public SnowLeopard(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setBreedParameters(120,0.25,2);
        setMaxEnergy(1200);
        setFoodValue(640);
        setMaxAge(1440*14);
        addPrey(RedPanda.class);
        addPrey(Goose.class);
        addPrey(Pika.class);
        addPrey(Goat.class);
        if(randomAge){
            randomiseAgeEnergy();
        }else{
            setEnergy(getMaxEnergy());
        }
    }

    /**
     * This method is run every simulation tick.
     * The animal seeks its prey, 
     * @param field The field currently occupied.
     * @param offspring A list to return newly born offspring.
     */
    public void act(List<Organism> offspring)
    {
        int energySpent = 0;
        if(isAlive()) {
            int currentHour = getField().getEnviroment().getHour();
            Location newLocation = getLocation();
            getOlder(getField().getEnviroment().getTimeInterval());
            energySpent += 1;
            if(currentHour < 21 && currentHour >= 6){
                // Lose a total of 10 energy when awake
                energySpent += 9;
                if(isAlive()) {
                    giveBirth(offspring);
                    if(isAlive()) {
                        // Move towards a source of food if found.
                        newLocation = findFood();
                        if(newLocation == null) { 
                            // No food found - try to move to a free location.
                            newLocation = getField().freeAdjacentLocation(getLocation());
                        }
                        // See if it was possible to move.
                        if(newLocation != null) {
                            setLocation(newLocation);
                        }
                        else {
                            // This animal can stay where it is.
                        }
                    }   
                }
            }
            // Now process the loss of energy and increase in age - if the animal is too old or hungry it dies.
            if(
                isAlive() && (getOlder(getField().getEnviroment().getTimeInterval()) ||
                loseEnergy(energySpent))
                )
                {setDead();}
                if(disease != null){disease.act(this);}
        }
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSnowLeopardes A list to return newly born offspring.
     */
    private void giveBirth(List<Organism> offspring)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(isAlive()){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0 && isAlive(); b++) {
                Location loc = free.remove(0);
                SnowLeopard young = new SnowLeopard(false, field, loc);
                young.setEnergy(getEnergy()/2);
                loseEnergy(getEnergy()/2);
                offspring.add(young);
            }
        }
    }
}
