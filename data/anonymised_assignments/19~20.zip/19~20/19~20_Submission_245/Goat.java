import java.util.List;
import java.util.Random;

/**
 * A simple model of a goat.
 * Goats eat Apples and Grass, and are awake between 05:00 and 20:00
 *
 * @version 2020.02.22
 */
public class Goat extends Animal
{
    // Characteristics shared by all goats (class variables).

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    /**
     * Create a new goat. A goat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the goat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Goat(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setBreedParameters(60,0.06,3);
        setMaxEnergy(900);
        setFoodValue(1000);
        setMaxAge(1440*7);
        addPrey(Apple.class);
        if(randomAge){
            randomiseAgeEnergy();
        }else{
            setEnergy(getMaxEnergy());
        }
    }

    /**
     * This is what the goat does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGoats A list to return newly born goats.
     */
    public void act(List<Organism> newGoats)
    {
        int energySpent = 0;
        if(isAlive()) {
            int currentHour = getField().getEnviroment().getHour();
            Location newLocation = getLocation();
            energySpent += 1;
            if(currentHour < 20 && currentHour >= 5){
                giveBirth(newGoats);            
                // Try to move into a free location.
                newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                energySpent += 9;
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // This animal can stay where it is.
            }
            // Now process the loss of energy and increase in age - if the animal is too old or hungry it dies.
            if(isAlive() && (getOlder(getField().getEnviroment().getTimeInterval()) || loseEnergy(energySpent)))
            {
                setDead();
            }
            if(disease != null){disease.act(this);}
        }
    }
            

    /**
     * Check whether or not this goat is to give birth at this step.
     * To give birth, they must be adjancent to another goat of the opposite gender; and both must be above the breeding age.
     * This check is performed within the breed method within the Animal class.
     * @param newGoats A list to return newly born organisms.
     */
    private void giveBirth(List<Organism> newGoats)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Goat young = new Goat(false, field, loc);
            young.setEnergy(this.getEnergy()/2);
            newGoats.add(young);
        }
    }

}

