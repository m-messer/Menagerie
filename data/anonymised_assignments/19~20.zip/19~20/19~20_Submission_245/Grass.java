import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Grass is a Plant present within the simulation. It spreads quite rapidly, and has a
 * minute chance of turning into an AppleTree every simulation tick.
 *
 * @version 2020.02.22
 */
public class Grass extends Plant
{
    // Characteristics shared by all rabbits (class variables).
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The nutrition this creature provides to any creature that eats it.
    // Individual characteristics (instance fields).
    private static final double TREE_CHANCE = 0.000002;
    /**
     * Create a patch of Grass.
     * To simplify the model, Grass does not have the concept of age; it is always assumed to be fully grown.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
        setSpreadParameters(0.3,3);
        setFoodValue(250);
        setPathable(true);
    }

    /**
     * Method called each tick by the Simulation. The grass attempts to spread,
     * and then has a small chance of creating an AppleTree in its position - simulating the growth of new trees.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Organism> newGrass)
    {
        if(isAlive()) {
                grow(newGrass);
                if(rand.nextDouble() < TREE_CHANCE){
                    Location pos = getLocation();
                    Field fil = getField();
                    setDead();
                    newGrass.add(new AppleTree(fil,pos));
                }
        }
    }

    /**
     * This method causes the grass to grow, spreading around itself akin to the breeding of animals.
     * 
     * @param newGrass A list to store the newly created organisms.
     */
    private void grow(List<Organism> newGrass)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = spread();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(field, loc);
            newGrass.add(young);
        }
    }

}
