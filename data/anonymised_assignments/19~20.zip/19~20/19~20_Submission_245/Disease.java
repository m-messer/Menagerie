
/**
 * An Abstract class, implementing vital functionality of each Disease.
 * Diseases are applied to animals, and "act" when the animals take an action themselves.
 * Currently, each animal can only possess one disease at a time.
 *
 * @version 2020.02.22
 */
public abstract class Disease
{

    /**
     * This method is ran by the animal hosting this disease every time it takes an action itself.
     *
     * @param  host  the animal which hosts the disease
     */
    abstract public void act(Animal host);
    
}
