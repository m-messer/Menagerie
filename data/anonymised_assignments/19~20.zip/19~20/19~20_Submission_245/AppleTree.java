import java.util.List;

/**
 * Apple Trees are a unique type of Plant.
 * They are not eaten by any creatures - their purpose is to generate Apples around themselves over time.
 *
 * @version 2020.02.22
 */
public class AppleTree extends Plant
{
    
    private static final double DECAY_CHANCE = 0.0001;
    /**
     * Create a new Apple Tree.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public AppleTree(Field field, Location location)
    {
        super(field, location);
        setSpreadParameters(0.3,3);
        setFoodValue(0); // you can't eat trees
    }

    /**
     * Every tick, this function is executed.
     * It generates new apples around the tree, and then has a small chance of decaying and simply turning into grass.
     */
    public void act(List<Organism> newFruit)
    {
        if(isAlive()) {
            produceFruit(newFruit);
            if(rand.nextDouble() < DECAY_CHANCE){
                Location pos = getLocation();
                Field fil = getField();
                fil.place(null, pos);
                setDead();
                newFruit.add(new Grass(fil,pos));
                }
        }
    }

    /**
     * Check the number of fruit that should be produced; and if this happens
     * how many apples should be produced.
     * @param newFruit The List to which created organisms are added.
     */
    private void produceFruit(List<Organism> newFruit)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = spread();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Apple young = new Apple(field, loc);
            newFruit.add(young);
        }
    }
}
