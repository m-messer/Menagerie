import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model for a Goose.
 * Geese eat Grass, are awake between 18:00 and 10:00, and can move up to 2 tiles each time they act.
 *
 * @version 2020.02.22
 */
public class Goose extends Animal
{
    // Characteristics shared by all geese (class variables).
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The nutrition this creature provides to any creature that eats it.
    // Individual characteristics (instance fields).

    /**
     * Create a new goose. A goose may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the goose will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Goose(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        setBreedParameters(60,0.06,2);
        setMaxEnergy(1800);
        setFoodValue(600);
        setMaxAge(1440*5);
        addPrey(Grass.class);
        if(randomAge){
            randomiseAgeEnergy();
        }else{
            setEnergy(getMaxEnergy());
        }
    }

    /**
     * Geese perform behaviours similar to other animals, they attempt to eat, or otherwise just wander around.
     * @param newGeese A list to return newly born organisms.
     */
    public void act(List<Organism> newGeese)
    {
        int energySpent = 0;
        if(isAlive()) {
            int currentHour = getField().getEnviroment().getHour();
            Location newLocation = getLocation();
            energySpent += 1;
            // Sleeps between 10am and 6pm.
            if(isAlive()) {
                if(currentHour < 10 || currentHour >= 18){
                    giveBirth(newGeese);            
                    // Try to move into a free location.
                    newLocation = findFood();
                    if(newLocation == null) {
                        // No food found - try to move to a free location twice!
                        newLocation = getField().freeAdjacentLocation(getLocation());
                        if (newLocation != null){
                            Location trial = getField().freeAdjacentLocation(newLocation);
                            if (trial != null){newLocation = trial;}
                    }
                    }
                    energySpent += 4;
                }
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // This animal can stay where it is.
                }
                // Now process the loss of energy and increase in age - if the animal is too old or hungry it dies.
                if(
                isAlive() && (getOlder(getField().getEnviroment().getTimeInterval()) ||
                loseEnergy(energySpent))
                )
                {setDead();}
                if(disease != null){disease.act(this);}
            }
        }
    }

    /**
     * Check whether or not this goose is to give birth at this step.
     * To give birth, they must be adjancent another goose of the opposite gender; and both must be above the breeding age.
     * This check is performed within the breed method within the Animal class.
     * @param newGeese A list to return newly born organisms.
     */
    private void giveBirth(List<Organism> newGeese)
    {
        // New geese are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Goose young = new Goose(false, field, loc);
            young.setEnergy(this.getEnergy()/2);
            newGeese.add(young);
        }
    }

}
