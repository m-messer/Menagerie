import java.util.List;
import java.util.Random;

/**
 * Apples are a plant produced by an Apple Tree.
 * It has a chance of decaying every time it acts; and can be eaten.
 * @version 2020.02.22
 */
public class Apple extends Plant
{
    // Characteristics shared by all rabbits (class variables).
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    private static final double DECAY_CHANCE = 0.004;
    /**
     * Create a new apple.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Apple(Field field, Location location)
    {
        super(field, location);
        setSpreadParameters(0,0);
        setFoodValue(450);
    }

    /**
     * This method is called every simulation tick.
     * Apples just exist until either eaten by other creatures, or they decay with a small chance each tick into Grass.
     * @param newRabbits A list to return newly created organisms.
     */
    public void act(List<Organism> newOrganism)
    {
        if(isAlive()) {
            if(rand.nextDouble() < DECAY_CHANCE){
                newOrganism.add(new Grass(getField(),getLocation()));
                setDead();
            }
        }
    }
}
