import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashSet;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.22
 */
public abstract class Animal extends Organism
{
    // The Age of the animal. 
    private double age = 0;
    // The Maximum age of the animal, in days. Upon reaching the max age, it will die.
    private double MAX_AGE = 2;
    // The maximum amount of energy this creature can have at any given time.
    private int MAX_ENERGY = 20;
    // The current amount of energy the animal has.
    private int energy = 0;
    // BREEDING PARAMETERS
    // Defines whether the animal is male 
    private boolean isMale;
    // The minimum age an animal needs to be in order to breed.
    private int BREEDING_AGE;
    // The likelihood of an animal breeding.
    private double BREEDING_PROBABILITY;
    // The maximum offspring that can be created by an animal.
    private int MAX_LITTER_SIZE;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    // If the animal has a disease, it is stored in this field.
    protected Disease disease;
    // A Set of the types of animal which this creature can hunt.
    private HashSet<Class> preySet = new HashSet();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        isMale = rand.nextBoolean();
    }
    

    /**
     * Specific implementation of setDead; removes references to the
     * location, field and disease of the animal upon being called.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
            disease = null;
        }
    }
    
    /**
     * Gets the maximum energy of this creature.
     * @return The animal's maximum energy.
     */
    public int getMaxEnergy(){
        return MAX_ENERGY;
    }
    
    /**
     * Sets the maximum energy of the animal to the provided value.
     * @param newFoodVal The animal's new maximum energy.
     */
    public void setMaxEnergy(int newMaxEnergy){
        MAX_ENERGY = newMaxEnergy;
    }
    
    /**
     * Gets the maximum age of this creature.
     * @return The animal's maximum age.
     */
    public double getMaxAge(){
        return MAX_AGE;
    }
    
    /**
     * Sets the maximum age of the animal to the provided value.
     * @param newMaxAge The animal's new maximum age.
     */
    public void setMaxAge(double newMaxAge){
        MAX_AGE = newMaxAge;
    }
    
    /**
     * Gets the age of this creature.
     * @return The animal's age.
     */
    public double getAge(){
        return age;
    }
    
    /**
     * Sets the age of the animal to the provided value.
     * @param newMaxAge The animal's new age.
     */
    public void setAge(double newAge){
        age = newAge;
    }
    
    
    /**
     * Returns the sex of the animal as a boolean - True represents Male, False represents Female.
     * @return True to represent Male, False to represent Female.
     */
    public boolean getSex() {
        return isMale;
    }
    
    /**
     * Gets the current energy of this creature.
     * @return The animal's current energy.
     */
    public int getEnergy(){
        return energy;
    }
    
    /**
     * Adds energy to the creature, up to the maximum energy of the creature.
     * @param energyToGain The energy which this animal should gain.
     */
    public void gainEnergy(int energyToGain){
        energy = Math.min(energy+energyToGain,MAX_ENERGY);
    }
    
    /**
     * Adds energy to the creature, up to the maximum energy of the creature.
     * @param energyToGain The energy which this animal should gain.
     */
    public void setEnergy(int energyValue){
        energy = Math.min(energyValue,MAX_ENERGY);
    }
    
    /**
     * Removes energy from the creature. If this would take the energy of the creature to 0 or below,
     * returns false, else returns true.
     * @param newFoodVal The animal's new location.
     * @return Whether the animal has run out of energy. 
     */
    public boolean loseEnergy(int energyToLose){
        energy = energy - energyToLose;
        if(energy <= 0){
            return true;
        }
        return false;
    }
    
    /**
     * Ages this animal by the number of minutes in a single cycle. 
     * If the new age exceeds the maximum age of the animal, returns true, else returns false.
     *
     * @param mins A parameter
     * @return Whether the current age of the animal exceeds the maximum age.
     */
    public boolean getOlder(double mins){
        age += mins;
        if(age > MAX_AGE) {
            return true;
        }
        return false;
    }
    
    /**
     * Sets the breeding parameters of the Animal.
     *
     * @param minAge The minimum age an animal should be in order to be eligible to breed.
     * @param breedChance The probability this animal will successfuly give birth to offspring.
     * @param maxLitter The maximum size of a litter. Each breed generates a number randomly from 1 to this number to create.
     */
    public void setBreedParameters(int minAge, double breedChance, int maxLitter)
    {
        BREEDING_AGE = minAge;
        BREEDING_PROBABILITY = breedChance;
        MAX_LITTER_SIZE = maxLitter;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Gives this Animal a Disease. If the animal already possesses a disease, nothing happens.
     */
    public void infect(Disease infection)
    {
        if(getDisease() == null){
            disease = infection;
        }
    }
    
     /**
     * Cures any Disease this Animal may have.
     */
    public void cure()
    {
        disease = null;
    }
    
    /**
     * Returns the Disease which this animal has; or null if no disease is present.
     */
    public Disease getDisease()
    {
        return disease;
    }

    /**
     * In order to breed, an animal
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object partner = (Object) field.getObjectAt(where);
            if(partner != null && this.getClass() == partner.getClass() && (!getSex() && ((Animal) partner).getSex())) {
                return (getAge() >= BREEDING_AGE);
            }
        }
        return false;
    }
    
    /**
     * Look for food adjacent to the current location.
     * Only the first eligible plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal != null && preySet.contains(animal.getClass())) {
                Organism prey = (Organism) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    gainEnergy(prey.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
   
    /**
     * Adds an class of an Organism to the list of those it will seek when
     * finding food.
     *
     * @param newPrey The class of the prey to add.
     */
    public void addPrey(Class newPrey){
        preySet.add(newPrey);
    }
    
    /**
     * Sets the age and energy of the Animal to a random value between 0 and
     * the maximum value for each.
     */
    public void randomiseAgeEnergy(){
        setAge(rand.nextDouble()*getMaxAge());
        setEnergy(rand.nextInt(getMaxEnergy()));
    }
}
