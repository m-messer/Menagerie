import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a predator.
 * Predatores age, move, eat preys, get infected, and die of old age or starvation.
 *
 * @version 2020.02.22
 */
abstract class Predator extends Animal {
    // List of prey that a predator can eat
    private List<Class> favouredPrey;

    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(Boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        favouredPrey = new ArrayList<>();
    }

    /**
     * Look for favoured preys adjacent to the current location.
     * Only the first live prey is eaten.
     * If the prey is infected, the predator gets also infected.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal != null && favouredPrey.contains(animal.getClass())) {
                Prey prey = (Prey) animal;
                if (prey.isAlive()) { 
                    if (prey.isInfected()) {
                        infect();
                    }
                    prey.setDead();
                    subtractHunger(prey.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Returns a list of prey that the predator can eat.
     * @return favouredPrey 
     */
    public List getFavouredPrey() {
        return favouredPrey;
    }

    /**
     * Sets favoured prey for a predators.
     * 
     * @param preys List of preys that can be eaten by a predator
     */
    public void setFavouredPrey(Class... preys) {
        favouredPrey.clear();
        for (Class prey : preys) {
            favouredPrey.add(prey);
        }
    }
}
