
/**
 * A class controlling the weather
 *
 * @version 2020.02.22 
 */
public class Weather {
    private static Condition currentCondition = Condition.SUNNY;
    private static Condition nextCondition;

    /**
     * Private constructor because weather is not meant to be instantiated
     */
    private Weather() {
    }

    /**
     * Returns the current weather condition
     * @return Condition the current condition
     */
    public static Condition getCurrentCondition() {
        return currentCondition;
    }

    /**
     * Sets nextCondition to a randomised condition
     */
    private static void randomiseCondition() {
        nextCondition = Condition.getRandomCondition();
    }

    /**
     * Gets the next weather condition. 
     */
    public static void changeCondition() {
        if (nextCondition == null) {
            currentCondition = Condition.getRandomCondition();
        } else {
            currentCondition = nextCondition;
        }
        nextCondition = Condition.getRandomCondition();
    }
    
    /**
     * Returns whether or not a condition is the current condition. 
     * Can take variable number of arguments.
     * 
     * @param conditions Conditions to test for
     * @return Current weather is this or not
     */
    public static boolean weatherIs(Condition... conditions) {
        for (Condition condition : conditions) {
            if (condition == currentCondition) {
                return true;
            }
        }
        return false;
    }
}