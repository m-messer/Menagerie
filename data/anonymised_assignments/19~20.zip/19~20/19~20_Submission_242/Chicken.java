import java.util.List;

/**
 * A simple model of a Chicken. Chickens inherit a lot of properties from prey,
 * but have their own way of acting every step.
 *
 * @version 2020.02.22
 */
public class Chicken extends Prey {
    /**
     * Constructor of Chickens. If the randomAge is set true the chicken will be spawned with random age.
     * 
     * @param randomAge Whether the chicken's age starts at 0 or not.
     * @param field The field where the chicken lives
     * @param location The location that the chicken occupies
     */
    public Chicken(Boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the Chicken does most of the time. It tries to find grass to eat 
     * and would transfer diseases to other chickens if sick.
     * It stops moving between hours 16 to 20.
     * Sometimes it will breed or die of old age, starvation or disease.
     * 
     * @param newChickens A list to return newly born Chickens.
     */
    public void act(List<Animal> newChickens) {
        super.act(newChickens);
        if (isAlive()) {  
            if (getFoodLevel() > (int) Grass.FOOD_VALUE / 2) {
                giveBirth(newChickens);   
            }       
            // Try to move into a free location.

            Location newLocation = findFood();
            if (newLocation != null) {
                if (getTimeOfDay() <= 16 || getTimeOfDay() >= 20) {
                    setLocation(newLocation);
                }
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }
}
