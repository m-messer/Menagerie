import java.util.Random;

/**
 * Enums for weather conditions with precipitation & temperature
 *
 * @version 2020.02.22 
 */
public enum Condition {
    //Set up enum values for each type of weather
    SUNNY("sunny", 0, 25), RAINY("rainy", 50, 10), SNOWY("snowy", 0, -5), STORMY("stormy", 100, 18);
    
    // The amount of precipitation and temperature caused by the current weather condition
    public final int precipitation, temperature;
    
    // Name of the weather condition
    private String name;
    
    /**
     * Constructor for Conditon
     */
    Condition(String name, int precipitation, int temperature) {
        this.precipitation = precipitation;
        this.temperature = temperature;
        this.name = name;
    }
    
    /**
     * Generates a random weather condition
     * @return the random Condition generated
     */
    public static Condition getRandomCondition() {
        return Condition.values()[new Random().nextInt(4)];
    }
    
    /**
     * Accessor method for the name of the weather condition
     * @return String of the name
     */
    public String getName() {
        return name;
    }
}
