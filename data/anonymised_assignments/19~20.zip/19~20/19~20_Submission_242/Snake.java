import java.util.List;

/**
 * A simple model of a Snake. Snakes inherit a lot of properties from Predator,
 * but have their own way of acting every step.
 *
 * @version 2020.02.22
 */
public class Snake extends Predator {
    /**
     * Constructor of Snakes. If the randomAge is set true the snake will be spawned with random age.
     * 
     * @param randomAge Whether the snake's age starts at 0 or not.
     * @param field The field where the snake lives
     * @param location The location that the snake occupies
     */
    public Snake(Boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        setFavouredPrey(Mouse.class, Chicken.class);
    }

    /**
     * This is what the Snake does most of the time. It hunts for
     * prey and would transfer diseases to other snakes if sick. 
     * Snake twice as if it is snowing. Otherwise it moves two steps
     * at a time. Sometimes it would breed or die of old age starvation or disease.
     * 
     * @param newSnakes A list to return newly born snakes.
     */
    public void act(List<Animal> newSnakes) {
        super.act(newSnakes);
        if (isAlive()) {  
            if (getFoodLevel() > (int) constants.get(getFavouredPrey().get(0))[FOOD_VALUE] / 2) {
                giveBirth(newSnakes);
            }          
            
            // Move towards a source of food if found.
            for (int i = 0; i < 2; i++) {
                Location newLocation = null;
                newLocation = findFood();
                if (newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    if (!Weather.weatherIs(Condition.SNOWY) || getTimeOfDay() % 2 != 0) {
                        setLocation(newLocation);
                    }
                } else {
                    // Overcrowding.
                    setDead();
                    i += 2;
                }
            }
        }
    }
}
