import java.util.HashMap;
import java.util.Random;
import java.util.List;

/**
 * A class controlling the behaviour of Grass
 *
 * @version 2020.02.22 
 */

public class Grass
{
    // Constants
    public static final int MAX_AGE = 20, POLLINATION_CHANCE = 500, FOOD_VALUE = 10, RIPE_AGE = 8;

    private int age;
    private boolean alive,  isRipe;

    // Randomiser
    public static final Random rand = Randomizer.getRandom();

    //Variables for the field and location
    private Field field;
    private Location location;

    /**
     * Constructor for objects of class Plant
     */
    public Grass(Field field, Location location) {
        this.field = field;
        this.location = location;
        age = 0;
        alive = true;
        isRipe = false; // When new grass grows, it can't be eaten until it reaches a certain age
        setLocation(location);
    }

    /**
     * Constructor for objects of class Plant
     * @param field, location and if it is ripe or not
     */
    public Grass(Field field, Location location, boolean ripe) {
        this(field, location);
        if (ripe) {
            age = RIPE_AGE;
            isRipe = true;
        }
    }

    /**
     * Grow method for grass - controls the spread of grass
     * @param list of new grass 
     */
    public void grow(List<Grass> newGrass) {
        incrementAge();
        if (isAlive()) {      
            Location freeRealEstate = field.plantFreeAdjacentLocation(location);
            if (freeRealEstate == null) {
                return;
            } else {
                if (rand.nextInt(1000) < POLLINATION_CHANCE) {
                    newGrass.add(new Grass(field, freeRealEstate));
                }
            } 
        }
    }

    /**
     * Increases the age of grass. If it's over the maximum age it sets it to dead,
     * and if it's over the ripe age, sets it to ripe
     */
    public void incrementAge() {
        age++;
        if (age > MAX_AGE) {
            alive = false;
        } else if (age > RIPE_AGE && !isRipe) {
            isRipe = true;
        }
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clearVegetationAt(location);
            location = null;
            field = null;
        }
    }

    /**
     * Acessor method for the ripeness of Grass. 
     * @return boolean if it's ripe or not
     */
    public boolean isRipe() {
        return isRipe;
    }

    /**
     * Accessor method for if the Grass is alive
     * @return boolean if the Grass is alive
     */
    public boolean isAlive() {
        return alive;
    }

    /**
     * Sets the location of Grass
     * @param Modifier method for seting the location of Grass
     */
    public void setLocation(Location location) {
        field.setVegetationAt(location, this);
    }
}
