import java.util.List;

/**
 * A simple model of a Mouse. Mice inherit a lot of properties from Prey,
 * but have their own way of acting every step.
 *
 * @version 2020.02.22
 */
public class Mouse extends Prey {
    /**
     * Constructor of Mice. If the randomAge is set true the mouse will be spawned with random age.
     * 
     * @param randomAge Whether the mouse's age starts at 0 or not.
     * @param field The field where the mouse lives
     * @param location The location that the mouse occupies
     */
    public Mouse(Boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the Mouse does most of the time. It tries to find grass to eat 
     * and would transfer diseases to other mice if sick.
     * It stops moving between hours 12 to 16.
     * If it is snowy or stormy it moves half as fast.
     * Sometimes it will breed or die of old age, starvation or disease.
     * 
     * @param newMice A list to return newly born mice.
     */
    public void act(List<Animal> newMice) {
        super.act(newMice);
        if (isAlive()) {  
            if (getFoodLevel() > (int) Grass.FOOD_VALUE / 2) {
                giveBirth(newMice);   
            }       
            // Try to move into a free location.

            Location newLocation = findFood();
            if (newLocation != null) {
                if (getTimeOfDay() <= 12 || getTimeOfDay() >= 16) {
                    if (!Weather.weatherIs(Condition.SNOWY, Condition.STORMY) || getTimeOfDay() % 2 != 0) {
                        setLocation(newLocation);
                    }
                }
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }
}
