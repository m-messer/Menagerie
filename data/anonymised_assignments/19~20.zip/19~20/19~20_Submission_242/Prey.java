import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Prey.
 * Preys age, move, breed, eat grass, and die of starvation or old age.
 *
 * @version 2020.02.22
 */
abstract class Prey extends Animal {
    /**
     * Create a new Prey. A Prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
    }

    /**
     * Look for grass adjacent to the current location.
     * @return Where grass was found, or null if it wasn't.
     */
    public Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.getFreeAdjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Grass grass = field.getVegetationAt(where);
            if (grass != null) {
                if (grass.isRipe()) {
                    subtractHunger(Grass.FOOD_VALUE);
                    grass.setDead();
                    return where;
                }
            }
        }
        
        if (adjacent.isEmpty()) {
            return null;
        } else {
            return adjacent.get(0);
        }
    }
}
