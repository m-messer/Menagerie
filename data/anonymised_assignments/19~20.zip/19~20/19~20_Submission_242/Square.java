import java.util.ArrayList;

/**
 * The field is made up of an array of squares.
 * Squares carry one animal and one plant in the background.
 *
 * @version 2020.02.22
 */
public class Square {
    // Grass object in the background
    private Grass background;
    
    // Animal that occupies this square
    private Animal occupier;
    
    /**
     * Constructor of Squares
     */
    public Square() {
        background = null;
        occupier = null;
    }
    
    /**
     * Gets the animal in this square
     * 
     * @return animal
     */
    public Animal getAnimal() {
        return occupier;
    }
    
    /**
     * Puts an animal in this square. If there was an animal here already it will be discarded.
     * 
     * @param animal
     */
    public void setAnimal(Animal animal) {
        occupier = animal;
    }
    
    /**
     * Gets the grass object in this square
     * 
     * @return grass
     */
    public Grass getPlants() {
        return background;
    }
    
    /**
     * Removes the grass object in this square
     */
    public void removePlant() {
        background = null;
    }
    
    /**
     * Puts a grass object in this square.
     * 
     * @param grass
     */
    public void addPlant(Grass grass) {
        background = grass;
    }
    
    /**
     * Removes the animal in this square.
     */
    public void clearAnimal() {
        occupier = null;
    }
    
    /**
     * Clears both grass and animal in this square
     */
    public void clear() {
        occupier = null;
        background = null;
    }
}
