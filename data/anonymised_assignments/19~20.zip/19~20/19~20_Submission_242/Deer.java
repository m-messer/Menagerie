import java.util.List;

/**
 * A simple model of a Deer. Deer inherit a lot of properties from Prey,
 * but have their own way of acting every step.
 *
 * @version 2020.02.22
 */
public class Deer extends Prey {
    /**
     * Constructor of Deer. If the randomAge is set true the deer will be spawned with random age.
     * 
     * @param randomAge Whether the deer's age starts at 0 or not.
     * @param field The field where the deer lives
     * @param location The location that the deer occupies
     */
    public Deer(Boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the Deer does most of the time. It tries to find grass to eat 
     * and would transfer diseases to other deer if sick.
     * It stops moving between hours 20 to 24 and cannot breed when it is snowing.
     * Sometimes it will breed or die of old age, starvation or disease.
     * 
     * @param newDeer A list to return newly born deer.
     */
    public void act(List<Animal> newDeer) {
        incrementAge();
        incrementHunger();
        transferDisease();
        if (isAlive()) {  
            if (getFoodLevel() > (int) Grass.FOOD_VALUE / 2 || Weather.getCurrentCondition().temperature > 0) {
                giveBirth(newDeer);   
            }       
            // Try to move into a free location.
            Location newLocation = findFood();
            if (newLocation != null) {
                if (getTimeOfDay() <= 20 || getTimeOfDay() >= 24) {
                    setLocation(newLocation);
                }
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }
}
