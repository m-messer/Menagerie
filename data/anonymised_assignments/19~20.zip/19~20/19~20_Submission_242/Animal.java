import java.util.List;
import java.util.HashMap;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.22
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // Animal's age
    private int age;
    // The animal's food level, which is increased by eating rabbits.
    private int foodLevel;
    // The animal's gender, assigned at birth and never changes...
    public final boolean isFemale;
    // Animal health state
    private boolean infected;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // Indices used to access an animal's constants
    public static final int BREEDING_AGE = 0, MAX_AGE = 1, BREEDING_PROBABILITY = 2, MAX_LITTER_SIZE = 3,
    FOOD_VALUE = 4, MAX_BELLY_SIZE = 5, CREATION_PROBABILITY = 6;
    // Randomizer
    public static final Random rand = Randomizer.getRandom();
    // HashMap that maps every animal class to its set of constants
    public static final HashMap<Class, Number[]> constants = setConstants();

    /**
     * Creates and returns a hashmap of all the constants.
     * 
     * @return temp Hashmap of all constants
     */
    private static HashMap<Class, Number[]> setConstants() {
        HashMap<Class, Number[]> temp = new HashMap<>();
        temp.put(Wolf.class, new Number[] {30, 150, 0.40, 5, 50, 30, 0.04});
        temp.put(Eagle.class, new Number[] {10, 100, 0.40, 4, 40, 40, 0.04});
        temp.put(Snake.class, new Number[] {15, 120, 0.55, 6, 20, 40, 0.04});
        temp.put(Deer.class, new Number[] {5, 90, 0.5, 5, 50, 80, 0.28});
        temp.put(Mouse.class, new Number[] {2, 20, 0.5, 3, 10, 20, 0.28});
        temp.put(Chicken.class, new Number[] {5, 90, 0.75, 8, 30, 40, 0.28});
        return temp;
    }

    /**
     * Create a new animal at location in field.
     * An animal can be born normally with 0 age
     * or spawned with a random age. All animals
     * are created half-full, or half-empty.
     * 
     * @param randomAge Age random or not
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        isFemale = rand.nextInt(2) == 1;
        infected = rand.nextInt(100) == 1;
        foodLevel = getMaxBellySize() / 2;
        age = randomAge ? rand.nextInt(getMaxAge()) : 0;
        setLocation(location);
    }

    /**
     * This is what the animal does every step.
     * This method should be overridden.
     * 
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newAnimals)
    {
        incrementAge();
        incrementHunger();
        transferDisease();
    }

    /**
     * Gives birth to new animals of this animal's kind.
     * It works by instantiating a new object through reflection
     */
    public void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = getField().getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Animal young = null;
            try {
                Class thisClass = this.getClass();
                Class[] parameters = {Boolean.class, Field.class, Location.class};
                young = (Animal) thisClass.getConstructor(parameters).newInstance(false, field, loc);
            } catch (Exception e) {
                // Do nothing
            }
            newAnimals.add(young);
        }
    }

    /**
     * The method an animal uses to find food. Food can be other animals or plants
     * 
     * @return location Where the closest food item is located
     */
    public abstract Location findFood();

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * A predator can breed if it has reached the breeding age.
     */
    public boolean canBreed()
    {
        return age >= getBreedingAge() && isFemale;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * The method that an animal uses to transfer disease.
     * It can only transfer diseases to others of its kind or if it gets eaten
     */
    public void transferDisease() {
        if (!infected) {
            return;
        }
        Location neighbourlocation = null;
        try {
            neighbourlocation = getField().randomAdjacentLocation(getLocation());
        } catch (NullPointerException e) {
        }
        if (neighbourlocation == null) {
            return;
        }
        Animal neighbour = getField().getObjectAt(neighbourlocation);
        if (neighbour == null || neighbour.getClass() != this.getClass()) {
            return;
        }
        if (rand.nextInt(100) < 10) {
            neighbour.infect();
        }
    }

    /**
     * Returns whether or not this animal is infected with disease
     * 
     * return infect Whether or not it is infected
     */
    public boolean isInfected() {
        return infected;
    }

    /**
     * This method causes an animal to be infected.
     * It should only be called when a disease is transferred to it
     */
    protected void infect() {
        infected = true;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Make this predator more hungry. This could result in the predator's death.
     * If an animal is infected it gets hungry twice as fast.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
        if (infected) {
            foodLevel--;
        }
    }

    /**
     * Increase the age.
     * This could result in the Prey's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    } 

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed() {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Animal animal = (Animal) field.getObjectAt(where);
                if(animal != null && animal.isAlive()) {
                    if (!animal.isFemale && animal.getClass() == this.getClass()) {
                        births = rand.nextInt(getMaxLitterSize()) + 1;
                    }
                }
            }
        }
        return births;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * Gets this animal's max age from the constants map
     * 
     * @return maxAge The animal's max age
     */
    public int getMaxAge() {
        return (Integer) constants.get(this.getClass())[MAX_AGE];
    }

    /**
     * Gets this animal's breeding age from the constants map
     * 
     * @return breedingAge The animal's breeding age
     */
    public int getBreedingAge() {
        return (Integer) constants.get(this.getClass())[BREEDING_AGE];
    }

    /**
     * Gets this animal's breeding probability from the constants map
     * 
     * @return breedingProbability The animal's breeding probability
     */
    public double getBreedingProbability() {
        return (Double) constants.get(this.getClass())[BREEDING_PROBABILITY];
    }

    /**
     * Gets this animal's max litter size from the constants map
     * 
     * @return maxLitterSize The animal's max litter size
     */
    public int getMaxLitterSize() {
        return (Integer) constants.get(this.getClass())[MAX_LITTER_SIZE];
    }

    /**
     * Gets this animal's nutritional value when eaten from the constants map
     * 
     * @return foodValue The animal's food value
     */
    public int getFoodValue() {
        return (Integer) constants.get(this.getClass())[FOOD_VALUE];
    }

    /**
     * Gets this animal's max belly size from the constants map
     * 
     * @return maxBellySize The animal's max belly size
     */
    public int getMaxBellySize() {
        return (Integer) constants.get(this.getClass())[MAX_BELLY_SIZE];
    }

    /**
     * Gets the current time of day from the simulator class in 24-hour format
     * 
     * @return timeOfDay Current time of day
     */
    public int getTimeOfDay() {
        return Simulator.getStep() % 24;
    }

    /**
     * Increases this animal's food level when it eats something
     * 
     * @param snacc Value to increase food level by
     */
    public void subtractHunger(int snacc) {
        foodLevel += snacc;
    }

    /**
     * Gets this animal's current food level
     * 
     * @return foodLevel Current food level
     */
    public int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Gets this animal's probability of getting spawned at the start of the simulation
     * 
     * @return creationProbability The probability that an animal is spawned
     */
    public double getCreationProbability() {
        return (Double) constants.get(this.getClass())[CREATION_PROBABILITY];
    }

    /**
     * Gets the provided animal's probability of getting spawned at the start of the simulation
     * 
     * @param type of animal to be spawned
     * @return creationProbability The probability that an animal is spawned
     */
    public static double getCreationProbabilityOf(Class animal) {
        return (Double) constants.get(animal)[CREATION_PROBABILITY];
    }
}
