import java.util.List;

/**
 * A simple model of a Eagle. Eagles inherit a lot of properties from Predator,
 * but have their own way of acting every step.
 *
 * @version 2020.02.22
 */
public class Eagle extends Predator {
    /**
     * Constructor of Eagles. If the randomAge is set true the eagle will be spawned with random age.
     * 
     * @param randomAge Whether the eagle's age starts at 0 or not.
     * @param field The field where the eagle lives
     * @param location The location that the eagle occupies
     */
    public Eagle(Boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        setFavouredPrey(Mouse.class, Deer.class);
    }

    /**
     * This is what the Eagle does most of the time. It hunts for
     * prey and would transfer diseases to other eagles if sick. 
     * Eagles move six steps at a time when it's not raining or storming.
     * Sometimes it would breed or die of old age starvation or disease.
     * 
     * @param newEagles A list to return newly born eagles.
     */
    public void act(List<Animal> newEagles) {
        super.act(newEagles);
        if (isAlive()) {  
            if (getTimeOfDay() <= 12 && getFoodLevel() > (int) constants.get(getFavouredPrey().get(0))[FOOD_VALUE] / 2) {
                giveBirth(newEagles);
            }          

            // Move towards a source of food if found.
            Location newLocation = null;
            newLocation = findFood();
            if (newLocation == null) { 
                if (Weather.getCurrentCondition().precipitation < 30) {
                    // No food found - try to look again for five times.
                    for (int i = 0; i < 5; i++) {
                        newLocation = findFood();
                        if (newLocation != null) {
                            i += 5;
                        } else {
                            newLocation = getField().freeAdjacentLocation(getLocation());
                            if (newLocation != null) {
                                setLocation(newLocation);
                            }
                        }
                    }
                }  else {
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
            }
            // See if it was possible to move.
            if (newLocation != null) {
                if (getTimeOfDay() > 12 || Weather.getCurrentCondition().precipitation > 30){
                    setLocation(newLocation);
                }
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }
}
