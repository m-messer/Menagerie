import java.util.List;
import java.util.Iterator;
import java.lang.Math;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.23
 */
public abstract class Animal extends Organism
{
    protected boolean isFemale; // is a female or not.
    
    protected boolean isDiseased; // is diseased or not.
    
    protected int diseaseProliferation; // how much the disease has spread for each organism.
    
    protected boolean matedThisStep; // whether the animal has mated at a specific step to prevent the same animals mating twice in one step.
    

    
    // Individual characteristics (instance fields).
    // The animal's age.
    protected int age;
    // The animal's food level, which is increased by eating it's designated prey. 
    protected int foodLevel;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        isFemale = Math.random() < 0.5;
        isDiseased = Math.random() < 0.01;
        diseaseProliferation = 0;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly made organisms.
     * @param isDayLight Whether it is day-time or not. May affect an Animals behaviour.
     * @param isRaining Whether it is raining or not. May affect an Animals behaviour.
     */
    abstract public void act(List<Organism> newOrganisms, boolean isDayLight, boolean isRaining);

    
    /**
     * Look for a mate of the opposite gender adjacent to the current location.
     * Breeding only happens with first mate found.
     * @return The mate animal found, or null if there was no mate found.
     */
    protected Animal foundMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Organism organism = (Organism) field.getObjectAt(where);
            if(organism == null || !(organism instanceof Animal)){}
            else
            {
               Animal animal = (Animal) organism;
                if(!animal.getClass().equals(this.getClass())){}
               else
               {
                   if(animal.isFemale == this.isFemale){}
                   else
                   {
                       if(animal.matedThisStep){}
                       else
                       {
                           return animal;
                        }
                   }
                } 
            }
            
            
        }
        return null;
    }

}
