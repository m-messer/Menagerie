import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a plant.
 * Plants age, move, eat mice, and die.
 *
 * @version 2020.02.23
 */
public class Plant extends Organism
{

    // The maximum number of growths.
    private static final int MAX_LITTER_SIZE = 23;
    
    private static final double GROWTH_PROBABILITY = 0.6;
    // The food value of a single mouse. In effect, this is the
    // number of steps a plant can go before it has to eat again.
    private static final int RAIN_VALUE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The plant's food level, which is increased by eating mice.
    private int thirstLevel;

    /**
     * Create a plant. A plant can be created as new (not thirsty) or with a thirst level.
     * 
     * @param randomAge If true, the plant will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            thirstLevel = rand.nextInt(RAIN_VALUE);
        }
        else {
            thirstLevel = RAIN_VALUE;
        }
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly made organisms.
     * @param isDayLight Whether it is day-time or not. May affect an Animals behaviour.
     * @param isRaining Whether it is raining or not. May affect an Animals behaviour.
     */
    public void act(List<Organism> newPlants, boolean isDayLight, boolean isRaining)
    {
        incrementThirst();
        if(isAlive() && isDayLight)
        {
            
            grow(newPlants);
        }
        
    }

    
    /**
     * Make this plant more thirsty. This could result in the plant's death.
     */
    private void incrementThirst()
    {
        thirstLevel--;
        if(thirstLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Reset thirst value. Called after raining.
     */
    protected void resetThirst()
    {
        thirstLevel = RAIN_VALUE;
    }
    

    
    /**
     * Check whether or not this plant is to grow at this step.
     * New growths will be made into free adjacent locations.
     * @param newPlants A list to return newly grown plants.
     */
    private void grow(List<Organism> newPlants)
    {
        // New plants grow into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        if(rand.nextDouble() <= GROWTH_PROBABILITY){
            int growths = rand.nextInt(MAX_LITTER_SIZE) + 1;
        
            for(int b = 0; b < growths && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Plant young = new Plant(false, field, loc);
                newPlants.add(young);
            }
        }
    }
        


}
