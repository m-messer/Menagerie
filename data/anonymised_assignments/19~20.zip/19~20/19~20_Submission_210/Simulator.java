    import java.util.Random;
    import java.util.List;
    import java.util.ArrayList;
    import java.util.Iterator;
    import java.awt.Color;
    
    /**
     * A simple predator-prey simulator, based on a rectangular field
     * containing various organisms.
     *
     * @version 2020.02.23
     */
    public class Simulator
    {
        // Constants representing configuration information for the simulation.
        // The default width for the grid.
        private static final int DEFAULT_WIDTH = 120;
        // The default depth of the grid.
        private static final int DEFAULT_DEPTH = 80;
        // The probability that a wolf will be created in any given grid position.
        private static final double WOLF_CREATION_PROBABILITY = 0.02;
        // The probability that a bear will be created in any given grid position.
        private static final double BEAR_CREATION_PROBABILITY = 0.02;
        // The probability that a eagle will be created in any given grid position.
        private static final double EAGLE_CREATION_PROBABILITY = 0.02;
        // The probability that a moose will be created in any given grid position.
        private static final double MOOSE_CREATION_PROBABILITY = 0.3; 
        // The probability that a mouse will be created in any given grid position.
        private static final double MOUSE_CREATION_PROBABILITY = 0.08;
        // The probability that a plant will be created in any given grid position.
        private static final double PLANT_CREATION_PROBABILITY = 0.02;
        // The probability that it will rain.
        private static final double RAIN_PROBABILITY = 0.7;
        
        private int time; // the current time.
        private boolean isDayLight; // whether it is day-time or not.
        private static final int DAY_LENGTH = 20; // the length of the whole day.
        private static final int NIGHT_START_TIME = 11; // when the night starts.
        private static final int DAYLIGHT_START_TIME = 1; // when the day starts.
        
        
        // List of animals in the field.
        private List<Organism> organisms;
        // The current state of the field.
        private Field field;
        // The current step of the simulation.
        private int step;
        // A graphical view of the simulation.
        private SimulatorView view;
        // is it isRaining.
        private boolean isRaining;
    
        /**
         * Construct a simulation field with default size.
         */
        public Simulator()
        {
            this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        }
        
        /**
         * Create a simulation field with the given size.
         * @param depth Depth of the field. Must be greater than zero.
         * @param width Width of the field. Must be greater than zero.
         */
        public Simulator(int depth, int width)
        {
            if(width <= 0 || depth <= 0) {
                System.out.println("The dimensions must be greater than zero.");
                System.out.println("Using default values.");
                depth = DEFAULT_DEPTH;
                width = DEFAULT_WIDTH;
            }
            
            organisms = new ArrayList<>();
            field = new Field(depth, width);
    
            // Create a view of the state of each location in the field.
            view = new SimulatorView(depth, width);
            view.setColor(Moose.class, Color.ORANGE);
            view.setColor(Wolf.class, Color.BLUE);
            view.setColor(Mouse.class, Color.YELLOW);
            view.setColor(Bear.class, Color.MAGENTA);
            view.setColor(Eagle.class, Color.RED);
            view.setColor(Plant.class, Color.GREEN);
            
            // Setup a valid starting point.
            reset();
        }
        
        /**
         * Run the simulation from its current state for a reasonably long period,
         * (4000 steps).
         */
        public void runLongSimulation()
        {
            simulate(4000);
        }
        
        /**
         * Run the simulation from its current state for the given number of steps.
         * Stop before the given number of steps if it ceases to be viable.
         * @param numSteps The number of steps to run for.
         */
        public void simulate(int numSteps)
        {
            for(int step = 1; step <= numSteps && view.isViable(field); step++) {
                simulateOneStep();
                delay(60);   // uncomment this to run more slowly
            }
        }
        
        /**
         * Run the simulation from its current state for a single step.
         * Iterate over the whole field updating the state of each
         * Organism.
         */
        public void simulateOneStep()
        {
            step++;
            isRaining = Math.random() < RAIN_PROBABILITY;
            // Provide space for new organisms.
            List<Organism> newOrganisms= new ArrayList<>();        
            // Let all Organisms act.
            
            for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
                Organism organism = it.next();
                organism.act(newOrganisms, isRaining, isDayLight); 
                if(!organism.isAlive()) {
                    it.remove();
                }
                if(organism instanceof Animal)
                {
                    Animal animal = (Animal) organism;
                    animal.matedThisStep = false;
                }
                if(organism instanceof Plant && isRaining)
                {
                    Plant plant = (Plant) organism;
                    plant.resetThirst();
                    
                }
                
            }
            
            if(isRaining && isDayLight)
            {
                populatePlants();
                
            }
            
            time++;
            if(time == DAY_LENGTH)
            {
                time = 0;
            }
            else if(time == DAYLIGHT_START_TIME)
            {
                isDayLight = true;
            }
            else if(time == NIGHT_START_TIME)
            {
                isDayLight =  false;
            }
            
            
            // Add the newly born Organisms to the main lists.
            organisms.addAll(newOrganisms);
    
            view.showStatus(step, field, isDayLight, isRaining);
        }
        
        /**
         * Reset the simulation to a starting position.
         */
        public void reset()
        {
            step = 0;
            isDayLight = true;
            time = DAYLIGHT_START_TIME;
            organisms.clear();
            populate();
            
            // Show the starting state in the view.
            view.showStatus(step, field, isDayLight, isRaining);
        }
            
            /**
             * Randomly populate the field with Organisms.
             */
            private void populate()
            {
                Random rand = Randomizer.getRandom();
                field.clear();
                for(int row = 0; row < field.getDepth(); row++) {
                    for(int col = 0; col < field.getWidth(); col++) {
                        if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                            Location location = new Location(row, col);
                            Wolf wolf = new Wolf(true, field, location);
                            organisms.add(wolf);
                        }
                        else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                            Location location = new Location(row, col);
                            Bear bear = new Bear(true, field, location);
                            organisms.add(bear);
                        }
                        else if(rand.nextDouble() <= EAGLE_CREATION_PROBABILITY) {
                            Location location = new Location(row, col);
                            Eagle eagle = new Eagle(true, field, location);
                            organisms.add(eagle);
                        }
                        else if(rand.nextDouble() <= MOOSE_CREATION_PROBABILITY) {
                            Location location = new Location(row, col);
                            Moose moose = new Moose(true, field, location);
                            organisms.add(moose);
                        }
                        else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                            Location location = new Location(row, col);
                            Mouse mouse = new Mouse(true, field, location);
                            organisms.add(mouse);
                        }
                        else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                            Location location = new Location(row, col);
                            Plant plant = new Plant(true, field, location);
                            organisms.add(plant);
                        }
                        // else leave the location empty.
                }
            }
        }
        
        /**
         * Randomly populate the field with plants on demand.
         */
        private void populatePlants()
        {
            Random rand = Randomizer.getRandom();
            
            for(int row = 0; row < field.getDepth(); row++) {
                for(int col = 0; col < field.getWidth(); col++) {
                    
                    if(field.getObjectAt(row, col) == null && rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Plant plant = new Plant(true, field, location);
                        organisms.add(plant);
                    }
                    // else leave the location empty.
                }
            }
        }
        
        /**
         * Pause for a given time.
         * @param millisec  The time to pause for, in milliseconds
         */
        private void delay(int millisec)
        {
            try {
                Thread.sleep(millisec);
            }
            catch (InterruptedException ie) {
                // wake up
            }
        }
    
        
    }
