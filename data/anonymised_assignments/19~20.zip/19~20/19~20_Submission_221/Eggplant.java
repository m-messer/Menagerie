import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Eggplant.
 * This is one of the special vegetation, when an infected animal eat eggplant,
 * the animal get cured.
 * 
 * @version 2020.02.20 
 */
public class Eggplant extends SpecialVegetation
{
    // The likelihood of a eggplant breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    //age when it breeds
    private static final int BREEDING_AGE = 2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //max steps an eggplant can survuve
    private static final int MAX_AGE = 5;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The eggplant's moisture.
    private int moisture;
    //eggplants hoobidong
    private int hoobidong;
    //this is amagic potion which can only be attained from the hoobadong weather
    //cures the animals that are infected
    //magicpotion

    /**
     * Constructor for objects of class EggPlants.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Eggplant(Field field, Location location)
    {

        // initialise instance variables
        super(field, location);

        moisture = 8;
        sunlevel = 8;
        hoobidong = 3;
        actorfoodval = EGGPLANT_FOOD_VALUE;
    }

    /**
     * This is what the EggPlant does most of the time: 
     * cures animals with inections if there isn't enough hoobidong it dies
     * gives birth to new eggplant
     */
    public void act(List<Actor> newEggplant, boolean day, int weather)
    {
        weatherChange(weather);
        TriggerStepChange();
        if(isAlive() && !isRotten()) {

            giveBirth(newEggplant);            

        }
    }

    /**
     * When sun, add sunlevel, when hoobidong add hoobidong level.
     * @param weather, a variable to make conditions.
     */
    private void weatherChange(int weather){
        if(weather == 0){
            sunlevel += 5;
        }
        else if(weather == 3){
            hoobidong += 5;
        } 
        else if(weather == 1){
            moisture += 10;
        }

    }

    /**
     * Make this eggplant more hungry for the 3 thing below. This could result in the eggplant's death.
     */
    private void TriggerStepChange()
    {
        sunlevel--;//After every step the mushroom utilizes moisture/sun and hoobidong in doing so.
        moisture--;
        hoobidong--;

        if((sunlevel <= 0) || (moisture <= 0) || (hoobidong <= 0)) {
            setRotten();
        }
    }

    /**
     * Check whether or not this eggplant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newEggplant, A list to return newly born eggplants.
     */
    private void giveBirth(List<Actor> newEggplant) 
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();

        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        int births = breed();

        for(int b = 0; (b < births) && (free.size() > 0); b++) {
            moisture= moisture -1;// each birth takes off 1 moisture level

            Location loc = free.remove(0);
            Eggplant young = new Eggplant(field, loc); 
            newEggplant.add(young);
        }
    }

    /**
     * 
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An eggplant can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {        
        if(moisture >= 5){
            return true;
        }
        return false;
    }

}
