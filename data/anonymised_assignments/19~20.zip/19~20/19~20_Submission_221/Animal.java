import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 * 
 * @version 2020.02.20 
 */
public abstract class Animal extends Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // 0 = male, 1 = female
    private int gender = 0;
    protected int age;
    protected int foodLevel;
    protected int infectionLevel = 0;
    //this stores the list of classes that an animla can eat
    protected List<Class<?>> animalFood = new ArrayList<Class<?>>();
    private static final double INFECTION_PROBABILITY = 0.95;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, int gender)
    {
        super(field, location);
        alive = true;
        this.gender = gender;

    }

    /**
     * Abstract method foe each subclass to allow breeding some may allow
     * bredding without the presense of the opposite gender.
     */
    abstract public boolean genderandequals(Object o);

    /**
     * Get method for the gender.
     * @return gender of the animal.
     */
    protected int getGender(){
        return gender;
    }

    /**
     * Increase the age. This could result in the fox's death.
     * @param a local final MAX_AGE vaiable. 
     */
    protected void incrementAge(int MAX_AGE)
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     * if the animal is infected then it consumes twice the food
     */
    protected void incrementHunger()
    {
    
        foodLevel--;
        if(infectionLevel > 0){
            foodLevel--;
            infectionLevel--;

        }
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check if animal has infection.
     */
    protected boolean hasInfection(){

        return (infectionLevel>0);
    }
    
    /**
     * @return how much infection the animal has.
     */
    protected int InfectionDepth(){

        return (infectionLevel);
    }
    
    /**
     * In case the animal catches infection from eating another animal the infectin level is tranfered.
     * @param Define foreign infection level.
     */
    protected void hasCaughtInfection(int foreignInfectionLevel){
        this.infectionLevel = foreignInfectionLevel;

    }

    /**
     * Look for animals adjacent to the current location.
     * then for each animal found in the adjacent location, check if it can be eaten by 
     * the current animal
     * Only the first animal to be eaten is consumed
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            
            if(actor instanceof Actor){ // only if the object is an actor we move on 
            for (Class<?> animalEatsClass : animalFood) {
                //for eachedible class in animalFood we check if the object actor can be eaten
                if(actor.getClass() == actor.getClass()) {

                    Actor a = (Actor) actor;
                    if(a.isAlive()) {
                        //only is a is alive are we going to eat it
                        //because there might be instances where this animal is already eaten
                        // this leads to null pointer exception
                        if(this instanceof Zebra && a instanceof Mushroom){
                            //this is a special case where a zebra cathes an infection from eating a mushroom
                            if(rand.nextDouble() <= INFECTION_PROBABILITY){
                                infectionLevel += 10;
                            }
                        }else if(this instanceof Fox && a instanceof Zebra){
                            //this is a special case where a Fox cathes an infection from eating a Zebra
                            Zebra z = (Zebra) a;
                            if(z.hasInfection()){ // check if the zebra is infected, and if it is transfer the infection 
                                infectionLevel += z.InfectionDepth();
                            }
                        }else if(((this instanceof Fox ) || (this instanceof Zebra )) && a instanceof Eggplant){
                            //this is a special case where a Fox or Zebra eats an eggplant 
                                infectionLevel =0;//then infection  = 0
                        }
                        // this is the general setup for food to be eaten
                        foodLevel += a.individualFoodValue();
                        a.setDead();
                        return where;
                    }
                }
            }
        }
        }
        //if there is nothing to eat
        return null;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes. breeding prob , maxlitter and breeding age from the subclass
     */
    protected void giveBirth(List<Actor> newAnimal, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, int BREEDING_AGE)
    { 
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        //this checks for the opposite gender in adjacent location
        List<Location> opp_gender_check = field.getAdjacentOppGender(getLocation()); 
        int births = breed(BREEDING_PROBABILITY, MAX_LITTER_SIZE, BREEDING_AGE);

        for(int b = 0; (b < births) && (free.size() > 0) && (opp_gender_check.size() >0); b++) {
            Location loc = free.remove(0);

            // code has been split into various if statemnts because the .newInstance method requires a constuctor without any parameters
            if(this instanceof Fox){
            //    System.out.println("Fox Born");
                Fox young = new Fox(false, field, loc, rand.nextInt(2));
            young.hasCaughtInfection(infectionLevel); // this could be 0
            newAnimal.add(young);
            }
            else if(this instanceof Zebra){
            //   System.out.println("Zebra Born"); 
            Zebra young = new Zebra(false, field, loc, rand.nextInt(2));
            young.hasCaughtInfection(infectionLevel);
            newAnimal.add(young);
            }
            else if(this instanceof Rabbit){
            //System.out.println("Rabbit Born");
                Rabbit young = new Rabbit(false, field, loc, rand.nextInt(2));
            young.hasCaughtInfection(infectionLevel);
            newAnimal.add(young);
            }
            else if(this instanceof Cheetah){
             //   System.out.println("Cheetah Born ");
            Cheetah young = new Cheetah(false, field, loc, rand.nextInt(2));
            young.hasCaughtInfection(infectionLevel);
            newAnimal.add(young);
            }
            else if(this instanceof Alligator){
              //  System.out.println("Rabbit Born");
            Alligator young = new Alligator(false, field, loc, rand.nextInt(2));
            young.hasCaughtInfection(infectionLevel);
            newAnimal.add(young);
            }                       
        }
    }

    /**
     * 
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, int BREEDING_AGE)
    {
        int births = 0;
        if(canBreed(BREEDING_AGE) && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    protected boolean canBreed(int BREEDING_AGE)
    {
        return age >= BREEDING_AGE;
    }

}
