import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Rabbit.
 * Foxes age, move,have gender, eat grass,muhsroom and eggplant and die.
 * 
 * @version 2020.02.20 
 */
public class Rabbit extends Animal
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * This is what the rabbit does most of the time: it feeds for
     * acts when it is alive, it is day and weather is not cloudy
     * gives birth, eats specific things and moves
     * dies when age is reached or overcrowded or hungry
     * 
     * @param randomAge If true, the rabbit will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the animal
     */
    public Rabbit(boolean randomAge, Field field, Location location, int gender)
    {
        super(field, location, gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }

        animalFood.add(Grass.class);
        animalFood.add(Mushroom.class);
        animalFood.add(Eggplant.class);
        actorfoodval = RABBIT_FOOD_VALUE;
    }

    /**
     * This is what the rabbit does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param day The daytime rabbit gives birth.
     * @param field The field currently occupied.
     * @param newRabbits A list to return newly born rabbits.
     */
    public void act(List<Actor> newRabbits, boolean day, int weather)
    {

        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive() && day) {
            giveBirth(newRabbits, BREEDING_PROBABILITY, MAX_LITTER_SIZE, BREEDING_AGE);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * over here this is called from field class
     * the Parameter is the Animal we are comparing this animal with
     * we check if the animal in the adjacent block is of the same class and is an opp gender
     * by overriding the equals method.
     * 
     * @param 'o' The Object clas's instance.
     */
    public boolean genderandequals(Object o){
        if(o == this){ //check if we are checking with itself
            return false;
        }

        if(!(o instanceof Rabbit)){//if it is not an instance of fox then return false, we cant check true coz
            //we need the below thigs
            return false;
        }

        Rabbit r = (Rabbit ) o; // typecast to fox
        if(this.getGender() == r.getGender()){ // if the gender is the same then they can make babies
            return true;
        }
        return true;
    }
}
