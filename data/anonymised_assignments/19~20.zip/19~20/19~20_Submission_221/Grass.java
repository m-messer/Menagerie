import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Grass.
 * The simulation starts with grass, 60% grass. 
 * Slowly grows into a tree given it maintains it health for 80 steps,
 * after 80 steps it becomes a tree and is non edible by everyone.
 * 
 * @version 2020.02.20 
 */
public class Grass extends Vegetation
{

    // The likelihood of a grass breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    //how likely is it for some grass to convert into a tree
    private static final double TREE_CONVERSION_PROBABILITY = 0.01;
    //age when it breeds
    private static final int BREEDING_AGE = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    //max steps
    private static final int MAX_AGE = 15;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    private int age;

    /**
     * Constructor for objects of class Grass.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(Field field, Location location)
    {
        // initialise instance variables
        super(field, location);
        age = 0;
        moisture = 8;
        actorfoodval = GRASS_FOOD_VALUE;
    }

    /**
     * This is what the grass does most of the time: 
     * during the day grows more grass and converts to trees when certain condition is met
     * @param field The field currently occupied.
     * @param newGrass A list to return newly born grass.
     */
    public void act(List<Actor> newGrass, boolean day, int weather)
    {
        weatherChange(weather);
        incrementAge();
        TriggerStepChange();

        if(isAlive() && !isRotten() && day) {// if its alive, not rotten and its day
            if(age >= MAX_AGE && moisture >= 10 ){
                //the condition for getting converted into a tree
                if(rand.nextDouble() <= TREE_CONVERSION_PROBABILITY){
                    Field fieldstore = getField();
                    Location locationstore = getLocation();

                    setDead();
                    Tree tree = new Tree(fieldstore, locationstore);// make a new tree and remove the grass here

                    newGrass.add(tree);
                }
                //grass is now a tree
            }else{
                giveBirth(newGrass);            
            }
        }
    }

    /**
     * Increase the age. This could result in the fox's death.
     */

    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setRotten();
        }
    }

    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrass A list to return newly born grass.
     */
    private void giveBirth(List<Actor> newGrass) 
    {
        // New grass is born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();

        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        int births = breed();

        for(int b = 0; (b < births) && (free.size() > 0); b++) {
            moisture= moisture -5;
            Location loc = free.remove(0);
            Grass young = new Grass(field, loc); 
            newGrass.add(young);
        }
    }

    /**
     * 
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A grass can breed if it has reached the breeding age. and it has more than 5 moisture
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE){
            if(moisture >= 5){
                return true;
            }
        }
        return false;
    }
}
