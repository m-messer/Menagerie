import java.util.ArrayList;
/**
 * An abstract superclass Vegetation. EggPlant and Mushroom subclasses use this class and methods when needed,
 * in order to avoid code duplication. This class contains common features for its subclasses.
 * 
 * @version 2020.02.20 
 */
public abstract class SpecialVegetation extends Landscape 
{
    
    protected int sunlevel;
    
    /**
     * Constructor of SpecialVegetation Class.
     * @param location, The Location's Class object.
     * @param field,  The Field's Class object.
     */
    public SpecialVegetation (Field field, Location location)
    {
        super(field, location); 
    }
}
