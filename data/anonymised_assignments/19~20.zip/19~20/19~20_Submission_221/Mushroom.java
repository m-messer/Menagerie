import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a Mushroom.
 * A subclass of specialVegetation, zebra is the animal who feed mushroom and get infection.
 * 
 * @version 2020.02.20 
 */
public class Mushroom extends SpecialVegetation
{
    /**
     * Constructor for objects of class Trees
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mushroom(Field field, Location location)
    {

        // initialise instance variables
        super(field, location);
        sunlevel = 8;
        actorfoodval = MUSHROOM_FOOD_VALUE;
    }

    /**
     * This is what the mushroom does most of the time: 
     * infects only zebras.
     */
    public void act(List<Actor> newMushroom, boolean day, int weather)
    {
        weatherChange(weather);
        TriggerStepChange();

    }

    /**
     * Mushroom needs sun, therefore add sun value; if the weather is sunny.
     * @param weather variable as a integer.
     */
    private void weatherChange(int weather){
        if(weather == 0){
            sunlevel += 3;
        }
    }

    /**
     * Make this mushroom more hungry for sunlight. This could result in the mushroom's death.
     */
    private void TriggerStepChange()
    {
        sunlevel--;
        if(sunlevel <= 0) {
            setRotten();
        }
    }
}
