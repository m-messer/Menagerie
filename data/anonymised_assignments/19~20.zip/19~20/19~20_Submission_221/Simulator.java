import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Animals and Vegetations
 * 
 * @version 2020.02.20 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.

    private static final double GRASS_CREATION_PROBABILITY = 0.1;
    private static final double MUSHROOM_CREATION_PROBABILITY = 0.05;

    //probability of creating a jackall
    private static final double FOX_CREATION_PROBABILITY = 0.01;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.1; 
    private static final double CHEETAH_CREATION_PROBABILITY = 0.01;
    private static final double ALLIGATOR_CREATION_PROBABILITY = 0.01;
    private static final double ZEBRA_CREATION_PROBABILITY = 0.1;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //weather for enivorment related things
    private Weather weather = new Weather();

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rabbit.class, Color.ORANGE);//
        view.setColor(Fox.class, Color.lightGray);//
        view.setColor(Cheetah.class, Color.RED);//
        view.setColor(Zebra.class, Color.MAGENTA);//
        view.setColor(Alligator.class, Color.CYAN);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Eggplant.class, Color.BLUE);
        view.setColor(Tree.class, Color.BLACK);
        view.setColor(Mushroom.class, Color.darkGray);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        /*
         * each day starts at 6am which is assumed to be the sunrise time. day is from 6am to 6pm night 6pm to 6am
         */
        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all animals act.
        // day and weather are passed in act for animals to act
        boolean dayCheck = weather.isDay(step);
        int weatherCheck = weather.getWeather();
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors, dayCheck, weatherCheck);
            if(! actor.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born foxes and rabbits to the main lists.
        actors.addAll(newActors);
        //the weather and step are to be displayed in teh GUI
        view.showStatus(step, field, weatherCheck, weather);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();

        // Show the starting state in the view.Initialises with static weather but 
        //later is overridden

        view.showStatus(step, field,0, weather);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        int gender_populate_int; // this is to generate a random gender
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                gender_populate_int = rand.nextInt(2); // can either be 0 or 1

                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location,gender_populate_int);
                    actors.add(fox);

                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass= new Grass(field, location);
                    actors.add(grass);
                    //System.out.println(location);    
                }
                else if(rand.nextDouble() <= MUSHROOM_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mushroom mushroom= new Mushroom(field, location);
                    //create adjacent eggplant

                    Eggplant eggplant = new Eggplant(field, field.freeAdjacentLocation(location));
                    actors.add(mushroom);
                    actors.add(eggplant);
                    //System.out.println(location);    
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location,gender_populate_int);
                    actors.add(rabbit);
                }
                else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah= new Cheetah(true, field, location,gender_populate_int);
                    actors.add(cheetah);
                }else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra= new Zebra(true, field, location,gender_populate_int);
                    actors.add(zebra);
                }
                else if(rand.nextDouble() <= ALLIGATOR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Alligator alligator = new Alligator(true, field, location,gender_populate_int);
                    actors.add(alligator);
                }
               // else leave the location empty.
               //System.out.println(field.getObjectAt(row, col));
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
        // wake up
        }
    }
}
