import java.util.ArrayList;
/**
 * An abstract superclass Vegetation. Grass and Tree subclasses use this class and methods when needed,
 * in order to avoid code duplication. This class contains common features for its subclasses.
 * 
 * @version 2020.02.20 
 */
public abstract class Vegetation extends Landscape
{
    protected int moisture; //moisture variable
    
    /**
     * Constructor of Vegetation Class.
     * @param location, The Location's Class object.
     * @param field,  The Field's Class object.
     */
    public Vegetation(Field field, Location location)
    {
        // put your code here
        super(field, location);

    }
    
    /**
     * Make this tree more hungry for water. This could result in the tree's death.
     */
    protected void TriggerStepChange()
    {
        moisture--;
        if(moisture <= 0) {
            setRotten();
        }
    }
    
    /**
     * Both tree and grass behave in a similar manner for weather
     */
    protected void weatherChange(int weather){
        if(weather == 1){
            moisture += 10;
        }
    }
}
