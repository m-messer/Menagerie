import java.util.List;

/**
 * landscape doesnt move, it spreads
 * Abstract class Landscape - This class provides vital information for all the subclasses
 * The area covered by the static/dynamic land is declared here
 * if the land is accessible or not.
 * 
 * @version 2020.02.20 
 */
public abstract class Landscape extends Actor
{
    // instance variables - replace the example below with your own
    private boolean islandscapealive;
    private boolean rotten =false;

    /** 
     * Create a new Landscape at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Landscape(Field field, Location location)
    {
        super(field, location);
        islandscapealive = true;
    }
    
    /**
     * Check if it is rotten.
     * @return rotten.
     */
    protected boolean isRotten(){
        return rotten;
    }    

    /**
     * The plant is now rotten and can be removed from field.
     */
    public void setRotten(){
        islandscapealive = false;
        rotten = true;
        if(getLocation() != null) {
            getField().clear(getLocation());
            clearFromField();
        }
    }
}
