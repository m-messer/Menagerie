import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a fox.
 * Foxes age, move,have gender, eat rabbits,zebra,grass,muhsroom and eggplant, and die.
 * 
 * @version 2020.02.20 
 */
public class Fox extends Animal
{
    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a fox can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    private int infectionLevel = 0;

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * Foxes competes with cheetahs for the food sources.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the animal
     */
    public Fox(boolean randomAge, Field field, Location location, int gender)
    {
        super(field, location, gender);
        //define age randomly
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
        foodLevel = RABBIT_FOOD_VALUE;
        //poplating the list of what this particlar animal eats
        animalFood.add(Rabbit.class);
        animalFood.add(Zebra.class);
        animalFood.add(Grass.class);
        animalFood.add(Mushroom.class);
        animalFood.add(Eggplant.class);
        actorfoodval = FOX_FOOD_VALUE;

    }
    
    /**
     * This is what the fox does most of the time: it hunts for
     * acts when he is alive, it is day and weather is not cloudy
     * gives birth, eats specific things and moves
     * dies when age is reached or overcrowded or hungry
     * 
     * @param newFoxes The list of the foxes.
     * @param day The daytime fox gives birth.
     * @param weather The weather conditions to breed.
     */
    public void act(List<Actor> newFoxes, boolean day, int weather)
    {
        weatherChange(weather);
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive() && day && (weather != (2))) {
            giveBirth(newFoxes, BREEDING_PROBABILITY, MAX_LITTER_SIZE, BREEDING_AGE);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This method is for weather related changes.
     */
    private void weatherChange(int weather){
        if(weather == 3){
            infectionLevel = 0;
        }
    }

    /**
     * over here this is called from field class
     * the Parameter is the Animal we are comparing this animal with
     * we check if the animal in the adjacent block is of the same class and is an opp gender
     * by overriding the equals method.
     * 
     * @param 'o' The Object clas's instance.
     */
    public boolean genderandequals(Object o){
        if(o == this){ //check if we are checking with itself
            return false;
        }

        if(!(o instanceof Fox)){//if it is not an instance of fox then return false, we cant check true coz
            //we are avoiding using else statements here therefore ! instance of fox
            return false;
        }

        Fox f = (Fox) o; // typecast to fox
        if(this.getGender() == f.getGender()){ // if the gender is the same then they cant make babies
            return false;
        }
        return true;// that means that there is an opposite gender 

    }
}
