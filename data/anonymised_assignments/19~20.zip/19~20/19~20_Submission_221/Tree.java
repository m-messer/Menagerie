import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a Tree.
 * Unlike other vegetations trees are stable and don't die.
 * 
 * @version 2020.02.20 
 */
public class Tree extends Vegetation
{

    /**
     * Constructor for objects of class Trees
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tree(Field field, Location location)
    {
        // initialise instance variables
        super(field, location);
        moisture = 8;
        actorfoodval = TREE_FOOD_VALUE;
    }
    
    /**
     * This is the trees action weather related changes take place here along with what happens at each step.
     */
    public void act(List<Actor> newTree, boolean day, int weather)
    {
        weatherChange(weather);//weather affects trees differently, it only needs moisture tolive
        TriggerStepChange(); //
    }

}
