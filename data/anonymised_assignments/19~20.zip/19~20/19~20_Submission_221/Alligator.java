import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Alligator.
 * Alligators have gender, age, move, eat foxes,cheetahs and trees, and die.
 * 
 * @version 2020.02.20  
 */
public class Alligator extends Animal
{
    // Characteristics shared by all alligators (class variables).

    // The age at which a alligator can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a alligator can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a alligator breeding.
    private static final double BREEDING_PROBABILITY = 1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * This is what the alligator does most of the time: it hunts for
     * acts when he is alive, it is day and weather is not cloudy
     * gives birth, eats specific things and moves
     * dies when age is reached or overcrowded or hungry
     * 
     * @param randomAge If true, the alligator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param gender The gender of the animal
     */
    public Alligator(boolean randomAge, Field field, Location location, int gender)
    {
        super(field, location, gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CHEETAH_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = CHEETAH_FOOD_VALUE;
        }

        animalFood.add(Fox.class);
        animalFood.add(Tree.class);
        animalFood.add(Cheetah.class);
        actorfoodval= ALLIGATOR_FOOD_VALUE;
    }

    /**
     * This is what the alligator does most of the time: it hunts for
     * fox,cheetah,tree. In the process, it might breed, die of hunger,
     * or die of old age.
     * 
     * @param day The daytime alligator gives birth.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Actor> newAlligators, boolean day, int weather)
    {
        incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive() && !day) {
            giveBirth(newAlligators, BREEDING_PROBABILITY, MAX_LITTER_SIZE, BREEDING_AGE);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * over here this is called from field class
     * the Parameter is the Animal we are comparing this animal with
     * we check if the animal in the adjacent block is of the same class and is an opp gender
     * by overriding the equals method.
     * 
     * @param 'o' The Object clas's instance.
     */
    public boolean genderandequals(Object o){
        if(o == this){ //check if we are checking with itself
            return false;
        }

        if(!(o instanceof Alligator)){//if it is not an instance of fox then return false, we cant check true coz
            //we need the below thigs
            return false;
        }

        Alligator a = (Alligator) o; // typecast to fox
        if(this.getGender() == a.getGender()){ // if the gender is the same then they cant make babies
            return false;
        }
        return true;
    }
}
