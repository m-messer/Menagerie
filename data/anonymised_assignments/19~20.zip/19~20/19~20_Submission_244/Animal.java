import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.22
 */
public abstract class Animal extends LiveSpecies
{
    private int foodLevel;
    private Disease disease;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge False if the animal's age should start at 0, true if the animal should be created with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param foodLevel The food level that the animal should be created with.
     */
    public Animal(boolean randomAge, Field field, Location location, int foodLevel)
    {
        super(randomAge, field, location);
        this.foodLevel = foodLevel;
        this.disease = null;
    }
        
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLiveSpecies A list with newly born live species.
     */
    protected abstract void giveBirth(List<LiveSpecies> newliveSpecies);
    
    /**
     * Look for food adjacent to the current location.
     * Only the first food found is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected abstract Location findFood();
    
    /**
     * Return the maximum age of the animal.
     * @return The maximum age of the animal.
     */
    protected abstract int getMaxAge();
    
    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Increment the animal's food level.
     * @param foodLevel The amount of food that should be added to the animal's food level.
     */
    protected void incrementFoodLevel(int foodLevel)
    {
        this.foodLevel += foodLevel;
    }
    
    /**
     * Make this LiveSpecies act - that is: make it do whatever it wants/needs to do.
     * Specific actions are defined in subclasses.
     * @param newAnimals A list to receive newly born animals.
     */
    protected void act(List<LiveSpecies> newAnimals)
    {
        incrementAge();
        incrementHunger();
        
        if (isAlive()) {
            giveBirth(newAnimals);            
            Location newLocation = findFood();
            if (newLocation == null) { 
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            if (newLocation != null) {
                setLocation(newLocation);
            }
            else {
                setDead();
                return;
            }
            
            if (disease == null) {
                if(Randomizer.getRandom().nextDouble() < disease.DISEASE_CREATION) {
                    disease = new Disease();
                }
            } 
            else {
                liveWithDisease();
            }
        }
    }
    
    /**
     * Simulate the effects of the animal's disease.
     */
    protected void liveWithDisease()
    {
        disease.live();
        
        if (disease.getLifeTime() <= 0) {
            disease = null;
            return;
        }
        
        if (Randomizer.getRandom().nextDouble() < disease.getKillChance()) {
            setDead();
            return;
        }
        
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = getField().getObjectAt(where);
            if (animal instanceof Animal) {
                if (Randomizer.getRandom().nextDouble() < disease.getSpreadChance()) {
                    ((Animal) animal).setDisease(disease.spreadDisease());
                }
            }
        }
    }
    
    /**
     * Set the disease of the animal.
     * @param disease The disease of the animal.
     */
    public void setDisease(Disease disease)
    {
        this.disease = disease;
    }
    
    
    /**
     * Determine whether the animal has a disease or not.
     * @return True if the animal has a disease, false if it does not.
     */
    public boolean isDiseased()
    {
        return disease != null;
    }
}
