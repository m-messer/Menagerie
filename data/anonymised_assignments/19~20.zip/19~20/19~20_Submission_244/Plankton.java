import java.util.List;

/**
 * The class creates an instance of plankton.
 * This is a subclass of the superclass Plant, which
 * in turn is a subclass of Live Species.
 * 
 * Plankton grow better in favourable weather conditions and will only grow during the daytime.
 *
 * @version 02.20.2020
 */
public class Plankton extends Plant
{
    //The liklehood that plankton will spread to neighbouring cells on a given turn.
    private static final double GROWING_PROBABILITY = 0.8;
    
    //The maximum age that a plankton can live to.
    private static final int MAX_AGE = 60;

    /**
     * Create a plankton. A plankton can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the plankton will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plankton(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Returns the maximum age that the plankton can live to.
     * @return The maximum age that the plankton can live to.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Create new plankton objects in neighboring cells if the conditions are right.
     * Plankton will only reproduce under favourable weather conditions and during the daytime.
     * @param newLiveSpecies A list with newly born live species.
     */
    protected void reproduce(List<LiveSpecies> newLiveSpecies)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());

        for(int b = 1; b < GROWING_PROBABILITY*Weather.getSunIndex() && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plankton newPlankton = new Plankton(false, field, loc);
            newLiveSpecies.add(newPlankton);
        }
    }

    /**
     * Return the probability that a plankton should be born in a given game square.
     * @return The creation probability of a plankton.
     */
    public static double getCreationProbability()
    {
        return GROWING_PROBABILITY;
    }
}
