import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A model of a seal.
 * Seals age, move, eat penguins, and die.
 * Seals eat penguins and aren't prey to any animal.
 *
 * @version 02.20.2020
 */
public class Seal extends Animal
{
    //The age at which seals can start having offspring.
    private static final int BREEDING_AGE = 5;
    
    //The maximum age that a seals can live to.
    private static final int MAX_AGE = 30;
    
    //The probability that a seals will produce offspring.
    private static final double BREEDING_PROBABILITY = 0.2;
    
    //The maximum amount of offspring that a seal can have in one birth.
    private static final int MAX_LITTER_SIZE = 2;
    
    //The amount of sustanance that eating one penguin will provide to a seal.
    private static final int PENGUIN_FOOD_VALUE = 4;
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a seal. A seal can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the seal will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seal(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, PENGUIN_FOOD_VALUE*3);
    }
    
    /**
     * Returns the maximum age that the seal can live to.
     * @return The maximum age that the seal Whale can live to.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Look for penguins adjacent to the current location.
     * Only the first live penguin is eaten.
     * Seals eat more effectivley in favourable weather/light conditions.
     * This is to simulate it being harder for seals to find their prey in poor light.
     * 
     * @return where Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Penguin) {
                Penguin penguin = (Penguin) animal;
                if(penguin.isAlive()) { 
                    penguin.setDead();
                    if(Weather.getSunIndex() > 4) {
                        incrementFoodLevel(PENGUIN_FOOD_VALUE);
                    }
                    else {
                        incrementFoodLevel((int) (0.5*PENGUIN_FOOD_VALUE));
                    }
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this seal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLiveSpecies A list to return newly born live species.
     */
    protected void giveBirth(List<LiveSpecies> newLiveSpecies)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seal young = new Seal(false, field, loc);
            newLiveSpecies.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return int - The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        
        return births;
    }

    /**
     * Return the probability that a seal should be born in a given game square.
     * @return The creation probability of a seal.
     */
    public static double getCreationProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A seal can breed if it has reached the breeding age.
     * @return True if the seal has reached the breeding age, false if it has not.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
