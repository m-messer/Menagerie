import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a whale.
 * Whales age, move, eat krill, and die.
 * Whales have no predators.
 *
 * @version 02.20.2020
 */
public class Whale extends Animal
{
    //The age at which whales can start having offspring.
    private static final int BREEDING_AGE = 15;
    
    //The maximum age that a whale can live to.
    private static final int MAX_AGE = 50;
    
    //The probability that a whale will produce offspring.
    private static final double BREEDING_PROBABILITY = 0.2;
    
    //The maximum amount of offspring that a whale can have in one birth.
    private static final int MAX_LITTER_SIZE = 2;
    
    //The amount of sustanance that eating one krill will provide to a whale.
    private static final int KRILL_FOOD_VALUE = 4;
    
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a whale. A whale can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the whale will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Whale(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, KRILL_FOOD_VALUE*5);
    }

    /**
     * Returns the maximum age that the whale can live to.
     * @return The maximum age that the whale can live to.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Look for plankton adjacent to the current location.
     * Only the first live plankton is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Krill) {
                Krill krill = (Krill) animal;
                if(krill.isAlive()) { 
                    krill.setDead();
                    incrementFoodLevel(KRILL_FOOD_VALUE);
                    return where;
                }
            }
        }
        
        return null;
    }

    /**
     * Check whether or not this whale is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLiveSpecies A list to return newly born live species.
     */
    protected void giveBirth(List<LiveSpecies> newLiveSpecies)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Whale young = new Whale(false, field, loc);
            newLiveSpecies.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Return the probability that a whale should be born in a given game square.
     * @return The creation probability of a whale.
     */
    public static double getCreationProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A whale can breed if it has reached the breeding age.
     * @return True if the whale has reached the breeding age, false if it has not.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
