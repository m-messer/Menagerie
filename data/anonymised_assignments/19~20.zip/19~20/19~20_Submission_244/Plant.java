import java.util.List;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2020.02.22
 */
public abstract class Plant extends LiveSpecies
{
    
    /**
     * Create a new plant at location in field.
     * 
     * @param randomAge False if the plant's age should start at 0, true if the plant should be created with a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * This is what the plant does most of the time. 
     * Sometimes it grow and expand to adjacent cells or die of old age.
     * 
     * @param newPlants A list to return newly born plants.
     */
    protected void act(List<LiveSpecies> newPlants)
    {
        incrementAge();
        if(isAlive() && Weather.isDayTime()) {
            reproduce(newPlants);    
        }
    }
    
    /**
     * Abstract method for the implementation of a plant's reproduction and
     * for further population of populate the field.
     * Plants only reproduce during the day time. 
     */
    protected abstract void reproduce(List<LiveSpecies> newPlant);
}
