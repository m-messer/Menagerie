import java.util.Random;

/**
 * The weather class keeps track of the weather conditions of the
 * arctic simulator.
 *
 * @version 02.20.2020
 */
public class Weather
{
    private static int sunIndex = 6;
    private static int seaTemp = 12;
    private static int time = 0;
    private static boolean roughWaters = false;
    
    /**
     * Simulate random changes in the weather.
     * The sun index will either remain the same or fluctuate by 1 up or down as does the sea temperature.
     * It will be randomly determined whether the waters are rough or not.
     */
    public static void changeWeather()
    {
        Random random = Randomizer.getRandom();
        
        sunIndex += random.nextInt(3) - 1 ;
        if(sunIndex < 0) {
            sunIndex = 0;
        }
        if(sunIndex > 25) {
            sunIndex = 25;
        }
        
        seaTemp += random.nextInt(3) - 1 ;
        if(seaTemp < 0) {
            seaTemp = 0;
        }
        if(seaTemp > 25) {
            seaTemp = 25;
        }

        roughWaters = random.nextBoolean();
    }
    
    /**
     * Return the sun index.
     * @return The sun index.
     */
    public static int getSunIndex()
    {
       return sunIndex; 
    }
    
    /**
     * Increment the time by one.
     */
    public static void incrementTime()
    {
        time += 1;
    }
    
    /**
     * Return true if it is daytime, false if it is not.
     * @return True if it is daytime, false if it is not.
     */
    public static boolean isDayTime()
    {
        return time%24 < 16 ;
    }
   
    /**
     * Return true if there are rough waters, false if there are not.
     * @return True if there are rough waters, false if there are not.
     */
    public static boolean roughWaters()
    {
       return roughWaters; 
    }
    
    /**
     * Return the sea temperature.
     * @return The sea temperature.
     */
    public static int getSeaTemp()
    {
       return seaTemp; 
    }
}
