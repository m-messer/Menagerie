
/**
 * The disease class creates new diseases and allows for spreading
 * of these different diseases.
 *
 * @version 02.20.2020
 */
public class Disease
{
    private double spreadChance ;
    private double killChance ;
    private int lifeTime ;
    private int originalLifeTime ;
    
    //The liklehood that a disease is created for a animal every step.
    public static final double DISEASE_CREATION = 0.002 ;
    
    
    /**
     * Create a new disease with random characteristics.
     * Diseases made with this constructor are assigned a random value determining how 
     * likely the disease is to spread to neighbouring animals, a random value determining 
     * how likely the disease is to kill its host, and a random lifetime of up to 20 years.
     */
    public Disease()
    {
        spreadChance = Randomizer.getRandom().nextDouble();
        killChance = Randomizer.getRandom().nextDouble();
        originalLifeTime = Randomizer.getRandom().nextInt(20);
        lifeTime = originalLifeTime ;
    }
    
    /**
     * Create a new disease with specificied characteristics.
     * @param spreadChance A value determining how likely the disease is to spread to neighbouring animals.
     * @param killChance A value determining how likely the disease is to kill its host.
     * @param originalLifeTime The lifetime of the disease in its host.
     */
    public Disease(double spreadChance, double killChance, int originalLifeTime)
    {
        this.spreadChance = spreadChance;
        this.killChance = killChance;
        this.originalLifeTime = originalLifeTime;
        lifeTime = originalLifeTime;
    }
    
    /**
     * Create a new instance of a disease to give to neighbouring animals.
     * @return A new instance of disease with the same spread chance, kill chance, and a full lifetime.
     */
    public Disease spreadDisease () 
    {
        return new Disease(spreadChance, killChance, originalLifeTime);
    }
    
    /**
     * Exist for one game cycle. For a disease, this just means decreasing the lifetime remaining.
     */
    public void live() 
    {
        lifeTime--;
    }
    
    /**
     * Return the chance that the disease will to spread to neighbouring animals.
     * @return The chance that the disease will to spread to neighbouring animals.
     */
    public double getSpreadChance() 
    {
        return spreadChance;
    }
    
    /**
     * Return the chance that the disease will kill its host.
     * @return The chance that the disease will kill its host.
     */
    public double getKillChance() 
    {
        return killChance;
    }
    
    /**
     * Return the number of cycles left for the disease to live.
     * @return The lifetime of the disease which is the number of cycles left for the disease to live.
     */
    public int getLifeTime() 
    {
        return lifeTime;
    }
    
    /**
     * Return the original lifetime of the disease. 
     * This is the amount of cycles that the disease had to live at the start of its live.
     * @return The original lifetime of the disease.
     */
    public int getOriginalLifeTime() 
    {
        return originalLifeTime;
    }
}
