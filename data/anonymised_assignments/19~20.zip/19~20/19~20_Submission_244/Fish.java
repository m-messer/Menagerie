import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a fish.
 * Fish age, move, breed, eat plankton, and die.
 * Fish are not prey.
 *
 * @version 02.20.2020
 */
public class Fish extends Animal
{
    //The age at which fish can start having offspring.
    private static final int BREEDING_AGE = 5;
    
    //The maximum age that a fish can live to.
    private static final int MAX_AGE = 30;
    
    //The probability that a fish will produce offspring.
    private static final double BREEDING_PROBABILITY = 0.3;
    
    //The maximum amount of offspring that a fish can have in one birth.
    private static final int MAX_LITTER_SIZE = 2;
    
    //The amount of sustanance that eating one plankton will provide to a fish.
    private static final int PLANKTON_FOOD_VALUE = 3;
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a fish. A fish can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the fish will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fish(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, PLANKTON_FOOD_VALUE*2);
    }
    
    /**
     * Returns the maximum age that the fish can live to.
     * @return The maximum age that the fish can live to.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Look for plankton adjacent to the current location.
     * Only the first plankton is eaten.
     * @return where - Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plankton) {
                Plankton plankton = (Plankton) animal;
                if(plankton.isAlive()) { 
                    plankton.setDead();
                    incrementFoodLevel(PLANKTON_FOOD_VALUE);
                    return where;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Check whether or not this fish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLiveSpecies A list to return newly born live species.
     */
    protected void giveBirth(List<LiveSpecies> newLiveSpecies)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fish young = new Fish(false, field, loc);
            newLiveSpecies.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        
        return births;
    }
    
    /**
     * Return the probability that a fish should be born in a given game square.
     * @return The creation probability of a fish.
     */
    public static double getCreationProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A fish can breed if it has reached the breeding age.
     * @return True if the fish has reached the breeding age, false if it has not.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
