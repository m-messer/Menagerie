import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A pretador-prey simulator, based on a rectangular field.
 * This field simulates animal and plant populations in the arctic.
 *
 * @version 02.20.2020
 */
public class Simulator
{
    private static final int DEFAULT_WIDTH = 120;
    private static final int DEFAULT_DEPTH = 80;
    
    private List<LiveSpecies> liveSpecies;
    private Field field;
    private int step;
    private SimulatorView view;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        liveSpecies = new ArrayList<>();
        field = new Field(depth, width);

        view = new SimulatorView(depth, width);
        view.setColor(KillerWhale.class, Color.ORANGE);
        view.setColor(Krill.class, Color.PINK);
        view.setColor(Seal.class, Color.MAGENTA);
        view.setColor(Penguin.class, Color.BLACK);
        view.setColor(Fish.class, Color.YELLOW);
        view.setColor(Whale.class, Color.BLUE);
        view.setColor(Plankton.class, Color.GREEN);
        
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * species.
     */
    public void simulateOneStep()
    {
        step++;

        List<LiveSpecies> newLiveSpecies = new ArrayList<>();        
        Weather.changeWeather();
        Weather.incrementTime();
        
        for(Iterator<LiveSpecies> it = liveSpecies.iterator(); it.hasNext(); ) {
            LiveSpecies liveSpecies = it.next();
            liveSpecies.act(newLiveSpecies);
            if(! liveSpecies.isAlive()) {
                it.remove();
            }
        }
        
        liveSpecies.addAll(newLiveSpecies);
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        liveSpecies.clear();
        populate();
        
        Randomizer.reset();
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= KillerWhale.getCreationProbability()) {
                    Location location = new Location(row, col);
                    KillerWhale killerWhale = new KillerWhale(true, field, location);
                    liveSpecies.add(killerWhale);
                }
                else if(rand.nextDouble() <= Fish.getCreationProbability()) {
                    Location location = new Location(row, col);
                    Fish fish = new Fish(true, field, location);
                    liveSpecies.add(fish);
                }
                else if(rand.nextDouble() <= Seal.getCreationProbability()) {
                    Location location = new Location(row, col);
                    Seal seal = new Seal(true, field, location);
                    liveSpecies.add(seal);
                }
                else if(rand.nextDouble() <= Whale.getCreationProbability()) {
                    Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    liveSpecies.add(whale);
                }
                else if(rand.nextDouble() <= Krill.getCreationProbability()) {
                    Location location = new Location(row, col);
                    Krill krill = new Krill(true, field, location);
                    liveSpecies.add(krill);
                }
                else if(rand.nextDouble() <= Penguin.getCreationProbability()) {
                    Location location = new Location(row, col);
                    Penguin penguin = new Penguin(true, field, location);
                    liveSpecies.add(penguin);
                }
                else if(rand.nextDouble() <= Plankton.getCreationProbability()) {
                    Location location = new Location(row, col);
                    Plankton plankton = new Plankton(true, field, location);
                    liveSpecies.add(plankton);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
