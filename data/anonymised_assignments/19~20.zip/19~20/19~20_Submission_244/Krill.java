import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A  model of krill.
 * Krill age, move, eat plankton, breed, and die.
 * Krill are prey to penguins and whales.
 *
 * @version 02.20.2020
 */
public class Krill extends Animal
{
    //The age at which krill can start having offspring.
    private static final int BREEDING_AGE = 6;
    
    //The maximum age that a krill can live to.
    private static final int MAX_AGE = 50;
    
    //The probability that a krill will produce offspring.
    private static final double BREEDING_PROBABILITY = 0.4;
    
    //The maximum amount of offspring that a krill can have in one birth.
    private static final int MAX_LITTER_SIZE = 6;
    
    //The amount of sustanance that eating one plankton will provide to a krill.
    private static final int PLANKTON_FOOD_VALUE = 10;
    
    private static final Random rand = Randomizer.getRandom();
     
    /**
     * Create a new krill. A krill may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the krill will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Krill(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, PLANKTON_FOOD_VALUE);
    }
    
    /**
     * Returns the maximum age that the krill can live to.
     * @return The maximum age that the krill can live to.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Look for plankton adjacent to the current location.
     * Only the first live plankton is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object liveSpecies = field.getObjectAt(where);
            if(liveSpecies instanceof Plankton) {
                Plankton plankton = (Plankton) liveSpecies;
                if(plankton.isAlive()) { 
                    plankton.setDead();
                    incrementFoodLevel(PLANKTON_FOOD_VALUE);
                    return where;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Check whether or not this krill is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLiveSpecies A list to return newly born live species.
     */
    protected void giveBirth(List<LiveSpecies> newLiveSpecies)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Krill young = new Krill(false, field, loc);
            newLiveSpecies.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Return the probability that a krill should be born in a given game square.
     * @return The creation probability of a krill.
     */
    public static double getCreationProbability()
    {
        return BREEDING_PROBABILITY;
    }
        
    /**
     * Krill can breed if it has reached the breeding age.
     * @return True if the krill has reached the breeding age, false if it has not.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
}
