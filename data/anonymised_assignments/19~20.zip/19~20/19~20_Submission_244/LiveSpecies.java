import java.util.List;

/**
 * Abstract class LiveSpecies - a class representing shared characteristics of
 * live species.
 *
 * @version 02.20.2020
 */
public abstract class LiveSpecies
{
    private boolean alive;
    private Field field;
    private Location location;
    private int age;
    
    /**
     * Construct a LiveSpecies object.
     * @param randomAge Specifies whether the LiveSpecies should be constructed with a randomly assigned age or whether it's age should start at 0.
     * @param field The field where the LiveSpecies will exist.
     * @param location The location in the field where the LiveSpecies will be created.
     */
    public LiveSpecies (boolean randomAge, Field field, Location location)
    {
        if(randomAge) {
            age = Randomizer.getRandom().nextInt(getMaxAge());
        }
        else {
            age = 0;
        }
        
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Check whether the LiveSpecies is alive or not.
     * @return True if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Get the current age of the LiveSpecies.
     * @return The age of the LiveSpecies.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * Make this LiveSpecies act - that is: make it do whatever it wants/needs to do.
     * Specific actions are defined in subclasses.
     * @param liveSpecies A list to receive newly born live species.
     */
    protected abstract void act(List<LiveSpecies> liveSpecies);
 
    /**
     * Indicate that the live species is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the LiveSpecies' location.
     * @return The LiveSpecies' location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the LiveSpecies at the new location in the given field.
     * @param newLocation The LiveSpecies' new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Increase the age. This could result in the LiveSpecies' death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Return the maximum age that can be reached by the LiveSpecies before it dies.
     * @return The LiveSpecies' maximum age.
     */
    protected abstract int getMaxAge();
    
    /**
     * Return the LiveSpecies' field.
     * @return The LiveSpecies' field.
     */
    protected Field getField()
    {
        return field;
    }
}
