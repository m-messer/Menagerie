import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a penguin.
 * Penguins age, move, breed, and die.
 * Penguins are predators and prey.
 * They eat krill and are prey for killer whales and seal.
 * 
 * Penguins can only breed during the daytime and only with penguins of the opposite sex.
 *
 * @version 02.20.2020
 */
public class Penguin extends Animal
{
    //The age at which penguins can start having offspring.
    private static final int BREEDING_AGE = 2;
    
    //The maximum age that a penguin can live to.
    private static final int MAX_AGE = 60;
    
    //The probability that a penguin will produce offspring.
    private static final double BREEDING_PROBABILITY = 0.5;
    
    //The maximum amount of offspring that a penguin can have in one birth.
    private static final int MAX_LITTER_SIZE = 8;
    
    //The amount of sustanance that eating one krill will provide to a penguin.
    private static final int KRILL_FOOD_VALUE = 6;
    
    private static final Random rand = Randomizer.getRandom();
    private boolean isMale;
    
    /**
     * Create a new penguin. A penguin may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the penguin will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Penguin(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, KRILL_FOOD_VALUE*5);
        isMale = Randomizer.getRandom().nextBoolean();
    }
    
    /**
     * Returns the maximum age that the penguin can live to.
     * @return The maximum age that the penguin can live to.
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Look for krill adjacent to the current location.
     * Only the first live krill is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Krill) {
                Krill krill = (Krill) animal;
                if(krill.isAlive()) { 
                    krill.setDead();
                    incrementFoodLevel(KRILL_FOOD_VALUE);
                    return where;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Check whether or not this penguin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLiveSpecies A list to return newly born live species.
     */
    protected void giveBirth(List<LiveSpecies> newLiveSpecies)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Penguin young = new Penguin(false, field, loc);
            newLiveSpecies.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births, if it can breed.
     * Penguins can only breed during daytime and when in the proximity of another penguin of the opposite sex.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Penguin) {
                Penguin penguin = (Penguin) animal;
                if(penguin.isMale() != this.isMale() && Weather.isDayTime() ) { 
                    if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                        births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                    }
                }
            }
        }
        
        return births;
    }
    
    /**
     * Return the probability that a penguin should be born in a given game square.
     * @return The creation probability of a penguin.
     */
    public static double getCreationProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * A penguin can breed if it has reached the breeding age.
     * @return True if the penguin has reached the breeding age, false if it has not.
     */
    private boolean canBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Return wether this parcticular penguin is male.
     * @return True if this particular penguin is male, false if it is not.
     */
    public boolean isMale()
    {
        return isMale;
    }
}
