
import java.util.ArrayList;
/**
 * this class modifies the season and how it changes
 *
 * @version 2020/2/22
 */
public class season
{
    private int index;
    private String currentseason;
    private ArrayList<String> season = new ArrayList<>();
    /**
     * Construct a season arraylist
     * 
     */
    public season()
    {
        season = new ArrayList<>();
       
    }
    
    /**
     * by entering a special to change the season
     * 
     */
    public void changeseason(int no)
    {
        index = no;
    }
    
    /**
     * the season will change in order 
     * spring summer autumn and winter
     * 
     */
    public String seasonchange()
    {
        index = index + 1;
        if(index > 3){
            index = 0;
        }
        return season.get(index);
    }
    
    /**
     * show the current season
     * 
     */
    public String getSeason()
    {
        return season.get(index);
    }
    
    /**
     * add a new season by entering a string
     * 
     */
    public void add(String add)
    {
        season.add(add);
    }
    
    /**
     * return the size of the arraylist
     * 
     */
    public int size()
    {
        return season.size();
    }
}
