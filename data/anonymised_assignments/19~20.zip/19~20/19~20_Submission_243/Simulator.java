import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple Monster Hunter World simulator, based on a rectangular field
 * containing THIEFDRAGONs Bears Anjanaths Rathian and HUNTERs.
 *
 * @version 2020/2/22
 */
public class Simulator 
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a HUNTER will be created in any given grid position.
    private static final double HUNTER_CREATION_PROBABILITY = 0.05;
    // The probability that a THIEFDRAGON will be created in any given grid position.
    private static final double THIEFDRAGON_CREATION_PROBABILITY = 0.09;
    // The probability that a RATHIAN will be created in any given grid position.
    private static final double RATHIAN_CREATION_PROBABILITY = 0.06;
    // The probability that a BEAR will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.07;
    // The probability that a ANJANATH will be created in any given grid position.
    private static final double ANJANATH_CREATION_PROBABILITY = 0.05;
    // The probability that a PLANTS will be created in any given grid position.
    private static final double PLANTS_CREATION_PROBABILITY = 0.06;
    private static Random rand = Randomizer.getRandom();
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //A counter which counts the days that have passed
    private int days;
    //A string which contains the weather
    private String condition;
    //the arraylist of weather and season
    private ArrayList<String> weather = new ArrayList<>();
    private ArrayList<String> season = new ArrayList<>();
    private weather weathe;
    //a counter which counts the change of days
    private int changeofdays;
    private season seaso;
    private String seasonnow;
    //two indexes for two arraylist
    int index1 = 0;
    int index2 = 0;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        //construct the original arraylists
        animals = new ArrayList<>();
        field = new Field(depth, width);
        season = new ArrayList<>();
        weather = new ArrayList<>();
        seasonnow = "Spring";
        weather.add("sunny");
        weather.add("rainy");
        season.add("Spring");
        season.add("Summer");
        season.add("Autumn");
        season.add("Winter");
        condition = "sunny";
        

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(ThiefDragon.class, Color.ORANGE);
        view.setColor(Hunter.class, Color.BLUE);
        view.setColor(Rathian.class, Color.PINK);
        view.setColor(Bear.class, Color.BLACK);
        view.setColor(Anjanath.class, Color.GREEN);
        view.setColor(Plants.class, Color.RED);
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * THIEFDRAGONs Bears Anjanaths Rathian and HUNTERs.
     */
    public void simulateOneStep()
    {   
        int definer = 0;
        step++;
        days = (step%2+step)/2;
        definer = step%2;
        changeWeather();
        changeofdays++; 
        if(changeofdays == 20){
     
            changeofdays = 0;
            seasonnow = seasonchange();
        }
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>(); 
        // Let all THIEFDRAGONs act.
        if(definer == 1){
            for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
                Animal animal = it.next();
                animal.act(newAnimals);
                if(! animal.isAlive()) {
                    it.remove();
                }
            }
        }       
        // Add the newly born HUNTERes and THIEFDRAGONs to the main lists.
        animals.addAll(newAnimals);
        //show the status in the view
        view.showStatus(days ,step, field,condition, seasonnow);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        days = 0;
        // Show the starting state in the view.
        view.showStatus(days,step,  field, condition, seasonnow);
    }
    
    /**
     * Randomly populate the field with THIEFDRAGONs Bears Anjanaths Rathian and HUNTERs.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HUNTER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hunter HUNTER = new Hunter(randomboolean(),true, field, location);
                    animals.add(HUNTER);
                }
                else if(rand.nextDouble() <= THIEFDRAGON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    ThiefDragon THIEFDRAGON = new ThiefDragon(randomboolean(),true, field, location);
                    animals.add(THIEFDRAGON);
                }
                else if(rand.nextDouble() <= RATHIAN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rathian RATHIAN = new Rathian(randomboolean(),true, field, location);
                    animals.add(RATHIAN);
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bear BEAR = new Bear(randomboolean(),true, field, location);
                    animals.add(BEAR);
                }
                else if(rand.nextDouble() <= ANJANATH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Anjanath ANJANATH = new Anjanath(randomboolean(),true, field, location);
                    animals.add(ANJANATH);
                }
                else if(rand.nextDouble() <= PLANTS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plants PLANTS = new Plants(true, field, location);
                    animals.add(PLANTS);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    private boolean randomboolean()
    {
        Random randomno = new Random();
        boolean value = randomno.nextBoolean();
        return value;
    }
    
    /**
     * every time call this method 
     * the weather will change by the random index
     */
    public void changeWeather()
    {
        Random rand = Randomizer.getRandom();
        index2 = rand.nextInt(weather.size());
        condition = weather.get(index2);
         
    }  
    
    /**
     * when this method is used
     * the current weather condition will be returned
     */
    public String showWeather()
    {
        return condition;
    }
    
    /**
     * this method will change the index directly
     * and the season will change as well in order
     */
    public String seasonchange()
    {
        index1 = index1 + 1;
        if(index1 > 3){
            index1 = 0;
        }
        return season.get(index1);
    } 
}
