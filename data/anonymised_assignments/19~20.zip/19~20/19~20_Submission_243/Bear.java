import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a bear.
 * bear age, move, eat other animals, and die.
 *
 * @version 2020/2/22
 */
public class Bear extends Animal
{
    // Characteristics shared by all bears (class variables).

    // The age at which a bear can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a bear can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a bear breeding.
    private static final double BREEDING_PROBABILITY = 0.10;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4 ;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    private static final int THIEFDRAGON_FOOD_VALUE = 2;
    private static final int PLANTS_FOOD_VALUE = 2;
    // Individual characteristics (instance fields).
    
    // The bear's age.
    private int age;
    private int foodLevel;
    private boolean male;
    /**
     * Create a new bear. A bear may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the bear will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bear(boolean male,boolean randomAge, Field field, Location location)
    {
        super(field, location);
        male = randomboolean();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = 7;
        }
        else {
            age = 0;
            foodLevel = 7;
        }
    }
    
    /**
     * This is what the bear does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Animal> newHunters)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHunters);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the bear's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this bear more hungry. This could result in the bear's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for bears adjacent to the current location.
     * Only the first live bear is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plants) {
                Plants plants = (Plants) animal;
                if(plants.isAlive()) { 
                    plants.setDead();
                    foodLevel = PLANTS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Animal> newBear)
    {
        // New bears are born into adjacent locations.
        // Get a list of adjacent free locations.
        
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
         List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bear){
                Bear bear = (Bear) animal;
                if(bear.male != male){
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Bear young = new Bear(randomboolean(),false, field, loc);
                        newBear.add(young);
                    }
                }
            }   
    
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A bear can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {       
        if(age >= BREEDING_AGE){
            return true;
        }
        else {
            return false;
        }
    }
}
