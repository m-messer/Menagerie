import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Rathian.
 * rathian age, move, eat other animals, and die.
 *
 * @version 2020/2/22
 */
public class Rathian extends Animal
{
    // Characteristics shared by all rathians (class variables).
    // The age at which a rathian can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a rathian can live.
    private static final int MAX_AGE = 135;
    // The likelihood of a rathian breeding.
    private static final double BREEDING_PROBABILITY = 0.10;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2 ;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    private static final int THIEFDRAGON_FOOD_VALUE = 2;
    private static final int BEAR_FOOD_VALUE = 4;
    private static final int ANJANATH_FOOD_VALUE = 7;
    // Individual characteristics (instance fields).
    private boolean male;
    // The rathian's age.
    private int age;
    private int foodLevel;
    /**
     * Create a new rathian. A rathian may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rathian will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rathian(boolean male,boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel =7;
        }
        else {
            age = 0;
            foodLevel = 7;
        }
    }
    
    /**
     * This is what the rathian does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newrathians A list to return newly born rathians.
     */
    public void act(List<Animal> newRathians)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newRathians);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the rathian's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this rathian more hungry. This could result in the rathian's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for rathians adjacent to the current location.
     * Only the first live rathian is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof ThiefDragon) {
                ThiefDragon thiefdragon = (ThiefDragon) animal;
                if(thiefdragon.isAlive()) { 
                    thiefdragon.setDead();
                    foodLevel = THIEFDRAGON_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Bear) {
                Bear bear = (Bear) animal;
                if(bear.isAlive()) { 
                    bear.setDead();
                    foodLevel = BEAR_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Anjanath) {
                Anjanath anjanath = (Anjanath) animal;
                if(anjanath.isAlive()) { 
                    anjanath.setDead();
                    foodLevel = ANJANATH_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this rathian is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Animal> newRathian)
    {
        // New rathians are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rathian){
                Rathian rathian = (Rathian) animal;
                if(rathian.male != male){
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Rathian young = new Rathian(randomboolean(),false, field, loc);
                        newRathian.add(young);
                    }
                }
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A rathian can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE){
            return true;
        }
        else {
            return false;
        }
    }
}
