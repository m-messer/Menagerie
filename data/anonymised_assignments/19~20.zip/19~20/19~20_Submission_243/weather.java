import java.util.ArrayList;
/**
 * this class modifies the weather and how it changes
 *
 * @version 2020/2/22
 */
public class weather
{
    private ArrayList<String> weathe = new ArrayList<>();
    
    
    /**
     * Constructor for objects of class weather
     */
    public weather()
    {
        // initialise instance variables
        weathe = new ArrayList<>();
   
    }

    /**
     * get a particular weather by entering an index
     * 
     */
    public String getWeather(int index)
    {
       return weathe.get(index);
    }
    
    /**
     * add a new weather by entering a string
     * 
     */
    public void add(String add)
    {
        weathe.add(add);
    }
    
    /**
     * return the size of the arraylist
     * 
     */
    public int size()
    {
        return weathe.size();
    }
}
