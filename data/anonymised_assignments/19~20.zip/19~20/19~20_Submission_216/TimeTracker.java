
/**
 * This class keep track of the day.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class TimeTracker
{
    // The time period before an earthquake happens.
    private static final int EARTHQUAKE_HAPPEN_PERIOD = 300;
    
    /**
     * Create a new time tracker.
     */
    public TimeTracker()
    {

    }

    /**
     * Show the time.
     * @param step The current step.
     * @return The time.
     */
    public int showTime(int step)
    {
        return (step % 24);
    }
    /**
     * Check whether the current time is day time.
     * @param step The current step.
     * @return true if it is day time now.
     */
    public boolean isDayTime(int step)
    {
        int hour = step % 24;
        return (hour >= 0) && (hour <= 11);
    }
    
    /**
     * Check if it is the time for an earthquake to happen.
     * @param time The current time.
     * @return true if an earthquake will happen at this time.
     */
    public boolean isEarthquakeTime(int time)
    {
        return time%EARTHQUAKE_HAPPEN_PERIOD == 0;
    }
}
