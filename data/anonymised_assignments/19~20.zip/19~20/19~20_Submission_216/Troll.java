import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * A simple model of a troll. Trolls age, move and hunt at night, and then die.
 * Each goblin has a chance to grow to a troll after certain age.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Troll extends Actor implements Hunter
{
     // The age to which a troll can live.
     private static final int MAX_AGE = 80;
     // The age of the troll.
     private int age;

     /**
     * Create a troll. A troll can be created by a chance when a goblin grow up.
     * The troll created has a age of 0.
     * @param field The field currently occupied.
     * @param itemField The field of items.
     * @param location The location within the field.
     */
    public Troll(Field field, ItemField itemField, Location location)
    {
        super(field, itemField, location);
        age = 0;
     }

    /**
     * Make this troll act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born trolls.
     * @param isDayTime Check whether is day time.
     */
    public void act(List<Actor> newActors, boolean isDayTime)
    {
         incrementAge();
         if(isAlive() && !isDayTime){
              if(findTarget()){
                   attack(targetLocations());
               }
               pickItems();
               move();
          }
     }

    /**
     * Increase the age. This could result in the troll's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE){
             setDead();
          }
     }

    /**
     * Look for targets adjacent to the current location.
     * @return An ArrayList of the locations where targets were found.
     */
    public ArrayList<Location> targetLocations()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        ArrayList<Location> targetLocations = new ArrayList<>();
        while(it.hasNext()){
            Location where = it.next();
            Actor actor = getActorAt(where);
            if(isTarget(actor)){
                 targetLocations.add(where);
               }
          }
        return targetLocations;
     }

    /**
     * Check whether if there is at least a target around.
     * @return true if find a target.
     */
    public boolean findTarget()
    {
        if(targetLocations().size() > 0){
             return true;
        }else{
             return false;
        }
     }

     /**
     * Check if an actor is a target of this hunter.
     * @param actor the actor to be checked.
     * @return true if this actor is a target.
     */
    public boolean isTarget(Actor actor)
    {
         boolean isTarget = (actor != null) && !(actor instanceof Troll);
         return isTarget;
    }

    /**
     * Attack the target.
     * @param targetLocations An ArrayList of the location of the targets.
     */
    public void attack(ArrayList<Location> targetLocations)
    {
        int numbTarget = targetLocations.size();
        if(numbTarget != 0){
             for(int i = 0; i < numbTarget; i++){
                  Actor target = getActorAt(targetLocations.get(i));
                  if(target.isAlive()){
                         target.setDead();
                    }
               }
          }
     }

     /**
     * The actor picks up items which are useful for the actor.
     */
    protected void pickItems()
    {
         // Nothing can be picked up by a troll so far...
    }

    /**
     * The actor drops items at current location.
     */
    protected void dropItems()
    {
        super.dropItems();
    }
}
