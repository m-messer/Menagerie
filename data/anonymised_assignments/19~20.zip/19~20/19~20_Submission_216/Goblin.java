import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a goblin.
 * Goblins age, move, breed, and die.
 * This class is an extension of "Rabbit" class from "foxes-and-rabbits".
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Goblin extends Actor implements Reproduction
{
    // Characteristics shared by all goblins (class variables).

    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    // The age at which a goblin can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a goblin can live.
    private static final int MAX_AGE = rand.nextInt(70);
    // The likelihood of a goblin breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The maximum amount of gold a goblin carries.
    private static final int DEFAULT_GOLD = 30;
    // The goblin has a chance to evolve to a troll.
    private static final double EVOLVE_CHANCE = 0.002;
    // The age of the goblin to be strong enough to evolve to a troll.
    private static final int EVOLVE_AGE = 25;
    
    // Individual characteristics (instance fields).
    
    // The goblin's age.
    private int age;
    // The goblin has different gender.
    private boolean isMale;
    // Each goblin carries some amount of gold.
    private int goldAmount;

    /**
     * Create a new goblin. A goblin may be created with age
     * zero (a new born) or with a random age.
     * @param randomAge If true, the goblin will have an random age.
     * @param field The field currently occupied.
     * @param itemField The field of items.
     * @param location The location within the field.
     */
    public Goblin(boolean randomAge, Field field, ItemField itemField, Location location)
    {
        super(field, itemField, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        isMale = rand.nextBoolean();
        goldAmount = rand.nextInt(DEFAULT_GOLD + 1);
    }
    
    /**
     * Make this goblin act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born actors.
     * @param isDayTime Check whether is day time.
     */
    public void act(List<Actor> newActors, boolean isDayTime)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newActors);
            pickItems();            
            move(); 
            evolve(newActors);
        }
    }

    /**
     * Increase the age.
     * This could result in the goblin's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * The goblin has a chance to evolve to a troll.
     * @param newTroll A list to return newly born trolls.
     */
    private void evolve(List<Actor> newTroll)
    {
        if(isAlive() && age > EVOLVE_AGE && rand.nextDouble() < EVOLVE_CHANCE){
            Field field = getField();
            ItemField itemField = getItemField();
            Location location = getLocation();
            setDead();
            Troll troll = new Troll(field, itemField, location);
            newTroll.add(troll);
        }
    }

    /**
     * The actor picks up items which are useful for the actor.
     */
    protected void pickItems()
    {
        Location location = getLocation();
        ArrayList<Item> localItems = getItemField().getItems(location);
        Iterator<Item> it = localItems.iterator();
        while(it.hasNext()){
            Item item = it.next();
            if(item instanceof GoldPack){
                GoldPack goldpack = (GoldPack) item;
                goldAmount = goldAmount + goldpack.getGold();
                it.remove();
            }
        }
    }

    /**
     * The actor drops items at current location.
     */
    protected void dropItems()
    {
        super.dropItems();
        Location location = getLocation();
        ArrayList<Item> localItems = getItemField().getItems(location);
        localItems.add(new GoldPack(goldAmount));
        goldAmount = 0;
    }
    
    /**
     * Check whether or not this goblin is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newActors A list to return newly born actors.
     */
    public void giveBirth(List<Actor> newActors)
    {
        Field field = getField();
        ItemField itemField = getItemField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Goblin young = new Goblin(false, field, itemField, loc);
            newActors.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed()) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Check whether the goblin can give birth or not.
     * @return true if the goblin can give birth.
     */
    public boolean canBreed()
    {
        Location location = getLocation();
        ArrayList<Goblin> partners = getGoblinsIn(getAdjacentActors(location));
        for (int i = 0; i < partners.size(); i++){
            if (isAdult() && partners.get(i).isMale && isMale != partners.get(i).isMale() && rand.nextDouble() <= BREEDING_PROBABILITY) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if this goblin is an adult.
     * @return true if this goblin is an adult.
     */
    private boolean isAdult()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Check the gender of the goblin.
     * @return true if the goblin is male.
     */
    private boolean isMale()
    {
        return isMale;
    }
}
