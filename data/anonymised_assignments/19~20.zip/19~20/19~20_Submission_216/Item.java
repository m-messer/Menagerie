
/**
 * This class provides a model of item.
 * Items can be set on the field.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public abstract class Item
{
    // The time the item lasts after dropped on the ground and not picked up by an actor.
    private int expiryPeriod;
    // The time the item left before disappearing on the location.
    private int timeLeft;
    // Whether the item is everlasting or not.
    private boolean everlasting;

    /**
     * Create a new item with the limit appear time.
     * @param time The limit appear time.
     */
    public Item(int time)
    {
        expiryPeriod = time;
        timeLeft = expiryPeriod;
        everlasting = false;
    }

    /**
     * Create a new item with unlimited time.
     */
    public Item()
    {
        everlasting = true;
    }

    /**
     * Check if the item is everlasting.
     * @return true if the item is everlasting.
     */
    public boolean everlasting()
    {
        return everlasting;
    }

    /**
     * Get the time left before the item disappears.
     * @return The time left.
     */
    public int getTimeLeft()
    {
        return timeLeft;
    }

    /**
     * Decrease the time left by one.
     */
    public void timeDecrement()
    {
        timeLeft--;
    }

    /**
     * Check if the item expires.
     * @return true if item expire.
     */
    public boolean hasExpire()
    {
        return timeLeft <= 0;
    }

    /**
     * Reset the time left to the maximum.
     */
    public void resetTimeLeft()
    {
        timeLeft = expiryPeriod;
    }
}
