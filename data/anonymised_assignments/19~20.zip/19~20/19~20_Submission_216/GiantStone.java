
/**
 * This class simulates a giant stone which is placed on a grid of field.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class GiantStone extends Landscape
{
    // The giant stone cannot be destroyed.
    public static final boolean canBeDestroyed = false;

    /**
     * Create a new giant stone. 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public GiantStone(Field field, Location location)
    {
        super(canBeDestroyed, field, location);
    }
}
