import java.util.Random;

/**
 * This class simulates a tree.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Tree extends Landscape
{
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new tree.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Tree(Field field, Location location)
    {
        super(rand.nextBoolean(), field, location);
    }
}
