import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an elf. Elves age, move, hunt, give birth and be killed.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Elf extends Actor implements Reproduction, Hunter
{
    // Characteristics shared by all elves (class variables).
    // The age at which an elf can start to breed.
    private static final int ADULT_AGE = 200;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The elf's age.
    private int age;

    /**
     * Create an elf.
     * @param randomAge If true then elf has a random age.
     * @param field The field currently occupied.
     * @param itemField The field of items.
     * @param location The location within the field.
     */
    public Elf(boolean randomAge, Field field, ItemField itemField, Location location)
    {
        super(field, itemField, location);
        if(randomAge) {
            age = rand.nextInt(ADULT_AGE);
        }
        else {
            age = 0;
        }
    }

    /**
     * Make this elf act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born actors.
     * @param isDayTime Check whether is day time.
     */
    public void act(List<Actor> newActors, boolean isDayTime)
    {
        incrementAge();
        if(isAlive() && isDayTime){
            giveBirth(newActors);
            if(findTarget()){
                attack(targetLocations());
            }
            pickItems();
            move();
        }
    }

    /**
     * Increase the age.
     */
    private void incrementAge()
    {
        age++;
    }
    
    /**
     * Look for targets adjacent to the current location.
     * @return An ArrayList of the locations where targets were found.
     */
    public ArrayList<Location> targetLocations()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        ArrayList<Location> targetLocations = new ArrayList<>();
        while(it.hasNext()) {
            Location where = it.next();
            Actor actor = getActorAt(where);
            if(isTarget(actor)) {
                targetLocations.add(where);
            }
        }
        return targetLocations;
    }

    /**
     * Check if there is at least a target around.
     * @return true if find a target.
     */
    public boolean findTarget()
    {
        if(targetLocations().size() > 0){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Check if an actor is a target of this hunter.
     * @param actor The actor to be checked.
     * @return true if this actor is a target.
     */
    public boolean isTarget(Actor actor)
    {
        boolean isTarget = (actor != null) && (actor instanceof Undead);
        return isTarget;
    }

    /**
     * Attack the target.
     * @param targetLocations An ArrayList of the location of the targets.
     */
    public void attack(ArrayList<Location> targetLocations)
    {
        int numbTarget = targetLocations.size();
        if(numbTarget != 0){
            Location selectedTarget = targetLocations.get(rand.nextInt(numbTarget));
            Actor target = getActorAt(selectedTarget);
            if(target.isAlive()){
                target.setDead();
            }
        }
    }

    /**
     * The actor picks up items which are useful for the actor.
     */
    protected void pickItems()
    {
        // The elf cannot pick up any item yet.
    }

    /**
     * The actor drops his/her items at current location.
     */
    protected void dropItems()
    {
        super.dropItems();
    }
    
    /**
     * Check whether or not this elf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newActors A list to return newly born actors.
     */
    public void giveBirth(List<Actor> newActors)
    {
        Field field = getField();
        ItemField itemField = getItemField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Elf young = new Elf(false, field, itemField, loc);
            newActors.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        Location location = getLocation();
        if(canBreed()) {
            births = getAdjacentLandscapes(location).size();
        }
        return births;
    }

    /**
     * Check whether the elf can give birth or not.
     * @return true if the elf can give birth.
     */
    public boolean canBreed()
    {
        Location location = getLocation();
        if(!getAdjacentLandscapes(location).isEmpty() && isAdult()){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Check if this elf is an adult.
     * @return true if this elf is an adult.
     */
    private boolean isAdult()
    {
        return age >= ADULT_AGE;
    } 
}
