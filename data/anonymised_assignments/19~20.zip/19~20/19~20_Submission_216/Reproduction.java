import java.util.List;
/**
 * This is an interface providing methods for reproduction process.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public interface Reproduction
{
    /**
     * Check the condition for an actor to give birth.
     * @return true if the actor meet condition to breed.
     */
    boolean canBreed();

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births.
     */
    int breed();

    /**
     * Check whether or not this actor is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newActors A list to return newly born actors.
     */
    void giveBirth(List<Actor> newActors);
}
