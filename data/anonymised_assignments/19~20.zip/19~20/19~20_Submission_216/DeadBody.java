
/**
 * This class is a subclass of class Item.
 * This class models a "dead body" item,
 * which is the body of dead actors.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class DeadBody extends Item
{
    // The time the item lasts after dropped on the ground and not picked up by an actor.
    private static final int expiryPeriod = 15;

    /**
     * Create a new dead body item.
     */
    public DeadBody()
    {
        super(expiryPeriod);
    }
}
