import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a human.
 * Humanes age, move, kill Goblins for the gold, and die.
 * This class is an extension of "Fox" class from "foxes-and-rabbits".
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Human extends Actor implements Reproduction, Hunter
{
    // Characteristics shared by all humanes (class variables).
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    // The age at which a human can start to breed.
    private static final int ADULT_AGE = 18;
    // The age to which a human can live.
    private static final int MAX_AGE = rand.nextInt(120);
    // The likelihood of a human breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_MULTIPLE_BIRTH = 2;
    // The initial gold the human has when initialised.
    private static final int DEFAULT_GOLD = 40;
    
    // Individual characteristics (instance fields).
    // The human's age.
    private int age;
    // The human's gold, which is increased by picking up gold packs.
    // Once the human is out of gold, he/she left the field(died).
    private int goldAmount;
    // The human has different gender.
    private boolean isMale;

    /**
     * Create a human. A human can be created as a new born (age zero) or with a random age.
     * @param randomAge If true, the human will have random age and gold amount.
     * @param field The field currently occupied.
     * @param itemField The field of items.
     * @param location The location within the field.
     */
    public Human(boolean randomAge, Field field, ItemField itemField, Location location)
    {
        super(field, itemField, location);
        if(randomAge){
            age = rand.nextInt(MAX_AGE);
            goldAmount = rand.nextInt(DEFAULT_GOLD + 1);
        }else{
            age = 0;
            goldAmount = DEFAULT_GOLD;
        }
        isMale = rand.nextBoolean();
    }

    /**
     * Make this human act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born actors.
     * @param isDayTime Check whether is day time.
     */
    public void act(List<Actor> newActors, boolean isDayTime)
    {
        incrementAge();
        if(isAlive() && isDayTime){
            giveBirth(newActors);
            if(findTarget()){
                attack(targetLocations());
            }
            log();
            pickItems();
            move();
            spendGold();
        }
    }

    /**
     * Increase the age. This could result in the human's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE){
            setDead();
        }
    }
    
    /**
     * The human spend gold every step.
     * If the human run out of gold, he dies.
     */
    private void spendGold()
    {
        goldAmount--;
        if(goldAmount <= 0){
            setDead();
        }
    }
    
    /**
     * Look for targets adjacent to the current location.
     * @return An ArrayList of the locations where targets were found.
     */
    public ArrayList<Location> targetLocations()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        ArrayList<Location> targetLocations = new ArrayList<>();
        while(it.hasNext()){
            Location where = it.next();
            Actor actor = getActorAt(where);
            if(isTarget(actor)){
                targetLocations.add(where);
            }
        }
        return targetLocations;
    }

    /**
     * Check if there is at least a target around.
     * @return true if find a target.
     */
    public boolean findTarget()
    {
        if(targetLocations().size() > 0){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Check if an actor is a target of this hunter.
     * @param actor The actor to be checked.
     * @return true if this actor is a target.
     */
    public boolean isTarget(Actor actor)
    {
        boolean isTarget = (actor != null) && (actor instanceof Goblin);
        return isTarget;
    }

    /**
     * Attack the target.
     * @param targetLocations An ArrayList of the location of the targets.
     */
    public void attack(ArrayList<Location> targetLocations)
    {
        int numbTarget = targetLocations.size();
        if(numbTarget != 0){
            Location selectedTarget = targetLocations.get(rand.nextInt(numbTarget));
            Actor target = getActorAt(selectedTarget);
            if(target.isAlive()){
                target.setDead();
            }
        }
    }

    /**
     * A human can log adjacent trees.
     */
    private void log()
    {
        Location location = getLocation();
        ArrayList<Landscape> landscapes = getAdjacentLandscapes(location);
        ArrayList<Tree> trees = getTreesIn(landscapes);
        for(Tree tree : trees){
            if(tree.canBeDestroyed()){
                tree.destroy();
            }
        }
    }

    /**
     * The actor picks up items which are useful for the actor.
     */
    protected void pickItems()
    {
        Location location = getLocation();
        ArrayList<Item> localItems = getItemField().getItems(location);
        Iterator<Item> it = localItems.iterator();
        ArrayList<Item> carriedItems = getItems();
        while(it.hasNext()){
            Item item = it.next();
            if(item instanceof GoldPack){
                GoldPack goldpack = (GoldPack) item;
                goldAmount = goldAmount + goldpack.getGold();
                it.remove();
            }
            // TODO Add more items for human to pick in version 2.0.
        }
    }

    /**
     * The actor drops his/her items at current location.
     */
    protected void dropItems()
    {
        super.dropItems();
        Location location = getLocation();
        ArrayList<Item> localItems = getItemField().getItems(location);
        localItems.add(new GoldPack(goldAmount));
        goldAmount = 0;
    }
    
    /**
     * Check whether or not this human is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newActors A list to return newly born actors.
     */
    public void giveBirth(List<Actor> newActors)
    {
        Field field = getField();
        ItemField itemField = getItemField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++){
            Location loc = free.remove(0);
            Human young = new Human(false, field, itemField, loc);
            newActors.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed()){
            births = rand.nextInt(MAX_MULTIPLE_BIRTH) + 1;
        }
        return births;
    }

    /**
     * Check whether the human can give birth or not.
     * @return true if the human can give birth.
     */
    public boolean canBreed()
    {
        Location location = getLocation();
        ArrayList<Human> partners = getHumansIn(getAdjacentActors(location));
        for(int i = 0; i < partners.size(); i++){
            if(isAdult() && partners.get(i).isAdult() && isMale != partners.get(i).isMale() && rand.nextDouble() <= BREEDING_PROBABILITY){
                return true;
            }
        }
        return false;
    }

    /**
     * Check if a human is an adult.
     * @return true if the human is an adult.
     */
    private boolean isAdult()
    {
        return age >= ADULT_AGE;
    } 

    /**
     * Check the gender of the human.
     * @return true if the human is male.
     */
    private boolean isMale()
    {
        return isMale;
    }
}
