import java.util.Random;

/**
 * This class is a subclass of class Item. This class models a "Gold pack" item,
 * which contains a random number of gold inside.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class GoldPack extends Item
{
    // The time the item lasts after dropped on the ground and not picked up by an actor.
    private static final int expiryPeriod = 2;
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();
    // The maximum gold the gold pack can contain.
    private int maxGold;

    /**
     * Create a gold pack.
     * @param maxGold The maximum gold the gold pack contains.
     */
    public GoldPack(int maxGold)
    {
        super(expiryPeriod);
        this.maxGold = maxGold;
    }

    /**
     * Generates an amount of gold.
     * @return Some amount of gold in this gold pack.
     */
    public int getGold()
    {
        if(maxGold > 0){
            return rand.nextInt(maxGold + 1);
        }else{
            return 0;
        }
    }
}
