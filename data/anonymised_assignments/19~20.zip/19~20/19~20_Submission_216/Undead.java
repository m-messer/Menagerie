import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of an undead. Undeads move, create new undead from dead actors
 * and die.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Undead extends Actor implements Reproduction
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The likelihood of an undead breading.
    private static final double BREEDING_PROBABILITY = 0.8;

    /**
     * Create an new undead. An undead may be created with a random location.
     * @param field The field currently occupied.
     * @param itemField The field of items.
     * @param location The location within the field.
     */
    public Undead(Field field, ItemField itemField, Location location)
    {
        super(field, itemField, location);
    }

    /**
     * Make this undead act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born actors.
     * @param isDayTime Check whether is day time.
     */
    public void act(List<Actor> newActors, boolean isDayTime)
    {
        if(isAlive() && !isDayTime){
            giveBirth(newActors);
            pickItems();
            move();
        }
    }

    /**
     * The actor picks up items which are useful for the actor.
     */
    protected void pickItems()
    {
        Location location = getLocation();
        ArrayList<Item> localItems = getItemField().getItems(location);
        Iterator<Item> it = localItems.iterator();
        ArrayList<Item> carriedItems = getItems();
        while(it.hasNext()){
            Item item = it.next();
            if(item instanceof DeadBody){
                carriedItems.add(item);
                it.remove();
            }
        }
    }

    /**
     * The actor drops items at current location.
     */
    protected void dropItems()
    {
        super.dropItems();
    }

    /**
     * Check the condition for an actor to give birth.
     * @return true if the actor meet condition to breed.
     */
    public boolean canBreed()
    {
        return rand.nextDouble() <= BREEDING_PROBABILITY;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births.
     */
    public int breed()
    {
        int births = 0;
        if(canBreed()){
            Iterator<Item> it = getItems().iterator();
            while(it.hasNext()){
                Item item = it.next();
                if(item instanceof DeadBody){
                    births++;
                    it.remove();
                }
            }
        }
        return births;
    }

    /**
     * Check whether or not this actor is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newActors A list to return newly born actors.
     */
    public void giveBirth(List<Actor> newActors)
    {
        Field field = getField();
        ItemField itemField = getItemField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++){
            Location loc = free.remove(0);
            Undead young = new Undead(field, itemField, loc);
            newActors.add(young);
        }
    }
}
