
/**
 * This class simulates objects of landscape.
 * If a landscape item is placed on a field location,
 * no actor can move to that location.
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Landscape
{
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    private Location location;
    // The landscape is destroyed.
    private boolean isDestroyed = false;
    // The landscape whether can be destroyed.
    private boolean canBeDestroyed;

    /**
     * Create a new landscape. A landscape may be destroyed based on some conditions.
     * @param canBeDestroyed If true, then the landscape can be destroyed.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Landscape(boolean canBeDestroyed,Field field, Location location)
    {
        this.field = field;
        this.canBeDestroyed = canBeDestroyed;
        setLocation(location);
    }

    /**
     * Return the location of the landscape.
     * @return The location of the landscape.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Check whether the landscape can be destroyed.
     * @return true if the landscape can be destroyed.
     */
    public boolean canBeDestroyed()
    {
        return canBeDestroyed;
    }

    /**
     * Destroy the landscape.
     */
    public void destroy()
    {
        isDestroyed = true;
        if(location != null){
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Check whether the landcape is destroyed.
     * @return true if the landscape is destroyed.
     */
    public boolean isDestroyed()
    {
        return isDestroyed;
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null){
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
}
