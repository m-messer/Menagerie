import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of actors.
 * This class is an extension of "Animal" class from "foxes-and-rabbits".
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public abstract class Actor
{
    // Each actor has a chance to create a dead body when dies.
    private static final double DEADBODY_CREATION_PROBABILITY = 0.2;
    // A shared random number generator.
    private static final Random rand = Randomizer.getRandom();

    // Whether the actor is alive or not.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's item field.
    private ItemField itemField;
    // The actor's position in the field.
    private Location location;
    // The actor's carried  items.
    private ArrayList<Item> items;
    
    /**
     * Create an new actor at location in field.
     * @param field The field currently occupied.
     * @param itemField The field of items.
     * @param location The location within the field.
     */
    public Actor(Field field, ItemField itemField, Location location)
    {
        alive = true;
        this.field = field;
        this.itemField = itemField;
        items = new ArrayList<>();
        setLocation(location);
    }
    
    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born actors.
     * @param isDayTime Check whether is day time.
     */
    abstract public void act(List<Actor> newActors, boolean isDayTime);

    /**
     * Move to a free adjacent location.
     */
    protected void move()
    {
        Location newLocation = getField().freeAdjacentLocation(getLocation());
        if(newLocation != null){
            // Try to move to a new location.
            setLocation(newLocation);
        }else{
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Return the actor at the given location, if any.
     * @param location Where in the field.
     * @return The actor at the given locaiton. Null if no actor found.
     */
    protected Actor getActorAt(Location location)
    {
        Actor actor = null;
        Object object = field.getObjectAt(location);
        if(object instanceof Actor){
            actor = (Actor) object;
        }
        return actor;
    }

    /**
     * This method checks the other actors around the actor.
     * @param Location The location where in the field.
     * @return A list of actors adjacent to the original actor.
     */
    protected ArrayList<Actor> getAdjacentActors(Location location)
    {
        ArrayList<Actor> actorList = new ArrayList<>();
        for(Location occupiedLocation : field.getOccupiedAdjacentLocations(location)){
            if(field.getObjectAt(occupiedLocation) instanceof Actor){
                actorList.add((Actor) field.getObjectAt(occupiedLocation));
            }
        }
        return actorList;
    }

    /**
     * Check the humans in the list of given actors.
     * @param actors An ArrayList of actors.
     * @return An ArrayList of humans in given actors.
     */
    protected ArrayList<Human> getHumansIn(ArrayList<Actor> actors)
    {
        ArrayList<Human> humans = new ArrayList<>();
        for(int i = 0; i < actors.size(); i++){
            if(actors.get(i) instanceof Human){
                humans.add((Human) actors.get(i));
            }
        }
        return humans;
    }

    /**
     * Check the goblins in the list of given actors.
     * @param actors An ArrayList of actors.
     * @return An ArrayList of goblins in given actors.
     */
    protected ArrayList<Goblin> getGoblinsIn(ArrayList<Actor> actors)
    {
        ArrayList<Goblin> goblins = new ArrayList<>();
        for(int i = 0; i < actors.size(); i++){
            if(actors.get(i) instanceof Goblin){
                goblins.add((Goblin) actors.get(i));
            }
        }
        return goblins;
    }

    /**
     * This method checks the landscape around given location.
     * @param Location The location where in the field.
     * @return A list of landscapes adjacent to the location.
     */
    protected ArrayList<Landscape> getAdjacentLandscapes(Location location)
    {
        ArrayList<Landscape> landscapes = new ArrayList<>();
        for(Location occupiedLocation : field.getOccupiedAdjacentLocations(location)){
            if(field.getObjectAt(occupiedLocation) instanceof Landscape)
            landscapes.add((Landscape) field.getObjectAt(occupiedLocation));
        }
        return landscapes;
    }

    /**
     * Check the trees in the list of given lndscapes.
     * @param landcapes An ArrayList of landscapes.
     * @return An ArrayList of trees in given landscapes.
     */
    protected ArrayList<Tree> getTreesIn(ArrayList<Landscape> landscapes)
    {
        ArrayList<Tree> trees = new ArrayList<>();
        for(int i = 0; i < landscapes.size(); i++){
            if(landscapes.get(i) instanceof Tree){
                trees.add((Tree) landscapes.get(i));
            }
        }
        return trees;
    }

    /**
     * The actor drops items at current location.
     */
    protected void dropItems()
    {
        for(Item item : items){
            item.resetTimeLeft();
            itemField.addItem(item, location);
        }
        items.clear();
    }

    /**
     * Get the items carried by the actor.
     * @return An ArrayList of items carried by the actor.
     */
    protected ArrayList<Item> getItems()
    {
        return items;
    }

    /**
     * The actor picks up items which are useful for the actor at current location.
     */
    abstract protected void pickItems();

    /**
     * Check whether the actor is alive or not.
     * @return true if the actor is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            dropItems();
            createDeadBody();
            field.clear(location);
            location = null;
            field = null;
            itemField = null;
        }
    }

    /**
     * Create a dead body item when die.
     */
    private void createDeadBody()
    {
        if(rand.nextDouble() < DEADBODY_CREATION_PROBABILITY){
            itemField.addItem(new DeadBody(), location);
        }
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the item field.
     * @return The item field.
     */
    protected ItemField getItemField()
    {
        return itemField;
    }
}
