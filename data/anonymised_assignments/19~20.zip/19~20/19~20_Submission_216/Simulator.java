import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing goblins, humanes, trolls, elves and undeads.
 * This class is an extension of "Simulator" class from "foxes-and-rabbits".
 * This class is a part of "Another World Simulator".
 *
 * @version 1.0
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a human will be created in any given grid position.
    private static final double HUMAN_CREATION_PROBABILITY = 0.04;
    // The probability that a goblin will be created in any given grid position.
    private static final double GOBLIN_CREATION_PROBABILITY = 0.06;
    // The probability that an undead will be created in any given grid position.
    private static final double UNDEAD_CREATION_PROBABILITY = 0.06;
    // The probability that an elf will be created in any given grid position.
    private static final double ELF_CREATION_PROBABILITY = 0.01;

    // The probability that a tree is grown on the given grid position.
    private static final double TREE_CREATION_PROBABILITY = 0.02;
    // The probaility that a giant stone is placed on the given grid position.
    private static final double GIANTSTONE_CREATION_PROBABILITY = 0.01;

    // The probability that an actor dies in an earthquake.
    private static final double EARTHQUAKE_DIE_PROBABILITY = 0.4;

    // List of actors in the field.
    private List<Actor> actors;
    // List of landscape in the field.
    private List<Landscape> landscapes;
    // The current state of the field.
    private Field field;
    // The field of items on the ground.
    private ItemField itemField;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Keep track of the time.
    private TimeTracker timeTracker;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        landscapes = new ArrayList<>();
        field = new Field(depth, width);
        itemField = new ItemField(depth,width);
        timeTracker = new TimeTracker();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        // Set colour for each actor.
        view.setColor(Goblin.class, Color.ORANGE);
        view.setColor(Human.class, Color.BLUE);
        view.setColor(Troll.class, Color.RED);
        view.setColor(Undead.class, Color.GRAY);
        view.setColor(Elf.class, Color.YELLOW);
        // Set colour for each landscape.
        view.setColor(Tree.class, Color.GREEN);
        view.setColor(GiantStone.class, Color.DARK_GRAY);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++){
            simulateOneStep();
            delay(60);
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actor.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ){
            Actor actor = it.next();
            actor.act(newActors, timeTracker.isDayTime(step));
            if(! actor.isAlive()){
                it.remove();
            }
        }

        // Clear the destroyed landscapes.
        for(Iterator<Landscape> it = landscapes.iterator(); it.hasNext(); ){
            Landscape landscape = it.next();
            if(landscape.isDestroyed()){
                it.remove();
            }
        }

        if(timeTracker.isEarthquakeTime(step)){
            earthquake();
        }

        updateItemField();

        // Add the newly born actors to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field, timeTracker);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        landscapes.clear();
        field.clear();
        itemField.clear();
        loadLandscape();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, timeTracker);
    }
    
    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++){
            for(int col = 0; col < field.getWidth(); col++){
                if(field.getObjectAt(row, col) == null){
                    if(rand.nextDouble() <= HUMAN_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Human human = new Human(true, field, itemField, location);
                        actors.add(human);
                    }else if(rand.nextDouble() <= GOBLIN_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Goblin goblin = new Goblin(true, field, itemField, location);
                        actors.add(goblin);
                    }else if(rand.nextDouble() <= UNDEAD_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Undead undead = new Undead(field, itemField, location);
                        actors.add(undead);
                    }else if(rand.nextDouble() <= ELF_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Elf elf = new Elf(true, field, itemField, location);
                        actors.add(elf);
                    }
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Randomly load landscapes.
     */
    private void loadLandscape()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++){
            for(int col = 0; col < field.getWidth(); col++){
                if(field.getObjectAt(row, col) == null){
                    if(rand.nextDouble() <= TREE_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        Tree tree = new Tree(field, location);
                        landscapes.add(tree);
                    }else if(rand.nextDouble() <= GIANTSTONE_CREATION_PROBABILITY){
                        Location location = new Location(row, col);
                        GiantStone stone = new GiantStone(field, location);
                        landscapes.add(stone);
                    }
                }
            }
        }
    }

    /**
     * This method clears the landscape.
     */
    private void clearLandscape()
    {
        Iterator<Landscape> it = landscapes.iterator();
        while(it.hasNext()){
            Landscape landscape = it.next();
            landscape.destroy();
            it.remove();
        }
    }

    /**
     * Simulate the event of earthquake.
     * An earthquake kill some random actors,
     * and re-destribute the landscapes.
     */
    public void earthquake()
    {
        clearLandscape();
        Random rand = Randomizer.getRandom();
        Iterator<Actor> it = actors.iterator();
        while(it.hasNext()){
            Actor actor = it.next();
            if(actor.isAlive() && rand.nextDouble() <= EARTHQUAKE_DIE_PROBABILITY){
                actor.setDead();
            }
        }
        loadLandscape();
    }

    /**
     * Update the items on every location.
     * Some items may expire.
     */
    private void updateItemField()
    {
        for(int row = 0; row < itemField.getDepth(); row++){
            for(int col = 0; col < itemField.getWidth(); col++){
                ArrayList<Item> items = itemField.getItems(row, col);
                Iterator<Item> it = items.iterator();
                while(it.hasNext()){
                    Item item = it.next();
                    if(!item.everlasting()){
                        if(item.hasExpire()){
                            it.remove();
                        }else{
                            item.timeDecrement();
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try{
            Thread.sleep(millisec);
        }
        catch(InterruptedException ie){
            // wake up
        }
    }
}
