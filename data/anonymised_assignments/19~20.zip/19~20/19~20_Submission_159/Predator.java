/**
 * A class representing shared characteristics of predators.
 *
 * @version 2020.02.23
 */
public abstract class Predator extends Animal {
    /**
     * Create a new predator at locaiton in field.
     * 
     * @param field The field currently occupied.
     * @param location THe location within the field.
     */
    public Predator(Field field, Location location) {
        super(field, location);
    }

    /**
     * Make this predator act - that is: make it do
     * whatever it wants/needs to do during the day.
     */
    public void actDay()  {
        this.incrementAge();
        this.incrementHunger();
        this.actInfected();
        if (this.isAlive()) {
            Location newLocation = this.findFood();
            if (newLocation == null) {
                newLocation = this.getField().freeAdjacentLocation(this.getLocation());
            }
            if (newLocation != null) {
                this.setLocation(newLocation);
            } else {
                this.setDead();
            }
        }
    }

    /**
     * Make the predator look for prey.
     * @return A location containing nearby prey, if there are any.
     */
    abstract Location findFood();
    
    /**
     * Increments the predator's age.
     */
    abstract void incrementAge();
}

