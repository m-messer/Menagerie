import java.util.List;
import java.util.Random;

/**
 * Represent a plant in the simulation.
 * Plants can grow, spread and die.
 *
 * @version 2020.02.23
 */
public class Plant {
    // The probability of the plant growing.
    private static final double GROWTH_PROBABILITY = 0.7D;
    // The maximum amount of water the plant can store.
    private static final int WATER_LEVEL = 10;
    // A randomizer.
    private static final Random rand = Randomizer.getRandom();
    // Whether the plant is alive or not.
    private boolean isAlive;
    // The current water level of the plant.
    private int waterLevel;
    // The location of the plant in the field.
    private Location location;
    // The field currently occupied.
    private Field field;

    /**
     * Create a new plant.
     * @param field The field currently occupied
     * @param location The location within the field.
     */
    public Plant(Field field, Location location) {
        this.field = field;
        this.setLocation(location);
        waterLevel = WATER_LEVEL;
        isAlive = true;
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    public Field getField() {
        return this.field;
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    public Location getLocation() {
        return this.location;
    }

    /**
     * Set the water level of the plant back to maximum.
     */
    public void resetWater() {
        int waterLevel = WATER_LEVEL;
    }
    
    /**
     * Decrease the water level of the plant.
     * Could lead to the plant's death if it is less than
     * or equal to 0.
     */
    public void decrementWater() {
        --waterLevel;
        if (waterLevel <= 0) {
            this.setDead();
        }
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    public void setLocation(Location newLocation) {
        if (this.location != null) {
            this.field.clear(this.location);
        }

        this.location = newLocation;
        this.field.place(this, newLocation);
    }

    /**
     * Check if the plant is alive.
     * @return True if the plant is alive, false otherwise.
     */
    public boolean isAlive() {
        return this.isAlive;
    }

    /**
     * Indicate that the plant is dead.
     * Set the field and location that the plant to be empty.
     */
    public void setDead() {
        this.isAlive = false;
        if (this.location != null) {
            this.field.clear(this.location);
            this.location = null;
            this.field = null;
        }
    }

    /**
     * Grow new plants at adjacent places.
     * @param newPlants A list of newborn plants.
     */
    public void growthSurrounding(List<Plant> newPlants) {
        List<Location> free = this.field.getFreeAdjacentLocations(this.location);
        if (!free.isEmpty() && rand.nextDouble() <= GROWTH_PROBABILITY) {
            Location loc = (Location)free.remove(0);
            Plant seed = new Plant(this.field, loc);
            newPlants.add(seed);
        }
    }
}
