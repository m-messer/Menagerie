 

public class Time {
    private int t = 0;
    private static final int MAX_TIME = 15;

    public Time() {
    }

    public void reset() {
        this.t = 0;
    }

    public void increment() {
        ++this.t;
        if (this.t > MAX_TIME) {
            this.t = 0;
        }

        this.checkDay();
    }

    public boolean checkDay() {
        return this.t < 7;
    }

}
