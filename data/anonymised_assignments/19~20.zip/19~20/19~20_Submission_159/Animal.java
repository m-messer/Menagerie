import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.23
 */
public abstract class Animal {
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's gender.
    protected final boolean isMale;
    // Whether the animal has the virus or not.
    protected boolean haveVirus;
    // If the animal has the virus, how many days it has to live.
    private int daysAlive;
    // The amount of steps an animal can walk before it dies.
    protected int foodLevel;
    // The virus.
    private final CoronaVirus virus = new CoronaVirus();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        this.field = field;
        this.setLocation(location);
        this.alive = true;
        Random ranGen = new Random();
        this.isMale = ranGen.nextBoolean();
        this.haveVirus = false;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do during the day.
     */
    public abstract void actDay();

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do during the night.
     * @param newAnimals A list to receive newly born animals.
     */
    public abstract void actNight(List<Animal> newAnimals);

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do during the night.
     * @param isRain Check if it is raining or not.
     */
    protected void actRain(boolean isRain) {
        if (isRain && this.isAlive()) {
            Location newLocation = findPack();
            if (newLocation != null) {
                this.setLocation(newLocation);
            }
            else {
                newLocation = this.getField().freeAdjacentLocation(getLocation());
                if (newLocation != null) {
                    this.setLocation(newLocation);
                }
                else    {
                    this.setDead();
                }
            }
        }
    }
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive() {
        return this.alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        this.alive = false;
        if (this.location != null) {
            this.field.clear(this.location);
            this.location = null;
            this.field = null;
            this.haveVirus = false;
        }
    }

    /**
     * How the animal should act if it is infected.
     */
    protected void actInfected() {
        if (this.haveVirus) {
            if (this.daysAlive == 0) {
                this.setDead();
            } else {
                this.setDaysAlive(this.daysAlive - 1);
                this.virus.infectSurrounding(this.getLocation(), this.getField());
            }
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation() {
        return this.location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (this.location != null) {
            this.field.clear(this.location);
        }

        this.location = newLocation;
        this.field.place(this, newLocation);
    }

    /**
     * Decrement the animal's food level.
     * Could lead to death if food level is less than or equal to 0.
     */
    protected void incrementHunger() {
        --this.foodLevel;
        if (this.foodLevel <= 0) {
            this.setDead();
        }
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField() {
        return this.field;
    }

    /**
     * Return the animal's gender.
     * @return True if animal is male, false if female.
     */
    protected boolean getGender() {
        return this.isMale;
    }

    /**
     * Indicate that this animal is now infected.
     */
    protected void infected() {
        this.haveVirus = true;
    }

    /**
     * The animal attempts to find its own kind.
     * @return A location of a nearby animal of its own kind, if there are any.
     */
    protected abstract Location findPack();

    /**
     * Set how many days left an infected animal has to live.
     * @param days The number of days the animal has to live.
     */
    protected void setDaysAlive(int days) {
        this.daysAlive = days;
    }

    /**
     * Return if the animal is infected or not.
     * @return True if the animal is infected, false otherwise.
     */
    public boolean isInfected() {
        return this.haveVirus;
    }
}

