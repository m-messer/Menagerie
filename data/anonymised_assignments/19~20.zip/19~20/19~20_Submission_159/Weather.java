/**
 * The weather of the simulation.
 */
public class Weather {
    private boolean isRainy;

    public Weather() {
        isRainy = false;
    }

    public void setWeather(boolean isRainy) {
        this.isRainy = isRainy;
    }

    public boolean getWeather() {
        return isRainy;
    }
}
