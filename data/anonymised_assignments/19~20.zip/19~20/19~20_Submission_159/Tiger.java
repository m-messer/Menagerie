import java.util.List;
import java.util.Random;

/**
 * Represents a tiger in the simulation.
 * Tigers age, move, mate, hunt prey, eat and die.
 *
 * @version 2020.02.23
 */
public class Tiger extends Predator {
    // The minimum age/number of steps before the tiger can breed.
    private static final int BREEDING_AGE = 15;
    // The maximum age/number of steps of the tiger.
    private static final int MAX_AGE = 60;
    // The probability of the tiger being able to breed.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum amount of young the tiger can give birth to at once.
    private static final int MAX_LITTER_SIZE = 2;
    // The amount of food a zebra gives a tiger.
    private static final int ZEBRA_FOOD_VALUE = 9;
    // A randomizer.
    private static final Random rand = Randomizer.getRandom();
    // The lion's age.
    private int age;

    /**
     * Create a new tiger. A tiger may be created with age 
     * zero (A new born) or with a random age.
     * 
     * @param randomAge If true, the tiger will have a random age.
     * @param field The field currently being occupied.
     * @param location The location within the field.
     */
    public Tiger(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            this.age = rand.nextInt(MAX_AGE);
            this.foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE);
        } else {
            this.age = 0;
            this.foodLevel = ZEBRA_FOOD_VALUE;
        }
    }

    /**
     * How the tiger acts at night.
     * @param newLions A list of newborn tigers.
     */
    public void actNight(List<Animal> newTigers) {
        this.actInfected();
        if (this.isAlive()) {
            this.giveBirth(newTigers);
        }
    }

    /**
     * Increment the tiger's age.
     * Could lead to the tiger's death.
     */
    protected void incrementAge() {
        ++this.age;
        if (this.age > MAX_AGE) {
            this.setDead();
        }
    }

    /**
     * Find any nearby zebras.
     * @return The location of any nearby zebras, or null if there are none.
     */
    protected Location findFood()   {
        Field field = this.getField();
        List<Location> adjacent = field.adjacentLocations(this.getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Prey && ((Prey) animal).isAlive()) {
                Prey prey = (Prey) animal;
                if (prey instanceof Zebra) {
                    prey.setDead();
                    this.foodLevel += ZEBRA_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Attempt to find other tigers.
     * @return A location of nearby tigers, or null if there are none.
     */
    protected Location findPack() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Tiger) {
                return where;
            }
        }
        return null;
    }

    /**
     * Give birth to new tigers.
     * @param newLions A list of newborn tigers.
     */
    private void giveBirth(List<Animal> newTigers) {
        Field field = this.getField();
        List<Location> free = field.getFreeAdjacentLocations(this.getLocation());
        int births = this.breed();
        for(int b = 0; b < births && free.size() > 0; ++b) {
            Location loc = (Location)free.remove(0);
            Tiger young = new Tiger(false, field, loc);
            newTigers.add(young);
        }
    }

    /**
     * Determine how many young a tiger will give birth to.
     * @return The number of young the tiger will give birth to.
     */
    private int breed() {
        int births = 0;
        List<Animal> candidate = this.getField().maleMate(this.getLocation());
        for (Animal animal : candidate) {
            if (this.canBreed() && animal instanceof Tiger && rand.nextDouble() <= BREEDING_PROBABILITY) {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                return births;
            }
        }
        return births;
    }

    /**
     * Check if the tiger can breed.
     * They can only breed if they are above a certain age and they 
     * are female.
     * @return True if the tiger can breed, false otherwise.
     */
    private boolean canBreed() {
        return this.age >= BREEDING_AGE && !this.isMale;
    }
}
