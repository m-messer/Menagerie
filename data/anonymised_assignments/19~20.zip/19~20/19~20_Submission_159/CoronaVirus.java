import java.util.List;
import java.util.Random;

/**
 * The virus in the simulation.
 * A virus has a fixed chance to infect an animal, and sets a number of steps
 * an infected animal can live before it dies.
 */
public class CoronaVirus {
    // The chance of infecting an animal.
    private static final double CHANCE_INFECTED = 0.45;
    // A randomizer.
    private static final Random randChance = Randomizer.getRandom();
    // The number of steps before the infected animal dies.
    private static final int DEATH_COUNTER = 10;
    // A randomizer.
    private final Random rand = new Random();

    /**
     * Constructor for the virus.
     */
    public CoronaVirus() {
    }

    /**
     * Infects an animal and sets how many steps it has left to live.
     * @param animal The animal to be infected.
     */
    public void infected(Animal animal) {
        animal.infected();
        animal.setDaysAlive(DEATH_COUNTER);
    }

    /**
     * Infect the surrounding area.
     * @param field The field of the area.
     * @param location The location in the field of the area.
     */
    public void infectSurrounding(Location location, Field field) {
        if (location != null && field != null) {
            List<Animal> virusCandidate = field.getVirusCandidate(location);
            if (!virusCandidate.isEmpty() && randChance.nextDouble() <= CHANCE_INFECTED) {
                Animal victim = virusCandidate.get(this.rand.nextInt(virusCandidate.size()));
                this.infected(victim);
            }
        }
    }
}