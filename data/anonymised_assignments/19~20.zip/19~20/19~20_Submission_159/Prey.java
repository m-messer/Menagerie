import java.util.List;

/**
 * A class representing shared characteristics of prey.
 *
 * @version 2020.02.23
 */
public abstract class Prey extends Animal {
    // The amount of food a plant gives an animal.
    protected static final int PLANT_FOOD_VALUE = 13;

    /**
     * Create a new prey at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(Field field, Location location) {
        super(field, location);
    }

    /**
     * Make this prey act - that is: make it do
     * whatever it wants/needs to do during the day.
     */
    public void actDay()  {
        this.incrementAge();
        this.incrementHunger();
        this.actInfected();
        if (this.isAlive()) {
            Location newLocation = this.findFood();
            if (newLocation == null) {
                newLocation = this.getField().freeAdjacentLocation(this.getLocation());
            }
            if (newLocation != null) {
                this.setLocation(newLocation);
            } else {
                this.setDead();
            }
        }
    }

    /**
     * Make the prey look for food - specifically plants.
     * @return A location containing nearby plants, if there are any.
     */
    protected Location findFood()  {
        Field field = this.getField();
        List<Location> adjacent = field.adjacentLocations(this.getLocation());

        for (Location where : adjacent) {
            Object plant = field.getObjectAt(where);
            if (plant instanceof Plant) {
                Plant grass = (Plant) plant;
                if (grass.isAlive()) {
                    grass.setDead();
                    this.foodLevel += PLANT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    } 
    
    /**
     * Increments the prey's age. 
     */
    abstract void incrementAge();
}

