import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing zebras and tigers.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a tiger will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.02;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.08;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02;
    // The probability that a gazelle will be created in any given grid position.
    private static final double GAZELLE_CREATION_PROBABILITY = 0.08;
    // The probability that a cheetah will be created in any given grid position.
    private static final double CHEETAH_CREATION_PROBABILITY = 0.02;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.2;
    // The probability that a cheetah will be created in randomly during the simulation.
    private static final double GROWTH_PROBABILITY_RANDOM = 0.015;
    // The maximum number of animals that can be infected at step 0.
    private static final int VIRUS_SEED = 15;
    // List of animals in the field.
    private List<Object> objects;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The time of the simulation.
    private Time time = new Time();
    // Boolean set to true if raining, false otherwise.
    public boolean currentWeather;
    // The weather of the simulation.
    private Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        objects = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Tiger.class, Color.ORANGE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Gazelle.class, Color.PINK);
        view.setColor(Cheetah.class, Color.YELLOW);
        view.setColor(Plant.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * tiger and zebra.
     */
    public void simulateOneStep()
    {
        step++;
        time.increment();
        boolean isDay = time.checkDay();

        // Provide space for newborn animals and growth of new plants.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        // Every 10 steps, randomly change the weather.
        if((step % 10) == 0) {
            Random random = new Random();
            boolean isRain = random.nextBoolean();
            weather.setWeather(isRain);
        }
        currentWeather = weather.getWeather();
        
        // Let all animals act and plants grow.
        for(Iterator<Object> it = objects.iterator(); it.hasNext(); ) {
            Object object = it.next();
            if(object instanceof Animal)    {
                Animal animal = (Animal) object;
                // Remove dead animals.
                if(! animal.isAlive()) {
                    it.remove();
                }
                if(isDay) {
                    animal.actDay();
                }
                else {
                    animal.actNight(newAnimals);
                }
                animal.actRain(currentWeather);
            }
            else if(object instanceof Plant) {
                Plant plant = (Plant) object;
                if(!plant.isAlive()) {
                    it.remove();
                }
                else {
                    if (isDay) {
                        plant.growthSurrounding(newPlants);
                    }
                    if(currentWeather) {
                        plant.resetWater();
                    }
                    else {
                        plant.decrementWater();
                    }
                }
            }
        }
        // Add the newly born animals to the main lists.
        objects.addAll(newAnimals);
        
        // Spawn random plants in the field during the rain.
        if(currentWeather) {
            randomGrowth();
        }
        view.showStatus(step, field, infectedNumber(), currentWeather());
    }

    /**
     * Get a string to represent the current weather.
     * @return A string showing the current weather.
     */
    private String currentWeather()
    {
        if(currentWeather) {
            return "Rainy";
        }
        else {
            return "Sunny";
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        objects.clear();
        populate();
        randomInfect();
        time.reset();
        // Show the starting state in the view.
        view.showStatus(step, field, infectedNumber(), currentWeather());
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // else leave the location empty.
                if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    objects.add(zebra);
                }
                else if(rand.nextDouble() <= GAZELLE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Gazelle gazelle = new Gazelle(true, field, location);
                    objects.add(gazelle);
                }
                else if(rand.nextDouble() <= TIGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tiger tiger = new Tiger(true, field, location);
                    objects.add(tiger);
                }
                else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah = new Cheetah(true, field, location);
                    objects.add(cheetah);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    objects.add(lion);
                }
                else  if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY)  {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    objects.add(plant);
                }
            }
        }
    }

    /**
     * Randomly populate the field with new plants.
     */
    private void randomGrowth()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if (field.getObjectAt(row,col) == null &&
                        rand.nextDouble() <= GROWTH_PROBABILITY_RANDOM) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(field, location);
                    field.place(plant, location);
                }
            }
        }
    }

    /**
     * Randomly infect some animals.
     */
    private void randomInfect()
    {
        Random random = new Random();
        for (int i = 0 ; i < VIRUS_SEED ; i++)
        {
            Object object = getAllObjects().get(random.nextInt(getAllObjects().size()));
            if (object instanceof Animal)   {
                Animal animal = (Animal) object;
                CoronaVirus virus = new CoronaVirus();
                virus.infected(animal);
            }
        }
    }

    /**
     * Get the number of animals that are infected.
     * @return The number of animals which are infected.
     */
    public int infectedNumber()
    {
        int infectedCounter = 0;
        for (int i = 0 ; i < getAllObjects().size() ; i++)    {
            if (getAllObjects().get(i) instanceof Animal) {
                Animal animal = (Animal) getAllObjects().get(i);
                if (animal.isInfected()) {
                    infectedCounter++;
                }
            }
        }
        return infectedCounter;
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Return a list of all the plants and animals in the simulator.
     * @return A list of all the plants and animals in the simulator.
     */
    public List<Object> getAllObjects()
    {
        return objects;
    } 
}

