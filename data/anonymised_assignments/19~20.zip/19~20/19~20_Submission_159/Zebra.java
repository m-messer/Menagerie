import java.util.List;
import java.util.Random;

/**
 * Represents a zebra in the simulation.
 * Zebras age, move, mate, find food, eat and die.
 *
 * @version 2020.02.23
 */
public class Zebra extends Prey {
    // The minimum age/number of steps before the zebra can breed.
    private static final int BREEDING_AGE = 5;
    // The maximum age/number of steps of the zebra.
    private static final int MAX_AGE = 40;
    // The maximum amount of young the zebra can give birth to at once.
    private static final int MAX_LITTER_SIZE = 4;
    // The probability of the zebra being able to breed.
    private static final double BREEDING_PROBABILITY = 0.12;
    // A randomizer.
    private static final Random rand = Randomizer.getRandom();
    // The age of the zebra.
    private int age = 0;

    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            this.age = rand.nextInt(MAX_AGE);
        }
        this.foodLevel = PLANT_FOOD_VALUE;
    }

    /**
     * How the zebra acts at night.
     * @param newZebras A list of newborn zebras.
     */
    public void actNight(List<Animal> newZebras) {
        this.actInfected();
        if (this.isAlive()) {
            this.giveBirth(newZebras);
        }
    }

    /**
     * Increment the zebra's age.
     * Could lead to the zebra's death.
     */
    protected void incrementAge() {
        ++this.age;
        if (this.age > MAX_AGE) {
            this.setDead();
        }
    }

    /**
     * Give birth to new zebras.
     * @param newZebras A list of newborn zebras.
     */
    private void giveBirth(List<Animal> newZebras) {
        Field field = this.getField();
        List<Location> free = field.getFreeAdjacentLocations(this.getLocation());
        int births = this.breed();
        for(int b = 0; b < births && free.size() > 0; ++b) {
            Location loc = (Location)free.remove(0);
            Zebra young = new Zebra(false, field, loc);
            newZebras.add(young);
        }
    }

    /**
     * Determine how many young a zebra will give birth to.
     * @return The number of young the zebra will give birth to.
     */
    private int breed() {
        int births = 0;
        List<Animal> candidate = this.getField().maleMate(this.getLocation());
        for (Animal animal : candidate) {
            if (this.canBreed() && animal instanceof Zebra && rand.nextDouble() <= BREEDING_PROBABILITY) {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            }
        }
        return births;
    }

    /**
     * Check if the zebra can breed.
     * They can only breed if they are above a certain age and they
     * are female.
     * @return True if the zebra can breed, false otherwise.
     */
    private boolean canBreed() {
        return this.age >= BREEDING_AGE && !this.isMale;
    }

    /** 
     * Attempt to find other zebras.
     * @return A location of nearby zebras, or null if there were none.
     */
    protected Location findPack() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Zebra) {
                return where;
            }
        }
        return null;
    }
}
