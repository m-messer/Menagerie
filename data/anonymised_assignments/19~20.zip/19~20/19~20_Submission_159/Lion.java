import java.util.List;
import java.util.Random;

/**
 * Represents a lion in the simulation.
 * Lions age, move, mate, hunt prey, eat and die.
 *
 * @version 2020.02.23
 */
public class Lion extends Predator {
    // The minimum age/number of steps in order for the lion to breed.
    private static final int BREEDING_AGE = 10;
    // The maximum age/number of steps of the lion.
    private static final int MAX_AGE = 55;
    // The probability of the lion being able to breed.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum amount of young the lion can give birth to at once.
    private static final int MAX_LITTER_SIZE = 2;
    // The amount of food a zebra gives a lion.
    private static final int ZEBRA_FOOD_VALUE = 7;
    // The amount of food a gazelle gives a lion.
    private static final int GAZELLE_FOOD_VALUE = 7;
    // A randomizer.
    private static final Random rand = Randomizer.getRandom();
    // The lion's age.
    private int age;

    /**
     * Create a new lion. A lion may be created with age 
     * zero (A new born) or with a random age.
     * 
     * @param randomAge If true, the lion will have a random age.
     * @param field The field currently being occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            this.age = rand.nextInt(MAX_AGE);
            this.foodLevel = rand.nextInt(BREEDING_AGE);
        } else {
            this.age = 0;
            this.foodLevel =GAZELLE_FOOD_VALUE;
        }
    }

    /**
     * How the lion acts at night.
     * @param newLions A list of newborn lions.
     */
    public void actNight(List<Animal> newLions) {
        this.actInfected();
        if (this.isAlive()) {
            this.giveBirth(newLions);
        }
    }

    /**
     * Increment the age of the lion.
     * Could lead to the lion's death.
     */
    protected void incrementAge() {
        ++this.age;
        if (this.age > MAX_AGE) {
            this.setDead();
        }
    }

    /**
     * Find any nearby zebras or gazelles.
     * @return The location of any nearby zebras or gazelles, or null if there are none.
     */
    protected Location findFood()   {
        Field field = this.getField();
        List<Location> adjacent = field.adjacentLocations(this.getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Prey && ((Prey) animal).isAlive()) {
                Prey prey = (Prey) animal;
                if (prey instanceof Gazelle) {
                    prey.setDead();
                    this.foodLevel += GAZELLE_FOOD_VALUE;
                    return where;
                }
                else if (prey instanceof Zebra)  {
                    prey.setDead();
                    this.foodLevel += ZEBRA_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Attempt to find other lions.
     * @return A location of nearby lions, or null if there are none.
     */
    protected Location findPack() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Lion) {
                return where;
            }
        }
        return null;
    }

    /**
     * Give birth to new lions.
     * @param newLions A list of newborn lions.
     */
    private void giveBirth(List<Animal> newLions) {
        Field field = this.getField();
        List<Location> free = field.getFreeAdjacentLocations(this.getLocation());
        int births = this.breed();
        for(int b = 0; b < births && free.size() > 0; ++b) {
            Location loc = (Location)free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }

    /**
     * Determine how many young a lion will give birth to.
     * @return The number of young the lion will give birth to.
     */
    private int breed() {
        int births = 0;
        List<Animal> candidate = this.getField().maleMate(this.getLocation());
        for (Animal animal : candidate) {
            if (this.canBreed() && animal instanceof Lion && rand.nextDouble() <= BREEDING_PROBABILITY) {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                return births;
            }
        }
        return births;
    }

    /**
     * Check if the lion can breed.
     * They can only breed if they are above a certain age and they 
     * are female.
     * @return True if the lion can breed, false otherwise.
     */
    private boolean canBreed() {
        return this.age >= BREEDING_AGE && !this.isMale;
    }
}
