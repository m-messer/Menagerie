import java.util.List;
import java.util.Random;

/**
 * Represents a gazelle in the simulation.
 * Gazelles age, move, mate, find food, eat and die.
 *
 * @version 2020.02.23
 */
public class Gazelle extends Prey {
    // The minimum age/number of steps before the gazelle can breed.
    private static final int BREEDING_AGE = 4;
    // The maximum age/number of steps of the gazelle.
    private static final int MAX_AGE = 40;
    // The maximum amount of young the gazelle can give birth to at once.
    private static final int MAX_LITTER_SIZE = 4;
    // The probability of the gazelle being able to breed.
    private static final double BREEDING_PROBABILITY = 0.12;
    // A randomizer.
    private static final Random rand = Randomizer.getRandom();
    // The age of the gazelle. 
    private int age = 0;
    
    /**
     * Create a new gazelle. A gazelle may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the gazelle will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gazelle(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            this.age = rand.nextInt(MAX_AGE);
        }
        this.foodLevel = PLANT_FOOD_VALUE;
    }

    /**
     * How the gazelle acts at night.
     * @param newGazelles A list of newborn gazelles.
     */
    public void actNight(List<Animal> newGazelles) {
        this.actInfected();
        if (this.isAlive()) {
            this.giveBirth(newGazelles);
        }
    }

    /**
     * Increment the gazelle's age.
     * This could lead to the gazelle's death.
     */
    protected void incrementAge() {
        ++this.age;
        if (this.age > MAX_AGE) {
            this.setDead();
        }
    }

    /**
     * Give birth to new gazelles.
     * @param newGazelles A list of newborn gazelles.
     */
    private void giveBirth(List<Animal> newGazelle) {
        Field field = this.getField();
        List<Location> free = field.getFreeAdjacentLocations(this.getLocation());
        int births = this.breed();
        for(int b = 0; b < births && free.size() > 0; ++b) {
            Location loc = (Location)free.remove(0);
            Gazelle young = new Gazelle(false, field, loc);
            newGazelle.add(young);
        }
    }

    /**
     * Determine how many young a gazelle will give birth to.
     * @return The number of young the gazelle will give birth to.
     */
    private int breed() {
        int births = 0;
        List<Animal> candidate = this.getField().maleMate(this.getLocation());
        for (Animal animal : candidate) {
            if (this.canBreed() && animal instanceof Gazelle && rand.nextDouble() <= BREEDING_PROBABILITY) {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
            }
        }

        return births;
    }

    /**
     * Check if the gazelle can breed.
     * They can only breed if they are above a certain age and they
     * are female.
     * @return True if the gazelle can breed, false otherwise.
     */
    private boolean canBreed() {
        return this.age >= BREEDING_AGE && !this.isMale;
    }

    /** 
     * Attempt to find other gazelles.
     * @return A location nearby gazelles, or null if there are none.
     */
    protected Location findPack() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Gazelle) {
                return where;
            }
        }
        return null;
    }
}
