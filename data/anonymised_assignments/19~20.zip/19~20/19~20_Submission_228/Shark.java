/**
 * An abstract class to define the animals of type shark more specifically.
 *
 * @version 2020 v1.0
 */
public abstract class Shark extends Animal
{
    /**
     * Constructor for objects of class Shark
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale The gender of the animal.
     */
    public Shark(Field field, Location location, boolean isFemale)
    {
        super(field, location, isFemale);
    }
     
}
