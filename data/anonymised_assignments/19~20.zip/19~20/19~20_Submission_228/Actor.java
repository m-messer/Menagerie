import java.util.*;
/**
 * A class representing shared characteristics of actors in the 
 * simulation such as animals and plants.
 *
 * @version 2020 v1.0
 */
public abstract class Actor
{
    // Whether the actor is alive or not.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    private Location location;
    // the number of steps in the simulation
    private int steps = Simulator.getSteps();
    // actor's age
    private int age;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Actor(Field field, Location location)
    {
        alive = true;
        this.field = field; 
        setLocation(location);
    }
    
    /**
     * An accessor method to return the number of steps
     * @return steps
     */
    protected int getSteps(){
        return steps;
    }
    
    /**
     * An accessor method to return the age of an actor
     * @return age
     */
    protected int getAge(){
        return age;
    }
    
    /**
     * Mutator method to set the age of an actor. Useful for constructors
     * that utilise random ages when the field is being populated.
     * @param age The age you want to set for an actor.
     */
    protected void setAge(int age){
        this.age = age;
    }
    
    /**
     * Increase the age.
     * This could result in the rabbit's death.
     * @param maxAge the value of the maximum age a rabbit can live.
     * will be a constant value from the concrete class.
     */
    protected void incrementAge(int maxAge)
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * abstract class which is implemented in the concrete classes.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newActors);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

}