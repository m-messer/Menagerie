import java.util.*;
/**
 * A class to control and set the current season and temperature within the predator/prey simulation.
 * Also to set the conditions, like if the water is murky.
 *
 * @version 2020 v1.0
 */
public class Weather
{
    // class variable storing temperature value in degrees celsius.
    private static int temperature;
    // A shared random number generator to control weather.
    private static final Random rand = Randomizer.getRandom();
    // constant list of the seasons of the simulation.
    private static final String[] seasons = {"Spring", "Summer", "Autumn", "Winter"};
    // keeping track of the current season which also dictates the temperature range.
    private static String currentSeason = seasons[0];
    // whether it is currently day or night in the simulation.
    private static boolean isDay;
    // whether the water is murky, if so, it is difficult for predators to see their prey.
    private static boolean isMurky;

    // probability constants for the water to turn murky for each season, less likely in warmer seasons.
    private static final double SUMMER_MURKY_PROBABILITY = 0.1;
    private static final double SPRING_MURKY_PROBABILITY = 0.15;
    private static final double AUTUMN_MURKY_PROBABILITY = 0.5;
    private static final double WINTER_MURKY_PROBABILITY = 0.85;

    /**
     * Static initialisation block to initialise the temperature at the start.
     */
    static
    {
        // setting the conditions initially.
        setConditions();
        // starts off with a random value of whether it is day or night.
        isDay = rand.nextBoolean();
    }
    
    /**
     * A get method to get the temperature of simulator.
     * @return temperature : the value of the field temperature is returned
     */
    public static int getTemperature()
    {
        return temperature;
    }
    
    /**
     * A get method to get the season of simulator.
     * @return currentSeason : the value of the field currentSeason is returned
     */
    public static String getSeason()
    {
        return currentSeason;
    }
    

    /**
     * A mutator method to change the season by accessing the array of seasons.
     * will change the season and reset the temperature by calling the 
     * set temperature method.
     */
    public static void changeSeason()
    {
        int currentSeasonIndex = 0;
        for(int i = 0; i < seasons.length; i++){
            if(seasons[i].equals(currentSeason)){
                currentSeasonIndex = i;
            }
        }
        currentSeason = seasons[(currentSeasonIndex + 1) % seasons.length];
        setConditions();
    }
    

    /**
     * A mutator method to set the temperature depending on what the current season is
     * within the simulator. Total temperature range of -60 to 50
     */
    public static void setConditions(){
        if(currentSeason.equals("Spring")){
            temperature = rand.nextInt(30 + 1) -40; // random temp from -10 to 20
            if(rand.nextDouble() > SPRING_MURKY_PROBABILITY){
                isMurky = true;
            }
        } 
        else if(currentSeason.equals("Summer")){
            temperature = rand.nextInt(50 + 1); // random temp from 0 to 50
            if(rand.nextDouble() > SUMMER_MURKY_PROBABILITY){
                isMurky = true;
            }
        }
        else if(currentSeason.equals("Autumn")){
            temperature = rand.nextInt(25 + 1) - 30; // random temp from -5 to -30
            if(rand.nextDouble() > AUTUMN_MURKY_PROBABILITY){
                isMurky = true;
            }
        }
        else if(currentSeason.equals("Winter")){
            temperature = rand.nextInt(40 + 1) - 60; // random temp from -20 to -60
            if(rand.nextDouble() > WINTER_MURKY_PROBABILITY){
                isMurky = true;
            }
        }
    }

    /**
     * Checks whether it is day time or not.
     * @return isDay to check if it is day.
     */
    public static boolean isDay()
    {
        return isDay;
    }

    /**
     * Checks whether the water is murky or not
     * @return isMurky
     */
    public static boolean isMurky()
    {
        return isMurky;
    }

    /**
     * Mutator method to toggle the time from day to night and vice versa.
     */
    public static void setTime()
    {
        isDay = !isDay;
    }

}