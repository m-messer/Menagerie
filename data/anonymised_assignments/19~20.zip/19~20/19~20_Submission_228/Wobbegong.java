import java.util.List;
import java.util.Random;

/**
 * A simple model of a wobbegong.
 * wobbegongs age, move, eat rabbits, and die.
 *
 * @version 2020 v1.0
 */
public class Wobbegong extends Shark
{
    // Characteristics shared by all wobbegongs (class variables).
    // The age at which a wobbegong can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a wobbegong can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a wobbegong breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single clownfish. In effect, this is the
    // number of steps a wobbegong can go before it has to eat again.
    private static final int CLOWNFISH_FOOD_VALUE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    private boolean maleFound;

    /**
     * Create a wobbegong. A wobbegong can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wobbegong will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale Whether the great white is female or not.
     */
    public Wobbegong(boolean randomAge, Field field, Location location,boolean isFemale)
    {
        super(field, location, isFemale);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(CLOWNFISH_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(CLOWNFISH_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the wobbegong does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newwobbegongs A list to return newly born wobbegongs.
     */
    public void act(List<Actor> newWobbegongs)
    {
        incrementAge(MAX_AGE);
        incrementHunger(getFoodLevel());
        if(isAlive()) {
            dealWithDisease();
            giveBirth(newWobbegongs);            
            // Move towards a source of food if found.
            Location newLocation = findFood(CLOWNFISH_FOOD_VALUE);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this wobbegong is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newwobbegongs A list to return newly born wobbegongs.
     */
    private void giveBirth(List<Actor> newWobbegongs)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(MAX_LITTER_SIZE, BREEDING_PROBABILITY, BREEDING_AGE);
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location location: adjacent){
            if(!maleFound){
                if(super.getIsFemale() && field.getObjectAt(location) != null &&field.getObjectAt(location).getClass().equals(Wobbegong.class)){
                    Wobbegong wobbegong = (Wobbegong) field.getObjectAt(location);
                    if(!(wobbegong.getIsFemale())){
                        maleFound = true;
                    }
                }
            }
        }
        if(maleFound){
            for(int b = 0; b <= births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean gender = rand.nextBoolean();
                Wobbegong young = new Wobbegong(false, field, loc, gender);
                newWobbegongs.add(young);
            }
       }
    }
        
}

