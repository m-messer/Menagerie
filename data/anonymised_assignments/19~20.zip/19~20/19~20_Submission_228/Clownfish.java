import java.util.List;
import java.util.Random;
/**
 * A simple model of a clownfish.
 * clownfish age, move, breed, and die.
 *
 * @version 2020 v1.0
 */
public class Clownfish extends Fish
{
    // Characteristics shared by all clownfish (class variables).
    // The age at which a clownfish can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a clownfish can live.
    private static final int MAX_AGE = 70;
    // The likelihood of a clownfish breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The amount of energy a plant can provide to a clownfish when eaten.
    // How many steps the clownfish can go before being hungry again.
    private static final int PLANT_FOOD_VALUE = 3;
    
    // Individual characteristics (instance fields).
    private boolean maleFound;

    /**
     * Create a new clownfish. A clownfish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the clownfish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale Whether or not the clonfish is female or not.
     */
    public Clownfish(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(field, location,isFemale);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(PLANT_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(PLANT_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the clownfish does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newclownfish A list to return newly born clownfish.
     */
    public void act(List<Actor> newClownfish)
    {
        incrementAge(MAX_AGE);
        incrementHunger(getFoodLevel());
        if(isAlive()) {
            dealWithDisease();
            giveBirth(newClownfish);            
            // Move towards a source of food if found.
            Location newLocation = findFood(PLANT_FOOD_VALUE);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this clownfish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newclownfish A list to return newly born clownfish.
     */
    private void giveBirth(List<Actor> newClownfish)
    {
        // New clownfish are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(MAX_LITTER_SIZE, BREEDING_PROBABILITY, BREEDING_AGE);
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location location: adjacent){
            if(!maleFound){
                if(super.getIsFemale() && field.getObjectAt(location)!=null &&field.getObjectAt(location).getClass().equals(Clownfish.class)){
                    Clownfish clownfish = (Clownfish) field.getObjectAt(location);
                    if(!(clownfish.getIsFemale())){
                        maleFound = true;
                    }
                }
            }
        }
        if(maleFound){
            for(int b = 0; b <= births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean gender = rand.nextBoolean();
                Clownfish young = new Clownfish(false, field, loc, gender);
                newClownfish.add(young);
            }
        }
    }
        
}

