import java.util.*;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020 v1.0
 */
public abstract class Animal extends Actor
{
    // The fields shared by all animal objects.
    // gender variable; whether the animal is female or not.
    private boolean isFemale;
    // Whether a certain animal is diseased or not.
    private boolean disease;
    // the current food level of an animal; how many steps it can go before getting hungry.
    private int foodLevel;

    // random value generator
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale The gender of the animal.
     */
    public Animal(Field field, Location location, boolean isFemale)
    {
        super(field,location);
        this.isFemale = isFemale;
        disease=false;
    }
    
    /**
     * Look for other animals or plants to be eaten in adjacent locations on the field.
     * Hammerhead and Great White sharks will both eat Starfish.
     * Wobbegongs will eat Clownfish.
     * Starfish, Clownfish and the Great White shark will all eat the plants.
     * @param foodValue A constant from the concrete class that dictates the food value of the eaten animal.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood(int foodValue)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object actor = field.getObjectAt(where);
            if(actor instanceof Starfish && 
            (this.getClass().equals(Hammerhead.class)|| this.getClass().equals(GreatWhite.class) && !Weather.isMurky())){
                Starfish starfish = (Starfish) actor;
                if(starfish.isAlive()) { 
                    starfish.setDead();
                    setFoodLevel(foodValue);
                    return where;
                }
            }
            else if(actor instanceof Clownfish && this.getClass().equals(Wobbegong.class)) {
                Clownfish clownfish = (Clownfish) actor;
                if(clownfish.isAlive()) { 
                    clownfish.setDead();
                    setFoodLevel(foodValue);
                    return where;
                }
            }
            else if(actor instanceof Plant && 
            (this.getClass().equals(Starfish.class)|| this.getClass().equals(Clownfish.class)|| this.getClass().equals(GreatWhite.class) && !Weather.isMurky())){
                Plant plant = (Plant) actor;
                if(plant.isAlive()) { 
                    plant.setDead();
                    setFoodLevel(foodValue);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Accessor method to retun the value of the foodLevel field.
     * @return The animal's current food level.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Mutator method to set the animal's current food level.
     * @param foodLevel the value of the food level of something an animal just ate or when they
     * born the maximum food value for their species.
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel+=foodLevel;
    }
    
    /**
     * Checks whether the current temperature of the simulation is too hot or too cold for the animal
     * and kills the animal if it is outside of the survivable range and returns false, or simply returns true if it
     * is a survivable temperature for the animal.
     * @param max_temp the maximum survivable temperature for the animal, set as a constant in the animal's class
     * @param min_temp the minimum survivable temperature for the animal, set as a constant in the animal's class
     * @return true or false
     */
    protected boolean checkTempViability(int max_temp, int min_temp){
        if(Weather.getTemperature() > max_temp || Weather.getTemperature() < min_temp){setDead(); return false;}
        else{return true;}

    }
    
    /**
     * Randomly changes the disease value of an animal if it doesn't have any disease.
     * @return Whether the animal now has a disease or not (T or F).
     */
    protected boolean changeDisease()
    {
        if (disease==false){
            disease = rand.nextBoolean(); 
        }
        return disease;
    }
    
    /**
     * Mutator method to simply give an animal disease indefinitely when the method is called.
     */
    protected void setDisease()
    {
        disease = true;
    }
    
    /**
     * Returns the value of the disease field to see whether or not an animal is diseased.
     * @return Whether the animal has a disease or not (T or F).
     */
    protected boolean isDiseased()
    {
        return disease;
    }

    /**
     * Infects an animal if nearby animals are diseased and if it is diseased then the disease will take 10 steps off the lifespan.
     * Otherwise it will randomly select a disease statuse for the animal.
     */
    protected void dealWithDisease(){
        if(getSteps() % 12 == 0){
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            //gets infected if nearby animal has disease
            for (Location location: adjacent){
                if (field.getObjectAt(location) != null && (field.getObjectAt(location).getClass() == (Animal.class))){
                    Animal animal = (Animal) field.getObjectAt(location);
                    if (animal.isDiseased()){
                        this.setDisease();}
                    }
            }
            if(isDiseased()){
                //this takes 10 years off the lifespan of the particular animal.
                setAge(getAge() + 10);
            }
            else{ 
                //checks if it randomly gets infected by disease by itself
                changeDisease();
            }
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @param maxLitterSize A constant value sent from a concrete class that indicates the maximum number of births.
     * @param breedingProb A constant sent from a concrete class that dictates the probability of giving birth.
     * @param breedingAge A constant sent from a concrete class that dictates at what age the animal is able to
     * @return The number of births (may be zero).
     */
    protected int breed(int maxLitterSize, double breedingProb, int breedingAge)
    {
        int births = 0;
        if(canBreed(breedingAge) && rand.nextDouble() <= breedingProb) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     * @param foodLevel The food level of the animal
     */
    protected void incrementHunger(int foodLevel)
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @param breedingAge A constant from a concrete class to indicate at what age an animal is able to breed.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed(int breedingAge)
    {
        return getAge() >= breedingAge;
    }
    
    /**
     * An accessor method for the field isFemale to tell whether or not the animal is female or not.
     */
    protected boolean getIsFemale()
    {
        return isFemale;
    }

}
