import java.util.*;
/**
 * A class to define the characteristics of the plant actor.
 *
 * @version 2020 v1.0
 */
public class Plant extends Actor
{
    // Characteristics of a plant. (class variables)
    // Maximum age a plant can live to in steps
    private static final int MAX_AGE = 10;
    // The rate at which plants will spawn/grow
    private static final double GROWTH_RATE = 0.1;
    // The maxmimum number of plants that can spawn at once
    private static final int MAX_PLANT_SPAWNS = 14;
    // A shared random number generator to control spawning.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Constructor for objects of class Plant
     * @param randomAge If true, the plant will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        }
        else {
            setAge(0);
        }
    }

    /**
     * This is what the plant does. It will just keep growing if alive.
     * @param newPlants A list to return newly spawned plants.
     */
    public void act(List<Actor> newPlants)
    {
        incrementAge(MAX_AGE);
        if(isAlive()) {
            growth(newPlants);  
        }
        
    }
    
    /**
     * Generate a number representing the number of spawns,
     * if it can spawn more plants.
     * @return The number of spawns (may be zero).
     */
    protected int spawn()
    {
        int spawns = 0;
        if(rand.nextDouble() <= GROWTH_RATE) {
            spawns = rand.nextInt(MAX_PLANT_SPAWNS) + 1;
        }
        return spawns;
    }
    
    /**
     * @param newPlants A list to return newly spawned plants.
     */
    private void growth(List<Actor> newPlants)
    {
        Field field = getField();
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = spawn();
        // New plants are spawned into adjacent locations.
        for(int b = 0; b <= births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false,field, loc);
            newPlants.add(young);
        }
    }
}
