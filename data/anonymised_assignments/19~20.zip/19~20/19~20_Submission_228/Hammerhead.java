import java.util.List;
import java.util.Random;

/**
 * A simple model of a hammerhead.
 * hammerheads age, move, eat rabbits, and die.
 *
 * @version 2020 v1.0
 */
public class Hammerhead extends Shark
{
    // Characteristics shared by all hammerheads (class variables).
    // The age at which a hammerhead can start to breed.
     private static final int BREEDING_AGE = 6;
    // The age to which a hammerhead can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a hammerhead breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The food value of a single starfish. In effect, this is the
    // number of steps a hammerhead can go before it has to eat again.
    private static final int STARFISH_FOOD_VALUE = 50;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The maximum survivable temperature for the hammerhead.
    private static final int MAX_TEMPERATURE = 25;
    // The minimum survivable temperature for the hammerhead.
    private static final int MIN_TEMPERATURE = -55;
    
    // Individual characteristics (instance fields).
    private boolean maleFound;

    /**
     * Create a hammerhead. A hammerhead can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hammerhead will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale Whether the great white is female or not.
     */
    public Hammerhead(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(field, location, isFemale);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(STARFISH_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(STARFISH_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the hammerhead does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newhammerheads A list to return newly born hammerheads.
     */
    public void act(List<Actor> newHammerheads)
    {
        incrementAge(MAX_AGE);
        incrementHunger(getFoodLevel());
        // check if alive and if it can survive the current temperature. If it can't it won't be able
        // to act and will hence die pretty soon after this.
        if(isAlive() && checkTempViability(MAX_TEMPERATURE, MIN_TEMPERATURE)) {
            dealWithDisease();
            giveBirth(newHammerheads);            
            // Move towards a source of food if found.
            Location newLocation = findFood(STARFISH_FOOD_VALUE);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    } 
    
    /**
     * Check whether or not this hammerhead is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newhammerheads A list to return newly born hammerheads.
     */
    private void giveBirth(List<Actor> newHammerheads)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(MAX_LITTER_SIZE, BREEDING_PROBABILITY, BREEDING_AGE);
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location location: adjacent){
            if(!maleFound){
                if(super.getIsFemale() && field.getObjectAt(location) != null &&field.getObjectAt(location).getClass().equals(Hammerhead.class)){
                    Hammerhead hammerhead = (Hammerhead) field.getObjectAt(location);
                    if (!(hammerhead.getIsFemale())){
                        maleFound = true;
                    }
                }
            }
        }
        if(maleFound){
            for(int b = 0; b <= births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean gender = rand.nextBoolean();
                Hammerhead young = new Hammerhead(false, field, loc, gender);
                newHammerheads.add(young);
            }
       }
    }
        
}
