import java.util.List;
import java.util.Random;
/**
 * A simple model of a starfish.
 * Starfish age, move, breed, and die.
 *
 * @version 2020 v1.0
 */
public class Starfish extends Fish
{
    // Characteristics shared by all starfish (class variables).
    // The age at which a starfish can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a starfish can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a starfish breeding.
    private static final double BREEDING_PROBABILITY = 0.9;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single starfish. In effect, this is the
    // number of steps a great white can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 15;
    // The maximum survivable temperature for the starfish.
    private static final int MAX_TEMPERATURE = 40;
    // The minimum survivable temperature for the starfish.
    private static final int MIN_TEMPERATURE = -50;
    
    // Individual characteristics (instance fields).
    private boolean maleFound;
    private boolean isAwake;

    /**
     * Create a new starfish. A starfish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the starfish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale Whether the great white is female or not.
     */
    public Starfish(boolean randomAge, Field field, Location location, boolean isFemale)
    {
        super(field, location,isFemale);
        isAwake = true;
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(PLANT_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(PLANT_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the starfish does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newstarfish A list to return newly born starfish.
     */
    public void act(List<Actor> newStarfish)
    {
        incrementAge(MAX_AGE);
        incrementHunger(getFoodLevel());
        // nocturnal so sleeps during the day and is awake during the night.
        if (Weather.isDay()) {
             isAwake = false;
        }
        // check if alive and if it can survive the current temperature. If it can't it won't be able
        // to act and will hence die pretty soon after this.
        if(isAlive( ) && isAwake && checkTempViability(MAX_TEMPERATURE, MIN_TEMPERATURE)) {
            dealWithDisease();
            giveBirth(newStarfish);            
            // Try to move into a free location.
            Location newLocation = findFood(PLANT_FOOD_VALUE);
            if(newLocation == null) { 
                 // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    
    /**
     * Check whether or not this starfish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newStarfish A list to return newly born starfish.
     */
    private void giveBirth(List<Actor> newStarfish)
    {
        // New starfish are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(MAX_LITTER_SIZE, BREEDING_PROBABILITY, BREEDING_AGE);
        List<Location> adjacent = field.adjacentLocations(getLocation());
        maleFound = false;
        for(Location location: adjacent){
            if(!maleFound){
                if(super.getIsFemale() && field.getObjectAt(location) != null &&field.getObjectAt(location).getClass().equals(Starfish.class)){
                    Starfish starfish = (Starfish) field.getObjectAt(location);
                    if(!(starfish.getIsFemale())){
                        maleFound = true;
                    }
                }
            }
        }
        if(maleFound){
            for(int b = 0; b <= births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean gender = rand.nextBoolean();
                Starfish young = new Starfish(false, field, loc, gender);
                newStarfish.add(young);
            }
       }
    }
    
}
