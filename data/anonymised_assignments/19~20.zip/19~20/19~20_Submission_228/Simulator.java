import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing different species of sharks, fishes and some plants.
 *
 * @version 2020 v1.0
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a hammerhead will be created in any given grid position.
    private static final double HAMMERHEAD_CREATION_PROBABILITY = 0.02;
    // The probability that a starfish will be created in any given grid position.
    private static final double STARFISH_CREATION_PROBABILITY = 0.05;
    // The probability that a great white will be created in any given grid position.
    private static final double GREATWHITE_CREATION_PROBABILITY = 0.1;
    // The probability that a wobbegong will be created in any given grid position.
    private static final double WOBBEGONG_CREATION_PROBABILITY = 0.08;
    // The probability that a clownfish will be created in any given grid position.
    private static final double CLOWNFISH_CREATION_PROBABILITY = 0.08;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.003;
    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private static int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Main method to run the simulation with a default grid size for 1000 steps.
     * @param args
     */
    public static void main(String[] args){
        Simulator simulator = new Simulator();
        simulator.simulate(1000);
    }
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Returns the value of the class field step which as the current step of the simulation.
     * @return current step of the simulation.
     */
    public static int getSteps(){
        return step;
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Starfish.class, Color.ORANGE);
        view.setColor(Hammerhead.class, Color.BLUE);
        view.setColor(GreatWhite.class, Color.RED);
        view.setColor(Wobbegong.class, Color.PINK);
        view.setColor(Clownfish.class, Color.YELLOW);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            Weather.setConditions(); // changing the temperature and if it is murky or not every step.
            // changing season every 15 steps, and calling the fishing season method for a fishing season to occur.
            if (step % 10 == 0){
                Weather.changeSeason();
                field.fishingSeason();
            }
            // toggling day or night every 2 steps.
            if (step % 2 == 0){
                Weather.setTime();
            }
            // delay(10); // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        //field.fishingSeason();
        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>(); 
        // Let all rabbits act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            
            Actor actor = it.next();
            actor.act(newActors);
            if(! actor.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born foxes and rabbits to the main lists.
        actors.addAll(newActors);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                boolean gender = rand.nextBoolean();
                Location location = new Location(row, col);
                if(rand.nextDouble() <= HAMMERHEAD_CREATION_PROBABILITY) {
                    Hammerhead hammerhead = new Hammerhead(true, field, location,gender);
                    actors.add(hammerhead);
                }
                else if(rand.nextDouble() <= STARFISH_CREATION_PROBABILITY) {
                    Starfish starfish = new Starfish(true, field, location,gender);
                    actors.add(starfish);
                }
                else if(rand.nextDouble() <= GREATWHITE_CREATION_PROBABILITY) {
                    GreatWhite greatWhite = new GreatWhite(true, field, location,gender);
                    actors.add(greatWhite);
                }
                else if(rand.nextDouble() <= WOBBEGONG_CREATION_PROBABILITY) {
                    Wobbegong wobbegong = new Wobbegong(true, field, location,gender);
                    actors.add(wobbegong);
                }
                else if(rand.nextDouble() <= CLOWNFISH_CREATION_PROBABILITY) {
                    Clownfish clownfish = new Clownfish(true, field, location,gender);
                    actors.add(clownfish);
                }
                else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Plant plant = new Plant(true,field, location);
                    actors.add(plant);
                }
                // else leave the location empty.
            }
        }
        
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
