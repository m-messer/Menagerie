import java.util.List;
import java.util.Random;

/**
 * A simple model of a Great White Shark.
 * They age, move, eat rabbits, and die.
 *
 * @version 2020 v1.0
 */
public class GreatWhite extends Shark
{
    // Characteristics shared by all great whites (class variables).
    
    // The age at which a great white can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a great white can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a great white breeding.
    private static final double BREEDING_PROBABILITY = 0.01;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single starfish. In effect, this is the
    // number of steps a great white can go before it has to eat again.
    private static final int STARFISH_PLANT_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The maximum survivable temperature for the great white.
    private static final int MAX_TEMPERATURE = 35;
    // The minimum survivable temperature for the great white.
    private static final int MIN_TEMPERATURE = -40;
    
    // Individual characteristics (instance fields).
    private boolean maleFound;

    /**
     * Create a great white. A great white can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the greatwhite will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale Whether the great white is female or not.
     */
    public GreatWhite(boolean randomAge, Field field, Location location,boolean isFemale)
    {
        super(field, location,isFemale);
        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(STARFISH_PLANT_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(STARFISH_PLANT_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the great white does most of the time: it hunts for
     * starfish. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newgreatwhites A list to return newly born greatwhites.
     */
    public void act(List<Actor> newGreatWhites)
    {
        incrementAge(MAX_AGE);
        incrementHunger(getFoodLevel());
        // check if alive and if it can survive the current temperature. If it can't it won't be able
        // to act and will hence die pretty soon after this.
        if(isAlive() && checkTempViability(MAX_TEMPERATURE, MIN_TEMPERATURE)) {
            dealWithDisease();
            giveBirth(newGreatWhites);            
            // Move towards a source of food if found.
            Location newLocation = findFood(STARFISH_PLANT_FOOD_VALUE);
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this greatwhite is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newgreatwhites A list to return newly born greatwhites.
     */
    private void giveBirth(List<Actor> newGreatWhites)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(MAX_LITTER_SIZE, BREEDING_PROBABILITY, BREEDING_AGE);
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for(Location location: adjacent){
            if(!maleFound){
                if (super.getIsFemale() && field.getObjectAt(location) != null &&field.getObjectAt(location).getClass().equals(GreatWhite.class)){
                    GreatWhite greatWhite = (GreatWhite) field.getObjectAt(location);
                    if (!(greatWhite.getIsFemale())){
                        maleFound = true;
                    }
                }
            }
        }
        if(maleFound){
            for(int b = 0; b <= births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                boolean gender = rand.nextBoolean();
                GreatWhite young = new GreatWhite(false, field, loc, gender);
                newGreatWhites.add(young);
            }
        }
    }
        
}
