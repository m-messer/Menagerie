/**
 * An abstract class to define the animals of type fish more specifically.
 *
 * @version 2020 v1.0
 */
public abstract class Fish extends Animal
{
    /**
     * Constructor for objects of class Fish
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param isFemale The gender of the animal.
     */
    public Fish(Field field, Location location, boolean isFemale)
    {  
         super(field, location, isFemale);
    }
    
}
