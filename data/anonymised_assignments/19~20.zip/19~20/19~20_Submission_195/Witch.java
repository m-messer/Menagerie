import java.util.*;
/**
 * A simple model of a Witch.
 * Witches age, move, breed, and die.
 * Witches do not get eaten by any other species
 *
 * @version 2020.02.23
 */
public class Witch extends Creature
{
    // Characteristics shared by all witches (class variables).

    // The age at which a witch can start to breed.
    private static final int BREEDING_AGE = 40;
    // The age to which a witch can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a witch breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    private static final double  DISEASE_PROBABILITY = 0.9; 

    // Individual characteristics (instance fields).    
    // The witches age.
    private int age;

    /**
     * Create a new witch. A witch may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the witch will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Witch(boolean randomAge, Field field, Location location)
    {
        super(field, location, false);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }

    }

    /**
     * This is what the witch does most of the time - it runs 
     * around infecting HumanEaters. Sometimes it will breed or die of old age.
     * @param newWitches A list to return newly born witches.
     */
    public void act(List<Creature> newWitches)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newWitches); 
            infect();           
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation(), this);
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Checks to see if there is a HumanEater in the surrounding locations,
     * if there is then set them as dead.
     */
    private void infect()
    {

        if(rand.nextDouble() <= DISEASE_PROBABILITY){
            for(Location location :getField().adjacentLocations(getLocation()))
            {
                Object object= getField().getObjectAt(location);
                if(object instanceof HumanEater)
                {
                    HumanEater humanEater= (HumanEater) object;
                    humanEater.setDead();
                }
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the witch's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Give birth to a new Witch
     * @param newWitch A list to return newly born witches.
     * @param loc the location of the newly born
     * */
    public void birthToWho(List<Creature> newWitch, Location loc)
    {        
        Witch young = new Witch(false, getField(), loc);
        newWitch.add(young);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A witch can breed if it has reached the breeding age.
     * @return true if the witch can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}