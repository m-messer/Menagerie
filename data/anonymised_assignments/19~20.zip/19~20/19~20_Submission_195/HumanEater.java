import java.util.*;
/**
 * A class representing shared characteristics of creatures that eat humans.
 * Human eaters age, move, eat humans, and die.
 *
 * @version 2020.02.23
 */
public abstract class HumanEater extends Creature
{
    // Characteristics shared by all human eateres (class variables).

    // The age at which a human eater can start to breed.
    private static final int BREEDING_AGE = 45;
    // The age to which a human eater can live to.
    private static final int MAX_AGE = 200;
    // The likelihood of a human eater breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single human. In effect, this is the
    // number of steps a human eater can go before it has to eat again.
    private static final int HUMAN_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The human eater's age.
    private int age;
    // The human eater's food level, which is increased by eating humans.
    private int foodLevel;

    /**
     * Create a human eater at a location in field.
     * 
     * @param randomAge If true, the human eater will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public HumanEater(boolean randomAge, Field field, Location location)
    {
        super(field, location, false);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(HUMAN_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = HUMAN_FOOD_VALUE;
        }
    }

    /**
     * This is what the human eater does most of the time: it hunts for
     * humans. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newHumanEateres A list to return newly born human eateres.
     */
    public void act(List<Creature> newHumanEaters)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHumanEaters);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation(), this);
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age. This could result in the human eater's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Makes the human eater more hungry. This could result in the human 
     * eater's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for humans adjacent to the current location.
     * Only the first live human is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Human) {
                Human human = (Human) creature;
                if(human.isAlive()) { 
                    human.setDead();
                    foodLevel = HUMAN_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A human eater can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

}