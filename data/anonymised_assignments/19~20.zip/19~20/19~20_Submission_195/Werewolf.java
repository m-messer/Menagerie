

import java.util.*;
/**
 * A simple model of a Werewolf.
 * Werewolves age, move, breed, and die.
 *
 * @version 2020.02.23
 */ 
public class Werewolf extends HumanEater
{
    /**
     * Create a new werewolf. A werewolf may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the werewolf will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Werewolf(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location);
    }
    
    /**   
     * Give birth to a new Werewolf
     * @param newWerewolf A list to return newly born werewolves.
     * @param loc the location of the newly born
     */
    public void birthToWho(List<Creature> newWerewolf, Location loc)
    {        
            Werewolf young = new Werewolf(false, getField(), loc);
            newWerewolf.add(young);
     }
}