import java.util.*;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing humans, human eateres and fishes.
 *
 * @version 2020.02.23
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The default depth of the river.
    private static final int DEFAULT_RIVER_END=20;
    // The value of the depth if the river
    private static int riverEnd;
    // The probability that a humans will be created in any given grid position.
    private static final double HUMAN_CREATION_PROBABILITY = 0.4;
    // The probability that each human eater will be created in any given grid position.
    private static final double  VAMPIRE_CREATION_PROBABILITY = 0.009;    
    private static final double  WEREWOLF_CREATION_PROBABILITY = 0.007;  
    private static final double  HYBRID_CREATION_PROBABILITY = 0.007;
    // The probability that a witch will be created in any given grid position.
    private static final double  WITCH_CREATION_PROBABILITY = 0.003; 
    // The probability that a fish will be created in any given grid position.
    private static final double  FISH_CREATION_PROBABILITY = 0.05; 
    // List of creatures in the field.

    private List<Creature> creatures;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private Integer step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // To check the time of day
    private Setting setting;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH, DEFAULT_RIVER_END);
    }

    /**
     * Create a simulation field with the given size.
     * Sets colors for each creature.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * @param endOfRiver Depth of the river. Must be greater than zero.
     */
    public Simulator(int depth, int width, int endOfRiver)
    {
        if(width <= 0 || depth <= 0 || endOfRiver<=0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH; 
            riverEnd=DEFAULT_RIVER_END;
        }
        else{
            riverEnd= endOfRiver;
        }

        creatures = new ArrayList<>();
        field = new Field(depth, width, riverEnd);
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, riverEnd);
        view.setColor(Human.class, Color.ORANGE);
        view.setColor(Vampire.class, Color.BLUE);
        view.setColor(Werewolf.class, Color.GREEN);
        view.setColor(Hybrid.class, Color.RED);
        view.setColor(Witch.class, Color.MAGENTA);
        view.setColor(Fish.class, Color.YELLOW);

        setting= new Setting(view);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(30);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * human eater and human .
     */
    public void simulateOneStep()
    {
        step++;
        setting.timeOfDay(step);
        // Provide space for newborn animals.
        List<Creature> newCreatures = new ArrayList<>();        
        // Let all human s act.
        String weather= setting.getWeather();

        for(Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {
            Creature creature = it.next();            
            if(creature instanceof Vampire)
            {
                if(weather.equals("Foggy")){
                    creature.act(newCreatures);
                }
                else if(setting.isNightTime(step))
                {
                    creature.act(newCreatures);
                }
                else{
                    //do nothing
                }
            }
            else if(creature instanceof Human && weather.equals("Rainy")){
                //do nothing
            }
            else{
                creature.act(newCreatures);
            }

            if(! creature.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born human eateres and human s to the main lists.
        creatures.addAll(newCreatures);

        view.showStatus(step, field);

    }

    /**
     * Reset the simulation to a  starting position.
     */
    public void reset()
    {
        creatures.clear();
        populate();
        step=0;
        setting.timeOfDay(step);
        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * This is used to store the fishes within the river into a list of 
     * type Creature.
     */
    private List<Creature> getRiverCreatures()
    {
        List<Creature> riverCreatures= new ArrayList();
        for(Creature creature: creatures)
        {
            if(creature.isRiverCreature())
            {
                riverCreatures.add(creature);
            }
        }
        return riverCreatures;
    }

    /**
     * Clears the field and populates the land and river with creatures.
     */
    private void populate()
    {
        field.clear();
        populateLand();
        populateRiver();
    }

    /**
     * Randomly populate the field with Fish.
     */
    private void populateRiver()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < riverEnd; row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FISH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, riverEnd);
                    Fish fish = new Fish(true, field, location);
                    creatures.add(fish);
                }
            }
        }
    }
    
    /**
     * Randomly populate the field with Humans and Human Eaters.
     */
    private void populateLand()
    {
        Random rand = Randomizer.getRandom();
        for(int row = riverEnd; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HUMAN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, riverEnd);
                    Human human = new Human(true, field, location);
                    creatures.add(human);
                }
                else if(rand.nextDouble() <= VAMPIRE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, riverEnd);
                    Vampire vampire = new Vampire(true, field, location);
                    creatures.add(vampire);
                }
                else if(rand.nextDouble() <= WEREWOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, riverEnd);
                    Werewolf werewolf = new Werewolf(true, field, location);
                    creatures.add(werewolf);
                }
                else if(rand.nextDouble() <= HYBRID_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, riverEnd);
                    Hybrid hybrid = new Hybrid(true, field, location);
                    creatures.add(hybrid);
                }
                else if(rand.nextDouble() <= WITCH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, riverEnd);
                    Witch witch = new Witch(true, field, location);
                    creatures.add(witch);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
