import java.util.*;
/**
 * A simple model of a Vampire.
 * Vampires age, move, breed, and die.
 *
 * @version 2020.02.23
 */
public class Vampire extends HumanEater
{
    /**
     * Create a new vampire. A vampire may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the vampire will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Vampire(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location);
    }
    
    /**
     * Give birth to a new Vampire
     * @param newVampire A list to return newly born vampires.
     * @param loc the location of the newly born
     */
    public void birthToWho(List<Creature> newVampire, Location loc)
    {        
            Vampire young = new Vampire(false, getField(), loc);
            newVampire.add(young);
     }
    }

