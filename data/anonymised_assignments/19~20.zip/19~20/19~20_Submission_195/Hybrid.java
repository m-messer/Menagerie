import java.util.*;
/**
 * A simple model of a Hybrid.
 * Hybrids age, move, breed, and die.
 *
 * @version 2020.02.23
 */
public class Hybrid extends HumanEater
{
    /**
     * Create a new hybrid. A hybrid may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the hybrid will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hybrid(boolean randomAge, Field field, Location location)
    {
        super(randomAge,field,location);
    }

    /**
     * Give birth to a new Hybrid
     * @param newHybrid A list to return newly born hybrids.
     * @param loc the location of the newly born
     * */
    public void birthToWho(List<Creature> newHybrid, Location loc)
    {        
            Hybrid young = new Hybrid(false, getField(), loc);
            newHybrid.add(young);
     }
}
