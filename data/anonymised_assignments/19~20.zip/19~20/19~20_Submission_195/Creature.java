import java.util.*;

/**
 * A class representing shared characteristics of creatures.
 *
 * @version 2020.02.23
 */
public abstract class Creature
{
    // Whether the creature is alive or not.
    protected boolean alive;
    // The creature's field.
    private Field field;
    // The creature's position in the field.
    private Location location;
    
    protected String weather;
    private static final Random rand = Randomizer.getRandom();
    private boolean riverCreature= false;

    /**
     * Create a new creature at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Creature(Field field, Location location, boolean isRiverCreature)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        riverCreature= isRiverCreature;
    }
    
    public boolean isRiverCreature()
    {
        return riverCreature;
    }

    /**
     * Makes the creatures act - that is: make it do
     * whatever it wants/needs to do.
     * @param newCreatures A list to receive newly born creatures.
     */
    abstract public void act(List<Creature> newCreatures);

    /**
     * Check whether the creature is alive or not.
     * @return true if the creature is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the creature is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the creature's location.
     * @return The creature's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the creature at the new location in the given field.
     * @param newLocation The creature's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
        /**
     * Makes the human eater give birth
     * @param newHumanEaters A list to return newly born human eateres.
     */
    protected void giveBirth(List<Creature> newCreatures){
        // New human eateres are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), this);
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {          
            Location loc = free.remove(0);
            birthToWho(newCreatures, loc);
        }
    }
    
    /** 
     * Checks whether the creature can breed;
     */
    abstract protected int breed();
    
    /**
     * Give birth to a new creature
     * @param newCreatures A list to return newly born human eaters.
     * @param loc the location of the newly born
     */
    public abstract void birthToWho(List<Creature> newCreatures, Location loc);

    /**
     * Return the creature's field.
     * @return The creature's field.
     */
    protected Field getField()
    {
        return field;
    }
}
