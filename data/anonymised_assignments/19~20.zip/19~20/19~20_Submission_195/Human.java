import java.util.*;

/**
 * A simple model of a Human.
 * Humans age, move, breed, and die.
 *
 * @version 2020.02.23
 */
public class Human extends Creature
{
    // Characteristics shared by all humans (class variables)

    // The age at which a human can start to breed.
    private static final int BREEDING_AGE = 17;
    // The age to which a human can live to.
    private static final int MAX_AGE = 90;
    // The likelihood of a human breeding.
    private static final double BREEDING_PROBABILITY = 0.99;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 12;
    // The food value of a single human. In effect, this is the
    // number of steps a human eater can go before it has to eat again.
    private static final int FISH_FOOD_VALUE = 100;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The human's age.
    private int age;
    // Whether the human is a woman or not.
    private boolean isWoman;
    // The human eater's food level, which is increased by eating humans.
    private int foodLevel;
    /**
     * Create a new human. A human may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the human will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Human(boolean randomAge, Field field, Location location)
    {
        super(field, location, false);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FISH_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FISH_FOOD_VALUE;
        }
        isWoman = rand.nextBoolean();
    }

    /**
     * This is what the humans do most of the time - they move 
     * around. Sometimes they will breed with the opposite gender or 
     * die of old age.
     * @param newHumans A list to return newly born humans.
     */
    public void act(List<Creature> newHumans)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHumans);            
            // Move towards a source of food if found.
            findFood();
            Location newLocation = getField().freeAdjacentLocation(getLocation(), this);
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the human's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Determines whether the adjacent location has a male in it or not
     * for the purpose of breeding.
     * @return true if there is a male next the woman, false otherwise.
     */
    private boolean hasMate()
    {
        Field field = getField();
        for(Location location :field.adjacentLocations(getLocation()))
        {
            Object object= field.getObjectAt(location);
            if(object instanceof Human && (((Human)object).isWoman != this.isWoman))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Check whether or not this human is to give birth at this step and
     * checks whether there is a male in the occupied adjacent locations to
     * breed with.
     * New births will be made into free adjacent locations.
     * @param newHumans A list to return newly born humans.
     */
    protected void giveBirth(List<Creature> newHumans)
    {        
        if(hasMate())
        {
            super.giveBirth(newHumans);
        }
    }

    /**
     * Give birth to a new Human
     * @param newHuman A list to return newly born humans.
     * @param loc the location of the newly born
     * */
    public void birthToWho(List<Creature> newHuman, Location loc)
    {        
        Human young = new Human(false, getField(), loc);
        newHuman.add(young);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A human can breed if it has reached the breeding age.
     * @return true if the human can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Makes the human eater more hungry. This could result in the human 
     * eater's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for fish adjacent to the current location.
     * Only the first live fish is eaten.
     */
    private void findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Fish) {
                Fish fish = (Fish) creature;
                if(fish.isAlive()) { 
                    fish.setDead();
                    foodLevel = FISH_FOOD_VALUE;
                }
            }
        }
    }
}