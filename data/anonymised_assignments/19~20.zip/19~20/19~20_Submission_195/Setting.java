import java.util.*;

/**
 * A class responsible for all the different settings that the field could
 * have.
 * This includes change in weather and change between night and day.
 *
 * @version 2020.02.23
 */
public class Setting
{   
    //The likelihood of fog.
    private static final double  FOGGY_PROBABILITY = 0.6; 
    //The likelihood of rain.
    private static final double  RAINY_PROBABILITY = 0.3;
    
    // A graphical view of the simulation.
    private static SimulatorView view;
    // To store the weather of the simulation.
    private String currentWeather="";

    /**
     * Creates settings for the field.
     * @param simulatorView The simulator view in which allows the  
     * settings to be implemented.
     */
    public Setting(SimulatorView simulatorView)
    {
        view = simulatorView;
    }

    /**
     * Return depending on whether it is night or not.
     * @param step Which iteration step it is.
     * @return true if modulus of the steps is more then 12, false otherwise.
     */
    public boolean isNightTime(int step)
    {
        int number=step;
        if(number%24>=12)
        { 
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Checks if it is night time and makes the stimulation background
     * turn black if it is. 
     * Or else it will stay white.
     * Using methods in the StimulatorView
     * @param step Which iteration step it is.
     */
    public void timeOfDay(int step)
    {
        int number=step;
        if(isNightTime(number))
        {
            view.makeNight();
        }
        else{
            view.makeDay();
            setWeather(step);
        }
    }

    /**
     * Randomly sets the weather of the land part of the field.
     * @param step Which iteration step it is.
     */
    public void setWeather(int step)
    {
        Random rand = Randomizer.getRandom();
        double random= rand.nextDouble();
        if(random <= RAINY_PROBABILITY) {
            view.makeRainy();
            currentWeather = "Rainy";
        }
        else if(random <= FOGGY_PROBABILITY) {
            view.makeFoggy();
            currentWeather = "Foggy";
        }
        else{
            currentWeather= "";
        }
    }

    /**
     * @returns the weather curretly occuring on the field.
     */
    public String getWeather()
    {    
        return currentWeather;
    }
}
