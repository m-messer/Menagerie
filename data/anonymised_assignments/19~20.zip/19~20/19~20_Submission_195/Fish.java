import java.util.List;
import java.util.Random;

/**
 * A simple model of a Fish.
 * Fishes age, move, breed, and die.
 *
 * @version 2020.02.23
 */
public class Fish extends Creature
{
    // Characteristics shared by all fishes (class variables)

    // The age at which a fish can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a fish can live to.
    private static final int MAX_AGE = 9;
    // The likelihood of a fish breeding.
    private static final double BREEDING_PROBABILITY = 0.17;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The fishes age.
    private int age;
    /**
     * Create a new fish. A fish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the fish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fish(boolean randomAge, Field field, Location location)
    {
        super(field, location, true);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the fishes do most of the time - they move 
     * around. Sometimes they will breed with the opposite gender or 
     * die of old age.
     * @param newFishes A list to return newly born fishes.
     */
    public void act(List<Creature> newFishes)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newFishes);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation(), this);
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the fishes death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Give birth to a new Fish
     * @param newFish A list to return newly born fishes.
     * @param loc the location of the newly born
     * */
    public void birthToWho(List<Creature> newFish, Location loc)
    {        
            Fish young = new Fish(false, getField(), loc);
            newFish.add(young);
     }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A fish can breed if it has reached the breeding age.
     * @return true if the fish can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}