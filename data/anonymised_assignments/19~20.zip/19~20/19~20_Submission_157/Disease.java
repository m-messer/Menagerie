import java.util.Random;

/**
 * This class represents disease in the simulation and
 * displays its effectiveness by the duration the disease
 * lasts for.
 *
 */
public class Disease
{
    //Initialises a random.
    private Random random = new Random();
    //The duration in time.
    private Time duration;

    /**
     * An empty constructor that creates a disease with a random
     * duration of max 2 hours.
     */
    public Disease()
    {
        duration = new Time(random.nextInt(2));
    }

    /**
     * Initialises the duration of the disease by its given parameter.
     */
    public Disease(Time duration)
    {
        this.duration = duration;
    }

    /**
     * @return Returns the duration.
     */
    public Time getDuration()
    {
        return duration;
    }

    /**
     * Decrements the duration by one.
     */
    public void decrementDuration()
    {
        duration.decrementTime();
    }
}
