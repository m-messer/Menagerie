import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an orc.
 * Orcs age, move, eat humans, dogs and mystic plants, and die.
 * 
 */
public class Orc extends GenderedSpecie
{
    // In essence how many steps an orc can move without dying from starvation.
    private final int FOOD_VALUE;
    // The orc's food level, which is increased by eating its prey.
    private int foodLevel;

    /**
     * Create an orc. An orc can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the orc will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Orc(boolean randomAge, Field field, Location location)
    {
        super(field, location, 18, 275, 0.2, 4);
        FOOD_VALUE = 75;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }
    
    /**
     * This is what the orc does most of the time: it hunts for
     * its prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newOrcs list to return newly born orcs.
     * @param step The number of steps in the simulator.
     */
    public void act(List<Species> newOrcs, int step)
    {
        deathFromDisease();
        if (isAlive()) {
            if(!getField().getTime().isDay()) {
                giveBirth(newOrcs);
                // Move towards a source of food if found.
                if (getField().getWeather().getCurrentWeather().equals("Drought")) {
                    if (step % 2 == 0) {
                        findNewLocation();
                        incrementAge();
                        incrementHunger();
                    }
                }
                else if (getField().getWeather().getCurrentWeather().equals("Icy")) {
                    if (step % 4 == 0) {
                        findNewLocation();
                        incrementAge();
                        incrementHunger();
                    }
                }
                else {
                    findNewLocation();
                    incrementAge();
                    incrementHunger();
                }
            }
        }
    }

    /**
     * Finds a new location by looking for food in the adjacent locations
     * and also checks if it can be infected once a location is found.
     */
    private void findNewLocation()
    {
        Location newLocation = findFood();
        if(newLocation == null) {
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
            beInfected();
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Make this orc more hungry. This could result in the orc's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for orcs adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof Eagle || species instanceof MysticPlant || 
            species instanceof Human) {
                Species animal = (Species) species;
                if(animal.isAlive()) { 
                    animal.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this orc is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrcs A list to return newly born orcs.
     */
    private void giveBirth(List<Species> newOrcs)
    {
        // New orcs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof Orc) {
                Orc orc = (Orc) species;
                if(orc.isMale() != orc.isMale()) { 
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Orc young = new Orc(false, field, loc);
                        newOrcs.add(young);
                    }
                }
            }
        }
    }
}
