import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 * 
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static Color EMPTY_COLOR = Color.white;
    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String WEATHER_PREFIX = "Weather: ";
    private final String TIME_PREFIX = "Time: ";
    //Labels for stats being displayed
    private JLabel stepLabel, population, timeLabel, humanLabel, orcLabel,
            dragonLabel, dogLabel, eagleLabel, mysticLabel, weather;
    private FieldView fieldView;

    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;
    // A statistics object computing and storing simulation information
    private FieldStats stats;

    private SwingWorker<Void, Void> worker;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width, Simulator simulator)
    {
        //initialise the variables stats and colors
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        //Initialise the labels
        setTitle("Fantasy World Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        timeLabel = new JLabel(TIME_PREFIX, JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        weather = new JLabel(WEATHER_PREFIX, JLabel.CENTER);

        humanLabel = new JLabel("Humans", JLabel.CENTER);
        humanLabel.setOpaque(true);
        humanLabel.setBackground(Color.ORANGE);

        dragonLabel = new JLabel("Dragons", JLabel.CENTER);
        dragonLabel.setForeground(Color.WHITE);
        dragonLabel.setOpaque(true);
        dragonLabel.setBackground(Color.RED);

        orcLabel = new JLabel("Orcs", JLabel.CENTER);
        orcLabel.setForeground(Color.WHITE);
        orcLabel.setOpaque(true);
        orcLabel.setBackground(Color.DARK_GRAY);

        eagleLabel = new JLabel("Eagles", JLabel.CENTER);
        eagleLabel.setOpaque(true);
        eagleLabel.setBackground(Color.PINK);

        dogLabel = new JLabel("Dogs", JLabel.CENTER);
        dogLabel.setOpaque(true);
        dogLabel.setBackground(Color.CYAN);

        mysticLabel = new JLabel("Mystic Plants", JLabel.CENTER);
        mysticLabel.setOpaque(true);
        mysticLabel.setBackground(Color.GREEN);

        setLocation(100, 50);

        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new BorderLayout());
        JPanel buttonPane = new JPanel(new BorderLayout());
        JPanel northPane = new JPanel(new GridLayout(0,1));
        JPanel colourPane = new JPanel(new GridLayout(0,1));
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(timeLabel, BorderLayout.CENTER);
        infoPane.add(weather, BorderLayout.EAST);

        colourPane.add(humanLabel);
        colourPane.add(dragonLabel);
        colourPane.add(orcLabel);
        colourPane.add(eagleLabel);
        colourPane.add(dogLabel);
        colourPane.add(mysticLabel);

        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);
        contents.add(buttonPane, BorderLayout.WEST);

        buttonPane.add(northPane, BorderLayout.NORTH);
        buttonPane.add(colourPane, BorderLayout.CENTER);

        // Create buttons that interact with the simulation.
        JButton randomiseButton = new JButton("Randomise");
        randomiseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                simulator.reset();
            }
        });
        northPane.add(randomiseButton);

        JButton oneStepButton = new JButton("Simulate One Step");
        oneStepButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { simulator.simulateOneStep();}
        });
        northPane.add(oneStepButton);

        JButton runLongButton = new JButton("Run Long Simulation");
        runLongButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                worker = new SwingWorker<>()
                {
                    @Override
                    protected Void doInBackground()
                    {
                        simulator.runLongSimulation();
                        return null;
                    }
                };
                worker.execute();
            }
        });
        northPane.add(runLongButton);

        JButton quitButton = new JButton("Quit");
        quitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { System.exit(0);}
        });
        buttonPane.add(quitButton, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }

    /**
     * Define a color to be used for a given class of animal.
     * @param animalClass The animal's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color)
    {
        colors.put(animalClass, color);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass)
    {
        Color col = colors.get(animalClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }

        Time fieldTime = field.getTime();
        Weather fieldWeather = field.getWeather();

        stepLabel.setText(STEP_PREFIX + step);
        this.weather.setText(WEATHER_PREFIX + fieldWeather.getCurrentWeather());
        timeLabel.setText(TIME_PREFIX + fieldTime.toString());
        stats.reset();

        fieldView.preparePaint();

        //The current colour of the object being painted.
        Color CURRENT_COLOR;

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    stats.incrementCount(animal.getClass());
                    if(((Species) animal).getDisease().getDuration().getHours() > 0) {
                        stats.incrementCount(((Species) animal).getDisease().getClass());
                    }
                    CURRENT_COLOR = getColor(animal.getClass());
                }
                else {
                    CURRENT_COLOR = EMPTY_COLOR;
                }
                //Makes it darker if it's night time.
                if(!fieldTime.isDay()) {
                    fieldView.darker(col, row, CURRENT_COLOR);
                } else {
                    fieldView.drawMark(col, row, CURRENT_COLOR);
                }
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * Paint on the grid by its given location and colour
         * but a darker version.
         */
        public void darker(int x, int y, Color colour)
        {
            g.setColor(colour.darker());
            g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
