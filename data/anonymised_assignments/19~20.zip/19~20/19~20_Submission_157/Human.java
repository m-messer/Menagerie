import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a human.
 * Humans age, move, eat, and die.
 * 
 */
public class Human extends GenderedSpecie
{
    // In essence how many steps a human can move without dying from starvation.
    private final int FOOD_VALUE;
    // The humans's food level, which is increased by eating its prey.
    private int foodLevel;

    /**
     * Create a human. A human can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the human will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Human(boolean randomAge, Field field, Location location)
    {
        super(field, location, 18, 125, 0.05, 3);
        FOOD_VALUE = 20;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * This is what the human does most of the time: it hunts for
     * food. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newHumans A list to return newly born humans.
     */
    public void act(List<Species> newHumans, int step)
    {
        deathFromDisease();
        if (isAlive()) {
            giveBirth(newHumans);
            // Move towards a source of food if found.
            // If the current weather is drought, move at half speed.
            if (getField().getWeather().getCurrentWeather().equals("Drought")) {
                if (step % 2 == 0) {
                    findNewLocation();
                    incrementAge();
                    incrementHunger();  
                }
            }
            // If the current weather is icy, move at quarter speed.
            else if (getField().getWeather().getCurrentWeather().equals("Icy")) {
                if (step % 4 == 0) {
                    findNewLocation();
                    incrementAge();
                    incrementHunger();
                }
            }
            else {
                findNewLocation();
                incrementAge();
                incrementHunger();
            }
        }
    }

    /**
     * Finds a new location by looking for food in the adjacent locations
     * and also checks if it can be infected once a location is found.
     */
    private void findNewLocation()
    {
        Location newLocation = findFood();
        if(newLocation == null) {
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
            beInfected();
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Make this human more hungry. This could result in the human's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first live variant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof MysticPlant || species instanceof Eagle) {
                Species organism = (Species) species;
                if(organism.isAlive()) { 
                    organism.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this human is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHumans A list to return newly born humans.
     */
    private void giveBirth(List<Species> newHumans)
    {
        // New humans are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof Human) {
                Human human = (Human) species;
                if(human.isMale() != this.isMale()) { 
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Human young = new Human(false, field, loc);
                        newHumans.add(young);
                    }
                }
            }
        }
    }
}
