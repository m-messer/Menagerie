import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Humans, Orcs, Eagles, Dragons, Dogs and Mystic Plants.
 * 
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // List of animals in the field.
    private List<Species> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);
        view.setColor(Human.class, Color.ORANGE);
        view.setColor(Dragon.class, Color.RED);
        view.setColor(Dog.class, Color.CYAN);
        view.setColor(Orc.class, Color.DARK_GRAY);
        view.setColor(Eagle.class, Color.PINK);
        view.setColor(MysticPlant.class, Color.GREEN);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(50);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Species> newSpeciess = new ArrayList<>();
        // Let all animals act.
        for(Iterator<Species> it = organisms.iterator(); it.hasNext(); ) {
            Species animal = it.next();
            animal.act(newSpeciess, step);
            if(!animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals to the main lists.
        organisms.addAll(newSpeciess);

        //increment the time by passing the steps
        field.getTime().incrementTime(step);

        //randomises the weather every
        if(field.getTime().getHours() % 20 == 0) {
            field.getWeather().getRandomWeather(field.getTime(), step);
        }

        //displays the stats on screen
        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with different animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                int random = rand.nextInt(100);
                if(random >= 0 && random <= 5) {
                    Location location = new Location(row, col);
                    Human human = new Human(true, field, location);
                    organisms.add(human);
                }
                else if(random > 5 && random <= 7) {
                    Location location = new Location(row, col);
                    Dragon dragon = new Dragon(true, field, location);
                    organisms.add(dragon);
                }
                else if(random > 8 && random <= 16) {
                    Location location = new Location(row, col);
                    Orc orc = new Orc(true, field, location);
                    organisms.add(orc);
                }
                else if(random > 16 && random <= 23) {
                    Location location = new Location(row, col);
                    Eagle eagle = new Eagle(true, field, location);
                    organisms.add(eagle);
                }
                else if(random > 23 && random <= 30) {
                    Location location = new Location(row, col);
                    Dog dog = new Dog(true, field, location);
                    organisms.add(dog);
                }
                else if(random > 30 && random <= 65) {
                    Location location = new Location(row, col);
                    MysticPlant mysticPlant = new MysticPlant(true, field, location);
                    organisms.add(mysticPlant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
