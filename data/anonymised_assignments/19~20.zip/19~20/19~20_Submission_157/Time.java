/**
 * A class to represent the time in the simulation.
 *
 */
public class Time {

    //The hours in time.
    private int hours;
    //The number of steps needed for the time
    //to be incremented.
    private int stepsPerHour;

    /**
     * A constructor with both hours and steps per hour
     * initialised.
     */
    public Time(int hours, int stepsPerHour)
    {
        this.hours = hours;
        this.stepsPerHour = stepsPerHour;
    }

    /**
     * A constructor with just the hours initialised.
     */
    public Time(int hours)
    {
        this.hours = hours;
    }

    /**
     * Increments time by one.
     * @param currentStep The number of steps the
     *                    simulation has made.
     */
    public void incrementTime(int currentStep)
    {
        if(currentStep % stepsPerHour == 0) {
            hours++;
            if(this.hours > 23) {
                this.hours = 0;
            }
        }
    }

    /**
     * Decrements time by an hour.
     */
    public void decrementTime()
    {
        hours--;
        if(hours < 0) {
            hours = 0;
        }
    }

    /**
     * @return The string representation of the
     * time.
     */
    @Override
    public String toString()
    {
        return hours + ":00";
    }

    /**
     * @return Returns a boolean regarding whether
     * the time represents day or night.
     */
    public boolean isDay()
    {
        return hours >= 7 && hours < 18;
    }

    /**
     * @return Returns the hours.
     */
    public int getHours()
    {
        return hours;
    }

    /**
     * @return Returns the steps required per
     * hour.
     */
    public int getStepsPerHour() {
        return stepsPerHour;
    }
}
