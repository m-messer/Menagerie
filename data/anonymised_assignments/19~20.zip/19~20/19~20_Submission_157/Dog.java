import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a dog.
 * Dogs age, move, breed, and die.
 * 
 */
public class Dog extends GenderedSpecie
{
    /**
     * Create a new dog. A dog may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the dog will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Dog(boolean randomAge, Field field, Location location)
    {
        super(field, location, 5, 35, 0.10, 3);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the dog does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newDogs A list to return newly born dogs.
     * @param step The number of steps in the simulator.
     */
    public void act(List<Species> newDogs, int step)
    {
        deathFromDisease();
        if(isAlive()) {
            // Try to move into a free location.
            if(getField().getTime().isDay()) {
                giveBirth(newDogs);
                findNewLocation();
                incrementAge();
            }
        }
    }

    /**
     * Finds a new location at the adjacent locations
     * and also checks if it can be infected once a location is found.
     */
    private void findNewLocation()
    {
        Location newLocation = getField().freeAdjacentLocation(getLocation());
        if(newLocation != null) {
            setLocation(newLocation);
            beInfected();
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Check whether or not this dog is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDogs A list to return newly born dogs.
     */
    private void giveBirth(List<Species> newDogs)
    {
        // New dog are born into adjacent locations.
        // Get a list of adjacent free locations.
        // New dogs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        while(it.hasNext()) {
            Location where = it.next();
            Object species = field.getObjectAt(where);
            if(species instanceof Dog) {
                Dog dog = (Dog) species;
                if(dog.isMale() != this.isMale()) { 
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Dog young = new Dog(false, field, loc);
                        newDogs.add(young);
                    }
                }
            }
        }
    }
}
