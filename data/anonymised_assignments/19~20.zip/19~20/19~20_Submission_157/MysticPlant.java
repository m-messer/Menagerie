import java.util.List;
import java.util.Random;

/**
 * A simple model of a mystic plant.
 * Mystic plants age, grow, and die.
 * 
 */
public class MysticPlant extends Species
{
    /**
     * Create a new plant. A plant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public MysticPlant(boolean randomAge, Field field, Location location)
    {
        super(field, location, 1, 75, 0.2, 5);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * This is what the plant does most of the time - it runs
     * around. Sometimes it will grow or die of old age.
     * @param newMysticPlants A list to return newly born plants.
     * @param step The number of steps in the simulator.
     */
    public void act(List<Species> newMysticPlants, int step)
    {
        deathFromDisease();
        if (isAlive()) {
            if(!getField().getTime().isDay()) {
                if(step % 20 == 0) {
                    giveBirth(newMysticPlants);
                    findNewLocation();
                    incrementAge();
                }
            }
            else {
                giveBirth(newMysticPlants);
                findNewLocation();
                incrementAge();
            }
        }
    }

    /**
     * Finds a new location in the adjacent locations
     * and also checks if it can be infected once a location is found.
     */
    private void findNewLocation()
    {
        Location newLocation = getField().freeAdjacentLocation(getLocation());
        if(newLocation != null) {
            setLocation(newLocation);
            beInfected();
        }
        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMysticPlants A list to return newly born plants.
     */
    private void giveBirth(List<Species> newMysticPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            MysticPlant mysticPlant = new MysticPlant(false, field, loc);
            newMysticPlants.add(mysticPlant);
        }
    }
}
