import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 * 
 */
public abstract class Species
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //Age of the animal.
    protected int age;
    //The breeding age of the animal.
    protected final int BREEDING_AGE;
    //The max age of the animal.
    protected final int MAX_AGE;
    //The breeding probability of the animal
    protected final double BREEDING_PROBABILITY;
    //The max amount of children the animal can breed.
    protected final int MAX_LITTER_SIZE;
    //A place to store the disease if the animal becomes
    //infected
    private Disease disease;
    
    public static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new specie within a location in a field.
     * Initialises the species important characteristics.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param breedingAge The breeding age
     * @param maxAge The max age
     * @param breedingProbability The breeding probability
     * @param maxLitterSize The maximum amount of children the animal
     *                      can have.
     */
    public Species(Field field, Location location, int breedingAge, int maxAge,
                   double breedingProbability, int maxLitterSize)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        BREEDING_AGE = breedingAge;
        MAX_AGE = maxAge;
        BREEDING_PROBABILITY = breedingProbability;
        MAX_LITTER_SIZE = maxLitterSize;
        //if the random number is greater than 0.8,
        //this specie is infected.
        if(rand.nextInt() > 0.8) {
            disease = new Disease();
        } else {
            disease = new Disease(new Time(0));
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newSpecies A list to receive newly born animals.
     * @param step The number of steps in the simulator.
     */
    public abstract void act(List<Species> newSpecies, int step);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Increase the age. This could result in the fox's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * A fox can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Checks adjacent locations for infections. If any specie
     * in the adjacent location is infected, it gets passed onto
     * this specie.
     */
    protected void beInfected() {
        List<Location> adjacent = field.adjacentLocations(getLocation());
        if(adjacent != null) {
            for(Location l : adjacent) {
                Species species = (Species) field.getObjectAt(l);
                if(species != null && species.isInfected() &&
                        species.getDisease().getDuration().getHours() > disease.getDuration().getHours()) {
                    disease = new Disease();
                    disease.decrementDuration();
                }
            }
        }
    }

    /**
     * @return Checks whether this specie is infected.
     */
    protected boolean isInfected()
    {
        return disease.getDuration().getHours() > 0;
    }

    /**
     * @return Returns the disease the specie has.
     */
    protected Disease getDisease()
    {
        return disease;
    }

    /**
     * Determines whether the animal dies from the disease by random chance.
     */
    protected void deathFromDisease()
    {
        if (isInfected()) {
            Random rd = new Random();
            int value = rd.nextInt(100);
            if (value < 10) {
                setDead();
            }
        }
    }
}
