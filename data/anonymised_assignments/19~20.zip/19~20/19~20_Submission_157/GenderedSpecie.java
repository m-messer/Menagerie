import java.util.List;
import java.util.Iterator;
/**
 * A class representing the animals with gender.
 *
 */
public abstract class GenderedSpecie extends Species
{
    // Contains the gender of an animal
    private boolean isMale;
    
    public GenderedSpecie(Field field, Location location, int breedingAge, int maxAge,
                   double breedingProbability, int maxLitterSize)
    {
        super(field, location, breedingAge, maxAge, breedingProbability,
               maxLitterSize);
        isMale = rand.nextBoolean();
    }
    
    protected boolean isMale()
    {
        return isMale;
    }
}
