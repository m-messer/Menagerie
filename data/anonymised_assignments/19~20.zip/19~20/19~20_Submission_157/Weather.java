import java.util.ArrayList;
import java.util.Random;
/**
 * A simple weather system that is used on the field.
 *
 */
public class Weather
{
    // Stores different types of weather.
    private ArrayList<String> weather;
    // Stores the current weather.
    private String currentWeather;

    /**
     * Constructor for objects of class Weather
     */
    public Weather(String currentWeather)
    {
        this.currentWeather = currentWeather;
        weather = new ArrayList<>();
        addWeathers();
    }
    
    /**
     * Method used to add different weather to the array list.
     */
    public void addWeathers()
    {
        weather.add("Calm");
        weather.add("Rain");
        weather.add("Drought");
        weather.add("Icy");
    }
    
    /**
     * @return a random weather from the weather array list.
     */
    public String getRandomWeather(Time time, int step)
    {
        Random rd = new Random();
        if(step % time.getStepsPerHour() == 0) {
            return currentWeather = weather.get(rd.nextInt(weather.size()));
        } else {
            return currentWeather;
        }
    }

    /**
     * @return the current weather.
     */
    public String getCurrentWeather()
    {
        return currentWeather;
    }
}
