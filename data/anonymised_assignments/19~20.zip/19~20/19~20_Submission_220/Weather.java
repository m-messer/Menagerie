import java.util.*;
/**
 * A class representing the characteristics of Weather.
 *
 * @version 2016.02.29 (2)
 */
public class Weather
{
    // instance variables - replace the example below with your own
    private String weather;
    //Step that help to decide the change of weather
    private int step;
    /**
     * Constructor for objects of class weather,it start with step 1
     * and reset weather when start
     */
    public Weather(){
        step = 1;
        resetWeather();
    }
    //get the weather now
    public String getWeather()
    {
        // initialise instance variables
        return weather;
    }
    // reset the weather in random
    public void resetWeather(){
         Random rand = Randomizer.getRandom();
        if(rand.nextDouble()  <  0.7){ 
            weather = "sunday";
        }
        else if(rand.nextDouble() <= 0.7){ 
            weather = "rainday";
        }
        else {
            weather = "fogday";
    }
    }
    // increase the step
    public void incStep(){
        step++;
    }
    // reset the step
    public void resetStep(){
        step = 1;
    }
    // return the step now
    public int getStep(){
        return step;
    }
}