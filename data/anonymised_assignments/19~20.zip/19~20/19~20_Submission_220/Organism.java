import java.util.List;
/**
 * The interface to be implemented by any class wishing to
 * participate in the simulation
 * 
 *
 * @version (a version number or a date)
 */
public interface Organism
{
    /**
     * Perform usual behaviour 
     * @param newOrganisms A list to recieve newly created organisms.
     */
    void act(List<Organism> newOrganisms,Weather weather);

    /**
     * Check if organism is still alive
     * @return True or false, depending if still alive or not.
     */
    boolean isAlive();
    
    /**
     * Any organism can get infected
     */
    boolean infectionStatus();
}
