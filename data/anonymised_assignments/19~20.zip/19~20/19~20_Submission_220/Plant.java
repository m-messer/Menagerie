import java.util.*;
/**
 * A class representing shared characteristics of Plants.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Plant implements Organism
{
    // Whether the Plant is alive or not.
    private boolean alive;
    // The Plant's field.
    private Field field;
    // The Plant's position in the field.
    private Location location;
    // Disease:
    private static final Random rand = Randomizer.getRandom();
    // Mutation makes plant infectious which can spread to different animals
    private double mutationProbability;
    // mutated or not
    private boolean mutated;
    /**
     * Create a new Plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        mutationProbability = rand.nextDouble();
        mutated = false;
    }
    
    /**
     * Make this Plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born Plants.
     */
    abstract public void act(List<Organism> newPlants,Weather weather);

    /**
     * Check whether the Plant is alive or not.
     * @return true if the Plant is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the Plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the Plant's location.
     * @return The Plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the Plant at the new location in the given field.
     * @param newLocation The Plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the Plant's field.
     * @return The Plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    protected double getMutationProb()
    {
        return mutationProbability;
    }
    
    /**
     *.return mutated or not
     */
    public boolean infectionStatus()
    {
        return mutated;
    }
    
    /**
     *  plant is now infectious. Mutator method
     */
    protected void mutate(){
        this.mutated = true;
    }
}
