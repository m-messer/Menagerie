import java.util.*;
/**
 * A simple model of a Wolf.
 * Wolfes age, move, eat zebras, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all Wolfes (class variables).
    
    // The age at which a Wolf can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a Wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single zebra. In effect, this is the
    // number of steps a Wolf can go before it has to eat again.
    private static final int FOOD_VALUE = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The wolf's food level, which is increased by eating animals.
    private int foodLevel;
   

    /**
     * Create a Wolf. A Wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        // food value of prey (zebra, sheep or deer)
        setLifeExpectancy(100);
        if(randomAge) {
            setAge(rand.nextInt(getLifeExpectancy()));
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            setAge(0);
            foodLevel = FOOD_VALUE;
        }
    }
    
    /**
     * This is what the Wolf does most of the time: it hunts for
     * animals. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newWolfes A list to return newly born Wolfes.
     * @param weather the current weather
     */
    public void act(List<Organism> newWolfes,Weather weather)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
                        
            // Move towards a source of food if found.
            if (weather.getWeather().equals("sunday") || weather.getWeather().equals("rainday")){
                Location newLocation = findFood();
                giveBirth(newWolfes); 
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }else if(weather.getWeather().equals("fogday")&&
                rand.nextDouble()<0.2)
                 {giveBirth(newWolfes); 
            }
        }
    }
    //increase the hungry level of wolf
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for animals adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator(); 
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            Object plant = field.getObjectAt(where);
            if(animal instanceof Zebra &&!findWolf() ){
                Zebra zebra = (Zebra) animal;
                if(zebra.isAlive()) { 
                    checkInfectionAndDecLife(zebra);
                    zebra.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Deer&&!findWolf()) {
                Deer deer = (Deer) animal;
                if(deer.isAlive()) { 
                    checkInfectionAndDecLife(deer);
                    deer.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Sheep&&!findWolf()) {
                Sheep sheep = (Sheep) animal;
                if(sheep.isAlive()) {
                    checkInfectionAndDecLife(sheep);
                    sheep.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
            else if(animal instanceof Lion&&braveHeart()) {
                Lion lion = (Lion) animal;
                if(lion.isAlive()) { 
                    checkInfectionAndDecLife(lion);
                    lion.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
            else if(plant instanceof Grass && reallyHungry()&&rand.nextDouble()<=0.05) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    checkInfectionAndDecLife(grass);
                    grass.setDead();
                    foodLevel = FOOD_VALUE; 
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * check if wolf have brave heart or not to eat lion
     */
    public boolean braveHeart(){
       Random rand = Randomizer.getRandom();
        if(rand.nextDouble()<0.5){
        return true;
    }
    return false;
    }
    // check if the Lion is really hungry or not
    public boolean reallyHungry(){
          if (FOOD_VALUE<3)
          {return true;}
          return false;
    }
    
    /**
     * check if there is a wolf in adjacent location or not
     */
    public boolean findWolf(){
         Random rand = Randomizer.getRandom();
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wolf&& rand.nextDouble()<0.5){
                return true;}
            else  if(animal instanceof Wolf&& rand.nextDouble()>0.5){
                return false;
            }
                
             else return false;
 
            
        }
        return false;
    }
    
    /**
     * @return The age at which a wolf starts to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * get the Probability of breeding
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
     
    /**
     * return the MaxLitterSize
     */
    public int getMaxLitterSize()
    {
        // put your code here
        return MAX_LITTER_SIZE;
    }
    //create  an animal with randomage field and locction
    public Animal createAnimal(boolean randomAge, Field field, Location location)
    {
        return new Wolf(randomAge, field, location);
    } 
}
