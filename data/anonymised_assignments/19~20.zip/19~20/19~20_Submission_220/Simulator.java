import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing zebras and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 150;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100;
    // The probability that a fox will be created in any given grid position.
    private static final double PREDATOR_CREATION_PROBABILITY = 0.15;
    // The probability that a zebra will be created in any given grid position.
    private static final double PREY_CREATION_PROBABILITY = 0.3;    
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // initial the weather
    private Weather weather = new Weather();
    // List of organisms in the field.
    private List<Organism> organisms = new ArrayList<>();

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();
        organisms = new ArrayList<>();
        field = new Field(depth, width);
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.BLUE);
        view.setColor(Sheep.class, Color.RED);
        view.setColor(Deer.class, Color.YELLOW);
        view.setColor(Lion.class, Color.BLACK);
        view.setColor(Grass.class, Color.green);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and zebra.
     */
    public void simulateOneStep()
    {
        step++;
        Random rand = Randomizer.getRandom();
        // Provide space for newborn organisms.
        if (step % 100 != 0){ // not sleeping
            if(weather.getStep() == 50){
                weather.resetWeather();
                weather.resetStep();
            }
            else{
                weather.incStep();
            }
            // Provide space for newborn actors.
            List<Organism> newOrganisms = new ArrayList<Organism>();        
            // Let all zebras act.
            for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
                Organism organism = it.next();
                organism.act(newOrganisms, weather);
                if(! organism.isAlive()) {
                    it.remove();
                }
            }

            // Add the newly born animal and plants to the main lists.
            organisms.addAll(newOrganisms);
            view.showStatus(step, field, "Daytime", weather.getWeather());
        }

        else{ // sleeping
            for (int i = 0; i<=100; i++){
                step++;
                delay(5);
                view.showStatus(step, field, "Nighttime", weather.getWeather());
            }
        }
        // grass randomly grows at a certain time
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++)
                if(step%100 == 0){if(rand.nextDouble()<=0.1){
                        Location location = new Location(row, col);
                        Grass grass = new Grass(true, field, location);
                        organisms.add(grass);
                        
                    }

                }

        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field,"sunday","daytime");
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PREDATOR_CREATION_PROBABILITY ){
                    if( rand.nextDouble() <= 0.5){
                        Location location =new Location(row, col);
                        Lion lion = new Lion(true, field, location);
                        organisms.add(lion);}
                    else{
                        Location location = new Location(row, col);
                        Wolf wolf = new Wolf(true, field, location);
                        organisms.add(wolf);}
                }
                if(rand.nextDouble() <= PREY_CREATION_PROBABILITY) {
                    if( rand.nextDouble() <= 0.33){
                        Location location = new Location(row, col);
                        Deer deer = new Deer(true, field, location);
                        organisms.add(deer);
                    }else if(rand.nextDouble() <= 0.5) {
                        Location location = new Location(row, col);
                        Zebra zebra = new Zebra(true, field, location);
                        organisms.add(zebra);
                    }else {
                        Location location = new Location(row, col);
                        Sheep sheep = new Sheep(true, field, location);
                        organisms.add(sheep);}
                }
                if(rand.nextDouble()<=0.07){
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    organisms.add(grass);
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}