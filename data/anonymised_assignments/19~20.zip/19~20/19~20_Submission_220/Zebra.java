import java.util.*;
import java.util.Random;
/**
 * A simple model of a Zebra.
 * Zebras age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Zebra extends Animal
{
    // Characteristics shared by all Zebras (class variables).

    // The age at which a Zebra can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a Zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    private static final int FOOD_VALUE = 60;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The Zebra's age.
    private int age;
    // The fox's food level, which is increased by eating Zebras.
    private int foodLevel;

    /**
     * Create a new Zebra. A Zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
         // food value of a plant. 
        setLifeExpectancy(100);
        if(randomAge) {
            age = rand.nextInt(getLifeExpectancy());
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * This is what the Zebra does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born Zebras.
     */
    public void act(List<Organism> newZebras,Weather weather)
    {
        incrementAge();
        incrementHunger();
                
        if(isAlive()) {
                
            giveBirth(newZebras);
            // Try to move into a free location.
            if (weather.getWeather().equals("sunday") || 
            weather.getWeather().equals("rainday")||
            (weather.getWeather().equals("fogday")&&
                rand.nextDouble()<0.50)){
                Location newLocation = findFood();
                   giveBirth(newZebras);   
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for grass adjacent to the current location.
     * Only the first live grass is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    checkInfectionAndDecLife(grass);
                    grass.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }

        }
        return null;
    }

    public Animal createAnimal(boolean randomAge, Field field, Location location)
    {
        return new Zebra(randomAge, field, location);
    } 
    
    /**
     * get the Probability of breeding
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }
    
    /**
     *return the MaxLitterSize
     */
    public int getMaxLitterSize()
    {
        // put your code here
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return The age at which a Zebra starts to breed.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
        
    /**
     *  return the age of animal
     */
    public int getAge(){
        return age;
    }


}
