import java.util.List;
import java.util.Iterator;
import java.lang.Math;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2020.02.21 
 */
public abstract class Animal extends Organism
{
    protected boolean female;
    
    protected boolean isDiseased;
    
    protected int diseaseProliferation;
    
    protected boolean matedThisStep;
    
    protected int MAX_AGE;

    
    // Individual characteristics (instance fields).
    // The animal's age.
    protected int age;
    // The  animal's food level, which is increased by eating animals or plant.
    protected int foodLevel;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        female = Math.random() < 0.5;
        isDiseased = Math.random() < 0.01;
        diseaseProliferation = 0;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Organism> newOrganisms, boolean day, boolean rain)
    {
        
    }
    
    /**
     * Increase the age. This could result in the mouse's death.
     */
    protected void incrementAge(int MAX_AGE) 
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    } 
    
    /**
     * Make this alive species more hungry. This could result in the species's death.
     * @param foodLevel The food level of alive species.
     */
    protected int incrementHunger(int foodLevel)
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
        return foodLevel;
    }
    /**
     * Look for a mate of the opposite gender adjacent to the current location.
     * Breeding only happens with first mate found.
     * @return Where mate was found, or null if it wasn't.
     */
    protected Animal foundMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Organism organism = (Organism) field.getObjectAt(where);
            if(organism == null || !(organism instanceof Animal)){}
            else
            {
               Animal animal = (Animal) organism;
                if(!animal.getClass().equals(this.getClass())){}
               else
               {
                   if(animal.female == this.female){}
                   else
                   {
                       if(animal.matedThisStep){}
                       else
                       {
                           return animal;
                        }
                   }
                } 
            }
            
            
        }
        return null;
    }
    

    
}
