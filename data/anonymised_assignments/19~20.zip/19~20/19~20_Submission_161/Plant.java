import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a plant.
 * Plants age, move.
 *
 * @version 2020.02.21 
 */
public class Plant extends Organism
{
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The plant spreading probability.
    private static final double SPREAD_PROBABILITY = 0.1;   
    // The growing rate of a plant.
    private static final int GROWTH_INTERVAL = 10;
    // The current step of growth interval of a plant.
    private int growInterval;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    

    public Plant(boolean randomAge, Field field, Location location)
    {
        // initialise instance variables
        super(field, location);
        growInterval = 0;
        if(randomAge) {
            growInterval = rand.nextInt(GROWTH_INTERVAL);
        }
    }  
    
    /**
     * This is what the plant does most of the time: it grow inthe day and rain. 
     * @param field The field currently occupied.
     * @param newPlant A list to return newly plant.
     */   
    protected void act(List<Organism> newPlant, boolean day, boolean rain)
    {
        growInterval++;   
        if(isAlive()&& day && rain)
        { 
           Grow(newPlant);      
           if(growInterval == GROWTH_INTERVAL) {                 
              setDead();
           }

        }
    }
    
    /**
     * Check whether or not this plant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param isAlves A list to return newly born .
     */   
    private void Grow(List<Organism> newPlant)
    {
        // New Alives are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(isAlive()) {
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = rand.nextInt(MAX_LITTER_SIZE) + 1;

            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Plant young = new Plant(false, field, loc);
                newPlant.add(young);
            }
        }
    } 
}
    


