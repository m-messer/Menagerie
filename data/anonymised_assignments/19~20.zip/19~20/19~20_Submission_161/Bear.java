import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a bear.
 * Bears age, move, eat mooses, and die.
 *
 * @version 2020.02.21 
 */
public class Bear extends Animal
{
    // Characteristics shared by all bears (class variables).
    
    // The age at which a bear can start to breed.
    private static final int BREEDING_AGE = 12;
    // The age to which a bear can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a bear breeding.
    private static final double BREEDING_PROBABILITY = 0.56;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single moose. In effect, this is the
    // number of steps a bear can go before it has to eat again.
    private static final int MOOSE_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    

    /**
     * Create a bear. A bear can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the bear will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bear(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MOOSE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = MOOSE_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the bear does most of the time: it hunts for
     * mooses. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newBears A list to return newly born bears.
     */
    public void act(List<Organism> newBears, boolean day, boolean rain)
    {
        incrementAge(MAX_AGE);
        incrementHunger(foodLevel);
        if(isAlive()) {
            Animal mate = foundMate();
            if(mate != null)
            {
                giveBirth(newBears); 
                matedThisStep = true;
                mate.matedThisStep = true;
                if(mate.isDiseased == true)
                {   
                    this.isDiseased = true;
                }
            }           
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
                Object object = getField().getObjectAt(newLocation);
                if(object instanceof Animal)
                {
                    Animal animal = (Animal) object;
                    if(animal.isDiseased == true)
                    {   
                        this.isDiseased = true;
                    }
                }
            }
            else {
                // Overcrowding.
                setDead();
            }
            
            if(isDiseased)
            {
                double progress = new Random().nextDouble();
                if(progress > 0.5){progress -= 0.5;}
                diseaseProliferation += progress;
                if(diseaseProliferation >= 1){setDead();}
            }
        }
    }
    
    /**
     * Look for mooses adjacent to the current location.
     * Only the first live moose is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Moose) {
                Moose moose = (Moose) animal;
                if(moose.isAlive()) { 
                    moose.setDead();
                    foodLevel = MOOSE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this bear is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBears A list to return newly born bears.
     */
    private void giveBirth(List<Organism> newBears)
    {
        // New bears are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bear young = new Bear(false, field, loc);
            newBears.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A bear can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
