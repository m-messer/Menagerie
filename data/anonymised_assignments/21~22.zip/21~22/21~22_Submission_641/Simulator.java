import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing sea animals
 *
 * @version 28/02/2022
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a whale will be created in any given grid position.
    private static final double WHALE_CREATION_PROBABILITY = 0.02;
    // The probability that a shark will be created in any given grid position.
    private static final double SHARK_CREATION_PROBABILITY = 0.05;    
    // The probability that a tuna will be created in any given grid position.
    private static final double TUNA_CREATION_PROBABILITY = 0.02;
    // The probability that a crab will be created in any given grid position.
    private static final double CRAB_CREATION_PROBABILITY = 0.06;
    // The probability that an octopus will be created in any given grid position.
    private static final double OCTOPUS_CREATION_PROBABILITY = 0.02;
    // The probability that seaweed will be created in any given grid position.
    private static final double SEAWEED_CREATION_PROBABILITY = 0.015;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //give the time without the need of creating an object
    private Time time;
    //keeps track of hours in a day 
    private int hour;
    //keeps track of the number of days gone by
    private int days;
    //keeps track of the weather 
    private String weather;
    //keeps track of the temperature
    private int temperature;
    //keeps track of the number of diseased animals in the simulation
    private int disease;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        actors = new ArrayList<>();
        field = new Field(depth, width);
        time = new Time();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Whale.class, Color.WHITE);
        view.setColor(Shark.class, Color.GRAY);
        view.setColor(Tuna.class, Color.YELLOW);
        view.setColor(Octopus.class, Color.MAGENTA);
        view.setColor(Crab.class, Color.RED);
        view.setColor(Seaweed.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field)  ; step++) {
            simulateOneStep();
            delay(1);   // Uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * predator and prey.
     */
    public void simulateOneStep()
    {
        // Keep all variables up to date for the GUI
        step++;
        time.incrementHours();
        hour = time.getHours();
        getDays();
        weather = changeWeather();
        changeTemperature();
        Disease.act(step , actors);

        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>();        
        // Let all actors act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors);
            if (actor instanceof Animal){
                Animal animal = (Animal) actor;
                if (! animal.isAlive()){
                    it.remove();
                }
            }
        }

        // Add the newly born actors to the main lists.
        actors.addAll(newActors);
        view.showStatus(step, field, hour, days, weather, temperature);
    }

    /**
     * Changes the weather according to the time of day after a regular interval of steps.
     * @return the number of days that have passed.
     */
    private String changeWeather()
    {
        if (step % 5 ==0 ) {
            weather = Weather.getWeather();
        }
        return weather;
    }

    /**
     * Changes the weather according to the time of day after a regular interval of steps.
     */
    private void changeTemperature()
    {
        if (step % 5 ==0 ) {
            temperature = Temperature.getTemperature();
        }
    }

    /**
     * Gets the number of days that have passed.
     * @return the number of days that have passed.
     */
    private int getDays()
    {
        if (step % 24 ==0) {
            days++;
        }
        return days;
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        hour = 0;
        days = 0;
        time.setZero();
        actors.clear();
        populate();
        changeWeather();
        Disease.act(step , actors);

        // Show the starting state in the view.
        view.showStatus(step, field, hour, days, weather, temperature );
    }

    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    actors.add(whale);
                }
                else if(rand.nextDouble() <= SHARK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shark shark = new Shark(true, field, location);
                    actors.add(shark);
                }
                else if(rand.nextDouble() <= TUNA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tuna tuna = new Tuna(true, field, location);
                    actors.add(tuna);
                }
                else if(rand.nextDouble() <= CRAB_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Crab crab = new Crab(true, field, location);
                    actors.add(crab);
                }
                else if(rand.nextDouble() <= OCTOPUS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Octopus octopus = new Octopus(true, field, location);
                    actors.add(octopus);
                }
                else if(rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Seaweed seaweed = new Seaweed(true, field, location);
                    actors.add(seaweed);
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Returns the current step in the simulation.
     * @return current step in simulation
     */
    private int getStep()
    {
        return step;
    }
}
