import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of seaweed.
 * Seaweed age, give birth and die 
 *
 * @version 28/02/2022
 */
public class Seaweed extends Plant
{
    // The age to which the seaweed lives.
    private static final int MAX_AGE = 10;
    // The likelihood of the seaweed breeding during the day.
    private static final double BREEDING_PROBABILITY_DAY = 0.3;
    // The likelihood of the seaweed breeding at night.
    private static final double BREEDING_PROBABILITY_NIGHT = 0.1;
    // The maximum number of offspring of a seaweed.
    private static final int MAX_OFFSPRING_SIZE = 5;
    // The minimum number of offspring of a seaweed.
    private static final int MIN_OFFSPRING_SIZE = 3;
    // Whether a seaweed can breed.
    private static final int BREEDING_AGE = 7;
    
    /**
     * Create seaweed. A seaweed can be created as a new born (age zero
     * and not hungry) or with a random age.
     * 
     * @param randomAge If true, the crab will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seaweed(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
        }
        else {
            setAge(0);
        }
    }
    
    /**
     * This is what the seaweed does most of the time: it breeds. 
     * In the process, it might die of hunger or die of old age.
     * @param field The field currently occupied.
     * @param newCrabs A list to return newly born crabs.
     */
    public void act(List<Actor> newSeaweeds)
    {
        incrementAge();
        if(isAlive() && getCanBreed()) {
            giveBirth(newSeaweeds);    
        }
    }
    
    /**
     * Check whether or not this seaweed is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSeaweeds A list to return newly born seaweed.
     */
    private void giveBirth(List<Actor> newSeaweeds)
    {
        // New seaweeds are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Seaweed young = new Seaweed(false, field, loc);
            newSeaweeds.add(young);
        }
    }

    /**
     * A seaweed can breed if it has reached the breeding age.
     * @return whether a seaweed has reached the breeding age.
     */
    public boolean getCanBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Returns the maximum age of a seaweed.
     * @return the maximum age of a seaweed.
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Returns the proabablity a seaweed will breed.
     * @return the proabablity a seaweed will breed
     */
    protected double getBreedingProbability()
    {
        if (Time.dayTime()) {
            return BREEDING_PROBABILITY_DAY;
        }
        else {
            return BREEDING_PROBABILITY_NIGHT;
        }
    }
    
    /**
     * Return the offspring sizes depending on the weather in which the seaweeds are. 
     * @return offspring sizes.
     */
    public int getOffspringSize()
    {
        if (Weather.getWeather().equals("Sunny") || Weather.getWeather().equals("Cloudy")) {
            return MAX_OFFSPRING_SIZE;
        }
        else {
            return MIN_OFFSPRING_SIZE;
        }
        
    }
}
