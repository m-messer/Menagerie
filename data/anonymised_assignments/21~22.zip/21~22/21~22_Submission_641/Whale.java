import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a whale.
 * Whale age, move, eat sharks, give birth and die.
 *
 * @version 28/02/2022
 */
public class Whale extends Animal
{
    // Characteristics shared by all whales (class variables).
    // The age at which a whale can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a whale can live.
    private static final int MAX_AGE = 300;
    // The likelihood of a whale breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // The food value of a single shark. In effect, this is the
    // number of steps a whale can go before it has to eat again.
    private static final int SHARK_FOOD_VALUE = 50; 

    /**
     * Create a whale. A whale can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the whale will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Whale(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            setFoodLevel(getRandom().nextInt(SHARK_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(SHARK_FOOD_VALUE);
        }
    }

    /**
     * This is what the whale does most of the time: it hunts for
     * sharks. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWhales A list to return newly born whales.
     */
    public void act(List<Actor> newWhales)
    {
        if (hasInfection) {
            effectOfInfection();
        }
        incrementAge();
        incrementHunger();
        if(isAlive() && Time.dayTime()) {
            if(isFemale() && oppositeGender()){
                giveBirth(newWhales); 
            }

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this whale more hungry. This could result in the whale's death.
     */
    private void incrementHunger()
    {
        setFoodLevel(getFoodLevel() - 1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }

    /**
     * Look for sharks adjacent to the current location.
     * Only the first live shark is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shark) {
                Shark shark = (Shark) animal;
                if(shark.isAlive()) { 
                    shark.setDead();
                    setFoodLevel(SHARK_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this whale is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWhales A list to return newly born whales.
     */
    private void giveBirth(List<Actor> newWhales)
    {
        // New whales are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Whale young = new Whale(false, field, loc);
            newWhales.add(young);
        }
    }

    /**
     * A whale can breed if it has reached the breeding age.
     * @return true if whale can breed
     */
    public boolean getCanBreed()
    {
        return getAge() >= BREEDING_AGE;
    }

    /**
     * Returns the maximum age of a whale.
     * @return the maximum age of a whale
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the proabablity a whale will breed.
     * @return the proabablity a whale will breed
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the litter size of a whale.
     * @return the litter size of a whale
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns true if adjacent whales are of opposite gender.
     * @return true if adjacent whales are of opposite gender
     */
    private boolean oppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Whale) {
                Whale whale = (Whale) animal;
                if(!whale.isFemale()) { 
                    return true;
                }
            }
        }
        return false;
    }
}
