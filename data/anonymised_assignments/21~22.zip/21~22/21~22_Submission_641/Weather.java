import java.util.Random;
/**
 * Determines what weather is experienced by all the actors in the simulation.
 *
 * @version 28/02/2022
 */
public class Weather
{
    // A shared random number generator to control breeding.
    private static Random rand = Randomizer.getRandom();
    
    // The weather conditions.
    // Probability of sunny weather
    private static final double PROBABILITY_SUNNY = 0.6;
    // Probability of cloudy weather
    private static final double PROBABILITY_CLOUDY = 0.4;
    // Probability of a hurricane
    private static final double PROBABILITY_HURRICANE = 0.3;
    // Probability of a windy day
    private static final double PROBABILITY_WINDY = 0.7;
    private static String weather;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        setWeather();
    }

    /**
     * Set the weather to be one defined in fields.
     * The weather depends on what time of day it is
     */
    public static void setWeather()
    {
        if (Time.dayTime()) {
            if (rand.nextDouble() <= PROBABILITY_SUNNY) {     // nextDouble gets random double between 0 and 1.
                weather = "Sunny";
            }
            else{
                weather = "Cloudy";
            } 
        }
        else {
            if (rand.nextDouble() <= PROBABILITY_HURRICANE) {     // nextDouble gets random double between 0 and 1.
                weather = "Hurricane";
            }
            else {
                weather = "Windy";
            } 
        }
    }
    
    /**
     * Get the weather.
     * @return the weather
     */
    public static String getWeather()
    {
        setWeather();
        return weather;
    }
}