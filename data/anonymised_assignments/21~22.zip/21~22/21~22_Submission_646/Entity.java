import java.util.List;

/**
 * Entity is an abstract class that is used to represent all the types of acting species in the simulation by encapsulating shared attributes and methods that exist
 * in all subclasses of entity such as whether the entity is alive, its gender and their location in the field [grid]
 *
 * @version (11/02/2022)
 */
public abstract class Entity
{
    
    // Whether the entity is alive or not.
    private boolean alive;
    // The entity's field.
    private Field field;
    // The entity's position in the field.
    private Location location;
    //The gender of the entity
    private Gender gender;   
    /**
     * Create a new entity [either animal or plant] at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Entity(Field field, Location location, Gender gender)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.gender = gender;
    }
    
    /**
     * Check whether the entity is alive or not.
     * @return true if the entity is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Place the entity at the new location in the given field.
     * @param newLocation The entity's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Indicate that the entity is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {   
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the entity's location.
     * @return The entity's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the entity's field.
     * @return The entity's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * return the entity's gender
     * @return The enumerated type of the entity's gender
     */
    protected Gender getGender()
    {
        return gender;
    }
    
    /**
     * Abstract method to exhibit the entity's acting behaviour
     * @param the list of new entities possibly birthed, the time of day either DAY or NIGHT and the weather
     */
    public abstract void act(List<Entity> newEntities, DayNight timeOfDay, Weather seeWeather);
    
}


