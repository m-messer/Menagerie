import java.util.HashMap;
import java.util.ArrayList;
import java.util.Set;

/**
 * Class EntityStatistics is used to keep track of a series of statistical measures that occur during the simulation that need to be passed to the bar chart. 
 * The class has one static HashMap which has a string as the key value, which is the name of the entity (Bear, Lynx, Deer....) and another 
 * HashMap as a value pair which itself contains a String-Integer pair. The string represents a statistic such as "Total OverCrowding" or "Total Animals Eaten" which 
 * depicts how many entities of a specific species died of overcrowding or were eaten respectively. This way each entity of string name Bear, Lynx , Deer... 
 * will have a set of statistics with a string explaining what the statistic is and an integer pair for the total numerical value associated to it
*
 * @version (v3)
 */
public class EntityStatistics

{ 
   //main data structure containing all entity statistics
   public static  HashMap<String, HashMap<String, Integer>> allStatistics = new HashMap<>();
   
   /**
    * Constructor to build the allStatistics HashMap with all the animals and plants' statistics for the simulation. This must be intialised before any data can be 
    * passed to an Object of EntityStatistics
    */
   public EntityStatistics()
   {
        //builds all the animals's statistics
        buildAnimal("Bear");
        buildAnimal("Lynx");
        buildAnimal("Hare");
        buildAnimal("Deer");
        buildAnimal("Goat");
        //builds all the plant statistics
        buildPlants("Yew");
        buildPlants("Grass");
   }    
   
   /**
    * Method to add to the value pair HashMap of allStatistics the base statistics and a default value of 0
    * @param plantName the name of the plant (in default case just Yew and Grass)
    */
   private void buildPlants(String plantName)
   {
        HashMap<String,Integer> entityStats = new HashMap<>();
        
        entityStats.put("Plant Eaten Deaths", 0);
        entityStats.put("Total Plants Eaten",0);
        entityStats.put("Total Plants Grown",0);
        entityStats.put("Depleted Storage Deaths",0);
        entityStats.put("Matured Plants",0);
        
        //adds all the above statistics to the main HashMap allStatistics which contains both animals and plants
        allStatistics.put(plantName, entityStats);
   }
    
   /**
    * Method to build all the default statistics for the Animals in the allStatistics object, this method sets all these animal statistics to zero as it needs to
    * build the default structure before the simulation has been run
    */ 
   private void buildAnimal(String animalName)
   {
        HashMap<String, Integer> entityStats = new HashMap<>();
        
        
        entityStats.put("Total OverCrowding",0);
        entityStats.put("Total Animals Eaten",0);
        entityStats.put("Total Died of Old Age",0);
        entityStats.put("Total Died from Hunger",0);
        entityStats.put("Total Infected",0);
        entityStats.put("Total Infected Deaths",0);
        entityStats.put("Total Births",0);
        entityStats.put("Total Poisoned",0);
        
        
        
        //adds all the above statistics to the main HashMap allStatistics which contains both animals and plants
        allStatistics.put(animalName, entityStats);
   }
    
    
    /**
     * Static Method called in the relevant position in the entity subclasse's act method that adds 1 to the relevant statistic. This allows for one dynamic method to add any type of valid
     * statistic to the allStatistic attribute. Try catch is implemented to make sure that a correct statistic string has been passed to the function at compile time.
     * 
     * @param the entity which is currently performing the act method(key in the allStatistics HashMap) and the String statistic which is refering to the key of the
     * pair value HashMap of allStatistics
     * 
     * This allows for more statistics to be added for every animal by only changing one part of the program, the buildAnimal method
     */
   public static  void addStatistic(Entity entity, String statistic)
   {
        //.getClass returns "class Bear" but string "Bear" is needed
      String entityName = entity.getClass().toString().substring(6).trim(); 
      try {
             HashMap<String, Integer> entityStats = allStatistics.get(entityName); 
             entityStats.put(statistic, entityStats.get(statistic) + 1);
      }
      catch(Exception e) {
             System.out.println("Passed statistic string does not exist");
      }
   }
    
   /**
     * Method resets all Integer values of the HashMap that is the value pair in the allStatistics HashMap
     */
    
   public void resetMap()
   {
        Set<String> animalStatistics = allStatistics.keySet();
        
       //double for loops looks at all statistics for every entity and resets their values to zero. 
       for(String animalStatistic : animalStatistics){
           Set<String> specificStatistics = allStatistics.get(animalStatistic).keySet();
           
           for(String eachStat: specificStatistics){
               allStatistics.get(animalStatistic).put(eachStat,0);
           }
       }
   }
    
    
}
