import java.util.List;

/**
 * Species of lynxes class which is a carnivore and in turn also an animal. This animal's unique behaviour is that it is Nocturnal
 *
 * @version (v2)
 */
public class Lynx extends Carnivore
{
    /**
     * Constructor for objects of class Lynx
     * @param randomAge, whether the animal has to have a random age, field, a grid the Lynx is added to  and location, which is the row and column in that field the Lynx is set in
     */
    public Lynx(boolean randomAge,Field field, Location location)
    {
        //super call that passes in all the raw numerical data that differentiates the lynx from all other species in the simulation
        super(randomAge,field,location,Gender.produceGender(),60,15,80,15,0.11,3);
        //makes the animal exhibit nocturnal behaviour meaning it moves around only at night and does not move around during the day
        setNocturnal();
    }
    
    /**
     * Abstract method implementation which creates a new Lynx, done here instead of super class
     * Location referes to the free location surrounding the female and male lynx animals at time of mating 
     */
    public void giveBirth(List<Entity> newAnimals, Location location)
    {
            Lynx lynxYoung = new Lynx(false, this.getField(), location);
            newAnimals.add(lynxYoung);
    }
    
    /**
     * Checks the species attempted to breed with this animal is of type lynx
     */
    protected boolean checkSpeciesToBreed(Object adjacentEntity)
    {
        return (adjacentEntity instanceof Lynx);
    }
    
    /**
     * Checks that the species attempted to be eaten by the lynx is valid by specifying all the non valid animals to be eaten, more efficient then specifying each possible prey either already in the default simulation or to be newly
     * added
    */
    protected boolean checkSpeciesToEat(Object entityToEat)
    {
        return(!(entityToEat instanceof Bear) && !(entityToEat instanceof Lynx) && 
        !(entityToEat == null) && !(entityToEat instanceof Plant)); 
    }
}
