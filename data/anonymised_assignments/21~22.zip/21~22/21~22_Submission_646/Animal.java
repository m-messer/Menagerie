import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * Animal is an abstract class that encapsulates together all the common attributes and behaviour present in all the animals
 * in our simulation. All the attributes of an animal have been written in this class so that addition of new shared attributes to all species of animals(Bear, Deer, Hare...) is more
 * extendable. Also, reducing the amount of code duplication as present in the original design which had all these attributes present in each species subclass which lead to a lot of code duplication and difficulty
 * adding new animals species
 * 
 * All the DEFUALT attributes are private as they are never used or required in the subclasses of each animal species (Bear ,Deer, Lynx...) and instead are initialised by a constructor call passing the raw 
 * data into the Animal Class constructor.
 * DEFAULT attributes can be accessed by protected getter methods which are only used in Carnivore or Herbivore subclasses
 * 
 * For NON-DEFAULT attributes such as whether the animal is nocturnal or not can be protected as they need to be initialised in
 * the constructor of the animal species subclass, however we have made it private and a protected method can change the default false value of this attribute to true
 * 
 * This Facilitates change and by encapsulating all common attributes in a single class there is no need to have all the attributes repeatedly initialised in each
 * new species subclass added to the simulation but simply have the constructor of this class receive all the raw data that uniquely identifies the animals' species.
 *
 * @version (11/02/2022)
 */
public abstract class Animal extends Entity
{ 
  //DEFAULT ATTRIBUTES 
    
  //Specifies the current age of the entity
  private int currentAge;
    
  //The max age of an animal before it dies
  private int maxAge;
    
  //corresponds to the food level gained by eating this animal
  private int animFoodLevel;
    
  //represents the energy with which the animal is satisfied and therefore will not hunt for food
  private int satisfiedEnergy;
    
  //corresponds to the amount of energy the entity is storing currently
  private int animEnergy;

  //represents the age an animal can breed at 
  private int breedingAge;
    
  //the probability that the animal will breed
  private double breedingProb;
    
  //the number of births that an animal will produce if it breeds
  private int birthsNo;
    
  //probability generator associated to what random age to assign to each animal
  private static final Random rand = Randomizer.getRandom();
   
  //flag to indicate whether the animal is infected
  private boolean infected = false;
   
  //Steps in the simulation that the animal has been infected (if 5 it dies) 
  private int infectionLength;
  
  //NON-DEFAULT ATTRIBUTES
  
  //flag to represent whether the animal will .act() during the night 
  private boolean isNocturnal = false;  
    /**
     * Animal constructor receives a set of values to which it initialises the class attributes which will uniquely differentiate animal species during runtime
     * @param 'randomAnimal', if the animal age is random or not, 'field' a grid the animal is added to, 'location' the location in the field the animal is in, 'gender' the gender of the animal, 'maxAge' the maximum age of the animal
     * 'animFoodLevel' the amount of energy acquired if this animal is eaten, 'satisfiedEnergy' the animal's satisfied energy level , 'breedingAge' the age the animal can breed at, 'breedingProb' probability the animal wil breed, 
     * 'birthsNo' number of young produced.
     */
  public Animal(boolean randomAnimal,Field field, Location location, Gender gender, int maxAge, int animFoodLevel,
  int satisfiedEnergy, int breedingAge, double breedingProb,int birthsNo)
  {
        super(field,location,gender);
        this.maxAge = maxAge;
        this.satisfiedEnergy = satisfiedEnergy;
        
        //if the animal to be created is not an offspring then they are assigned a random age
        if(randomAnimal){
            currentAge = rand.nextInt(maxAge);
        }else{
            currentAge = 0;
        }
        
        //the animal will have its current energy set to a random number which will go up to one minus the satisfied energy attribute
        animEnergy = rand.nextInt(satisfiedEnergy); 
        this.birthsNo = birthsNo;
        
        this.animFoodLevel = animFoodLevel;
        
        this.breedingAge = breedingAge;
        this.breedingProb = breedingProb;
        
        
        
  }
    
  /**
  * Sets the animal's nocturnal behaviour to the opposite it was (if false becomes true)
  */
  protected void setNocturnal()
  {
       isNocturnal = !isNocturnal;
  }
    
  /**
    *Act method inherited from entity which encapsulates in a single public method all of the animal's behaviours and interaction
    *@param list of new animals that could be populated as a result of the breeding, the time of day of the simulation and the weather present in the simulation
    */
  public void act(List <Entity> newAnimals, DayNight timeOfDay, Weather randomWeather)
  {
       incrementAge();
       incrementHunger();
       
       //if the animal is infected then every step of the simulation       
       if(infected){
            infectionLength++;
            if(infectionLength >= 5){
            setDead();
            
            //Adds the number of infection deaths correlated to this object's dynamic type
            EntityStatistics.addStatistic(this, "Total Infected Deaths");
            }
       }
    
        //checks if the animal is alive
       if(isAlive()){// && !(Weather.isFoggy(randomWeather))) {
            //check conditions for nocturnal behaviour (non nocturnal animals only act during the day , and nocturnal animals only act at night)
            if(!isNocturnal && timeOfDay.isDay()){
                actAnimal(newAnimals);
            }else if(isNocturnal && timeOfDay.isNight()){
                actAnimal(newAnimals);
            }
       }
    } 
    
  /**
  * This method encompases all the animal behaviour such as breeding and finding food
  */
  private void actAnimal(List <Entity> newAnimals)
  {
        //simulates mating for any animal species (potentially also for plants)
        meet(newAnimals);            
        //1% chance for an animal to become infected with a disease
        chanceOfInfection();
            
        //4% chance that if the animal is infected it will infect every other animal in the vicinity
        transmitInfection();
            
        Location newLocation;
        // Move towards a source of food if found, only if the animal has not exceeded their satisfied energy attribute (meaning the animal is not hungry) 
        if(animEnergy < satisfiedEnergy){
            newLocation = findFood();
        }else{
            newLocation = null;
        }
            
        //this animal ate something that killed it, e.g. poisonous plant therefore it does not perform the moving to a new location
        if(!isAlive()){
            return;
        }
            
        if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            // System.out.println(newLocation);
            setLocation(newLocation);
        }
        else{
            //Overcrowding.
            setDead();
                
            EntityStatistics.addStatistic(this,"Total OverCrowding");
            //Corresponds to the total number of animals died to overcrowding 
        }    
  }
    
  /**
    * Method that is executed with a 4% chance that causes an infected animal to spread its disease to all the animals in the vicinty, therefore all animals in the 
    * adjacent cells
    */
  private void transmitInfection()
  {
         if(infected && (rand.nextDouble() <= 0.04)){
             
                List<Location> adjacentLocations = this.getField().adjacentLocations(this.getLocation());
                //checks that returned list of adjacent locations is not empty
                if(!adjacentLocations.isEmpty()){    
                    for(Location adjacentLocation : adjacentLocations){
                       if(this.getField().getObjectAt(adjacentLocation) instanceof Animal){
                           Animal toBeInfectedAnim = (Animal) this.getField().getObjectAt(adjacentLocation);
                           toBeInfectedAnim.setInfected();
                           
                           EntityStatistics.addStatistic(this, "Total Infected");
                           //Adds an infected animal to statistic as the infected animal infects all animals in adjacent locations
                       }
                    }
                }
            }
  }
    
    /**
     * Look for animals adjacent to the current location which this animal can eat.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
  protected abstract Location findFood();
    
  /**
     * Method that checks whether the performing of an eat method is valid in the context that it does not exceed the satisfied energy of the animal
     * This method is implemented in both the Carnivore and Herbivore passing the relevant values to the class to perfrom an eat method
     */
  protected void performEat(int currentEnergy, int toGainEnergy, int maxEnergy)
  {
     int tempEnergy = currentEnergy + toGainEnergy;
                
    //in the case that the animal being consumed exceeds the satisifed energy
    if(tempEnergy > maxEnergy){
        int differenceEnergy =  maxEnergy - currentEnergy;
        currentEnergy = currentEnergy + differenceEnergy;
    }else{
        currentEnergy = currentEnergy + toGainEnergy;
        }
  }
    
    
  /**
  * Main method to check if an animal will mate at a particular step in the simulation
  * @param newAnimals a list of type Entity for new birthed animals to be added to the main list of entities in the simulation  
  */
  private void meet(List<Entity> newAnimals)
  {
   //gets a list of all adjacent cells to the one of the animal
   List<Location> adjacentLocations = this.getField().adjacentLocations(this.getLocation());
        
    //produce a list of free locations adjacent to the female animal for giving birth to babies
    List<Location> freeLocations = this.getField().getFreeAdjacentLocations(this.getLocation());
        
    for(Location adjacentLocation : adjacentLocations){
            
        Object adjacentObject = this.getField().getObjectAt(adjacentLocation);
        //checks if the animal attempting to breed with this animal is of the same species   
        if(checkSpeciesToBreed(adjacentObject)){
                
        Animal adjacentAnimal = (Animal) this.getField().getObjectAt(adjacentLocation);
        //Species adjacentAnimSpecies = adjacentAnimal.getSpecies();
               
        Gender adjacentAnimGender = adjacentAnimal.getGender(); 
        //breed only if this. animal is female and the adjacent animal is a male   
        if((adjacentAnimGender != null)  && !(adjacentAnimGender.equals(this.getGender()))){
                
                //get free location to put the spawns in
                int births = breed();
                for(int b = 0; b < births && freeLocations.size() > 0; b++) {
                        Location loc = freeLocations.remove(0);
                        //function that creates new animal in the relevant subclass depending on the dynamic type of this. object during runtime
                        giveBirth(newAnimals, loc);
                             
                        EntityStatistics.addStatistic(this, "Total Births");
                        //Corresponds to the total number of birthed animals
                }
        }
    }
   }
   }
   
   /**
    *Checks that the two animals attempting to breed together are of the same species (same subclass)
    */
  protected abstract boolean checkSpeciesToBreed(Object adjacentEntity);
   
  /**
  * Abstract method called to give birth of a new animal of type as the same species as the subclass that calls it
  * 
  */
  protected abstract void giveBirth(List<Entity> newAnimals, Location location);
   
  /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
  private int breed()
  {
        int births = 0;
        
        if(canBreed() && rand.nextDouble() <= breedingProb) {
            births = rand.nextInt(birthsNo) + 1;
        }
        return births;
  }

   /**
     * A animal can breed if it has reached the breeding age.
     */
  private boolean canBreed()
  {
        return currentAge >= breedingAge;
  }
     
    /**
     * Increment the age of this animal after every step of the simulation is executed
     */
  private void incrementAge()
  {
        currentAge++;
        
        if(currentAge > maxAge) {
            setDead();
            
            EntityStatistics.addStatistic(this,"Total Died of Old Age");
            //Corresponds to the total number of animals that died of old age
        }
  }
    
    /**
     * Increments the hunger level of the animal after every step of the simulation is executed
     */
  private void incrementHunger()
  {
        animEnergy--;
        
        if(animEnergy <= 0) {
            setDead();
            
            EntityStatistics.addStatistic(this,"Total Died from Hunger");
            //Corresponds to the total number of animals that have died of hunger
        }
  }
  
  /**
   * method to randomly infect an animal
   */
  private void chanceOfInfection()
  {
        //There is a 1% chance that an animal becomes infected
        //second part checks that the animal is not already infected
        if(rand.nextDouble() <= 0.01 && !(infected)){
            setInfected();
            
            EntityStatistics.addStatistic(this, "Total Infected");
            //Corresponds to the total number of infected animals in the simulation
        }
  }
    
  /**
  * sets the animal to be infected
  */
  protected void setInfected()
  {
        infected = true;
  }
  
  /**
   * returns the animal's food level, how much energy another animal gains if this one is eaten
   * @return animFoodLevel
   */
  protected int getAnimalFoodLevel()
  {
        return animFoodLevel;
  }
  
  /**
   * returns the animal's satisfied energy attribute, how much energy the animal can consume until it is satisfied and does not hunt
   * @return satisfiedEnergy
   */
  protected int getSatisfiedEnergy()
  {
        return satisfiedEnergy;
  }
  
  /**
   * returns the current energy attribute of the animal
   * @return animEnergy
   */
  protected int getCurrentEnergy()
  {
        return animEnergy;
  }
  
  /**
   * checks if the animal is infected
   */
  protected boolean isInfected()
  {
        return infected;
  }  
}
