import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.Map;
import javafx.application.Application;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing entities which are the actors of the simulator
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;
    
    //https://teaching.csse.uwa.edu.au/units/CITS1001/colorinfo.html reference for building unique colors not in by default in class Color
    private final Color LIGHT_BROWN = new Color(153,102, 0);
    private final Color LIGHT_ORANGE = new Color(255,153,0);
    private final Color DARK_GREEN = new Color(0,153,0);
    private final Color BROWN = new Color(102,51,0);
    private final Color PURPLE = new Color(102,0,153);
    
    
    // The probability that a specified animal will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.05;
    private static final double GOAT_CREATION_PROBABILITY = 0.16;    
    private static final double LYNX_CREATION_PROBABILITY = 0.09;
    private static final double HARE_CREATION_PROBABILITY = 0.20;
    private static final double DEER_CREATION_PROBABILITY = 0.13;
    
    //The below are the probability for creation of the plants in the simulation, YEWs are poisonous
    private static final double YEW_CREATION_PROBABILITY = 0.005;
    private static final double GRASS_CREATION_PROBABILITY = 0.12;

    // List of entites in the field
    private List<Entity> entities;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    //corresponds to the time of day either DAY or NIGHT (Every 5 steps is DAY and every other 5 is NIGHT)
    //Nocturnal entities act during the NIGHT and the others during the DAY
    private DayNight timeOfDay;
    
    //object to gather statistics of events during the simulation
    private EntityStatistics simulationStatistics;
    
    //The bar chart object that is displayed to the user at the end of the run long simulation
    private BarChart chart;
    
    //The weather of the simulation
    private Weather simulationWeather;
    
    //A check to see if the simulation has been run for the first time
    //For opening the javaFX application once for the bar chart and later of only to open windows of the new bar chart if the simulator is reset
    private boolean isFirstRun = true;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        entities = new ArrayList<>();
        field = new Field(depth, width);
        //set up of the entity statistics object that stores the statistics of events during the simulation
        simulationStatistics = new EntityStatistics();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        
        //colours representing the different animal species in the simulator
        view.setColor(Bear.class, Color.BLACK);
        view.setColor(Hare.class, LIGHT_BROWN);
        view.setColor(Lynx.class, LIGHT_ORANGE);
        view.setColor(Goat.class, Color.LIGHT_GRAY);
        view.setColor(Deer.class, BROWN);
        view.setColor(Yew.class, PURPLE);
        view.setColor(Grass.class, Color.GREEN);
        
        
        // Setup a valid starting point.
        reset();
        
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (1000 steps).
     */
    public void runLongSimulation()
    {
        //number passed must be greater than 0
        simulate(1000);
          
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        if (numSteps <= 0) {
            return;
        }
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
             //delay(60);   // uncomment this to run more slowly
        }
        chart.displayStatistics();
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * entity in the simulation.
     */
    public void simulateOneStep()
    {
        step++;
        //checks whether to change to night or day, done every 5 steps
        checkDay();
        //first checks whether to change the weather or not, this is done every 10 steps
        checkWeather();
        
        // Provide space for newborn entities.
        List<Entity> newEntities = new ArrayList<>();        
        // Let all entities act
        for(Iterator<Entity> it = entities.iterator(); it.hasNext(); ) {
            Entity entity = it.next();
            //pass in the time of day and weather as entities have varying behaviours based on this
            entity.act(newEntities,timeOfDay,simulationWeather);
            if(! entity.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born entities to the main lists.
        entities.addAll(newEntities);

        view.showStatus(step, field, timeOfDay,simulationWeather);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;

        //Simulation always starts off during the DAY
        timeOfDay = DayNight.setDay();
        
        //creates a random weather for the simulation to start of with
        simulationWeather = Weather.setWeather(timeOfDay);
        
        //reset the gathered statistics
        simulationStatistics.resetMap();
        
        //creates the new bar chart object passing in the relevant entityStatistic object
        chart = new BarChart(simulationStatistics);
        
        //resets the bar chart
        chart.clearBarChart();
        
        //condition to check if this is the first occurence of the reset method being called, therefore the simulator needs to create a new thread to launch
        //the bar chart manager application, else simply open a new window on the same thread to display the bar chart.
        if(isFirstRun){
            launchBarChartApplication();
        }
        
        entities.clear();
        populate();
        
        
        // Show the starting state in the view.
        view.showStatus(step, field, timeOfDay,simulationWeather);
    }

    /**
     * Method dedicated to the building of the entities in the simulation, entities are ordered in ascending order of creation probability in the if/else if statement
     * from top to bottom
     * @param the row and column of where to place the entity
     */
    private void buildEntities(int row, int col)
    {
             Random rand = Randomizer.getRandom();
        
             if(rand.nextDouble() <= YEW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                   Yew yewPlant = new Yew(true,field, location);
                    entities.add(yewPlant);
                }
             
                 else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    //an animal of random age is created
                    Bear bear = new Bear(true, field, location);
                    entities.add(bear);
                }
                 else if(rand.nextDouble() <= LYNX_CREATION_PROBABILITY){
                   Location location = new Location(row, col);
                   Lynx lynx = new Lynx(true, field, location);
                   entities.add(lynx); 
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY){
                 Location location = new Location(row, col);  
                  Grass grass = new Grass(true,field, location);
                  entities.add(grass);
                }
                 else if(rand.nextDouble()  <= DEER_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location);
                    entities.add(deer);
                }
                else if (rand.nextDouble()  <= GOAT_CREATION_PROBABILITY){
                   Location location = new Location(row, col);
                   Goat goat = new Goat(true, field, location);
                   entities.add(goat); 
                }
                else if(rand.nextDouble()  <= HARE_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Hare hare = new Hare(true, field, location);
                    entities.add(hare);
                } 
    }
   
    /**
     * Randomly populate the field with entities.
     */
    private void populate()
    {
        
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                buildEntities(row,col);
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Every 3 steps in the simulation the weather has changed
     */
    private void checkWeather()
    {
        if(step % 4== 0){
           simulationWeather = Weather.setWeather(timeOfDay); 
        }
    }
    
     /**
     * Method that keeps track of the number of steps for the day and night cycle, 5 steps are for the day and the next 5 for the night
     */
    private void checkDay()
    {
        if((step % 5 == 0) && timeOfDay.isDay()){
            //sets the time of day to night
            timeOfDay = DayNight.setNight();
        }else if((step % 5 == 0) && timeOfDay.isNight()) {
            timeOfDay = DayNight.setDay();
        }
    }
      
    /**
     * This method launches the BarChartManager's JavaFX application, creating a new thread. This is only done once, when the simulator object is first created,
     * subsequent resetting of simulators will not create new threads but simply open new windows for the bar chart on the same one
     */
    private void launchBarChartApplication()
    {
       new Thread(){
            @Override
            public void run(){
                javafx.application.Application.launch(BarChartManager.class);
                
            }
    }.start(); 
    isFirstRun = false;
    }
}