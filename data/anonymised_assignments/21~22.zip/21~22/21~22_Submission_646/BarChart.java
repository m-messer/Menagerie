import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import java.util.*;
import java.util.Arrays;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

/**
 *The bar chart object displays all the data gathered by the EntityStatistics object in a new window which is shown to the user when the long simulation of the habitat
*has ended
*
*The construcor is passed the EntityStatistics object which the constructor parses and dynamically adds its information to the x and y axies of the bar chart object
*
 * @version (v2)
 * REFERENCE = https://docs.oracle.com/javafx/2/charts/bar-chart.html
 */
public class BarChart extends Stage
{
    final CategoryAxis xAxis = new CategoryAxis();
    final NumberAxis yAxis = new NumberAxis();
    //actual bar chart object
    final StackedBarChart<String, Number> sbc =
            new StackedBarChart<String, Number>(xAxis, yAxis);
    //EntityStatistics object passed to add all raw data into the bar chart
    private EntityStatistics chartStats;
    //list of all the series (all the animals)
    private ArrayList<XYChart.Series<String, Number>> seriesList = new ArrayList<>();
    
    
    /**
     * Constructor creating the barchart based on the contents of the chartStats object passed to the constructor.
     * @param chartStats which are all the entity statistics gathered during the simulation
     */
    public BarChart(EntityStatistics chartStatistics)
    {
    this.setTitle("Simulation Data Collection");
    sbc.setTitle("Simulation Summary");
    xAxis.setLabel("Simulation Events"); //Animals
    
    this.chartStats = chartStatistics;
    
    //list to contain the x-axis labels which are the statistic strings in the allStatistics object such as "Total Animals eaten", "Total Poisoned"....
    List<String> statisticsList = new  ArrayList<>();
    
    //loops over all entities in the allStatistics object and adds all the statistic strings that represent events such as an animal eating another animal
    for(String entityName: chartStats.allStatistics.keySet()){
        Set<String> statisticNames = chartStats.allStatistics.get(entityName).keySet();
        for(String statisticName: statisticNames){
            //to make sure the same data is not added twice, also because the plant statistics are different from the animal statistic strings
            if(!(statisticsList.contains(statisticName))){
                statisticsList.add(statisticName);
            }
        }
    }
    
    //passes ArrayList as observable list to x.Axis.categories object
    xAxis.setCategories(FXCollections.observableList(statisticsList));
    

    yAxis.setLabel("Number of Entities"); 
    
    //for loop that dynamically adds all the color coding for all the entities(animals and plants) in the chartStats object
    for(String entityName : chartStats.allStatistics.keySet()){
        XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();
        series.setName(entityName);
        seriesList.add(series);
    }
}

/**
 * Adds all of the entityStatistics object's data to the bar chart and displays this information in a new window
 */
public void displayStatistics()
{
    
    Set<String> entities = chartStats.allStatistics.keySet();
    HashMap<String,Integer> entityStatistics = new HashMap<>();
    //Takes the hashmap from the EntityStatistics class
    for(String entityName: entities){
        entityStatistics = chartStats.allStatistics.get(entityName);
           
        Set<String> statisticName = entityStatistics.keySet();
        //for each entity(plant or animal) it adds all the statistical string's data to the relevant x-axies which represent that data
        for(int x = 0; x <= seriesList.size() - 1;x++){
            if(seriesList.get(x).getName().equals(entityName)){
                for(String statistic : statisticName){
                seriesList.get(x).getData().add(new XYChart.Data<String, Number>(statistic,entityStatistics.get(statistic)));
                }     
            }
        }  
       }
       
    Scene scene = new Scene(sbc, 1500, 700);
    
    //adds color coding to differentiate what data represents for which entity(animal or plant)
    for(XYChart.Series<String, Number> series: seriesList){
        sbc.getData().add(series);
    }
    this.setScene(scene);
    this.show();
    //Shows the bar chart in a new window
}

/**
 * Clears the bar chart's data
 */
public void clearBarChart()
{
  sbc.getData().clear();
  
}
}