import java.util.List;

/**
 * Species of Deer class which is a herbivore and in turn also an animal
 *
 * @version (v2)
 */
public class Deer extends Herbivore
{
    /**
     * Constructor for objects of class Deer
     * @param randomAge, whether the animal has to have a random age, field, a grid the Deer is added to  and location, which is the row and column in that field the Deer is set in
     */
    public Deer(boolean randomAge,Field field, Location location)
    {
        super(randomAge,field,location,Gender.produceGender(),50,45,100,4,0.21,3);
        
    }
    
    /**
     * Abstract method implementation which creates a new Deer, done here instead of super class
     * Location referes to the free location surrounding the female and male deer animals at time of mating 
     */
    public void giveBirth(List<Entity> newAnimals, Location location)
    {
            Deer deerYoung = new Deer(false, this.getField(), location);
            newAnimals.add(deerYoung);
    }
    
    /**
     * Checks the species attempted to breed with this animal is of type Deer
     */
    protected boolean checkSpeciesToBreed(Object adjacentEntity)
    {
        return (adjacentEntity instanceof Deer);
    }
    
}
