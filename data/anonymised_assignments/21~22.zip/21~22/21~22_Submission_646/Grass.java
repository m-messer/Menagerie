import java.util.List;
/**
 *Species of grass class which is a plant which is the most commonly eaten plabt by herbivores
 *
 * @version (v2)
 */
public class Grass extends Plant
{
    /**
     * Constructor for objects of class Grass
     * @param 'randomGrowthLevel' ,whether the Grass has to a random growth level attributed to it, 'field', the grid to which the Grass is added to, 'location', the 
     * row and column of the field where the Grass is specifically placed in
     */
    public Grass(boolean randomGrowthLevel,Field field, Location location)
    {
       super(randomGrowthLevel,field,location,Gender.setNull(),100,300, 40, 40) ;
    }
    
    /**
     * implementation of abstract method in plant that spawns new plants of this species type in a location adjacent and free to this plant object that spawned it
     */
    public void spawnPlant(List<Entity> newPlants, Location location) {
        Grass toSpawnGrass = new Grass(false,this.getField(), location);
        newPlants.add(toSpawnGrass);
    }
    
}
