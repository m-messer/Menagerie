import java.util.List;
import java.util.Iterator;


/**
 *Herbivore is a subclass of animal used to differentiate animals which only eat entities of type plant from carnivores. 
 *
 * @version (v1)
 */
public abstract class Herbivore extends Animal
{
    /**
     * Constructor receiving and passing the same values to its super constructor in animal
     */
    public Herbivore (boolean randomAnimal,Field field, Location location, Gender gender, int maxAge, int animFoodLevel,
    int animMaxEnergy, int breedingAge, double breedingProb,int birthsNo)
    {
    super(randomAnimal, field, location,  gender, maxAge,animFoodLevel,
    animMaxEnergy,breedingAge,breedingProb,birthsNo);
    }

    /**
     * Look for plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where plant was found, or null if it wasn't.
     */
    protected Location findFood()
    {
    Field field = getField();
    List<Location> adjacent = field.adjacentLocations(getLocation());
    Iterator<Location> it = adjacent.iterator();
    while(it.hasNext()) {
        Location where = it.next();
        Object entity = field.getObjectAt(where);
        //checks if the adjacent object is of type plant
        if(entity instanceof Plant){
            Plant eatenPlant = (Plant) entity;
            //plant has to be alive and of correct maturity to be eaten by the herbivore
            if(eatenPlant.isAlive() && eatenPlant.checkMaturity()) {
                
                
                //how much of the plant will be eaten depending on the herbivore's satisfied energy attribute
                int amountEaten = this.eatPlant(eatenPlant.getPlantHealth());
                eatenPlant.updatePlantHealth(amountEaten);
                
                performEat(this.getCurrentEnergy(), amountEaten, this.getSatisfiedEnergy());
                
                if(eatenPlant.isPoisonous()){
                    this.setDead();
                    //adds poisoned and eaten plant as statistical measure
                    EntityStatistics.addStatistic(this,"Total Poisoned");
                    EntityStatistics.addStatistic(eatenPlant,"Total Plants Eaten");
                    return null;
                }
                //add eaten plant as statistical measure
                EntityStatistics.addStatistic(eatenPlant,"Total Plants Eaten");
                
                //the animal has eaten only part of the plant and cannot move to its location as it has not fully eaten it
                if(eatenPlant.isAlive()){
                    return null;
                }
                
                return where;
        }
    }
    }
    return null;
    }
    
    /**
     * Different herbivores have different sizes and therefore will eat different amounts of a plant depending on their satisfied energy attribute.
     * All herbivores will eat 90% of their satisfied energy, this value will be taken away from the plant's health
     */
    private int eatPlant(int plantHealth)
    {
        int eatenAmount = (int) Math.round(0.9 * this.getSatisfiedEnergy());
        
        if(eatenAmount > plantHealth){
            return plantHealth;
        }else{
        return eatenAmount;
        }
    }
    
    /**
     * Abstract method called to give birth of a new animal of type as the same species as the subclass that calls it
     */
    protected abstract void giveBirth(List <Entity> newAnimals, Location location);
    
    /**
     * Checks that the two animals attempting to breed together are of the same species (same subclass)
     */
    protected abstract boolean checkSpeciesToBreed(Object adjacentEntity);
   
}
