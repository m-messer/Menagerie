import java.util.List;

/**
 * Species of bears class which is a carnivore and in turn also an animal
 *
 * @version (v2)
 */
public class Bear extends Carnivore
{
    /**
     * Constructor for objects of class Bear
     * @param randomAge, whether the animal has to have a random age, field, a grid the Bear is added to  and location, which is the row and column in that field the Bear is set in
     */
    public Bear(boolean randomAge,Field field, Location location)
    {
        //super call that passes in all the raw numerical data that differentiates the bear from all other species in the simulation
        super(randomAge,field,location,Gender.produceGender(),80,100,100,12,0.11,2);
        
    }
    
    /**
     * Abstract method implementation which creates a new Bear, done here instead of super class
     * Location referes to the free location surrounding the female and male bear animals at time of mating 
     */
    protected void giveBirth(List<Entity> newAnimals, Location location)
    {
            Bear bearYoung = new Bear(false, this.getField(), location);
            newAnimals.add(bearYoung);
    }
    
    /**
     * Checks the species attempted to breed with this animal is of type bear
     */
    protected boolean checkSpeciesToBreed(Object adjacentEntity)
    {
        return (adjacentEntity instanceof Bear);
    }
    
    /**
     * Checks that the species attempted to be eaten by the bear is valid by specifying all the non valid animals to be eaten, more efficient then specifying each possible prey either already in the default simulation or to be newly
     * added
    */
    protected boolean checkSpeciesToEat(Object entityToEat)
    {
        return(!(entityToEat instanceof Bear) && (entityToEat != null) && 
        !(entityToEat instanceof Plant) && !(entityToEat instanceof Lynx));
    }
}