import java.util.List;
/**
 *Species of yew class which is a plant which is a less frequent plant that is poisonous and if eaten causes the animal to die
 *
 * @version (v2)
 */
public class Yew extends Plant
{
    /**
     * Constructor for objects of class Grass
     * @param 'randomGrowthLevel' ,whether the Yew has to a random growth level attributed to it, 'field', the grid to which the Yew is added to, 'location', the 
     * row and column of the field where the Yew is specifically placed in
     */
    public Yew(boolean randomGrowthLevel,Field field, Location location)
    {
        super(randomGrowthLevel,field,location,Gender.setNull(), 60, 210, 30,30) ;
        //makes this plant poisonous
        setPoisonous();
    }

     /**
     * implementation of abstract method in plant that spawns new plants of this species type in a location adjacent and free to this plant object that spawned it
     */
    public void spawnPlant(List<Entity> newPlants, Location location) 
    {
        Yew toSpawnYew = new Yew(false,this.getField(), location);
        newPlants.add(toSpawnYew);
    }
}
