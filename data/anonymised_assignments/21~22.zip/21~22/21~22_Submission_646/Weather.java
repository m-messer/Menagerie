import java.util.Random;
import java.util.*;



/**
 * Enumeration class Weather - This class is to determine what the weather will be each step depending on whether it is day or night. The weather variations only affect
 * the Plants objects.
 *
 * @version (v1)
 */
public enum Weather
{
    
    
        RAIN, WIND, SUN;
        
        
        //https://intellipaat.com/community/39397/pick-a-random-value-from-an-enum
        private static List<Weather> PWEATHER = Collections.unmodifiableList(Arrays.asList(values()));
        
        //Creates a list of all the enums
        private static final int SIZE = PWEATHER.size();
        //Getting the size of the list
        private static final Random rand = Randomizer.getRandom();
    
        public static Weather setWeather(DayNight timeOfDay) {
        //Seeing if it is day or night then calling the appropriate method
        if(timeOfDay.isDay()) {
            return randomDayWeather();
        } else if(timeOfDay.isNight()) {
            return randomNightWeather();
        }
        return null;
        }
        
        /**
         * static method that creates a random day weather which is different from a random night weather
         */
        public static Weather randomDayWeather() {
            return PWEATHER.get(rand.nextInt(SIZE));
            //Returning a random weather
        }
        
        /**
         * static method that creates a random night weather which is different from a random day weather
         */
        public static Weather randomNightWeather() {
            return PWEATHER.get(rand.nextInt(SIZE-1));
            //Returning a random weather without SUN
        }
        
        /**
         * checks whether the passed Weather enum type is of type SUN
         */
        public static boolean isSunny(Weather CWeather) {
            return (CWeather.equals(Weather.SUN));
        }
        
        /**
         * checks whether the passed Weather enum type is of type RAIN
         */
        public static boolean isRainy(Weather CWeather) {
            return (CWeather.equals(Weather.RAIN));
        }
        
        /**
         * checks whether the passed Weather enum type is of type WIND
         */
        public static boolean isWindy(Weather CWeather) {
            return (CWeather.equals(Weather.WIND));
        }
    }