import java.util.List;
import java.util.Iterator;

/**
 * Carnivore is an abstract class used to identify animals that prey on other animal species, seperating them from herbivores. These animals will have a set of allowed prey to hunt and these are
 * specified by the checkSpeciesToEat method.  
 *
 * @version (v2)
 */
public abstract class Carnivore extends Animal
{
    /**
     * Constructor calls the super constructor of animal taking in the same values
     */
    public Carnivore (boolean randomAnimal,Field field, Location location, Gender gender, int maxAge, int animFoodLevel,
    int satisfiedEnergy, int breedingAge, double breedingProb,int birthsNo)
    {
    super(randomAnimal, field, location,  gender, maxAge,animFoodLevel,
    satisfiedEnergy,breedingAge,breedingProb,birthsNo);
    }
    
    /**
     * Look for allowed prey adjacent to the current location.
     * Only the first live prey found is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
    Field field = getField();
    List<Location> adjacent = field.adjacentLocations(getLocation());
    Iterator<Location> it = adjacent.iterator();
    while(it.hasNext()) {
        Location where = it.next();
        Object entity = field.getObjectAt(where);
        //checks adjacent entity found is of dynamic type of allowed species to eat for this animal
        if(checkSpeciesToEat(entity)){
            //casting as it is known the object is of type animal
            Animal eatenAnimal = (Animal) entity;
            if(eatenAnimal.isAlive()) {
               //carnivore eats another animal, this method processes the act of eating by adding the eaten animal's food level to the current energy level of the 
               //eating animal without exceeding satisfied energy attribute
               performEat(this.getCurrentEnergy(), eatenAnimal.getAnimalFoodLevel(), this.getSatisfiedEnergy());
                
                //Attempted animal to be eaten is infected then the eating animal also becomes infected
                if(eatenAnimal.isInfected()){
                    this.setInfected();
                    
                    //this animal becomes infected therefore adding to the statistic
                    EntityStatistics.addStatistic(this, "Total Infected");
                }
                
                eatenAnimal.setDead();
                
                EntityStatistics.addStatistic(eatenAnimal, "Total Animals Eaten");
                //Corresponds to the total number of eaten animals
                
                return where;
        }
    }
    }
    return null;
    }
    
    /**
     * abstract method that checks the species the animal is allowed to eat returning a boolean
     * @return a boolean of whether the animal species can be eaten
     */
    protected abstract boolean checkSpeciesToEat(Object entityToEat);
    
    /**
     * Abstract method called to give birth of a new animal of type as the same species as the subclass that calls it
     */
    protected abstract void giveBirth(List <Entity> newAnimals, Location location);
    
    /**
     * Checks that the two animals attempting to breed together are of the same species (same subclass)
     */
    protected abstract boolean checkSpeciesToBreed(Object adjacentEntity);
   
}
