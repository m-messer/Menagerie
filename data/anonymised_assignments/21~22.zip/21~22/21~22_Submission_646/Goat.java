import java.util.List;

/**
 * Species of Goat class which is a herbivore and in turn also an animal
 *
 * @version (v2)
 */
public class Goat extends Herbivore
{
    /**
     * Constructor for objects of class Goat
     * @param randomAge, whether the animal has to have a random age, field, a grid the Goat is added to  and location, which is the row and column in that field the Goat is set in
     */
    public Goat(boolean randomAge,Field field, Location location)
    {
        super(randomAge,field,location,Gender.produceGender(),40,40,100,5,0.18,3);
        
    }
    
    /**
     * Abstract method implementation which creates a new Goat, done here instead of super class
     * Location referes to the free location surrounding the female and male goat animals at time of mating 
     */
    public void giveBirth(List<Entity> newAnimals, Location location)
    {
            Goat goatYoung = new Goat(false, this.getField(), location);
            newAnimals.add(goatYoung);
    }
    
    /**
     * Checks the species attempted to breed with this animal is of type Goat
     */
    protected boolean checkSpeciesToBreed(Object adjacentEntity)
    {
        return (adjacentEntity instanceof Goat);
    }
}
