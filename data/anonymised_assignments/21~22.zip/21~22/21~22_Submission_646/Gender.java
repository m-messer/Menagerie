import java.util.Random;

/**
 * Enumeration class Gender - Enumerated types used to classify the gender of an entity, either MALE or FEMALE
 *
 * @version (12/10/2022)
 */
public enum Gender
{
    FEMALE, MALE, NULL;
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * returns an enum type to represent whether the animal is female or male, creating a 50 - 50 population of female and male animals
     * 
     * @return enumerated Gender type [either FEMALE or MALE]
     */
    public static Gender produceGender()
    {            
            if(rand.nextDouble() < 0.5){
                    return MALE;
                    
            }else{
                    return FEMALE;
                }
    }
    
    /**
     * Sets the Gender enum type to null, this is used in plants which at design time of the project have been decided to have no gender, thus NULL
     */
    public static Gender setNull()
    {
        return NULL;
    }
}