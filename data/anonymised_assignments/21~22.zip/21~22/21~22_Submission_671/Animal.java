import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of all animals.
 *
 * @version 2022.03.02.
 */
public abstract class Animal extends Species
{    
    Random rand = new Random();
    
    // Holds the food level of the species
    private int foodLevel;
    
    // Determines whether the organism is a female or male 
    private boolean isFemale;
    // Likelihood of an organism being female.
    private static final double FEMALE_PROBABILITY = 0.5;
    
    // Determines whether the organism is poisoned or not.
    private boolean poisoned;
    // Checks to see how long the animal has been poisoned for
    private int poisonCounter;
    
    // Determines whether the organism is diseased or not.
    private boolean diseased;
    // Probability that an animal will be diseased.
    private static final double DISEASED_PROBABILITY = 0.01; 
    //Proabability that an animal will spread the disease.
    private static final double DISEASE_SPREAD_CHANCE = 0.05;
    // Probability that an animal dies from the disease.
    private static final double DEATH_BY_DISEASE = 0.2;
    
    /**
     * Create a new species at location in field.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        setGender();
        poisonCounter = 0;
        poisoned = false;
        diseased = false;
    } 
    
    /**
     * Randomly decides an animal's gender.
     */
    public void setGender() { 
        if (rand.nextDouble() <= FEMALE_PROBABILITY) {
            isFemale = true; 
        } 
        else {
            isFemale = false;
        }
    }
    
    /**
     * @return true whether animal is a female.
     */
    public boolean getGender() {
        return isFemale; 
    }
    
    /**
     * Common behaviour between species.
     * @param newAnimals A list to receive newly born animals, and their age limit.
     */
    protected void commonBehaviour(List<Animal> newAnimals, int maxAge) {
        updateAge(maxAge);
        updateHunger(); 
        
        Location newLocation;
        
        if(isAlive()) { 
            // Males look for females to mate.
            if(foodLevel > foodLevel / 1.5 && !getGender()) {
                // Move towards a mate if found.
                newLocation = findMate(newAnimals);
            }
            else if(isDiseased() && rand.nextDouble() < DISEASE_SPREAD_CHANCE) {
                // Disease inhibits animal's normal functionality.
                newLocation = spreadDisease();
            }
            else {
                // Move towards a source of food if found.
                newLocation = findFood();
            }
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
                            
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            } 
            
            if(isDiseased() && rand.nextDouble() <= DEATH_BY_DISEASE) {
                setDead();
            }
        }
    }
    
    /**
     * Behaviour of sleeping animals.
     * @param Age limit.
     */
    protected void sleepingBehaviour(int maxAge) {
        updateAge(maxAge);
        updateHunger(); 
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals, their age limit, and time period.
     */
    abstract protected void act(List<Animal> newAnimals, int maxAge, boolean dayTime); 
    
    /**
     * Look for food adjacent to the animal's current location.
     * Only the first food is eaten.
     */
    abstract protected Location findFood(); 
    
    /**
     * Make this organism more hungry. This could result in the organism's death.
     */
    protected void updateHunger() {
        foodLevel--;
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
    
    /**
     * Sets the food level of a species.
     */
    protected void setFoodLevel(int num) {
        foodLevel = num;
    }
    
    /**
     * @return organism's food level.
     */
    protected int getFoodLevel() {
        return foodLevel;
    }
    
    /**
     * Make a male animal find a female mate.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract protected Location findMate(List<Animal> newAnimals); 
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed(int breedingAge, double breedingProb, int maxLitter, Random rand) {
        int births = 0;
        if(canBreed(breedingAge) && rand.nextDouble() <= breedingProb) {
            births = rand.nextInt(maxLitter) + 1;
        }
        return births;
    }
    
    /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    protected boolean canBreed(int breedingAge) {
        int age = getAge();
        return age >= breedingAge;
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    abstract protected void giveBirth(List<Animal> newAnimals); 
    
    /**
     * Poisons the animal.
     */
    protected void setPoison() {
        poisoned = true;
    } 
    
    /**
     * Updates the animal's current poison status. After a random amount of 
     * time it disappears.
     */
    protected void resetPoisonCounter() {
        // Randomly choose poison's lengths.
        int lengthOfPoison = rand.nextInt(10) + 1;   
        if (poisonCounter == lengthOfPoison) {
            poisoned = false;
            poisonCounter = 0;
        }
        else {
            poisonCounter++;
        }
    }
    
    /**
     * Check whether the organism is poisoned or not.
     * @return true if the organism is poisoned.
     */
    protected boolean isPoisoned()
    {
        return poisoned;
    } 
    
    /**
     * Look for animals adjacent to the current location that are diseased.
     * @return Where a diseased animal was found, or null if it wasn't.
     */
    protected Location spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            
            if (animal instanceof Animal) {
                Animal diseasedAnimal = (Animal) animal;
                if(diseasedAnimal.isDiseased()) {
                    setDisease();
                }
            }
        }
        return null;
    }
    
    /**
     * Makes an animal diseased.
     */
    protected void hasDisease() {
        diseased = true;
    } 
    
    /**
     * Randomly decides if an animal's diseased.
     */
    public void setDisease() {
        if (rand.nextDouble() <= DISEASED_PROBABILITY) {
            diseased = true; 
        } 
        else {
            diseased = false;
        }
    }
    
    /**
     * Check whether the organism is diseased or not.
     * @return true if the organism is diseased.
     */
    protected boolean isDiseased()
    {
        return diseased;
    }
}
