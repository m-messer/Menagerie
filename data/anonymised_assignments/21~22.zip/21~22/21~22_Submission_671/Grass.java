import java.util.List;
import java.util.Random;

/**
 * Simple model of grass.
 * Grass can grow, die, and be eaten by prey.
 *
 * @version 2022.03.02
 */
public class Grass extends Plant
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom(); 
    // The age to which grass can live.
    private static final int MAX_AGE = 10;
    
    /**
     * Create grass. Grass is created with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location, int age)
    {
       super(field, location);
       setDefaultAge(0); 
       setMaxAge(MAX_AGE);
       
       if (randomAge) {
            setDefaultAge(rand.nextInt(MAX_AGE));
        }
    } 
    
    /**
     * Make grass act - that is: make it do
     * whatever it wants/needs to do.
     * @param newGrass A list to receive newly created grass, their age limit, and time period.
     */
    protected void act(List<Plant> newGrass, int maxAge, boolean daytime) {
        commonBehaviour(newGrass, maxAge); 
    }
}
