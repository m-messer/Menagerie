import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a pigeon.
 * Pigeons age, move, eat grass and berries, they also die.
 *
 * @version 2022.03.02
 */
public class Pigeon extends Animal
{
    // The age at which a pigeon can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a pigeon can live.
    private static final int MAX_AGE = 25;
    // The likelihood of a pigeon breeding.
    private static final double BREEDING_PROBABILITY = 0.47;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // Number of steps a pigeon can take before it eats again. 
    private static final int PLANT_FOOD_VALUE = 16;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a pigeon. A pigeon can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the pigeon will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Pigeon(boolean randomAge, Field field, Location location, int age)
    {
        super(field, location);
        setDefaultAge(age);
        setGender(); 
        setDisease();
        setMaxAge(MAX_AGE); 
        setFoodLevel(PLANT_FOOD_VALUE); 
        
        if(randomAge) {
            setDefaultAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(PLANT_FOOD_VALUE));
        } 
        else {
            setDefaultAge(0); 
            setFoodLevel(PLANT_FOOD_VALUE);
        } 
    } 
    
    /**
     * This is what the pigeon does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPigeons A list to return newly born pigeons.
     */
    protected void act(List<Animal> newPigeons, int maxAge, boolean daytime) {
        if(daytime) {
            commonBehaviour(newPigeons, maxAge);    
        }
        else {
            sleepingBehaviour(maxAge);
        }
    } 
    
    /**
     * Look for food adjacent to the current location.
     * Only the first food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant.isAlive()) { 
                    plant.setDead();
                    setFoodLevel(PLANT_FOOD_VALUE);
                    return where;
                }
                else if(plant instanceof PoisonBerry) {
                    PoisonBerry berry = (PoisonBerry) plant; 
                    if (berry.isAlive()) {
                        berry.setDead(); 
                        setPoison();
                        return where;
                    }
                }
            }
        }
        return null;
    } 
    
    /**
     * Look for mating partner adjacent to the current location.
     * Only the first mating partner will be mated with.
     */
    protected Location findMate(List<Animal> newPigeons) {
        Field field = getField(); 
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where); 
            if (animal instanceof Pigeon) {
                Pigeon pigeon = (Pigeon) animal; 
                boolean isFemale = pigeon.getGender(); 
                if(pigeon.isAlive() && isFemale && !isPoisoned()) {
                    giveBirth(newPigeons);
                }
            }
        }
        return null;
    } 
    
    /**
     * Check whether or not this pigeon is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPigeons A list to return newly born pigeons.
     */
    protected void giveBirth(List<Animal> newPigeons)
    {
        // New pigeons are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, rand);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Pigeon young = new Pigeon(false, field, loc, 0);
            newPigeons.add(young);
        }
    }
}
