import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a squirrels.
 * Squirrels age, move, eat grass and berries, they also die.
 *
 * @version 2022.03.02
 */
public class Squirrel extends Animal
{
    // The age at which a squirrel can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a squirrel can live.
    private static final int MAX_AGE = 20;
    // The likelihood of a squirrel breeding.
    private static double BREEDING_PROBABILITY = 0.4; // 45
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // Number of steps a squirrel can take before it eats again. 
    private static final int FOOD_VALUE = 14;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new squirrel. A squirrel may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the squirrel will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Squirrel(boolean randomAge,Field field, Location location, int age)
    {
        super(field, location);
        setDefaultAge(age);
        setGender(); 
        setDisease();
        setMaxAge(MAX_AGE); 
        setFoodLevel(FOOD_VALUE);
        
        if(randomAge) {
            setDefaultAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(FOOD_VALUE));
        } 
        else {
            setDefaultAge(0); 
            setFoodLevel(FOOD_VALUE);
        }
    }  
    
    /**
     * This is what the rabbit does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newSquirrels A list to return newly born squirrels.
     */
    protected void act(List<Animal> newSquirrels, int maxAge, boolean daytime) {
        if(daytime) {
            if(environment.getSeason().equals("Spring")) {
                BREEDING_PROBABILITY = 0.55;
            }
            else {
                BREEDING_PROBABILITY = 0.47;
            }
            resetPoisonCounter();
            commonBehaviour(newSquirrels, maxAge);    
        }
        else {
            sleepingBehaviour(maxAge);
        }
    } 
    
    /**
     * Look for food adjacent to the current location.
     * Only the first food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext() && !environment.getWeather().equals("Fog")) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Grass) {
                Grass grass = (Grass) plant;
                if(grass.isAlive()) { 
                    grass.setDead();
                    setFoodLevel(FOOD_VALUE);
                    return where;
                }
            }
            else if(plant instanceof PoisonBerry) {
                PoisonBerry berry = (PoisonBerry) plant; 
                if (berry.isAlive()) {
                    berry.setDead(); 
                    setFoodLevel(FOOD_VALUE);
                    setPoison();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Look for mating partner adjacent to the current location.
     * Only the first mating partner will be mated with.
     */
    protected Location findMate(List<Animal> newSquirrels) {
        Field field = getField(); 
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where); 
            if (animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal; 
                boolean isFemale = squirrel.getGender(); 
                if(squirrel.isAlive() && isFemale && !isPoisoned()) {
                    giveBirth(newSquirrels);
                    return where;
                }
            }
        }
        return null;
    } 
    
    /**
     * Check whether or not this squirrel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSquirrels A list to return newly born squirrels.
     */
    protected void giveBirth(List<Animal> newSquirrels)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, rand);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Squirrel young = new Squirrel(false, field, loc, 0);
            newSquirrels.add(young);
        }
    } 
}
