
/**
 * The snowing class is a subclass of the Weather class.
 * Is used to simulate the snowy weather.
 *
 * @version 12/02/2022
 */
public class Snowing extends Weather
{
    /**
      * Constructor for objects of class Raining
     */
    public Snowing()
    {
    }
    
    /**
     * Returns the name of the weather, in this case "Snowing".
     * @return The weather "Snowing"
     */
    public String returnWeatherName() {
        return "Snowing";
    }
}
