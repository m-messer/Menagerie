import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

/**
 * Represent a rectangular grid of field positions.
 * Each position is able to store a single animal.
 *
 * @version 2022.03.02
 */
public class Field
{

    // A random number generator for providing random locations.
    private static final Random rando = Randomizer.getRandom();
    private Random rand = new Random();
    
    // The depth and width of the field.
    private int depth, width;
    // Storage for the animals.
    private Animal[][] field;
    // Storage for terrain information
    private Terrain[][] Earth;
    // Storage for plants
    private Plants[][] plant;


    /**
     * Represent a field of the given dimensions.
     * @param depth The depth of the field.
     * @param width The width of the field.
     * @throws IOException
     */
    public Field(int depth, int width)
    {
       
        this.depth = depth;
        this.width = width;
        field = new Animal[depth][width];

        // this is another layer of feild to indicate all terrein stuuf
        //like light level and earth permubility is there water ext
        Earth = new Terrain[depth][width];

        // this is another layer of feild to indicate all plants
        plant = new Plants[depth][width];

        for (int row =0; row< getDepth(); row++){
            for(int col = 0; col<getWidth();col++){
                
                // setting the terreain of each sqr
                if (col < width/4){

                    Earth[row][col] = new Terrain(0,rand.nextInt(10));

                }
                else if (col < width/2){

                    Earth[row][col] = new Terrain(1,rand.nextInt(10));
                    
                }
                else if (col < width*3/4){

                    Earth[row][col] = new Terrain(2,rand.nextInt(10));
                    
                }
                else{

                    Earth[row][col] = new Terrain(3,rand.nextInt(10));
                    
                }


            }


        }

        setTerrain();


    }

    /**
     * sets the terrain for the map
     */
    public void setTerrain() {


        //depth width
        // setting the mountain, the x and y are the epicenter
        int y = rand.nextInt(depth -1);
        int x = rand.nextInt(width-1);

        // set the epicenter at max hieght
        Terrain epicenter = getTerrainAt(y,x);
        epicenter.setElevation(getGetMaxElevation());
        Location temp = new Location(y, x);

        setTerrainPath(temp);



    }

    /**
     * generates elevated terrain in an area
     * given the information about the random elevation
     * such as the location of the epicentre, elevation of the epicentre...
     * @param place epicentre of elevation
     */
    private void setTerrainPath(Location place) {


        Terrain adjacent;

        Terrain epicentre;

        List<Location> locations;

        List<Location> epicentres = new LinkedList<>();

        epicentres.add(place);

        List<Location> newLocation = adjacentLocations(place) ;



        // make a mountain

        while(epicentres.size()>0){

            newLocation.clear();

            for(Location epicentreLoc : epicentres){

                epicentre = getTerrainAt(epicentreLoc);
                locations = adjacentLocations(epicentreLoc);

                for(Location next : locations){
                    

                    adjacent = getTerrainAt(next.getRow(),next.getCol());

                    if(epicentre.getElevation() != 0 && adjacent.getElevation() == 0 && place.getRow() != 0 && place.getCol() !=0){
                    

                        if(rand.nextDouble() <= getMaxCliffChance()){
                            adjacent.setElevation(epicentre.getElevation()-1);
                        }

                        else{
                            adjacent.setElevation(epicentre.getElevation());
                        }

                        if(adjacent.getElevation()>0){
                            if(!newLocation.contains(next)){
                             newLocation.add(next);
                            }
                        }

                    
                    }

                }
            }
            epicentres.clear();
            for(Location plot : newLocation){
                epicentres.add(plot);
            }



        }

    }
    
    /**
     * Empty the all the fields except terrain
     */
    public void clear()
    {
        for(int row = 0; row < depth; row++) {
            for(int col = 0; col < width; col++) {
                field[row][col] = null;
                plant[row][col] = null;
                Earth[row][col].clear();
            }
        }


    }
    
    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    public void clearAnimal(Location location)
    {
        field[location.getRow()][location.getCol()] = null;
    }

    /**
     * Clear the given location.
     * @param location The location to clear.
     */
    public void clearPlant(Location location)
    {
        plant[location.getRow()][location.getCol()] = null;
    }
    
    /**
     * Place an animal at the given location.
     * If there is already an animal at the location it will
     * be lost.
     * @param animal The animal to be placed.
     * @param row Row coordinate of the location.
     * @param col Column coordinate of the location.
     */
    public void place(Animal animal, int row, int col)
    {
        place(animal, new Location(row, col));
    }
    
    /**
     * Place an animal at the given location.
     * If there is already an animal at the location it will
     * be lost.
     * @param animal The animal to be placed.
     * @param location Where to place the animal.
     */
    public void place(Animal animal, Location location)
    {
        field[location.getRow()][location.getCol()] = animal;
    }

        /**
     * Place an plant at the given location.
     * If there is already an animal at the location it will
     * be lost.
     * @param plant The plant to be placed.
     * @param location Where to place the plant.
     */
    public void placePlant(Plants plant_m, Location location)
    {
        plant[location.getRow()][location.getCol()] = plant_m;
    }
    
    /**
     * Return the animal at the given location, if any.
     * @param location Where in the field.
     * @return The animal at the given location, or null if there is none.
     */
    public Animal getAnimalAt(Location location)
    {
        return getAnimalAt(location.getRow(), location.getCol());
    }

    /**
     * Return the plant at the given location, if any.
     * @param location Where in the field.
     * @return The plant at the given location, or null if there is none.
     */
    public Plants getPlantAt(Location location)
    {
        return getPlantAt(location.getRow(), location.getCol());
    }
    
    /**
     * Return the animal at the given location, if any.
     * @param row The desired row.
     * @param col The desired column.
     * @return The animal at the given location, or null if there is none.
     */
    public Animal getAnimalAt(int row, int col)
    {
        return field[row][col];
    }

    /**
     * Return the plant at the given location, if any.
     * @param row The desired row.
     * @param col The desired column.
     * @return The plant at the given location, or null if there is none.
     */
    public Plants getPlantAt(int row, int col)
    {
        return plant[row][col];
    }

    /**
     * Return the terrain at the given location
     * @param row The desired row.
     * @param col The desired column.
     * @return The Terrain at the given location
     */
    public Terrain getTerrainAt(int row, int col){
        return Earth[row] [col];
    }

    /**
     * Return the terrain at the given location
     * @param location terrain at desired Location
     * @return The Terrain at the given location
     */
    public Terrain getTerrainAt(Location location)
    {
        return getTerrainAt(location.getRow(), location.getCol());
    }

    /**
     * Updates weather given the season
     * checks and updates according to each season
     * removes snow in summer, adds water in spring, adds snow in winter
     */
    public void FieldUpdate(){

        Terrain temp;

        // for snow
        switch(Terrain.getSeason()){

            case 0:
            for (int row =0; row< getDepth(); row++){
                for(int col = 0; col<getWidth();col++){
                    Earth[row][col].takeAwaySnow();
                }
            }
            break;
            case 1:
            for (int row =0; row< getDepth(); row++){
                for(int col = 0; col<getWidth();col++){
                    if(rand.nextDouble()<= getWaterChance() && Earth[row][col].getWaterToGrow()>1){
                        Earth[row][col].editWaterToGrow(-rand.nextInt(2));
                    }
                }
            }
            break;
            case 2:
                if(Terrain.getSeason() == 2){
                    for (int row =0; row< getDepth(); row++){
                        for(int col = 0; col<getWidth();col++){
                            temp = Earth[row][col];
                            if(temp.getElevation() == getGetMaxElevation()){
                                if(rand.nextDouble() <= getSnowChance()){
                                    temp.putSnow();
                                }
                            }
                            else if(rand.nextDouble() <= (getSnowChance()/10)){
                                temp.putSnow();
                            }
                            if(rand.nextDouble()<=getWaterChance() && Earth[row][col].getWaterToGrow()<9){
                                Earth[row][col].editWaterToGrow(rand.nextInt(2));
                            }

                        }
                    }

                }
            break;
        }

        Terrain.changeStartingLight(getDaysPerSeaoson());
    }

        //update Season levels specific

    /**
     * updates the starting light levels of the terrain
     * @param season integer value of the season to set to
     * @param time integer value of the time to set to
     */
    public void FieldUpdate(int season, int time){

         Terrain.changeStartingLight(season,time);
    }
    
    /**
     * Generate a random location that is adjacent to the
     * given location, or is the same location.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location randomAdjacentLocation(Location location)
    {
        List<Location> adjacent = adjacentLocations(location);
        return adjacent.get(0);
    }
    
    /**
     * Get a shuffled list of the free adjacent locations.
     * @param location Get locations adjacent to this.
     * @return A list of free adjacent locations.
     */
    public List<Location> getFreeAdjacentLocations(Location location)
    {
        List<Location> free = new LinkedList<>();
        List<Location> adjacent = adjacentLocations(location);
        for(Location next : adjacent) {
            if(getAnimalAt(next) == null) {
                free.add(next);
            }
        }
        return free;
    }

    
    /**
     * Try to find a free location that is adjacent to the
     * given location. If there is none, return null.
     * The returned location will be within the valid bounds
     * of the field.
     * @param location The location from which to generate an adjacency.
     * @return A valid location within the grid area.
     */
    public Location freeAdjacentLocation(Location location)
    {
        // The available free ones.
        List<Location> free = getFreeAdjacentLocations(location);
        if(free.size() > 0) {
            return free.get(0);
        }
        else {
            return null;
        }
    }

    /**
     * Return a shuffled list of locations adjacent to the given one.
     * The list will not include the location itself.
     * All locations will lie within the grid.
     * @param location The location from which to generate adjacencies.
     * @return A list of locations adjacent to that given.
     */
    public List<Location> adjacentLocations(Location location)
    {
        assert location != null : "Null location passed to adjacentLocations";
        // The list of locations to be returned.
        List<Location> locations = new LinkedList<>();
        if(location != null) {
            int row = location.getRow();
            int col = location.getCol();
            for(int roffset = -1; roffset <= 1; roffset++) {
                int nextRow = row + roffset;
                if(nextRow >= 0 && nextRow < depth) {
                    for(int coffset = -1; coffset <= 1; coffset++) {
                        int nextCol = col + coffset;
                        // Exclude invalid locations and the original location.
                        if(nextCol >= 0 && nextCol < width && (roffset != 0 || coffset != 0)) {
                            locations.add(new Location(nextRow, nextCol));
                        }
                    }
                }
            }
            
            // Shuffle the list. Several other methods rely on the list
            // being in a random order.
            Collections.shuffle(locations, rando);
        }
        return locations;
    }

    /**
     * Return the depth of the field.
     * @return The depth of the field.
     */
    public int getDepth()
    {
        return depth;
    }
    
    /**
     * Return the width of the field.
     * @return The width of the field.
     */
    public int getWidth()
    {
        return width;
    }

    /**
     * Return the width of the field.
     * @return The Days in a season.
     */
    public int getDaysPerSeaoson(){

        return Config.getDaysPerSeaoson();
    }

        /**
     * Return the width of the field.
     * @return The Days in a season.
     */
    public double getSnowChance(){

        return Config.getSnowChance();
    }

        /**
     * Return the width of the field.
     * @return The Days in a season.
     */
    public int getGetMaxElevation(){

        return Config.getGetMaxEarthElevation();
    }

    public double getWaterChance(){
        return Config.getWaterChance();
    }

        /**
     * Return the width of the field.
     * @return The Days in a season.
     */
    public double getMaxCliffChance(){

        return Config.getMaxCliffChance();
    }
}
