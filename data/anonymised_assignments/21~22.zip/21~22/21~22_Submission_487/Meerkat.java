import java.util.ArrayList;

/**
 * Model of a meerkat
 * They can move, eat, reproduce, get infected, and die
 * they eat insects and mountain flowers
 * they all share one genetic value : 4
 *
 * @version 2022.03.01
 */
public class Meerkat extends Animal
{

    //An array of classes that the animal eats
    private static ArrayList<Class<?>> ANIMAL_EATS = new ArrayList<Class<?>>();
    static{
        ArrayList<Class<?>> tmp = new ArrayList<Class<?>>();
        tmp.add(Insect.class);
        tmp.add(MountainFlower.class);
        ANIMAL_EATS = tmp;
    }

    // The animals own genetic values
    // always contains one value specific to this particular animal
    private ArrayList<Integer> genetics = new ArrayList<>();

    /**
     * Creates a meerkat with random values
     * adds genetic code 4
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Meerkat(Field field, Location location)
    {
        super(field, location, Meerkat.class);
        genetics.add(4);
        super.populateGenetics();
    }

    /**
     * Creates a meerkat as offspring
     * second constructor needed as it takes
     * parents as parameters
     * adds genetic code 4
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    public Meerkat(Field field, Location location, Animal parent1, Animal parent2)
    {
        super(field, location, Meerkat.class, parent1, parent2);
        genetics.add(4);
        super.populateGenetics();
    }

    /**
     * Creates and returns meerkat as offspring
     * needed to create specific animals in Animal class
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    protected Animal newAnimal(Field field, Location loc, Animal parent1, Animal parent2)
    {
        return new Meerkat(field, loc, parent1, parent2);
    }

    /**
     * gets the arraylist of classes the meerkat eats
     * @return arraylist of type class
     */
    protected ArrayList<Class<?>> getEats()
    {
        return ANIMAL_EATS;
    }

    /**
     * adds inputted number into genetics list
     * @param number the value that is added
     */
    protected void addGenetics(int number)
    {
        genetics.add(number);
    }
    
    /**
     * gets the arraylist of genetics for this animal
     * each value in genetics is an integer
     */
    protected ArrayList<Integer> getGenetics()
    {
        return genetics;
    }
}
