//imports
import java.util.List;

/**
 * Model of a berry plant
 * berry plants can grow, be eaten, spread seeds and die
 *
 * @version 2022.03.01
 */
public class BerryPlant extends Plants {

    /**
     * this constructor is used for refrence and
     *  will not work for placing a plant
     */
    public BerryPlant()
    {
        // to just have plant data with no location specified
        super(null,null,BerryPlant.class);
    }

    /**
     * Creates a berry plant
     * @param location location of the berry plant
     * @param field field it will be in
     */
    public BerryPlant(Location location,Field field){
        super(field,location,BerryPlant.class);
    }

    /**
     * made for future use 
     * {plants grow in different ways, have other actions...}
     * @param newPlants the list of new plants to be added to the field
     */
    public  void grow(List<Plants> newPlants){

        //Do the growth all plants do
        commonGrowth(newPlants);
    }

    /**
     * sets the plant to dead when eaten
     * -> potential extra actions when eaten
     */
    public void Eaten(){
        setDead();
    }


    /**
     * creates a new berry plant
     * with the given locations and field
     */
    public Plants MakeNewPlant(Location location,Field field) {

        return new BerryPlant(location,field);

    }

    
}
