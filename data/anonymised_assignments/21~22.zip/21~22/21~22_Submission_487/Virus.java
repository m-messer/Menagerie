import java.util.ArrayList;
import java.util.Random;

/**
 * Model of a virus
 * viruses are randomly created, have a set of random genetics that
 * they cant infect, and have a random damageChance and spreadChance
 *
 * @version 2022.03.01
 */
public class Virus{

        // arraylist of numbers that the virus cannot infect (immune)
        private ArrayList<Integer> immuneGenetics = new ArrayList<Integer>();
        // double value of if the virus damages the animal
        private double damageChance;
        // double value of if the virus spreads to the surrounding animals
        private double spreadChance;

    /**
     * Creates a virus with 3 random genetic values
     * ramdom damage chance, and random spread chance
     */
    public Virus()
    {
        Random rand = new Random();
        int count = 0;
        while(count < 2)
        {
            int randomGenetic = rand.nextInt(26);
            immuneGenetics.add(randomGenetic);
            count++;
        }
        damageChance = rand.nextDouble();
        spreadChance = rand.nextDouble();
        
    }

    /**
     * checks spread chance
     * if random value < spread chance, return true
     * @return boolean if virus is spread
     */
    public boolean spreadVirus()
    {
        Random rand = new Random();
        double randomValue = rand.nextDouble();
        return (spreadChance > randomValue);
    }

    /**
     * checks damage chance
     * if viruses chance to damage > random value
     * return true
     * @return boolean if animal is damaged
     */
    public boolean damageAnimal()
    {
        Random rand = new Random();
        double randomValue = rand.nextDouble();
        return (damageChance > randomValue);
    }

    /**
     * checks if animal can be infected
     * takes in genetics of the animal, and compares values
     * if there is a match, animal is immune so return false
     * @param genetics the animals arraylist of integers
     * @return if the animal is not immune, return true
     */
    public boolean canInfect(ArrayList<Integer> genetics)
    {
        for(int i = 0; i == 2; i++)
        {
            if(genetics.contains(immuneGenetics.get(i)))
            {
                return false;
            }
        }
        return true;
    }

}