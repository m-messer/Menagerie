import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 * The animals can move, reproduce, eat, spread disease and each
 * have a set of characteristics, inherited from parent animals
 *
 * @version 2022.03.01
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //gender of the animal 1 = male, 2 = female
    private int gender;
    // resciliance of animal
    private int resilience;
    // class to get info from config
    Class<? extends Animal> AnimalType;

    // A shared random number generator to control breeding.
     private static final Random rand = Randomizer.getRandom();

    // The animal's age.
    private int age;
    // The animal's food level, which is increased by eating entities
    // which are in ANIMAL_EATs
    private int foodLevel;
    // The food level at which is no longer searched for
    private int Max_Food_level;
    // the list of viruses the animal has
    private ArrayList<Virus> animalInfections;
    // the animals integer value intelligence (0-100)
    private int intelligence;
    // the animals integer value strength (0-100)
    private int strength;
    // the animals integer value luck (0-100)
    private int luck;
    /**
     * Create a new animal at location in field.
     * animal's gender is set, class is known
     * intelligence, strength and luck are set as random
     * This constructor is for the initial creation of an animal
     *  so age and foodLevel are set randomly
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalClass Class type of the animal
     */
    public Animal(Field field, Location location, Class<? extends Animal> animalClass)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        setGender();
        resilience = 10;
        AnimalType = animalClass;
        Max_Food_level = Config.getHungerValue(AnimalType);

        age = rand.nextInt(getMaxAge());
        foodLevel = rand.nextInt(30);

        //currently empty arraylist of viruses
        animalInfections = new ArrayList<Virus>();

        // creates a random number from 1 - 100 and assigns to variable
        // does this for each characteristic
        Random rand = new Random();
        intelligence = rand.nextInt(101);
        strength = rand.nextInt(101);
        luck = rand.nextInt(101);
    }

    /**
     * This is to create a new animal, as offspring
     * This is a seperate constructor as it needs the parents to be
     * passed into the constructor to give the average characteristics
     * age and foodLevel are also set to initial values 
     * as the animal was just born
     * @param field The field currently occupied
     * @param location The location of the animal in the field
     * @param animalClass The class type of the current animal
     * @param parent1 one parent of the animal
     * @param parent2 second parent of the animal
     */
    public Animal(Field field, Location location, Class<? extends Animal> animalClass, Animal parent1, Animal parent2)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        setGender();
        resilience = 10;
        AnimalType = animalClass;
        Max_Food_level = Config.getHungerValue(AnimalType); //gets the static value from config

        // stats of the animal just born
        age = 0; 
        foodLevel = 30;

        animalInfections = new ArrayList<Virus>();

        // each characteristic is the average of the parents characteristics
        intelligence =Math.round(( parent1.getIntelligence() + parent2.getIntelligence() ) / 2);
        strength =Math.round(( parent1.getStrength() + parent2.getStrength() ) / 2);
        luck =Math.round(( parent1.getLuck() + parent2.getLuck() ) / 2);        
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Animal> newAnimals){
        incrementAge();
        incrementHunger();


        if(this.alive == true && isNotSleeping())
        {
            if(isAlive()) {
                giveBirth(newAnimals);
                // weather effect
                if(field.getTerrainAt(location).getSnow()){
                    resilience -= 3;
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    virusAct();
                    setLocation(newLocation);
                    resilience += gainResiliance();
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        // dies if resilience value is too low
        if (resilience<=0){
            setDead();
        }
    }

    /**
     * Gives birth to new animals of the same kind
     * if there is an animal of the same type, opposite gender
     * the animals are of breeding age, and probability is success 
     * @param newAnimals all the new animals added to the field
     */
    protected void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // the type of animal
        Class<? extends Animal> animalType = this.getClass();
        while(it.hasNext()) {
            Location where = it.next();
            Animal animal = field.getAnimalAt(where);

            //if there exists an animal, and if it is of the same type

            if(animal != null && animal.getClass().equals(animalType))
            {
                //object needs to be cast to animal
                Animal adjacentAnimal = (Animal) animal;
                //if can breed, and genders are opposite
                if(adjacentAnimal.canBreed() && (getGender() + adjacentAnimal.getGender()) == 3)
                {
                    //adds new animal if there is space
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Animal young = newAnimal(field, loc, this, adjacentAnimal);
                        newAnimals.add(young);
                    }
                }
            }
        }
    }

    /**
     * Look for edible entities adjacent to the current location.
     * Only the first edible entity is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        // not hungry
        if(foodLevel >= Max_Food_level){
            return null;
        }
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Animal entity = field.getAnimalAt(where);
            if(entity != null && canEat(entity)) { //need to check if its an animal

                Animal animal = (Animal)entity;
                if(animal.isAlive()) {
                    animal.setDead();
                    //adds food to the animals food count
                    addFoodLevel(animal.getFoodValue() + foodFromStrength());
                    return where;
                }
            }
            Plants plant = field.getPlantAt(where);
            // if there is not an animal on the area next to it
            // and there is a plant that it can eat -> move and eat
            if(entity == null && plant != null && canEat(plant))
            {
                if(plant.canEat())
                {
                    setFoodLevel(plant.getFoodValue());
                    plant.Eaten();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * sets the animals food level
     * @param foodValue the integer value of animals food level
     */
    protected  void setFoodLevel(int foodValue){
        foodLevel = foodValue;
    }

    /**
     * adds to the animmals food level
     * @param foodValue integer value added to food level
     */
    private void addFoodLevel(int foodValue){
        foodLevel += foodValue;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clearAnimal(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clearAnimal(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }


    /**
     * sets the gender of the animal randomly
     * between 1 and 2
     */
    private void setGender()
    {
        Random rand = new Random();
        gender = rand.nextInt(2) + 1;
    }

    /**
     * spreads the virus the current animal has
     * if they are not excempt, if spread is successful 
     * and if the animal does not have the virus
     * The virus also damages the animal
     */
    private void virusAct()
    {
        // no need to perform anything if animal is not infected at all
        if( !animalInfections.isEmpty() )
        {
            //gets the locations around the animal
            Field field = getField();
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext())
            {
                Location where = it.next();
                Animal entity = field.getAnimalAt(where);
                if(entity != null)
                {
                    // for each virus the animal has
                    for(Virus virus : animalInfections)
                    {
                        Animal animal = (Animal)entity;
                        // gets the list of viruses for target animal
                        ArrayList<Virus> animalVirus = animal.getAnimalInfections();
                        // if the target animal is not already infected with particular virus
                        // animal is not immune and virus is successfully spread, then virus is added to target
                        if(!animalVirus.contains(virus) && virus.canInfect(animal.getGenetics()) && virus.spreadVirus())
                        {
                            animal.addVirus(virus);
                        }
                    }
                }
            }
            // animal is potentially damaged for each virus it has
            for(Virus virus : animalInfections)
            {
                if(virus.damageAnimal())
                {
                    resilience--;
                }
            }
        }        
    }

    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Increments hunger of the animal
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }


    /**
     * Checks whether the entered object is edible by the current animal
     * @param food that is being checked if its edible
     * @return true if it can be eaten
     */
    protected boolean canEat(Object food)
    {
        ArrayList<Class<?>> edibles = this.getEats();
        Class<?> foodType = food.getClass();
        if(edibles.contains(foodType))
        {
            return true;
        }
        return false;
    }

    /**
     * check if the current animal is not sleeping
     * @return boolean true if is awake, false otherwise
     */
    private boolean isNotSleeping()
    {
        int time = field.getTerrainAt(location).getTime();
        return getSleepTime() != time;
    }

    /**
     * Extra food gained when eating if current animal is stronger
     * @return integer extra gained food
     */
    private int foodFromStrength()
    {
        return Math.round(strength / 20);
    }

    /**
     * if the animal is smarter, it can survive better through
     * the cold and viruses
     * chance to gain resiliance
     * @return 1 or 0 depending on if it is successful
     */
    private int gainResiliance()
    {
        double intelligenceDecimal = intelligence / 100;
        Random rand = new Random();
        double randomChance = rand.nextDouble();
        if(intelligenceDecimal > randomChance)
        {
            return 1;
        }
        return 0;
    }

    /**
     * higher chance of successfully mating if luck is higher
     * @return decimal value of gained breeding chance
     */
    private double breedLuck()
    {
        return (luck / 400);
    }

     /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= (getBreedingProability() + breedLuck()) ) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * if the animal is old enough to breed
     * @return boolean true if it can breed
     */
    public boolean canBreed()
    {
        return age >= getBreedingAge();
    }

    /**
     * creates a new animal of particular type with given details
     * @param field field it is in
     * @param loc location of new animal
     * @param parent1 parent of the animal
     * @param parent2 second parent of the animal
     * @return animal created
     */
    abstract protected Animal newAnimal(Field field,Location loc, Animal parent1, Animal parent2);


    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Returns the animal's gender
     * @return gender as int, 1 -> male ; 2 -> female
     */
    protected int getGender()
    {
        return gender;
    }


    /**
     * Gets the food value gained from eating the animal
     * @return integer value gained from eating
     */
    protected int getFoodValue()
    {
        return Config.getAnimalFoodValue(AnimalType);
    }

    protected int getAge(){

        return age;
    }

    /**
    * Gets the animals minimum brightness needed to be awake
    * @return integer minimum of brightness to be awake
    */
    protected int getSleepTime()
    {
        return Config.getSleepTime(AnimalType);
    }

    /**
     * gets max age
     * @return integer max age
     */
    protected int getMaxAge(){

        return Config.getMaxAge(AnimalType);
    }

    /**
     * gets maximum amount of offspring
     */
    protected int getMaxLitterSize(){

        return Config.getMaxLitterSize(AnimalType);
    }

    /**
     * gets the probability of the animal breeding
     */
    protected double getBreedingProability(){

        return Config.getBreedingProability(AnimalType);
    }

    /**
     * gets the age the animal can start breeding
     */
    protected double getBreedingAge(){

        return Config.getBreedingAge(AnimalType);
    }

    /**
     * gets the list of viruses the animal has
     */
    public ArrayList<Virus> getAnimalInfections()
    {
        return animalInfections;
    }

    /**
     * gets the strength integer value for animal
     */
    public int getStrength()
    {
        return strength;
    }

    /**
     * gets the luck integer value for animal
     */
    public int getLuck()
    {
        return luck;
    }

    /**
     * gets the intelligence integer value for animal
     */
    public int getIntelligence()
    {
        return intelligence;
    }

    public int getRecsiliance(){

        return resilience;
    }

    public int getHunger(){

        return foodLevel;
    }

    /**
     * adds 4 random integers between 6-25 to genetics list
     */

    protected void populateGenetics()
    {
        Random rand = new Random();
        int count = 0;
        while (count < 4)
        {
            int int_random = rand.nextInt(20) + 6;
            addGenetics(int_random);
            count++;
        }
    }

    /**
     * adds inputted virus to animals viruslist
     * @param virus virus that is added to list
     */
    public void addVirus(Virus virus)
    {
        animalInfections.add(virus);
    }

    /**
     * Add value to genetics arraylist in animal
     * @param number integer that is added to lsit
     */
    abstract protected void addGenetics(int number);

     /**
     * Gets the classes of the types the current animal can eat
     * @return ArrayList of what the animal can eat
     */
    abstract protected ArrayList<Class<?>> getEats();

    /**
     * gets the arraylist of values for the genetics
     * @return arraylist of genetic values.
     */
    abstract protected ArrayList<Integer> getGenetics();
}
