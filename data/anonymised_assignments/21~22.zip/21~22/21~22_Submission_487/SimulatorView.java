import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2016.02.29
 */
public class SimulatorView extends JPanel
{

    // Exit the application and free memory

    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;



    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String SEASON_PREFIX = "Season: ";
    private final String TIME_PREFIX = "Time: ";
    private JLabel stepLabel, population, infoLabel, Season, Time, SeasonLable, TimeLable;
    private FieldView fieldView;
    JFrame main;
    TrackerPane specificInfo;
    
    // A statistics Animal computing and storing simulation information
    private FieldStats stats;


    // what feilds to be shown
    private boolean AnimalField = true;
    private boolean TerrainField = true;
    private boolean PlantField = true;




    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {

        //As a jpanel we change the layut type
        super(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints(); 

        stats = new FieldStats();

        
        //setTitle("Fox and Rabbit Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        Season= new JLabel(SEASON_PREFIX, JLabel.CENTER);
        Time = new JLabel(TIME_PREFIX, JLabel.CENTER);
        specificInfo = new TrackerPane(width,height);

         //testing


        
        setLocation(100, 50);
        
        fieldView = new FieldView(height, width);


        JPanel infoPane = new JPanel(new GridLayout(0,1));
            infoPane.add(stepLabel);
            infoPane.add(infoLabel);
            infoPane.add(Time);
            infoPane.add(Season);
            infoPane.setBackground(Color.PINK); 

        JPanel PopulationPane = new JPanel();
            PopulationPane.add(population);
            PopulationPane.setBackground(Color.PINK);


        JPanel infoPane2 = new JPanel();
            infoPane2.add(PopulationPane);
            infoPane2.add(specificInfo);
            infoPane2.setBackground(Color.PINK);   
        


        
        //infopane
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
       // c.weightx = 1.0;
       // c.weighty = 1.0;
        //c.gridheight = 2;
        add(infoPane, c);

        //fieldview
        c.gridx = 0;
        c.gridy = 2;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
       // c.gridheight = 0;
        add(fieldView, c);

         //population pane
         c.gridx = 0;
         c.gridy = 10;
         c.fill = GridBagConstraints.BOTH;
         c.weightx = 0;
        c.weighty = 0;
        // c.gridheight = 4;
        add(infoPane2,c);


    }
    




    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }


    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }
            
        stepLabel.setText(STEP_PREFIX + step);

        // each day is 4 steps

        int offset = step%4;
        switch (offset){
            case 0:
                Time.setText(TIME_PREFIX + "00:00");
                break;
            case 1:
                Time.setText(TIME_PREFIX + "6:00");
                break;
            case 2:
                Time.setText(TIME_PREFIX + "12:00");
                break;
            case 3:
                Time.setText(TIME_PREFIX + "18:00 (Nightfall)");
                break;
            default:
                Time.setText(TIME_PREFIX + "unknown");

        }

        // for seasons currently 1 day a season
        switch (Terrain.getSeason()){
            case 0:
                Season.setText(SEASON_PREFIX + "Spring");
                break;
            case 1:
                Season.setText(SEASON_PREFIX + "Summer");
                break;
            case 2:
                Season.setText(SEASON_PREFIX + "Winter");
                break;
            case 3:
                Season.setText(SEASON_PREFIX + "odd");
                break;
            default:
                Season.setText(SEASON_PREFIX + "Unknown");
        }


        stats.reset();
        
        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Animal animal = field.getAnimalAt(row, col);
                Plants plant = field.getPlantAt(row, col);

                // get the count
                if(animal != null ) {
                    stats.incrementCount(animal.getClass());

                }
                if(plant != null){
                    stats.incrementCount(plant.getClass());
                }

                //show the data

                if(animal != null && AnimalField){
                    fieldView.drawMark(col, row, Config.getColor(animal.getClass()));
                }
                else if(plant != null && PlantField){
                    Color color = Config.getColor(plant.getClass());
                    if(!plant.canEat()){

                        color = color.darker();
                    }
                    fieldView.drawMark(col, row, color);

                }
                else if(TerrainField) {
                    Terrain EarthData = field.getTerrainAt(row,col);
                    fieldView.drawMark(col, row, CalculateColour(EarthData) );
                    

                }
                else{

                    fieldView.drawMark(col, row,EMPTY_COLOR );

                }
            }
        }
        stats.countFinished();

        population.setText("<html>"+ POPULATION_PREFIX + "<br/>" + stats.getPopulationDetails(field) + "</html>" );
        specificInfo.Update(field);
        fieldView.repaint();
        //ctrl.delay(40);
    }

    private void drawMark(int col, int row, Color green) {
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        // for showing stats of eac individual sqr on the map
        private MouseListener mouseHandler;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                                 gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            Dimension temp = new Dimension(this.getSize());
            if(! size.equals(temp)) {
                  // if the size has changed...
                size = temp;
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();
                
                //get the Scale
                Scale();
            }
        }

        /**
         * 
         * Get the scale values compared from the resizing and the paint
         */
        public void Scale(){


            xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = (GRID_VIEW_SCALING_FACTOR);
                }
                yScale = (size.height / gridHeight);
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }


        // These methods are to override what the mose does
        @Override
        public void addNotify(){
            super.addNotify();

            if(mouseHandler != null){
                removeMouseListener(mouseHandler);
            }

            mouseHandler = new MouseAdapter(){

                @Override
                public void mousePressed(MouseEvent e){


                    int sqrX = e.getX()/xScale;
                    int sqrY = e.getY()/yScale;
                    specificInfo.getCords(sqrX,sqrY);

                }

                @Override
                public void mouseReleased(MouseEvent e){


                }

                @Override
                public void mouseEntered(MouseEvent e){
                    
                }
                @Override
                public void mouseExited(MouseEvent e) {}

            };
            addMouseListener(mouseHandler);
        }


        @Override
        public void removeNotify() {
            super.removeNotify();
            if (mouseHandler != null) {
                removeMouseListener(mouseHandler);
            }
        }


    }



    // toggle stuff on and off
    public void ToggleField(int Tochange,int step,Field field){
        switch(Tochange){

            case 1: 
                if(AnimalField){AnimalField = false;}
                else{AnimalField = true;}
                break;
            case 2: 
                if(TerrainField){TerrainField = false;}
                else{TerrainField = true;}
                break;
            case 3: 
                if(PlantField){PlantField = false;}
                else{PlantField = true;}
                break;
            default:
                System.out.println("toggle input wrong");

        }

        showStatus(step, field);
    }



    /**  
     * calculates the colour of terrain depending on elevation and light level
     * @param Terrain
     * */
    private Color CalculateColour(Terrain data){

        
        int[] Colorset = {222,192,11};
        if(data.getSnow()){
            return Color.WHITE;
        }


        switch (data.getElevation()) {


                case 1:  
                    Colorset[0]=181;
                    Colorset[1]=146;
                    Colorset[2]=4;
                    break;
                case 2:
                    Colorset[0]=222;
                    Colorset[1]=192;
                    Colorset[2]=11;
                break;
                case 3:
                    Colorset[0]=232;
                    Colorset[1]=239;
                    Colorset[2]=35;
                    break;
                default: 
                    break;
        }
            // add light to color

        for(int i=0;i< data.getLight(); i++){

            Colorset[0] *= 0.75;
            Colorset[1] *=0.75;
            Colorset[2] *=0.75;

        }
        

        Color test = new Color(Colorset[0],Colorset[1],Colorset[2]);

        return test;
    }


    /**
     * This pane is for tracking specif animals
     */
    private class TrackerPane extends JPanel{

        //JLabels
        private JLabel Cords , Type, age , virus, intelligence, luck, resciliance, hunger, foodlevel
        ,Status;

        //srings for Jlabels
        private String[] prefixString = {"Tracking X,Y: ", " ", "Age: ","Virus: ", "intelligence: ","Luck: ",
        "resilience:", "Hunger: ", "EatenValue: ", "Status:" };

        int gridx;
        int gridy;
        Field field;


        // jlabel formatting
        private Animal tracking;
        public TrackerPane(int x, int y){
            gridx = x;
            gridy = y;
            tracking = null;
            setBackground(Color.WHITE);
            setLayout(new GridLayout(0,2));

            Cords  = new JLabel(prefixString[0]);
            add(Cords);

   
            Type  = new JLabel(prefixString[1]);
            add( Type);

            age  = new JLabel(prefixString[2]);
            add(age);

            virus   = new JLabel(prefixString[3]);
            add( virus);

   
            intelligence   = new JLabel(prefixString[4]);
            add(intelligence);

      
            luck   = new JLabel(prefixString[5]);
            add( luck);

    
            resciliance   = new JLabel(prefixString[6]);
            add(resciliance);

  
            hunger   = new JLabel(prefixString[7]);
            add(hunger);

  
            foodlevel   = new JLabel(prefixString[8]);
            add(foodlevel);

          
            Status  = new JLabel(prefixString[9]);
            add( Status);


        }

        /** 
         * this functions checks if there is an animal to track
         * @param intx,y for cords
        */
        public void getCords(int x,int y){
            if(x>=gridx || y>=gridy){
                return;
            }

            if(field.getAnimalAt(x,y) != null){
                tracking = field.getAnimalAt(y,x);
                setBackground(Color.RED);
                Update(field);
            }
        }

        /**
         * Tracks the selected animal till death
         * @param field_m
         */
        public void Update(Field field_m){
            field = field_m;

            // if no animal to track do nothing
            if(tracking == null){
                return;
            }
            // if animal dead set to dead and do nothing
            if(!tracking.isAlive()){
                Status.setText(prefixString[9] = "Dead");
                return;
            }
            // else update all labels

            Location temp = tracking.getLocation();

            Cords.setText(prefixString[0] +temp.getRow()+"," + temp.getCol());
        
            Type.setText(prefixString[1] + tracking.getClass());

            age.setText(prefixString[2] + tracking.getAge());

            virus.setText(prefixString[3] + tracking.getAnimalInfections());

   
            intelligence.setText(prefixString[4] + tracking.getIntelligence());

      
            luck.setText(prefixString[5] + tracking.getLuck());

            resciliance.setText(prefixString[6]+ tracking.getRecsiliance());

  
            hunger.setText(prefixString[7] + tracking.getHunger());

  
            foodlevel.setText(prefixString[8]+ tracking.getFoodValue());

          
            Status.setText(prefixString[9] = "Alive");
           
        }

    }

}



