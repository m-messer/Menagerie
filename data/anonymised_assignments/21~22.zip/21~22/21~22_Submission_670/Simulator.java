import java.util.prefs.Preferences;

import java.util.Random;

import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing boars, wolves, owls, deers, bushes and grass.
 *
 * @version 1
 */
public class Simulator
{
    //the Preferences object, where we store various variables, such as 
    //the creation probabilities of organisms and the number of steps.
    private Preferences prefs;
    private boolean prefsExisted;       //whether the Preferences object exists or not

    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // The default length of a day.
    public static final int DAY_LENGTH = 50;

    // The probability that a wolf will be created in any given grid position.
    private double WOLF_CREATION_PROBABILITY = 0.145724;

    // The probability that an owl will be created in any given grid position.
    private double OWL_CREATION_PROBABILITY = 0.050706;

    // The probability that a boar will be created in any given grid position.
    private double BOAR_CREATION_PROBABILITY = 0.317745;
    
    // The probability that a deer will be created in any given grid position.
    private double DEER_CREATION_PROBABILITY = 0.4040;

    // The probability that a bush plant will be created in any given grid position.
    private double BUSH_CREATION_PROBABILITY = 0.493261;
    
    // The probability that a grass plant will be created in any given grid position.
    private double GRASS_CREATION_PROBABILITY = 0.0344;

    
    private List<Organism> organisms;

    //these provide us the information for each species of organisms
    private ArrayList<OrganismInformation> templateOrganisms;

    //these provide us the information for each species of pathogens
    private HashSet<PathogenInformation> templatePathogens;


    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    // whether the simulator is used for searching stable environments
    //if this is true, then the window of the simulation will not be shown
    private boolean isSearching = false;
    

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        bootSimulation(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Construct a simulation field with default size, and not showing the window.
     * 
     * @param isSearching if this parameter is present then the window showing the simulation
     * will not be shown
     */
    public Simulator(boolean isSearching){
        this.isSearching = true;
        bootSimulation(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        bootSimulation(depth, width);
    }

    /**
     * Boots up the simulation field with a given width and depth.
     * 
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    private void bootSimulation(int depth, int width){
        Randomizer.reset();
        setupPreferences();             //sets up the Preferences object

        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        organisms = new ArrayList<>();

        //sets up both templates
        setTemplateOrganisms();
        setTemplatePathogens();

        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, !isSearching);

        //assigns colors
        for (OrganismInformation org : templateOrganisms) {
            view.setColor( org.getOrganismType() , org.getColor());
        }

        // Setup a valid starting point.
        reset();
    }

    /**
     * Sets up the prefs and prefsExisted field,
     * by checking if preferences exist or not on the machine.
     */
    private void setupPreferences(){

        //the directory of this program
        String programDir = System.getProperty("user.dir");

        try{
            prefsExisted = Preferences.userRoot().nodeExists(programDir);
        }catch(Exception e){
            prefsExisted = false;
        }

        prefs = Preferences.userRoot().node(programDir);

    }

    /**
     * Sets up all the organism's templates.
     */
    private void setTemplateOrganisms(){
        templateOrganisms = new ArrayList<>();

        templateOrganisms.add( 
            new OrganismInformation(Wolf.class, Color.RED, 
                    WOLF_CREATION_PROBABILITY, new Wolf(null, null))
        );

        templateOrganisms.add( 
            new OrganismInformation(Owl.class, Color.decode("#5f1c0c"), 
                    OWL_CREATION_PROBABILITY, new Owl(null, null))
        );

        templateOrganisms.add( 
            new OrganismInformation(Boar.class, Color.BLUE, 
                    BOAR_CREATION_PROBABILITY, new Boar(null, null))
        );

        templateOrganisms.add( 
            new OrganismInformation(Deer.class, Color.decode("#d1e44e"), 
                    DEER_CREATION_PROBABILITY, new Deer(null, null))
        );

        templateOrganisms.add( 
            new OrganismInformation(Bush.class, Color.GREEN, 
                    BUSH_CREATION_PROBABILITY, new Bush(null, null, 0))
        );

        templateOrganisms.add( 
            new OrganismInformation(Grass.class, Color.decode("#107a12"), 
                    GRASS_CREATION_PROBABILITY, new Grass(null, null, 0))
        );
    }

    /**
     * Sets up the templates for all pathogens.
     */
    private void setTemplatePathogens(){
        templatePathogens = new HashSet<>();

        templatePathogens.add( new PathogenInformation( new Salmonella(), 0.001 ) );
    }

    /**
     * Loads up the creation data from the Preferences field.
     * If the data for a particular creation probability didn't exist,
     * we write it onto the registry, and use the default values inside this class. 
     */
    private void loadDataFromPreferences(){

        for (OrganismInformation org : templateOrganisms)
        {
            double organismCreationProbability = org.getOrganismCreationProbability();
            org.setOrganismCreationProbabilty( prefs.getDouble( org.getOrganismName(), organismCreationProbability ) );

            if (!prefsExisted){
                prefs.putDouble( org.getOrganismName() , organismCreationProbability);
            }
        }
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * 
     * Resets the simulation if the reset button has been pressed, and pauses
     * the simulation until the pause button is pressed again.
     * 
     * While paused the simulation can show the information about a particular organism
     * if one clicks with the mouse on the field's grid.
     * 
     * @param numSteps The number of steps to run for.
     * @return the total number of steps until the simulation finished. 
     */
    public int simulate(int numSteps)
    {
        int step;

        for(step = 1; step <= numSteps && view.isViable(field); step++) {
            prefs.putInt("steps", step);

            simulateOneStep();

            //reset every aspect of the simulation
            if (view.getIsReset()){
                view.toggleIsReset();
                this.reset();

                step = 1;
                view.resetPopulationCounts();
            }
            
            //while paused check if it unpaused
            while (view.getIsPaused()){
                if (view.mouseClicked()) view.showOrganismInformation(field);
                delay(10);
            }

            //delay(60);   // uncomment this to run more slowly
        }

        //show a population graph at the end of the simulation
        if (!isSearching) view.showPopulationGraph();

        return step;
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * organism.
     * At each step an organism may be randomly infected.
     */
    public void simulateOneStep()
    {
        step++;

        List<Organism> newOrganisms = new ArrayList<>();
        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {

            Organism organism = it.next();

            introduceInfections(organism);
            organism.act(newOrganisms);
            
            if(! organism.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals and plants to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        //load the creation probabilities
        loadDataFromPreferences();        

        step = 0;
        clearAllOrganisms();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with organisms.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                for (OrganismInformation org : templateOrganisms){
                    
                    if (rand.nextDouble() <= org.getOrganismCreationProbability()) {
                        Organism newOrganism = null;

                        Location location = new Location(row, col);
                        Organism nullOrganism = org.getNullOrganism();

                        if (nullOrganism instanceof Animal)
                        {
                            Animal animalNullOrganism = (Animal) nullOrganism;
                            newOrganism = animalNullOrganism.createOffspring( field, location, null, null );
                        
                        }else if (nullOrganism instanceof Plant)
                        {
                            Plant plantNullOrganism = (Plant) nullOrganism;
                            newOrganism = plantNullOrganism.createOffspring( field, location, 0 );
                        }

                        if (newOrganism != null){

                            organisms.add(newOrganism);
                        }
                    }
                }
            }
        }
    }

    /**
     * Introduce an infection to an organism from nowhere
     * @param organism the organism we want to infect
     */
    private void introduceInfections(Organism organism){
        Random rand = Randomizer.getRandom();

        for (PathogenInformation pathogenInfo : templatePathogens){
            double apparitionProbability = pathogenInfo.getApparitionProbability();

            if (rand.nextDouble() <= apparitionProbability){
                organism.infectOrganism( pathogenInfo.getPathogen(), organism);
                return;
            }
        }
    }

    /**
     * Clears the list of all the different types of organisms
     */
    private void clearAllOrganisms()
    {
        organisms.clear();
    }

    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Returns the template organisms
     * @return the template organisms
     */
    public ArrayList<OrganismInformation> getOrganismInformations(){
        return this.templateOrganisms;
    }
}
