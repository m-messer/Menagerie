import java.util.HashMap;
import java.util.List;

/**
 * A simple model of a boar.
 * Boars age, move, breed, and die.
 * Boars may also run away from predators.
 *
 * @version 1
 */
public class Boar extends Animal
{
    // Characteristics shared by all boars (class variables).

    // The age at which a boar can start to breed.
    private static final int BREEDING_AGE = 8;

    // The age to which a boar can live.
    private static final int MAX_AGE = 80;

    // The likelihood of a boar breeding.
    private static final double BREEDING_PROBABILITY = 0.7;

    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    //the maximum food the boar can eat.
    private static final int MAX_FOOD_VALUE = 12;
    
    // The food value of a single plant. 
    private static final int PLANT_FOOD_VALUE = 4;

    private static final int SLEEP_CYCLE = Simulator.DAY_LENGTH/2;


    /**
     * Create a new boar, with a random age and pair of genes.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Boar(Field field, Location location)
    {
        super(field, location, null, null);
    }

    /**
     * Create a newly born Boar, assign its genes in function of his parent's genes.
     * 
     * @param field the field currently occupied.
     * @param location the location within the field
     * @param maleGenes the genes of the male parent
     * @param femaleGenes the genes of the female parent
     */
    public Boar(Field field, Location location, byte[] maleGenes, byte[] femaleGenes)
    {
        super(field, location, maleGenes, femaleGenes);
    }

    /**
     * Implementation to return the boar's base characteristics
     */
    protected double[] getCharacteristics() {
        return new double[] {BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_VALUE, SLEEP_CYCLE};
    }

    /**
     * returns the Boar's class type
     */
    protected Class<?> getAnimalType(){
        return Boar.class;
    }

    /**
     * returns the Boar's diet, which consists of all plants.
     */
    protected HashMap<Class<?>, Integer> getFoodInformation(){
        HashMap<Class<?>, Integer> foodInformation = new HashMap<Class<?>, Integer>();
        
        foodInformation.put(Plant.class, PLANT_FOOD_VALUE);

        return foodInformation;
    }

    /**
     * Creates a new Boar offspring
     * @return new Boar object is created with given parameters and then returned.
     */
    public Animal createOffspring(Field field, Location loc, byte[] maleGenes, byte[] femaleGenes){
        return new Boar(field, loc, maleGenes, femaleGenes);
    }

    /**
     * Does the actions specific to boars.
     */
    protected void doSpecialisedActions(List<Organism> newAnimals){
        if (!isAlive()) return;
        
        //get a singular, random active gene to decide on the boar's actions.
        int bitIndex = this.getRandomActionGeneBitIndex();

        //Here we implement the different actions determined by the boar's genes
        //each case represents a gene, so it can go up to case 7.
        switch(bitIndex){
            case 0:
            case 1:
            case 2:
            case 3:
                runAway();
                break;
        }
    }

    /**
     *  The boar can run away from predators. (animals that have the boar inside their diets)
     */
    private void runAway(){

        Object nearbyPredatorObj = field.getNearbyPredator(location, Boar.class);
        
        if (nearbyPredatorObj == null || !( nearbyPredatorObj instanceof Animal )) return;

        Animal nearbyPredator = (Animal) nearbyPredatorObj;

        int[] direction = location.getDirection( nearbyPredator.getLocation() ); 

        //move into opposite direction of predator
        Location newLocation = new Location( location.getRow() - direction[0], location.getCol() - direction[1] );
        
        if ( field.isLocationFree( newLocation ) ){
            setLocation(newLocation);
        }
    }
}