/**
 * 
 * A simple model for a bush.
 * All that a bush does is grow and be eaten by animals.
 *
 * @version 1
 */
public class Bush extends Plant{

    //the probability that a bush creates a new leaf
    private final double REPRODUCTION_PROBABILITY = 0.12;

    //the probability that the bush is digested
    private final double DIGESTION_PROBABILITY = 0.7;

    //how many leaves the bush can make at one time
    private final int MAX_LEAF_SIZE = 4;

    //how much the bush can extend from the bush of depth 0
    private final int MAX_PLANT_EXTENSION = 4;

    //how far away, a leaf can be birthed to.
    //mimicking a branch of a plant.
    private final int MAX_BRANCH_EXTENSION = 2;

    //how fast the plant grows, effectively how many steps it takes for a plant to grow.
    private final int GROWTH_RATE = 4;

    /**
     * Create a Bush object, providing the current field,
     * the location of the bush and the "depth" : aka how far away it is from a bush of
     * depth 0. 
     * One can see a bush of depth 0 as the "main" bush, and the rest
     * are the bush's leaves extending outwards.
     * 
     * @param field the current field of the simulation
     * @param location the location of the new bush
     * @param depth how far away this bush is from the bush of depth 0.
     * 
     */
    public Bush(Field field, Location location, int depth)
    {
        super(field, location, depth);
    }

    /**
     * Returns the Bush class type
     * @return the Bush class type
     */
    protected Class<?> getPlantType(){
        return Bush.class;
    }

    /**
     * Returns the Bush's defining attributes 
     * @return the Bush's defining attributes
     */
    protected double[] getPlantAttributes(){
        return new double[] {REPRODUCTION_PROBABILITY, DIGESTION_PROBABILITY, 
                             MAX_LEAF_SIZE, MAX_PLANT_EXTENSION, MAX_BRANCH_EXTENSION, GROWTH_RATE};
    }

    /**
     * Create a new bush, providing the current field,
     * new location and depth.
     * 
     * @param field the current field of the simulation
     * @param location the location of the new bush
     * @param depth the depth of the new bush
     */
    public Organism createOffspring(Field field, Location location, int depth)
    {
        return new Bush(field, location, depth);
    }
}