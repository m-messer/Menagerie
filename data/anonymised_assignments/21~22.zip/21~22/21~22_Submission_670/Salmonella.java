import java.util.HashMap;

/**
 * 
 * Class modelling the Salmonella pathogen.
 * It affects hunger and can be transmitted sexually.
 *
 * @version 1.0
 */
public class Salmonella extends Pathogen {
    // the probability of attacking the host's qualities (e.g age, hunger...)
    private HashMap<Class<?>, Double> hostAttackRates;
    
    // the infection rate of the pathogen
    private final double INFECTION_RATE = 0.5;

    // the probability of a host recovering from the pathogen
    private final double RECOVERY_RATE = 0.4;

    /**
     * Constructor that creates a Salmonella obejct
     */
    public Salmonella(){
        super();
        hostAttackRates = new HashMap<>();

        hostAttackRates.put(Wolf.class, 0.7);
        hostAttackRates.put(Boar.class, 0.5);

    }

    /**
     * Returns how much Salmonella affects hugner
     * @return how much Salmonella affects hugner
     */
    protected int affectsHungerModifier(){
        return 4;
    }

    /**
     * Salmonella is sexually transitive, therefore returns true
     * @return true
     */
    protected boolean isSexuallyTransitive(){
        return true;
    }

    /**
     * Returns whether Salmonella transmits to another organism
     * @return whether Salmonella transmits to another organism
     */
    public boolean doesTransmit(){
        return rand.nextDouble() <= INFECTION_RATE;
    }

    /**
     * Returns how probable it is for Salmonella to modify the host's qualities.
     * @return how probable it is for Salmonella to modify the host's qualities.
     */
    protected double getHostAttackRate(Class<?> hostType){
        Double infectRate = hostAttackRates.get(hostType);

        if (infectRate == null) return 0;
        return hostAttackRates.get(hostType);
    }

    /**
     * Returns whether an organism recovers from Salmonella
     * @return whether an organism recovers from Salmonella
     */
    public boolean doesRecover(){
        return rand.nextDouble() <= RECOVERY_RATE;
    }

    /**
     * Returns whether Salmonella can infect the given organism's class type
     * @return whether Salmonella can infect the given organism's class type
     */
    public boolean canInfect(Class<?> hostType){
        return hostAttackRates.containsKey(hostType);
    }

    /**
     * Return a new Salmonella object
     */
    public Pathogen newPathogen(){
        return new Salmonella();
    }
}
