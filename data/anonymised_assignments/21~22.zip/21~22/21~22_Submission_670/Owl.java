import java.util.HashMap;
import java.util.List;

/**
 * A simple model of an Owl.
 * Owls age, move, breed, and die.
 * They can also fly if hungry enough, in search of new food.
 *
 * @version 1.0
 */
public class Owl extends Animal
{
    // Characteristics shared by all owls (class variables).
    
    // The age at which a owls can start to breed.
    private static final int BREEDING_AGE = 14;

    // The age to which a owls can live.
    private static final int MAX_AGE = 125;

    // The likelihood of a owls breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;

    //the maximum food the owls can eat.
    private static final int MAX_FOOD_VALUE = 12;

    // The food value of a single boar. 
    private static final int BOAR_FOOD_VALUE = 8;

    // The food value of a single bush.
    private static final int BUSH_FOOD_VALUE = 6;

    // The time at which the owls go to sleep (they are nocturnal)
    private static final int SLEEP_CYCLE = 0;

    /**
     * Create a new owls, with a random age and pair of genes.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Owl(Field field, Location location)
    {
        super(field, location, null, null);
    }

    /**
     * Create a newly born Owl, assign its genes in function of his parent's genes.
     * 
     * @param field the field currently occupied.
     * @param location the location within the field
     * @param maleGenes the genes of the male parent
     * @param femaleGenes the genes of the female parent
     */
    public Owl(Field field, Location location, byte[] maleGenes, byte[] femaleGenes){
        super(field, location, maleGenes, femaleGenes);
    }

    /**
     * Implementation to return the owl's base characteristics
     */
    protected double[] getCharacteristics() {
        return new double[] {BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_VALUE, SLEEP_CYCLE};
    }

    /**
     * returns the owl's class type
     */
    protected Class<?> getAnimalType(){
        return Owl.class;
    }

    /**
     * returns the Owl's diet, which consists of boars and bushes
     */
    protected HashMap<Class<?>, Integer> getFoodInformation(){
        HashMap<Class<?>, Integer> foodInformation = new HashMap<Class<?>, Integer>();

        foodInformation.put(Boar.class, BOAR_FOOD_VALUE);
        foodInformation.put(Bush.class, BUSH_FOOD_VALUE);

        return foodInformation;
    }
    
    /**
     * Creates a new Owl offspring
     */
    public Animal createOffspring(Field field, Location loc, byte[] maleGenes, byte[] femaleGenes){
        return new Owl(field, loc, maleGenes, femaleGenes);
    }

    /**
     * It moves the owl to a new random location if hungry enough.
     */
    private void fly(){
        if ( this.getFoodLevel() >= 4) return;
        
        Location newLocation = field.getRandomEmptyLocation();

        if (newLocation != null) this.setLocation(newLocation);
    }

    /**
     * Does the actions specific to owls.
     */
    protected void doSpecialisedActions(List<Organism> newAnimals){
        if (!isAlive()) return;

        fly();

        //get a singular, random active gene to decide on the owl's actions.
        int bitIndex = this.getRandomActionGeneBitIndex();

        //Here we implement the different actions determined by the Owl's genes
        //each case represents a gene, so it can go up to case 7.
        switch(bitIndex){
            case 0:
                break;
            }    
    }
}