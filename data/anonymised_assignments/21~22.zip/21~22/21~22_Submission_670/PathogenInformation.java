/**
 * This class holds information about a certain pathogens :
 * it's apparition probability and an object representing the pathogen itself.
 *
 * @version 1.0
 */
public class PathogenInformation {

    private Pathogen pathogen;
    private double apparitionProbability;   //the probability that the pathogen appears in the field

    /**
     * Creates a new PathogenInformation object
     * @param pathogen the pathogen object
     * @param apparitionProbability the probability the pathogen appears in the field
     */
    public PathogenInformation(Pathogen pathogen, double apparitionProbability){
        this.pathogen = pathogen;
        this.apparitionProbability = apparitionProbability;
    }

    /**
     * Return the Pathogen object
     * @return the Pathogen object
     */
    public Pathogen getPathogen(){
        return this.pathogen;
    }

    /**
     * Return the apparition probability of the pathogen
     * @return the apparition probability of the pathogen
     */
    public double getApparitionProbability(){
        return this.apparitionProbability;
    }
}
