import java.util.ArrayList;
import java.util.prefs.Preferences;
import java.awt.Color;

import plot.*;
//TODO : discrepancy with this and simulator
/**
 * Simple program that looks for initial conditions in which the program runs for the 
 * longest time possible.
 *
 * @version 1
 */
public class StableEnvironmentFinder {
    private Preferences prefs;              //the Preferences object
    private StatisticsCalculator stats;     

    private ArrayList<Double> countData;    //the number of counts for every environment

    private ArrayList<OrganismInformation> organismsInfo;

    /**
     * Create a new StableEnvironmentFinder object and start searching.
     */
    public StableEnvironmentFinder(){
        prefs = Preferences.userRoot().node(System.getProperty("user.dir"));
        stats = new StatisticsCalculator();

        organismsInfo = null;

        countData = new ArrayList<>();

        findBestEnvironmentWithRandomSampling();
    }

    /**
     * Looks for the best environment by sampling random initial conditions.
     */
    private void findBestEnvironmentWithRandomSampling(){
        long startTime = System.currentTimeMillis()/1000;

        double bestCount = -1;
        double currentCount;
        double[] randomProbs;

        double[] best = null;

        for (int j=0; j<10; j++){
            Simulator sim = new Simulator();

            //get organismInfo from simulator
            if (organismsInfo == null){
                organismsInfo = sim.getOrganismInformations();
                best = new double[organismsInfo.size()];
            }

            currentCount = sim.simulate(10_000);

            if (currentCount >= bestCount){

                //update the best initial conditions
                for (int orgIndex = 0; orgIndex < this.organismsInfo.size(); orgIndex++){
                    OrganismInformation orgInfo = this.organismsInfo.get(orgIndex);
                    best[orgIndex] = prefs.getDouble( orgInfo.getOrganismName(), orgInfo.getOrganismCreationProbability() );
                }

                bestCount = currentCount;
            }

            randomProbs = new double[ best.length ];

            for ( int i = 0; i < randomProbs.length; i++ )
            {
                randomProbs[i] = Math.random()/2;
            }

            countData.add(currentCount);
            setProbabilities(randomProbs);
        }

        //show the data
        System.out.println(String.format("The best count was %s with these stats : " , bestCount));

        for (int orgIndex = 0; orgIndex < this.organismsInfo.size(); orgIndex++){
            OrganismInformation orgInfo = this.organismsInfo.get(orgIndex);
            System.out.println(String.format("%s : %.4f ", orgInfo.getOrganismName(), best[orgIndex]));
        }

        System.out.println(String.format("The program took %ss to complete.", System.currentTimeMillis()/1000 - startTime));

        setProbabilities(best);
    }

    /**
     * Set the preferences' data to the given new data.
     * @param newProbs the new data that we want to set
     */
    private void setProbabilities(double[] newProbs){
        for (int orgIndex = 0; orgIndex < this.organismsInfo.size(); orgIndex++){
            OrganismInformation orgInfo = this.organismsInfo.get(orgIndex);
            prefs.putDouble( orgInfo.getOrganismName(), newProbs[orgIndex] );
        }
    }

    /**
     * Draw the graph of the total number of steps against probability of occurrrence.
     */
    public void getGraphOfCounts(){
        Double[] arrayCountData =  countData.toArray(new Double[0]);

        stats.setData(arrayCountData);
        ArrayList<Data> data = new ArrayList<>();

        data.add(new Data(stats.getProbabilitySpread(), Color.RED, "Steps"));

        new Plotter( data, "Graph of total number of steps against probability of occurrence","Total number of Steps", "Probability of Occurrence").setVisible(true);
    }
}