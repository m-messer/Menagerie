import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Simple class that allows us to know what buttons of a mouse have been clicked.
 *
 * @version 1
 */
class MyMouseListener extends MouseAdapter {
    private boolean leftButtonClicked = false;
    private boolean rightButtonClicked = false;

    /**
     * The adapted function that is activated when the mouse is clicked.
     */
    @Override
    public void mouseClicked(MouseEvent e) {

        if (e.getButton() == MouseEvent.BUTTON1) { // BUTTON1 = left button
            leftButtonClicked = true;
        }else if ( e.getButton() == MouseEvent.BUTTON2 || 
                   e.getButton() == MouseEvent.BUTTON3 ){ // BUTTON2/BUTTON3 = right button
            rightButtonClicked = true;
        }
    }

    /**
     * Returns whether the left button has been clicked.
     * @return whether the left button has been clicked
     */
    public boolean didLeftButtonClick(){
        return this.leftButtonClicked;
    }

    /**
     * Toggles the state of the leftButtonClicked field.
     */
    public void toggleLeftButtonClicked(){
        this.leftButtonClicked = !this.leftButtonClicked;
    }

    /**
     * Returns whether the right button has been clicked, and toggles it's state.
     * @return whether the right button has been clicked
     */
    public boolean didRightButtonClick(){
        return this.rightButtonClicked;
    }

    /**
     * Toggles the state of the rightButtonClicked field.
     */
    public void toggleRightButtonClicked(){
        this.rightButtonClicked = !this.rightButtonClicked;
    }
}