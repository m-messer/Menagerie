import java.awt.*;
import javax.swing.*;

import java.awt.Color;

/**
 * 
 * A class creating a view frame for to show an organism's data
 * onto a JFrame.
 *
 * @version 1.0
 */
class OrganismView extends JFrame{

    //the constant widht height of the window
    private static final int WIDTH = 200;
    private static final int HEIGHT = 300;

    //the padding between the window and the organism's data
    private static final int PADDING = Math.max(WIDTH, HEIGHT)/15;

    private Organism organism;
    private Color color;

    /**
     * Create an OrganismView object, thus creating a frame with the object's
     * data showing. The color is the same color used to show the organism on the field grid.
     * @param organism the organism whose data we want to view
     * @param color the color of the organism on the field grid
     */
    public OrganismView(Organism organism, Color color){
        super("");

        this.organism = organism;

        //if color null, set black as default
        this.color = (color == null) ? Color.BLACK : color;


        getContentPane().setBackground(Color.WHITE);
        setSize(WIDTH, HEIGHT);

        setLocationRelativeTo(null);
        Toolkit.getDefaultToolkit().setDynamicLayout(false); 
    }

    /**
     * Method to paint/repaint the window
     */
    public void paint(Graphics g) {
        super.paint(g);

        //keeps the size constant
        setSize(WIDTH, HEIGHT);

        Graphics2D g2d = (Graphics2D) g;

        drawLayout(g2d);
        drawProperties(g2d);

    }

    /**
     * Draws the layout of the organism data viewer, with the color and organism's name
     * @param g the Graphics2D object we are painting
     */
    private void drawLayout(Graphics2D g){
        g.setStroke(new BasicStroke(2));
        g.setColor(color);

        //center it properly
        g.drawRect( PADDING, PADDING, WIDTH - 2*PADDING, HEIGHT - 2*PADDING );
        g.drawLine(PADDING, 3*PADDING, WIDTH - PADDING, 3*PADDING);

        g.setColor(Color.BLACK);
        g.drawString( organism.getClass().getName(), (WIDTH - PADDING)/2, PADDING*5/2);
    }

    /**
     * Draw all the properties of each organism type onto the data viewer.
     * Animals show their location, genes, age, gender, foodLevel, 
     * pathogen and a plant excrement (if they eat plants).
     * 
     * @param g the Graphics2D object we are painting onto
     */
    private void drawProperties(Graphics2D g){
        if (organism instanceof Animal)
        {
            Animal animal = (Animal) organism;

            //if it eats plants there is an extra property to show
            int numberOfProperties =  (animal.eatsPlants()) ? 7 : 6;

            //the vertical space between each property
            int delta = (HEIGHT - PADDING - 3*PADDING) / (numberOfProperties+1);

            drawProperty(g, "Location", "(" + animal.getLocation().toString() + ")", 3*PADDING + delta);
            drawProperty(g, "Genes", animal.getGenesString() , 3*PADDING + 2*delta);

            drawProperty(g, "Age", "" + animal.getAge(), 3*PADDING + 3*delta);

            // For gender, 1 Female, 0 Male.
            String gender = (animal.getGender() == 0) ? "Female" : "Male";
            drawProperty(g, "Gender", gender, 3*PADDING + 4*delta);

            drawProperty(g, "Food-Level", "" + animal.getFoodLevel(), 3*PADDING + 5*delta);
            drawProperty(g, "Pathogen", animal.getPathogenName(), 3*PADDING + 6*delta);

            if (animal.eatsPlants()){
                Plant excrement = animal.getPlantExcrement();

                String text = (excrement == null) ? "null" : excrement.getClass().getName();
                drawProperty(g, "Excrement", text, 3*PADDING + 7*delta);
            }



        }else if (organism instanceof Plant)
        {

            Plant plant = (Plant) organism;

            //same as above
            int numberOfProperties =  4;
            int delta = (HEIGHT - PADDING - 3*PADDING) / (numberOfProperties+1);

            drawProperty(g, "Location", "(" + plant.getLocation().toString() + ")", 3*PADDING + delta);
            
            drawProperty(g, "Depth", "" + plant.getDepth() , 3*PADDING + 2*delta);
            drawProperty(g, "Growth-rate", "" + plant.getGrowthRate() , 3*PADDING + 3*delta);

            drawProperty(g, "Pathogen", plant.getPathogenName(), 3*PADDING + 4*delta);

        }
    }

    /**
     * Draws a given property onto the window, given its name value and y-coordinate.
     * They are centered by default.
     * 
     * @param g the Graphics2D object we are painting onto
     * @param propertyName the name of the property we want to draw
     * @param propertyValue the value of the property we want to draw
     * @param y the y-coordinate of the property.
     */ 
    private void drawProperty(Graphics2D g, String propertyName, String propertyValue, int y)
    {
        String text = " " + propertyName + " : " + propertyValue;
        int textWidth = g.getFontMetrics().stringWidth(text);

        g.drawString(text, PADDING + (WIDTH - 2*PADDING)/2 - textWidth/2, y);
    }

    /**
     * Sets the size of the window to a fixed one.
     */
    public void setSize(int width, int height){
        super.setSize(WIDTH, HEIGHT);
    }
}
