import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class collects and provides some statistical data on the state 
 * of a field. It is flexible: it will create and maintain a counter 
 * for any class of object that is found within the field.
 *
 * @version 1
 */
public class FieldStats
{
    // Counters for each type of entity (fox, boar, etc.) in the simulation.
    private HashMap<Class<?>, Counter> counters;

    // A data set for the population number of any entity in the simulation,
    // at a particular time. (e.g : for wolves : population = 1000 at time = 102)
    private HashMap<Class<?>, ArrayList<double[]>> populationNumbers;

    // Whether the counters are currently up to date.
    private boolean countsValid;

    /**
     * Construct a FieldStats object.
     */
    public FieldStats()
    {
        // Set up a collection for counters for each type of animal that
        // we might find
        counters = new HashMap<>();
        populationNumbers = new HashMap<>();

        countsValid = true;
    }

    /**
     * Get details of what is in the field.
     * @return A string describing what is in the field.
     */
    public String getPopulationDetails(Field field)
    {
        StringBuffer buffer = new StringBuffer();
        if(!countsValid) {
            generateCounts(field);
        }
        for(Class<?> key : counters.keySet()) {
            Counter info = counters.get(key);
            buffer.append(info.getName());
            buffer.append(": ");
            buffer.append(info.getCount());
            buffer.append(' ');
        }
        return buffer.toString();
    }

    /**
     * Returns the population numbers, the population count and the time at which it was sampled at
     * @return the population numbers, the population count and the time at which it was sampled at
     */
    public HashMap<Class<?>, ArrayList<double[]>> getPopulationNumebers(){
        return this.populationNumbers;
    }
    
    /**
     * Invalidate the current set of statistics; reset all 
     * counts to zero.
     */
    public void reset()
    {
        countsValid = false;
        for(Class<?> key : counters.keySet()) {
            Counter count = counters.get(key);
            count.reset();
        }

        //reset only if it's at the start of the simulation: aka the
        //populationNumbers list is empty
        if (populationNumbers.size() == 0){
            resetPopulationCounts();
        }
    }

    /**
     * Increment the count for one class of animal.
     * @param animalClass<?> The class of animal to increment.
     */
    public void incrementCount(Class<?> animalClass)
    {
        Counter count = counters.get(animalClass);
        if(count == null) {
            // We do not have a counter for this species yet.
            // Create one.
            count = new Counter(animalClass.getName());
            counters.put(animalClass, count);
        }
        count.increment();
    }

    /**
     * Indicate that an animal count has been completed.
     */
    public void countFinished()
    {
        countsValid = true;
    }

    /**
     * Determine whether the simulation is still viable.
     * I.e., should it continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        // How many counts are non-zero.
        int nonZero = 0;
        if(!countsValid) {
            generateCounts(field);
        }
        for(Class<?> key : counters.keySet()) {
            Counter info = counters.get(key);

            if(info.getCount() > 0) {
                nonZero++;
            }
        }
        //bigger than 2 as we have two plant types
        return nonZero > 2;
    }

    /**
     * Updates the population numbers of each species, at a particular moment in time.
     * @param step the moment when the population numbers are sampled
     */
    public void updatePopulationNumbers(int step){
        for (Class<?> key : counters.keySet()){
            Counter info = counters.get(key);
            ArrayList<double[]> population = populationNumbers.get(key);

            if (population != null) population.add(new double[] {(double) step, (double) info.getCount()});
        }
    }

    /**
     * Resets the population counts, and creates a new empty populationNumbers instance
     * with every entity in the counters field.
     */
    public void resetPopulationCounts(){
        populationNumbers.clear();

        if (counters.size() == 0) return;

        for (Class<?> key : counters.keySet()){
            populationNumbers.put( key, new ArrayList<>() );
        }
    }
    
    /**
     * Generate counts of the number of each organism.
     * These are not kept up to date organisms
     * are placed in the field, but only when a request
     * is made for the information.
     * @param field The field to generate the stats for.
     */
    private void generateCounts(Field field)
    {
        reset();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object animal = field.getObjectAt(row, col);
                if(animal != null) {
                    incrementCount(animal.getClass());
                }
            }
        }
        countsValid = true;
    }
}
//TODO : show infected && gene distribution