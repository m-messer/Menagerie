import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.stream.IntStream;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 1
 */

public abstract class Animal extends Organism
{

    //the age to which an animal can breed
    private int breedingAge;

    // The age to which an animal can live.
    private int maxAge;

    // The likelihood of an animal breeding.
    private double breedingProbability;

    // The maximum number of births of the animal.
    private int maxLitterSize;

    //the maximum amount of food an animal can eat
    private int maxFoodValue;

    //what time of the day the animal goes to sleep
    //and all animals sleep for a third of a day
    private int sleepCycle;

    private boolean isSleeping;
    
    private int gender;         //here gender is usually 0 for male and 1 for female.
    private int age;

    //the animal's mating partner
    private Animal partner;

    //how much food the animal has eaten
    ///In effect, this is the number of steps an animal can go before it dies of malnutrition.
    private int foodLevel;

    //the class type of the animal
    private Class<?> animalType;

    //the information regarding the animal's diet (what animals it eats/how much food they consist of)
    private HashMap<Class<?>, Integer> foodInformation;

    //the last plant the animal has eaten
    private Plant plantExcrement;

    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, byte[] maleGenes, byte[] femaleGenes)
    {
        super(field, location, maleGenes, femaleGenes);

        //we assign each characteristic of the animal from the animal class to this one.
        assignCharacteristics();

        this.animalType = getAnimalType();

        this.foodInformation = getFoodInformation();
        this.plantExcrement = null;

        this.isSleeping = false;

        //in any situation, upon creation the gender is random
        this.gender = rand.nextInt(2);


        //if the animal is being instantiated, then give it a random age and foodLevel
        if (maleGenes == null || femaleGenes == null) { 
            age = rand.nextInt(maxAge);

            //if it doesn't eat, then its foodLevel is set to 1.
            if (foodInformation != null) foodLevel = rand.nextInt(maxFoodValue);
            else foodLevel = 1; 

        //when newlly born the animals' are fully satiated
        }else{
            age = 0;
            foodLevel = maxFoodValue;
        }

        setLocation(location);
    }

    /**
     * Assigns each characteristic from each individual subclass to this object's fields.
     * Moreover, modifies these base qualities depending on the animal's genes.
     */
    private void assignCharacteristics()
    {
        double[] characteristics = getCharacteristics();
        
        //here we assign the importance of an active gene on a particular characteristic
        breedingAge = (int) assignCharacteristic(characteristics[0], 5, 1);
        maxAge = (int) assignCharacteristic(characteristics[1], 10, 1);
        breedingProbability = assignCharacteristic(characteristics[2], 0.2, 2);
        maxLitterSize = (int) assignCharacteristic(characteristics[3], -1, 2);
        maxFoodValue = (int) assignCharacteristic(characteristics[4], 4 , 3);
        sleepCycle = (int) assignCharacteristic(characteristics[4], 2 , 3);

    }

    /**
     * Given the presence or absence of a gene, a base characteristic (e.g: max_age) of an animal
     * can be affected.
     * 
     * @param characteristic the characteristic affected by the gene
     * @param dominantExpressionValue how much the characteristic varies given the gene's state 
     * @param geneBitIndex the index of the gene in the chromosome (the index of the bit inside the byte)
     * @return the new adjusted characteristic
     */
    private double assignCharacteristic(double characteristic, double dominantExpressionValue, int geneBitIndex){
        if (this.isGeneBitTrue(0, geneBitIndex)){
            return characteristic + dominantExpressionValue;
        }else{
            return characteristic - dominantExpressionValue;
        }
    }

    /**
     * Get the values of the base, unmodified characteristics from each animal class
     * @return the characteristics in an array
     */
    abstract double[] getCharacteristics();

    /**
     * Get the animal class of the specfied animal
     * @return the animal's class
     */
    abstract Class<?> getAnimalType();

    /**
     * Gets the information about the diet of the animal, from the animal's class
     * @return the information about the diet of the animal
     */
    abstract HashMap<Class<?>, Integer> getFoodInformation();

    /**
     * Do a specialised action depending on the animal's class (e.g: eagles may fly),
     * or depending on the animal's genes
     * @param newAnimals a list to return newly born animals.
     */
    abstract void doSpecialisedActions(List<Organism> newAnimals);

    /**
     * This is what animals do most of the time : 
     * age, get hungry, get food and breed.
     * 
     * This method incorporates those aspects and specific aspects about an animal, thus
     * encompassing all the actions of an animal
     * @param newAnimals a list to return newly born animals
     */
    protected void act(List<Organism> newAnimals){
        incrementTime();
        
        //the animal goes to sleep at a certain time plus or minus a random element
        if (sleepCycle + rand.nextInt(sleepCycle/8) >= this.time || isSleeping) {
            isSleeping = true;

            sleep(newAnimals);
            return;
        }

        incrementAge();
        incrementHunger();

        pathogenAct();

        doSpecialisedActions(newAnimals);      

        if(isAlive()) { 

            excretePlant(newAnimals);

            giveBirth(newAnimals);      

            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = field.freeAdjacentLocation(location);
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is what animals do when they're asleep. Usually nothing.
     * @param newAnimals a list to return newly born animals
     */
    protected void sleep(List<Organism> newAnimals){
        incrementAge();
        doSpecialisedSleepActions(newAnimals);          //do actions that only certain species perform when asleep
        
        //sleep till morning, && sleep for a third of the day
        if ( (sleepCycle + Simulator.DAY_LENGTH/3)%Simulator.DAY_LENGTH >= this.time ){
            isSleeping = false;
        }

    }

    /**
     * What each animal does specifically when asleep, usually nothing.
     * @param newAnimals a list to return newly born animals
     */
    protected void doSpecialisedSleepActions(List<Organism> newAnimals){
    };

    /**
     * Return the gender of the animal
     * @return the gender of the animal
     */
    public int getGender()
    {
        return gender;
    }

    /**
     * Return the age of the animal
     * @return the age of the animal
     */
    public int getAge()
    {
        return age;
    }

    /**
     * Checks whether an animal eats a particular class of organisms.
     * @param organismClass the class of organisms the animal eats
     * @return whether or not the animal eats the class of organisms queried
     */
    public boolean eatsOrganism(Class<?> organismClass){
        for (Class<?> foodType : foodInformation.keySet()){
            if (foodType.getSuperclass().equals( organismClass ) || foodType.equals( organismClass )){
                return true;
            }
        }

        return false;
    }

    /**
     * Returns whether the animal eats plants or not
     * @return whether the animal eats plants or not
     */
    public boolean eatsPlants(){
        return eatsOrganism(Plant.class);
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Organism> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(location);
        int births = breed();

        for(int b = 0; b < births && free.size() > 0; b++) {
            Organism young;

            Location loc = free.remove(0);

            //just getting the male/femal parents sorted out
            if (this.gender == 0) young = createOffspring(field, loc, this.getGenes(), partner.getGenes());
            else young = createOffspring(field, loc, partner.getGenes(), this.getGenes());
             
            newAnimals.add( young );

        }
    }

    /**
     * Excretes an eaten plant onto the field. This plant however, could have
     * been digested by the animal, thus killing it.
     * Used to mimic seed displacement.
     * @param newAnimals 
     */
    protected void excretePlant(List<Organism> newPlants)
    {
        if ( plantExcrement != null && !plantExcrement.hasBeenDigested() ){
            List<Location> free = field.getFreeAdjacentLocations(location);

            if (free.size() > 0){
                plantExcrement.setLocation(free.remove(0));
                newPlants.add(plantExcrement);
                
            }
        }

        plantExcrement = null;

    }


    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= breedingProbability) {
            births = rand.nextInt(maxLitterSize) + 1;
        }
        return births;
    }

    /**
     * An animal can breed if it has reached the breeding age, and there is a partner nearby.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= breedingAge && isPartnerAvailable() && foodLevel > 2;
    }

    /**
     * Checks the adjacent locations for partners for the animal to mate with.
     * @return whether a partner has been found. If a partner has been found, it is 
     * assigned to a field.
     */
    private boolean isPartnerAvailable()
    {
        List<Object> possiblePartners = field.getNearbySimilarObjects(location, animalType);

        if (possiblePartners.size() == 0) return false;

        for (Object possiblePartner : possiblePartners) {
            //if they have opposing genders
            if ( ((Animal) possiblePartner).getGender() != this.gender ){
                this.partner = (Animal) possiblePartner;

                if (this.partner.isInfected()){
                    partner.infectSexually(this);
                }

                infectSexually( this.partner );         //only works if disease if sexually transitive

                return true;
            }
        }
        return false;
    }

    
    /**
     * Increase the age.
     * This could result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > maxAge) {
            setDead();
        }
    }

    /**
     * Look for food sources adjacent to the current location.
     * The live animal increasing the animals' hunger level the most is eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        //if the animal doesn't eat
        if (this.foodInformation == null || foodInformation.size() == 0) return null;
        
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();

        Organism organismEaten  = null;
        Location whereOrganismEaten = null;

        while(it.hasNext()) {
            Location where = it.next();
            Object adjObject = field.getObjectAt(where);

            if (adjObject == null) continue;

            //loop over all the possible food types
            for (Class<?> foodType : this.foodInformation.keySet()) {

                if(adjObject.getClass() == foodType) {

                    Organism organism = (Organism) adjObject;
                    int organismFoodValue = getFoodValue(foodType);

                    //if the food level is above the maximum, then avoid eating this food source
                    if (foodLevel + organismFoodValue > maxFoodValue) {
                        continue;

                    }else if(organism.isAlive()) { 
                        //looking for the best one
                        if (organismEaten == null || organismFoodValue > getFoodValue(organismEaten.getClass())) {
                            organismEaten = organism;
                            whereOrganismEaten = where;
                        }
                    }
                }
            }
        }

        if (organismEaten != null){
            foodLevel += getFoodValue(organismEaten.getClass());
            organismEaten.setDead();

            this.infectOrganism(organismEaten);         //if this animal eats an infected animal, it becomes infected

            //here the animal may eat a plant's seed, thus giving it a chance at reproduction
            if (organismEaten instanceof Plant){
                Plant plantEaten = (Plant) organismEaten;
                if (plantEaten.dropsSeeds()){
                    plantExcrement = (Plant) plantEaten.createOffspring(field, null, 0);
                }
            }
        } 

        //can return null if nothing was found
        return whereOrganismEaten;
    }

    /**
     * Returns the food value a particular animal gives to this animal
     * @param foodType the animal class that we are checking
     * @return the food value of a particaulr animal for the current object
     */
    private int getFoodValue(Class<?> foodType){
        return this.foodInformation.get(foodType);
    }

    /**
     * Returns the animal's plant excrement
     * @return the animal's plant excrement
     */
    public Plant getPlantExcrement(){
        return this.plantExcrement;
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        //if the animal doesn't have food sources, it doesn't get hungry.
        if (foodInformation == null || foodInformation.size() == 0) return;

        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Creates a new animal offspring, specified in each subclass
     * @param field the field where the animal will be born into
     * @param location the location where the animal is born in
     * @param maleGenes the genes passed on from the male parent
     * @param femaleGenes the genes passed on from the female parent
     * @return the new animal's offspring
     */
    public abstract Organism createOffspring(Field field, Location location, byte[] maleGenes, byte[] femaleGenes);

    /**
     * Returns the food level of the animal, or "hunger"
     * @return the food level of the animal, or "hunger"
     */
    public int getFoodLevel(){
        return this.foodLevel;
    }

    /**
     * Returns the class of this animal, specifically a sub-class
     * @return the class of this animal, specifically a sub-class
     */
    public Class<?> getOrganismClass(){
        return this.animalType;
    }

    /**
     * Offset the animal's age by a certain amount.
     * Used mainly by diseases to age an animal faster
     * 
     * @param offset how much the animal's age is offset by
     */
    public void offsetAge(int offset){
        IntStream.range(1, offset).forEach( i -> incrementAge());
    }

    /**
     * Offset the animal's hunger by a certain amount.
     * Used mainly by diseases to hunger an animal faster
     * 
     * @param offset how much the animal's hunger is offset by
     */
    public void offsetHunger(int offset){
        IntStream.range(1, offset).forEach( i -> incrementHunger());
    }

    /**
     * Offset the animal's perception of time by a certain amount.
     * Used mainly by diseases to make an animal sleep faster
     * 
     * @param offset how much the animal's sleep level is offset by
     */
    public void offsetSleep(int offset){
        IntStream.range(1, offset).forEach( i -> incrementTime());
    }

    /**
     * Infect the animal's sexual partner with the animal's disease
     * @param pathogen the pathogen carried by this animal
     */
    public void infectPartner(Pathogen pathogen){
        this.infectOrganism(pathogen, this.partner);
    }
}