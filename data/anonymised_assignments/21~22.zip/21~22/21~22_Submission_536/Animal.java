import java.util.List;
import java.lang.Math;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Creature
{
    // The probability for a predator to prey.
    protected static final double PREY_PROBABILITY = 0.8;
    // The total population of animals die of disease.
    public static int animalsDieOfDisease;
    
    // The animal's gender, 'f' is female and 'm' is male;
    private char gender;
    // The infection status of an animal.
    private boolean isInfected;
    

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
        gender = 'f';
        isInfected = false;
    }
    
    /**
     * Check whether the animal is male or not.
     * @return "m" if the animal is male.
     */
    protected char getGender()
    {
        return gender;
    }
    
    /**
     * Randomly assign two different kinds of genders to all the animals.
     */
    protected void setGender()
    {
        double a = Math.random();
        if (a <= 0.5) {
            gender = 'm';
        }
        if (a > 0.5) {
            gender = 'f';
        }
    }
    
    /**
     * Return the infection status of an animal.
     */
    public boolean getInfectionStatus()
    {
        return isInfected;
    }
    
    /**
     * Assign boolean value of true to an animal
     * if the animal is infected.
     */
    protected void setInfected()
    {
        isInfected = true;
    }
    
    /**
     * Assign boolean value of true to an animal
     * if the animal is cured.
     */
    protected void setCured()
    {
        isInfected = false;
    }
    
    /**
     * The healthy animals might be infected by the disease if there
     * is an infected animal nereby.
     */
    protected void infectAnimal(Disease disease)
    {
        if(this.getInfectionStatus() == true && Randomizer.getRandom().nextDouble() <= disease.INFECTION_RATE) {
            setInfected();
        }
    }
    
    /**
     * There is a certain chance that the animal recovers from disease
     * after plenty steps.
     */
    protected void cureAnimal(Disease disease)
    {
        if(getInfectionStatus() == true) {
            if(Randomizer.getRandom().nextDouble() <= disease.CURE_PROBABILITY) {
                setCured();
            }
        }
    }
    
    /**
     * Randomly set infected animals to be dead.
     */
    protected void dieOfDisease(Disease disease)
    {
        if(getInfectionStatus() == true) {
            if(Randomizer.getRandom().nextDouble() <= disease.DEATH_PROBABILITY) {
                setDead();
                animalsDieOfDisease++;
            }
        }
    }
 }
