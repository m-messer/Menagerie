import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * Wolfes age, move, eat animals, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolves (class variables).
    
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.24;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The wolf's age.
    private int age;
    // The wolf's food level, which is increased by eating rabbits.
    private int foodLevel;

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(WOLF_FOOD_VALUE);
            setGender();
        }
        else {
            age = 0;
            foodLevel = WOLF_FOOD_VALUE;
            setGender();
        }
    }
    
    /**
     * This is what the animal does most of the time.
     * In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWolves A list to return newly born panthers.
     */
    public void act(List<Creature> newWolves, Disease disease)
    {
        incrementAge();
        incrementHunger();
        
        cureAnimal(disease);
        dieOfDisease(disease);
        
        if(isAlive()) {
            giveBirth(newWolves);            
            if(!field.getWeather().equals("foggy") && Math.random() <= PREY_PROBABILITY) {
                move(disease);
            }
            else if(field.getWeather().equals("foggy") && Math.random() <= (PREY_PROBABILITY / 2)) {
                move(disease);
            }
        }
    }
    
    /**
     * The movement of an animal, it finds food and move to 
     * a new location.
     */
    private void move(Disease disease) {
        Location newLocation = search(disease);
        // Move towards a source of food if found.
        if(newLocation == null) { 
            // No food found - try to move to a free location.
            newLocation = getField().freeAdjacentLocation(getLocation());
        }
        // See if it was possible to move.
        if(newLocation != null) {
            setLocation(newLocation);
        }
        else {
            // Overcrowding.
            setDead();
        }
    }
    

    /**
     * Increase the age. This could result in the wolf's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this wolf more hungry. This could result in the wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Look for food adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location search(Disease disease)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            // Infect nearby animal if this animal has already been infected.
            if(creature instanceof Animal) {
                Animal animal = (Animal) creature;
                if(animal.getInfectionStatus() == true) {
                    infectAnimal(disease);
                }
            }
            if(creature instanceof Rat) {
                Rat rabbit = (Rat) creature;
                if(rabbit.isAlive()) { 
                    rabbit.setDead();
                    foodLevel = RAT_FOOD_VALUE;
                    return where;
                }
            }
            if(creature instanceof Deer) {
                Deer deer = (Deer) creature;
                if(deer.isAlive()) { 
                    deer.setDead();
                    foodLevel = DEER_FOOD_VALUE;
                    return where;
                }
            }
            if(creature instanceof Grass) {
                Grass grass = (Grass) creature;
                if(grass.isAlive()) { 
                    grass.setDead();
                    return where;
                }
            }
        }
        return null;
    }  
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolfes.
     */
    private void giveBirth(List<Creature> newWolves)
    {
        // New wolfes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Wolf){
               Wolf wolf = (Wolf) creature;
               if(wolf.getGender() != 'f'){
                   int births = breed();
                   for(int b = 0; b < births && free.size() > 0; b++) {
                           Location loc = free.remove(0);
                           Wolf young = new Wolf(false, field, loc);
                           newWolves.add(young);
                   } 
               }   
            }  
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A wolf can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
