import java.util.List;

/**
 * Weather class which creates weather objects on the field
 * and these weather objects have specific effects on certain
 * other objects on the field.
 *
 * @version 2022.03.02
 */
public abstract class Weather {
    private final Location location;
    private int MAX_DURATION;
    private int CURRENT_DURATION;
    private boolean active;

    /**
     * Create new weather object at location in field.
     *
     * @param location The location of the weather on the field.
     */
    public Weather(Location location) {
        this.location = location;
        active = true;
    }

    /**
     * Getter method for location of the weather object.
     *
     * @return Location of the weather object.
     */
    public Location getLocation() {
        return location;
    }

    /**
     * Setter method for the maximum number of steps a weather
     * object can exist on the field for.
     *
     * @param MAX_DURATION the lifespan of the weather object.
     */
    protected void setMAX_DURATION(int MAX_DURATION) {
        this.MAX_DURATION = MAX_DURATION;
    }

    /**
     * Increment the duration the weather object has existed
     * for.
     *
     */
    protected void incrementDuration() {
        CURRENT_DURATION += 1;
    }

    /**
     * Getter method to determine whether a weather object
     * has gone past its max lifespan.
     *
     * @return the status of the weather object.
     */
    protected boolean getActive() {
        return active;
    }

    /**
     * Getter method for the maximum number of steps a weather
     * object can exist on the field for.
     *
     */
    protected int getMAX_DURATION() {
        return MAX_DURATION;
    }

    /**
     * Getter method for the current number of steps a weather
     * object is existing.
     *
     * @return The current age of the weather object.
     */
    protected int getCURRENT_DURATION() {
        return CURRENT_DURATION;
    }

    /**
     * Setter method to alter whether the weather object
     * is active or not.
     *
     */
    protected void setInactive() {
        active = false;
    }

    /**
     * Determines whether the parsed location is the same
     * as the location of the current weather object.
     *
     * @param loc Location to be compared with.
     * @return True if the locations on the field being
     * compared are the same.
     */
    protected boolean sameLocation(Location loc) {
        return (location.getCol() == loc.getCol()) && (location.getRow() == loc.getRow());
    }

    /**
     * This method is in charge of incrementing the weather's
     * current duration, checking if the duration is past the
     * threshold and also changing the active field.
     *
     * @param animals The list of all active animals on the field.
     * @param plants  The list of all active plants on the field.
     */
    abstract public void act(List<Animal> animals, List<Plant> plants);

    /**
     * Alters the probability at which a weather object
     * affects certain plants.
     *
     * @param plant The plant that is to be affected.
     * @return a double value that is added onto the default
     * breeding value.
     */
    abstract protected double getPlantBirthProbability(Plant plant);

    /**
     * Alters the probability at which a weather object
     * affects certain animals.
     *
     * @param animal The animal that is to be affected.
     * @return a double value that is added onto the default
     * breeding value.
     */
    abstract protected double getAnimalBirthProbability(Animal animal);

    /**
     * Determines whether a specific weather type affects
     * certain animals/plants.
     *
     * @param plant  The plant being checked if affected.
     * @param animal The animal being checked if affected.
     * @return True if the object is affected by the weather type.
     */
    abstract protected boolean weatherAffects(Plant plant, Animal animal);
}
