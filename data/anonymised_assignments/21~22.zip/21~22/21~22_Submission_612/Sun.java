import java.util.List;

/**
 * Subclass of Weather. This class imitates Sun on the field.
 *
 * @version 2022.03.02
 */
public class Sun extends Weather {
    public Sun(Location location) {
        super(location);
        setMAX_DURATION(25);
    }

    /**
     * Increments sun object, and alters active field if too old.
     *
     * @param animals The list of all active animals on the field.
     * @param plants  The list of all active plants on the field.
     */
    public void act(List<Animal> animals, List<Plant> plants) {
        incrementDuration();
        if (getCURRENT_DURATION() > getMAX_DURATION()) {
            setInactive();
        }
    }

    /**
     * Determines the additional probability a plant is affected
     * by sun.
     *
     * @param plant The plant that is to be affected.
     * @return additional probability to add to breeding chance.
     */
    protected double getPlantBirthProbability(Plant plant) {
        return -1;
    }

    /**
     * Determines the additional probability an animal is affected
     * by sun.
     *
     * @param animal The animal that is to be affected.
     * @return additional probability to add to breeding chance.
     */
    protected double getAnimalBirthProbability(Animal animal) {

        if (animal instanceof Jaguar || animal instanceof Caiman || animal instanceof Anaconda) {
            return 0.15;
        } else if (animal instanceof Capybara) {
            return 0.25;
        } else if (animal instanceof Tapir) {
            return 0.25;
        } else {
            return 0;
        }
    }

    /**
     * Determines which plants and animals are affected by sun.
     *
     * @param plant  The plant being checked if affected.
     * @param animal The animal being checked if affected.
     * @return true if a specific type of animal/plant is
     * affected by sun.
     */
    protected boolean weatherAffects(Plant plant, Animal animal) {
        if (plant != null) {
            return plant instanceof Shrub || plant instanceof Fruit;
        } else {
            return animal instanceof Jaguar || animal instanceof Caiman;
        }
    }
}
