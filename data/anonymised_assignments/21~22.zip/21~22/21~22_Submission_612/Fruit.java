import java.util.List;
import java.util.Random;

/**
 * @version 2022.03.02
 */
public class Fruit extends Plant {
    // The age at which a fruit can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a fruit can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a fruit breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The age after which a fruit is ripe.
    private static final int RIPE_AGE = 5;
    // The probability that when a plant is born it is diseased.
    private static final double DISEASED_PROBABILITY = 0.1;
    // The probability that the disease spreads to another fruit.
    private static final double DISEASE_SPREAD_PROBABILITY = 0.05;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Creates a new fruit, fruits can be created in two different ways,
     * they may be born at age 0, or they may be created with a random age and hunger.
     * Each time a fruit is created they have a random chance of being diseased.
     *
     * @param randomAge if false they are born, if true they are randomly created
     * @param field     the field in which they are contained
     * @param location  the location within the field
     */
    public Fruit(boolean randomAge, Field field, Location location) {
        super(field, location);
        setDiseased(rand.nextDouble() <= DISEASED_PROBABILITY);
        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        } else {
            setAge(0);
        }
    }

    @Override
    public void grow(List<Plant> newFruits, int timeOfDay, List<Weather> weathers) {
        incrementAge();
        //If the time of day is between 12pm and 6pm the fruits reproduce, otherwise they remain static.
        if (isAlive() && (timeOfDay > 11 && timeOfDay < 17)) {
            giveBirth(newFruits, weathers);
            spreadDisease();

        }
    }

    /**
     * Check whether this fruit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the parent plant is diseased then the children will
     * also be born diseased.
     *
     * @param newFruits A list to return newly born caimans.
     */
    private void giveBirth(List<Plant> newFruits, List<Weather> weathers) {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(weathers);
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fruit young = new Fruit(false, field, loc);
            if (isDiseased()) {
                young.setDiseased(true);
            }
            newFruits.add(young);
        }
    }

    @Override
    protected boolean isRipe() {
        return getAge() >= RIPE_AGE;
    }

    @Override
    protected int getBREEDING_AGE() {
        return BREEDING_AGE;
    }

    @Override
    protected double getBREEDING_PROBABILITY() {
        return BREEDING_PROBABILITY;
    }

    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected int getMAX_AGE() { return MAX_AGE; }

    @Override
    protected double getDISEASE_SPREAD_PROBABILITY() { return DISEASE_SPREAD_PROBABILITY; }
}
