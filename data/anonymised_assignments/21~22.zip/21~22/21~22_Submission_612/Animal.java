import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.03.02
 */
public abstract class Animal {
    protected final Gender sex;
    // The animal's field.
    protected Field field;
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's position in the field.
    private Location location;
    //The age of the animal.
    private int age;
    // The animal's food level
    private int foodLevel;
    // If the animal is diseased or not.
    private boolean diseased;

    private static final Random r = new Random();

    /**
     * Create a new animal at location in field.
     * Assigns their gender.
     *
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
        sex = assignGender();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     *
     * @param newAnimals A list to receive newly born animals.
     * @param timeOfDay The current time of day in the simulation.
     * @param weathers The weathers currently on the field.
     */
    abstract public void act(List<Animal> newAnimals, int timeOfDay, List<Weather> weathers);


    /**
     * Assigns the gender to each animal with a 50% chance of
     * being either sex.
     *
     * @return Gender enum
     */
    protected Gender assignGender() {
        if (Math.random() < 0.5) {
            return Gender.MALE;
        } else {
            return Gender.FEMALE;
        }
    }

    /**
     * Indicates the sex of the current animal object.
     *
     * @return boolean value of whether the animal is male.
     */
    protected boolean genderEquals(Animal first, Animal second) {
        return first.sex == second.sex;
    }

    /**
     * Decreases the food level by one, if the anaconda's food level reaches 0,
     * then it dies.
     */
    protected void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Increases the age of the animal by one,
     * if the animal is older than the max age, then it dies.
     * If the animal is diseased then their max age is halved.
     *
     */
    protected void incrementAge() {
        setAge(getAge() + 1);
        if (isDiseased()) {
            if (getAge() > getMAX_AGE() / 2) {
                setDead();
            }
        } else if (getAge() > getMAX_AGE()) {
            setDead();
        }
    }

    /**
     * This method is used to determine whether animals are capable of
     * breeding.
     *
     * @param animal this is the animal itself
     * @param age    the current age of the animal
     * @return true if the necessary conditions for reproduction are met
     */
    protected boolean canBreed(Animal animal, int age) {

        field = getField();
        //Checks adjacent locations.
        for (Location loc : field.adjacentLocations(getLocation())) {
            //If there is an animal in one of the adjacent locations...
            if (!(field.getObjectAt(loc) == null)) {
                //If the animals are of the same class...
                if (animal.getClass() == field.getObjectAt(loc).getClass()) {
                    Animal neighbor = (Animal) field.getObjectAt(loc);
                    //If the animals are of the opposite gender...
                    if (!genderEquals(this, neighbor)) {
                        //If they are both old enough to breed...
                        if ((age >= getBREEDING_AGE()) && (neighbor.getAge() >= getBREEDING_AGE())) {
                            //Then they are capable of breeding.
                            return true;
                        }
                    }
                }
            }
        }
        //Else they are not capable of breeding.
        return false;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @param weathers The list of all weathers currently on the field.
     *                 This is needed to check if an animal's breeding
     *                 probability needs to be altered.
     * @return The number of births (maybe zero).
     */
    protected int breed(List<Weather> weathers) {
        int births = 0;
        double newBreedingProbability = getBREEDING_PROBABILITY();
        for (Weather weath : weathers) {
            if (weath.sameLocation(getLocation()) && weath.weatherAffects(null, this)) {
                if (canBreed(this, getAge())) {
                    newBreedingProbability = getBREEDING_PROBABILITY() + weath.getAnimalBirthProbability(this);
                }
            }
        }

        if (canBreed(this, getAge()) && r.nextDouble() <= newBreedingProbability) {
            births = r.nextInt(getMAX_LITTER_SIZE()) + 1;
        }
        return births;
    }

    /**
     * If the animal is diseased, it has a certain probability of
     * spreading that disease to adjacent animals of the same type.
     */
    protected void spreadDisease() {
        if (!isDiseased()) {
            return;
        }
        for (Location loc : field.adjacentLocations(getLocation())) {
            if(field.getObjectAt(loc) != null){
                if (this.getClass() == field.getObjectAt(loc).getClass()) {
                    setDiseased(r.nextDouble() <= getDISEASE_SPREAD_PROBABILITY());
                }
            }
        }
    }

    /**
     * @return The animal's field.
     */
    protected Field getField() {
        return field;
    }

    /**
     * @return The animal's location.
     */
    protected Location getLocation() {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * @return The age of the animal.
     */
    protected int getAge() {
        return age;
    }

    /**
     * Sets the age of the animal to the given input.
     * @param age Age to be set.
     */
    protected void setAge(int age) {
        this.age = age;
    }

    /**
     * Look for prey in the adjacent locations.
     * @return Where food was found, or null if it wasn't
     */
    abstract protected Location findFood();

    /**
     * @return The food level of the animal.
     */
    protected int getFoodLevel() {
        return foodLevel;
    }

    /**
     * Sets the food level of the animal to the given input.
     *
     * @param foodLevel FoodLevel to be set.
     */
    protected void setFoodLevel(int foodLevel) {
        this.foodLevel = foodLevel;
    }

    /**
     * @return True if the animal is diseased, false if not.
     */
    protected boolean isDiseased() {
        return diseased;
    }

    /**
     * Sets the value of diseased.
     *
     * @param diseased True or false.
     */
    protected void setDiseased(boolean diseased) {
        this.diseased = diseased;
    }

    /**
     * @return the minimum age to breed for the animal.
     */
    abstract protected int getBREEDING_AGE();

    /**
     * @return the breeding probability of the animal.
     */
    abstract protected double getBREEDING_PROBABILITY();

    /**
     * @return the maximum number of births an animal can have.
     */
    abstract protected int getMAX_LITTER_SIZE();

    /**
     * @return The maximum age the animal can reach.
     */
    abstract protected int getMAX_AGE();

    /**
     * @return The probability that this animal spreads disease to another.
     */
    abstract protected double getDISEASE_SPREAD_PROBABILITY();

    /**
     * Simple enum to identify the gender of each animal.
     *
     */
    enum Gender {
        MALE,
        FEMALE
    }
}
