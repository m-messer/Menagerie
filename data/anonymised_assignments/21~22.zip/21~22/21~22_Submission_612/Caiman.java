import java.util.List;
import java.util.Random;

/**
 * A class which models the behaviour of a Caiman
 * <p>
 * Code adapted from Fox class of this project, by David J. Barnes and Michael KÃÂ¶lling.
 *
 * @version 2022.03.02
 */
public class Caiman extends Animal {
    //Characteristics shared by all caimans

    // The age at which a caiman can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a caiman can live.
    private static final int MAX_AGE = 600;
    // The likelihood of a caiman breeding.
    private static final double BREEDING_PROBABILITY = 0.7;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a capybara, this is the amount of steps
    // this is the number of steps a caiman can go without eating again.
    private static final int CAPYBARA_FOOD_VALUE = 10;
    // The food value of a tapir, this is the amount of steps
    // this is the number of steps a caiman can go without eating again.
    private static final int TAPIR_FOOD_VALUE = 12;
    // The probability that when a caiman is born it is diseased.
    private static final double DISEASED_PROBABILITY = 0.0075;
    // The probability that the disease is passed to an adjacent caiman.
    private static final double DISEASE_SPREAD_PROBABILITY = 0.03;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Creates a new caiman, caimans can be created in two different ways,
     * they may be born at age 0, or they may be created with a random age and hunger.
     * Each time a caiman is created they have a random chance of being diseased.
     *
     * @param randomAge if false they are born, if true they are randomly created
     * @param field     the field in which they are contained
     * @param location  the location within the field
     */
    public Caiman(boolean randomAge, Field field, Location location) {
        super(field, location);
        setDiseased(rand.nextDouble() <= DISEASED_PROBABILITY);
        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            //Capybara food value used as it gives more range
            setFoodLevel(rand.nextInt(TAPIR_FOOD_VALUE));
        } else {
            setAge(0);
            setFoodLevel(TAPIR_FOOD_VALUE);
        }
    }

    @Override
    public void act(List<Animal> newCaimans, int timeOfDay, List<Weather> weathers) {
        incrementAge();
        //If the time of day is between 8pm and 7am the caiman functions normally, otherwise sleeps.
        if (isAlive() && (timeOfDay <= 6 || timeOfDay >= 19)) {
            incrementHunger();
            if (isAlive()) {
                giveBirth(newCaimans, weathers);
                if (isDiseased()) {
                    spreadDisease();
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    @Override
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Capybara) {
                Capybara capybara = (Capybara) animal;
                if (capybara.isAlive()) {
                    capybara.setDead();
                    setFoodLevel(getFoodLevel() + CAPYBARA_FOOD_VALUE);
                    return where;
                }
            }
            if (animal instanceof Tapir) {
                Tapir tapir = (Tapir) animal;
                if (tapir.isAlive()) {
                    tapir.setDead();
                    setFoodLevel(getFoodLevel() + TAPIR_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether this caiman is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the parent animal is diseased then the children will
     * also be born diseased.
     *
     * @param newCaimans A list to return newly born caimans.
     */
    private void giveBirth(List<Animal> newCaimans, List<Weather> weathers) {
        // New caimans are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(weathers);
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Caiman young = new Caiman(false, field, loc);
            if (isDiseased()) {
                young.setDiseased(true);
            }
            newCaimans.add(young);
        }
    }


    @Override
    protected int getBREEDING_AGE() {
        return BREEDING_AGE;
    }

    @Override
    protected double getBREEDING_PROBABILITY() {
        return BREEDING_PROBABILITY;
    }

    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected int getMAX_AGE() { return MAX_AGE; }

    @Override
    protected double getDISEASE_SPREAD_PROBABILITY() {return DISEASE_SPREAD_PROBABILITY; }
}