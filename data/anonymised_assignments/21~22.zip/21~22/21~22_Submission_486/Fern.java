import java.util.List;
import java.util.Random;

/**
 * Fern is another plant that grows alongside grass and is eaten by some dinosaurs.
 *
 * @version 2022.03.09
 */
public class Fern extends Plant
{
    // The age at which grass can start to breed.
    private static final int POLLINATION_AGE_FERN = 2;
    // The age to which grass can live.
    private static final int MAX_AGE_FERN = 30;
    // The likelihood of grass breeding.
    private static double pollinationProbability = 0.05;
    // The maximum number of births.
    private static final int MAX_GROWTH_SIZE_FERN = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomiser.getRandom();
    // The grass's age.
    private int age;

    /**
     * Constructor for objects of class Fern
     */
    public Fern(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE_FERN);
        }
    }

    /**
     * This is what the Fern does most of the time - it does not run
     * around. Sometimes it will breed or die of old age.
     * @param newFern A list to return newly born Fern.
     */
    public void act(List<Organism> newFern)
    {
        incrementAge();
        if(isAlive()) 
        {
            //reactionToWeather();
            giveBirth(newFern);          
        }
    }
    
    /**
     * Increase the age.
     * This could result in the Fern's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE_FERN) 
        {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Fern is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFern A list to return newly born Fern.
     */
    public void giveBirth(List<Organism> newFern)
    {
        // New Fern are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            Location loc = free.remove(0);
            Fern young = new Fern(false, field, loc);
            newFern.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= pollinationProbability) 
        {
            births = rand.nextInt(MAX_GROWTH_SIZE_FERN) + 1;
        }
        return births;
    }
    
    /**
     * Fern can breed if it has reached the breeding age.
     * @return true if the Fern can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= POLLINATION_AGE_FERN;
    }
}