import java.awt.*;
import javax.swing.*;
import java.util.Random;
import java.util.ArrayList;

/**
 * This class creates a new window that displays images of dinosaurs alongside facts about them.
 *
 * @version 2022.03.09
 */
public class FunFact
{
    // Instance variables for GUI.
    private JFrame factFrame;
    private JPanel imagePanel;
    private JPanel factPanel;
    // ArrayLists for all images and facts.
    private ArrayList<String> images;
    private ArrayList<String> facts;
    
    /**
     * Constructor for objects of class FunFact
     */
    public FunFact()
    {
        images = new ArrayList<>();
        images.add("dinosaurs1.jpeg"); //https://abcnews.go.com/US/species-dinosaurs-found-china-scientists/story?id=79380332
        images.add("edmontosaurus.jpeg"); //https://www.dkfindout.com/uk/dinosaurs-and-prehistoric-life/dinosaurs/edmontosaurus/
        images.add("kayentatherium.jpeg"); //https://en.wikipedia.org/wiki/Kayentatherium
        images.add("megalosaurus.jpeg"); //https://kidadl.com/dinosaur-facts/megalosaurus-facts
        images.add("tyrannosaurus.jpeg"); //https://www.dkfindout.com/us/dinosaurs-and-prehistoric-life/dinosaurs/tyrannosaurus/
        images.add("velociraptor.jpeg"); //https://jurassicpark.fandom.com/wiki/Velociraptor
        images.add("dinosaurs2.jpeg"); //https://www.bbc.co.uk/news/world-australia-57394830
        images.add("dinosaurs3.jpeg"); //https://www.sciencefocus.com/news/irelands-first-ever-dinosaurs-discovered/
        images.add("dinosaurs4.jpeg"); //https://news.mit.edu/2014/early-dinosaur-evolution-0812
        images.add("dinosaurs5.jpeg"); //https://www.smithsonianmag.com/smart-news/study-suggests-dinosaurs-were-decline-asteroid-struck-earth-180978097/
        images.add("dinosaurs6.jpeg"); //https://www.discovermagazine.com/planet-earth/how-did-dinosaurs-hear-the-world-alligators-give-us-clues
        
        facts = new ArrayList<>();
        facts.add("<html>" + "Over 700 different species of dinosaurs have been identified" + "<br>" + "and named. Of these, 108 species of dinosaurs, including the Megalosaurus," + "<br>" + "have been discovered in Britain." + "</html>"); //https://www.thedinosaurmuseum.com/dino-facts
        facts.add("<html>" + "The first dinosaur to be named was Megalosaurus, which means \"great lizard\"." + "</html>"); //The first dinosaur to be named was Megalosaurus.
        facts.add("<html>" + "Dinosaurs lived on all the continents, including Antarctica." + "</html>"); //https://www.factretriever.com/dinosaur-facts
        facts.add("<html>" + "While many people think dinosaurs were massive, dinosaurs were" + "<br>" + "usually human sized or smaller. Scientists believe that" + "<br>" + "the larger bones were just easier to be fossilized." + "</html>"); //https://www.factretriever.com/dinosaur-facts
        facts.add("<html>" + "Dinosaurs dominated Earth for over 165 million years." + "<br>" + "Humans have been around for only 2 million years." + "</html>"); //https://www.factretriever.com/dinosaur-facts
        facts.add("<html>" + "Tyrannosaurus rex had huge back legs, but its tiny" + "<br>" + "front legs were not much longer than human arms." + "</html>"); //https://www.factretriever.com/dinosaur-facts
        facts.add("<html>" + "The dinosaur with the longest name was Micropachycephalosaurus meaning \"tiny thick-headed lizard\"." + "<br>" + "Its fossils have been found in China, and it was named in" + "<br>" + "1978 by the Chinese paleontologist Dong." + "</html>"); //https://www.thedinosaurmuseum.com/dino-facts
        facts.add("<html>" + "Stegosaurus had a brain the size of a walnut - only 3 centimetres" + "<br>" + "long and weighing 75 grams. However, comparing" + "<br>" + "brain size to body size sauropodomorphs, like" + "<br>" + "Plateosaurus, were probably one of the dumbest dinosaurs." + "</html>"); //https://www.thedinosaurmuseum.com/dino-facts
        facts.add("<html>" + "The oldest known dinosaur so far discovered in Britain is Thecodontosaurus antiquus." + "<br>" + "It was discovered near Bristol in 1970 but only now has" + "<br>" + "funding been achieved to excavate the dinosaur." + "</html>"); //https://www.thedinosaurmuseum.com/dino-facts
        
        create();
    }
    
    /**
     * Creates the window and GUI for the fun fact page.
     */
    public void create()
    {
        factFrame = new JFrame();
        factFrame.setTitle("Dinosaurs Fun Fact");
        
        factFrame.setLayout(new BorderLayout());   
        
        imagePanel = new JPanel();
        displayRandomImage();
        factFrame.add(imagePanel, BorderLayout.NORTH);
        
        factPanel = new JPanel();
        displayRandomString();
        factFrame.add(factPanel, BorderLayout.SOUTH);
        
        factFrame.pack();
        factFrame.setVisible(true);
    }
    
    /**
     * @return factFrame
     */
    public JFrame getFactFrame()
    {
        return factFrame;
    }
    
    // ---- Methods to select and display a random image on an image panel. ----
    
    /**
     * Chooses one of the random names of an image from the arrayList and returns it
     * @return String of random image
     */
    private String randomImage()
    {
        Random rand1 = new Random( );
        int index1 = rand1.nextInt(images.size());
        return images.get(index1);
    }
    
    /**
     * https://stackhowto.com/how-to-display-an-image-on-jframe-in-java-swing/
     * Will take the image and display it
     */
    private void displayRandomImage()
    {
        ImageIcon icon = new ImageIcon(randomImage());
        imagePanel.add(new JLabel(icon));
    }
    
    // ---- Methods to select and display a random fact on the fact frame. ----
    
    /**
     * Generates a random fact string from the arrayList and returns this.
     * @return fact at chosen index.
     */
    private String randomString()
    {
        Random rand2 = new Random();
        int index2 = rand2.nextInt(facts.size());
        return facts.get(index2);
    }
    
    /**
     * Displays the random string generated by adding it to the factpanel
     */
    private void displayRandomString()
    {
        factPanel.add(new JLabel(randomString()));
    }
}