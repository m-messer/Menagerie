import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of dinosaurs.
 *
 * @version 2022.03.09
 */
public abstract class Dinosaur extends Organism
{
    //Probability being male or female.
    protected static final double GENDER_PROBABILITY = 0.5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomiser.getRandom();
    // Boolean variable whether or not the dinosaur is diseased.
    protected boolean hasDisease;
    
    /**
     * Constructor for dinosaur objects
     */
    public Dinosaur(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Make this dinosaur act - that is: make it do
     * whatever it wants/needs to do.
     * @param newDinosaurs A list to receive newly born dinosaurs.
     */
    abstract public void act(List<Organism> newOrganisms);
    
    /**
     * Each dinosaur has to find its own food sources.
     */
    abstract public Location findFood();
    
    /**
     * This method is used to scan the adjacent fields of a dinosaur and
     * work out of they will be infected or not.
     */
    abstract public void possibleTransmission();
    
    /**
     * To get the gender of the dinosaur
     * Has a 50/50 chance of each gender.
     */
    public boolean findGender()
    {
        return rand.nextDouble() <= GENDER_PROBABILITY;
    }
}