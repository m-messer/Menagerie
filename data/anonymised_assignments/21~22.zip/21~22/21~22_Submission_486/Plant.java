import java.util.List;

/**
 * A class representing shared characteristics of dinosaurs.
 *
 * @version 2022.03.09
 */
public abstract class Plant extends Organism
{
    // No instance fields.
    
    /**
     * Constructor for class Plant
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born dinosaurs.
     */
    abstract public void act(List<Organism> newOrganisms);
}