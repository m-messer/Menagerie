import java.util.Map;
import java.util.LinkedHashMap;
import java.util.Hashtable;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location representing its contents.
 * It uses a default background color.
 * Colors for each type of species can be defined using the setColor method.
 *
 * @version 2022.03.09
 */
public class SimulatorView extends JFrame
{
    // Color used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;
    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;
    
    // Prefix label strings.
    private final String STEP_PREFIX = "Time elapsed: ";
    private final String POPULATION_PREFIX = "Population: ";
    
    // The current state of the field.
    private Field field;
    private FieldView fieldView;
    // A statistics object computing and storing simulation information
    private FieldStats stats;
    
    // Label variables.
    private JLabel stepLabel, population, infoLabel, weatherLabel;
    // Hour, day, month, year within the simulation based on the step value.
    private int stepHours, stepDays, stepMonths, stepYears;
    // Label for the hour, day, month, year within the simulation based on the step value.
    private String stepHoursLabel, stepDaysLabel, stepMonthsLabel, stepYearsLabel;
    // Current and desired step label strings.
    private String stepLabelString, simulationStepLabelString;
    // ActionPane buttons.
    private JButton simulationButton, restartButton;
    // Slider which defines the simulation's desired duration.
    private JSlider simulationSlider;
    
    public static boolean nightTime;
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        setTitle("Dinosaurs Simulation");
        if (stepLabelString != null) 
        {
            stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        } 
        else 
        {
            stepLabel = new JLabel("No time elapsed. Start simulator.", JLabel.CENTER);
        }
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        setLocation(100, 50);

        fieldView = new FieldView(height, width);

        createGUI();
    }

    /**
     * Creates the GUI for the simulation, including buttons and labels, slider, and description.
     */
    private void createGUI()
    {
        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new BorderLayout());
        JPanel actionPane = new JPanel();

        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);
        contents.add(actionPane, BorderLayout.WEST);

        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(infoLabel, BorderLayout.CENTER);

        actionPane.setLayout (new BoxLayout (actionPane, BoxLayout.Y_AXIS));
        actionPane.setPreferredSize(new Dimension(310,400));

        JPanel textDescription = new JPanel(new FlowLayout(FlowLayout.LEFT));
        textDescription.add(new JLabel("This simulation displays a field of dinosaurs."));
        textDescription.add(new JLabel("These dinosaurs must find food to survive,"));
        textDescription.add(new JLabel("they experience disease, and various"));
        textDescription.add(new JLabel("weather conditions."));
        textDescription.add(new JLabel("Enjoy the occasional dinosaur fun fact!"));
        actionPane.add(textDescription);
        
        JPanel simulationPane = new JPanel();
        simulationPane.add(new JLabel("Use the slider to select simulation duration."));
        simulationSlider = new JSlider(0, 8952, 4392);
        simulationSlider.setPreferredSize(new Dimension(305, 80));
        simulationSlider.setMajorTickSpacing(2196);
        simulationSlider.setMinorTickSpacing(168);
        simulationSlider.setPaintTicks(true);
        simulationSlider.setPaintLabels(true);
        simulationSlider.setSnapToTicks(true);
        JLabel simulationLabel1 = new JLabel();
        JLabel simulationLabel2 = new JLabel();
        JLabel simulationLabel3 = new JLabel();
        JLabel simulationLabel4 = new JLabel();
        JLabel simulationLabel5 = new JLabel();
        simulationLabel1.setText("Simulation Duration Value: 6 months");
        
        //http://www.java2s.com/Code/JavaAPI/javax.swing/JSlidersetLabelTableDictionarylabels.htm
        Hashtable<Integer, JLabel> table = new Hashtable<Integer, JLabel>();
        table.put(0, new JLabel("0 days"));
        table.put(2196, new JLabel("3 months"));
        table.put(4392, new JLabel("6 months"));
        table.put(6588, new JLabel("9 months"));
        table.put(8952, new JLabel("1 year"));
        simulationSlider.setLabelTable(table);
        
        //////http://www.java2s.com/Tutorials/Java/Swing_How_to/JSlider/Show_JSlider_value_while_dragging.htm
        simulationSlider.addChangeListener(new ChangeListener() 
        {
                public void stateChanged(ChangeEvent e) 
                {
                    stepLabelToString(getSimulationSliderValue());
                    simulationLabel1.setText("Simulation Duration Value: ");
                    simulationLabel2.setText(stepYears + " " + stepYearsLabel + ",");
                    simulationLabel3.setText(stepMonths + " " + stepMonthsLabel + ",");
                    simulationLabel4.setText(stepDays + " " + stepDaysLabel + ",");
                    simulationLabel5.setText(stepHours + " " + stepHoursLabel);
                }
        });
        
        simulationPane.add(simulationSlider);
        
        simulationButton = new JButton();
        simulationButton.setText("Click to start simulation.");
        restartButton = new JButton();
        restartButton.setText("<html>" + "The simulation has finished." + "<br>" + "Click to restart simulation." + "</html>");
        restartButton.setVisible(false);
        
        JPanel simulationLabelPane = new JPanel();
        simulationLabelPane.setLayout(new GridLayout(5,1));
        simulationLabelPane.add(simulationLabel1);
        simulationLabelPane.add(simulationLabel2);
        simulationLabelPane.add(simulationLabel3);
        simulationLabelPane.add(simulationLabel4);
        simulationLabelPane.add(simulationLabel5);
        
        simulationPane.add(simulationLabelPane);
        simulationPane.add(simulationButton);
        simulationPane.add(restartButton);
        actionPane.add(simulationPane);
        
        JPanel weatherPanel = new JPanel();
        weatherLabel = new JLabel();
        weatherPanel.add(weatherLabel);
        actionPane.add(weatherPanel);
        
        JPanel colourCodePane = new JPanel();
        colourCodePane.setLayout (new GridLayout(9,1));
        JLabel titleLabel = new JLabel(" Dinosaur Colour Codes"); colourCodePane.add(titleLabel);
        JLabel ivyLabel = new JLabel(" Ivy"); ivyLabel.setOpaque(true); ivyLabel.setBackground(new Color(45, 250, 246)) ; colourCodePane.add(ivyLabel);
        JLabel grassLabel = new JLabel(" Grass"); grassLabel.setOpaque(true); grassLabel.setBackground(new Color(43, 140, 36)) ; colourCodePane.add(grassLabel);
        JLabel fernLabel = new JLabel(" Fern"); fernLabel.setOpaque(true); fernLabel.setBackground(new Color(185, 247, 181)) ; colourCodePane.add(fernLabel);
        JLabel kayentatheriumLabel = new JLabel(" Kayentatherium"); kayentatheriumLabel.setOpaque(true); kayentatheriumLabel.setBackground(new Color(173, 177, 255)) ; colourCodePane.add(kayentatheriumLabel);
        JLabel edmontosaurusLabel = new JLabel(" Edmontosaurus"); edmontosaurusLabel.setOpaque(true); edmontosaurusLabel.setBackground(new Color(247, 177, 250)) ; colourCodePane.add(edmontosaurusLabel);
        JLabel velociraptorLabel = new JLabel(" Velociraptor"); velociraptorLabel.setOpaque(true); velociraptorLabel.setBackground(new Color(227, 247, 2)) ; colourCodePane.add(velociraptorLabel);
        JLabel megalosaurusLabel = new JLabel(" Megalosaurus"); megalosaurusLabel.setOpaque(true); megalosaurusLabel.setBackground(new Color(250, 135, 40)) ; colourCodePane.add(megalosaurusLabel);
        JLabel tyrannosaurusLabel = new JLabel(" Tyrannosaurus"); tyrannosaurusLabel.setOpaque(true); tyrannosaurusLabel.setBackground(new Color(250, 40, 50)) ; colourCodePane.add(tyrannosaurusLabel);
        actionPane.add(colourCodePane);

        pack();
        setVisible(true);
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    {
        if(!isVisible()) 
        {
            setVisible(true);
        }

        if (stepLabelString != null) 
        {
            stepLabel.setText(STEP_PREFIX + stepLabelString);
        }

        stepLabelToString(step);
        stats.reset();
        timeOfDay();

        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) 
        {
            for(int col = 0; col < field.getWidth(); col++) 
            {
                Object dinosaur = field.getObjectAt(row, col);
                if(dinosaur != null)
                {
                    stats.incrementCount(dinosaur.getClass());
                    fieldView.drawMark(col, row, getColor(dinosaur.getClass()));
                }
                else 
                {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }
    
    // ---- Methods to set and get color in simulator. ----
    
    /**
     * Define a color to be used for a given class of dinosaur.
     * @param dinosaurClass The dinosaur's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class dinosaurClass, Color color)
    {
        colors.put(dinosaurClass, color);
    }

    /**
     * @return The color to be used for a given class of dinosaur.
     */
    private Color getColor(Class dinosaurClass)
    {
        Color col = colors.get(dinosaurClass);
        if(col == null) 
        {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else 
        {
            return col;
        }
    }
    
    // ---- Setter methods for GUI labels. ----
    
    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }
    
    /**
     * Sets the appropriate weather label
     * @param weatherLabelString
     */
    public void setWeatherLabelString(String weatherLabelString)
    {
        weatherLabel.setText(weatherLabelString);
    }
    
    // ---- Getter methods for actionpane buttons and values. ----
    
    /**
     * @return Simulation button
     */
    public JButton getSimulationButton()
    {
        return simulationButton;
    }
    
    /**
     * @return Restarting button
     */
    public JButton getRestartButton()
    {
        return restartButton;
    }
    
    /**
     * @return Value of the slider 
     */
    public int getSimulationSliderValue()
    {
        return simulationSlider.getValue();
    }
    
    // ---- Methods based on the simulation's step value. ----
    
    /**
     * Determine the values and strings for hour, day, month, and year, based on the simulation steps.
     * @param numberOfSteps
     */
    private void stepLabelToString(int numberOfSteps)
    {
        // Time values, assuming no leap years and each month to have 31 days.
        stepHours = numberOfSteps%24;
        stepDays = (numberOfSteps/24)%31;
        stepMonths = (numberOfSteps/744)%13;
        stepYears = (numberOfSteps/271560)%366;

        // Distinguishes between singular and plural for the strings hour(s), day(s), month(s), year(s).
        if (stepHours == 1) 
        {
            stepHoursLabel = "hour";
        } 
        else 
        {
            stepHoursLabel = "hours";
        }

        if (stepDays == 1) 
        {
            stepDaysLabel = "day";
        } 
        else 
        {
            stepDaysLabel = "days";
        }

        if (stepMonths == 1) 
        {
            stepMonthsLabel = "month";
        } 
        else 
        {
            stepMonthsLabel = "months";
        }

        if (stepYears == 1) 
        {
            stepYearsLabel = "year";
        } 
        else 
        {
            stepYearsLabel = "years";
        }

        // Concatenates values and strings into 1 label.
        stepLabelString = stepYears + " " + stepYearsLabel + ", " + stepMonths + " " + stepMonthsLabel + ", " + stepDays + " " + stepDaysLabel + ", " + stepHours + " " + stepHoursLabel;
    }

    /**
     * Determines the time of day by seeing what hour it is.
     */
    public void timeOfDay()
    {
        if(stepHours <= 7 || stepHours >=21) 
        {
            nightTime = true;
        } 
        else 
        {
            nightTime = false;
        }
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) 
            {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) 
                {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) 
                {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) 
            {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) 
                {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else 
                {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
