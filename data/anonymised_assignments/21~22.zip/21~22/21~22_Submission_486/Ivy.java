import java.util.List;
import java.util.Random;

/**
 * Ivy is a poisonous plant that can be eaten by some dinosaurs, who will die as a result.
 *
 * @version 2022.03.09
 */
public class Ivy extends Plant
{
    // Characteristics shared by all ivy (class variables).
    // The age at which ivy can start to breed.
    private static final int POLLINATION_AGE_IVY = 5;
    // The age to which ivy can live.
    private static final int MAX_AGE_IVY = 25;
    // The likelihood of ivy pollinating.
    private static double pollinationProbability = 0.06;
    // The maximum number of births.
    private static final int MAX_GROWTH_SIZE_IVY = 4;
    // A shared random number generator to control pollination.
    private static final Random rand = Randomiser.getRandom();
    
    // Individual characteristics (instance fields).
    // The grass's age.
    private int age;
    
    /**
     * Constructor for objects of class Ivy
     */
    public Ivy(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE_IVY);
        }
    }
    
        /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born prey.
     */
    public void act(List<Organism> newIvy)
    {
        incrementAge();
        if(isAlive()) 
        {
            //reactionToWeather();
            giveBirth(newIvy);            
        }
    }
    
    /**
     * Increase the age.
     * This could result in the Ivy's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE_IVY) 
        {
            setDead();
        }
    }
    
        /**
     * Check whether or not this Ivy is to pollenate at this step.
     * New births will be made into free adjacent locations.
     * @param newIvy A list to return newly grown Ivy.
     */
    public void giveBirth(List<Organism> newIvy)
    {
        // New Ivy are grown into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            Location loc = free.remove(0);
            Ivy young = new Ivy(false, field, loc);
            newIvy.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= pollinationProbability) 
        {
            births = rand.nextInt(MAX_GROWTH_SIZE_IVY) + 1;
        }
        return births;
    }
    
    /**
     * An Ivy can breed if it has reached the breeding age.
     * @return true if the Ivy can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        return age >= POLLINATION_AGE_IVY;
    }
}