import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's gender.
    private String gender;
    // If the animal is infected.
    private boolean infected;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        infected = false;
        this.field = field;
        setLocation(location);
        
        // 10 random numbers to generrate the animals' gender.
        
        int zeroOne = rand.nextInt(10) + 1;
        boolean randomGender = true;
        // if the random num is <= 5 the gender is Female;
        if(zeroOne <= 5){
                gender = "Female";
        }
        //if the random num is > 5 the gender is Male;
        else if(zeroOne > 5){
                gender = "Male";
        }
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * return the animal's gender
     */
    protected String getGender()
    {
        return gender;
    }
    
    /**
     * return the animal's infection status.
     * @ return true if the animal was infected by a disease - Malaria.
     */
    protected boolean getInfectionStatus()
    {
        return infected;
    }
    
    /**
     * changes the animal's infection status.
     * Originally it is not infected. infected = false.
     * This method changes infected to true.
     */
    protected void setInfectionStatus()
    {
        infected = true;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Look for disease - Malaria adjacent to the current location.
     * The first live disease - Malaria will change the animal's
     * infection status, and the disease - Malaria will die after that.
     */
    protected void gotInfected()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object m = field.getObjectAt(where);
            if(m instanceof Malaria) {
                Malaria malaria = (Malaria) m;
                if(malaria.isAlive()) {
                    infected = true;
                    malaria.setDead();
                }
            }
        }
    }
}
