import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator representing The Lion King movie,
 * based on a rectangular field
 * containing 2 lions Simba & Scar, cows, hyenas, zebras, monkeys,
 * cactus, grass, and orange trees.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 170;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a hyena will be created in any given grid position.
    private static final double HYENA_CREATION_PROBABILITY = 0.02;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.03;    
    // The probability that Simba will be created in any given grid position.
    private static final double SIMBA_CREATION_PROBABILITY = 0.025;
    // The probability that a Cow will be created in any given grid position.
    private static final double COW_CREATION_PROBABILITY = 0.1;    
    // The probability that Scar will be created in any given grid position.
    private static final double SCAR_CREATION_PROBABILITY = 0.025; 
    // // The probability that a cactus will be created in any given grid position.
    private static final double CACTUS_CREATION_PROBABILITY = 0.007; 
    // The probability that a Gras will be created in any given grid position.
    private static final double GRAS_CREATION_PROBABILITY = 0.017; 
    // The probability that a Monkey will be created in any given grid position.
    private static final double MONKEY_CREATION_PROBABILITY = 0.002; 
    // The probability that an orange tree will be created in any given grid position.
    private static final double ORANGETREE_CREATION_PROBABILITY = 0.017; 
    // The probability that malaria will be created in any given grid position.
    private static final double MALARIA_CREATION_PROBABILITY = 0.001; 
    

    // List of plants in the field.
    private List<Plants> plants;
    // List of animals in the field.
    private List<Animal> animals;
    // List of malaria in the field.
    private List<Malaria> malaria;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        malaria = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.LIGHT_GRAY);
        view.setColor(Hyena.class, Color.BLUE);
        view.setColor(Simba.class, Color.RED);
        view.setColor(Scar.class, Color.DARK_GRAY);
        view.setColor(Cow.class, Color.PINK);
        view.setColor(Cactus.class, Color.CYAN);
        view.setColor(Gras.class, Color.GREEN);
        view.setColor(Malaria.class, Color.MAGENTA);
        view.setColor(Monkey.class, Color.GRAY);
        view.setColor(OrangeTree.class, Color.ORANGE);
        
        // Setup a valid starting point.
        hurricane();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox, rabbit, lion, CowTest, hyena.
     */
    public void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if(step % 200 < 100){
                animal.act(newAnimals);
            }
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born Simbas, Scars, hyenas, cows, zebras, and monkeys to the main lists.
        animals.addAll(newAnimals);
        
        // Provide space for newborn plants.
        List<Plants> newPlants = new ArrayList<>();        
        // Let all plants act.
        for(Iterator<Plants> itt = plants.iterator(); itt.hasNext(); ) {
            Plants plants = itt.next();
            plants.act(newPlants, step);
            if(! plants.isAlive()) {
                itt.remove();
            }
        }
               
        // Add the new cactus, grass, and orange trees to the main lists.
        plants.addAll(newPlants);
        
        // Provide space for new malaria.
        List<Malaria> newMalaria = new ArrayList<>();        
        for(Iterator<Malaria> itt = malaria.iterator(); itt.hasNext(); ) {
            Malaria malaria = itt.next();
            if(! malaria.isAlive()) {
                itt.remove();
            }
        }
               
        // Add the new malaria to the main lists.
        malaria.addAll(newMalaria);
        
        if(step % 100 == 0){
            rain();
        }
        
        if(step % 1500 == 0){
            int newStep = step;
            hurricane();
            step = newStep;
        }

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void hurricane()
    {
        step = 0;
        animals.clear();
        plants.clear();
        malaria.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with lions and CowTests.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= SIMBA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Simba simba = new Simba(true, field, location);
                    animals.add(simba);
                }
                else if(rand.nextDouble() <= SCAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Scar scar = new Scar(true, field, location);
                    animals.add(scar);
                }
                else if(rand.nextDouble() <= HYENA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hyena hyena = new Hyena(true, field, location);
                    animals.add(hyena);
                }
                else if(rand.nextDouble() <= COW_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cow cow = new Cow(true, field, location);
                    animals.add(cow);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= CACTUS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cactus cactus = new Cactus(field, location);
                    plants.add(cactus);
                }
                else if(rand.nextDouble() <= ORANGETREE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    OrangeTree orangeTree = new OrangeTree(field, location);
                    plants.add(orangeTree);
                }
                else if(rand.nextDouble() <= MONKEY_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Monkey monkey = new Monkey(true, field, location);
                    animals.add(monkey);
                }
                else if(rand.nextDouble() <= MALARIA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Malaria m = new Malaria(field, location);
                    malaria.add(m);
                }
                //else leave the location empty.
            }
        }
    }
    
    /**
     * Randomly populate the field with gras because it only grows 
     * when it rains.
     */
    private void rain()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
               if(rand.nextDouble() <= GRAS_CREATION_PROBABILITY ) {
                    Location location = new Location(row, col);
                    Gras gras = new Gras(field, location);
                    plants.add(gras);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
